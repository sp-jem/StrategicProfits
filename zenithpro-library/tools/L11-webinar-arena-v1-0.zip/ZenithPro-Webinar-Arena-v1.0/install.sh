#!/bin/bash

# ZenithPro Webinar Arena Installer
# Version 1.0.0
# Exclusive to ZenithPro Members

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Get the directory where the script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo ""
echo -e "${BLUE}============================================${NC}"
echo -e "${BLUE}   ZenithPro Webinar Arena Installer v1.0  ${NC}"
echo -e "${BLUE}============================================${NC}"
echo ""

# Collect user information
echo -e "${YELLOW}Please enter your information for license tracking:${NC}"
echo ""
read -p "Your Name: " USER_NAME
read -p "Your Email: " USER_EMAIL

if [ -z "$USER_NAME" ] || [ -z "$USER_EMAIL" ]; then
    echo -e "${RED}Error: Name and email are required.${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}Installing for: $USER_NAME ($USER_EMAIL)${NC}"
echo ""

# Create directories if they don't exist
echo -e "${YELLOW}Creating directories...${NC}"

mkdir -p ~/.claude/skills
mkdir -p ~/.claude/agents
mkdir -p ~/.claude/webinar-arena/projects
mkdir -p ~/.claude/webinar-arena/win-records
mkdir -p ~/.claude/webinar-arena/synthesis-registry/successful
mkdir -p ~/.claude/webinar-arena/synthesis-registry/attempted

echo -e "${GREEN}✓ Directories created${NC}"

# Copy all skills (6 expert suites + webinar-expert + webinar-arena)
echo -e "${YELLOW}Installing webinar skills...${NC}"

SKILL_COUNT=0
for skill_dir in "$SCRIPT_DIR/skills/"webinar-*/; do
    if [ -d "$skill_dir" ]; then
        skill_name=$(basename "$skill_dir")
        cp -r "$skill_dir" ~/.claude/skills/
        echo -e "${GREEN}  ✓ $skill_name${NC}"
        ((SKILL_COUNT++))
    fi
done

if [ $SKILL_COUNT -eq 0 ]; then
    echo -e "${RED}✗ No webinar skills found in package${NC}"
    exit 1
fi

echo -e "${GREEN}✓ $SKILL_COUNT skills installed${NC}"

# Copy agents
echo -e "${YELLOW}Installing agents...${NC}"

AGENT_COUNT=0
for agent_dir in "$SCRIPT_DIR/agents/"*/; do
    if [ -d "$agent_dir" ]; then
        agent_name=$(basename "$agent_dir")
        cp -r "$agent_dir" ~/.claude/agents/
        echo -e "${GREEN}  ✓ $agent_name${NC}"
        ((AGENT_COUNT++))
    fi
done

echo -e "${GREEN}✓ $AGENT_COUNT agents installed${NC}"

# Copy arena templates
echo -e "${YELLOW}Installing arena templates...${NC}"

if [ -f "$SCRIPT_DIR/arena-templates/ledger.md" ]; then
    cp "$SCRIPT_DIR/arena-templates/ledger.md" ~/.claude/webinar-arena/
    echo -e "${GREEN}  ✓ ledger.md${NC}"
fi

if [ -f "$SCRIPT_DIR/arena-templates/config.md" ]; then
    cp "$SCRIPT_DIR/arena-templates/config.md" ~/.claude/webinar-arena/
    echo -e "${GREEN}  ✓ config.md${NC}"
fi

# Copy win records
if [ -d "$SCRIPT_DIR/arena-templates/win-records" ]; then
    cp "$SCRIPT_DIR/arena-templates/win-records/"*.md ~/.claude/webinar-arena/win-records/ 2>/dev/null || true
    echo -e "${GREEN}  ✓ win-records${NC}"
fi

# Copy synthesis registry templates
if [ -d "$SCRIPT_DIR/arena-templates/synthesis-registry" ]; then
    cp -r "$SCRIPT_DIR/arena-templates/synthesis-registry/"* ~/.claude/webinar-arena/synthesis-registry/ 2>/dev/null || true
    echo -e "${GREEN}  ✓ synthesis-registry${NC}"
fi

echo -e "${GREEN}✓ Arena templates installed${NC}"

# Create version folders for expert skills (for skill evolution)
echo -e "${YELLOW}Creating version history folders...${NC}"

for expert in fladlien cage brunson kern joon kennedy; do
    if [ -d ~/.claude/skills/webinar-$expert ]; then
        mkdir -p ~/.claude/skills/webinar-$expert/.versions
    fi
done

echo -e "${GREEN}✓ Version folders created${NC}"

# Create critique log files
echo -e "${YELLOW}Creating critique log files...${NC}"

for expert in fladlien cage brunson kern joon kennedy; do
    if [ -d ~/.claude/agents/webinar-$expert-critic ]; then
        if [ ! -f ~/.claude/agents/webinar-$expert-critic/critique-log.md ]; then
            echo "# Critique Log: Webinar ${expert^}" > ~/.claude/agents/webinar-$expert-critic/critique-log.md
            echo "" >> ~/.claude/agents/webinar-$expert-critic/critique-log.md
            echo "*Patterns detected across critiques will be logged here.*" >> ~/.claude/agents/webinar-$expert-critic/critique-log.md
            echo "" >> ~/.claude/agents/webinar-$expert-critic/critique-log.md
            echo "---" >> ~/.claude/agents/webinar-$expert-critic/critique-log.md
        fi
    fi
done

echo -e "${GREEN}✓ Critique logs created${NC}"

# Log installation
echo -e "${YELLOW}Logging installation...${NC}"

INSTALL_LOG=~/.claude/webinar-arena/install-log.md
echo "# Webinar Arena Installation Log" > "$INSTALL_LOG"
echo "" >> "$INSTALL_LOG"
echo "**Installed:** $(date)" >> "$INSTALL_LOG"
echo "**User:** $USER_NAME" >> "$INSTALL_LOG"
echo "**Email:** $USER_EMAIL" >> "$INSTALL_LOG"
echo "**Version:** 1.0.0" >> "$INSTALL_LOG"
echo "" >> "$INSTALL_LOG"
echo "## Components Installed" >> "$INSTALL_LOG"
echo "" >> "$INSTALL_LOG"
echo "- $SKILL_COUNT skills (6 expert suites + meta-skill + arena)" >> "$INSTALL_LOG"
echo "- $AGENT_COUNT Agents" >> "$INSTALL_LOG"
echo "- Arena templates (ledger, config, win-records)" >> "$INSTALL_LOG"
echo "" >> "$INSTALL_LOG"

echo -e "${GREEN}✓ Installation logged${NC}"

# Summary
echo ""
echo -e "${BLUE}============================================${NC}"
echo -e "${BLUE}         Installation Complete!            ${NC}"
echo -e "${BLUE}============================================${NC}"
echo ""
echo -e "${GREEN}Installed:${NC}"
echo "  • $SKILL_COUNT skills (complete webinar expert system)"
echo "  • $AGENT_COUNT agents"
echo "  • Arena templates"
echo ""
echo -e "${YELLOW}To verify installation, run:${NC}"
echo "  /webinar-arena"
echo ""
echo -e "${YELLOW}For help, read:${NC}"
echo "  $SCRIPT_DIR/docs/01-QUICK-START.md"
echo ""
echo -e "${GREEN}Thank you for being a ZenithPro member!${NC}"
echo ""
