# ZenithPro Webinar Arena Installer
# Version 1.0.0
# Exclusive to ZenithPro Members
# PowerShell version for Windows

$ErrorActionPreference = "Stop"

# Get the directory where the script is located
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "============================================" -ForegroundColor Blue
Write-Host "   ZenithPro Webinar Arena Installer v1.0  " -ForegroundColor Blue
Write-Host "============================================" -ForegroundColor Blue
Write-Host ""

# Collect user information
Write-Host "Please enter your information for license tracking:" -ForegroundColor Yellow
Write-Host ""
$UserName = Read-Host "Your Name"
$UserEmail = Read-Host "Your Email"

if ([string]::IsNullOrWhiteSpace($UserName) -or [string]::IsNullOrWhiteSpace($UserEmail)) {
    Write-Host "Error: Name and email are required." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Installing for: $UserName ($UserEmail)" -ForegroundColor Green
Write-Host ""

# Define Claude directory
$ClaudeDir = Join-Path $env:USERPROFILE ".claude"

# Create directories if they don't exist
Write-Host "Creating directories..." -ForegroundColor Yellow

$directories = @(
    "$ClaudeDir\skills",
    "$ClaudeDir\agents",
    "$ClaudeDir\webinar-arena\projects",
    "$ClaudeDir\webinar-arena\win-records",
    "$ClaudeDir\webinar-arena\synthesis-registry\successful",
    "$ClaudeDir\webinar-arena\synthesis-registry\attempted"
)

foreach ($dir in $directories) {
    if (!(Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
}

Write-Host "✓ Directories created" -ForegroundColor Green

# Copy all webinar skills (6 expert suites + webinar-expert + webinar-arena)
Write-Host "Installing webinar skills..." -ForegroundColor Yellow

$skillCount = 0
$skillsSource = Join-Path $ScriptDir "skills"

if (Test-Path $skillsSource) {
    Get-ChildItem -Path $skillsSource -Directory -Filter "webinar-*" | ForEach-Object {
        $skillDest = Join-Path $ClaudeDir "skills\$($_.Name)"
        Copy-Item -Path $_.FullName -Destination $skillDest -Recurse -Force
        Write-Host "  ✓ $($_.Name)" -ForegroundColor Green
        $skillCount++
    }
}

if ($skillCount -eq 0) {
    Write-Host "✗ No webinar skills found in package" -ForegroundColor Red
    exit 1
}

Write-Host "✓ $skillCount skills installed" -ForegroundColor Green

# Copy agents
Write-Host "Installing agents..." -ForegroundColor Yellow

$agentCount = 0
$agentsSource = Join-Path $ScriptDir "agents"

if (Test-Path $agentsSource) {
    Get-ChildItem -Path $agentsSource -Directory | ForEach-Object {
        $agentDest = Join-Path $ClaudeDir "agents\$($_.Name)"
        Copy-Item -Path $_.FullName -Destination $agentDest -Recurse -Force
        Write-Host "  ✓ $($_.Name)" -ForegroundColor Green
        $agentCount++
    }
}

Write-Host "✓ $agentCount agents installed" -ForegroundColor Green

# Copy arena templates
Write-Host "Installing arena templates..." -ForegroundColor Yellow

$templatesSource = Join-Path $ScriptDir "arena-templates"

# Copy ledger.md
$ledgerSource = Join-Path $templatesSource "ledger.md"
if (Test-Path $ledgerSource) {
    Copy-Item -Path $ledgerSource -Destination "$ClaudeDir\webinar-arena\ledger.md" -Force
    Write-Host "  ✓ ledger.md" -ForegroundColor Green
}

# Copy config.md
$configSource = Join-Path $templatesSource "config.md"
if (Test-Path $configSource) {
    Copy-Item -Path $configSource -Destination "$ClaudeDir\webinar-arena\config.md" -Force
    Write-Host "  ✓ config.md" -ForegroundColor Green
}

# Copy win records
$winRecordsSource = Join-Path $templatesSource "win-records"
if (Test-Path $winRecordsSource) {
    Get-ChildItem -Path $winRecordsSource -Filter "*.md" | ForEach-Object {
        Copy-Item -Path $_.FullName -Destination "$ClaudeDir\webinar-arena\win-records\" -Force
    }
    Write-Host "  ✓ win-records" -ForegroundColor Green
}

# Copy synthesis registry
$synthesisSource = Join-Path $templatesSource "synthesis-registry"
if (Test-Path $synthesisSource) {
    Copy-Item -Path "$synthesisSource\*" -Destination "$ClaudeDir\webinar-arena\synthesis-registry\" -Recurse -Force 2>$null
    Write-Host "  ✓ synthesis-registry" -ForegroundColor Green
}

Write-Host "✓ Arena templates installed" -ForegroundColor Green

# Create version folders for expert skills
Write-Host "Creating version history folders..." -ForegroundColor Yellow

$experts = @("fladlien", "cage", "brunson", "kern", "joon", "kennedy")
foreach ($expert in $experts) {
    $expertDir = "$ClaudeDir\skills\webinar-$expert"
    if (Test-Path $expertDir) {
        $versionsDir = Join-Path $expertDir ".versions"
        if (!(Test-Path $versionsDir)) {
            New-Item -ItemType Directory -Path $versionsDir -Force | Out-Null
        }
    }
}

Write-Host "✓ Version folders created" -ForegroundColor Green

# Create critique log files
Write-Host "Creating critique log files..." -ForegroundColor Yellow

foreach ($expert in $experts) {
    $criticDir = "$ClaudeDir\agents\webinar-$expert-critic"
    if (Test-Path $criticDir) {
        $critiqueLog = Join-Path $criticDir "critique-log.md"
        if (!(Test-Path $critiqueLog)) {
            $expertCapitalized = (Get-Culture).TextInfo.ToTitleCase($expert)
            $content = @"
# Critique Log: Webinar $expertCapitalized

*Patterns detected across critiques will be logged here.*

---
"@
            Set-Content -Path $critiqueLog -Value $content
        }
    }
}

Write-Host "✓ Critique logs created" -ForegroundColor Green

# Log installation
Write-Host "Logging installation..." -ForegroundColor Yellow

$installLog = "$ClaudeDir\webinar-arena\install-log.md"
$logContent = @"
# Webinar Arena Installation Log

**Installed:** $(Get-Date)
**User:** $UserName
**Email:** $UserEmail
**Version:** 1.0.0

## Components Installed

- $skillCount skills (6 expert suites + meta-skill + arena)
- $agentCount Agents
- Arena templates (ledger, config, win-records)

"@
Set-Content -Path $installLog -Value $logContent

Write-Host "✓ Installation logged" -ForegroundColor Green

# Summary
Write-Host ""
Write-Host "============================================" -ForegroundColor Blue
Write-Host "         Installation Complete!            " -ForegroundColor Blue
Write-Host "============================================" -ForegroundColor Blue
Write-Host ""
Write-Host "Installed:" -ForegroundColor Green
Write-Host "  • $skillCount skills (complete webinar expert system)"
Write-Host "  • $agentCount agents"
Write-Host "  • Arena templates"
Write-Host ""
Write-Host "To verify installation, run:" -ForegroundColor Yellow
Write-Host "  /webinar-arena"
Write-Host ""
Write-Host "For help, read:" -ForegroundColor Yellow
Write-Host "  $ScriptDir\docs\01-QUICK-START.md"
Write-Host ""
Write-Host "Thank you for being a ZenithPro member!" -ForegroundColor Green
Write-Host ""
