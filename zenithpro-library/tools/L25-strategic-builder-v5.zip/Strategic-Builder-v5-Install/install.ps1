# Strategic Builder v5 - Windows Installer

Write-Host "============================================"
Write-Host "  Strategic Builder v5 Installer"
Write-Host "  The Complete Software Engineering System"
Write-Host "============================================"
Write-Host ""

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$TargetDir = "$env:USERPROFILE\.claude\skills"

if (-not (Test-Path $TargetDir)) {
    Write-Host "Creating skills directory at $TargetDir..."
    New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
}

Write-Host "Installing skills..."

$Skills = @("strategic-builder")

foreach ($skill in $Skills) {
    Write-Host "  -> $skill"
    Copy-Item -Path "$ScriptDir\skills\$skill" -Destination $TargetDir -Recurse -Force
}

Write-Host ""

# Verify
$AllGood = $true
foreach ($skill in $Skills) {
    if (-not (Test-Path "$TargetDir\$skill")) {
        Write-Host "ERROR: $skill failed to install."
        $AllGood = $false
    }
}

if ($AllGood) {
    Write-Host "============================================"
    Write-Host "  Installation Complete!"
    Write-Host "============================================"
    Write-Host ""
    Write-Host "Skills installed:"
    Write-Host "  - strategic-builder   (v5 — The Complete Software Engineering System)"
    Write-Host ""
    Write-Host "How to run:"
    Write-Host "  1. Restart Claude Code"
    Write-Host "  2. Type: /strategic-builder"
    Write-Host ""
} else {
    Write-Host ""
    Write-Host "ERROR: Installation failed."
    Write-Host "Check that the skills/ folder is intact in this package."
}
