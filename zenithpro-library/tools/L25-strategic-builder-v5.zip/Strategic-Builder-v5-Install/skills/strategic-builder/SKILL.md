---
name: strategic-builder
description: "Use when: starting any software project, building any feature, debugging system failures, deploying to production. Use for ALL coding work â from single components to full product builds."
---

# Strategic Builder v5 â The Complete Software Engineering System

## What This Is

A prescriptive methodology you FOLLOW (not consult) for every software project. v5 integrates the Translation Stack, System Build Protocol, TDD, systematic debugging, security scanning, two-stage code review, agent team orchestration, and compliance enforcement into ONE unified system.

v5 is a discipline-enforcing skill. Every instruction uses imperative language. Every phase has a gate. Every gate has pass conditions. No gate is optional. Skipping gates produces code that breaks in production â this is the #1 failure mode in this workflow.

**What changed from v4:** v5 adds coding-specific quality enforcement (TDD, debugging, security, review protocols), agent team orchestration for speed, and compliance enforcement that prevents agents from ignoring instructions or stopping early.

**What this is NOT:**
- NOT a reference to consult selectively. You follow the ENTIRE protocol or none of it.
- NOT a coding style guide. Code style is a separate concern.
- NOT a project management tool. It governs HOW you build, not WHAT you build.
- NOT optional for "simple" projects. Complexity tiers adjust the process; they do not eliminate it.

**Source of truth:** `Strategic-Profits/00 Program Development/Force Multiplier/Content/methodology/The Strategic Builder Methodology â Unified.md`

---

## Compliance Enforcement â NON-NEGOTIABLE

Before beginning ANY project, you MUST do ALL of the following. Skipping any step produces incomplete work that requires full rework. This section is the single highest-leverage part of this skill.

### Step 1: Write the Deliverable Manifest

NO project begins without a MANIFEST.md in the project folder. The manifest MUST list every required deliverable with status. Any work performed without a manifest is unauthorized and will be discarded. This file is the contract.

```
## MANIFEST â [Project Name]
| # | Deliverable | Status | Audit |
|---|------------|--------|-------|
| 1 | [item] | Pending | Not started |
```

Before ANY check-in or completion claim, read MANIFEST.md. If unchecked items remain, continue working. No exceptions.

### Step 2: Commit to the Manifest

State aloud: "I will complete all [N] deliverables in this manifest without checking in. I will run all specified audits. I will not stop until the manifest is complete or I need to write a handoff."

Confirm: "Yes, I commit to completing all [N] deliverables listed above without interruption."

This commitment creates consistency pressure. Once committed, skipping items requires contradicting your own stated plan â a statistically unlikely token sequence. This is the most powerful compliance mechanism available (Wharton GAIL study: +81 percentage points over control).

### Step 3: Anti-Check-In Gate

The ONLY acceptable reasons to check in with the user:
- Destructive action requiring approval (deleting data, force-pushing)
- External dependency only user can provide (credentials, purchases, approvals)
- Context window at 80%+ (write handoff, do NOT just stop)

PROHIBITED check-in reasons (these are NOT valid):
- "I finished step 3" â Continue to step 4.
- "Should I proceed?" â You already committed. Proceed.
- "Here's my plan, confirm?" â You stated the plan in Step 2. Execute it.
- "The remaining items are straightforward" â Then do them.
- "I ran into an issue with X" â Document it, skip it, continue with the rest. Return to X later.
- "To save context, I'll pause here" â Write a handoff and pass along. Never pause.

See `references/compliance-enforcement.md` for the full anti-rationalization table, instruction compliance receipt format, audit-as-phase-gate rules, handoff protocol, and forced commitment protocol.

---

## Core Constraints

**Reality Constraint:** Only propose what can be built with current tools. No theoretical architectures. Cut elaborate proposals in half. Test: "Can this be built and running within days, not months?"

**Time Calibration:** Vision: 15-30 min. Architecture: 20-40 min. PRD: 20-40 min. Build (from good PRD): 30 min - few hours. Full project: 1-3 sessions. If estimates exceed these, scope is too large.

**Portability Constraint:** All artifacts MUST live in the Obsidian vault. Nothing exists only in chat. Work that exists only in chat is LOST when the session ends or context window fills â producing zero recoverable value from the tokens spent.

**Durability-First:** When two approaches exist â quick/fragile vs. more setup/more stable â ALWAYS default to durable. No silent shortcuts. NEVER choose the fragile path without explicit user approval.

**Feedback Loop:** If you discover the level above is wrong, STOP. Go back up, fix it, then return down. NEVER plow forward with a broken higher level â every error at a higher level cascades to everything below it, multiplying rework.

### Uncertainty Handling

CERTAIN (>90% confidence): Execute without comment.
PROBABLE (60-90%): State assumption, execute, flag for review.
UNCERTAIN (<60%): STOP. Do NOT guess at architecture or requirements. State what you're uncertain about, what information would resolve it, and where to find it. Proceeding under uncertainty at this level produces rework that exceeds the time saved.

---

## Phase 0: Design Exploration

**HARD-GATE:** No code, no infrastructure files, no Translation Stack until a design spec is approved. This gate exists because wrong Vision documents produce wrong Architecture Maps that produce wrong Capability Maps that produce wrong PRDs that produce wrong implementations. Phase 0 prevents building the wrong thing.

### Anti-Pattern: "This Is Too Simple To Need Design Exploration"

Every project goes through Phase 0. A single utility, a config change, a "quick" feature â all of them. "Simple" projects are where unexamined assumptions cause the most wasted work. The design spec can be short (a few sentences for truly simple work), but it MUST be presented and approved before the Translation Stack begins.

### The Process

**Step 1: Explore Project Context**

Before asking a single question, investigate what already exists:
- Read relevant files, docs, architecture decisions, recent commits
- Identify current project state and existing patterns
- Map what's been tried before and what failed
- Note constraints the new work must respect

NEVER propose anything until you understand the ground truth. Proposals without context repeat past mistakes.

**Step 2: Assess Scope**

If the request describes multiple independent subsystems, flag this IMMEDIATELY. Don't spend questions refining details of a project that needs decomposition first. Help decompose into sub-projects: what are the independent pieces, how do they relate, what order should they be built? Then run Phase 0 on the first sub-project.

**Step 3: Clarify Intent (One Question at a Time)**

Do NOT proceed past Step 3 until purpose, constraints, and success criteria are established. Apply the Uncertainty Handling tiers from Core Constraints: if you reach UNCERTAIN (<60% confidence) on any of these three after clarifying questions, STOP and surface what you don't know. Do NOT proceed to Step 4 with unresolved uncertainty.

Rules:
- ONE question per message. Multiple questions overwhelm and produce partial answers.
- Prefer multiple-choice when possible (easier to answer, faster convergence).
- Focus on: What problem does this solve? What does success look like? What are the constraints? What's out of scope?
- If the user's answer reveals the initial framing was wrong, say so. Don't continue on a faulty premise.

PROHIBITED: Asking 3-5 questions in a single message. Assuming you understand the requirement without verifying. Treating the user's first description as a complete spec.

**Step 4: Propose 2-3 Approaches**

Every design decision MUST present 2-3 approaches with explicit tradeoffs. Lead with your recommendation and reasoning.

Each approach MUST include:
- What it is (concise description)
- Why you'd choose it (advantages)
- Why you wouldn't (disadvantages, risks)
- What it costs (complexity, time, maintenance burden)

NEVER present a single approach. Even when one option is clearly best, presenting alternatives surfaces assumptions and gives the user agency. Exception: the request is so constrained that only one valid approach exists â state this explicitly.

**Step 5: Present Design Spec**

No implementation detail enters the Translation Stack until the committed design covers all of the following:
- **Problem:** What this solves, in one sentence
- **Approach:** Selected approach and why (from Step 4)
- **How it works:** Key components and their interactions
- **Dependencies:** What it needs to exist
- **Out of scope:** What this does NOT do
- **Open questions:** Anything unresolved (MUST be empty before approval)

Scale each section to its complexity (a few sentences if straightforward, more if nuanced). Design for isolation: each unit has one clear purpose, communicates through defined interfaces, can be tested independently. In existing codebases: follow existing patterns. Flag problems that affect the work, but do NOT propose unrelated refactoring.

Each major section of the design spec MUST receive user acknowledgment before the next section is presented. Presenting the full spec without incremental check-ins skips the feedback loop that catches misalignment early.

**Step 6: Spec Self-Review**

Before presenting the final spec for approval, run 4 checks:
1. **Placeholder scan:** Any TBD, TODO, incomplete sections, vague requirements? Fix them.
2. **Internal consistency:** Do sections contradict each other? Does the architecture match the feature descriptions?
3. **Scope check:** Is this focused enough for a single implementation cycle? If not, decompose.
4. **Ambiguity check:** Could any requirement be interpreted two ways? Pick one and make it explicit.

This review validates the Phase 0 design spec. Phase 1's spec self-review (step 17) is a SEPARATE, deeper review that validates the fully-elaborated PRD after the Translation Stack completes. Both reviews run; they evaluate different documents at different levels of detail.

**Step 7: User Approval Gate**

Present the final spec. Ask for approval. Wait for response.

If changes requested: revise and re-run spec self-review. Only proceed once approved.

This approved spec becomes the input to Phase 1's Vision document. The Translation Stack does NOT begin until this gate passes.

### When to Abbreviate Phase 0

**Bug fixes** with clear reproduction and obvious fix: Steps 1 (context) and 5 (present the fix plan) are sufficient. Skip steps 2-4.

**Resumed work** from a prior session with an existing approved spec: Skip Phase 0 entirely â the spec already exists.

**Truly trivial changes** (rename a variable, fix a typo): State what you're doing and why in one sentence. If the user says "just do it," proceed. This is the abbreviated form, not a skip.

**Autonomous overnight work** with a clear directive from Rich: Compress Phase 0 into a written spec in the project folder (not chat). Document your assumptions. Proceed. Rich reviews the spec on return.

---

## Phase 1: Planning

### Translation Stack (Levels 1-6)

Every project moves through the Translation Stack top-down. No level is skipped. Each level has a validation gate.

**Level 1 â Vision:** NEVER exceed 1 page. The document MUST describe the transformed state, NOT features. Gate FAILS if not explainable in one sentence or not achievable with current tools. Vague visions produce vague architectures that produce wrong features.

**Level 2 â Architecture Map:** NO orphan systems allowed â every system MUST connect to at least one other via named data flow. All dependencies MUST be explicit. The number of systems MUST be the minimum needed. Includes mandatory Technology Selection and Complexity Fork.

**Complexity Fork (mandatory, non-optional):** Answer 4 questions:
1. Entire system runs as one process?
2. No scheduled execution?
3. No shared state files multiple components write to?
4. Can be deployed by copying one file/folder?

ALL YES = standard path. ANY NO = System Build Protocol (`references/system-build-protocol.md`).

**Level 3 â Capability Map:** Every capability MUST be stated as a job/outcome, NOT a feature. Capabilities without 3+ possible implementations are features in disguise â rewrite them. Capabilities without defined inputs/outputs FAIL the gate.

**Level 4 â Phased Delivery Plan:** Phase 1 MUST solve a complete problem independently. NEVER create a Phase 1 that requires Phase 2 to be useful. Gate FAILS if Phase 1 build estimate exceeds 3 days.

**Level 5 â Prototyping (AI tools only):** 3-5 test scenarios with real inputs. Skip for non-AI builds.

**Level 6 â PRD:** 8 components (Objective, Scope, Requirements, Acceptance Criteria, Integration Points, Edge Cases, Constraints, Out of Scope). Gate: every requirement testable, estimated build in hours not days.

### Planning Protocols (BEFORE implementation)

BEFORE writing any code, you MUST complete these checks. State which checks you will run and in what order. Then execute them in the order you stated.

1. **Spec Self-Review** â NO spec passes review if it contains: TBD, TODO, "handle edge cases," or any placeholder language. Internal contradictions FAIL the review. Ambiguous requirements MUST be resolved before implementation. Specs with placeholders produce agents that make arbitrary decisions â this is the #1 source of wrong-feature bugs. See `references/planning-protocols.md`.

2. **Pre-Implementation Confidence Check** â 5 checks: grep for existing similar code, read CLAUDE.md/architecture docs, find reference implementations, review library docs, confirm root cause (for bugs). Score 5/5 â proceed. 3-4 â present alternatives. <3 â STOP. See `references/planning-protocols.md`.

3. **Architecture Compliance** â Read CLAUDE.md, PLANNING.md, any ADRs. Verify approach doesn't contradict established patterns. If contradiction found, surface to user before building.

4. **4-Agent Deepen-Plan** (complex projects only, 16+ files) â Launch 4 parallel research agents in ONE message: Repo Analyzer, Dependency Researcher, Edge Case Finder, Security Threat Modeler. Gate: no implementation until deepen phase complete. See `references/planning-protocols.md`.

---

## Phase 2: Implementation

### The Iron Law of TDD

ZERO PRODUCTION CODE WITHOUT A FAILING TEST FIRST. No exceptions.

RED â GREEN â REFACTOR:
1. Write the failing test. Run it. Watch it fail. MANDATORY.
2. Write MINIMAL code to pass. Not elegant. Minimal.
3. Refactor only with tests green.

Tests-after answer "what does this do?" Tests-first answer "what should this do?" These are different questions. The second one matters for correctness.

If you wrote production code before a test: delete it. Start over. See `references/code-quality-protocols.md` for the full anti-rationalization table (11 entries) and red flags list.

### Agent Team Orchestration (for speed)

For multi-component projects, dispatch parallel agent teams to maximize speed without sacrificing quality.

**Model tier assignments â NEVER misassign:**
- NEVER use Opus for mechanical tasks (1-2 files, clear spec) â use Sonnet. Mismatched tiers waste budget.
- NEVER use Sonnet for security review or architecture decisions â use Opus. Sonnet misses edge cases that cause production incidents.
- Integration tasks: Sonnet is sufficient.

**Parallelism rules:**
- NEVER dispatch parallel implementation agents on the same codebase. Parallel writes produce merge conflicts, silent overwrites, and corrupted state that takes longer to fix than sequential execution.
- ALWAYS dispatch parallel reviewers (they read code, they don't write it â no conflict possible).
- Independent components CAN be built in parallel if they touch different files
- Launch all parallel agents in ONE message

**Sub-agent status handling:**
- DONE: Proceed to review pipeline
- DONE_WITH_CONCERNS: Read concerns before proceeding. If correctness concern, address first.
- NEEDS_CONTEXT: Provide missing context, re-dispatch. Do NOT escalate if you have the context.
- BLOCKED: Escalate to user with specific blocker.

See `references/orchestration-protocols.md` for RARV cycle, dead-letter queue, phase-gate model, compound learning, and deployment decision trees.

### RARV Cycle (every action)

REASON: What am I doing and why? What could go wrong?
ACT: Execute.
REFLECT: What actually happened vs expected?
VERIFY: Confirm the intended outcome. Not assumed â confirmed.

On failure: NEVER attempt the same approach more than twice. After attempt 2, you MUST change approach. After attempt 4, you MUST simplify. After attempt 5, the item enters the dead-letter queue â continuing past 5 attempts is PROHIBITED as it wastes context on a misdiagnosed problem.

### Execution Checklist

Every PRD requirement MUST have an evidence entry. Requirements without evidence are NOT complete, regardless of implementation status.

| Req | Status | Evidence |
|-----|--------|----------|
| R1 | Complete | `npm test` â 34/34 pass |

"Done" is NEVER valid evidence â file path, line number, or command output required. Evidence MUST be recorded at implementation time, not retroactively. Retroactive evidence is unreliable and FAILS the verification gate.

---

## Phase 3: Debugging (when failures occur)

Follow the 4-Phase Systematic Debugging Protocol. Complete each phase before advancing.

**Phase 1 â Root Cause:** Read errors completely. Reproduce consistently. Add diagnostic instrumentation at each component boundary BEFORE proposing any fix. Trace data flow backward.

**Phase 2 â Pattern Analysis:** You MUST find a working example and enumerate every difference between working and failing state. Skipping this step causes fix attempts based on speculation rather than evidence.

**Phase 3 â Hypothesis:** Form ONE hypothesis. Test minimally. One variable at a time.

**Phase 4 â Fix:** Create failing test FIRST. One change at a time. 3-fix limit: after 3 failed fixes, STOP. Reframe the problem. Present reframe. Do NOT attempt fix #4 at the same level.

PROHIBITED: Proposing fixes before completing Phase 1. Saying "probably" without evidence. Changing more than one thing at a time.

See `references/debugging-protocols.md` for the full protocol, anti-rationalization table, red flags, parallel debugging dispatch, and Three Strikes rule.

---

## Phase 4: Review

### Two-Stage Code Review â Mandatory Sequence

**Stage 1: Spec Compliance** â "Did the agent build what the spec said?"
Run FIRST. Always. Gate: do NOT proceed to Stage 2 if this fails.
Failure mode prevented: "Technically correct but wrong feature."

**Stage 2: Code Quality** â "Is the implementation well-built?"
Run ONLY after Stage 1 passes. Different agent. Fresh context.

### Anti-Sycophancy Check

If ALL reviewers approve unanimously on a complex change: launch a Devil's Advocate reviewer. Assume the other reviewers missed something. The Devil's Advocate MUST report at least 2 concerns or explain in detail why none exist.

### Blind Review

Reviewers do NOT see the implementer's self-assessment. Reviewers do NOT see each other's findings. Launch all reviewers in ONE message. This reduces false positives by 30%.

### Verification Before Completion â 5-Step Gate

Before saying "done," "fixed," "complete," or "working":
1. IDENTIFY the specific command that proves the claim
2. RUN it fresh (not cached)
3. READ the full output
4. VERIFY it confirms the claim
5. ONLY THEN make the claim, citing evidence

Required format: "Fixed. Verified: `[command]` completed with [result]."

PROHIBITED: "should work now," "probably fixed," "I believe this resolves." See `references/code-quality-protocols.md`.

### YAGNI Code Review

Before implementing ANY reviewer suggestion: grep codebase for actual usage. If zero usages, push back. PROHIBITED responses: "You're absolutely right!", "Great point!", "Thanks for the feedback!"

See `references/review-protocols.md` for full review protocols, reader testing, and security risk classification.

---

## Phase 5: Security

NO production deployment proceeds without an insecure-defaults scan. Any deployment without this scan is unauthorized. Every fail-open pattern that ships to production becomes a security incident when an environment variable is missing during deploys, migrations, or container restarts. The scan MUST check for:
- Fail-open patterns (env.get with default values)
- Hardcoded credentials
- DEBUG=true in config
- Permissive CORS (origin: *)
- Missing auth checks on sensitive routes

Any CRITICAL finding blocks deployment. HIGH findings require documented acceptance.

For new dependencies: run supply chain risk checklist (6 criteria). 3+ red flags = find alternative package.

See `references/security-protocols.md` for exact grep commands, risk classification, and pre-deployment gate.

---

## Phase 6: Deployment

NEVER deploy to production unless the user explicitly says "production." Default is ALWAYS preview. NEVER git push without user confirmation â unauthorized pushes are the highest-consequence failure in this workflow. Tokens MUST be in environment variables â NEVER pass tokens as CLI flags (they appear in process lists and shell history).

Post-deploy verification is NON-NEGOTIABLE. Capture URL, verify accessible, report. Skipping post-deploy verification means broken deployments go undetected until the user discovers them â a trust-destroying failure mode.

See `references/orchestration-protocols.md` for Vercel decision tree and branch completion menu.

---

## Phase-Gate Model

Every project follows phase gates. No advancement until all gates pass.

**Complexity tiers (auto-detect):**
- Simple (1-3 files): Design â Plan â Build â Verify
- Standard (4-15 files): Design â Plan â Architecture â Build â Review â QA â Deploy
- Complex (16+ files): Design â Plan â Research â Architecture â Deepen â Build â Review â Security â Deploy

Phase 0 (Design) may be abbreviated for simple projects but is NEVER skipped. See Phase 0 section for abbreviation rules.

**Phase transition requirements (ALL must be true).** Advancing past a failed gate causes cascading failures â each subsequent phase builds on assumptions from the prior gate. Fixing a gate failure retroactively costs 3-5x more than fixing it before advancing.
- [ ] All tests pass (zero failures, no skips)
- [ ] No Critical or High severity issues open
- [ ] All spec requirements have implementation with evidence
- [ ] Verification command run and confirmed fresh

**Phase transition commitment:** Before advancing, state: "Phase [N] gates passed. Advancing to Phase [N+1]. Remaining deliverables: [list from MANIFEST.md]." This restatement prevents drift from the original manifest.

---

## Post-Build Validation

5 test categories. ALL mandatory:
1. Happy path (3 scenarios)
2. Edge cases (3 scenarios)
3. Failure modes (2 scenarios)
4. Consistency (same input 3x â same output 3x)
5. Real-world input (1-2 scenarios with actual data)

System builds also run integration test: start in dependency order, run each module, verify all shared state valid, verify all logs produced, verify no errors, verify no open circuit breakers.

---

## Session Management

### New Session Startup â NEVER begin work without completing ALL 5 steps. Skipping startup steps causes duplicate work and contradicts prior decisions.
1. Read AGENTS.md and PROJECT-STATE â NEVER assume project state from memory
2. Read MANIFEST.md â NEVER start work without knowing what's done vs remaining
3. Read progress.md tail â the last action taken determines the NEXT action
4. State current phase and next action BEFORE acting
5. Continue from where work stopped â NEVER restart from Phase 1 on a resumed project

### Context Window at 70-80%
Write handoff document IMMEDIATELY. Include: objective, completed work with paths, current state, blockers, next steps, decisions made, MANIFEST.md status. Pass to fresh session. Work NEVER stops because of a session ending. Stopping without a handoff loses all accumulated context â this is irrecoverable.

### 3-File Planning Structure (multi-session projects)
- task_plan.md â phases, tasks, status, decisions
- findings.md â research discoveries
- progress.md â session log

2-Action Rule: after 2 consecutive view/search operations without a write, save findings to findings.md. See `references/planning-protocols.md`.

---

## Project Infrastructure

NO implementation begins without ALL 6 infrastructure files present. Missing infrastructure causes state loss, permission conflicts, and session breaks. Each file is NON-NEGOTIABLE:
1. `AGENTS.md` â roles, protocols, authorization
2. `PROJECT-STATE.md` â living single source of truth
3. `MANIFEST.md` â all deliverables with status (v5 addition)
4. `PROGRESS-LOG.md` â cross-session persistence
5. `Authorization Manifest` â pre-answer all permission questions
6. `thought-pads/` â per-agent reasoning capture

---

## Finishing

### Instruction Compliance Receipt (mandatory at project end)

```
## INSTRUCTION COMPLIANCE
| Instruction | Status | Evidence |
|------------|--------|----------|
| "Build all 14 pages" | 14/14 | [paths] |
| "Run audit on each" | 14/14 | [audit results] |
| "Don't check in" | 0 unauthorized | â |
| Instructions skipped | NONE | â |
```

Any skipped instruction requires a specific reason. "I decided to prioritize" is NOT valid.

### Complete Project Package

Every completed project MUST contain ALL of the following. Missing items mean the project is NOT complete:
- Source code with passing tests
- MANIFEST.md with all items marked Complete
- Instruction Compliance Receipt
- PROGRESS-LOG.md (full session history)
- PROJECT-STATE.md (final state)
- Post-build validation results (5 categories)
- Security scan results (if deploying)

### 3 End States
- **Complete:** All manifest items done, all audits passed, compliance receipt delivered
- **Handoff:** Context heavy, handoff document written, fresh session continues
- **Blocked:** External dependency, user notified with specific blocker

### Archive
After completion: move to archive, update index, create tombstone file.

---

## Reference Documents

### v5 New References (coding quality + compliance)
| File | Contents |
|------|----------|
| `references/planning-protocols.md` | Spec self-review, no-placeholders, confidence check, deepen-plan, 3-file structure, architecture compliance |
| `references/code-quality-protocols.md` | TDD Iron Law + anti-rationalization, verification gate, React performance (69 rules), composition patterns, CSO rule |
| `references/debugging-protocols.md` | 4-phase systematic debugging, parallel agent debugging, Three Strikes rule |
| `references/review-protocols.md` | Two-stage review, YAGNI check, anti-sycophancy, reader testing, blind review, security risk classification |
| `references/security-protocols.md` | Insecure defaults scan, supply chain risk, pre-deployment gate |
| `references/orchestration-protocols.md` | RARV cycle, dead-letter queue, phase-gates, agent dispatch, branch completion, deployment, compound learning, session heartbeat |
| `references/compliance-enforcement.md` | Manifest protocol, anti-check-in gate, compliance receipt, anti-rationalization table, audit-as-gate, handoff protocol, forced commitment, scarcity gates |

### v4 References (project infrastructure â unchanged)
| File | Contents |
|------|----------|
| `references/system-build-protocol.md` | Full System Build Protocol (10 changes, checklists) |
| `references/shared-state-template.md` | Shared state architecture template |
| `references/deployment-architecture-template.md` | Process inventory, scheduling, health monitoring |
| `references/architecture-template.md` | Architecture document template |
| `references/capability-map-template.md` | Capability map template |
| `references/prd-template.md` | PRD template with execution checklist |
| `references/three-questions-protocol.md` | Q1/Q2/Q3 decision framework |
| `references/agentic-operations-principles.md` | 8 operational principles |
| `references/operations-protocol-missing-layer.md` | 7 operational distinctions |
| `references/skill-architecture-patterns.md` | 10-layer skill quality model |
| `references/strategic-builder-source.md` | Original methodology source |
| `references/technical-design-documents.md` | TDD guidance |
| `references/tdd-template.md` | TDD template |
| `references/delivery-gap-and-prevention.md` | Delivery failure postmortem |

---

## Full Workflow: New Project â Mandatory Sequence

NO step is optional. NO step is reordered. Skipping steps is the #1 cause of project failures in this workflow. Every step has a gate; every gate MUST pass before advancing.

**Phase 0: Design Exploration**
1. Explore project context (files, docs, commits, prior attempts)
2. Assess scope â decompose if multiple independent subsystems
3. Clarify intent â one question at a time until purpose/constraints/success criteria are clear
4. Propose 2-3 approaches with tradeoffs and recommendation
5. Present design spec â incremental sections, user approves each
6. Spec self-review (placeholder scan, consistency, scope, ambiguity) â user approval gate

**Phase 1: Planning (Translation Stack)**
7. Create project folder + infrastructure (AGENTS.md, PROJECT-STATE, MANIFEST.md, PROGRESS-LOG)
8. Write MANIFEST.md with all deliverables
9. Commit to manifest: state all deliverables, confirm commitment
10. Level 1: Vision document (from approved Phase 0 spec) â validation gate
11. Level 2: Architecture Map â Technology Selection â Complexity Fork
12. If system: activate System Build Protocol
13. Level 3: Capability Map â validation gate
14. Level 4: Phased Delivery Plan â validation gate
15. Level 5: Prototyping (if AI tools)
16. Level 6: PRD â translation audit
17. Pre-implementation checks: confidence check, architecture compliance, spec self-review
18. Deepen-plan (complex projects): 4 parallel research agents

**Phase 2: Implementation**
19. Implementation with TDD (Red-Green-Refactor on every component)

**Phase 3: Review**
20. Two-stage review: spec compliance â code quality
21. Anti-sycophancy check (if unanimous approval)

**Phase 4: Security**
22. Security scan: insecure defaults + dependency audit

**Phase 5: Validation**
23. Post-build validation: 5 test categories

**Phase 6: Deployment**
25. Deployment: follow decision tree, preview first
26. Instruction compliance receipt: prove every instruction was followed
27. Update MANIFEST.md: all items Complete
28. Finish: archive or handoff
