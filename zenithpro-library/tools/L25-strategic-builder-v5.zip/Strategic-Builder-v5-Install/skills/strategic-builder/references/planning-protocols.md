# Strategic Builder v5 â Planning Protocols

All planning protocols run BEFORE implementation. No exceptions.

**Commitment checkpoint:** Before beginning planning, state which planning protocols you will apply and in what order.

---

## Protocol 1: Spec Self-Review Checklist

Every spec MUST pass all 4 checks before handoff to implementation agents.

### Check 1: Placeholder Scan

Forbidden patterns â any occurrence = automatic failure:
- `TBD`, `TODO`, `FIXME`, `HACK`, `XXX`
- `add appropriate X` (any variant)
- `write tests for above`, `handle edge cases`, `implement as needed`
- `similar to above`, `[insert X]`, `etc.`, `and so on`, `...`
- `as required`, `as appropriate`, `where necessary`
- `follow the same pattern`, `use best practices`, `standard approach`

Run: `grep -r "TBD\|TODO\|etc\.\|\.\.\."` â zero matches required.

### Check 2: Internal Consistency

- Every term used consistently across sections
- Every requirement compatible with every other requirement
- No contradictions between data model, API contracts, UI behavior
- File names in spec match the file structure pre-map

### Check 3: Scope Check

Spec contains ONLY what was requested and NOTHING that was not requested.
- Flag any feature not in the original requirement
- Flag any dependency not in the original stack
- Flag any file not in the original structure

### Check 4: Ambiguity Check

"If five different agents read this sentence, would they produce the same output?" If not, rewrite.

Ambiguity triggers:
- Relative terms without anchors ("fast", "simple", "lightweight", "clean")
- Conditional behavior without specified conditions
- Optional behavior without explicit optionality markers
- Shared state without explicit locking/concurrency specs
- Success criteria stated as feelings rather than measurements

**Gate:** All 4 checks MUST pass before handoff.

---

## Protocol 2: No-Placeholders â Forbidden Pattern List and File Pre-Map

### Forbidden Pattern List (Four Tiers)

**Tier 1 â Absolute Prohibitions (zero tolerance):** TBD, TODO, FIXME, HACK, XXX, [placeholder], [insert here]

**Tier 2 â Deferred Decision Language:** "add appropriate X", "write tests for above", "handle edge cases", "implement as needed", "follow the same pattern as", "use standard approach"

**Tier 3 â Lazy Enumeration:** etc., and so on, and others, ..., among other things, and more

**Tier 4 â False Specificity:** "some value", "an appropriate value", "a reasonable default", "a sensible configuration"

### File Structure Pre-Map (MANDATORY)

| File Path | Action | Reason |
|-----------|--------|--------|
| `src/components/Auth.tsx` | CREATE | New auth component required by spec |
| `src/utils/validators.ts` | MODIFY | Add email validation function |

Every file touched, created, or deleted MUST appear in this table before implementation begins.

### Task Granularity Rule

Each task MUST represent 2-5 minutes of AI work.

**Too large:** "Build the authentication system"
**Correctly scoped:** "Create `src/types/AuthState.ts` with `userId`, `token`, `expiresAt` fields"

---

## Protocol 3: Pre-Implementation Confidence Check

### The 5 Checks

**Check 1: Duplicate Scan** â `grep -r "[function/class name]"` to verify nothing similar already exists

**Check 2: Architecture Compliance** â read CLAUDE.md, PLANNING.md, ADRs

**Check 3: Reference Implementation Search** â find a similar feature that already works, read it in full

**Check 4: Documentation Review** â README, API docs, recent changelogs

**Check 5: Root Cause Identified (Bug Fixes Only)** â reproduce consistently, identify exact line, predict what changes

### Scoring and Gates

| Score | Action |
|-------|--------|
| 5/5 | Proceed to implementation |
| 3-4 | Present 2-3 implementation alternatives with tradeoffs. Do not proceed until one is selected. |
| <3 | STOP. State which checks failed and what information is missing. |

---

## Protocol 4: 4-Agent Deepen-Plan Pattern

**Trigger:** Complex projects only â 16+ files, or 3+ integrated systems.

**Gate:** No implementation until all 4 agents complete and outputs are synthesized.

Launch ALL 4 agents in ONE message. Sequential launch wastes time and allows early agents to bias later agents.

### Agent 1: Repo Analyzer
Maps existing codebase â relevant files, responsibilities, interfaces, dependencies, existing patterns, conflict candidates, integration points.

### Agent 2: Dependency Researcher
Audits all dependencies â current vs latest versions, breaking changes in last 2 major versions, deprecated APIs in codebase, compatibility matrix.

### Agent 3: Edge Case Finder
Identifies all edge cases, failure modes, boundary conditions. Enumerates every non-happy-path scenario. Does not propose solutions â only identifies gaps.

### Agent 4: Security Threat Modeler
Applies STRIDE (Spoofing, Tampering, Repudiation, Information Disclosure, DoS, Elevation of Privilege). Flags unvalidated inputs, auth bypasses, injection points, insecure defaults. Rates likelihood and impact.

### Integration Step

1. Check for file conflicts across agent outputs
2. Update spec with edge cases and security requirements
3. Update dependency list based on Agent 2's findings
4. Re-run Protocol 1 on the updated spec
5. Only then proceed to task list generation

---

## Protocol 5: 3-File Planning Structure

Every multi-session project MUST use the 3-file planning structure.

### The 3 Files

**File 1: `task_plan.md`** â full task list with status tracking
- Task ID, description, files affected, status (PENDING/IN_PROGRESS/COMPLETE/BLOCKED), blocker description, agent assignment

**File 2: `findings.md`** â append-only log of everything discovered during planning
- Repo Analyzer output, Dependency Researcher output, Edge Case Finder output, Security Threat Modeler output, architecture decisions, surprises during implementation

**File 3: `progress.md`** â running log of what has been completed
- `[TIMESTAMP] Task [ID]: [Description] â Files modified: [list] â Tests passing: [yes/no/partial] â Notes: [unexpected]`

### The 2-Action Rule

After any 2 consecutive view/search/read operations that do not produce a write, STOP and write findings to `findings.md` before continuing.

Counts as read: reading a file, grep, find, browsing a directory, reading documentation, checking a dependency version.

Counts as write: entry in `findings.md`, entry in `progress.md`, updating task status, writing implementation file.

### The 5-Question Reboot Test

When resuming a session, MUST answer all 5 questions:

1. What was the last completed task? (`progress.md`)
2. What is the next task? (`task_plan.md`)
3. Are there any blockers? (`task_plan.md`, BLOCKED rows)
4. Any open architectural questions? (`findings.md`, last 10 entries)
5. Has anything changed that affects the plan? (git log)

### Session Recovery Protocol

If 3-file structure does not exist when a session begins:
1. STOP. Do not continue implementation.
2. Create the 3-file structure immediately.
3. Reconstruct `progress.md` from git log and file modification dates.
4. Reconstruct `task_plan.md` from the spec.
5. Only then resume work.

---

## Protocol 6: Architecture Compliance Check

### Files to Read (in this order)

1. `CLAUDE.md` â Project-level Claude instructions
2. `PLANNING.md` â High-level architectural decisions
3. `docs/decisions/ADR-*.md` â All Architecture Decision Records
4. `README.md` â Architecture section if it exists

### Verification Checklist

For each file read:
- [ ] Identified all constraints on technology choices
- [ ] Identified all constraints on file structure
- [ ] Identified all constraints on naming conventions
- [ ] Identified all constraints on testing requirements
- [ ] Identified all constraints on dependency usage
- [ ] Identified any explicitly forbidden approaches

### Contradiction Handling Rule

If the spec contradicts an ADR or CLAUDE.md instruction:
1. Document the contradiction in `findings.md`
2. Precedence order: CLAUDE.md > ADR > PLANNING.md > spec
3. Propose a resolution that satisfies both constraints if possible
4. If no resolution possible, surface to user before proceeding

**Commitment checkpoint:** After reading all architecture files, state: "I have read [list of files]. The following architectural constraints apply: [list]. My plan is compliant because [reason]."

---

## Summary: Protocol Execution Order

1. Architecture Compliance Check (Protocol 6)
2. Pre-Implementation Confidence Check (Protocol 3)
3. File Structure Pre-Map (Protocol 2)
4. Spec Self-Review (Protocol 1)
5. 4-Agent Deepen-Plan (Protocol 4) â if 16+ files or 3+ systems
6. 3-File Planning Structure (Protocol 5)

**This order is not negotiable.**
