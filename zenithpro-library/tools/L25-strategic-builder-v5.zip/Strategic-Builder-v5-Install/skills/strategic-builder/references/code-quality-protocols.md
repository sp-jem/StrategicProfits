# Code Quality Protocols â Strategic Builder v5

## Three-Layer Persuasion Architecture

These protocols use:
- **Authority** â MUST/NEVER with imperative language
- **Commitment** â Agent states plan before executing
- **Social Proof** â Named failure consequences for every rule

---

## 1. TDD Iron Law

**Zero production code without a failing test first. No exceptions. No rationalizations.**

### The Red-Green-Refactor Cycle

```
RED    â Write a test. Run it. Watch it fail. Confirm it fails for the right reason.
GREEN  â Write the minimum production code to make the test pass. Nothing more.
REFACTOR â Clean up without changing behavior. Run tests after every change.
```

**The fundamental distinction:**
- Tests-after = "what does this code do?" (description)
- Tests-first = "what should this code do?" (specification)

Tests-after are documentation. Tests-first are design tools. The Iron Law requires design tools, not documentation.

### TDD Anti-Rationalization Table

| Rationalization | Why It's Wrong |
|-----------------|----------------|
| "This is too simple to need a test" | Simple code with no test has no contract. It will break and there will be no signal. |
| "I'll write the tests after I get it working" | You will not. The code will "work" and the tests will get deprioritized permanently. |
| "Tests slow me down" | Tests prevent 3â5x the time in debugging. They are not overhead; they are velocity. |
| "This is a prototype" | Prototypes become production at 2 AM. Write the test. |
| "The type system is the test" | Types verify shape, not behavior. A typed function can be completely wrong. |
| "I know this will work" | Knowing is not verifying. Run the test. |
| "The manual test showed it works" | Manual tests are single runs with no coverage tracking. Write the automated test. |
| "Tests are hard to write for this" | Hard-to-test code is hard-to-maintain code. The test difficulty is a design signal. |
| "The code is self-documenting" | Documentation describes. Tests verify. You need both. |
| "I'll mock it later" | Mocking after-the-fact requires rewriting the code. Design with mocking in mind from the start. |
| "We're moving too fast for TDD" | Moving fast without tests means slowing down permanently when the bugs accumulate. |

### Red Flags â Triggers for "Delete Code, Start Over"

Any of these in production code means the implementation is wrong at the design level:

- Function longer than 50 lines â It's doing too many things
- Nested conditionals deeper than 3 levels â Logic is not understood
- Magic numbers without named constants â Meaning is not captured
- Side effects in pure-looking functions â Behavior will be surprising
- Global state mutation â Unpredictable at any scale
- Catch block that swallows errors silently â Bugs become invisible
- `any` type in TypeScript (without explicit justification) â Type safety abandoned
- Copy-pasted blocks (3+ lines duplicated) â Abstraction needed
- Test that doesn't assert anything â Test provides false confidence
- Test that always passes regardless of implementation â Test is broken

**When you see a red flag:** Stop. Delete the implementation. Start the TDD cycle from RED.

**Failure consequence:** Every red flag is technical debt with compound interest. A 50-line function written today becomes a 200-line function in 6 months because no one understands it well enough to refactor. It never gets deleted because everyone is afraid to touch it. The codebase gradually becomes unmaintainable and the entire system must be rewritten.

### Property-Based Test Triggers

Write property-based tests (not just example-based) whenever the function:
- **Encodes/decodes** â `decode(encode(x)) === x` for all valid x
- **Parses** â `parse(serialize(x))` round-trips for all valid inputs
- **Normalizes** â `normalize(normalize(x)) === normalize(x)` (idempotent)
- **Sorts or filters** â Sorted output must satisfy ordering invariants for all inputs
- **Generates IDs** â All generated IDs must be unique across large sample

Property-based tests catch edge cases that example-based tests miss. They are not a replacement; they are a supplement.

---

## 2. Verification Before Completion Gate

**NEVER claim something is fixed or complete without running the verification command first.**

### The Five-Step Gate

Every completion claim MUST follow this sequence in order:

**Step 1 â Identify the command**
Name the exact command that proves the claim. "The build works" â `npm run build`. "Tests pass" â `npm test`. "No type errors" â `tsc --noEmit`.

**Step 2 â Run it fresh**
Do not use cached results. Do not use the last run's output. Run the command now.

**Step 3 â Read the full output**
Read every line. Not just the last line. Not just "it looked green." Every line.

**Step 4 â Verify the output confirms the claim**
The output must specifically confirm what was claimed. "Build successful" with 3 warnings is not the same as "Build successful with 0 warnings."

**Step 5 â Only then make the claim, citing evidence**
State what you ran and what it showed.

### Required Format

```
Fixed. Verified: `[command]` completed with [specific result]. Output: [key line from output].
```

### Prohibited Phrases

**NEVER use these phrases to describe a completion:**

- "should work now"
- "probably fixed"
- "I believe this resolves"
- "this likely addresses"
- "that ought to do it"
- "looks good to me"
- "it seems to be working"
- "I think this is fixed"
- Any expression of confidence BEFORE running verification

**These phrases signal that verification was skipped.** They are not hedging; they are evidence of a process failure.

### Rationalization Table

| Rationalization | Why It's Wrong |
|-----------------|----------------|
| "I just fixed it, I know it works" | Knowing is not verifying. Run the command. |
| "Running the test takes too long" | You have time to claim it works but not to verify it? Run the command. |
| "The last run was fine and I didn't change much" | "Not much" is not "nothing." Run the command. |
| "The error was obvious and my fix is correct" | Obvious errors have non-obvious causes. Run the command. |
| "I'll verify at the end" | Unverified claims stack. Each one hides the next. Verify now. |

### Common Claim Verification Table

| Claim | Required Verification | Not Sufficient |
|-------|-----------------------|----------------|
| "Build passes" | `npm run build` completes with 0 errors | "The code looks right" |
| "Tests pass" | `npm test` shows 0 failures | "I ran one test manually" |
| "No type errors" | `tsc --noEmit` exits with code 0 | "TypeScript didn't complain during editing" |
| "Linting passes" | `npm run lint` shows 0 errors | "The linter seems happy" |
| "File was created" | File exists at expected path and has content | "I wrote the write command" |
| "API responds" | `curl` or test shows expected response | "The endpoint should work" |

**Failure consequence:** An unverified fix creates false confidence that blocks real diagnosis. The next agent (or the next session) sees "Fixed" in the notes, doesn't investigate, and spends an hour debugging a problem that was never actually fixed. Unverified claims are not just wrong â they actively mislead.

---

## 3. React Critical Performance Rules

**Performance is not a feature. It is infrastructure. These rules are not optional optimizations â they are correctness requirements.**

### Waterfall Elimination

**NEVER use sequential awaits for independent data fetches:**
```typescript
// WRONG â sequential, waterfall
const user = await getUser(id);
const posts = await getPosts(id);
const comments = await getComments(id);

// RIGHT â parallel
const [user, posts, comments] = await Promise.all([
  getUser(id),
  getPosts(id),
  getComments(id)
]);
```

**Use React Suspense for parallel component loading.** A component tree that waterfalls through sequential data fetches multiplies latency â 3 independent 200ms fetches become 600ms total when sequential and 200ms when parallel.

### Bundle Size Rules

- **NEVER use barrel imports** (`import { x } from 'lodash'` imports all of lodash)
- **ALWAYS use named subpath imports** (`import debounce from 'lodash/debounce'`)
- **ALWAYS use dynamic imports** for routes and large components
- **Run bundle analysis before shipping.** `@next/bundle-analyzer` is not optional on complex projects.

### Server-Side Caching

- **Use `React.cache`** for request-level deduplication in Server Components
- **Use LRU cache** for cross-request caching of expensive computations
- **NEVER use shared module-level state** for caching â this persists across requests and leaks user data between sessions

### Re-render Reduction â 15 Rules

1. **Wrap leaf components in `React.memo`** â prevents re-renders from parent state changes
2. **Wrap expensive calculations in `useMemo`** â recomputes only when dependencies change
3. **Wrap callbacks in `useCallback`** â stable reference prevents child re-renders
4. **NEVER pass inline objects as props** â `{style={{color: 'red'}}}` creates new reference every render
5. **NEVER pass inline arrays as props** â same reason as inline objects
6. **NEVER pass inline functions as props** â same reason, and this is the most common violation
7. **Derive state, don't sync it** â if state B depends on state A, compute B from A, don't maintain both
8. **Use `useTransition` for non-urgent updates** â keeps UI responsive during expensive state transitions
9. **Use `useDeferredValue` for input debouncing** â renders stale value while computing new one
10. **Split context by update frequency** â a context with both fast and slow values re-renders all consumers on every change
11. **Put context providers as low in the tree as possible** â fewer components affected by updates
12. **Use `startTransition` for search/filter operations** â marks as non-urgent, keeps input responsive
13. **Memoize context value** â prevents all consumers from re-rendering on provider re-render
14. **Use Zustand or Jotai for global state** â avoids React context re-render cascades
15. **Profile before optimizing** â React DevTools Profiler shows actual render causes

### JavaScript Performance

- **Use `Set` for membership checks** â O(1) vs O(n) for arrays
- **Use `Map` for frequent key lookups** â faster than object property access for dynamic keys
- **Use early returns** â flatten conditionals, reduce nesting, exit fast
- **Hoist regex to module level** â regex created inside a function allocates on every call

**Failure consequence:** A React app that re-renders every component on every keystroke in a search field is unusable on mobile. A bundle that includes all of lodash for one debounce function adds 70KB to load time. Only caught in production after users have already left.

---

## 4. React Composition Patterns

### Boolean Prop Proliferation â Anti-Pattern

When a component accepts 4+ boolean variants, it is doing too many things. Split it into explicit variant components or use a discriminated union prop.

### Compound Components Pattern

For complex UI with shared state â encapsulate state, allow flexible composition, avoid prop drilling.

### State Lifting via Context

**NEVER lift state higher than necessary.** State only needed by a subtree should live in that subtree's context, not at the root.

### Children as Nodes Over Render Props

Prefer `<Modal>{children}</Modal>` over `<Modal render={(props) => <Content {...props} />} />`. Simpler, more composable, easier to read.

### React 19 Changes â MUST Know

- **No `forwardRef`** â `ref` is now a regular prop. Pass it directly.
- **`use()` hook** â Replaces `useContext` and handles Promises.
- **Server Actions** â `'use server'` directive enables form actions without API routes.
- **Optimistic updates** â `useOptimistic` replaces manual optimistic state management.

**Failure consequence:** A codebase with boolean prop proliferation becomes unmaintainable at 50+ components. New developers can't read component signatures. The component becomes a god-component that must be understood entirely before it can be changed safely.

---

## 5. Skill Description CSO Rule

**Skill descriptions that summarize workflow cause Claude to follow the description instead of reading the skill. This is the single most common skill failure mode.**

### The Problem

When a skill description summarizes what the skill does, Claude reads that description and follows it as instructions â skipping the actual skill file. The description becomes the skill.

### The Rule â Triggering Conditions Only

**WRONG â describes workflow:** "Analyzes competitive markets through systematic research and synthesis."

**RIGHT â triggering conditions only:** "Use when: user asks for competitive analysis, market research, or competitive positioning."

### Formula

```
Use when: [trigger 1], [trigger 2], [trigger 3].
```

That is the entire description. Nothing about what the skill does. Nothing about how it works. Only the conditions that should trigger it.

### Token Efficiency Targets

| Description Type | Token Count | Claude Behavior |
|-----------------|-------------|-----------------|
| Workflow summary (wrong) | 30â60 tokens | Follows description, skips skill |
| Triggering conditions (right) | 10â20 tokens | Reads skill file, follows skill |

**Failure consequence:** A skill with a workflow-summary description has a shadow behavior that partially or fully replaces the intended skill behavior. Claude reads the 30-word description and produces output based on that. The 500 lines of skill content are ignored.

---

## Quick Reference

| Protocol | Key Rule | Consequence of Violation |
|----------|---------|--------------------------|
| TDD Iron Law | Failing test before production code | Unspecified behavior, untestable code |
| Verification Gate | Run command before claiming done | False confidence, blocked diagnosis |
| Waterfall Elimination | Promise.all for independent fetches | 3x latency, unusable on mobile |
| Bundle Size | No barrel imports, use dynamic imports | +70KB+ load time per violation |
| Server Caching | React.cache + LRU, never module state | User data leaks across requests |
| Re-render Rules | 15 rules â memo, useMemo, useCallback | Unusable performance on mobile |
| Compound Components | Explicit variants, no boolean proliferation | God-components, unmaintainable |
| Skill Descriptions | Triggering conditions only | Skill ignored, description followed |
