# Deployment Architecture Template

Use this template for any project that forks into the System Build Protocol and has scheduled execution, daemons, or multiple coordinated processes. Produce this document BEFORE building any module.

For 2-3 module systems with NO scheduled execution, this document is optional (see Scaling Guidance in system-build-protocol.md).

---

## Process Inventory

### [Process Name] (e.g., brain_daily.py)

| Field | Value |
|-------|-------|
| **Trigger** | [schedule / event / manual / always-on] |
| **Schedule** | [exact timing: "6:15 AM daily via launchd" / "every 30 min via cron" / "on file change via fswatch" / "manual only" / "runs continuously"] |
| **Runtime** | [interpreter: `/usr/bin/python3`, working directory: `/path/to/project`, env vars: `ANTHROPIC_API_KEY`, `OLLAMA_HOST`] |
| **Dependencies** | [what must be running/available: "Ollama on localhost:11434", "brain-state.json must exist and be valid", "ANTHROPIC_API_KEY set"] |
| **Timeout** | [max execution time: "300 seconds" / "10 minutes" / "no limit (always-on)"] |
| **Overlap protection** | [skip / queue / kill -- pick one. e.g., "skip: if previous run still active, do not start a new one"] |
| **Failure behavior** | [restart / alert / degrade / nothing -- pick one. e.g., "alert: log failure, increment circuit breaker counter, do not restart"] |

---

### [Process Name 2] (copy this section for each additional process)

| Field | Value |
|-------|-------|
| **Trigger** | |
| **Schedule** | |
| **Runtime** | |
| **Dependencies** | |
| **Timeout** | |
| **Overlap protection** | |
| **Failure behavior** | |

---

## Execution Order

If processes must run in sequence, document the order here. If all processes are independent, state "All processes run independently -- no execution order required."

| Order | Process | Waits For | Notes |
|-------|---------|-----------|-------|
| 1 | [process A] | Nothing -- runs first | |
| 2 | [process B] | A's completion (verified by: [mechanism]) | |
| 3 | [process C] | Independent -- can run anytime | |

---

## Port Allocation

| Port | Owner | Purpose |
|------|-------|---------|
| [port] | [process name] | [what it serves] |

**Rule:** No two processes may claim the same port. If this table has duplicates, resolve the conflict before building.

If no processes use network ports, state "No network ports used."

---

## Health Monitoring

### How to Check System Health

[Describe the primary mechanism for checking if the system is working. This must be something that can be done without reading individual log files.]

Examples:
- A status endpoint at `http://localhost:9876/health` that returns JSON with each module's last run status
- A summary file at `logs/health-summary.json` updated after each module runs
- A dashboard at `http://localhost:3000` showing module status

### What to Check

| Check | How | Expected Result | If Failed |
|-------|-----|-----------------|-----------|
| [All modules ran today] | [read health summary] | [all modules show today's date] | [check logs/alerts.json for circuit breakers] |
| [No open alerts] | [read logs/alerts.json] | [file empty or nonexistent] | [investigate the alerted module] |
| [Shared state valid] | [parse each shared state file] | [all parse correctly with expected schema_version] | [restore from .bak, investigate which module corrupted it] |

---

## Validation Checklist

Before proceeding to build any module, verify:

- [ ] Every process has a defined failure behavior (specific action, not "shouldn't crash")
- [ ] No scheduling conflicts exist (verified: no two processes write to the same resource at overlapping times)
- [ ] Overlap protection defined for every scheduled process (specific mechanism: skip, queue, or kill)
- [ ] Port allocation table has no duplicates
- [ ] At least one health check mechanism defined that can be run without reading individual log files
