# Review Protocols â Strategic Builder v5

## COMMITMENT GATE â MANDATORY

Before beginning ANY review, you MUST state:

```
Review Plan:
1. Stages I will run: [list]
2. Order: [sequence]
3. Pass criteria for each stage: [definition]
4. Fail criteria for each stage: [definition]
```

Proceeding without this statement is a protocol violation.

---

## 1. Two-Stage Code Review Protocol

### The Rule

Code review MUST be executed in exactly two sequential stages. NEVER run both simultaneously.

**Stage 1: Spec Compliance Review** â Does every requirement in the spec appear in the code? Are all interfaces, endpoints, data shapes, and behaviors as specified? Binary: Pass or Fail.

**Stage 2: Code Quality Review** â Is the code readable, maintainable, performant? Error handling appropriate? Testable? Any security anti-patterns? Runs ONLY after Stage 1 passes.

### The Consequence

Running quality review before spec review produces "technically correct but wrong feature" failures. A Stage 1 failure makes Stage 2 meaningless.

### Implementer Status Handling Matrix

| Status | Action |
|--------|--------|
| `DONE` | Proceed to Stage 1 normally |
| `DONE_WITH_CONCERNS` | Document concerns. Run Stage 1. Verify each concern is real. |
| `NEEDS_CONTEXT` | DO NOT run Stage 1. Surface ambiguity. Get clarification. |
| `BLOCKED` | DO NOT run Stage 1. Escalate blocker immediately with exact description. |

### Model Cost Optimization

| Task Type | Model Tier | Examples |
|-----------|-----------|---------|
| Mechanical | Sonnet | Linting, format verification, naming |
| Integration | Sonnet | API contract verification, data flow tracing |
| Architecture | Opus | Design pattern review, tradeoff analysis |
| Spec Review | Opus | Requirement compliance, edge case coverage |

NEVER assign architecture or spec review to a cheap model.

---

## 2. YAGNI Code Review Verification

### The Rule

Before implementing ANY suggestion from a code reviewer, MUST grep the codebase for actual usage. If zero usage, the suggestion is YAGNI and MUST be rejected unless the reviewer provides a concrete near-term use case with a timeline.

### Verification Command Pattern

```bash
grep -r "FunctionName\|feature_name\|pattern_name" ./src --include="*.ts" --include="*.js" --include="*.py"
```

### Prohibited Responses to Reviewer Suggestions

NEVER respond with:
- "You're absolutely right!"
- "Great point!"
- "Thanks for the feedback!"
- "That's a good idea, I'll add that."

These bypass evaluation. They are sycophancy, not code review.

### Correct Response Formats

**If valid:** `Fixed. [One-sentence description of what changed and why.]`

**If YAGNI:**
```
Pushback: [Specific reason this change is not warranted].
Evidence: [grep result or spec reference].
Proposal: [Alternative if any, or "No change needed."]
```

### External Reviewer Skepticism

- External reviewers do not have full codebase context. Grep before trusting.
- External reviewers optimize for comprehensiveness, not necessity.
- A suggestion from a senior developer is a hypothesis, not a verdict.
- "Best practice" suggestions MUST be evaluated against this codebase's actual constraints.
- NEVER implement an external suggestion without tracing its impact through the full call graph.

---

## 3. Anti-Sycophancy Review Protocol

### The Trigger

If ALL reviewers approve a complex change without a single concern raised on >50 line / 2+ system changes: mandatory Devil's Advocate pass.

### The Action

Spawn Devil's Advocate with:

```
You are a Devil's Advocate reviewer. Your ONLY job is to find problems.

You are NOT allowed to approve.
You are NOT allowed to say it looks good.
You are NOT allowed to agree with previous reviewers.

Find at least 3 specific concerns. If you cannot find 3 real concerns, find the 3 least-bad concerns and explain why they are still worth flagging.

The change under review: [paste change]
```

### Skip for

- Trivial changes under 5 lines
- Documentation-only changes
- Pure formatting or whitespace changes
- Changes that are literal spec copy

### The Logic

Unanimous approval without concerns is not evidence of quality â it is evidence that reviewers are satisficing. Real code has tradeoffs.

---

## 4. Reader Testing Protocol

For all documentation artifacts (specs, PRDs, proposals, landing pages, course content).

### The Method

Spawn a fresh sub-agent with ONLY the document. No conversation history. No project context.

```
You are a reader encountering this document for the first time. You have no prior context.

1. What is this document trying to accomplish?
2. What action should you take after reading it?
3. What is still unclear after reading it?
4. What assumptions does the document make about your prior knowledge?
5. Is there anything that could be misinterpreted?

Document: [paste full document]
```

### Pass / Fail

**Pass:** Reader correctly identifies purpose, required action, no substantive misunderstandings.

**Fail:** Any of:
- Misidentifies document's purpose
- Cannot identify required next action
- Misinterprets a critical requirement
- Makes an assumption not licensed by document
- Identifies ambiguity in decision-critical section

On fail: revise and re-run. Do not ship a document that fails.

---

## 5. Blind Review Protocol

### The Rule

Reviewers MUST NOT see the implementer's self-assessment before completing their review. Reviewers MUST NOT see each other's findings.

### Implementation

Launch ALL reviewers in a single message. Each receives:
- The artifact under review
- The spec or acceptance criteria
- NOTHING ELSE

Do not include implementer's self-assessment, other reviewers' notes, your own assessment, or context about how the change was built.

### The Rationale

Blind review reduces false positives by 30%. When reviewers see the implementer's framing, they anchor to it rather than forming their own. When reviewers see each other, they collapse into agreement rather than independently identifying concerns.

After all reviewers submit independent findings, consolidate and surface conflicts. Do not resolve disagreement by defaulting to majority view.

---

## 6. Security Review Risk Classification

### Risk Tiers

**HIGH RISK** â Mandatory security review with written report
- Authentication and authorization logic
- Cryptographic operations
- Payment processing and financial data
- External API integrations
- Data persistence
- Session management

**MEDIUM RISK** â Standard security review, document findings inline
- Business logic with financial or access implications
- State management
- Public-facing interfaces

**LOW RISK** â No dedicated security review required
- Documentation changes
- Test additions (unless tests contain credentials)
- Internal refactors with no interface changes
- Pure formatting changes

### Blast Radius Calculation

```bash
grep -r "functionName\|moduleName" ./src --include="*.ts" --include="*.js" --include="*.py" | wc -l
```

A change with blast radius of 1 has different risk than one with blast radius of 47.

### Rationalization Table

| Rationalization | Why It's Wrong |
|-----------------|---------------|
| "It's a small PR" | Heartbleed was 2 lines. Shellshock was 1 line. |
| "We're moving fast" | Security incidents stop all movement. |
| "It's internal only" | Internal services are most common pivot point in breaches. |
| "We'll review before prod" | The review never happens at same quality level. |
| "Similar code passed before" | Security debt compounds. |
| "It's just a config change" | Fail-open defaults live in config. |

### Mandatory Report for HIGH-Risk Changes

```
SECURITY REVIEW REPORT
Change: [description]
Risk tier: HIGH
Blast radius: [grep count] callers

Findings:
- [CRITICAL/HIGH/MEDIUM/LOW]: [description] â [remediation]

Recommendation: [APPROVE / APPROVE WITH CONDITIONS / REJECT]
Conditions (if any): [list]
```

A HIGH-risk change with no report is not reviewed. It is assumed. Do not assume security.

---

## Consolidated Commitment Gate

Before beginning any review session, the reviewing agent MUST state:

```
Review Commitment:
- Stages: [list]
- Order: [exact sequence]
- Models assigned: [which model tier for each stage]
- Pass criteria: [per stage]
- Fail criteria: [per stage]
- Risk classification: [HIGH/MEDIUM/LOW, with rationale]
- Blind review: [yes/no, if no: why not]
```

Any agent that produces review output without first producing this commitment statement has not followed the protocol.
