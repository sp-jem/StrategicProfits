# Strategic Builder v5 â Debugging Protocols

All debugging follows a systematic protocol. Intuition-based debugging is prohibited.

**Commitment checkpoint:** Before beginning debugging, state: which phase you are in, what evidence you have so far, and what you will do next. Do not take a single debugging action without first stating this orientation.

---

## Protocol 1: 4-Phase Systematic Debugging Protocol

Debugging phases MUST be executed in order. Jumping to Phase 3 (Hypothesis) without completing Phase 1 (Root Cause) is the primary source of debugging loops that never resolve.

### Phase 1: Root Cause Identification

**Purpose:** Understand the actual error before touching any code. A fix written before root cause is identified is a guess. Guesses generate new bugs.

**Step 1.1 â Read the full error.** Read every line. The most useful information is almost always in the middle of a stack trace, not at the top. Copy the complete error text to your debugging notes. Do not paraphrase.

**Step 1.2 â Reproduce consistently.** A bug you cannot reproduce is a bug you cannot verify you fixed. State the exact sequence of steps that produce the error. If you cannot produce consistent reproduction, that is your current problem â not the bug itself.

**Step 1.3 â Check recent changes.** Run `git log --oneline -20` then `git diff HEAD~1`. Most common cause of a new bug is a recent change. If a change in the last 48 hours correlates with the error, that correlation is your primary hypothesis.

**Step 1.4 â Add diagnostic instrumentation at each component boundary.** Do NOT add logging randomly. Add it at every boundary where one system hands off to another: API calls, DB queries, state mutations, function boundaries, error handling.

Required format: `[COMPONENT] [BOUNDARY] [DATA]: [value]`

**Step 1.5 â Trace backward from the error.** At each frame answer: "What did this component receive, and what did it produce?" Repeat until you reach the frame where the wrong data first appeared. That frame contains the root cause.

**Gate: Phase 1 is complete when you can state:** "The root cause is [specific function/component/line] because [it receives/produces/transforms] [wrong value]. This is demonstrated by [diagnostic output]."

MUST NOT proceed to Phase 2 until you can make this statement with evidence.

---

### Phase 2: Pattern Analysis

**Purpose:** Verify root cause hypothesis by finding the working version of the same behavior.

**Step 2.1 â Find working examples.** Search for 3 other instances of the same operation type that work correctly.

**Step 2.2 â List the differences.** Create comparison table:

| Attribute | Working Example | Broken Instance |
|-----------|----------------|-----------------|
| Input type | string | undefined |
| Null check | yes | no |
| Error handling | try/catch | none |

**Step 2.3 â Identify the structural difference.** The structural difference IS the root cause confirmation. If you cannot find one, either your working example is wrong or your hypothesis is wrong.

**Gate:** Comparison table with at least one structural difference mapping directly to error behavior.

---

### Phase 3: Hypothesis Formation

**ONE hypothesis per debugging cycle.** Simultaneous tests produce uninterpretable results.

**Valid hypothesis format:**
> "If I add a null check for `userId` before calling `validateToken()`, then the TypeError will not be thrown because the error trace shows `userId` is undefined at line 47."

**Invalid:** "The auth logic seems wrong, let me refactor it." / "Maybe there's a race condition."

**Step 3.1 â Test minimally.** Smallest possible code change. Do not refactor. Do not clean up. Change exactly what your hypothesis requires.

---

### Phase 4: Implementation

**Step 4.1 â Write the failing test first.** If you cannot write this test, you do not understand the bug well enough to fix it safely. Return to Phase 1.

**Step 4.2 â One change at a time.** Run test suite. Observe. Do not apply a second change until you have observed the result of the first.

**Step 4.3 â Enforce the 3-fix limit.** See Protocol 3 below.

---

### Anti-Rationalization Table

| Rationalization | What You're Actually Doing | Consequence |
|----------------|---------------------------|-------------|
| "It probably works now" | Skipping verification | Bug ships to production |
| "The error message is misleading" | Ignoring primary evidence | You fix the wrong thing |
| "This worked before, so bug must be in new code" | Confirmation bias | You miss regressions in old code |
| "It works on my machine" | Ignoring environment differences | Bug ships, users see it, you don't |
| "The logs don't show anything useful" | Insufficient instrumentation | You guess instead of knowing |
| "This is a one-off edge case" | Minimizing | You close a bug that will return |
| "Let me try a few things and see what sticks" | Simultaneous hypothesis testing | Cannot diagnose what you cannot isolate |
| "I know what this code does" | Assuming instead of reading | You miss the change that broke it |

**Rule:** When you catch yourself using any rationalization in this table, STOP. State explicitly: "I am rationalizing. The actual evidence is [X]. I will follow the evidence."

---

### Red Flags List

Treat as mandatory escalation triggers:
- Same function changed 3+ times without resolving the error
- Error message changes with each fix but system still fails
- Bug appears to move (fixing in one place makes it appear in another)
- Cannot reproduce bug consistently
- Bug only in production, not dev/staging
- Fix requires 50+ lines of change for a reported single-function bug
- Adding workarounds (try/catch swallowing errors, fallback values) instead of fixing root cause
- Debugging 45+ minutes without updating root cause statement

---

### Human Signal Words Table

| Signal Word | What User Means | Diagnostic Implication |
|-------------|----------------|----------------------|
| "Sometimes" | Intermittent â timing/state dependent | Check race conditions, async ordering, cache state |
| "Used to work" | Regression | git bisect or compare recent commits |
| "Only on my machine" | Environment difference | Check env vars, OS, dependency versions |
| "Only when I..." | Condition-dependent | The condition IS the root cause trigger |
| "Just started happening" | Correlation with recent event | Check deploys, dependency updates, data changes |
| "Always" | Deterministic â 100% reproducible | If you can't reproduce, you're missing a setup step |
| "Randomly" | Probabilistic â timing/threading/external | Add timing instrumentation; check shared mutable state |
| "After I..." | Sequence-dependent | State from prior action is persisting incorrectly |

Signal words cut debugging time by 40-60% on average.

---

## Protocol 2: Parallel Agent Debugging Protocol

**Trigger:** ONLY when 3+ separate debugging attempts have failed with different diagnosed root causes. Different root causes on each attempt = strong evidence of a system-level issue, not component-level.

### When to Trigger

All 3 conditions MUST be true:
1. 3+ debugging cycles completed (full Phase 1-4 each time)
2. Each cycle diagnosed a different root cause
3. No fix has resolved the error

### Agent Prompt Structure (4 fields)

```
Scope: [component/file/boundary]
Goal: [one specific question]
Constraints: [what agent MUST NOT change, tools allowed]
Expected Output: [exact deliverable format]
```

### Example: 3-Agent Parallel Debug

**Agent 1: Data Flow Tracer** â Read-only trace of data through system from HTTP handler to DB query.

**Agent 2: Contract Verifier** â Find any location where caller passes value not matching function's declared contract.

**Agent 3: State Mutation Auditor** â Find any shared state mutation that could cause concurrent requests to see inconsistent state.

### Integration Step

1. Check for file conflicts between agent recommendations
2. Identify the intersection â components appearing in 2+ agent reports are most probable root cause
3. Run full test suite before applying any fix
4. Apply fixes in order of dependency (deepest layer first)
5. Run test suite after each fix. Do not batch.

---

## Protocol 3: Three Strikes Architecture Rule

**After 3 failed fix attempts for the same bug: STOP. Do NOT attempt fix #4.**

**Consequence of fix #4:** After 3 failures, probability that you correctly diagnosed root cause is below 15%. A 4th attempt at the same level has <15% chance of succeeding and significant chance of introducing new failures.

### What Counts as a "Failed Fix Attempt"

Complete Phase 1-4 cycle + ran tests + error persisted or new error appeared.

If you applied a change without completing Phase 1, it was a guess, not a debugging attempt. Doesn't count toward strikes.

### The Reframe Protocol

**Step 1: State it explicitly.** Write: "3 fix attempts have failed. I am stopping. I am not attempting fix #4. I am questioning the architecture, not applying another patch."

**Step 2: Document failed attempts** in `findings.md` â hypothesis, change, result, why it failed for each of 3 attempts, plus the pattern across all 3.

**Step 3: Reframe.** Move up one level of abstraction:
- Component bug or system integration bug?
- Is the component I've been fixing even the one that owns this responsibility?
- Is the data wrong at the point I'm fixing it, or at the point it was created?
- Code bug or configuration bug?
- Runtime bug or build/deployment bug?

**Step 4: Present reframe to user.** Required format:
> "3 fix attempts failed. Tried [X], [Y], [Z]. None worked. I now think the real problem is [diagnosis at higher abstraction level]. Evidence: [specific]. Proposed approach: [new]. Proceed?"

**Step 5: Wait for direction.** Hard stop.

### What the Reframe Is NOT

- Touches the same file as all 3 failed attempts
- Proposes same type of change as failed attempts
- More aggressive version of most recent fix
- Doesn't explain why previous 3 attempts failed

A genuine reframe changes the level of abstraction.

### Does NOT Apply To

- Iterative optimization (autoresearch, A/B testing, eval-driven improvement)
- Configuration tuning
- Progressive enhancement

Three Strikes applies ONLY when something is broken and you are trying to make it not broken.

---

## Summary: Protocol Decision Tree

```
BUG REPORTED
     â Phase 1 (Root Cause)
     â Can you state root cause with evidence?
         YES â Phase 2 (Pattern Analysis)
         NO  â Add instrumentation. Return to Phase 1.
     â Phase 3 (Hypothesis) â ONE hypothesis
     â Phase 4 (Implementation) â failing test first, one change
     â Did it work?
         YES â Done. Verify with full test suite.
         NO  â How many attempts?
                 1-2 â Return to Phase 1 with new evidence
                 3   â THREE STRIKES: STOP
                        â 3+ different root causes? â PARALLEL AGENT PROTOCOL
                        â Same root cause 3x?       â REFRAME. Present. Wait.
```

**The protocol is the guardrail.** Agents who follow it complete debugging in 1-2 cycles. Agents who skip it average 4-7 cycles for the same class of bug.
