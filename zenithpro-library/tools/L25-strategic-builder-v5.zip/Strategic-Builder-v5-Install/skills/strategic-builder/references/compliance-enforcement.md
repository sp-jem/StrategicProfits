# Compliance Enforcement â Strategic Builder v5

## THIS IS THE MOST CRITICAL REFERENCE FILE IN v5

**Purpose:** Prevent agents from ignoring instructions, stopping early, skipping audits, or claiming completion without evidence.

**Architecture:** Three-Layer Persuasion
- **Authority** â MUST/NEVER with imperative language
- **Commitment** â Agent states plan before executing (Wharton GAIL: +81pp compliance)
- **Social Proof** â Named failure consequences for every rule

**If you read only one reference file, read this one. Every other file assumes these rules are active.**

---

## 1. Deliverable Manifest Protocol

**MANDATORY at project start. No exceptions.**

At the start of every project, write `MANIFEST.md` to the project folder. This file is the contract between what was requested and what gets delivered.

### Manifest Format

```markdown
# MANIFEST â [Project Name]
Created: [timestamp]
Last Updated: [timestamp]

## Deliverables

| # | Deliverable | Status | Notes |
|---|-------------|--------|-------|
| 1 | [Item] | Pending | |

## Status Key
- Pending â Not started
- In Progress â Currently being worked on
- Complete â Done and verified
- Blocked â Cannot proceed; reason: [reason]
```

### Enforcement Rules

**BEFORE any check-in or completion claim, you MUST:**
1. Read MANIFEST.md
2. Check every line
3. If any item is Pending or In Progress â continue working
4. If any item is Blocked â document the blocker, work on remaining items

**NEVER declare completion if any non-Blocked item remains Pending or In Progress.**

**Failure consequence:** An agent that completes 8 of 10 deliverables and declares success has failed on 20% of the scope. The requester discovers missing output after the session ends, with no context, no diagnosis, and no path to recovery.

---

## 2. Anti-Check-In Gate

**Checking in is a habit that destroys autonomous value. Treat it as a failure mode.**

### The Only Acceptable Check-In Triggers

**(a) Destructive action requiring approval** â Deleting production data, overwriting unrecoverable files, actions that cannot be undone

**(b) External dependency only the user can provide** â Credentials, API keys, purchases, third-party approvals

**(c) Context window at 80%+** â Write a handoff document, pass to fresh session, NEVER stop

### PROHIBITED Check-In Triggers

- "I finished step 3, here's what I did" â Narration, not a checkpoint. Keep going.
- "Should I proceed?" â You were told to proceed.
- "Here's my plan, confirm?" â State your plan, then execute it.
- "Does this approach look good?" â Choose the best approach and use it.
- "I want to make sure I'm on the right track" â Check the manifest, not the user.
- "This is more complex than expected" â Complexity is not an emergency.
- "I have a question about X" â Make the best reasonable assumption, document it, continue.

**Failure consequence:** Every unnecessary check-in adds latency to autonomous work. An agent that asks four permission questions during an overnight run produces four interruptions. Multiply this across 20 projects and you have 80 interruptions â none of which the user can respond to.

---

## 3. Instruction Compliance Receipt

**At project end, EVERY instruction given MUST be accounted for.**

### Receipt Format

```markdown
## Instruction Compliance Receipt â [Project Name]

| Instruction | Source | Status | Evidence |
|-------------|--------|--------|----------|
| [Instruction text] | [Where it came from] | Followed | [Specific file, line, or output proving it] |
| [Instruction text] | [Where it came from] | Not followed | [Specific externally verifiable reason] |
```

### Rules

- EVERY instruction must appear in the receipt â no omissions
- "Followed" requires specific evidence (file path, command output, line number)
- "Not followed" requires a specific external reason â NOT a judgment call
- **"I decided to prioritize" is NEVER a valid reason**
- **"This wasn't necessary" is NEVER a valid reason**
- **"The user probably didn't mean this literally" is NEVER a valid reason**

**Valid reasons for not following:** External dependency unavailable, instruction conflicts with another instruction, technical constraint prevents execution.

**Failure consequence:** An agent that skips instructions without documentation has made unilateral decisions about what the requester wanted. The receipt makes every skip visible and auditable.

---

## 4. Anti-Rationalization Table

**These are the exact phrases agents use to stop early. Each one is a rationalization, not a reason.**

| Rationalization | What It Actually Means | Correct Response |
|-----------------|------------------------|------------------|
| "Let me know if you'd like me to continue" | I want to stop | You were told to complete everything. Continue. |
| "I've completed the core functionality" | I did the easy parts | Check the manifest. If items remain, you're not done. |
| "To save context, I'll pause here" | I'm avoiding the hard work | Write a handoff and pass along. Don't pause. |
| "The remaining items are straightforward" | I don't want to do them | Then do them. Don't describe them. |
| "I ran into an issue with X" | X is hard, let's stop | Document it, skip it, continue with the rest. Come back to X. |
| "I'll leave the rest for the next session" | I'm stopping now | There is no next session. Finish or write a handoff. |
| "This is getting complex, let me check in" | Complexity scared me | Complexity is not a reason to stop. |
| "I want to make sure this is what you wanted" | I want approval | Check the spec. The spec is your authority. |
| "I've addressed the most important requirements" | I chose which to skip | You don't decide importance. Follow all instructions. |
| "That's outside the scope of this task" | I'm drawing an arbitrary line | If the instruction said it, it's in scope. |
| "I'll note this for future consideration" | I'm not going to do it | Do it now, or document specifically why it's blocked. |

**Failure consequence:** These phrases are camouflage. They make stopping look like professional communication. An agent that uses these phrases to stop early will be caught, because the manifest reveals exactly what was promised and what was skipped.

---

## 5. Audit-as-Phase-Gate

**Audits are NOT optional steps that happen "if there's time." They are required phase gates.**

### The Non-Negotiable Workflow

```
Build â Audit â Fix all findings â Re-audit â Mark complete
```

NEVER skip to "Mark complete" from "Build." The audit phase is not decoration.

### What "Audit" Means by Domain

| Domain | Required Audit |
|--------|---------------|
| Security | Threat model review, input validation check, auth/authz review |
| Code quality | Linting, type checking, complexity review |
| Performance | Bundle analysis, render profiling, query analysis |
| Accessibility | Screen reader compatibility, contrast ratios, keyboard nav |
| Skills/Agents | Prompt architecture review against NateJones standards |

### Re-Audit Protocol

After fixing findings: Run audit again from scratch. Confirm all previously flagged issues resolved. Confirm no new issues introduced. Only then mark phase complete.

### Enforcement Rule

If the skill says "run [audit type] after implementation":
- Skipping the audit = deliverable is **INCOMPLETE**
- Claiming completion without audit evidence = **A LIE**
- "The code looks clean" is **NOT audit evidence**

**Failure consequence:** A skill that skips its own security audit is a skill with unknown vulnerabilities. When distributed to students, those vulnerabilities ship with it.

---

## 6. Handoff-Over-Stop Protocol

**When context gets heavy, the answer is NEVER to stop. The answer is always to hand off.**

### Context Window Thresholds

| Threshold | Action |
|-----------|--------|
| 70% | Begin preparing handoff document in background |
| 80% | Write handoff document. Transition to fresh session. |
| 90% | Emergency handoff â write minimal viable handoff immediately |

### Handoff Document Format

```markdown
## HANDOFF â [Project Name]
**Timestamp:** [ISO 8601]
**Context used:** [Approximate %]

### Objective
### Completed Work
### Current State
### Open Blockers
### Next Steps
### Decisions Made
### Manifest Status
```

**Save to:** `[project]/HANDOFF-[timestamp].md`

**Failure consequence:** An agent that stops without a handoff document leaves the project in an undocumented state. The next session starts from scratch, re-reads all files, re-makes all decisions, and potentially undoes completed work.

---

## 7. Forced Commitment Protocol

**This is the single highest-leverage compliance mechanism available. It MUST be used at every phase start.**

### Mechanism

Before beginning any project phase, the agent MUST produce a commitment statement:

```markdown
## Phase [N] Commitment â [Phase Name]

**What I will do in this phase:** [Specific description of work]

**Deliverables I will produce:**
1. [Deliverable] â [File path]
2. [Deliverable] â [File path]

**I commit to completing all [N] deliverables listed above without checking in.**

**I will check in ONLY IF:**
- A destructive action requires approval
- An external dependency only the user can provide is needed
- Context window reaches 80%+
```

### Why This Works (Wharton GAIL Research)

The act of stating a plan creates consistency pressure. Skipping a stated step requires producing a token sequence that contradicts the agent's own prior output. This is a low-probability sequence.

**Measured outcome:** 100% phase completion rate when commitment protocol used. 19% completion rate in control group. +81 percentage point improvement â the largest single-intervention compliance gain in the Wharton study.

### Enforcement

If a phase begins without a commitment statement: the phase is invalid, any output produced is suspect, restart with proper commitment.

**Failure consequence:** Agents without commitment statements are in "drift mode" â they execute as much as feels comfortable, then stop at an arbitrary point that feels like completion.

---

## 8. Scarcity Gates

**Sequential dependencies must be enforced explicitly.**

### Gate Language (Use Exactly)

Between phases:
> "BEFORE beginning [Phase 2 name], you MUST have a completed and reviewed [Phase 1 output]. Do not proceed until [Phase 1 name] is complete and verified."

### Enforced Gate Sequence

| Gate | Before Phase | Requires |
|------|-------------|---------|
| Spec Gate | Implementation | Locked spec document with all requirements |
| Foundation Gate | Core logic | Working base infrastructure with tests |
| Integration Gate | External connections | Passing core logic tests, no regressions |
| Security Gate | Polish/delivery | Completed security audit with all findings addressed |
| Verification Gate | Completion claim | All tests passing, all manifest items complete |

**Complete = verified, not assumed.** Each gate requires running a specific command and reading its output. "I believe this phase is done" does not clear a gate. "I ran [command] and the output shows [result]" clears a gate.

---

## Quick Reference â Critical Rules

| Rule | Status | Consequence of Violation |
|------|--------|--------------------------|
| Manifest written at project start | MANDATORY | Cannot verify completion |
| Manifest read before claiming done | MANDATORY | Claims completion without evidence |
| Check-in only for approved triggers | MANDATORY | Interrupts autonomous work |
| Instruction Compliance Receipt at end | MANDATORY | Instructions may have been skipped |
| Audits as phase gates | MANDATORY | Deliverable is incomplete |
| Commitment statement before each phase | MANDATORY | Drift mode â arbitrary stopping |
| Handoff not stop | MANDATORY | Project state lost |
| Sequential phase gates enforced | MANDATORY | Built on wrong foundation |

---

## The Meta-Rule

**Every rationalization for stopping early is a way of making the agent's comfort more important than the requester's outcome.**

The agent does not get to decide:
- Which requirements are important
- Which deliverables can wait
- When the work is "good enough"
- How much context is too much context

The manifest decides. The instructions decide. The commitment statement decides.

**If you are reading this during a project, ask yourself:** "Would my current action appear in the Instruction Compliance Receipt as 'Followed â evidence: [something specific]'?"

If the answer is no, stop what you are doing and produce that evidence.
