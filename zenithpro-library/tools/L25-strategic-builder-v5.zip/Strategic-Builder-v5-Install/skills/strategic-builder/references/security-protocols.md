# Security Protocols â Strategic Builder v5

## AUTHORITY STATEMENT

These protocols are not suggestions. Every fail-open pattern that ships to production becomes a security incident when an environment variable is missing. This happens during deploys, server migrations, and container restarts.

You MUST run security scanning before any production deployment. You MUST classify risk before assigning review effort. You MUST block on CRITICAL findings. There are no exceptions.

---

## Pre-Execution Commitment Gate

Before running any security protocol, state:

```
Security Scan Commitment:
- Deployment target: [staging/production/internal]
- Risk classification: [HIGH/MEDIUM/LOW]
- Scans I will run: [list]
- Gate threshold: [what blocks deployment]
- Acceptance threshold: [what requires documented approval]
```

---

## 1. Insecure Defaults / Fail-Open Detection

### The Critical Distinction

**Fail-open:** System runs in insecure state when configuration is missing. User gets access they should not have. This is the pattern that kills companies.

**Fail-secure:** System throws error, refuses to start, or rejects operation when configuration is missing. This is correct behavior.

Code MUST fail-secure. A missing environment variable MUST cause hard failure at startup.

### The 5 Search Pattern Categories

Run ALL five. Do not skip.

**Category 1: Fallback Secrets**
```bash
grep -rn "SECRET.*||.*['\"]" ./src
grep -rn "process\.env\.\w+\s*\|\|\s*['\"]" ./src
grep -rn "os\.environ\.get.*,.*['\"]" ./src
```

**Category 2: Hardcoded Credentials**
```bash
grep -rn "password\s*=\s*['\"][^'\"]\+['\"]" ./src
grep -rn "BEGIN\s*PRIVATE\s*KEY" ./src
grep -rn "AKIA[0-9A-Z]{16}" ./src     # AWS access key
grep -rn "sk-[a-zA-Z0-9]{32,}" ./src  # OpenAI/Stripe secret
```

**Category 3: Weak Defaults**
```bash
grep -rn "DEBUG\s*=\s*[Tt]rue" ./src ./config
grep -rn "NODE_ENV.*=.*development" ./src ./config
grep -rn "verify\s*=\s*[Ff]alse" ./src   # SSL verification disabled
grep -rn "check_hostname\s*=\s*[Ff]alse" ./src
```

**Category 4: Permissive CORS**
```bash
grep -rn "Access-Control-Allow-Origin.*\*" ./src
grep -rn "cors.*origin.*['\*'\"]" ./src
grep -rn "origin:\s*['\"]?\*" ./src
```

**Category 5: Missing Auth Checks**
```bash
grep -rn "skipAuth\|noAuth\|publicRoute\|isPublic" ./src
grep -rn "@PermitAll\|@Unsecured\|@Public" ./src
grep -rn "allow_unauthenticated\|require_auth.*[Ff]alse" ./src
# Detect async handlers missing await on auth checks
grep -rn "auth\|authenticate\|authorize" ./src --include="*.ts" --include="*.js" | grep -v "await "
```

### Report Format Per Hit

```
FINDING: [Category]
File: [path:line_number]
Code: [exact matching line]
Risk: [CRITICAL/HIGH/MEDIUM]
Issue: [what this means in plain language]
Fix: [exact change required]
```

List every hit individually. Do not summarize.

---

## 2. Supply Chain Risk Checklist

### 6 Risk Criteria Table

| # | Criterion | Red Flag | Verification |
|---|-----------|----------|--------------|
| 1 | Maintainer count | Single maintainer, no succession plan | `npm info [pkg] maintainers` |
| 2 | Maintenance status | No commit in 12+ months | `git log --oneline -5` on repo |
| 3 | Popularity | <10K weekly downloads | `npm info [pkg] downloads` |
| 4 | Risk features | Requires fs, net, eval, child_process in package that doesn't need it | `cat node_modules/[pkg]/index.js \| grep -E "require\('fs\|require\('net\|eval\("` |
| 5 | CVE history | Any known CVE in last 24 months | `npm audit --audit-level=moderate` |
| 6 | Security contact | No SECURITY.md, no security email | Check repo root |

### Scoring and Decision Rules

| Red Flags | Decision |
|-----------|----------|
| 0 | Use freely |
| 1-2 | Document decision in package.json or PR |
| 3+ | Find alternative. If none, build in-house or escalate. |

### High-Risk Feature Flags (Automatic HIGH)

Any package with these capabilities in a context not requiring them is a supply chain attack vector:

- `child_process` spawn or exec
- `eval` or `new Function()`
- Direct filesystem writes
- Network requests to external URLs
- Access to environment variables beyond its own config
- Monkey-patching of global objects
- Dynamic `require()` with variable path

---

## 3. Pre-Deployment Security Gate

### The Rule

MUST run before ANY production deployment. No exceptions for "small" changes, "hotfixes", "config-only", or "we already reviewed this."

### Gate Sequence

Run three scans in order. Do not parallelize.

**Scan 1: Insecure Defaults** â all 5 categories from Protocol 1

**Scan 2: Dependency Audit**
```bash
npm audit --audit-level=moderate
# OR pip-audit (Python), govulncheck ./... (Go)
```

**Scan 3: Secrets Scan**
```bash
git diff main -- . | grep "^+" | grep -iE "password|secret|key|token|credential" | grep -v "^+++"
grep -rn "AKIA[0-9A-Z]\{16\}" . --exclude-dir=node_modules --exclude-dir=.git
grep -rn "sk-[a-zA-Z0-9]\{48\}" . --exclude-dir=node_modules --exclude-dir=.git
grep -rn "ghp_[a-zA-Z0-9]\{36\}" . --exclude-dir=node_modules --exclude-dir=.git
```

### Gate Decision Rules

| Finding Level | Action |
|---------------|--------|
| CRITICAL | BLOCK deployment. Fix and re-run gate. |
| HIGH | BLOCK unless documented acceptance with owner sign-off. |
| MEDIUM | Document. Proceed with PR comment. Follow-up ticket. |
| LOW | Note in PR. No action required. |

### Gate Output Format

```
PRE-DEPLOYMENT SECURITY GATE REPORT
Date: [timestamp]
Deployment target: [environment]
Branch: [branch name]
Scans completed: [list]

--- SCAN 1: INSECURE DEFAULTS ---
Status: [CLEAN / FINDINGS]
[List findings with file:line, or "No findings."]

--- SCAN 2: DEPENDENCY AUDIT ---
Status: [CLEAN / FINDINGS]
Vulnerabilities: [count by severity]
New dependencies added: [list]

--- SCAN 3: SECRETS SCAN ---
Status: [CLEAN / FINDINGS]
[List findings with file:line, or "No secrets detected."]

--- GATE DECISION ---
CRITICAL findings: [count]
HIGH findings: [count]
MEDIUM findings: [count]

DECISION: [APPROVED / BLOCKED]
Reason: [if blocked, specific findings]
Required before deploy: [specific fixes required]
```

A verbal statement of "looks clean" is not a gate. The report is the gate.

---

## Fail-Open Pattern Reference

### Fail-Open Auth Check

```javascript
// WRONG â fails open if JWT_SECRET is missing
const secret = process.env.JWT_SECRET || 'default-secret';

// CORRECT â fails secure
const secret = process.env.JWT_SECRET;
if (!secret) throw new Error('JWT_SECRET not configured. Cannot verify tokens.');
```

### Fail-Open Permission Check

```python
# WRONG â returns True (allow) if check throws
def has_permission(user, resource):
    try:
        return check_permission(user, resource)
    except:
        return True  # fail open

# CORRECT â returns False (deny) if check throws
def has_permission(user, resource):
    try:
        return check_permission(user, resource)
    except:
        return False  # fail secure
```

### Fail-Open CORS

```javascript
// WRONG â allows any origin if ALLOWED_ORIGINS is not set
const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(',') || ['*'];

// CORRECT â fails if ALLOWED_ORIGINS is not set
const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(',');
if (!allowedOrigins?.length) throw new Error('ALLOWED_ORIGINS not configured.');
```

### Missing Startup Validation

```javascript
// CORRECT â validate all required secrets at startup
const REQUIRED_ENV = ['JWT_SECRET', 'DB_PASSWORD', 'API_KEY', 'ENCRYPTION_KEY'];
const missing = REQUIRED_ENV.filter(key => !process.env[key]);
if (missing.length > 0) {
  throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
}
```

Startup validation fails immediately with a clear error message instead of running insecurely until a missing-config path is triggered.
