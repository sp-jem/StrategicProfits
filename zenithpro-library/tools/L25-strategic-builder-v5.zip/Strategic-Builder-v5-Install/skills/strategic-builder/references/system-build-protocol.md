# System Build Protocol

**Version:** 1.0 (introduced in Strategic Builder v4)
**Purpose:** Prescriptive build process for multi-component systems. Use this when the Complexity Fork in SKILL.md identifies a system build.

---

## When This Applies

After creating the Architecture Map (Level 2 of the Translation Stack), answer the fork test:

- [ ] The entire system runs as one process
- [ ] No scheduled execution (no cron, no launchd, no daemons)
- [ ] No shared state files that multiple components write to
- [ ] Can be deployed by copying one file/folder

**If ANY answer is NO, you are building a system. Follow this protocol.**

---

## If You Only Do One Thing

Add the Complexity Fork at the architecture step. The single question â "Does this have multiple processes, shared state, or scheduled execution?" â flags the project as a system build and triggers all downstream protections.

---

## Dependency Order of Changes

```
Change 2 (Shared State Architecture)
  â Change 4 (Physical Module Isolation)
    â Change 5 (Modification Safety)

Change 6 (Structured Observability)
  â Change 9 (Circuit Breaker)

Changes 1, 3, 7, 8, 10 â independent
```

---

## Scaling Guidance

| Modules | Shared State | Required |
|---------|-------------|----------|
| 2-3 | 1 | Shared State doc, Isolation tests, Observability, Recovery |
| 4-8 | 2-3 | Full protocol |
| 9+ | 4+ | Full protocol + dedicated integration test suite + health dashboard mandatory |

**Non-negotiable at any scale:** Shared State Architecture document and module isolation.

---

## TDD Overlap Resolution

For systems following this protocol, the **Deployment Architecture document replaces the TDD**. Do not produce both unless individual modules need their own TDD for external service integrations.

---

## Change 1: Complexity Fork

Lives in SKILL.md at Level 2 (System Architecture Map). Apply fork test. If system, all subsequent work follows this protocol.

---

## Change 2: Shared State Architecture

Produce BEFORE building any module. Template: `references/shared-state-template.md`.

### Validation Gate

- [ ] Every shared resource has exactly one owner
- [ ] No resource has multiple authoritative writers without documented conflict resolution
- [ ] "Could this be split?" asked and answered
- [ ] Concurrency rules implementable (specific mechanism, not "be careful")
- [ ] Corruption recovery defined with specific steps
- [ ] Every shared state file includes `schema_version` field
- [ ] Schema migration path documented

**Store as:** `[Project Folder]/shared-state-architecture.md`

---

## Change 3: Deployment Architecture

Produce BEFORE building any module (skip only for 2-3 module systems with no scheduled execution). Template: `references/deployment-architecture-template.md`.

### Validation Gate

- [ ] Every process has defined failure behavior
- [ ] No scheduling conflicts exist
- [ ] Overlap protection defined for every scheduled process
- [ ] Port allocation table has no duplicates
- [ ] Health check mechanism defined

**Store as:** `[Project Folder]/deployment-architecture.md`

---

## Change 4: Physical Module Isolation

Every module must be:

### Structurally Isolated
- Own directory: `modules/[module-name]/`
- Own entry point: `__main__.py` or `run.py`
- Own test file
- Own error log location
- NO direct imports from other modules' internal code

### Interface-Only Communication

Modules read/write shared state through a defined state access layer.

**Shared library allowlist (exhaustive):**
1. Logging utilities
2. File I/O (read, write, atomic write, exists, mkdir, backup copy)
3. Config reading
4. JSON parsing
5. Path resolution
6. Timestamp formatting

Any business logic, domain data transformation, or module-specific logic is NOT a utility.

### Independently Testable

Each module runs with `python -m modules.[name]` or `python modules/[name]/run.py`. Test passes or fails without any other module running.

### Validation Gate

- [ ] Every module has own directory with own entry point
- [ ] No cross-module imports (`grep -r "from modules\." modules/[name]/` returns zero)
- [ ] Shared library contains only allowlisted utilities
- [ ] Each module's isolation test passes standalone

### Build Cadence

1. Build shared state access layer first
2. Build module A, test in isolation
3. Build module B, test in isolation
4. Run A and B together, verify shared state integrity
5. Continue until all modules built
6. Integration test end-to-end
7. Only THEN deploy

---

## Change 5: Modification Safety Protocol

When changing an existing module in a deployed system:

1. Impact analysis â which shared resources + which other modules read them
2. Change in sandbox/copy first
3. Run module's isolation test
4. Run affected modules' tests
5. Run integration test
6. Only then deploy

**Never deploy a change that hasn't been tested against affected modules.** "I only changed one file" is not a safety argument.

**Store as:** Section in `[Project Folder]/AGENTS.md`.

---

## Change 6: Structured Observability

Every module produces structured logs answering 4 questions: What happened? Did it work? What changed? How long did it take?

### Standard Log Format

```json
{
  "module": "brain_prune",
  "timestamp": "2026-03-31T06:15:42",
  "status": "success",
  "duration_sec": 12.4,
  "summary": "Pruned 47 terminal items older than 30 days",
  "changes": {"items_before": 426, "items_after": 379, "items_pruned": 47},
  "error": null,
  "error_detail": null
}
```

### Requirements

- Structured log entry on every run (success or failure)
- Logs in `logs/` directory, one file per module per day: `[module-name]-YYYY-MM-DD.json`
- Daily health summary
- Failures include error, state left behind, and corruption status
- Logging in `try/finally` wrapper around entire module entry point

### Health Dashboard

Optional for 2-3 modules, required for 9+. Single page showing every module's last run time, status, errors. Green/red at a glance.

---

## Change 7: Recovery Design

Every module that writes shared state must implement:

### Atomic Writes
- Write to temp file first
- Only rename after successful write

### Pre-Write Backup
- Before modifying shared state, copy current file to `.bak`

### State Validation After Write
- Re-read file, verify valid
- If validation fails, restore from backup and log

### Validation Gate

- [ ] Atomic writes (write-to-temp-then-rename) â verified in module code
- [ ] `.bak` backup before writing â verified in module code
- [ ] Validation after writing â verified in module code
- [ ] PRD "Recovery" section with all three fields
- [ ] Recovery behavior tested (manually corrupt, verify restoration)

---

## Change 8: Dependency Health Checks (Preflight)

Every module checks dependencies before doing work.

```python
def preflight_check():
    """Run before any module logic. Return (ok, issues)."""
    issues = []
    if not state_file.exists():
        issues.append("brain-state.json missing")
    # ... other checks
    return (len(issues) == 0, issues)

# Usage at module entry point:
ok, issues = preflight_check()
if not ok:
    log_failure(module_name, "preflight_failed", issues)
    sys.exit(1)
```

### Rules

- If preflight fails: log specifics, skip execution, exit cleanly
- Do NOT proceed with missing dependencies
- Do NOT catch preflight failures silently

---

## Change 9: Circuit Breaker

**Depends on Change 6.**

Any module running on schedule must track consecutive failures.

- **After 3 consecutive failures:** Stop executing. Write alert to `logs/alerts.json`.
- **On each scheduled run:** Check `logs/alerts.json` for OPEN circuit breaker. If found, skip and log "circuit breaker open."

### Alert Format

```json
{
  "module": "brain_hourly",
  "alert_type": "circuit_breaker",
  "consecutive_failures": 3,
  "last_error": "Ollama not responding",
  "status": "OPEN",
  "action_required": "Check Ollama service, then reset"
}
```

### Reset

Delete alert from `logs/alerts.json` or run reset command. Module resumes on next scheduled run.

---

## Change 10: Distribution-Ready from Day One

Activated by flag at Vision (Level 1): "Will this be distributed to students/clients?"

If YES:

### Portability Architecture

- Environment detection
- Graceful degradation for missing optional dependencies
- All environment-specific values in one config file
- Installer prompts for credentials â NEVER embedded
- Platform support declared (Mac, PC, both)

### Per-Module PRD

- [ ] Zero hardcoded paths (all from config)
- [ ] Zero embedded credentials
- [ ] Test mode with sample data
- [ ] Setup instructions for someone with zero context

### Build Validation

- [ ] `grep -r "/Users/" [project-dir]` returns zero
- [ ] `grep -r "sk-ant-\|xoxb-\|Bearer " [project-dir]` returns zero
- [ ] Module runs on clean Python environment with declared dependencies
- [ ] Installer prompts for all required configuration

### End-to-End Distribution Test

- [ ] Package into installer (Mac + PC)
- [ ] Run on different user account or clean machine
- [ ] System starts with sample data
- [ ] No step requires reading source code

---

## Integration Test Definition

After all modules built and pass isolation tests:

1. Start all modules in dependency order
2. Run each module once
3. Verify all shared state is valid (exists, parses, schema_version matches, required keys present)
4. Verify all logs produced (structured entry with `status: "success"`)
5. Verify no errors (no `status: "failure"`)
6. Verify circuit breakers not tripped (no OPEN alerts)

Integration test **passes** if all 6 verification steps succeed. Partial passes are not passes.

---

## Runtime Verification for UI Systems

If system includes UI component:

- [ ] App builds without errors
- [ ] App starts and serves on designated port
- [ ] Port reachable
- [ ] Core data displays correctly (3 spot-checks)
- [ ] No JavaScript console errors on initial load

---

## Complete Checklist

### Design Phase

- [ ] Shared State Architecture document (passes gate)
- [ ] Deployment Architecture document (passes gate)
- [ ] Module isolation test contracts in each capability
- [ ] Portability architecture (if distributable)
- [ ] Build order from dependency graph
- [ ] TDD overlap resolved

### Per-Module Build Phase

- [ ] Module PRD with Observability, Recovery, Preflight/Dependencies, Portability sections
- [ ] Module built in own directory with own entry point
- [ ] Zero cross-module imports (verified by grep)
- [ ] Shared library uses only allowlisted utilities
- [ ] Module isolation test passes with sample data
- [ ] Atomic write + backup for state writes
- [ ] Preflight checks all dependencies
- [ ] Structured log entry on test run
- [ ] Integration test passes with prior modules

### System Integration Phase

- [ ] Full integration test passes (all 6 steps)
- [ ] Circuit breaker configured for scheduled modules
- [ ] Health dashboard functional (required 9+ modules)
- [ ] Modification Safety Protocol in project AGENTS.md
- [ ] Runtime verification passes for UI (if applicable)
- [ ] Distribution test on clean machine passes (if distributable)

---

## Retrofit Checklist for Existing Systems

### Prioritized Retrofit Order

1. Structured observability (Change 6) â visibility first
2. Preflight checks (Change 8) â prevent cascading failures during retrofit
3. Shared State Architecture (Change 2) â understand current state landscape
4. Recovery design (Change 7) â protect during retrofit
5. Module isolation (Change 4) â refactor one module at a time
6. Circuit breakers (Change 9) â prevent failure loops
7. Deployment Architecture (Change 3) â formalize what's running
8. Modification Safety Protocol (Change 5)
9. Distribution readiness (Change 10) â if applicable
10. Complexity Fork in AGENTS.md (Change 1)

### Retrofit Rules

- One module at a time
- Integration test after each
- Do NOT retrofit all simultaneously â that's a rewrite, not a retrofit

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-03-31 | Initial release with Strategic Builder v4. 10 system build changes, validation gates, integration test, scaling, retrofit. |
