# Shared State Architecture Template

Use this template for any project that forks into the System Build Protocol. Fill out one entry per shared resource. Produce this document BEFORE building any module.

---

## Shared State Question (Answer First)

For each piece of state in the system, ask: "Does more than one module need the same view of this data at the same time?" If NO, it should be module-owned state, not shared state. Only items that pass this test belong in this document.

---

## Shared State Inventory

### [State Name] (e.g., brain-state.json)

| Field | Value |
|-------|-------|
| **Location** | [exact path, e.g., `data/brain-state.json`] |
| **Format** | [JSON / SQLite / plain text / etc.] |
| **Owner** | [ONE module name -- the single authoritative writer] |
| **Readers** | [module names, in the order they typically read] |
| **Writers** | [module names and the mechanism each uses to write -- e.g., "brain_daily writes via atomic_write(), brain_prune writes via atomic_write()"] |
| **Concurrency** | [specific mechanism: lock file at `data/brain-state.lock` / sequential scheduling (A runs at :00, B runs at :30) / single-writer (only owner writes) / queue] |
| **Corruption recovery** | [specific steps: "restore from brain-state.json.bak, which is created before every write" / "rebuild from source data in feeds/" / "fail safe: module exits without writing"] |
| **Size management** | [does it grow? what prunes it? max size -- e.g., "Grows with new items. brain_prune removes terminal items older than 30 days. Max 2MB."] |

**Schema:**
```json
{
  "schema_version": 1,
  "key_1": "type: string -- description",
  "key_2": "type: integer -- description",
  "nested_object": {
    "sub_key": "type: array of strings -- description"
  }
}
```

**Could this be split?** [YES/NO -- if YES, describe how. If NO, explain why multiple modules need the same view.]

**Migration path:** When `schema_version` changes, readers that encounter an unrecognized version must: [fail explicitly with error "unrecognized schema_version: X, expected: Y" / attempt backward-compatible read / etc.]

---

### [State Name 2] (copy this section for each additional shared resource)

| Field | Value |
|-------|-------|
| **Location** | |
| **Format** | |
| **Owner** | |
| **Readers** | |
| **Writers** | |
| **Concurrency** | |
| **Corruption recovery** | |
| **Size management** | |

**Schema:**
```json
{
  "schema_version": 1
}
```

**Could this be split?** 

**Migration path:** 

---

## Minimal Shared State Rule

The ONLY state that should be shared is state that genuinely requires multiple modules to have the same view of the same data at the same time. Everything else should be module-owned.

If this document has more than 3-4 shared resources, re-examine whether some can be converted to module-owned state.

---

## Validation Checklist

Before proceeding to build any module, verify:

- [ ] Every shared resource has exactly one owner (one authoritative writer)
- [ ] No resource has multiple authoritative writers without explicit conflict resolution mechanism documented
- [ ] The "could this be split?" question was asked and answered for every shared resource -- answers recorded above
- [ ] Concurrency rules are implementable (specific mechanism named, not "be careful" or "avoid conflicts")
- [ ] Corruption recovery is defined with specific steps (not "shouldn't happen" or "restart the system")
- [ ] Every shared state file includes a `schema_version` field in its schema
- [ ] Schema migration path documented for every shared state file
