# Orchestration Protocols â Strategic Builder v5

## Three-Layer Persuasion Architecture

These protocols use:
- **Authority** â MUST/NEVER with imperative language
- **Commitment** â Agent states plan before executing
- **Social Proof** â Named failure consequences for every rule

---

## COMMITMENT REQUIREMENT (Read First)

Before dispatching any agent team, you MUST state:

1. How many agents you will spawn
2. What role each agent plays
3. What model each agent uses
4. What constitutes success for each agent

**Failure consequence:** Projects that skip this step produce redundant work, conflicting outputs, and wasted compute. The Wharton GAIL study showed agents that pre-committed to a plan completed 100% of deliverables vs. 19% in the control group.

---

## 1. RARV Cycle

**EVERY action runs through four checkpoints.**

**REASON** â Before acting: What am I doing and why? What could go wrong? What is the expected outcome?

**ACT** â Execute the action.

**REFLECT** â After acting: What actually happened? Does it match what was expected? What was the delta?

**VERIFY** â Confirm: Run the verification command. Read the full output. Only claim completion when output confirms it.

### Failure Escalation Ladder

| Attempt | Protocol |
|---------|----------|
| 1â2 | Retry with same approach |
| 3 | Switch to a different approach |
| 4 | Simplify â strip to minimum viable |
| 5 | Dead-letter queue (see Section 2) |

**NEVER skip VERIFY because the action "seemed to work."** Seeming is not evidence. Run the command.

---

## 2. Dead-Letter Queue

**When a task fails 5 times, it goes to the dead-letter queue. You MUST NOT block the project on it.**

### Protocol

1. Log the failure to `[project]/.dead-letter.json`
2. Move on to the next task
3. Report all dead-letter items at session end

### Log Format

```json
{
  "task": "Description of what was attempted",
  "attempts": 5,
  "last_error": "Exact error message",
  "timestamp": "ISO 8601 timestamp",
  "approaches_tried": ["approach 1", "approach 2"],
  "impact": "What this blocks"
}
```

### Rules

- NEVER retry a dead-letter item in the same session without a fundamentally new approach
- NEVER omit dead-letter items from the session-end report
- NEVER mark a project complete if dead-letter items affect core deliverables
- ALWAYS flag dead-letter items by name, not as generic "some issues arose"

---

## 3. Phase-Gate Build Model

### Complexity Tier Auto-Detection

| Tier | File Count | Phase Count | Signal |
|------|------------|-------------|--------|
| Simple | 1â3 files | 3 phases | Single-purpose utility |
| Standard | 4â15 files | 6 phases | Multi-file, 1â2 integrations |
| Complex | 16+ files | 8 phases | Full application, multiple integrations, DB |

### Phase Transition Requirements (ALL must be true)

1. All tests for the current phase pass
2. No critical or high issues remain open
3. All spec requirements for this phase are implemented
4. The verification command has been run and its output confirms completion

### Standard Phase Structure (6-phase)

1. Spec â 2. Foundation â 3. Core â 4. Integration â 5. Polish â 6. Verification

### Complex Phase Structure (8-phase)

1. Spec â 2. Deepen â 3. Foundation â 4. Core â 5. Integration â 6. Security â 7. Polish â 8. Verification

### The Deepen Phase (Complex Projects Only)

Spawn 4 parallel research agents BEFORE writing a line of production code:

| Agent | Role |
|-------|------|
| Architecture Researcher | What patterns apply here? |
| Security Researcher | What can go wrong? |
| Integration Researcher | What does the external system require? |
| Performance Researcher | What will break under load? |

All four run in parallel. Implementation begins only after all four complete.

---

## 4. Agent Team Dispatch

### Model Tier Assignments

| Task Type | Model | Rationale |
|-----------|-------|-----------|
| File generation, formatting, boilerplate | Sonnet | Mechanical |
| Integration work, API calls | Sonnet | Structured |
| Architecture decisions, design review | Opus | Judgment-intensive |
| Security audit, threat modeling | Opus | Stakes are high |
| Copy critique, strategic synthesis | Opus | Nuance-dependent |

### Parallelism Rules

**NEVER run parallel implementation agents.** Two agents writing code to the same codebase create merge conflicts.

**ALWAYS run parallel review agents.** Reviewers read; they don't write.

### Sub-Agent Status Codes

Every sub-agent MUST return one of:

| Code | Meaning | Handler Action |
|------|---------|----------------|
| `DONE` | Complete, no issues | Accept output, proceed |
| `DONE_WITH_CONCERNS` | Complete, flagged items | Review concerns before proceeding |
| `NEEDS_CONTEXT` | Blocked on missing info | Provide context, re-dispatch |
| `BLOCKED` | Cannot proceed without external action | Escalate, log to dead-letter |

---

## 5. Branch Completion Menu

When a feature branch reaches completion, present:

```
Branch completion options:
1. Merge locally (no remote push)
2. Push + open PR
3. Keep as-is (no action)
4. Discard branch (requires typing "discard" to confirm)
```

### Prerequisites Before Presenting

- All tests pass
- No uncommitted changes
- No new TODO/FIXME comments added this session

---

## 6. Deployment Decision Trees

### Vercel Decision Tree

```
Is project linked to Vercel?
âââ YES: git push â Vercel auto-deploys via integration
âââ NO: Install CLI â link â preview deploy
```

### Safety Rules

- **Preview by default** â Every deployment goes to preview unless production is explicitly requested
- **Never production without explicit request** â "Deploy this" means preview. "Deploy to production" means production.
- **Token security** â Auth tokens go in environment variables, NEVER as CLI flags
- **Verify deployment URL** â After every deployment, confirm the preview URL loads

---

## 7. Compound Learning

Non-obvious solutions MUST be extracted to the solutions library.

### Extraction Criteria â ALL THREE must be true

1. The root cause was non-obvious
2. The solution is reusable
3. The session won't remember it

### File Location

`~/.claude/solutions/{category}/{slug}.md`

### Required YAML Frontmatter

```yaml
---
slug: descriptive-hyphenated-name
category: category-name
problem: One sentence describing the problem
root_cause: One sentence describing why it happened
solution: One sentence describing the fix
discovered: YYYY-MM-DD
tags: [tag1, tag2, tag3]
---
```

---

## 8. Session Liveness Heartbeat

For long-running agents, `[project]/.session.json` MUST be updated every turn.

### Required Fields

```json
{
  "session_id": "unique-identifier",
  "started": "ISO 8601 timestamp",
  "last_heartbeat": "ISO 8601 timestamp â updated every turn",
  "current_phase": "Phase name",
  "current_task": "What the agent is doing right now",
  "completed_tasks": 0,
  "total_tasks": 0,
  "status": "active | paused | complete | failed",
  "last_error": null
}
```

### Update Protocol

1. Update `last_heartbeat` at START of every action
2. Update `current_task` when switching tasks
3. Update `current_phase` when crossing a phase gate
4. Update `completed_tasks` when a task finishes
5. Set `status: failed` and populate `last_error` if session terminates abnormally

---

## 9. Git Worktree Parallelism

### When to Use

- 3+ independent workstreams with no shared code paths
- One stream must not block another
- Streams will eventually merge to main

### Setup

```bash
git worktree add ../[project]-stream-1 -b stream/stream-1
git worktree add ../[project]-stream-2 -b stream/stream-2
```

### Signal Files for Inter-Stream Communication

Each stream signals state via `.stream-[name]-status` â contents: `active`, `complete`, or `blocked:[reason]`

### Cleanup

```bash
git worktree remove ../[project]-stream-1
git branch -d stream/stream-1
```

**NEVER leave orphaned worktrees.**

---

## Quick Reference

| Protocol | Trigger | Key Rule |
|----------|---------|----------|
| RARV | Every action | REASON â ACT â REFLECT â VERIFY |
| Dead-Letter Queue | 5th failure | Log, move on, report at end |
| Phase-Gate Build | Any project | All gates must pass before next phase |
| Agent Dispatch | Team needed | Commit first: agents, roles, models, success |
| Branch Menu | Feature complete | Present options, wait for selection |
| Deployment | Deploy requested | Preview default, never prod without explicit ask |
| Compound Learning | Non-obvious fix | Extract to solutions library |
| Heartbeat | Long-running session | Update every turn |
| Worktree | Multi-stream | Clean separation or go sequential |
