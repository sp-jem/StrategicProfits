# Strategic Builder v5
## Installation Guide

---

## What You're Installing

**Strategic Builder v5** is a prescriptive methodology you FOLLOW (not consult) for every software project. It integrates the Translation Stack, System Build Protocol, TDD, systematic debugging, security scanning, two-stage code review, agent team orchestration, and compliance enforcement into ONE unified system.

**The Translation Stack (7 levels):**
1. **Vision Document** — Transformed state, not features
2. **System Architecture Map** — All systems and dependencies
3. **Capability Map** — Jobs each system must perform
4. **Phased Delivery Plan** — Phase 1 solves a real problem on its own
5. **Prototyping** — AI tools only; validate before writing the PRD
6. **PRD** — 8-component specification; translation audit required
7. **Implementation** — Build with Execution Checklist; evidence required per requirement

**Every level has a gate. Every gate has pass conditions. No gate is optional.**

**What this is NOT:**
- Not a reference to consult selectively — follow the entire protocol or none of it
- Not a coding style guide
- Not a project management tool
- Not optional for "simple" projects

---

## Prerequisites

1. **Claude Code CLI installed and working**
   - Open a terminal and type `claude` — it should start a session

No other dependencies required.

---

## Installation Instructions

### Mac / Linux

**Option A: Installer Script (Recommended)**

1. Open Terminal
2. Navigate to this folder:
   ```
   cd ~/Desktop/Strategic-Builder-v5-Install
   ```
3. Run the installer:
   ```
   bash install.sh
   ```
4. Restart Claude Code

**Option B: Manual Copy**

Copy the skill folder into `~/.claude/skills/`:
```bash
cp -r skills/strategic-builder ~/.claude/skills/
```

---

### Windows

**Option A: Installer Script (Recommended)**

1. Open PowerShell as Administrator
2. Navigate to this folder:
   ```
   cd "$env:USERPROFILE\Desktop\Strategic-Builder-v5-Install"
   ```
3. If needed, allow script execution:
   ```
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```
4. Run the installer:
   ```
   .\install.ps1
   ```
5. Restart Claude Code

**Option B: Manual Copy**

Copy `skills\strategic-builder\` into `C:\Users\[YourName]\.claude\skills\`

---

## Verify Installation

After restarting Claude Code, type:
```
/strategic-builder
```

Claude will ask what you're building and guide you through the appropriate workflow.

---

## What's Included

| Folder | What It Is |
|--------|-----------|
| `skills/strategic-builder/` | The complete v5 methodology skill |
| `skills/strategic-builder/references/` | All templates: PRD, TDD, architecture, capability map, and more |

---

## How to Use

**Trigger:** `/strategic-builder`

**Use it when:**
- Starting any software project
- Building any feature
- Debugging system failures
- Deploying to production

**The decision tree (from the skill):**
- New project → Full Workflow (Infrastructure → Vision → ... → Implementation → Finishing)
- Continuing existing project → Session Startup Protocol
- Adding new system → Architecture → Capability Map → PRD → Build
- Quick fix → PRD (lightweight) → Build

---

## Version History

| Version | Notes |
|---------|-------|
| v5 | Added coding-specific quality enforcement (TDD, debugging, security, review protocols), agent team orchestration, and compliance enforcement. Unified Translation Stack with System Build Protocol. |
| v4 | Translation Stack + System Build Protocol (separate). |
