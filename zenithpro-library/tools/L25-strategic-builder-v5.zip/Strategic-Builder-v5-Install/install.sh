#!/bin/bash
# Strategic Builder v5 - Mac/Linux Installer

echo "============================================"
echo "  Strategic Builder v5 Installer"
echo "  The Complete Software Engineering System"
echo "============================================"
echo ""

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
TARGET_DIR="$HOME/.claude/skills"

if [ ! -d "$TARGET_DIR" ]; then
    echo "Creating skills directory at $TARGET_DIR..."
    mkdir -p "$TARGET_DIR"
fi

echo "Installing skills..."

SKILLS=("strategic-builder")

for skill in "${SKILLS[@]}"; do
    echo "  -> $skill"
    cp -r "$SCRIPT_DIR/skills/$skill" "$TARGET_DIR/"
done

echo ""

# Verify
ALL_GOOD=true
for skill in "${SKILLS[@]}"; do
    if [ ! -d "$TARGET_DIR/$skill" ]; then
        echo "ERROR: $skill failed to install."
        ALL_GOOD=false
    fi
done

if [ "$ALL_GOOD" = true ]; then
    echo "============================================"
    echo "  Installation Complete!"
    echo "============================================"
    echo ""
    echo "Skills installed:"
    echo "  - strategic-builder   (v5 — The Complete Software Engineering System)"
    echo ""
    echo "How to run:"
    echo "  1. Restart Claude Code"
    echo "  2. Type: /strategic-builder"
    echo ""
    echo "Use it when:"
    echo "  - Starting any software project"
    echo "  - Building any feature"
    echo "  - Debugging system failures"
    echo "  - Deploying to production"
    echo ""
else
    echo ""
    echo "ERROR: Installation failed."
    echo "Check that the skills/ folder is intact in this package."
fi
