# ZenithPro: Toward Markets — Install All 11 Skills
# Run this from the folder where you unzipped the package.
# In PowerShell: Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

$Skills = @(
    "toward-desire-mapper",
    "aspiration-excavation",
    "aspiration-avatar-excavation",
    "progression-pattern-analysis",
    "permission-concept-generator",
    "ideal-aspiration-mindset",
    "identity-belief-gap-analyzer",
    "toward-usp-generator",
    "aspiration-mimetic-intelligence",
    "community-architect",
    "toward-demand-architect"
)

Write-Host "Installing ZenithPro: Toward Markets (11 skills)..."
Write-Host ""

$Success = 0
$Failed = 0

foreach ($Skill in $Skills) {
    $InstallDir = "$env:USERPROFILE\.claude\skills\$Skill"
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    Copy-Item "$Skill\SKILL.md" "$InstallDir\SKILL.md"
    if (Test-Path "$InstallDir\SKILL.md") {
        Write-Host "✅ $Skill"
        $Success++
    } else {
        Write-Host "❌ $Skill — FAILED"
        $Failed++
    }
}

Write-Host ""
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
Write-Host "Installed: $Success / 11 skills"
if ($Failed -gt 0) {
    Write-Host "Failed: $Failed skills — check that ~/.claude/skills/ exists"
}
Write-Host ""
Write-Host "Run any skill with: /[skill-name]"
Write-Host "Run full pipeline:  /toward-demand-architect full [your market]"
Write-Host "Diagnose market:    /motivation-spectrum-analyzer [your market]"
