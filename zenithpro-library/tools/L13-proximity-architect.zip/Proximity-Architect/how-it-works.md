# How Proximity Architect Works

> **Note:** This document contains Mermaid diagrams. For best results, view in Obsidian, VS Code, or GitHub.

## Overview

Proximity Architect is a single-command skill that transforms "Find my AI community in [city]" into a complete, actionable network guide in 2-3 minutes.

```mermaid
flowchart TD
Q[Your Request] --> D[Mode Detection]
D --> R[Deep Research]
R --> C[Consolidation]
C --> O[Output Generation]
O --> F[(Your AI Network Guide)]
```

## Detailed Flow

### Step 1: Mode Detection (Automatic)

The skill reads your request and automatically determines what mode to use:

```mermaid
flowchart TD
REQ[Your Request] --> CHECK{Contains dates?}
CHECK -->|Yes| TRAVEL[Travel Mode]
CHECK -->|No| LOCAL[Local Mode]
CHECK --> UE{Universal Expander detected?}
UE -->|Yes| PERSONALIZE[Add Personalization]
UE -->|No| STANDARD[Standard Output]
```

**Three modes:**
1. **Local Mode** - Building your permanent AI network map
2. **Travel Mode** - Finding events during specific travel dates
3. **Universal Expander Mode** - Personalized recommendations based on your identity framework

**Universal Expander detection:**
- Checks conversation for your Universal Expander document
- Looks in common Obsidian vault paths
- Searches Zenith folders
- If found: extracts your strategic capacities for personalized recommendations
- If not found: proceeds without it (never asks)

### Step 2: Research (1-2 minutes)

The skill uses Claude Code's deep-research capabilities to search multiple sources in parallel:

```mermaid
flowchart TD
CITY[City/Location] --> DEEP[Deep Research Orchestrator]
DEEP --> M[Meetup.com]
DEEP --> E[Eventbrite]
DEEP --> L[Luma]
DEEP --> LI[LinkedIn Events]
DEEP --> CW[Coworking Directories]
DEEP --> AI[AI Community Sites]
M & E & L & LI & CW & AI --> RESULTS[Raw Results]
```

**Sources searched:**
- **Event platforms:** Meetup, Eventbrite, Luma, LinkedIn Events
- **Community sites:** AI Tinkerers, AI Engineers, local AI chapters
- **Coworking:** WeWork, Regus, independent spaces, coffee shops
- **Innovation hubs:** Accelerators, incubators, university programs
- **Key people:** LinkedIn profiles, local organizers, community leaders

**What's collected:**
- Community names, meeting schedules, locations
- Event dates, times, registration links
- Coworking pricing, amenities, addresses
- People names, titles, LinkedIn URLs
- Topics, focus areas, audience profiles

### Step 3: Consolidation (30 seconds)

Raw research results are consolidated using smart deduplication heuristics:

```mermaid
flowchart TD
RAW[Raw Results] --> DUP[Deduplication]
DUP --> VER[Verification]
VER --> PRI[Prioritization]
PRI --> ORG[Organization]
ORG --> CLEAN[Clean Data]
```

**Deduplication heuristics:**

```
SAME COMMUNITY if:
- Name similarity ≥80% (fuzzy match)
- Same city/neighborhood (within 5 miles)
- Same meeting frequency (weekly/monthly)
→ Merge into one entry

DIFFERENT COMMUNITIES if:
- Location differs by >5 miles
- Organizer differs
- Platform differs
→ List as separate entries

UNCERTAIN:
→ List both with verification note
```

**Example:**
- "GenAI Boca Meetup" on Meetup.com
- "GenAI Boca" on Eventbrite at same address
- **Result:** Merged into one entry with both registration links

**Verification:**
- Confirms addresses are real
- Checks that URLs work
- Validates contact information
- Flags outdated events

**Prioritization:**
- Travel Mode: Events during your dates ranked first
- Local Mode: Regular communities ranked by activity level
- Both: Free options highlighted

**Organization:**
By actionability:
1. Next 48 hours (immediate action)
2. This week (short-term planning)
3. This month (medium-term)
4. Full directory (reference)

### Step 4: Output Generation (10 seconds)

Creates your complete AI Network guide using the Visual Impact template:

```mermaid
flowchart TD
DATA[Clean Data] --> HERO[Hero Section]
DATA --> COMM[Communities]
DATA --> SPACE[Spaces]
DATA --> PEOPLE[People]
DATA --> INV[Investment Strategy]
DATA --> CAL[Calendar Template]
DATA --> PLAY[90-Day Playbook]
HERO & COMM & SPACE & PEOPLE & INV & CAL & PLAY --> MD[Markdown File]
DATA --> ICS[.ics Calendar Files]
MD & ICS --> PKG[Complete Package]
```

**Generated files:**

1. **Main Guide** (`[City] - AI Network.md`)
   - Hero stats section
   - Start Here (48 hours)
   - Communities directory
   - Spaces (coworking, coffee shops, hubs)
   - People (key connectors)
   - Investment strategy (free, mid, premium)
   - Perfect Week template
   - Next 30 Days calendar
   - 90-Day Playbook

2. **Calendar Files** (`[City] - Events Calendar/`)
   - Individual .ics file for each event
   - Ready to import into any calendar app

**Visual Impact features:**
- Emoji navigation for quick scanning
- Expandable sections (progressive disclosure)
- Priority stars for must-attend events
- Stats tables with "What This Means" context
- Action-oriented language throughout

### Step 5: Package Delivery

```mermaid
flowchart TD
PKG[Complete Package] --> SAVE[Save to Location]
SAVE --> OBS{Obsidian detected?}
OBS -->|Yes| VAULT[Save to Vault]
OBS -->|No| CWD[Save to Current Directory]
VAULT & CWD --> SUMMARY[Delivery Summary]
SUMMARY --> USER((You))
```

**Saved to:**
- Obsidian users: `~/Documents/Obsidian/Active-Brain/00 Projects/Your AI Network/[City]/`
- Others: `./Your AI Network/[City]/`

**Delivery summary includes:**
- File locations
- Number of communities found
- Number of events this month
- Next 48 hours action items
- Quick start instructions

---

## Edge Case Handling

### No Events During Travel Dates

```mermaid
flowchart TD
RESEARCH[Research Complete] --> COUNT{Events found?}
COUNT -->|Zero| OPTIONS[Present Options]
OPTIONS --> OPT1[Expand date range ±3 days]
OPTIONS --> OPT2[Show full network anyway]
OPTIONS --> OPT3[Deliver venues + contacts only]
COUNT -->|Some| PROCEED[Generate normal output]
```

**Instead of failing, you get:**
1. Count of coworking spaces found
2. Count of key people to reach out to
3. Count of regular communities (even if meetings fall outside dates)
4. Three clear options to proceed

### Small Cities

```mermaid
flowchart TD
RESEARCH[Research Complete] --> SIZE{Large results?}
SIZE -->|Small| EXPAND[Expand Search]
EXPAND --> NEARBY[Show nearby cities]
EXPAND --> VIRTUAL[Show virtual communities]
EXPAND --> START[Show how to start your own]
SIZE -->|Large| PROCEED[Generate normal output]
```

**Graceful adaptation:**
- Shows communities in nearby cities (within 50 miles)
- Includes virtual/online AI communities
- Provides guidance on starting your own meetup
- Lists adjacent communities (tech, entrepreneurship)

### Universal Expander Not Found

```mermaid
flowchart TD
DETECT[Check for Universal Expander] --> FOUND{Found?}
FOUND -->|Yes| EXTRACT[Extract capacities]
EXTRACT --> PERSONALIZE[Personalize recommendations]
FOUND -->|No| SKIP[Skip personalization]
SKIP --> STANDARD[Standard output]
```

**No interruption:**
- Never asks user about Universal Expander
- Proceeds with full network output
- No degradation in quality
- Simply skips personalization layer

---

## Why This Approach Works

### Manual Research (Old Way)

**Time:** 4+ hours

**Steps:**
1. Google "AI meetups [city]"
2. Check Meetup.com individually
3. Check Eventbrite individually
4. Find coworking spaces
5. Look up people on LinkedIn
6. Manually organize into usable format
7. Create calendar entries by hand
8. Try to figure out what to prioritize

**Problems:**
- Scattered results
- Missed communities
- Duplicate entries
- No prioritization
- No action plan
- Time-consuming

### Proximity Architect (New Way)

**Time:** 2-3 minutes

**Steps:**
1. Tell Claude: "Find my AI community in [city]"
2. Wait
3. Done

**Benefits:**
- Comprehensive search (sources you'd never check)
- Smart consolidation (no duplicates)
- Automatic prioritization (by actionability)
- Complete action plan (48 hours → 90 days)
- Calendar files ready to import
- Beautiful, usable output

---

## Technical Details

### Mode Detection Logic

```
IF request contains date patterns:
  → Travel Mode
ELSE:
  → Local Mode

IF Universal Expander detected in:
  - Current conversation
  - Common vault paths
  - Zenith folders
  → Extract identity framework
  → Add personalization layer
```

### Deduplication Algorithm

```
FOR each community in results:
  FOR each other community:
    name_similarity = fuzzy_match(name1, name2)
    distance = calculate_distance(location1, location2)

    IF name_similarity >= 0.8
       AND distance <= 5 miles
       AND frequency_matches:
      → MERGE (use most detailed info)

    ELSE IF significantly_different:
      → KEEP BOTH

    ELSE:
      → FLAG for verification
```

### Output Template Structure

```
1. Hero Section (collapsible callout)
   - Stats table
   - Motivational intro

2. Start Here (collapsible callout)
   - Next 48 hours
   - This week
   - This month

3. Communities (expandable entries)
   - Each with priority stars
   - Attendee profiles
   - Entry requirements

4. Spaces (expandable entries)
   - Coworking with pricing tables
   - Coffee shops with best times
   - Innovation hubs with programs

5. People (expandable entries)
   - Key connectors
   - Where to find them
   - Outreach templates

6. Investment Strategy (collapsible tiers)
   - Free/Under $50
   - Mid $50-200
   - Premium $200+

7. Calendar (collapsible callout)
   - Perfect Week template
   - Next 30 Days table

8. 90-Day Playbook (collapsible callouts)
   - Month 1: Foundation
   - Month 2: Integration
   - Month 3: Leadership

9. Quick Links (collapsible callout)
   - All URLs in one place
```

---

## Future Enhancements (Potential)

- **Integration with calendar apps** - Direct calendar sync
- **Automatic updates** - Refresh your network monthly
- **Community health scores** - Rate communities by activity level
- **Personalized matching** - Beyond Universal Expander, match based on interests/skills
- **Multi-city networks** - For frequent travelers
- **Virtual community integration** - Discord servers, Slack groups, online meetups
- **Testimonial collection** - Real reviews from community members

---

*Generated for Proximity Architect documentation*
*Created by Rich Schefren - Strategic Profits*
