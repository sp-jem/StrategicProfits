# Proximity Architect v1.0

**Instant AI community network mapping for any city. Finds coworking spaces, meetups, key connectors, and creates your complete action plan with calendar files—all in one command.**

---

## What This Does

When you tell Claude Code "Find my AI community in [city]" or "I'm traveling to Austin next week," this skill automatically:

1. **Researches** - Searches multiple sources for AI communities, coworking spaces, events, workshops, and key people
2. **Consolidates** - Deduplicates results and organizes by actionability
3. **Creates Your Action Plan** - Generates a beautiful, visual document with:
   - Next 48 hours action items
   - Weekly calendar template
   - 90-day integration playbook
   - Complete community directory with addresses, costs, registration links
   - Key people to connect with (including LinkedIn outreach templates)
4. **Exports Calendar Files** - Creates .ics files you can import directly into your calendar

**Result:** Instead of spending hours researching and organizing, you get a complete "Your AI Network" guide in minutes—ready to use immediately.

---

## What You'll Get

### The Output Document

A visually rich Obsidian/Markdown document with:

- **Hero Stats Section** - Quick overview (12 communities, 5 coworking spaces, 23 events this month)
- **Start Here** - Next 48 hours action items (specific events, coworking day passes, people to connect with)
- **Communities Directory** - Each community with frequency, location, cost, attendees, how to join
- **Spaces** - Coworking spaces with pricing, coffee shops, innovation hubs
- **People** - Key connectors with LinkedIn profiles and outreach templates
- **Investment Strategy** - Free, mid-tier, and premium options organized by ROI
- **Perfect Week Template** - Hour-by-hour schedule showing how to integrate networking
- **90-Day Playbook** - Month 1 (Foundation), Month 2 (Integration), Month 3 (Leadership)

See `sample-output.pdf` for a real example.

### Calendar Files

Individual .ics files for each event that you can:
- Import into Google Calendar, Apple Calendar, Outlook
- Set reminders
- Share with others

### Three Modes

1. **Local Mode** - Map your home city's complete AI network
2. **Travel Mode** - Find events/venues during specific travel dates
3. **Universal Expander Mode** - Automatically detects and incorporates your identity framework for personalized recommendations

---

## Who This Is For

- **AI power users** looking to connect with other builders in their city
- **Entrepreneurs** traveling to new cities who want to network efficiently
- **Remote workers** seeking coworking spaces where AI builders gather
- **Anyone** who wants to stop researching and start connecting

---

## Requirements

Before installing, you'll need:

1. **Claude Code** installed and working
2. **Obsidian** (recommended for viewing the beautiful output, but not required—output is standard Markdown)

That's it. No API keys, no Python dependencies, no complex setup.

---

## Installation

### Mac/Linux (Terminal)

```bash
cd ~/Downloads/Proximity-Architect
chmod +x install.sh
./install.sh
```

### Windows (PowerShell)

```powershell
cd ~/Downloads/Proximity-Architect
.\install.ps1
```

The installer will:
1. Create `~/.claude/skills/proximity-architect/` directory
2. Copy the skill file
3. Verify installation
4. Show you how to use it

Takes about 5 seconds.

---

## How to Use

### Basic Usage

After installation, open Claude Code and say:

```
Find my AI community in Miami
```

Or:

```
I'm traveling to Austin March 15-20, find AI events and coworking spaces
```

Or just:

```
Proximity architect for Boston
```

Claude will:
1. Ask for any missing details (city, dates if traveling)
2. Run deep research across multiple sources
3. Consolidate and deduplicate results
4. Generate your complete AI Network document
5. Create calendar files for all events
6. Save everything to a folder in your Obsidian vault (or current directory)

### Universal Expander Integration

If you have a Universal Expander document in your Obsidian vault, the skill automatically detects it and personalizes recommendations based on:
- Your strategic capacities
- Your genius zones
- Your transformational purpose

No setup required—it just works.

### Output Location

By default, files are saved to:
```
~/Documents/Obsidian/Active-Brain/00 Projects/Your AI Network/[City Name]/
```

Or if not using Obsidian:
```
./Your AI Network/[City Name]/
```

Files created:
- `[City Name] - AI Network.md` - Main guide
- `[City Name] - Events Calendar/` - Individual .ics files for each event

---

## Sample Output

See `sample-output.md` in this folder for a real example created for Delray Beach, Florida.

Key features you'll see:
- Beautiful visual hierarchy with expandable sections
- Emoji navigation for quick scanning
- Priority stars for must-attend events
- Action-oriented formatting (addresses, times, costs, URLs)
- Progressive disclosure (expand sections as needed)
- Complete 90-day playbook

---

## How It Works

### Step 1: Mode Detection (Automatic)

The skill reads your request and determines:
- **Local Mode** - Building permanent network map
- **Travel Mode** - Finding events during specific dates
- Detects Universal Expander if present

### Step 2: Research (1-2 minutes)

Searches multiple sources:
- Meetup.com
- Eventbrite
- Luma
- LinkedIn Events
- Community websites
- Coworking space directories
- Local AI chapters (AI Tinkerers, AI Engineers, etc.)

### Step 3: Consolidation (30 seconds)

- Deduplicates communities (same group on multiple platforms)
- Verifies addresses and contact info
- Prioritizes events by relevance
- Organizes by actionability

### Step 4: Output Generation (10 seconds)

- Creates beautifully formatted guide
- Generates calendar files
- Packages everything for immediate use

**Total time:** 2-3 minutes from request to complete deliverable.

---

## Why This Works Better Than Manual Research

### Manual Research (Old Way)
1. Google "AI meetups [city]" → 30 min
2. Check Meetup.com → 20 min
3. Check Eventbrite → 20 min
4. Find coworking spaces → 30 min
5. Look up key people on LinkedIn → 45 min
6. Organize into usable format → 60 min
7. Create calendar entries → 30 min
8. Figure out which events to prioritize → 30 min

**Total:** 4+ hours, scattered results, likely missed important communities

### Proximity Architect (New Way)
1. Tell Claude: "Find my AI community in [city]"
2. Wait 2-3 minutes
3. Done.

**Total:** 3 minutes, comprehensive results, actionable from day one

### What Makes It Better

- **Comprehensive** - Searches sources you'd never think to check
- **Smart consolidation** - Detects duplicate communities across platforms
- **Action-oriented** - Every section answers "what do I do next?"
- **Time-phased** - Shows you what to do in 48 hours, this week, this month, 90 days
- **Calendar integration** - Import events directly, no manual entry
- **Personalized** (if using Universal Expander) - Recommends based on your identity
- **Beautiful output** - Actually enjoyable to use, not a wall of text

---

## Edge Cases Handled

The skill gracefully handles:

### Traveling, But No Events During Your Dates

Instead of failing, it shows:
- Coworking spaces you can visit
- Key people to reach out to for spontaneous coffee
- Regular communities (even if meetings fall outside your dates)
- Options to expand date range or show full network

### Small Cities with Limited AI Communities

Shows:
- Nearby cities with active communities
- Virtual communities you can join
- How to start your own meetup
- Adjacent communities (tech, entrepreneurship, innovation hubs)

### Duplicate Communities

Uses smart heuristics:
- 80% name similarity + same location + same frequency = merge into one entry
- Lists both if details conflict, with note to verify
- Prioritizes the one with more detailed information

### Universal Expander Not Found

Proceeds without it—outputs full network without personalization. Never interrupts you to ask about it.

---

## Advanced Usage

### Research Specific Locations Only

```
proximity-architect coworking-only Miami
```

### Export to Different Location

```
Find AI community in Seattle, save to ~/Desktop/
```

### Force Travel Mode

```
proximity-architect travel Austin "March 15-20"
```

---

## What's Installed

```
~/.claude/skills/proximity-architect/
└── SKILL.md                # Skill definition for Claude
```

That's it. One file. No dependencies, no scripts, no virtual environments.

---

## Troubleshooting

**Skill not recognized:**

Make sure you're using Claude Code, not regular Claude. The skill system only works in Claude Code.

**Output folder not created:**

The skill creates folders based on your file system. If Obsidian vault path isn't detected, it saves to your current directory. You can always move the files afterward.

**Missing events or communities:**

The skill searches widely but may miss some. If you know of communities not included, you can manually add them to the generated document—it's just Markdown.

**Calendar files not importing:**

Make sure you're using a calendar app that supports .ics files (Google Calendar, Apple Calendar, Outlook all work). Some apps require you to open the file, others let you drag-and-drop.

**"No events found" in travel mode:**

This happens in smaller cities or when your dates don't align with meeting schedules. The skill will show you other options (expand dates, show full network, or deliver venues/contacts only).

---

## Privacy & Data

**What this skill accesses:**
- Public event listings (Meetup, Eventbrite, Luma, etc.)
- Public coworking space directories
- LinkedIn public profiles (no login required)
- Your Obsidian vault (only to detect Universal Expander document)

**What it does NOT access:**
- Your private calendar
- Your contacts
- Your location (you explicitly tell it which city)
- Any private or sensitive data

**Data storage:**
- All research results are saved locally on your machine
- Nothing is sent to external services except the public research queries
- No tracking, no analytics, no cloud storage

---

## Frequently Asked Questions

**Q: Do I need API keys?**
A: No. The skill uses Claude Code's built-in research capabilities.

**Q: Does this work outside the US?**
A: Yes! It works for any city worldwide where there's an AI community presence.

**Q: Can I customize the output format?**
A: Yes. The skill file (`SKILL.md`) contains the output template. Edit it to match your preferences.

**Q: What if I want to add my own communities?**
A: Just edit the generated Markdown file—it's yours to customize.

**Q: Can I share the output with others?**
A: Absolutely. Export to PDF, send the Markdown file, or share the calendar files.

**Q: Does this replace networking?**
A: No—it accelerates it. You still need to show up and talk to people. This just tells you exactly where to go and who to meet.

**Q: Will this work for industries beyond AI?**
A: The current version is optimized for AI communities, but you could modify the skill to search for other industries (crypto, fintech, biotech, etc.)

---

## Updates and Support

This is v1.0, released January 2026.

For questions or issues, you're on your own—this is a DIY skill distributed as-is. That said, it's been thoroughly tested and audited. If something breaks, check:
1. Is Claude Code working? (Test with other commands)
2. Is your Obsidian path correct? (Or just save to Desktop)
3. Did you run the installer? (Should take only 5 seconds)

---

## Credits

**Designed by:** Rich Schefren
**Built with:** Claude Code, Claude Sonnet 4.5
**Audited by:** Marcus Webb (Interaction Purist framework)
**Score:** 9.3/10 (Production Approved)

**Special thanks to:**
- The Deep Research skill (pattern inspiration)
- The AI community builders making these networks possible

---

## What You Should Do Next

1. **Install the skill** (takes 5 seconds)
2. **Run it for your city** (takes 3 minutes)
3. **Pick one event from "Next 48 Hours"**
4. **Show up and talk to three people**
5. **Repeat weekly**

Your tribe is waiting.

---

*Packaged by Rich Schefren - Strategic Profits*
*January 2026*
