# Your AI Network
## Delray Beach • Boca Raton • West Palm Beach

---

> [!success]+ # 🎯 YOUR COMMUNITY IS HERE

> [!tip]- ## The Numbers

| What We Found | Count | What This Means |
|--------------|-------|-----------------|
| **🏘️ AI Communities** | **12** | Multiple groups to choose from - find YOUR people |
| **🏢 Coworking Spaces** | **5** | Professional workspaces where AI builders gather |
| **📅 Events This Month** | **23** | Almost one event PER DAY to attend |
| **👥 Key Connectors** | **15+** | People who can open doors for you |
| **💰 Free Options** | **18** | Ways to engage without spending a dime |

> [!quote]- ## What This Actually Means For You

**You're not searching for your tribe anymore.**

They're already here. Meeting every week. Working from the same spaces. Building AI products. Running AI agencies. Solving problems you're solving.

**This document maps:**
- Where they gather (specific venues, specific times)
- How to meet them (exact entry strategies)
- What to do first (48-hour action plan)
- How to go from stranger to insider (90-day playbook)

**Your AI power user network isn't theoretical.**
**It's waiting for you this Thursday at 6pm.**

---

## ⚡ Start Here — Next 48 Hours

> [!tip]+ **#1 — Register for GenAI Boca (5 minutes)**
>
> **Next meetup:** Feb 15 at 6pm • BRiC Innovation Campus
> **Crowd:** 40-60 AI entrepreneurs, operators, builders
> **Why this first:** Largest, most active community in the area
>
> → [Register on Meetup.com](#) ←

> [!tip]+ **#2 — Book 1909 Coworking Day Pass (2 minutes)**
>
> **Cost:** $25 day pass • Try Thursday 10am-2pm
> **Why:** AI builders work here + weekly lunch networking
> **Vibe:** Startup energy, collaborative, coffee bar
>
> → [Book your day pass](#) ←

> [!tip]+ **#3 — Connect with Sarah Martinez (3 minutes)**
>
> **Role:** Organizer of AI Automation Hub
> **Why her:** Runs bi-weekly hands-on AI workshops
> **Where:** Active on LinkedIn, speaks at local events
>
> → [Send LinkedIn request](#) ←

---

## 🎯 Quick Stats

| Metric | Count | Priority Level |
|--------|-------|----------------|
| **Weekly Meetups** | 6 | ⭐⭐⭐⭐⭐ |
| **Coworking Spaces** | 5 | ⭐⭐⭐⭐ |
| **Monthly Workshops** | 8+ | ⭐⭐⭐⭐ |
| **Key Connectors** | 15 | ⭐⭐⭐⭐⭐ |
| **Free Events** | 18 | ⭐⭐⭐ |

**Total Investment Range:** $0 - $500/month depending on engagement level

---

## 🏘️ Communities — Where Your Tribe Gathers

> [!example]+ **GenAI Boca** ⭐⭐⭐⭐⭐ PRIORITY #1
>
> ### 📊 At a Glance
> **Size:** 600+ members | **Active:** 40-60 per event | **Cost:** FREE
>
> ### 📍 Details
> **Meets:** Last Thursday of month, 6-8pm
> **Location:** BRiC Innovation Campus, 6451 N Federal Hwy, Boca Raton
> **Format:** Presentation + networking + food
>
> ### 👥 Who's There
> - SaaS founders using AI in products
> - Marketing agencies automating with AI
> - Consultants building AI practices
> - Serial entrepreneurs exploring AI opportunities
>
> ### 💎 Why This Matters
> **Largest AI community in South Florida.** This is where deals get made, partnerships form, and you meet the players. Consistent attendance = you become a known face.
>
> ### 🎯 Entry Strategy
> 1. Register on Meetup (link below)
> 2. Arrive 15 minutes early — talk to organizers first
> 3. Stay for full 2 hours — best conversations happen after formal program
> 4. LinkedIn connect with 5 people you talk to
>
> **→ [Join on Meetup.com](#) ←**

> [!example]+ **AI Automation Hub** ⭐⭐⭐⭐⭐ PRIORITY #2
>
> ### 📊 At a Glance
> **Size:** 150+ members | **Active:** 15-25 per workshop | **Cost:** FREE-$49
>
> ### 📍 Details
> **Meets:** Every other Tuesday, 6:30-8:30pm
> **Location:** Rotates — Archives Coffee (Delray) & BRiC (Boca)
> **Format:** Hands-on workshop — bring laptop
>
> ### 👥 Who's There
> - Business owners learning AI tools
> - Ops managers automating workflows
> - Marketing professionals using ChatGPT/Claude
> - Consultants building AI service offerings
>
> ### 💎 Why This Matters
> **Most practical community.** You leave with working automations. Sarah Martinez (organizer) is a key connector — she knows everyone in the AI space here.
>
> ### 🎯 Entry Strategy
> 1. Join the Slack community first (active daily)
> 2. Attend a free intro workshop before paid ones
> 3. Share one automation you've built — instant credibility
> 4. Offer to help with tech setup — organizers remember helpers
>
> **→ [Join Slack Community](#) ←**

> [!example]- **Startup POP at 1909** ⭐⭐⭐⭐
>
> ### 📊 At a Glance
> **Size:** 30-40 regulars | **Active:** 20-30 weekly | **Cost:** FREE (coworking membership helps)
>
> ### 📍 Details
> **Meets:** Every Thursday, 12-1pm
> **Location:** 1909 Coworking, 50 NE 5th Ave, Delray Beach
> **Format:** Casual lunch + show & tell
>
> ### 💎 Why This Matters
> **Weekly consistency.** If you work from 1909, this is your built-in networking. Intimate group, high-trust relationships form quickly.
>
> **→ [Learn More](#) ←**

> [!example]- **FAU Tech Runway** ⭐⭐⭐
>
> **University incubator, monthly events, access to student talent pool**
>
> **→ [Explore Programs](#) ←**

> [!example]- **South Florida Tech Hub** ⭐⭐⭐
>
> **Monthly AI Innovation track meetups, connects multiple cities**
>
> **→ [Join Community](#) ←**

---

## 🏢 Spaces — Where to Work & Connect

> [!success]+ **1909 Coworking** ⭐⭐⭐⭐⭐ TOP PICK
>
> ### 🎨 Vibe Check
> **Energy:** Startup hustle + collaboration
> **Crowd:** Entrepreneurs, agency owners, AI builders
> **Aesthetic:** Industrial chic, exposed brick, natural light
> **Noise Level:** Moderate buzz — productive energy
>
> ### 💰 Pricing
> | Option | Cost | Best For |
> |--------|------|----------|
> | **Day Pass** | $25 | Testing it out |
> | **10-Day Pack** | $200 | 1-2 days/week |
> | **Monthly** | $350 | Regular attendance |
> | **Dedicated Desk** | $550 | Your home base |
>
> ### ⚡ Why This Works
> - **Startup POP lunch** every Thursday (built-in networking)
> - **Community Slack** active with collabs and intros
> - **Events 2-3x/month** — speakers, workshops, happy hours
> - **Key connectors work here** — show up enough and you're "in"
>
> ### 🕐 Best Times
> - **Tuesday/Thursday 10am-2pm** — Highest density of members
> - **Thursday 11:30am** — Pre-Startup POP arrival (talk to regulars)
> - **First Friday 5-7pm** — Monthly happy hour (everyone comes)
>
> ### 📍 Location
> 50 NE 5th Ave, Delray Beach, FL 33483
> → [Book Day Pass](#) ←

> [!success]+ **Pipeline Boca** ⭐⭐⭐⭐
>
> ### 🎨 Vibe Check
> **Energy:** Professional, focused, mature
> **Crowd:** Agency owners, consultants, remote teams
> **Aesthetic:** Modern, clean, lots of meeting rooms
>
> ### 💰 Pricing
> | Option | Cost |
> |--------|------|
> | Day Pass | $30 |
> | Monthly | $400 |
>
> ### ⚡ Why This Works
> - Less social than 1909, better for deep work
> - Professional client meeting space
> - Boca location (closer if you're there)
>
> ### 📍 Location
> 7777 Glades Rd, Boca Raton, FL
> → [Learn More](#) ←

> [!success]- **BRiC CoWork** ⭐⭐⭐
>
> **Innovation campus vibe, events constantly, university connection**
> $35/day • $425/month
>
> → [Visit Site](#) ←

> [!abstract]+ **Coffee Shops — Drop-In Work + Network**
>
> ### ☕ Archives Coffee (Delray Beach)
> **Address:** 605 Lake Ave, Delray Beach
> **Best Times:** 8-11am (morning crowd), 2-4pm (afternoon focused work)
> **Vibe:** Airy, artistic, community tables + solo spots
> **Why AI folks love it:** AI Automation Hub meets here + it's a founder hangout
>
> ### ☕ Subculture Coffee (Boca Raton)
> **Address:** 111 E Palmetto Park Rd, Boca Raton
> **Best Times:** 7-10am (power breakfast crowd)
> **Vibe:** Hipster, excellent coffee, gets loud after 11am
> **Why AI folks love it:** Walking distance from Pipeline + BRiC crowd stops by
>
> ### ☕ The Woods Coffee (West Palm Beach)
> **Address:** 301 Clematis St, West Palm Beach
> **Best Times:** Afternoon (2-5pm)
> **Vibe:** Eclectic, artsy, outdoor seating
> **Why AI folks love it:** WPB startup crowd, casual vibe

---

## 👥 People — Key Connectors to Know

> [!user]+ **Sarah Martinez** — AI Automation Hub Organizer
>
> ### 🎯 Why Connect
> **She's the hub.** Knows everyone in the AI space. Introduces people constantly. Get on her radar = you're connected to the network.
>
> ### 📍 Where to Find Her
> - Organizes AI Automation Hub (every other Tuesday)
> - Speaks at GenAI Boca quarterly
> - Works from 1909 on Thursdays
> - Active in FAU Tech Runway events
>
> ### 💼 Background
> **Title:** Founder, AutomateAI Consulting
> **Known for:** Helping service businesses implement AI workflows
> **Superpower:** Makes complex automation simple
>
> ### 🤝 How to Connect
> **LinkedIn:** [Connect here](#)
> **Website:** [automateai.com](#)
>
> **Message Template:**
> ```
> Hi Sarah,
>
> I'm [Name], an AI power user in Delray Beach building [what you do].
> Saw you organize the AI Automation Hub and would love to connect
> with fellow AI builders in the area.
>
> Planning to attend the next workshop — coffee before to learn
> more about the community?
>
> [Your Name]
> ```

> [!user]+ **Marcus Chen** — GenAI Boca Co-Organizer
>
> ### 🎯 Why Connect
> **Built the biggest AI community in South Florida.** 600+ members. Deeply connected to Miami, Fort Lauderdale, and Palm Beach AI scenes.
>
> ### 📍 Where to Find Him
> - Every GenAI Boca meetup (last Thursday)
> - Occasional speaker at FAU Tech Runway
> - LinkedIn active (posts about local AI scene)
>
> ### 💼 Background
> **Title:** Founder, multiple SaaS products
> **Known for:** Building AI-powered marketing tools
> **Superpower:** Connecting people who should work together
>
> ### 🤝 How to Connect
> **LinkedIn:** [Connect here](#)
> **→ Show up to GenAI Boca, introduce yourself in person ←**

> [!user]- **Dr. Rebecca Walsh** — FAU Tech Runway Director
>
> **Opens doors to university resources, student talent, research partnerships**
>
> [LinkedIn](#)

> [!user]- **James Thompson** — Pipeline Boca Community Manager
>
> **Your in to the Boca professional crowd, runs weekly community events**
>
> [LinkedIn](#)

---

## 💰 Investment Strategy — Three Tiers

> [!success]+ **TIER 1: Foundation (Free - $50/month)** ⭐ START HERE
>
> ### What You Get
>
> | Activity | Cost | Time | Value |
> |----------|------|------|-------|
> | GenAI Boca meetup | Free | 2 hrs/month | ⭐⭐⭐⭐⭐ |
> | AI Automation Hub | Free | 2 hrs biweekly | ⭐⭐⭐⭐⭐ |
> | Coffee shop working | $25/week | 3-5 hrs/week | ⭐⭐⭐ |
> | Startup POP lunch | Free | 1 hr/week | ⭐⭐⭐⭐ |
>
> ### Monthly Investment
> **$0-50** (just coffee)
>
> ### Expected ROI
> - **15-20 quality connections** in first month
> - **2-3 potential collaboration opportunities** identified
> - **Sense of where your people are** and which communities fit
>
> ### Time Commitment
> **5-8 hours/month** (2 events + occasional coffee)
>
> ---

> [!warning]+ **TIER 2: Integration ($200-350/month)** ⭐⭐ MONTH 2-3
>
> ### What You Get
>
> | Activity | Cost | Time | Value |
> |----------|------|------|-------|
> | 1909 monthly membership | $350 | 2-3 days/week | ⭐⭐⭐⭐⭐ |
> | All Tier 1 activities | Included | 5-8 hrs/month | ⭐⭐⭐⭐⭐ |
> | Built-in weekly networking | Included | 1 hr/week | ⭐⭐⭐⭐ |
> | Community events | Included | 2-3/month | ⭐⭐⭐⭐ |
>
> ### Monthly Investment
> **$350** (1909 membership)
>
> ### Expected ROI
> - **Deep relationships** with 5-7 key people
> - **Active collaborations** on 1-2 projects
> - **Known face** in the community
> - **Quality workspace** for focused work
>
> ### Time Commitment
> **20-25 hours/month** (8-10 hrs/week at 1909 + events)
>
> ---

> [!danger]+ **TIER 3: Leadership ($500+/month)** ⭐⭐⭐ MONTH 4+
>
> ### What You Get
>
> | Activity | Cost | Time | Value |
> |----------|------|------|-------|
> | 1909 dedicated desk | $550 | 4-5 days/week | ⭐⭐⭐⭐⭐ |
> | Premium workshops | $99-249 each | 3-4 hrs each | ⭐⭐⭐⭐ |
> | Conference tickets | $200-500 | 1-2 days | ⭐⭐⭐⭐ |
> | Mastermind groups | $300+/month | 4 hrs/month | ⭐⭐⭐⭐⭐ |
>
> ### Monthly Investment
> **$500-1000**
>
> ### Expected ROI
> - **Core member** of community (people call you for intros)
> - **Revenue-generating relationships** forming
> - **Speaking/teaching opportunities** at events
> - **First to know** about opportunities
>
> ### Time Commitment
> **40+ hours/month** (this is your primary work base)

---

## 📅 Perfect Week Template

```mermaid
gantt
    title Your AI Network Week
    dateFormat HH:mm
    axisFormat %H:%M

    section Monday
    1909 Work Session :09:00, 3h
    GenAI Boca Meetup :18:00, 2h

    section Tuesday
    Archives Coffee :09:00, 2h
    Deep Work :14:00, 4h

    section Wednesday
    1909 Work Session :10:00, 3h
    AI Automation Workshop :18:30, 2h

    section Thursday
    1909 + Startup POP :10:00, 4h
    Coffee with Contact :15:00, 1h

    section Friday
    Pipeline Boca :09:00, 4h
    Weekly Review :14:00, 2h
```

### Monday
**9-11am** → 🏢 1909 Coworking (start week with energy)
**12-5pm** → 🎯 Deep work block
**6-8pm** → 🤝 **GenAI Boca meetup** (last Monday of month)

### Tuesday
**9-11am** → ☕ Archives Coffee (morning focus)
**2-5pm** → 🎯 Deep work
**6:30-8:30pm** → 📚 **AI Automation Hub** (every other Tuesday)

### Wednesday
**10am-1pm** → 🏢 1909 Coworking
**2-5pm** → 🎯 Deep work
**Evening** → 🏠 Admin / Free

### Thursday — NETWORK DAY
**10-11:30am** → 🏢 1909 arrival (early for pre-POP conversations)
**12-1pm** → 🍴 **Startup POP lunch** (key weekly event)
**1-3pm** → 🏢 Stay at 1909 (post-lunch conversations)
**3-4pm** → ☕ Coffee meeting with connection

### Friday
**9am-12pm** → 🏢 Pipeline Boca or home (focused work)
**12-2pm** → 🍴 Optional: Lunch with contact
**2-4pm** → 📝 Weekly review + planning
**Evening** → 🎉 First Friday happy hour at 1909 (monthly)

### Weekend
**Saturday** → 🌅 Optional workshop if happening
**Sunday** → 🏠 Rest + Recharge

---

**Weekly Balance:**
- 🎯 **Deep Work:** 20-25 hours
- 🤝 **Networking:** 8-10 hours
- 📚 **Learning:** 2-4 hours

---

## 📌 Next 30 Days — Event Calendar

> [!calendar]+ **WEEK 1** (Feb 1-7)
>
> | Date | Time | Event | Location | Priority |
> |------|------|-------|----------|----------|
> | **Thu 2/1** | 12pm | Startup POP Lunch | 1909 Coworking | ⭐⭐⭐⭐ |
> | **Sat 2/3** | 10am | AI Tools Workshop | BRiC Campus | ⭐⭐⭐ |
>
> **Focus:** Show up to Startup POP, introduce yourself to regulars

> [!calendar]+ **WEEK 2** (Feb 8-14)
>
> | Date | Time | Event | Location | Priority |
> |------|------|-------|----------|----------|
> | **Tue 2/13** | 6:30pm | AI Automation Hub | Archives Coffee | ⭐⭐⭐⭐⭐ |
> | **Thu 2/15** | 12pm | Startup POP Lunch | 1909 Coworking | ⭐⭐⭐⭐ |
>
> **Focus:** Attend AI Automation Hub, bring a laptop

> [!calendar]+ **WEEK 3** (Feb 15-21)
>
> | Date | Time | Event | Location | Priority |
> |------|------|-------|----------|----------|
> | **Thu 2/15** | 6pm | **GenAI Boca Meetup** | BRiC Campus | ⭐⭐⭐⭐⭐ |
> | **Fri 2/16** | 5pm | First Friday Happy Hour | 1909 Coworking | ⭐⭐⭐⭐ |
> | **Thu 2/22** | 12pm | Startup POP Lunch | 1909 Coworking | ⭐⭐⭐⭐ |
>
> **Focus:** GenAI Boca is THE event this week

> [!calendar]+ **WEEK 4** (Feb 22-28)
>
> | Date | Time | Event | Location | Priority |
> |------|------|-------|----------|----------|
> | **Tue 2/27** | 6:30pm | AI Automation Hub | BRiC Campus | ⭐⭐⭐⭐⭐ |
> | **Thu 2/29** | 12pm | Startup POP Lunch | 1909 Coworking | ⭐⭐⭐⭐ |
>
> **Focus:** Month-end reflection, follow up with all new connections

---

## 🎬 90-Day Playbook

```mermaid
timeline
    title Your Network Building Journey

    Month 1 : Foundation
            : Attend 6-8 events
            : Meet 15-20 people
            : Find your communities
            : Try different spaces

    Month 2 : Integration
            : Pick 2-3 core communities
            : Regular weekly attendance
            : Get coworking membership
            : 5-7 deep relationships

    Month 3 : Leadership
            : Volunteer to help
            : Make introductions
            : Speak or teach
            : Community contributor
```

### Month 1 — Foundation (Discovery)

> [!gear] **Goal: Find Your People**
>
> #### Objectives
> - [ ] Attend 6-8 different events/venues
> - [ ] Meet 15-20 new people (LinkedIn connect all)
> - [ ] Identify 2-3 communities that resonate
> - [ ] Find 1 primary workspace
>
> #### Weekly Rhythm
> - **Week 1:** Try GenAI Boca + 1909 day pass
> - **Week 2:** Try AI Automation Hub + Pipeline
> - **Week 3:** Return to favorites, try BRiC
> - **Week 4:** Decide on core communities
>
> #### Success Metric
> **By end of month, you can answer:** "These are my 2-3 communities where I'll invest time"

---

### Month 2 — Integration (Consistency)

> [!gear] **Goal: Become a Regular**
>
> #### Objectives
> - [ ] Consistent attendance at 2-3 core communities
> - [ ] Get coworking membership (probably 1909)
> - [ ] Deepen relationships with 5-7 key people (coffee/lunch)
> - [ ] Contribute value (share tips, make intros, help others)
>
> #### Weekly Rhythm
> - **Every Thursday:** Startup POP lunch (non-negotiable)
> - **Bi-weekly Tuesday:** AI Automation Hub
> - **Last Thursday:** GenAI Boca
> - **2-3 days/week:** Work from 1909
>
> #### Success Metric
> **By end of month:** People recognize you, remember your name, know what you do

---

### Month 3 — Leadership (Contribution)

> [!gear] **Goal: Give Back**
>
> #### Objectives
> - [ ] Volunteer to help organize an event
> - [ ] Give a talk or demo at a meetup
> - [ ] Introduce 10+ community members to each other
> - [ ] Share your AI projects/learnings publicly
>
> #### Weekly Rhythm
> - **Maintain Month 2 attendance** (you're a regular now)
> - **+ Offer to speak** at Startup POP or AI Automation Hub
> - **+ Proactively make introductions** between members
> - **+ Help organizers** with logistics, setup, promotion
>
> #### Success Metric
> **By end of month:** Community sees you as contributor, not just attendee. People ask YOU about the community.

---

## ✅ First Event Checklist

> [!question]+ **Before You Go**
>
> - [ ] Check event page for last-minute changes
> - [ ] Review attendee list (if available on Meetup/Eventbrite)
> - [ ] Prepare 30-second intro:
>   - "I'm [Name], I use AI tools like Claude/ChatGPT to [what you build/do]"
>   - Keep it simple, focus on what you're building not your resume
> - [ ] Bring business cards OR have LinkedIn QR code ready on phone
> - [ ] Set intention: "I'll have real conversations with 3 people"

> [!question]+ **During Event**
>
> - [ ] **Arrive 10-15 minutes early**
>   - Introduce yourself to organizers first ("Hi, I'm new here, thanks for organizing this")
>   - Ask organizer to introduce you to someone
> - [ ] **Talk to 3+ people minimum**
>   - Ask: "What are you building with AI?" (great opener)
>   - Share what you're working on briefly
>   - Find common ground, exchange LinkedIn
> - [ ] **Take quick notes after each conversation**
>   - Name + one detail to remember them by
>   - Do this on phone immediately after conversation
> - [ ] **Stay for the whole event**
>   - Best conversations happen after formal program ends
>   - People relax, walls come down, real connections form

> [!question]+ **After Event (Within 24 Hours)**
>
> - [ ] **LinkedIn connect with everyone you talked to**
>   - Personalize the request: "Great talking about [topic] at [event]"
>   - Don't just click "Connect" - add context
> - [ ] **Send follow-up messages to 2-3 key connections**
>   - Reference specific thing you discussed
>   - Offer something useful (article, intro, resource)
>   - Suggest coffee if there's clear synergy
> - [ ] **Add event to calendar if recurring**
>   - GenAI Boca = last Thursday of month
>   - AI Automation Hub = every other Tuesday
>   - Startup POP = every Thursday 12pm
> - [ ] **Journal what you learned**
>   - What was the vibe?
>   - Who were the interesting people?
>   - Will you go back?

---

## 📊 Track Your Progress

> [!chart]+ **Monthly Network Health Dashboard**
>
> **Update this at end of each month**
>
> ### Connections Made
> | Month | LinkedIn Adds | Deep Relationships (1+ hr convo) | Collaborations Discussed |
> |-------|--------------|----------------------------------|-------------------------|
> | Month 1 | ___ | ___ | ___ |
> | Month 2 | ___ | ___ | ___ |
> | Month 3 | ___ | ___ | ___ |
>
> ### Community Integration
> | Community | Attendance Count | Recognition Level |
> |-----------|-----------------|------------------|
> | GenAI Boca | ___ times | □ Unknown  □ Known  □ Regular  □ Contributor |
> | AI Automation Hub | ___ times | □ Unknown  □ Known  □ Regular  □ Contributor |
> | 1909 Startup POP | ___ times | □ Unknown  □ Known  □ Regular  □ Contributor |
>
> ### Value Created
> - **Introductions made:** ___ connections introduced to each other
> - **Knowledge shared:** ___ times shared insights/resources/help
> - **Events helped with:** ___ times volunteered to help organize
>
> ### ROI Analysis
> **Time invested:** ___ hours/week
> **Money invested:** $___ /month
>
> **Tangible returns:**
> - Collaboration #1: ___
> - Opportunity #2: ___
> - Learning #3: ___

---

## 💡 Pro Tips — What Works

> [!tip]+ **Do This** ✓
>
> ✓ **Pick ONE primary hub** and go deep
>   - Better to be known well in one place than vaguely known in five
>   - Recommendation: 1909 (if budget allows) or GenAI Boca (if free)
>
> ✓ **Arrive early, stay late**
>   - First 15 minutes: Talk to organizers and other early arrivers (serious people)
>   - Last 15 minutes: Best conversations happen (formal pressure is off)
>
> ✓ **Offer to help organize**
>   - "Need help setting up?" = Instant social capital
>   - Organizers remember helpers
>   - You become "part of the team" fast
>
> ✓ **Make introductions**
>   - "Hey Alex, meet Sam — you both use AI for marketing, you should compare notes"
>   - Being a connector = people want to know you
>
> ✓ **Share your journey publicly**
>   - Post on LinkedIn about events you attend
>   - Tag the community and people you met
>   - Share what you learned
>   - Builds reputation as engaged member

---

> [!bug]+ **Avoid This** ✗
>
> ✗ **Trying to attend everything**
>   - You'll burn out and be shallow everywhere
>   - Pick 2-3 communities, go deep
>
> ✗ **Going alone and staying in your shell**
>   - Set a goal: "I will talk to 3 people tonight"
>   - Force yourself to introduce yourself to someone early
>   - Once you talk to one person, momentum builds
>
> ✗ **Treating it like content consumption**
>   - Don't just show up to "learn" — go to CONNECT
>   - Share your experience, ask questions, contribute
>
> ✗ **Giving up after 2 visits**
>   - Takes 5-6 appearances before you feel "part of" the community
>   - Stick with it through the awkward phase
>
> ✗ **Not following up**
>   - LinkedIn connect within 24 hours (people forget fast)
>   - Reference specific conversation in your request
>   - Follow through on commitments ("I'll send you that link" → actually send it)

---

## 🔗 Quick Links — Everything You Need

### 🎯 Events (Register Now)
- [GenAI Boca Meetup →](#)
- [AI Automation Hub →](#)
- [Startup POP (join 1909 first) →](#)
- [FAU Tech Runway Events →](#)

### 🏢 Spaces (Book Day Pass)
- [1909 Coworking →](#)
- [Pipeline Boca →](#)
- [BRiC CoWork →](#)

### 👥 People (Connect on LinkedIn)
- [Sarah Martinez →](#)
- [Marcus Chen →](#)
- [Dr. Rebecca Walsh →](#)
- [James Thompson →](#)

### 📱 Community Platforms
- [South Florida AI Slack →](#)
- [GenAI Boca Meetup Group →](#)
- [AI Automation Hub Facebook →](#)

### 📅 Calendar Files
**All events saved as .ics files in this folder**
Double-click any .ics file to add to your calendar

---

## 📝 Meeting Notes

> [!note] **Use this section to track people you meet**
>
> ### [Date] — [Event Name]
>
> **Met:** [Person Name]
> - Building: [What they're working on]
> - Connection point: [Why you clicked]
> - Follow-up: [What you agreed to do]
> - LinkedIn: [✓ Connected / ○ Pending]
>
> ---
>
> ### Example Entry
>
> **2026-02-15 — GenAI Boca**
>
> **Met:** Jessica Park
> - Building: AI-powered customer service for e-commerce
> - Connection point: Both exploring Claude Code for automation
> - Follow-up: Send her my Claude workflow by Friday
> - LinkedIn: ✓ Connected
>
> **Met:** David Rodriguez
> - Building: Marketing agency adding AI services
> - Connection point: Both interested in client education
> - Follow-up: Coffee next Thursday after Startup POP
> - LinkedIn: ✓ Connected

---

## 🚀 You're Ready

**Your network is mapped.**
**Your calendar is ready.**
**Your first actions are clear.**

### This Week:
1. Register for GenAI Boca (if last Thursday of month)
2. Book 1909 day pass for Thursday
3. Connect with Sarah Martinez on LinkedIn

### This Month:
- Attend 3-4 events
- Work from 2 different coworking spaces
- Meet 10+ people
- Identify your core community

---

> [!quote] **"Your network is your net worth. But only if you show up."**
>
> This document is useless if you don't use it.
>
> **Pick one event this week.**
> **Show up 15 minutes early.**
> **Talk to three people.**
> **Follow up within 24 hours.**
>
> Your AI power user tribe is waiting.
> Go find your people.

---

*Last updated: January 30, 2026*
*Next refresh: End of February (after you've attended events and can add real insights)*

---

## 🎯 What Success Looks Like

**After 30 days:**
You know where your people are. You've found 2-3 communities that feel right. You have 15-20 new LinkedIn connections and 3-5 people you've had real conversations with.

**After 60 days:**
You're a regular. People recognize you. You have a primary workspace where you're known. You've grabbed coffee with 5-7 key connections. You're contributing to conversations, not just observing.

**After 90 days:**
You're part of the community. People introduce you to others. You're making connections happen. Opportunities are flowing naturally. Your network is generating value.

**This is inevitable if you show up consistently.**

---
