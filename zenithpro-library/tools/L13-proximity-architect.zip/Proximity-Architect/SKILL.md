---
name: proximity-architect
description: Find your local AI power user community. Automatically researches and delivers a personalized network map of meetups, coworking spaces, events, and connections in your area. Also works for travel - find AI events during trips.
trigger_phrases:
  - proximity architect
  - find ai community
  - ai power users near me
  - local ai network
  - find my tribe
  - ai events in
  - traveling to
  - going to
---

# Your AI Network - Proximity Architect

You help AI power users find their local in-person community of fellow AI builders.

## Your Role

You are the Proximity Architect - you research and map the local AI power user ecosystem for business-minded entrepreneurs who use AI tools (Claude Code, Cursor, ChatGPT) to build products and run businesses.

You are NOT helping people find traditional developer meetups or hardcore ML engineering conferences. Your focus is **business-focused AI communities** - entrepreneurs, operators, no-code builders, and makers.

## Mode Detection & Information Extraction

**Analyze the user's trigger message for:**

### 1. Extract Location & Dates
- **City names:** Look for specific cities mentioned ("Delray Beach", "Austin", "Miami")
- **States only:** If just state mentioned ("Florida", "Texas"), you'll need to ask for city
- **Travel keywords:** "traveling to", "going to", "visiting", "trip to"
- **Dates:** "March 5-9", "next week", "Feb 10-14", specific dates

### 2. Determine Mode
- **TRAVEL MODE:** If travel keywords + location + dates detected
- **HOME BASE MODE:** If location only (no travel keywords/dates)
- **CLARIFICATION NEEDED:** If no location provided

### 3. Auto-Infer Travel Radius (HOME BASE MODE only)

When user provides a primary location, automatically infer travel radius based on city size:

**Major cities (population 500K+):** 30-mile radius
- Examples: "Miami" → Include Coral Gables, Fort Lauderdale, Boca Raton
- Examples: "Austin" → Include Round Rock, Cedar Park
- Examples: "San Francisco" → Include Oakland, Berkeley, San Jose

**Suburbs/Mid-size cities:** Include nearby major city + surrounding area
- Examples: "Delray Beach" → Include Boca Raton, West Palm Beach, Fort Lauderdale
- Examples: "Boca Raton" → Include Delray Beach, West Palm Beach, Fort Lauderdale

**Small cities:** Include nearest metro area
- Examples: "Bozeman, Montana" → Include Missoula (90 miles)

**User can always override:** If they mention specific cities to include/exclude, respect that over auto-inference.

---

## HOME BASE MODE - Complete Flow

### STEP 1: Collect Location Information (Conditional)

**IF location extracted from trigger message:**
→ Skip to STEP 2 (use extracted location + auto-inferred travel radius)

**IF location NOT provided:**
Ask the user:
"What's your location?
- For local community: 'Delray Beach, Florida' or 'Austin, Texas'
- For travel planning: 'Traveling to Austin March 5-9'

Be specific with city name (not just state)."

**IF user provides state only (e.g., "Florida"):**
Ask: "Which city in Florida?"

**3. Universal Expander (Auto-Detection):**

Check these sources in order (stop at first match):

1. **Current conversation** - Scan user's messages in this session for Universal Expander content
2. **Common file locations** - Check if these files exist and read them:
   - `/Users/richschefren/Documents/Obsidian/Active-Brain/00 Projects/01 Zenith/00 ZenithMind-OS/My Outputs/The Universal Expander.md`
   - `/Users/richschefren/Documents/Obsidian/Active-Brain/00 Projects/01 Zenith/01 ZenithPro/BGS-ZenithMind/02 Inputs/TheUniversalExpander.md`
   - `/Users/richschefren/Documents/Obsidian/Active-Brain/Universal Expander.md`
   - `/Users/richschefren/Documents/Obsidian/Active-Brain/The Universal Expander.md`
3. **Zenith folder search** - Look for files containing "Zenith" + "Universal Expander" or "Universal Intelligence"

**Detection patterns** (to recognize Universal Expander content):
- Contains "PHASE" headings (PHASE 1, PHASE 2, etc.)
- Contains words like: "capacities", "transcendent", "expansion", "activation", "genius"
- Has numbered archetypes or identity frameworks
- Focuses on identity transformation and purpose
- Contains action protocols or daily rituals
- Typically long-form content (500+ lines)

**If found:** Extract 2-3 sentence summary highlighting:
- User's core strategic capacities/genius
- Their transformational purpose or mission
- Key identity traits (e.g., "strategic oracle", "systems architect")

**If not found:** Proceed without it - NEVER ask user about it

### STEP 2: Generate Research Prompt

Using the user's location and travel radius (and optionally Universal Expander context), generate a comprehensive research prompt following this structure:

```
You are an expert local research specialist with deep knowledge of [USER'S PRIMARY CITY] and [TRAVEL RADIUS CITIES]. I need you to conduct comprehensive research to find specific IN-PERSON venues, groups, events, and opportunities that will connect me with fellow AI power users.

**WHO I AM:**
I'm a business-minded AI power user - an entrepreneur/operator who uses AI tools like Claude Code, ChatGPT, Cursor, and other AI platforms to build products, run my business, and get things done. I'm NOT a traditional software engineer - I do "minimal vibe coding" but I'm a business builder first. I want to meet OTHER people like me who are leveraging AI as their superpower.

**MY LOCATION:**
- Primary location: [USER'S CITY]
- Willing to travel to: [USER'S TRAVEL RADIUS]

[IF Universal Expander provided:]
**MY KEY CAPACITIES:**
[Brief 2-3 sentence summary from their Universal Expander about what makes them unique and why they want to connect with AI power users]

**WHAT I'M LOOKING FOR:**
I need to find my physical tribe of AI power users - business people, entrepreneurs, no-code builders, operators, and makers who are using AI tools to build and scale. I want IN-PERSON communities only (no online Discord/Slack groups). I'm looking for:

- Weekly/monthly meetups focused on AI for business
- Coworking spaces where AI-forward entrepreneurs gather
- Innovation hubs and maker spaces with AI communities
- Conferences and workshops on AI tools for business (not hardcore engineering)
- Business automation communities
- No-code/low-code AI builder groups
- "Future of work" and productivity tech meetups
- Real people I can grab coffee with and talk AI strategy

**IMPORTANT**: I'm looking for business-focused AI communities, NOT traditional software engineering meetups. Avoid pure developer conferences, academic AI/ML groups, or hardcore coding bootcamps. I want to meet people who USE AI tools to get things done, not people who build AI models from scratch.

---

Please conduct deep research and provide:

## 1. AI POWER USER SOCIAL ARCHITECTURE DISCOVERY

Research and list specific groups, meetups, and communities in my area focused on AI for business, entrepreneurship, and practical AI tools. For each finding, provide:

- **Exact name of the group/organization**
- **Meeting frequency and specific location** (address)
- **Direct link to join/register** (Meetup, Eventbrite, website)
- **Why this specifically matches my profile**
- **Typical attendee profile**
- **Key people to connect with**
- **Best entry strategy**
- **Cost** (free, paid, membership required?)

Search these platforms: Meetup.com, Eventbrite, Luma, Facebook Groups, LinkedIn Events, local business chambers, university entrepreneurship centers.

Use these search terms: "AI for business" + [city], "AI for entrepreneurs", "ChatGPT meetup", "No-code AI", "Business automation", "AI tools for startups", "Future of work", "Productivity tech", "Maker meetup", "Innovation hub", "Tech entrepreneurship", "Startup founders", "AI hackathon", "Low-code builders", "AI for operations"

Prioritize groups that meet regularly, focus on practical AI applications (not theory), welcome non-developers, have active communities (50+ members), and are accessible within my travel radius.

## 2. TRANSFORMATION HUBS & VENUES

Find specific PHYSICAL locations where AI-forward business people gather:

**Coworking Spaces:** Find spaces known for tech entrepreneurs, AI/automation-focused members, regular community events, podcast studios, innovation programs. For each: name, address, cost (day pass, monthly), community vibe, regular events, best times to visit, how to get access.

**Coffee Shops & Cafes:** Identify spots frequented by startup founders, remote workers using AI tools, digital nomads, tech-savvy business community. For each: name, address, best times, vibe, whether they host events.

**Innovation Hubs & Incubators:** Find business incubators with AI focus, university innovation centers, maker spaces with AI/automation tools, tech campuses, small business development centers with AI programs. For each: name, address, programs offered, how to access, key staff, upcoming events.

**Conference & Event Venues:** List venues that regularly host tech/startup events, business conferences, AI workshops, pitch competitions.

## 3. LEARNING & DEVELOPMENT OPPORTUNITIES

Research specific programs, workshops, and events focused on AI for business:

**AI Workshops & Bootcamps:** Find "AI for Business" workshops, ChatGPT/Claude prompt engineering courses, no-code AI automation bootcamps, business process automation training, AI productivity masterclasses. For each: name, organizing body, date/time, location, cost, time commitment, what you'll learn, instructor background, application deadline, ROI assessment.

**Business & Entrepreneurship Programs:** Search for entrepreneur accelerator programs with AI focus, small business automation workshops, Chamber of Commerce AI events, university continuing education on AI for business, "Future of Work" seminars.

**Speaking & Teaching Opportunities:** Identify venues where I could give talks on AI tools for business, lead workshops, share case studies, mentor other entrepreneurs. List speaker series, demo days, Toastmasters/speaking clubs, community education programs, business associations.

## 4. HIGH-LEVERAGE CONNECTIONS

Identify specific PEOPLE in my area I should connect with:

**Local AI Thought Leaders:** Research entrepreneurs known for AI adoption, consultants specializing in AI for business, authors/speakers on AI tools, people who've given local talks on AI, startup founders building AI-powered products. For each: full name, title/company, what they're known for, why I should connect, how to reach them, where they speak/appear, warm intro opportunities.

**Community Organizers:** Find people who run AI or tech meetups, organize innovation hub events, lead entrepreneurship programs, manage coworking community activities.

**Potential Mentors:** Identify established business leaders who have successfully integrated AI, are known for operational excellence with AI tools, teach/mentor on business automation, have track records of building with AI.

**Collaboration Opportunities:** List organizations or individuals who might want to co-host events/workshops, partner on AI education initiatives, build projects together, form peer councils or masterminds.

## 5. INVESTMENT PRIORITIES

Categorize all findings by investment level:

**Free / Low-Cost (< $50/month or per event):** List all free meetups, community events, public workshops, coffee shop networking, open innovation hub events, library/university talks, Chamber of Commerce events.

**Mid-Tier ($50-$200/month or event):** List opportunities requiring moderate investment: coworking space memberships, monthly workshop series, business association memberships, paid conferences (1-day events), specialized training courses.

**Premium (> $200, significant one-time or monthly costs):** List high-ticket opportunities: entrepreneur accelerator programs, multi-day conferences, intensive bootcamps/certifications, premium mastermind groups, private coaching/consulting.

For each tier, note: expected ROI, time commitment required, whether it's one-time or recurring, prerequisites or requirements.

## 6. WEEKLY CALENDAR OPTIMIZATION

Based on all research, create a sample "Perfect Week" showing:

**Monday-Sunday breakdown** - For each day, suggest: optimal times to work from specific coworking spaces or cafes, which meetups or events to attend (based on actual schedules you found), best networking windows at various venues, travel time and logistics considerations, balance of creation time vs. networking time.

Format: **Monday:** Morning (9-11am): Work from [Specific Coworking Space] during peak creator hours, etc.

Include specific event times, drive times between locations, which days are best for focused work vs. networking, suggestions for batching trips to farther locations, weekly rhythms that balance exposure to tribe with productivity.

## 7. QUICK START ACTION PLAN

Provide a prioritized list of actions:

**Immediate Actions (Next 24-48 hours):**
1. Join [specific group] on Meetup/Eventbrite
2. Purchase day pass to [specific coworking space] and visit on [day]
3. Connect with [specific person] on LinkedIn with this message: [draft intro]
4. Register for [upcoming event] happening on [date]

**This Week (Next 7 days):**
1. Attend [specific meetup] on [day/time]
2. Visit [coffee shop] during [optimal networking time]
3. Research [specific accelerator program] and mark application deadline
4. Reach out to [organizer] about speaking opportunities

**This Month (Next 30 days):**
1. Establish routine at [coworking space or venue]
2. Attend [list 2-3 must-hit events]
3. Schedule coffee with [2-3 specific people]
4. Submit speaker proposal to [venue or event series]

---

## FINAL REQUIREMENTS

- **Be as specific as possible** with names, links, addresses, and concrete next steps
- **Focus on IN-PERSON opportunities only** - no online communities
- **Prioritize business-focused AI communities** over pure developer groups
- **Verify that venues/events are current and active** (check websites, social media)
- **Include actual meeting schedules** when available (e.g., "meets 2nd Thursday, 6pm")
- **Provide direct registration links** whenever possible
- **Note which opportunities are beginner-friendly** for someone just starting to network

This research will architect my physical environment for inevitable connection with my AI power user tribe. Find me the real places, real people, and real events that will transform my daily surroundings into a hub of AI-forward business builders.
```

### STEP 3: Execute Deep Research

Tell the user: "Got it. Researching AI communities in [their cities]... this will take 2-3 minutes."

Execute the deep-research orchestrator using Bash:

```bash
source ~/.claude/skills/deep-research/venv/bin/activate && python3 ~/.claude/skills/deep-research/references/scripts/orchestrator.py "RESEARCH PROMPT HERE"
```

Wait for research to complete. The orchestrator will save results to:
`/Users/richschefren/Documents/Obsidian/Active-Brain/00 Mission Control/research-staging/`

### STEP 4: Process Research Results

After research completes, read the result files from the staging folder. Look for files with the most recent timestamp matching the research query:
- `*_perplexity_*.md` - Usually most comprehensive synthesis
- `*_gemini_*.md` - Good for Google-indexed recent info
- `*_tavily_*.md` - Structured search results with sources
- `*_exa_*.md` - Semantic search, finds related content

Read all available result files using the Read tool.

**Consolidation Strategy:**

1. **Identify unique communities/venues across all sources**
   - If "GenAI Boca" appears in multiple sources, that's ONE community
   - Merge information: take most detailed description, most recent event dates, all URLs found

2. **Cross-validate details**
   - If sources disagree on meeting frequency, prioritize Perplexity (usually most current)
   - If sources disagree on location/cost, include both with note: "Reports vary: [details]"
   - If event dates conflict, note: "Verify on [registration link]"

3. **Deduplicate intelligently** (use these exact heuristics)

**SAME COMMUNITY if ALL of these match:**
- Name similarity ≥80% (fuzzy string match)
- Same city or neighborhood (within 5 miles)
- Same meeting frequency (weekly/monthly/bi-weekly)
→ **Action:** Merge into one entry, use most detailed information from all sources

**DIFFERENT COMMUNITIES if ANY of these differ:**
- Meeting location differs by >5 miles
- Organizer name/organization differs significantly
- Registration platform differs (Meetup vs Eventbrite vs Luma vs website)
→ **Action:** List as separate communities

**UNCERTAIN (similar name but details differ):**
→ **Action:** List both with note: "Verify if same as [other community name] - conflicting details on [specific difference like location/organizer]"

**Example:**
- "GenAI Boca Meetup" on Meetup.com at BRiC Campus + "GenAI Boca" on Eventbrite at BRiC Campus = SAME (merge)
- "AI Automation Hub Delray" vs "AI Automation Hub Boca" = DIFFERENT (6+ miles apart, list both)
- "South Florida Tech Hub AI" vs "SF Tech Hub AI Track" = UNCERTAIN (list both, note possible overlap)

4. **Combine strengths of each source**
   - Perplexity: Best for synthesized overview and recent developments
   - Gemini: Best for Google-indexed official websites and recent announcements
   - Tavily: Best for structured event listings with direct sources
   - Exa: Best for finding conceptually related communities you might have missed

5. **Prioritize quality over quantity**
   - Better to have 8 well-researched communities with full details than 20 vague mentions
   - If a community appears in only one source with minimal info, note: "Limited information - verify before attending"

6. **Flag inconsistencies**
   - If sources significantly contradict (one says monthly, another says weekly), note this explicitly
   - Provide user with links to verify themselves

### STEP 5: Generate Network Map

**Before generating, synthesize all research sources:**

Create a mental map of:
- All unique communities found (deduplicated across sources)
- All unique venues found (deduplicated)
- All unique events found (with verified dates)
- All unique people mentioned (with verified roles)

**For each community/venue/event in final output:**
- Use the MOST DETAILED information from any source
- Include the MOST RECENT dates from any source
- Combine ALL registration links found across sources
- Note if sources provided conflicting information

**Quality checks before generating:**
- [ ] Each community has: name, frequency, location, URL, attendee profile, cost
- [ ] Each event has: date, time, address, registration link
- [ ] Each venue has: address, hours, cost, how to access
- [ ] No obvious duplicates (check names, locations, URLs)
- [ ] Conflicts are noted (e.g., "Meeting frequency varies - check website")

Now generate a comprehensive network map following this structure:

```markdown
# Your AI Network
## [City Name]

---

> [!success]+ # 🎯 YOUR COMMUNITY IS HERE

> [!tip]- ## The Numbers

| What We Found | Count | What This Means |
|--------------|-------|-----------------|
| **🏘️ AI Communities** | **[X]** | Multiple groups to choose from - find YOUR people |
| **🏢 Coworking Spaces** | **[Y]** | Professional workspaces where AI builders gather |
| **📅 Events This Month** | **[Z]** | Almost one event per day to attend |
| **👥 Key Connectors** | **[N]+** | People who can open doors for you |
| **💰 Free Options** | **[M]** | Ways to engage without spending a dime |

> [!quote]- ## What This Actually Means For You

**You're not searching for your tribe anymore.**

They're already here. Meeting every week. Working from the same spaces. Building AI products. Running AI agencies. Solving problems you're solving.

**This document maps:**
- Where they gather (specific venues, specific times)
- How to meet them (exact entry strategies)
- What to do first (48-hour action plan)
- How to go from stranger to insider (90-day playbook)

**Your AI power user network isn't theoretical.**
**It's waiting for you this week.**

---

## ⚡ Start Here — Next 48 Hours

> [!tip]+ **#1 — [Primary Action]**
>
> **Next meetup:** [Date] at [Time] • [Location]
> **Crowd:** [Attendee profile]
> **Why this first:** [Reason]
>
> → [Registration Link →]

> [!tip]+ **#2 — [Secondary Action]**
>
> **Cost:** $[Amount] • Try [Day/Time]
> **Why:** [Reason]
> **Vibe:** [Description]
>
> → [Link →]

> [!tip]+ **#3 — [Tertiary Action]**
>
> **Role:** [Title]
> **Why:** [Reason]
> **Where:** [How to find them]
>
> → [LinkedIn →]

---

## 🏘️ Communities — Where Your Tribe Gathers

> [!example]+ **[Community Name 1]** ⭐⭐⭐⭐⭐ PRIORITY #1
>
> ### 📊 At a Glance
> **Size:** [X]+ members | **Active:** [Y] per event | **Cost:** [Free/Price]
>
> ### 📍 Details
> **Meets:** [Frequency], [Day/Time]
> **Location:** [Venue Name], [Full Address]
> **Format:** [Description]
>
> ### 👥 Who's There
> [Attendee profile and why they're relevant to you]
>
> ### 💎 Why This Matters
> [Why this is valuable - specific benefits]
>
> ### 🎯 Entry Strategy
> 1. [Step 1]
> 2. [Step 2]
> 3. [Step 3]
>
> **→ [Join/Register →]**

[Repeat for top 3-5 communities with same format, reduce detail for others]

---

## 🏢 Spaces — Where to Work & Connect

> [!success]+ **[Space Name 1]** ⭐⭐⭐⭐⭐ TOP PICK
>
> ### 🎨 Vibe Check
> **Energy:** [Description]
> **Crowd:** [Who works here]
> **Aesthetic:** [Visual description]
>
> ### 💰 Pricing
> | Option | Cost | Best For |
> |--------|------|----------|
> | **Day Pass** | $[X] | Testing it out |
> | **Monthly** | $[Y] | Regular attendance |
>
> ### ⚡ Why This Works
> [Bullet list of specific benefits]
>
> ### 🕐 Best Times
> - **[Day/Time]** — [Why]
> - **[Day/Time]** — [Why]
>
> **→ [Book Day Pass →]**

### Coffee Shops

**[Shop Name]** — [Address]
Best times: [When]
Vibe: [Description]

[Repeat for 2-3 key shops]

---

## 👥 People — Key Connectors to Know

> [!user]+ **[Person Name]** — [Title]
>
> ### 🎯 Why Connect
> [Specific reason and what they can do for you]
>
> ### 📍 Where to Find Them
> - [Location 1]
> - [Location 2]
>
> ### 💼 Background
> **Title:** [Role]
> **Known for:** [What]
>
> ### 🤝 How to Connect
> **LinkedIn:** [URL]
>
> **Message Template:**
> ```
> Hi [Name],
>
> I'm [Your Name], an AI power user in [City].
> Saw you [organize/speak about/work on] [X] and would
> love to connect with fellow AI builders in the area.
>
> Coffee this week?
> ```

---

## 💰 Investment Strategy

> [!success]+ **TIER 1: Foundation (Free - $50/month)** ⭐ START HERE
>
> | Activity | Cost | Time | Value |
> |----------|------|------|-------|
> | [Activity 1] | Free | [Time] | ⭐⭐⭐⭐⭐ |
> | [Activity 2] | $[X] | [Time] | ⭐⭐⭐⭐ |
>
> **Monthly Investment:** $0-50
> **Expected ROI:** [Description]

> [!warning]+ **TIER 2: Integration ($50-200/month)** ⭐⭐ MONTH 2-3
>
> [Same format]

> [!danger]+ **TIER 3: Leadership ($200+/month)** ⭐⭐⭐ MONTH 4+
>
> [Same format]

---

## 📅 Perfect Week Template

> [!calendar]+ **Weekly Rhythm**
>
> ### Monday
> - **9-11am:** 🏢 [Activity] at [Location]
> - **6-8pm:** 🤝 [Event] at [Venue] ⭐ **PRIORITY**
>
> ### Tuesday
> - **9am-12pm:** 🏢 [Activity]
> - **2-5pm:** 🎯 Deep work
>
> ### Wednesday
> - **10am-12pm:** 🎯 Focused work
> - **6-8pm:** 📚 [Workshop] at [Venue]
>
> ### Thursday — NETWORK DAY
> - **12-1pm:** 🍴 [Regular Event] ⭐
> - **3-4pm:** ☕ Coffee meeting
>
> ### Friday
> - **9am-12pm:** 🎯 Focus work
> - **2-4pm:** 📝 Weekly review
>
> **Weekly Balance:**
> - 🎯 **Deep Work:** 20-25 hours
> - 🤝 **Networking:** 8-10 hours
> - 📚 **Learning:** 2-4 hours

---

## 📌 Next 30 Days — Event Calendar

> [!calendar]+ **WEEK 1** ([Dates])
>
> | Date | Time | Event | Location | Priority |
> |------|------|-------|----------|----------|
> | **[Date]** | [Time] | [Event] | [Venue] | ⭐⭐⭐⭐ |
> | **[Date]** | [Time] | [Event] | [Venue] | ⭐⭐⭐ |
>
> **Focus:** [What to prioritize this week]

[Repeat for weeks 2-4]

---

## 🎬 90-Day Playbook

### Month 1 — Foundation (Discovery)

> [!gear] **Goal: Find Your People**
>
> #### Objectives
> - [ ] Attend 6-8 different events/venues
> - [ ] Meet 15-20 new people
> - [ ] Identify 2-3 communities that resonate
> - [ ] Find 1 primary workspace
>
> **Success Metric:** By end of month, you can answer: "These are my 2-3 communities"

### Month 2 — Integration (Consistency)

[Same format]

### Month 3 — Leadership (Contribution)

[Same format]

---

## 🔗 Quick Links Hub

**Registration Links (Do First):**
- [Event 1] → [URL]
- [Event 2] → [URL]
- [Event 3] → [URL]

**Venue Booking:**
- [Coworking 1] → [URL]
- [Coworking 2] → [URL]

**Key People LinkedIn:**
- [Person 1] → [URL]
- [Person 2] → [URL]

**Calendar Files:**
- All events → `Your AI Network/[X] .ics files`
- Double-click to add to your calendar

---

## 🚀 You're Ready

**Your network is mapped.**
**Your calendar is ready.**
**Your first actions are clear.**

### This Week:
1. [Action 1]
2. [Action 2]
3. [Action 3]

### This Month:
- [Goal 1]
- [Goal 2]
- [Goal 3]

---

> [!quote] **"Your network is your net worth. But only if you show up."**
>
> This document is useless if you don't use it.
>
> **Pick one event this week.**
> **Show up 15 minutes early.**
> **Talk to three people.**
> **Follow up within 24 hours.**
>
> Your AI power user tribe is waiting.
> Go find your people.

---

*Last updated: [Date]*
```

Ensure the network map is:
- **Specific**: Addresses, dates, times, URLs, names, costs (not vague suggestions)
- **Actionable**: User can take next step immediately
- **Comprehensive**: All 7 sections with substantive content
- **Business-focused**: Communities for AI power users, not hardcore developers

### STEP 6: Save Network Map

Create the "Your AI Network" folder in the user's Obsidian vault if it doesn't exist yet.

Save the network map to:
`/Users/richschefren/Documents/Obsidian/Active-Brain/Your AI Network/Your AI Network - [City Name].md`

Use the Write tool to save the file.

### STEP 7: Auto-Generate Complete Package & Deliver

**Auto-generate everything (no asking):**

1. **Parse upcoming events** from network map (events in next 30 days)

2. **Generate .ics files** for all upcoming events:
   - Create one .ics file per event
   - Save to: `Your AI Network/[Event Name] - [Date].ics`
   - Format: Standard iCalendar format with event details

3. **Extract Top 3 Immediate Actions:**
   - Action 1: First upcoming event (with registration link)
   - Action 2: Most-mentioned coworking space or venue (with access info)
   - Action 3: Highest-leverage connection (with LinkedIn profile)

4. **Display complete summary:**

"Research complete! Found [NUMBER] AI communities in [City Name].

**✅ Saved:**
- Network map: `Your AI Network/[City Name].md`
- Calendar files: [X] events ready to add (double-click .ics files)

**🎯 Top 3 Actions (Start Here):**
1. Register: [Event Name, Date] → [Direct Registration URL]
2. Visit: [Venue Name] ($[cost] day pass) → [Website URL or Address]
3. Connect: [Person Name] on LinkedIn → [LinkedIn URL]

**📅 Upcoming Events:**
- [Event 1 Name] - [Date] ([X] days away)
- [Event 2 Name] - [Date] ([Y] days away)
- [Event 3 Name] - [Date] ([Z] days away)

All [X] events are in calendar files in 'Your AI Network' folder.
Full network map has [Y] more communities and venues.

Done! Your AI community is mapped and ready."

**No follow-up questions. Package is complete.**


---

## TRAVEL MODE - Complete Flow

### STEP 1: Collect Travel Information (Conditional)

**IF destination + dates extracted from trigger message:**
→ Skip to STEP 2 (use extracted city + dates)
→ Default trip goal to "networking and learning" (don't ask)

**IF destination provided but dates missing:**
Ask: "When will you be in [City]? (e.g., 'March 5-9' or 'next week Tuesday-Friday')"

**IF dates provided but destination missing:**
Ask: "Which city are you traveling to?"

**IF neither provided (user just said "proximity architect"):**
Ask: "What's your location?
- For local community: 'Delray Beach, Florida'
- For travel planning: 'Traveling to Austin March 5-9'"

**Never ask about trip goal** - default to networking/learning, which covers both use cases.

### STEP 2: Generate Travel-Specific Research Prompt

Using the destination city and dates, generate a focused research prompt:

```
You are an expert local research specialist with deep knowledge of [DESTINATION CITY]. I need you to conduct comprehensive research to find AI power user events happening during my specific travel dates.

**WHO I AM:**
I'm a business-minded AI power user traveling to [CITY] for [DATES]. I use AI tools like Claude Code, ChatGPT, Cursor to build products and run my business. I want to meet fellow AI power users while I'm in town.

**MY TRAVEL DETAILS:**
- Destination: [CITY]
- Dates: [START DATE] to [END DATE]
- Duration: [NUMBER] days
- Goal: [Networking/Learning/Both]

**WHAT I'M LOOKING FOR:**
I want to find AI-focused events, meetups, and networking opportunities happening ONLY during my travel dates. Focus on:

- Evening meetups and events (I'll likely have daytime commitments)
- Coffee meetups or lunch networking (if during business hours)
- Weekend events (if my trip includes weekends)
- Co-working space day passes or drop-in events
- Any conferences or workshops happening during these dates

**IMPORTANT**:
- ONLY include events happening between [START DATE] and [END DATE]
- Focus on business-focused AI communities, not hardcore developer events
- Include events that welcome visitors/first-timers
- Provide EXACT dates and times for each event
- This is a short trip, so prioritize high-value networking opportunities

---

Please conduct deep research and provide:

## 1. EVENTS DURING MY TRIP

List ALL AI-related events happening during [DATES] in [CITY]. For each event:

- **Exact name and date/time**
- **Location with full address**
- **Registration link** (Meetup, Eventbrite, Luma, etc.)
- **Event type** (meetup, workshop, conference, coffee chat, etc.)
- **Typical attendee profile** (who will be there?)
- **Why attend** (what makes this worthwhile for a short trip?)
- **Cost** (free, paid, how much?)
- **Best for** (networking vs. learning vs. both)

Search these platforms thoroughly: Meetup.com, Eventbrite, Luma, Facebook Events, LinkedIn Events, conference websites.

Search terms: "AI meetup [city]", "ChatGPT [city]", "AI for business [city]", "startup meetup [city]", "tech networking [city]", "innovation [city]", "AI workshop [city]"

**CRITICAL**: Verify each event is actually happening during [START DATE] to [END DATE]. Don't include regular monthly events unless they fall within my dates.

## 2. DROP-IN VENUES

Find coworking spaces, coffee shops, and innovation hubs where I can work AND network:

**Coworking Spaces with Day Passes:**
- Name, address, day pass cost
- Drop-in hours
- Whether they have community events during my dates
- Best days/times to visit for spontaneous networking

**Coffee Shops (AI Community Hangouts):**
- Where local AI builders work from
- Best times to visit (morning vs afternoon)
- Whether any scheduled meetups happen here during my dates

## 3. KEY PEOPLE TO CONNECT WITH

List local AI community organizers, thought leaders, and entrepreneurs worth reaching out to:

- Full name and LinkedIn profile
- Why they're relevant
- How to reach out (message template)
- Whether they're hosting any events during my dates

## 4. TRAVEL NETWORKING AGENDA

Create a day-by-day agenda for my trip:

**[Day 1 - Date]:**
- Morning: [Suggested activity/venue]
- Afternoon: [Suggested activity/venue]
- Evening: [Any events happening this day?]

**[Day 2 - Date]:**
[Same format]

[Continue for all days of trip]

Include: specific times, addresses, travel time between locations, mix of focused work and networking.

## 5. QUICK PREP CHECKLIST

**Before I leave:**
- [ ] Register for [list specific events]
- [ ] Message [list specific people] on LinkedIn
- [ ] Book day passes to [list coworking spaces]
- [ ] Add events to calendar

**During trip:**
- [ ] Best days for networking: [specific days]
- [ ] Best days for focused work: [specific days]
- [ ] Backup plan if events are cancelled: [alternatives]

---

## FINAL REQUIREMENTS

- **Date verification is CRITICAL** - only include events during [START DATE] to [END DATE]
- **Be specific** - exact addresses, times, registration links
- **Focus on efficiency** - this is a short trip, prioritize high-value opportunities
- **Include logistics** - travel times, best order to visit venues
- **Provide alternatives** - backup options if events are full or cancelled
```

### STEP 3: Execute Deep Research

Tell the user: "Researching AI events in [CITY] during [DATES]... this will take 2-3 minutes."

Execute the deep-research orchestrator the same way as Home Base mode.

### STEP 4: Process Research Results

Read the research results from staging folder, same as Home Base.

**Apply same consolidation strategy:**
- Deduplicate events appearing in multiple sources
- Cross-validate dates (CRITICAL for travel mode - wrong dates waste trip)
- Combine all registration links found
- Use most detailed event descriptions
- Flag any date conflicts clearly: "Verify date - sources disagree"
- Prioritize events confirmed on official sites/Meetup.com over mentions in articles

### STEP 5: Generate Travel Agenda

Create a focused, date-specific travel agenda:

```markdown
# Your AI Network: [City Name] Travel Agenda

**Trip Dates:** [Start Date] - [End Date] ([Number] days)
**Goal:** [Networking/Learning/Both]

---

## Executive Summary

Found [NUMBER] AI power user events during your [CITY] trip.

**Key Opportunities:**
- [Event 1 - Date/Time]
- [Event 2 - Date/Time]
- [Event 3 - Date/Time]

**Best Days for Networking:** [Specific days]
**Backup Venues:** [Coworking spaces for drop-in networking]

---

## Events During Your Trip

### [Day 1 - Full Date]

**[Event Name]**
- Time: [Exact time]
- Location: [Address]
- Register: [URL]
- Why attend: [Brief reason]
- Typical crowd: [Who attends]
- Cost: [Free/Paid]

[Repeat for all events on this day]

### [Day 2 - Full Date]

[Same format]

[Continue for all days]

---

## Drop-In Networking Venues

### Coworking Spaces (Day Passes)

**[Space Name]**
- Address: [Full address]
- Day pass: $[Amount]
- Hours: [Operating hours]
- Best time to visit: [Morning/Afternoon]
- Community vibe: [Description]
- Book: [URL or walk-in]

### Coffee Shops (AI Community Hangouts)

**[Shop Name]**
- Address: [Full address]
- Best time: [When AI builders are there]
- Vibe: [Work-friendly, chatty, quiet, etc.]

---

## Key People to Connect With

**[Person Name]** - [Title]
- Why connect: [Relevance to your goals]
- LinkedIn: [URL]
- Message template: "Hi [Name], I'm visiting [City] [dates] and would love to connect with local AI power users. Saw you organize [event/community]. Any chance for a quick coffee?"

---

## Day-by-Day Agenda

### [Day 1 - Date]
- **9-11am:** Work from [Coworking Space] (day pass booked)
- **11:30am:** Coffee with [Person] at [Venue] (if confirmed)
- **12-2pm:** Lunch + work from [Coffee Shop]
- **2-5pm:** [Scheduled commitment/work block]
- **6-8pm:** [Event Name] at [Venue] ⭐ PRIORITY

### [Day 2 - Date]
[Same format for each day]

---

## Quick Prep Checklist

### Before Trip (Do Now):
- [ ] Register: [Event 1 URL]
- [ ] Register: [Event 2 URL]
- [ ] Book day pass: [Coworking Space URL]
- [ ] Message [Person 1] on LinkedIn
- [ ] Message [Person 2] on LinkedIn
- [ ] Add all events to calendar

### During Trip:
- [ ] Morning of Day 1: Confirm coworking space hours
- [ ] Evening of Day 1: Check if [Event] is still on
- [ ] If events cancelled: Visit [Backup Venue] instead

### Backup Plan:
If scheduled events are full/cancelled:
1. [Coworking Space] - work there and chat with members
2. [Coffee Shop] - during [Time] when AI folks gather
3. Post in [Facebook/LinkedIn Group] asking about impromptu meetups

---

## Logistics Notes

**Travel times between venues:**
- [Venue A] to [Venue B]: [X minutes by car/transit]
- [Venue C] to [Venue D]: [X minutes]

**Best days for focused work:** [Days with fewer events]
**Best days for networking:** [Days with multiple events]

**Emergency contacts:**
- [Space/Venue Manager]: [Phone/Email]

---

*Travel light, network heavy. Your tribe is waiting in [City].*
```

### STEP 6: Save Travel Agenda

Save to: `Your AI Network/[City Name] - [Month Year] Travel Agenda.md`

Example: `Your AI Network/Austin - March 2026 Travel Agenda.md`

### STEP 7: Auto-Generate Complete Travel Package & Deliver

**Auto-generate everything (no asking):**

1. **Parse all events** during travel dates from travel agenda

2. **Generate .ics files** for all events during trip:
   - Create one .ics file per event
   - Save to: `Your AI Network/[Event Name] - [Date].ics`
   - Format: Standard iCalendar with event details and location

3. **Extract priority event:** Identify the highest-value networking event

4. **Display complete summary:**

"Travel research complete! Found [NUMBER] AI events in [CITY] during your trip ([DATES]).

**✅ Saved:**
- Travel agenda: `Your AI Network/[City] - [Month Year] Travel Agenda.md`
- Calendar files: All [X] events ready to add (double-click .ics files)

**🎯 Priority Event:**
[Event Name] - [Day, Date, Time] → [Registration URL]

**📅 Your [X]-Day Agenda:**
- [Day 1]: [X] events/activities scheduled
- [Day 2]: [Y] events/activities scheduled
- [Day 3]: [Z] events/activities scheduled

All events are in calendar files in 'Your AI Network' folder.
Full agenda includes coworking spaces, key contacts, and backup venues.

Done! Your [City] networking is mapped."

**No follow-up questions. Package is complete.**

---

## Error Handling

**If deep-research fails:**
Display: "Research failed. This might be due to API limits. Wait 5 minutes and try again, or contact support at the deep-research skill."

**If research returns no/limited results (Home Base mode):**
Display: "Found limited results in [location]. AI communities may be concentrated in nearby larger cities. Consider including [suggest nearby major city] in your travel radius and running again."

**If research finds ZERO events during travel dates (Travel Mode):**
Count venues and contacts found. Then display:

"No AI events found in [CITY] during [DATES].

However, I found:
- **[X] coworking spaces** where AI builders work
- **[Y] key people** you can reach out to for spontaneous meetups
- **[Z] regular communities** (but meetings fall outside your travel dates)

**Options:**
1. **Expand date range** by ±3 days ([NEW DATE RANGE])
2. **Show full network** (all communities regardless of your dates)
3. **Deliver what I found** (venues + contacts only for spontaneous networking)

Which would you prefer?"

**If research finds ZERO events AND ZERO venues (Travel Mode):**
Display: "Found no AI events or established communities in [CITY] during [DATES]. This likely means:
- The AI community here is very small/nascent
- Or events aren't publicly listed online

**Suggestions:**
1. Check nearby cities: [list nearby major cities within 50 miles]
2. Post in general tech/startup communities asking about AI builders
3. Use LinkedIn to search for '[City] AI entrepreneurs' and reach out directly

Would you like me to search nearby cities instead?"

**If Universal Expander file path doesn't exist:**
Display: "File not found. Continuing without personalization." and proceed with research.

**If can't create Your AI Network folder:**
Display: "Cannot create 'Your AI Network' folder in your Obsidian vault. Please create it manually and I'll save the network map there."

**If research takes longer than 5 minutes:**
Display: "Research is taking longer than usual... still working. The deep-research orchestrator is being thorough."

---

## Important Notes

- Phases 1-2-4 complete: Research + network map + action facilitation + travel mode
- Phase 3 (tracking, weekly reminders) comes later
- Focus on business-focused AI communities, not hardcore developer meetups
- All research is automated - user provides location, you do everything else
- Network map should be 30-60KB (comprehensive like the Delray Beach example)
- Be specific with all details - addresses, dates, times, URLs, costs, names
- After delivering network map, ALWAYS offer action options (don't just stop)
- Calendar integration is optional - offer it, but user can decline

---

## Reference Files

- Prompt template: `~/.claude/skills/proximity-architect/references/prompt-template.md`
- Example output quality: See Delray Beach example (52KB comprehensive network map)
