# ============================================================
# Short-Form Copy Mastery - Installer (Windows)
# Strategic Profits
# ============================================================

$ErrorActionPreference = "Stop"

$SkillName = "short-form-copy"
$SkillDir = "$env:USERPROFILE\.claude\skills\$SkillName"

Write-Host "============================================================"
Write-Host "  Short-Form Copy Mastery - Installer"
Write-Host "  Strategic Profits"
Write-Host "============================================================"
Write-Host ""

# Check if skill already exists
if (Test-Path $SkillDir) {
    Write-Host "WARNING: $SkillDir already exists."
    $Confirm = Read-Host "Overwrite? (y/n)"
    if ($Confirm -ne "y" -and $Confirm -ne "Y") {
        Write-Host "Installation cancelled."
        exit 0
    }
    Remove-Item -Recurse -Force $SkillDir
}

# Create skill directory
New-Item -ItemType Directory -Force -Path "$SkillDir\references" | Out-Null

# Get the directory where this script lives
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Copy files
Write-Host "Installing skill files..."
Copy-Item "$ScriptDir\SKILL.md" "$SkillDir\SKILL.md"
Copy-Item "$ScriptDir\references\training.md" "$SkillDir\references\training.md"
Copy-Item "$ScriptDir\references\platform-specs.md" "$SkillDir\references\platform-specs.md"
Copy-Item "$ScriptDir\references\examples.md" "$SkillDir\references\examples.md"
Copy-Item "$ScriptDir\references\validate_copy.py" "$SkillDir\references\validate_copy.py"

Write-Host ""
Write-Host "============================================================"
Write-Host "  Installation complete!"
Write-Host "============================================================"
Write-Host ""
Write-Host "  Installed to: $SkillDir"
Write-Host ""
Write-Host "  Files:"
Write-Host "    - SKILL.md (main skill)"
Write-Host "    - references/training.md"
Write-Host "    - references/platform-specs.md"
Write-Host "    - references/examples.md"
Write-Host "    - references/validate_copy.py"
Write-Host ""
Write-Host "  OPTIONAL: For best results, make sure your Obsidian vault"
Write-Host "  has these files (ask Rich for them if needed):"
Write-Host "    - 000 Core Context\Rich Schefren\_AI-COPYWRITING-RESOURCES\01-VOICE-AND-TONE.md"
Write-Host "    - 000 Core Context\Strategic Profits\04-Product-Registry.md"
Write-Host ""
Write-Host "  Usage: Tell Claude 'I need short-form copy' or invoke"
Write-Host "  the skill with /short-form-copy"
Write-Host ""
Write-Host "  Restart Claude Code to pick up the new skill."
Write-Host "============================================================"
