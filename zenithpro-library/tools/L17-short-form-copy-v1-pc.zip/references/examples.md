# Short-Form Copy Examples - Strategic Profits

These are reference examples for all SP products across all platforms. Use them as patterns to swipe from, not as final copy.

---

## FORCE MULTIPLIER EXAMPLES

### Facebook

#### FM-FB-001
- **Headline:** The Guru's Guru on AI Architecture
- **Primary Text:** 88% of companies adopted AI. Only 6% see meaningful impact (McKinsey). The gap isn't about tools -- it's about architecture. Rich Schefren, the consultant behind $15B in client revenue, reveals the "Motor Swap" that fixes it in 10 days.

#### FM-FB-002
- **Headline:** 88% Adopt AI. Only 6% See Results.
- **Primary Text:** You bought a Ferrari. You're still driving 25 in the same neighborhood. That's what most AI adoption looks like. Rich Schefren calls it AI theater. Here's what the 6% do differently.

#### FM-FB-003
- **Headline:** Stop Teaching Your Team Better Prompts
- **Primary Text:** Prompts vanish. Skills persist. That's the entire difference between AI theater and AI architecture. The man who coached Russell Brunson, Frank Kern, and Ryan Deiss shows the fix.

#### FM-FB-004
- **Headline:** Your Team Is Your AI Advantage
- **Primary Text:** Camp 1: fire everyone, do it yourself. Efficient until it breaks. Camp 2: give everyone ChatGPT. AI theater. Camp 3: teach your team to command AI. Unkillable. Rich shows Camp 3.

#### FM-FB-005
- **Headline:** AI Theater vs AI Architecture
- **Primary Text:** "Felt like when I first got online." That's what Russell Brunson, Todd Brown, Mike Filsaime, and Donnie French each told Rich. Not about a tool. About what happens when you rebuild your business around AI. 10 days. March 24.

#### FM-FB-006 (Long-form Primary Text)
- **Headline:** Same 7 Patterns. 100 Years. Your Turn.
- **Primary Text:** In 1880, factories replaced steam engines with electric motors. Same floor plan. Same workflow. Different motor. Productivity? Zero improvement. For 40 years.

Then someone redesigned the factory floor around what electricity made possible. 30% gains overnight.

That's EXACTLY what's happening with AI right now. You're bolting new technology onto old processes. Same prompts, same workflow, different tool.

Rich Schefren ran 263 deep research projects across 100 years of disruption -- electrification, computing, Internet, mobile, AI. Same 7 characteristics determined the winners every single time.

In March, he's teaching those 7 characteristics live while training his own team. You pull up a seat and watch.

12-18 months left in the window. Click to see the architecture.

---

### YouTube / GDN

#### FM-GDN-001
- **Headline:** AI Architecture for Teams
- **Long Headline:** 88% adopted AI. 6% saw impact. The gap is architectural. Rich Schefren shows the fix.
- **Description:** The $15B consultant reveals why prompts don't compound and what to build instead. 10 days.

#### FM-GDN-002
- **Headline:** Stop the AI Theater
- **Long Headline:** Your team has ChatGPT. Nothing compounds. Nothing persists. Here's the architectural fix.
- **Description:** The Motor Swap: redesign your business around AI, not bolt AI onto old processes.

#### FM-GDN-003
- **Headline:** The Motor Swap Explained
- **Long Headline:** Bolting AI onto old processes is like putting an electric motor in a steam-era factory.
- **Description:** 40 years of no gains. Then someone redesigned the floor. 30% overnight. Same pattern now.

#### FM-GDN-004
- **Headline:** 6-Person Team. 600x Output.
- **Long Headline:** Rich Schefren turned a 6-person team into the equivalent of 600 using AI architecture.
- **Description:** Not tools. Not prompts. Persistent skills, specialized agents, compounding systems. See how.

#### FM-GDN-005
- **Headline:** Multiply Your Team in 10 Days
- **Long Headline:** Force Multiplier: 10-day intensive that installs AI architecture for teams of 2-20.
- **Description:** From the consultant behind $15B in client revenue. March 24. Architecture, not prompts.

---

### Google Search

#### FM-GS-001
- **Headline:** AI Team Training by Schefren
- **Long Headline:** Force Multiplier: AI team training from the consultant behind $15 billion in results.
- **Description:** 10-day intensive. Train your team to command AI architecture. March 24. Teams of 2-20.

#### FM-GS-002
- **Headline:** Force Multiplier Official
- **Long Headline:** Force Multiplier Official Site - AI Architecture Training for Business Teams.
- **Description:** By Rich Schefren. 10-day intensive, March 24 - April 5. $5K-$20K by team size.

#### FM-GS-003
- **Headline:** AI Training for Business Teams
- **Long Headline:** Not another AI course. AI architecture that compounds. For teams of 2-20 people.
- **Description:** Rich Schefren's Force Multiplier. Same system behind 54% revenue growth. See details.

---

### Twitter / X

#### FM-TW-001
88% of companies adopted AI. Only 6% saw meaningful impact.

The gap isn't about the tool. It's about the architecture.

#### FM-TW-002
Stop teaching your team better prompts.

Prompts vanish the moment they're used. Skills persist. Agents compound. Architecture scales.

That's the difference between AI theater and AI infrastructure.

#### FM-TW-003
Your instinct to plan before executing?
Trained incapacity.

Your instinct to simplify as you grow?
Trained incapacity.

Your instinct to learn before doing?
Trained incapacity.

The skills that made you successful are the ones making you fail at AI.

#### FM-TW-004
Factories bolted electric motors onto steam-era layouts. Zero productivity gain for 40 years.

Then someone redesigned the factory around electricity. 30% gains overnight.

That's exactly what most businesses are doing with AI right now.

#### FM-TW-005
"I felt like I did when I first got online."

That's what Russell Brunson told me. Todd Brown said the same. So did Mike Filsaime. And Donnie French.

They weren't talking about a tool. They were talking about AI architecture.

#### FM-TW-006
I will never buy another course in my life.

Not because courses are bad. Because I can turn any course into an agent that executes the methodology for me.

The value shifted from teaching to architecture.

#### FM-TW-007
The real risk isn't the investment.

The real risk is staying where you are for another 12 months while this window closes.

#### FM-TW-008
AI is not a tool. It's infrastructure.

You don't add infrastructure to existing processes. You rebuild processes around infrastructure.

That's the entire lesson of 100 years of technological disruption in two sentences.

---

### Email / Substack

#### FM-EM-001
- **Subject:** 88% adopt AI. 6% see results. Why?
- **Preview:** The gap is architectural, not technological. Here's what the 6% do differently.

#### FM-EM-002
- **Subject:** What I told Russell Brunson at 11pm
- **Preview:** It wasn't about AI. It was about architecture.

#### FM-EM-003
- **Subject:** I will never buy another course
- **Preview:** Not because courses are bad. Because architecture changed everything.

#### FM-EM-004
- **Subject:** Your success is making you fail at AI
- **Preview:** Trained incapacity: when deep training for one environment makes you incapable in another.

#### FM-EM-005
- **Subject:** 40 years of zero improvement
- **Preview:** Same motor. Same layout. Sound familiar?

#### FM-EM-006
- **Subject:** Stop teaching your team better prompts
- **Preview:** Prompts vanish. Skills persist. That's the whole lesson.

#### FM-EM-007
- **Subject:** Camp 1, Camp 2, or Camp 3?
- **Preview:** Two of them are traps. One is unkillable.

#### FM-EM-008
- **Subject:** The 12-18 month window
- **Preview:** Same pattern. Electrification. Computing. Internet. Mobile. Now AI.

---

### Newsletter Ad Copy

#### FM-NA-001
- **Headline:** $15B Consultant Goes Public on AI Architecture
- **Body:** Rich Schefren coached Russell Brunson, Frank Kern, and Ryan Deiss. His system produced 54% revenue growth in 2025. Now he's teaching it live in a 10-day intensive for teams of 2-20.
- **CTA:** See the architecture

#### FM-NA-002
- **Headline:** 88% Adopt AI. 6% See Impact. The Fix Is Live.
- **Body:** McKinsey says 88% of companies adopted AI. Only 6% saw meaningful impact. The consultant behind $15B in client revenue reveals the architectural fix in a 10-day intensive.
- **CTA:** Watch the free training

---

### Taboola / Native

#### FM-TAB-001
- **Headline:** $15 Billion Consultant Reveals AI's Real Problem

#### FM-TAB-002
- **Headline:** Why 88% of AI Adoption Fails (McKinsey Data)

#### FM-TAB-003
- **Headline:** The Guru's Guru Goes Public on AI

#### FM-TAB-004
- **Headline:** Stop Adding AI to Old Processes (Here's Why)

#### FM-TAB-005
- **Headline:** Same 7 Patterns. 100 Years. AI Is Next.

#### FM-TAB-006
- **Headline:** Russell Brunson's 11pm Text About AI

---

## ZENITH MIND OS EXAMPLES

### Facebook

#### ZMOS-FB-001
- **Headline:** The AI-Powered Knowing-Doing Gap Fix
- **Primary Text:** You know what to do. You're not doing it. That's not a discipline problem -- it's a self-understanding problem. Zenith Mind OS uses AI to bridge the gap between knowing and doing. 4 weeks. $1K.

#### ZMOS-FB-002
- **Headline:** Why Smart People Stay Stuck
- **Primary Text:** Intelligence determines your potential. It doesn't guarantee results. Rich Schefren built an AI-powered system that bridges the gap. 1,409 people enrolled in 2025. Here's what they found.

#### ZMOS-FB-003
- **Headline:** "Most Understood I've Ever Felt"
- **Primary Text:** That's what students say after Week 1 of Zenith Mind OS. AI-powered self-mastery that bridges the gap between knowing what to do and actually doing it. 4-week cohort. Next one starts soon.

### Twitter / X

#### ZMOS-TW-001
Your intelligence determines your potential.
Your self-understanding determines your results.

There's a gap between those two. We built an AI system to close it.

#### ZMOS-TW-002
"I've never felt more understood in my entire life. I'm crying."

That's Day 1 of Zenith Mind OS. Not a course. An AI-powered mirror that shows you why you're stuck.

### Email / Substack

#### ZMOS-EM-001
- **Subject:** Why smart people stay stuck
- **Preview:** It's not discipline. It's self-understanding. There's an AI fix.

#### ZMOS-EM-002
- **Subject:** The knowing-doing gap has a name
- **Preview:** And an AI-powered solution. 1,409 people found it in 2025.

---

## STEAL OUR WINNERS EXAMPLES

### Facebook

#### SOW-FB-001
- **Headline:** 500+ Expert Interviews. $50/Month.
- **Primary Text:** 71 issues. 500+ expert interviews. Curated strategies from the world's top marketers, entrepreneurs, and business builders. New issue monthly. Cancel anytime.

#### SOW-FB-002
- **Headline:** Stop Searching. Start Stealing.
- **Primary Text:** Rich Schefren has interviewed 500+ of the world's top experts. Every strategy, every framework, every breakthrough -- curated into one library. $50/month. New issue every month.

### Twitter / X

#### SOW-TW-001
I've interviewed 500+ of the world's top experts over the past decade.

Every strategy. Every framework. Every breakthrough.

All curated into one library called Steal Our Winners.

$50/month. New issue monthly. Cancel anytime.

### Email / Substack

#### SOW-EM-001
- **Subject:** 500+ expert strategies for $50/month
- **Preview:** Every framework I've collected from a decade of interviews. One library.

---

## COURSE / MODULE DESCRIPTION EXAMPLES

These follow the pattern: `[Action Verb] + [Specific Outcome] + [Timeframe/Qualifier]`

### Force Multiplier Modules
| Module | Description |
|--------|-------------|
| The Motor Swap | Redesign your business around AI in one session |
| Trained Incapacity | Identify which success skills are now liabilities |
| The Three Camps | Diagnose your AI adoption approach in 15 minutes |
| Building Your First Skill | Clone your expertise into a persistent AI skill |
| Agent Architecture | Deploy specialized AI agents for your team |
| The Portability Principle | Build AI that works across any platform |
| Complexity Inversion | Turn complexity into a competitive weapon |
| The Advantage Window | Calculate your remaining disruption window |

### ZenithPro Modules
| Module | Description |
|--------|-------------|
| AI Marketing System | Build your complete AI marketing architecture |
| Copy Clinic | Get live AI-powered copy feedback and fixes |
| Growth Engine | Install systematic growth into your business |
| Skill Building Workshop | Create custom AI skills for your business |
| Agent Workshop | Build specialized agents that compound daily |

### Zenith Mind OS Modules
| Module | Description |
|--------|-------------|
| Self-Discovery Week | Map your cognitive patterns with AI precision |
| The Knowing-Doing Gap | Identify exactly what's blocking your execution |
| Personal Operating System | Build an AI system tailored to your psychology |
| Integration Week | Lock in the changes so they stick permanently |
