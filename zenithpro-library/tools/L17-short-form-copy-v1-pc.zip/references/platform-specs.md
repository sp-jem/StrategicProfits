# Platform Specifications - Character Limits & Deliverables

## Facebook / Meta Ads

**Context:** Social feed, passive browsing, short attention span. Audience is scrolling. You have 3 seconds.

**Deliverables:**
- Headline
- Primary Text

**Character Limits:**
- Headline: 40 characters
- Primary Text: 125 characters (recommended -- this is what shows before "See more")
- Primary Text (extended): up to 500+ characters (engagement decreases with length)

**Tone:** Conversational, story-driven. Emoji OK but strategic (not spammy). Can be longer-form in primary text when curiosity-driven. Rich's contrarian voice works exceptionally well here -- pattern interrupt against the feed.

**SP-Specific Notes:**
- Lead with validation ("You're right to be skeptical of AI courses")
- Or lead with a provocative stat ("88% adopt AI. 6% see results.")
- Or lead with authority ("The consultant behind $15B in revenue")
- Use the "See more" strategically -- front-load curiosity, answer after truncation

---

## YouTube / Google Display Network (GDN)

**Context:** Content sites, during active reading/browsing. More professional context than FB.

**Deliverables:**
- Headline
- Long Headline
- Description

**Character Limits:**
- Headline: 30 characters
- Long Headline: 90 characters
- Description: 90 characters

**Tone:** More professional than FB. Benefit-focused, direct. Less emoji, less casual.

**SP-Specific Notes:**
- Headline = the core mechanism or outcome ("AI Architecture for Teams")
- Long Headline = expanded promise with specificity ("Your team has the expertise. They lack the architecture. Rich Schefren shows the fix.")
- Description = how/credibility ("The consultant behind $15B reveals why 94% of AI adoption fails and what to do instead.")

---

## Google Search

**Context:** High intent -- they are actively searching for solutions. Match their query.

**Deliverables:**
- Headline
- Long Headline
- Description

**Character Limits:**
- Headline: 30 characters
- Long Headline: 90 characters
- Description: 90 characters

**Tone:** Direct, keyword-conscious. Answer their search intent. Include keywords Google will bold.

**SP-Specific Notes:**
- Match search intent: "AI team training" → "AI Team Training for Business"
- Include brand terms in 2-3 variants: "Rich Schefren AI Training", "Force Multiplier Official"
- Be crystal clear about what you offer
- Numbers catch the eye in text-heavy search results

**Additional product-specific entries (2-3 per product):**
```
Headline: Force Multiplier Official
Long Headline: Force Multiplier Official Site - AI Team Training by Rich Schefren
Description: 10-day intensive. Train your team to command AI. $15B+ in client results.

Headline: Rich Schefren AI Training
Long Headline: Rich Schefren's AI Team Training - Clone Your Expertise Into AI Systems
Description: From the Guru's Guru. Architecture, not prompts. For teams of 2-20.
```

---

## Twitter / X

**Context:** Fast-moving feed, opinion-driven, contrarian content performs well. Rich's natural contrarian voice is a weapon here.

**Deliverables (Organic):**
- Tweet (280 characters max)

**Deliverables (Promoted/Ads):**
- Tweet copy (280 characters max)
- Optional: Card headline (70 characters)
- Optional: Card description (200 characters)

**Character Limits:**
- Tweet: 280 characters
- Card headline: 70 characters
- Card description: 200 characters

**Tone:** Punchiest of all platforms. Provocative, contrarian, opinionated. Thread-starters that drive to longer content. Thought leadership, not sales.

**SP-Specific Notes:**
- Rich's contrarian positions are PERFECT for Twitter
- Lead with the provocative claim, not the product
- "I will never buy another course in my life." (66 chars -- banger tweet)
- "88% of companies adopted AI. 6% saw meaningful impact. The fortune is in the gap."
- "Your team's biggest AI problem isn't the tool. It's the architecture."
- Use threads for deeper points, single tweets for hooks

---

## Substack Newsletters

**Context:** Email-adjacent. Reader has opted in. Higher trust, longer attention span. But the subject line still has to earn the open.

**Deliverables:**
- Subject Line
- Preview Text (shown after subject in inbox)

**Character Limits:**
- Subject Line: 50 characters optimal (6-10 words) -- longer gets truncated on mobile
- Preview Text: 90 characters (complements subject, adds context)

**Tone:** Conversational, like an email from a smart friend. Rich's signature phrases and bucket brigades work well here. Not salesy -- more thought leadership.

**SP-Specific Notes:**
- Subject lines should create curiosity or state a contrarian position
- Preview text should expand without repeating the subject
- "Here's what I told Russell Brunson at 11pm" (Subject) + "It wasn't about AI. It was about architecture." (Preview)
- Avoid click-bait that erodes trust -- these are subscribers

---

## Newsletter Ad Copy (Sponsored Placements in Other People's Newsletters)

**Context:** You are a guest in someone else's newsletter. The reader trusts the host, not you (yet). You have ONE shot to earn a click.

**Deliverables:**
- Headline
- Body Text
- CTA

**Character Limits:**
- Headline: 60 characters
- Body: 150-300 characters
- CTA: 30 characters

**Tone:** Authoritative but not aggressive. Credential-led (borrow credibility quickly). Specific outcomes.

**SP-Specific Notes:**
- Lead with Rich's authority or a striking stat
- "The consultant behind $15B in revenue reveals why 94% of AI adoption fails. And what the 6% do differently." (Body)
- CTA: "See the architecture" / "Watch the free training" / "Get the framework"
- Avoid sounding like every other AI ad -- the contrarian angle differentiates

---

## Taboola / Native Ads

**Context:** Content discovery, "Around the web" placements. Curiosity-driven. More sensational is OK.

**Deliverables:**
- Headline

**Character Limits:**
- Headline: 60 characters (35-45 for best performance)

**Tone:** More curiosity-driven. Bolder claims OK. Pattern interrupts. But still grounded in real authority (not clickbait).

**SP-Specific Notes:**
- "Why This Consultant Told Russell Brunson To Stop"
- "88% of Companies Get AI Wrong. Here's Proof."
- "$15 Billion in Results. Zero Lines of Code."
- Use authority quotes, challenges, shocking stats
- Keep it 35-45 chars for best CTR

---

## Course / Module Descriptions (Members Area)

**Context:** Already a customer. Browsing their training library. Don't need to be sold -- just need to know what this specific module delivers.

**Deliverables:**
- Course/Module Name (keep as-is -- don't change)
- Description

**Character Limits:**
- Description: 60 characters (pure benefit statement)

**Tone:** Clean, outcome-focused. Strong action verb + specific result + timeframe if applicable.

**SP-Specific Notes:**
- Pattern: `[Action Verb] + [Specific Outcome] + [Timeframe/Qualifier]`
- "Clone your expertise into persistent AI skills in 90 minutes"
- "Build your first AI agent that actually compounds"
- "Identify your team's #1 AI bottleneck in 30 minutes"
- Use: Eliminate, Build, Clone, Install, Unlock, Identify, Deploy, Multiply
- Avoid: Learn, Discover, Understand (too passive for action-oriented audience)

---

# Delivery Formatting

## Working/Draft Phase

Group deliverables by individual ad/unit so each can be evaluated as a set:

### Facebook:
```
Headline: [text]
Primary Text: [text]

Headline: [text]
Primary Text: [text]
```

### YouTube/GDN:
```
Headline: [text]
Long Headline: [text]
Description: [text]

Headline: [text]
Long Headline: [text]
Description: [text]
```

### Google Search:
```
Headline: [text]
Long Headline: [text]
Description: [text]
```

### Twitter (Organic):
```
Tweet: [text]

Tweet: [text]
```

### Twitter (Promoted):
```
Tweet: [text]
Card Headline: [text]
Card Description: [text]
```

### Email/Substack:
```
Subject: [text]
Preview: [text]

Subject: [text]
Preview: [text]
```

### Newsletter Ad:
```
Headline: [text]
Body: [text]
CTA: [text]
```

### Course Description:
```
Course: [name]
Description: [text]
```

---

## Final Delivery Format (Post-Approval)

**CRITICAL: All copy in code blocks. Raw copy only. No labels, no numbering, no commentary inside code blocks.**

Group all deliverables of the same type together. Each line = one cell in Google Sheets.

### Facebook Example (Correct):
```
The Guru's Guru on AI Architecture
88% Adopt AI. Only 6% See Impact.
Stop Training Prompts. Build Systems.

88% of companies adopted AI. Only 6% saw impact. The gap is architectural.
Your team isn't the problem. Your AI architecture is. Here's the fix.
The consultant behind $15B reveals why prompts don't compound but skills do.
```

### Facebook Example (WRONG -- DO NOT DO THIS):
```
HEADLINES:
Headline 1: The Guru's Guru on AI Architecture
Headline 2: 88% Adopt AI. Only 6% See Impact.

PRIMARY TEXT:
Primary Text 1: 88% of companies adopted AI...
```

### Visual Check Before Delivery:
If you see ANY of these words inside a code block, you did it WRONG:
- "Headline"
- "Primary Text"
- "Description"
- "Tweet"
- "Subject"
- Numbers like "1.", "2.", "3."
- ALL CAPS section headers

You should see ONLY the actual copy text, line by line, with a blank line between different deliverable types.
