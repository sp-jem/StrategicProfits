#!/usr/bin/env python3
"""
Short-Form Copy Character Count Validator
Strategic Profits Edition

Usage:
1. Replace the copy_items dictionary below with your actual copy
2. Run: python3 ~/.claude/skills/short-form-copy/references/validate_copy.py
3. Fix any FAIL items and re-run until 100% pass

Character Limits:
- Facebook Headline: 40
- Facebook Primary Text (recommended): 125
- YouTube/GDN Headline: 30
- YouTube/GDN Long Headline: 90
- YouTube/GDN Description: 90
- Google Search Headline: 30
- Google Search Long Headline: 90
- Google Search Description: 90
- Twitter Tweet: 280
- Twitter Card Headline: 70
- Twitter Card Description: 200
- Substack Subject Line: 50
- Substack Preview Text: 90
- Newsletter Ad Headline: 60
- Newsletter Ad Body: 300
- Newsletter Ad CTA: 30
- Taboola Headline: 60
- Course Description: 60
"""

import sys

# ============================================================
# REPLACE THIS SECTION WITH YOUR ACTUAL COPY
# ============================================================

copy_items = {
    "Facebook Headlines": {
        "limit": 40,
        "items": [
            "The Guru's Guru on AI Architecture",
            "88% Adopt AI. Only 6% See Results.",
            "Stop Teaching Your Team Better Prompts",
            "Your Team Is Your AI Advantage",
            "AI Theater vs AI Architecture",
        ]
    },
    "Facebook Primary Text (Recommended)": {
        "limit": 125,
        "items": [
            "88% of companies adopted AI. Only 6% see meaningful impact. The gap isn't tools -- it's architecture. See the fix.",
            "Prompts vanish. Skills persist. That's the difference between AI theater and AI architecture. Rich Schefren shows why.",
        ]
    },
    "YouTube/GDN Headlines": {
        "limit": 30,
        "items": [
            "AI Architecture for Teams",
            "Stop the AI Theater",
            "The Motor Swap Explained",
            "6-Person Team. 600x Output.",
            "Multiply Your Team in 10 Days",
        ]
    },
    "YouTube/GDN Long Headlines": {
        "limit": 90,
        "items": [
            "88% adopted AI. 6% saw impact. The gap is architectural. Rich Schefren shows the fix.",
            "Your team has ChatGPT. Nothing compounds. Nothing persists. Here's the architectural fix.",
        ]
    },
    "YouTube/GDN Descriptions": {
        "limit": 90,
        "items": [
            "The $15B consultant reveals why prompts don't compound and what to build instead. 10 days.",
            "The Motor Swap: redesign your business around AI, not bolt AI onto old processes.",
        ]
    },
    "Google Search Headlines": {
        "limit": 30,
        "items": [
            "AI Team Training by Schefren",
            "Force Multiplier Official",
            "AI Training for Business Teams",
        ]
    },
    "Google Search Long Headlines": {
        "limit": 90,
        "items": [
            "Force Multiplier: AI team training from the consultant behind $15 billion in results.",
            "Force Multiplier Official Site - AI Architecture Training for Business Teams.",
        ]
    },
    "Google Search Descriptions": {
        "limit": 90,
        "items": [
            "10-day intensive. Train your team to command AI architecture. March 24. Teams of 2-20.",
            "By Rich Schefren. 10-day intensive, March 24 - April 5. $5K-$20K by team size.",
        ]
    },
    "Twitter Tweets": {
        "limit": 280,
        "items": [
            "88% of companies adopted AI. Only 6% saw meaningful impact.\n\nThe gap isn't about the tool. It's about the architecture.",
            "Stop teaching your team better prompts.\n\nPrompts vanish the moment they're used. Skills persist. Agents compound. Architecture scales.\n\nThat's the difference between AI theater and AI infrastructure.",
        ]
    },
    "Substack Subject Lines": {
        "limit": 50,
        "items": [
            "88% adopt AI. 6% see results. Why?",
            "What I told Russell Brunson at 11pm",
            "I will never buy another course",
            "Your success is making you fail at AI",
            "Stop teaching your team better prompts",
            "Camp 1, Camp 2, or Camp 3?",
            "The 12-18 month window",
        ]
    },
    "Substack Preview Text": {
        "limit": 90,
        "items": [
            "The gap is architectural, not technological. Here's what the 6% do differently.",
            "It wasn't about AI. It was about architecture.",
            "Not because courses are bad. Because architecture changed everything.",
        ]
    },
    "Newsletter Ad Headlines": {
        "limit": 60,
        "items": [
            "$15B Consultant Goes Public on AI Architecture",
            "88% Adopt AI. 6% See Impact. The Fix Is Live.",
        ]
    },
    "Newsletter Ad Body": {
        "limit": 300,
        "items": [
            "Rich Schefren coached Russell Brunson, Frank Kern, and Ryan Deiss. His system produced 54% revenue growth in 2025. Now he's teaching it live in a 10-day intensive for teams of 2-20.",
            "McKinsey says 88% of companies adopted AI. Only 6% saw meaningful impact. The consultant behind $15B in client revenue reveals the architectural fix in a 10-day intensive.",
        ]
    },
    "Newsletter Ad CTAs": {
        "limit": 30,
        "items": [
            "See the architecture",
            "Watch the free training",
            "Get the framework",
        ]
    },
    "Taboola Headlines": {
        "limit": 60,
        "items": [
            "$15 Billion Consultant Reveals AI's Real Problem",
            "Why 88% of AI Adoption Fails (McKinsey Data)",
            "The Guru's Guru Goes Public on AI",
            "Stop Adding AI to Old Processes (Here's Why)",
            "Same 7 Patterns. 100 Years. AI Is Next.",
        ]
    },
    "Course Descriptions": {
        "limit": 60,
        "items": [
            "Redesign your business around AI in one session",
            "Identify which success skills are now liabilities",
            "Diagnose your AI adoption approach in 15 minutes",
            "Clone your expertise into a persistent AI skill",
        ]
    },
}

# ============================================================
# VALIDATION ENGINE - DO NOT MODIFY
# ============================================================

def validate():
    total = 0
    passed = 0
    failed = 0
    failures = []

    print("=" * 70)
    print("SHORT-FORM COPY CHARACTER COUNT VALIDATION")
    print("Strategic Profits Edition")
    print("=" * 70)
    print()

    for category, data in copy_items.items():
        limit = data["limit"]
        items = data["items"]

        print(f"\n--- {category} (limit: {limit} chars) ---")
        print()

        for i, item in enumerate(items, 1):
            total += 1
            # Count characters (excluding newlines for multi-line items like tweets)
            char_count = len(item.replace("\n", " "))
            pct = (char_count / limit) * 100

            if char_count <= limit:
                status = "PASS"
                passed += 1
                indicator = "+"
            else:
                status = "FAIL"
                failed += 1
                indicator = "X"
                over = char_count - limit
                failures.append({
                    "category": category,
                    "index": i,
                    "text": item[:60] + "..." if len(item) > 60 else item,
                    "count": char_count,
                    "limit": limit,
                    "over": over,
                })

            # Truncate display text
            display = item.replace("\n", " ")
            if len(display) > 55:
                display = display[:52] + "..."

            print(f"  [{indicator}] {status} | {char_count}/{limit} ({pct:.0f}%) | {display}")

    # Summary
    print()
    print("=" * 70)
    print(f"RESULTS: {passed}/{total} passed | {failed}/{total} failed")
    print("=" * 70)

    if failures:
        print()
        print("FAILURES TO FIX:")
        print("-" * 50)
        for f in failures:
            print(f"  {f['category']} #{f['index']}: {f['count']}/{f['limit']} ({f['over']} over)")
            print(f"    \"{f['text']}\"")
            print()
        print("Fix the above items and re-run validation.")
        sys.exit(1)
    else:
        print()
        print("ALL COPY VALIDATED - READY FOR DELIVERY")
        sys.exit(0)


if __name__ == "__main__":
    validate()
