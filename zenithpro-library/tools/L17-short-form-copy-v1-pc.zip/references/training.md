# Short-Form Copy Mastery Training - Strategic Profits Edition

## Table of Contents
1. [The Philosophy of Short-Form Copy for Sophisticated Audiences](#the-philosophy)
2. [The Long-Form-to-Short-Form Translation Process](#translation-process)
3. [The 15 Hook Formulas](#hook-formulas)
4. [The 5 Primary Text Structures](#primary-text-structures)
5. [The 12 Core Copy Principles](#core-principles)
6. [Platform-Specific Optimization](#platform-optimization)
7. [The Step-by-Step Creation Process](#creation-process)
8. [Advanced Techniques](#advanced-techniques)

---

## The Philosophy of Short-Form Copy for Sophisticated Audiences {#the-philosophy}

Short-form copy is NOT long-form copy "shortened." It's a completely different discipline.

**The Core Truth:**
You have 3-5 seconds to stop the scroll. But your audience is Level 4-5 sophistication -- they've been burned by AI hype, they've bought courses that didn't deliver, and they smell bullshit from a mile away. Your job is not to hype -- it's to create enough curiosity and credibility that a skeptical business owner clicks.

**The Mindset Shift:**
- Long-form: Build the case, overcome objections, close the sale
- Short-form: Create a curiosity gap, name the mechanism, promise the outcome -- all while sounding like the smartest person in the room, not the loudest

**The SP Success Formula:**
`Contrarian Hook + Specific Outcome + Named Mechanism + Authority Proof + Low-Friction CTA = Click`

**What Makes SP Short-Form Different from Typical:**
1. **Anti-hype positioning.** We sound like the correction to everyone else's noise, not more noise.
2. **Architecture language.** We sell systems, infrastructure, frameworks -- not tips, tricks, or hacks.
3. **Specificity as credibility.** "$15B in client revenue" does more work than "billions in revenue."
4. **Honest difficulty.** "You have to be comfortable being uncomfortable" -- this audience respects honesty about effort.
5. **Mechanism-first.** We name the mechanism (Motor Swap, Trained Incapacity, Three Camps) before the outcome.

---

## The Long-Form-to-Short-Form Translation Process {#translation-process}

### What to Extract from VSLs, Webinars, Sales Pages, or Reports

When you have a proven long-form piece, extract these 11 assets:

#### 1. The Big Mechanism (Primary Asset)
The unique method, system, or framework that makes your solution different.

**SP Examples:**
- "The Motor Swap" (Force Multiplier)
- "Trained Incapacity" (Force Multiplier)
- "The Three Camps Framework" (Force Multiplier)
- "The 1% Architecture Distinction" (ZenithPro)
- "The Knowing-Doing Gap" (Zenith Mind OS)
- "The Core Concept" (BGS)

**Why It Matters:** "Fix your AI adoption" = generic. "The Motor Swap: redesign your business around AI, not bolt AI onto old processes" = unique, branded, curiosity-creating.

#### 2. Specific Outcomes & Numbers
Vague promises don't work with sophisticated audiences. Extract SPECIFIC results:

**SP Examples:**
- "$15 billion in client revenue" (lifetime)
- "$1 billion Agora growth in 1 year" (specific engagement)
- "54% YoY revenue growth from AI" (2025)
- "500% AOV increase" (2021-2025)
- "6-person team → equivalent of 600" (Force Multiplier)
- "88% adoption / 6% impact" (McKinsey stat)
- "12-18 month advantage window" (research-backed)

**The Rule:** Always be more specific than you think you need to be. This audience trusts numbers, not adjectives.

#### 3. Authority Markers & Credibility
Who is Rich Schefren and why should they listen?

**SP Examples:**
- "The Guru to the Gurus"
- "Coached Russell Brunson, Ryan Deiss, Frank Kern, Todd Brown"
- "$15B+ in client revenue"
- "Invented the automated webinar"
- "First viral PDF in internet marketing (5M+ downloads)"
- "The only consultant with a $1 billion testimonial"
- "Forbes, WSJ, VOGUE, CNN, NBC, ABC, FOX"

**Pattern:** [Authority] + [Impressive Credential] + [Why That Matters to THEM]

#### 4. The Avatar's Pain Points
Specific frustrations the ICP faces:

**SP Examples (AI Team Training):**
- "Tried AI courses that taught prompts, not architecture"
- "Team has scattered prompts that don't transfer"
- "Owner is still the bottleneck reviewing all AI output"
- "Invested in tools that don't compound"
- "88% adoption, 6% meaningful impact"
- "Spent money on AI with nothing to show for it"
- "Competitors seem to be figuring it out"
- "Don't know if I'm too old, too stubborn, or too stupid"

#### 5. Social Proof & Testimonials
Real results from real people:

**SP Examples:**
- "Donnie French: $1.3M in 7 days from AI-written sales letter"
- "Todd Brown, Mike Filsaime, Russell Brunson: 'Felt like when I first got online'"
- "Russell Brunson text at 11pm: 'This would make a bigger difference than the automated webinar'"
- "729,000+ entrepreneurs taught"
- "Matt Leeds (AI expert): 'Never seen anything like this'"

#### 6. The Root Cause Framework
Why existing solutions don't work:

**SP Examples:**
- "You're bolting AI onto old processes. That's like putting an electric motor in a steam factory."
- "The problem isn't the AI. It's the architecture."
- "The Two Lies: SaaS companies say it's a tool. Prompt engineers say it's about typing. Both are wrong."
- "Trained Incapacity: The skills that made you successful are the ones making you fail at AI."

#### 7. The Transformation Promise
Before → After:

**Before (SP Avatar):**
- Using AI like a search engine
- Team has scattered prompts
- Owner reviews everything
- Nothing compounds
- Falling behind competitors

**After (Force Multiplier):**
- AI is your operating system
- Team commands persistent AI systems
- Architecture runs without bottleneck
- Everything compounds
- Unkillable competitive advantage

#### 8. False Beliefs to Break
What the audience currently believes that's wrong:

- "AI is just another tool to add to my workflow"
- "Better prompts = better AI results"
- "I should fire people and replace them with AI"
- "I need to learn to code"
- "I should wait until AI stabilizes"
- "My team can figure this out on their own"

#### 9. Price Anchoring
The expensive alternative:

- "AI specialist: $150K/year"
- "Consulting firm: $50K+"
- "Fractional AI expert: $25K"
- "The cost of waiting 12-18 months while the window closes"

#### 10. Urgency Elements
Why act now:

- "12-18 month advantage window (based on 100 years of disruption data)"
- "ChatGPT launched Nov 2022. We're 3+ years in."
- "You will be certain when the advantage is no longer there to be seized upon."
- "This is the first time Rich has done a public webinar about the opportunity"

#### 11. Features List
What they actually get:

- 10-day intensive (half-day per day)
- Owner track + Everyone track
- Live implementation
- Rich training his own team -- you watch
- Persistent AI systems built during the program
- Architecture that works across Claude, Gemini, Codex

---

## The 15 Hook Formulas {#hook-formulas}

### Formula 1: Authority + Specific Outcome
`[Authority] + [Specific Result] + [Timeframe/Qualifier]`

**Examples:**
- "The $15B Consultant Reveals AI's Real Problem"
- "Rich Schefren: 54% Growth Using AI Architecture"
- "Guru to the Gurus Shows Why AI Courses Fail"

### Formula 2: Time-Bound Challenge
`[Specific Result] + in + [Short Timeframe]`

**Examples:**
- "Multiply Your Team's Output In 10 Days"
- "Build Your First AI Agent In 90 Minutes"
- "Clone Your Expertise In One Afternoon"

### Formula 3: Quantified Simplicity
`[Small Number] + [Simple Action] + [Big Result]`

**Examples:**
- "1 Architecture. All Your AI. Zero Prompts."
- "6 People. 600x Output. One System."
- "217 Skills. 28 Agents. 1 Architecture."

### Formula 4: Curiosity Gap (Hidden Secret)
`[Teaser] + reveals + [Hidden Thing]`

**Examples:**
- "The ONE Thing Separating AI's 6% Winners"
- "Why 94% of AI Adoption Fails (It's Not the AI)"
- "What Russell Brunson Learned at 11pm"

### Formula 5: Social Proof Volume
`[Big Number] + [People Type] + [Result]`

**Examples:**
- "729K+ Entrepreneurs Trust This Man on AI"
- "$15B in Results. Zero Lines of Code."
- "5M+ Downloaded His First Manifesto"

### Formula 6: The Shocking Truth / New Discovery
`[NEW/Revealed] + [Category] + [Mechanism]`

**Examples:**
- "[NEW] Why Your AI 'Success' Is Actually Theater"
- "The 100-Year Pattern Behind AI Winners"
- "AI Is Infrastructure, Not a Tool. Here's Why."

### Formula 7: Direct Question (Qualification)
`[Pain Point Question]?` or `[Desire Question]?`

**Examples:**
- "Is Your Team Still Using AI Like a Search Engine?"
- "Adopted AI But Seeing No Real Impact?"
- "Ready to Stop Adding AI to Old Processes?"

### Formula 8: The Mechanism Name (Branded)
`[Mechanism Name]` + supporting context

**Examples:**
- "The Motor Swap: Why Your AI Isn't Working"
- "Trained Incapacity Explained"
- "The Three Camps of AI Adoption"

### Formula 9: The Negative Reversal
`[Stop/Don't] + [Common Wrong Action]`

**Examples:**
- "Stop Teaching Your Team Better Prompts"
- "Don't Hire an AI Expert. Not Yet."
- "Stop Bolting AI Onto Old Processes"

### Formula 10: The Comparison
`[Your Thing] vs [Their Thing]`

**Examples:**
- "Tools Fail. Architecture Compounds."
- "Prompts Vanish. Skills Persist."
- "AI Theater vs AI Architecture"

### Formula 11: The Seasonal / Event
`[Event/Timing] + [Offer] + [Benefit]`

**Examples:**
- "Last Cohort Before the Window Closes"
- "March 24: Rich Trains His Team. Watch."
- "10 Days in March That Change Everything"

### Formula 12: The Testimonial / Story Hook
`"[Quote]" - [Name + Credential]`

**Examples:**
- "'Felt Like When I First Got Online' - Brunson"
- "'$1.3M in 7 Days' - AI-Written Copy"
- "'Never Seen Anything Like This' - AI Expert"

### Formula 13: The #1 / Best / Leading Claim
`#1/Best/Leading + [Category] + [For Avatar]`

**Examples:**
- "The Consultant Behind $15 Billion"
- "Internet Marketing's Most Influential Advisor"
- "#1 AI Architecture System for Teams"

### Formula 14: The "For You" Personalization
`[Solution] + For + [Specific Avatar]`

**Examples:**
- "AI Architecture for Teams of 2-20"
- "For Business Owners Burned by AI Courses"
- "AI Training for Non-Technical Founders"

### Formula 15: The Proof / Guarantee
`[Result] + Proven/Backed by [Evidence]`

**Examples:**
- "Same 7 Patterns. 100 Years. 263 Studies."
- "AI Architecture Proven Across $15B in Results"
- "Backed by 263 Deep Research Projects"

---

## The 5 Primary Text Structures {#primary-text-structures}

### Structure 1: The Social Proof Story
Best for: Establishing credibility through peer results

**Template:**
```
"[Testimonial with specific result]" - [Name + Credential]

[Name] is just one of [big number] [avatar type] who [result] using [mechanism].

I designed it specifically for [avatar] who struggle with:
- [Pain point 1]
- [Pain point 2]
- [Pain point 3]

This fixes the real problem: [root cause]. [CTA]
```

**SP Example:**
```
"I felt like I did when I first got online." That's what Russell Brunson told me. Todd Brown said the same thing. So did Mike Filsaime.

They weren't talking about a tool. They were talking about what happens when you stop treating AI as a search engine and start building it as infrastructure.

If you've tried AI courses and seen no compound results -- it's not you. It's the architecture.

Click to see how we're fixing that.
```

### Structure 2: The Authority Introduction
Best for: When Rich's credibility is the angle

**Template:**
```
[Authority intro + impressive credential]

[Why they're revealing this now]

[What they're offering: mechanism name]

[2-4 bullet benefits]

[CTA]
```

**SP Example:**
```
Rich Schefren coached Russell Brunson, Ryan Deiss, and Frank Kern before they became household names. His clients have generated $15B+ in revenue.

Now he's going public with the AI operating system that produced 54% YoY growth and turned a 6-person team into the equivalent of 600.

It's not a course. It's architecture. Click to see it.
```

### Structure 3: Problem-Agitation-Solution (PAS)
Best for: Audience aware of problem but frustrated with existing solutions

**Template:**
```
[State the problem with specificity]

[Agitate - why existing solutions don't work]

Here's the deal: [Root cause explanation]

[Mechanism/solution]

[Benefits]

[CTA]
```

**SP Example:**
```
88% of companies report AI adoption. Only 6% see meaningful impact. That's a McKinsey stat, not my opinion.

Why? Because everyone's treating AI like a tool. Add ChatGPT to your workflow. Write better prompts. AI theater.

Here's the deal: AI is infrastructure, not a tool. You don't add infrastructure to existing processes -- you rebuild processes around infrastructure.

That's what the Motor Swap is. And it's what we teach in Force Multiplier.

Click to see the architecture.
```

### Structure 4: The Curiosity-Gap Tease
Best for: When you want to drive clicks through curiosity

**Template:**
```
[Bold claim or question]

And it has nothing to do with:
- [Wrong thing 1]
- [Wrong thing 2]
- [Wrong thing 3]

[The truth/secret]

[What happens when they discover this]

[CTA]
```

**SP Example:**
```
There are exactly 7 characteristics that separate the 6% of AI winners from the 94% who see no impact.

And they have nothing to do with:
- Which AI tool you use
- How good your prompts are
- How technical your team is

I found the same 7 characteristics across 100 years of technological disruption -- electrification, computing, Internet, mobile, and now AI.

Miss even one and success plummets.

Click to see the 7 characteristics.
```

### Structure 5: The Bullet-Point Benefits
Best for: High scannability, strong specific benefits

**Template:**
```
[Hook intro]

[Mechanism]

[Bullet list of 3-7 specific benefits]

[Social proof or risk reversal]

[CTA]
```

**SP Example:**
```
In 10 days, Rich Schefren's Force Multiplier installs AI architecture that:

- Turns scattered prompts into persistent skills that compound
- Gives every team member an AI that knows your business
- Removes YOU as the bottleneck reviewing all AI output
- Works across Claude, Gemini, and Codex (never locked to one tool)
- Built for teams of 2-20, not solo prompt engineers

This is the same system behind 54% revenue growth and a 500% AOV increase.

Click to join the March cohort.
```

---

## The 12 Core Copy Principles {#core-principles}

### 1. The Specificity Principle
More specific = more believable.

Levels:
- Vague: "Improve your AI results"
- Better: "See 54% revenue growth from AI"
- Best: "54% YoY revenue growth from AI architecture, measured in Stripe, with a 6-person team"

### 2. The Mechanism Principle
People don't buy solutions. They buy NEW mechanisms.

"I'll help you adopt AI" = heard it before.
"I'll show you the Motor Swap -- why bolting AI onto old processes fails and how to redesign around AI" = new, branded, curiosity-creating.

### 3. The Authority Principle
Rich has overwhelming authority. Use it. Stack it.

Authority Multipliers:
1. Association: "Coached Russell Brunson, Ryan Deiss, Frank Kern"
2. Volume: "$15B+ in client revenue"
3. Industry firsts: "Invented the automated webinar"
4. Third-party: "Forbes, WSJ, CNN"
5. Peer testimony: "Russell Brunson text at 11pm"
6. Self-use: "This is how Rich runs his own company"

### 4. The Simplicity Principle
Make the complex seem accessible (without lying about difficulty).

SP version: "You have to be comfortable being uncomfortable" -- but the ARCHITECTURE is learnable.
- "10 days"
- "Half-day per day"
- "You're watching Rich train his own team"

### 5. The Root Cause Principle
Why other solutions failed:
1. "AI courses teach prompts" (prompts vanish)
2. "SaaS companies call it a tool" (tools don't compound)
3. "They treat AI as an add-on" (you need a redesign)

### 6. The Transformation Principle
Before → After in vivid terms:

Before: "Your team has ChatGPT accounts and uses AI for email drafts"
After: "Your team commands persistent AI systems that know your business, improve themselves, and run without you"

### 7. The Social Proof Principle
SP has massive social proof. Deploy it:
- Peer names (Brunson, Deiss, Kern, Brown)
- Numbers ($15B, 729K entrepreneurs)
- Recency (Donnie French: $1.3M in 7 days, January 2026)

### 8. The Curiosity Gap Principle
Create an information gap only clicking can close:
- "The ONE thing the 6% do differently"
- "Why your biggest success skill is now your biggest liability"
- "What Rich told Russell at 11pm that changed everything"

### 9. The Speed-To-Result Principle
How fast they see results:
- "10 days"
- "90 minutes to first skill"
- "First agent by day 4"
- "Architecture compounds from day 1"

### 10. The Avatar Specificity Principle
Narrow = more resonant:
- "For business owners with teams of 2-20"
- "For non-technical founders"
- "For the 88% who adopted AI but saw no impact"

### 11. The Contrast Principle
Show the difference:
- "Prompts vanish. Skills persist."
- "Tools fail. Architecture compounds."
- "AI theater vs AI architecture."
- "88% adoption. 6% impact. The fortune is in the gap."

### 12. The Anti-Hype Principle (SP-Specific)
This is the #1 differentiator. Rich is the correction to the noise:
- "I'm not asking you to believe me. I'm asking you to look at the data."
- "This isn't easy. But it's the only approach that actually compounds."
- "I'm training my team anyway. You're pulling up a seat to watch."
- Validate skepticism: "You're right to be skeptical of AI courses."

---

## Platform-Specific Optimization {#platform-optimization}

See `platform-specs.md` for character limits and delivery formats.

### Facebook
- Story-driven, conversational
- Use "See more" strategically
- Lead with peer proof or contrarian stat
- Emoji OK but strategic (not spammy)

### YouTube / GDN
- More professional, benefit-focused
- Headline = mechanism or outcome
- Description = credibility or how

### Google Search
- Match intent directly
- Include keywords
- Be direct about what you offer
- Include authority

### Twitter
- Punchiest, most contrarian
- Thought leadership > sales
- Rich's natural voice is perfect here
- Threads for depth, tweets for hooks

### Substack
- Subject lines earn the open
- Preview text adds context
- Conversational, not salesy
- Respect the subscriber relationship

### Newsletter Ads
- Credential-led (borrow host credibility fast)
- One striking stat or claim
- Clear, specific CTA

### Taboola
- More curiosity-driven
- Bolder claims OK
- 35-45 chars optimal
- Authority quotes and shocking stats

---

## The Step-by-Step Creation Process {#creation-process}

### Step 1: Extract Copy Assets
Create a Copy Assets document from the source material (see Translation Process above).

### Step 2: Create Hook Variations (15-30)
Use the 15 formulas. Vary by angle:
- Authority-led
- Outcome-led
- Mechanism-led
- Social proof-led
- Pain-led (validation-style, not hype)
- Curiosity-led
- Contrast-led

### Step 3: Match Hooks to Primary Text Structures
- Authority hook → Authority Introduction
- Outcome hook → PAS
- Social proof hook → Social Proof Story
- Curiosity hook → Curiosity Gap Tease
- Benefits hook → Bullet-Point Benefits

### Step 4: Write Primary Text Variations
Per platform:
- Facebook: 2-3 long-form (300-500 words) + 5-8 short-form (under 125 chars)
- GDN: Long Headlines + Descriptions
- Twitter: Organic tweets + promoted
- Substack: Subject + Preview pairs
- Newsletter Ads: Headline + Body + CTA

### Step 5: Optimize for Character Limits
Techniques:
- Cut weak words: "really," "very," "quite," "just," "simply"
- Contractions: "you will" → "you'll"
- Numerals: "fifteen" → "15"
- Replace phrases: "in order to" → "to"
- Cut redundancies: "end result" → "result"

### Step 6: Validate Characters
Run `validate_copy.py` with all copy. Fix failures. Re-run until 100%.

### Step 7: Organize by Platform
Package all copy by platform with correct counts per deliverable type.

### Step 8: Deliver in Correct Format
Working format during revision. Final code-block format after approval.

---

## Advanced Techniques {#advanced-techniques}

### 1. The Contrarian Open
Start with what everyone else is saying, then demolish it:
"Everyone says AI is a tool. Add it to your workflow. That's Lie #1."

### 2. The False Belief Breakdown
```
And it has nothing to do with:
- Better prompts
- More expensive tools
- Hiring an AI expert
The real problem is architectural.
```

### 3. The Peer Emotional Confirmation Stack
Name-drop multiple peers confirming the same emotion:
"Todd Brown. Mike Filsaime. Russell Brunson. Donnie French. All said the same thing: 'This feels like when I first got online.'"

### 4. The Inversion Close
"The real risk isn't the investment. The real risk is staying where you are while the window closes."

### 5. The Anti-Guarantee as Positioning
"No refund. No guarantee. Rich's 20-year reputation IS the guarantee."

### 6. The Historical Pattern Stack
"Same pattern. Electrification. Computing. Internet. Mobile. AI. Same 7 characteristics. Same winners."

### 7. The "I'm Doing This Anyway" Frame
"Rich is training his team in March regardless. You're pulling up a seat to watch."

### 8. The 88/6 Gap
"88% adopted AI. 6% saw impact. The fortune lives in that gap."

### 9. The Window Clock
"ChatGPT launched Nov 2022. Historical windows are 3-5 years. We're at 3+. Do the math."

### 10. The Phase Transition
"The gap between using AI well and building AI infrastructure isn't incremental. It's a phase transition."
