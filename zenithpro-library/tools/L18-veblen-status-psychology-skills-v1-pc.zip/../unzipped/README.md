# Thorstein Veblen Status Skills
## Strategic Profits / Deep Marketing Thinkers Series

---

## What This Is

7 Claude Code skills built on Thorstein Veblen's status theory (*The Theory of the Leisure Class*, 1899). Veblen's core insight: **consumption is a social act — every purchase positions you relative to your peers.** People don't just buy things for utility. They buy to signal status, maintain social position, and distinguish themselves from the people copying them.

These skills translate that theory into executable marketing intelligence tools that decode the status dynamics in any market.

---

## Installation

**Mac / Linux:**
```bash
chmod +x install.sh
./install.sh
```

**Windows (PowerShell):**
```powershell
.\install.ps1
```

Restart Claude Code after installing.

---

## The 7 Skills

### 1. `/veblen-status-intelligence {market}`
**Map the complete status hierarchy in your market.**
Places 15-20 real players into tiers (Apex, Established, Ascending, Mass), catalogs their status signals, tracks signal decay, and detects counter-signaling. Tells you where YOU sit in the hierarchy — honestly.

### 2. `/veblen-signal-decoder {brand}`
**Decode what a brand's signals ACTUALLY say.**
Reads every visible signal (pricing, design, language, proof, access, associations, presence, absence) and tells you what status story the brand is telling — whether they intend to or not. Catches contradictions between what a brand MEANS to communicate and what it ACTUALLY communicates.

### 3. `/veblen-emulation-tracker {market}`
**Track imitation flows and predict signal migration.**
Maps what's being copied, by whom, from whom, and where each signal sits in the decay cycle. Tracks three flows: upward emulation (copying the tier above), lateral competition (peer arms races), and downward distinction (abandoning signals once they're copied). Predicts what the top tier will adopt next.

### 4. `/veblen-waste-audit {brand}`
**Audit whether your non-functional excess creates prestige or looks performative.**
Scores every element on the workmanship-prestige spectrum. Diagnoses whether your production value, design investment, and conspicuous spending reads as credible quality or try-hard theater. Identifies where SIMPLICITY would increase rather than decrease your prestige.

### 5. `/veblen-price-ladder {offer-structure}`
**Analyze pricing as a status device.**
Each price tier creates a social identity — it tells the market WHO buys at this level. This skill decodes what identity each tier creates, detects where low-end offers collapse premium narrative, identifies Veblen goods (where raising the price increases demand), and recommends restructuring for status coherence.

### 6. `/veblen-display-map {brand-or-community}`
**Map the full vicarious display chain.**
Tracks how status flows from buyer to peers, buyer to founder, community to outsiders, alumni to next cohort. Finds broken links where status stops flowing. Designs display mechanics that make members WANT to signal their participation — without forcing it.

### 7. `/veblen-field-intelligence`
**Master synthesis layer — reads all Veblen outputs simultaneously.**
Cross-layer synthesis that detects convergence zones invisible to individual skills. Produces a unified Status Field Briefing with: convergence map, the Single Move (one highest-leverage action), self-examination mirror, signal timeline, 90-day projection, and risk/opportunity matrix. Run this after running multiple Veblen skills on the same market.

---

## Key Concepts

### Counter-Signaling
When high-status people deliberately signal DOWN to distinguish themselves from the aspirational tier copying them. The billionaire in a plain t-shirt. The elite strategist who doesn't use hype language. Simplicity as the ultimate status signal.

### Signal Decay
Prestige signals have a lifecycle: Exclusive → Aspirational → Saturated → Exhausted. "Application-only" was a premium signal 5 years ago. Now every $47 course uses it. The skills track where every signal sits in this cycle.

### Invidious Comparison
Peer-level competition — measuring yourself against the people in your tier, not the tier above. This is what drives purchasing in masterminds and group programs. Every member is measuring against every other member.

### The Instinct of Workmanship
The tension between "build" and "display." Serious buyers want products that are BOTH genuinely useful AND status markers. Pure prestige repels them. Pure utility fails to trigger the social motivation that drives premium purchasing.

---

## Recommended Starting Sequence

1. **`/veblen-status-intelligence`** — map the hierarchy in your market
2. **`/veblen-signal-decoder`** — audit your own brand's actual signals
3. **`/veblen-waste-audit`** — check if your investment is landing as prestige or waste
4. **`/veblen-field-intelligence`** — synthesize findings into one strategic direction

Then run **`/veblen-price-ladder`** before any pricing decisions, and **`/veblen-display-map`** before any community or referral design.

---

## Works With Girard Skills

If you have the Girard Mimetic Desire Skills installed, the Veblen skills cross-reference them:
- **Girard** explains WHY people want what they want (borrowed desire from models)
- **Veblen** explains HOW they display what they've acquired (status signaling)

Together they answer: what does this market WANT, and how does it SIGNAL what it has? Each Veblen skill includes a Girard Cross-Reference section that activates when Girard outputs exist.

---

## Source

Based on the work of **Thorstein Veblen (1857–1929)** — *The Theory of the Leisure Class* (1899), *The Instinct of Workmanship* (1914), *The Theory of Business Enterprise* (1904).

Part of the Deep Marketing Thinkers series — thinkers who described the real mechanisms behind how desire forms, how decisions get made, and how behaviors spread through populations.

---

*Strategic Profits — Deep Marketing Thinkers Series*
