#!/bin/bash
# ============================================================
# Thorstein Veblen Status Skills — Installer (Mac/Linux)
# Strategic Profits / Deep Marketing Thinkers Series
# ============================================================

SKILLS_DIR="$HOME/.claude/skills"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/skills"

SKILLS=(
  "veblen-status-intelligence"
  "veblen-signal-decoder"
  "veblen-emulation-tracker"
  "veblen-waste-audit"
  "veblen-price-ladder"
  "veblen-display-map"
  "veblen-field-intelligence"
)

echo ""
echo "============================================================"
echo " Thorstein Veblen Status Skills — Installer"
echo " Strategic Profits / Deep Marketing Thinkers Series"
echo "============================================================"
echo ""

# Check Claude Code skills directory exists
if [ ! -d "$SKILLS_DIR" ]; then
  echo "Creating ~/.claude/skills/ directory..."
  mkdir -p "$SKILLS_DIR"
fi

INSTALLED=0
SKIPPED=0

for skill in "${SKILLS[@]}"; do
  if [ -d "$SKILLS_DIR/$skill" ]; then
    echo "  SKIP  $skill  (already installed)"
    ((SKIPPED++))
  else
    cp -r "$SOURCE_DIR/$skill" "$SKILLS_DIR/$skill"
    echo "  OK    $skill"
    ((INSTALLED++))
  fi
done

echo ""
echo "------------------------------------------------------------"
echo "  Installed: $INSTALLED skills"
echo "  Skipped:   $SKIPPED (already present)"
echo "------------------------------------------------------------"
echo ""
echo "NEXT STEP: Restart Claude Code, then try:"
echo "  /veblen-status-intelligence  — map the status hierarchy in your market"
echo "  /veblen-signal-decoder       — decode what a brand's signals actually say"
echo "  /veblen-emulation-tracker    — track imitation flows and signal decay"
echo "  /veblen-waste-audit          — audit whether excess creates prestige or looks performative"
echo "  /veblen-price-ladder         — analyze pricing as a status device"
echo "  /veblen-display-map          — map the vicarious display chain"
echo "  /veblen-field-intelligence   — master synthesis across all Veblen outputs"
echo ""
echo "See README.md for full usage guide."
echo ""
