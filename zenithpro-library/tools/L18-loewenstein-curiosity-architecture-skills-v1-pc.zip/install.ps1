# ============================================================
# George Loewenstein Curiosity & Behavioral Skills — Installer (Windows)
# Strategic Profits / Deep Marketing Thinkers Series
# ============================================================

$SkillsDir = "$env:USERPROFILE\.claude\skills"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceDir = Join-Path $ScriptDir "skills"

$Skills = @(
    "loewenstein-curiosity-architect",
    "loewenstein-empathy-gap-map",
    "loewenstein-risk-as-feelings",
    "loewenstein-anticipation-engine",
    "loewenstein-visceral-audit",
    "loewenstein-information-flow",
    "loewenstein-field-intelligence"
)

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " George Loewenstein Curiosity & Behavioral Skills — Installer" -ForegroundColor Cyan
Write-Host " Strategic Profits / Deep Marketing Thinkers Series" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Create skills directory if it doesn't exist
if (-not (Test-Path $SkillsDir)) {
    Write-Host "Creating ~/.claude/skills/ directory..."
    New-Item -ItemType Directory -Path $SkillsDir -Force | Out-Null
}

$Installed = 0
$Skipped = 0

foreach ($skill in $Skills) {
    $dest = Join-Path $SkillsDir $skill
    if (Test-Path $dest) {
        Write-Host "  SKIP  $skill  (already installed)" -ForegroundColor Yellow
        $Skipped++
    } else {
        $src = Join-Path $SourceDir $skill
        Copy-Item -Path $src -Destination $dest -Recurse
        Write-Host "  OK    $skill" -ForegroundColor Green
        $Installed++
    }
}

Write-Host ""
Write-Host "------------------------------------------------------------" -ForegroundColor Gray
Write-Host "  Installed: $Installed skills" -ForegroundColor Green
Write-Host "  Skipped:   $Skipped (already present)" -ForegroundColor Yellow
Write-Host "------------------------------------------------------------" -ForegroundColor Gray
Write-Host ""
Write-Host "NEXT STEP: Restart Claude Code, then try:" -ForegroundColor Cyan
Write-Host "  /loewenstein-curiosity-architect" -ForegroundColor White
Write-Host "  /loewenstein-empathy-gap-map" -ForegroundColor White
Write-Host "  /loewenstein-risk-as-feelings" -ForegroundColor White
Write-Host "  /loewenstein-anticipation-engine" -ForegroundColor White
Write-Host "  /loewenstein-visceral-audit" -ForegroundColor White
Write-Host "  /loewenstein-information-flow" -ForegroundColor White
Write-Host "  /loewenstein-field-intelligence" -ForegroundColor White
Write-Host ""
Write-Host "See README.md for full usage guide."
Write-Host ""
