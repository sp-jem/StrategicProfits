#!/bin/bash
# Expert Content Processor - Mac/Linux Installer

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$HOME/.claude/skills/expert-content-processor"

echo "========================================"
echo "  Expert Content Processor Installer"
echo "========================================"
echo ""

# Check dependencies
echo "Checking dependencies..."

if ! command -v python3 &>/dev/null; then
    echo "WARNING: python3 not found. Needed for video/audio transcription."
    echo "Install: https://www.python.org/downloads/"
fi

# Create skill directory
mkdir -p "$SKILL_DIR"

# Copy skill
cp "$SCRIPT_DIR/expert-content-processor/SKILL.md" "$SKILL_DIR/SKILL.md"
echo "Installed: $SKILL_DIR/SKILL.md"

echo ""
echo "========================================"
echo "  Installation complete!"
echo "========================================"
echo ""
echo "This skill converts folders of raw content (video, audio, PDFs,"
echo "PowerPoints, Word docs, spreadsheets) into organized markdown."
echo ""
echo "Usage: Tell Claude Code:"
echo '  "Process the content in [folder path]"'
echo '  "Convert everything in [folder] to markdown"'
echo ""
echo "Optional companion skills (install separately if you have them):"
echo "  - video-transcription (for audio/video files)"
echo "  - pdf (for PDF conversion)"
echo "  - pptx (for PowerPoint conversion)"
echo "  - docx (for Word document conversion)"
echo "  - xlsx (for spreadsheet conversion)"
echo ""
echo "The processor works without these but will skip file types"
echo "it can't convert. Install companion skills for full coverage."
