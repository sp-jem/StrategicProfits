# Expert Content Processor - Windows (PowerShell) Installer

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillDir = Join-Path $env:USERPROFILE ".claude\skills\expert-content-processor"

Write-Host "========================================"
Write-Host "  Expert Content Processor Installer"
Write-Host "========================================"
Write-Host ""

# Check dependencies
Write-Host "Checking dependencies..."

try {
    $pyver = python3 --version 2>&1
    Write-Host "Python version: $pyver"
} catch {
    try {
        $pyver = python --version 2>&1
        Write-Host "Python version: $pyver"
    } catch {
        Write-Host "WARNING: Python not found. Needed for video/audio transcription."
        Write-Host "Install: https://www.python.org/downloads/"
    }
}

# Create skill directory
if (-not (Test-Path $SkillDir)) {
    New-Item -ItemType Directory -Path $SkillDir -Force | Out-Null
}

# Copy skill
$Source = Join-Path $ScriptDir "expert-content-processor\SKILL.md"
$Dest = Join-Path $SkillDir "SKILL.md"
Copy-Item $Source $Dest -Force
Write-Host "Installed: $Dest"

Write-Host ""
Write-Host "========================================"
Write-Host "  Installation complete!"
Write-Host "========================================"
Write-Host ""
Write-Host "This skill converts folders of raw content (video, audio, PDFs,"
Write-Host "PowerPoints, Word docs, spreadsheets) into organized markdown."
Write-Host ""
Write-Host "Usage: Tell Claude Code:"
Write-Host '  "Process the content in [folder path]"'
Write-Host '  "Convert everything in [folder] to markdown"'
Write-Host ""
Write-Host "Optional companion skills (install separately if you have them):"
Write-Host "  - video-transcription (for audio/video files)"
Write-Host "  - pdf (for PDF conversion)"
Write-Host "  - pptx (for PowerPoint conversion)"
Write-Host "  - docx (for Word document conversion)"
Write-Host "  - xlsx (for spreadsheet conversion)"
Write-Host ""
Write-Host "The processor works without these but will skip file types"
Write-Host "it can't convert. Install companion skills for full coverage."
