#!/usr/bin/env python3
"""
Claude Deep Research — uses claude.ai session cookie to trigger Deep Research.
Usage: python3 research.py "your research question here"
"""

import sys
import os
import json
import uuid
import urllib.request
import urllib.error

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")

def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)

def get_headers(config):
    cookies = f"sessionKey={config['session_key']}"
    if config.get("cf_clearance"):
        cookies += f"; __cf_clearance={config['cf_clearance']}"
    return {
        "Cookie": cookies,
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Accept": "text/event-stream, application/json",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://claude.ai/new",
        "Origin": "https://claude.ai",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "anthropic-client-platform": "web_claude_ai",
    }

def api_get(url, headers):
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode())

def api_post(url, headers, data):
    body = json.dumps(data).encode()
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(req) as resp:
        return resp.read().decode()

def parse_sse(raw):
    """Parse SSE stream from rendering_mode: messages"""
    result = []
    for line in raw.splitlines():
        if line.startswith("data: "):
            try:
                payload = json.loads(line[6:])
                event_type = payload.get("type", "")
                if event_type == "content_block_delta":
                    delta = payload.get("delta", {})
                    if delta.get("type") == "text_delta":
                        result.append(delta.get("text", ""))
                elif event_type == "completion":
                    result.append(payload.get("completion", ""))
            except json.JSONDecodeError:
                pass
    return "".join(result)

def run_research(query):
    config = load_config()
    headers = get_headers(config)

    print(f"Researching: {query}\n", file=sys.stderr)

    # Get org ID
    orgs = api_get("https://claude.ai/api/organizations", headers)
    org_id = orgs[0]["uuid"] if isinstance(orgs, list) else orgs["uuid"]
    print(f"[org: {org_id[:8]}...]", file=sys.stderr)

    # Create conversation
    conv_url = f"https://claude.ai/api/organizations/{org_id}/chat_conversations"
    conv_data = json.loads(api_post(conv_url, headers, {"name": ""}))
    conv_id = conv_data["uuid"]
    print(f"[conv: {conv_id[:8]}...]", file=sys.stderr)

    # Send message with Deep Research payload
    msg_url = f"https://claude.ai/api/organizations/{org_id}/chat_conversations/{conv_id}/completion"

    payload = {
        "prompt": query,
        "parent_message_uuid": "00000000-0000-4000-8000-000000000000",
        "timezone": "America/New_York",
        "locale": "en-US",
        "model": "claude-opus-4-6",
        "rendering_mode": "messages",
        "attachments": [],
        "files": [],
        "sync_sources": [],
        "personalized_styles": [
            {
                "type": "default",
                "key": "Default",
                "name": "Normal",
                "nameKey": "normal_style_name",
                "prompt": "Normal\n",
                "summary": "Default responses from Claude",
                "summaryKey": "normal_style_summary",
                "isDefault": True
            }
        ],
        "tools": [
            {"type": "web_search_v0", "name": "web_search"},
            {"type": "artifacts_v0", "name": "artifacts"}
        ],
        "turn_message_uuids": {
            "human_message_uuid": str(uuid.uuid4()),
            "assistant_message_uuid": str(uuid.uuid4())
        }
    }

    raw = api_post(msg_url, headers, payload)
    result = parse_sse(raw)
    return result if result else raw[:3000]

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 research.py \"your research question\"")
        sys.exit(1)

    query = " ".join(sys.argv[1:])

    try:
        result = run_research(query)
        print(result)
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"HTTP {e.code}: {body[:500]}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
