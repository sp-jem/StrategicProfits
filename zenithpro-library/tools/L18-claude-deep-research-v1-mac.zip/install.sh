#!/usr/bin/env bash
# Claude Deep Research Skill — Mac/Linux Installer
# Installs the skill into ~/.claude/skills/claude-deep-research/

set -e

SKILL_NAME="claude-deep-research"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/.claude/skills/$SKILL_NAME"

echo ""
echo "======================================"
echo "  Claude Deep Research Skill Installer"
echo "======================================"
echo ""

# Check for python3
if ! command -v python3 &>/dev/null; then
    echo "ERROR: python3 is not installed."
    echo "Install it with: brew install python3"
    echo "Or download from: https://www.python.org/downloads/"
    exit 1
fi

echo "Python 3 found: $(python3 --version)"
echo ""

# Check for Claude Code skills directory
if [ ! -d "$HOME/.claude" ]; then
    echo "ERROR: ~/.claude directory not found."
    echo "Please install Claude Code first: https://claude.ai/claude-code"
    exit 1
fi

# Check for existing installation
if [ -d "$INSTALL_DIR" ]; then
    echo "Existing installation found at: $INSTALL_DIR"
    read -p "Overwrite? (y/N): " CONFIRM
    if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
        echo "Installation cancelled."
        exit 0
    fi
    echo "Backing up existing config..."
    if [ -f "$INSTALL_DIR/config.json" ]; then
        cp "$INSTALL_DIR/config.json" "$INSTALL_DIR/config.json.bak"
        echo "  Saved: $INSTALL_DIR/config.json.bak"
    fi
fi

# Create install directory
mkdir -p "$INSTALL_DIR"

# Copy skill files
echo "Installing files to: $INSTALL_DIR"
cp "$SCRIPT_DIR/SKILL.md"    "$INSTALL_DIR/SKILL.md"
cp "$SCRIPT_DIR/research.py" "$INSTALL_DIR/research.py"

# Only copy config if no existing config (preserve user's session key)
if [ ! -f "$INSTALL_DIR/config.json" ] || [ -f "$INSTALL_DIR/config.json.bak" ]; then
    cp "$SCRIPT_DIR/config.json" "$INSTALL_DIR/config.json"
    echo "  Installed: config.json (template)"
else
    echo "  Kept existing: config.json (preserved your session key)"
fi

# Verify installation
echo "Verifying installation..."
VERIFY_FAILED=0
for f in SKILL.md research.py config.json; do
    if [ ! -f "$INSTALL_DIR/$f" ]; then
        echo "  ERROR: $f not found after install"
        VERIFY_FAILED=1
    else
        echo "  OK: $f"
    fi
done
if [ "$VERIFY_FAILED" -eq 1 ]; then
    echo "ERROR: Installation verification failed."
    exit 1
fi

echo ""
echo "======================================"
echo "  Installation Complete"
echo "======================================"
echo ""
echo "Files installed:"
echo "  $INSTALL_DIR/SKILL.md"
echo "  $INSTALL_DIR/research.py"
echo "  $INSTALL_DIR/config.json"
echo ""
echo "======================================"
echo "  NEXT STEP: Add Your Session Key"
echo "======================================"
echo ""
echo "1. Open claude.ai in Chrome (logged in)"
echo "2. Press Cmd+Option+I to open DevTools"
echo "3. Click: Application > Cookies > https://claude.ai"
echo "4. Find 'sessionKey' and copy its value"
echo "5. Open this file in a text editor:"
echo "   $INSTALL_DIR/config.json"
echo "6. Replace YOUR_SESSION_KEY_HERE with your copied value"
echo ""
echo "After that, restart Claude Code and say:"
echo "  'claude deep research: [your topic]'"
echo ""
echo "Or run directly:"
echo "  python3 $INSTALL_DIR/research.py \"your research question\""
echo ""
