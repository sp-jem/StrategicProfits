# Claude Deep Research Skill for Claude Code

Run Claude's native Deep Research feature directly from Claude Code — no browser required after setup.

---

## What This Does For You

When you click "Deep Research" on claude.ai, Claude spins up an agentic loop that searches the web across dozens of sources, synthesizes findings, and produces a comprehensive research report. It takes 2-10 minutes and produces far more depth than a regular chat response.

This skill brings that exact feature into Claude Code. Once installed, you can say "claude deep research: [your topic]" and Claude Code will authenticate with your claude.ai account, submit the query, and return the full Deep Research output — all without touching a browser.

The skill uses your real claude.ai session (the same one you're already logged into), so you get the same quality output you'd get clicking the button manually, but as part of your Claude Code workflow.

**What it's NOT:** This is not the regular `web_search` API tool, which is shallow single-step search. This is the real multi-step agentic Deep Research — the same feature Anthropic charges Claude Pro subscribers to use.

---

## How It Works

1. You provide a session cookie from your logged-in claude.ai browser tab (one-time setup, takes 30 seconds)
2. The skill authenticates with claude.ai using that cookie
3. It creates a new conversation and submits your query with Deep Research enabled
4. Claude does its full multi-step research and returns the results

See `how-it-works.md` for architecture diagrams.

---

## Requirements

- **Claude Code** installed and running
- **Python 3** (comes pre-installed on Mac; on Windows, download from python.org)
- A **claude.ai account** (free or Pro — Deep Research may require Pro)
- **Google Chrome** (for the one-time cookie setup)

---

## Installation

### Mac (Terminal)

```bash
cd ~/Downloads/claude-deep-research-v1
chmod +x install.sh
./install.sh
```

### Windows (PowerShell)

If you get a script execution error, first run:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

Then install:
```powershell
cd ~/Downloads/claude-deep-research-v1
.\install.ps1
```

---

## What Gets Installed

| File | Location |
|------|----------|
| `SKILL.md` | `~/.claude/skills/claude-deep-research/` |
| `research.py` | `~/.claude/skills/claude-deep-research/` |
| `config.json` | `~/.claude/skills/claude-deep-research/` |

The installer copies these three files. Nothing else is modified.

---

## One-Time Setup: Get Your Session Cookie

After installation, you need to give the skill your claude.ai session key. This takes about 30 seconds.

1. Open **claude.ai** in Chrome and make sure you're logged in
2. Open DevTools: `Cmd + Option + I` (Mac) or `F12` (Windows)
3. Click the **Application** tab
4. In the left sidebar: **Cookies** → click **https://claude.ai**
5. Find the row named **`sessionKey`** — click it
6. The full value appears at the bottom panel. Copy it (starts with `sk-ant-sid01-`)
7. Open `~/.claude/skills/claude-deep-research/config.json` in any text editor
8. Replace `YOUR_SESSION_KEY_HERE` with your copied value
9. Save the file

Your config.json should look like:
```json
{
  "session_key": "sk-ant-sid01-YOURVALUHERE...",
  "cf_clearance": ""
}
```

---

## How to Use

In Claude Code, just say:

```
claude deep research: [your topic]
```

Examples:
```
claude deep research: the latest AI agent frameworks in 2026
claude deep research: Rich Schefren's marketing philosophy and key frameworks
claude deep research: competitive landscape for online course platforms
```

Claude Code will run the research script and return the full Deep Research output. **Expect 2-10 minutes** — this is real multi-step research, not instant search.

You can also run it directly from the terminal:

```bash
python3 ~/.claude/skills/claude-deep-research/research.py "your research question"
```

---

## Refreshing Your Session Cookie

Session keys expire periodically (typically days to weeks). When yours expires, you'll get a 401 or 403 error.

To refresh:
1. Go to claude.ai (still logged in)
2. DevTools → Application → Cookies → copy the new `sessionKey` value
3. Open `~/.claude/skills/claude-deep-research/config.json` and replace the old value

That's it. The skill works again immediately.

---

## Troubleshooting

**"401 Forbidden" or "403 Forbidden" error**
Your session key has expired. Follow the "Refreshing Your Session Cookie" steps above.

**Empty result returned**
The SSE stream returned no text content. Try running the query again — the claude.ai API occasionally returns empty responses on first attempt.

**"python3: command not found" (Mac)**
Install Python 3 via Homebrew: `brew install python3`

**"python: command not found" (Windows)**
Download Python from python.org and check "Add Python to PATH" during installation.

**PowerShell says scripts are disabled (Windows)**
Run this first:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**Skill isn't being recognized by Claude Code**
Restart Claude Code after installation. Skills are loaded at startup.

**Mac-specific:** If you see "Operation not permitted" on install, run Terminal as normal (not root). The installer only writes to `~/.claude/skills/`.

**Windows-specific:** Use `python` not `python3` when running the script manually on Windows.

---

*Claude Deep Research Skill v1*
*Packaged by Strategic Profits*
