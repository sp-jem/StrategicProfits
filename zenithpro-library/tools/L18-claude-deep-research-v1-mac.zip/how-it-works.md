# How Claude Deep Research Works

## Overview

```mermaid
flowchart TD
A[You say: claude deep research topic] --> B[Claude Code reads SKILL.md]
B --> C[Runs research.py with your query]
C --> D[Loads session key from config.json]
D --> E[Authenticates with claude.ai]
E --> F[Creates new conversation]
F --> G[Submits query with web_search tool]
G --> H[Claude Deep Research runs<br>2-10 minutes]
H --> I[Returns full research report]
I --> J[Claude Code displays results]
```

---

## Authentication Flow

```mermaid
flowchart TD
A[config.json has sessionKey] --> B[GET claude.ai/api/organizations]
B --> C{Auth OK?}
C -->|Yes| D[Get org UUID]
C -->|No 401/403| E[Session expired<br>Refresh cookie]
D --> F[POST create conversation]
F --> G[POST send message with tools]
```

---

## Request Payload

What the skill sends to claude.ai (mirrors exactly what your browser sends when you click Deep Research):

```mermaid
flowchart TD
A[research.py builds payload] --> B[model: claude-opus-4-6]
A --> C[rendering_mode: messages]
A --> D[tools: web_search_v0]
A --> E[tools: artifacts_v0]
A --> F[prompt: your query]
B & C & D & E & F --> G[POST to /completion endpoint]
G --> H[SSE stream response]
H --> I[parse_sse extracts text]
```

---

## File Layout After Installation

```mermaid
flowchart TD
A[~/.claude/skills/claude-deep-research/] --> B[SKILL.md<br>Claude Code reads this]
A --> C[research.py<br>Python script that calls claude.ai]
A --> D[config.json<br>Your session key lives here]
C --> D
```

---

## Cookie Lifecycle

```mermaid
flowchart TD
A[First time setup] --> B[Open claude.ai in Chrome]
B --> C[DevTools > Application > Cookies]
C --> D[Copy sessionKey value]
D --> E[Paste into config.json]
E --> F[Skill works]
F --> G{Key expires?}
G -->|Days to weeks later| H[Get 401 error]
H --> B
G -->|Still valid| F
```
