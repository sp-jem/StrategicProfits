# Dispatcher-Manager Agent Installer for Windows
# Adds the orchestration pattern to your Claude Code configuration

$ErrorActionPreference = "Stop"

$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path
$CLAUDE_MD = "$env:USERPROFILE\.claude\CLAUDE.md"

Write-Host ""
Write-Host "==================================" -ForegroundColor Cyan
Write-Host "Dispatcher-Manager Agent Installer" -ForegroundColor Cyan
Write-Host "==================================" -ForegroundColor Cyan
Write-Host ""

# Create .claude directory if needed
if (!(Test-Path "$env:USERPROFILE\.claude")) {
    New-Item -ItemType Directory -Force -Path "$env:USERPROFILE\.claude" | Out-Null
}

# Check if CLAUDE.md exists
$content = ""
if (Test-Path $CLAUDE_MD) {
    Write-Host "Found existing CLAUDE.md" -ForegroundColor Green
    $content = Get-Content $CLAUDE_MD -Raw

    # Check if already installed
    if ($content -match "DISPATCHER/MANAGER MODE") {
        Write-Host "Dispatcher-Manager is already installed in CLAUDE.md" -ForegroundColor Yellow
        $response = Read-Host "Reinstall/update? (y/N)"
        if ($response -ne "y" -and $response -ne "Y") {
            Write-Host "Installation cancelled"
            exit 0
        }
        # Create backup before modifying
        $backupPath = "$CLAUDE_MD.backup"
        Copy-Item $CLAUDE_MD $backupPath
        Write-Host "Backup created: $backupPath" -ForegroundColor Green
        # Remove existing section
        $content = $content -replace '(?s)## DISPATCHER/MANAGER MODE.*?\*The goal is verified, completed work - not supervised steps\.\*\r?\n?', ''
    }
} else {
    Write-Host "Creating new CLAUDE.md"
    $content = "# Claude Code Instructions`n`n"
}

# Append the Dispatcher-Manager section
$dispatcherSection = @"

## DISPATCHER/MANAGER MODE

For complex multi-step projects, invoke the Dispatcher/Manager pattern:

``````
I want to use the Dispatcher/Manager pattern for this project.

Objective: [What you want to accomplish]
Constraints: [Any limitations]
Quality Level: [STANDARD / ELEVATED / CRITICAL]
``````

**What the Manager does:**
- Decomposes objective into task graph
- Spawns persona-optimized sub-agents
- Enforces quality thresholds (70% / 85% / 95%)
- Maintains project state across sessions
- Escalates only when necessary

**Quality Thresholds:**
- STANDARD (70%) - Non-critical auxiliary tasks
- ELEVATED (85%) - Default for important work
- CRITICAL (95%) - Final output, client deliverables

**Persona Library for Sub-Agents:**
- **Dr. Elena Vasquez** - Analytical tasks (research, data)
- **Marcus Chen** - Creative tasks (ideation, breakthroughs)
- **Sarah Okonkwo** - Validation tasks (compliance, flaws)
- **Dr. James Liu** - Research tasks (exhaustive coverage)
- **Dr. Maya Patel** - Synthesis tasks (cross-domain connections)
- **Jack Morrison** - Copywriting tasks (direct response)

**Communication Protocol:**
- ALWAYS provide options + recommendation
- NEVER just ask "what should I do?"
- Report at milestones with clear summaries
- Escalate critical decisions with trade-offs

*The goal is verified, completed work - not supervised steps.*
"@

$content += $dispatcherSection
$content | Out-File -FilePath $CLAUDE_MD -Encoding utf8

# Verify installation
$verifyContent = Get-Content $CLAUDE_MD -Raw
if ($verifyContent -match "DISPATCHER/MANAGER MODE") {
    Write-Host ""
    Write-Host "==================================" -ForegroundColor Green
    Write-Host "Installation Complete!" -ForegroundColor Green
    Write-Host "==================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Added to: $CLAUDE_MD"
} else {
    Write-Host ""
    Write-Host "==================================" -ForegroundColor Red
    Write-Host "WARNING: Installation may have failed" -ForegroundColor Red
    Write-Host "==================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "Could not verify DISPATCHER/MANAGER MODE in $CLAUDE_MD"
    Write-Host "Please check the file manually."
    exit 1
}
Write-Host ""
Write-Host "USAGE:" -ForegroundColor Yellow
Write-Host ""
Write-Host "Start any Claude Code session with:"
Write-Host ""
Write-Host "  I want to use the Dispatcher/Manager pattern for this project."
Write-Host "  Objective: [your goal]"
Write-Host "  Constraints: [limitations]"
Write-Host "  Quality Level: ELEVATED"
Write-Host ""
Write-Host "==================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "For the full agent definition, see AGENT.md in this folder."
Write-Host ""
