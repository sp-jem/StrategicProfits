#!/bin/bash
# Dispatcher-Manager Agent Installer for Mac/Linux
# Adds the orchestration pattern to your Claude Code configuration

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CLAUDE_MD="$HOME/.claude/CLAUDE.md"

echo ""
echo "=================================="
echo "Dispatcher-Manager Agent Installer"
echo "=================================="
echo ""

# Create .claude directory if needed
mkdir -p "$HOME/.claude"

# Check if CLAUDE.md exists
if [ -f "$CLAUDE_MD" ]; then
    echo "Found existing CLAUDE.md"

    # Check if already installed
    if grep -q "DISPATCHER/MANAGER MODE" "$CLAUDE_MD"; then
        echo "Dispatcher-Manager is already installed in CLAUDE.md"
        read -p "Reinstall/update? (y/N) " -n 1 -r
        echo ""
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo "Installation cancelled"
            exit 0
        fi
        # Backup before modifying
        cp "$CLAUDE_MD" "$CLAUDE_MD.backup"
        echo "Backup created: $CLAUDE_MD.backup"
        # Remove existing section (match the full closing line)
        sed -i.bak '/^## DISPATCHER\/MANAGER MODE$/,/^\*The goal is verified, completed work - not supervised steps\.\*$/d' "$CLAUDE_MD"
        rm -f "$CLAUDE_MD.bak"
    fi
else
    echo "Creating new CLAUDE.md"
    echo "# Claude Code Instructions" > "$CLAUDE_MD"
    echo "" >> "$CLAUDE_MD"
fi

# Append the Dispatcher-Manager section
cat >> "$CLAUDE_MD" << 'EOF'

## DISPATCHER/MANAGER MODE

For complex multi-step projects, invoke the Dispatcher/Manager pattern:

```
I want to use the Dispatcher/Manager pattern for this project.

Objective: [What you want to accomplish]
Constraints: [Any limitations]
Quality Level: [STANDARD / ELEVATED / CRITICAL]
```

**What the Manager does:**
- Decomposes objective into task graph
- Spawns persona-optimized sub-agents
- Enforces quality thresholds (70% / 85% / 95%)
- Maintains project state across sessions
- Escalates only when necessary

**Quality Thresholds:**
- STANDARD (70%) - Non-critical auxiliary tasks
- ELEVATED (85%) - Default for important work
- CRITICAL (95%) - Final output, client deliverables

**Persona Library for Sub-Agents:**
- **Dr. Elena Vasquez** - Analytical tasks (research, data)
- **Marcus Chen** - Creative tasks (ideation, breakthroughs)
- **Sarah Okonkwo** - Validation tasks (compliance, flaws)
- **Dr. James Liu** - Research tasks (exhaustive coverage)
- **Dr. Maya Patel** - Synthesis tasks (cross-domain connections)
- **Jack Morrison** - Copywriting tasks (direct response)

**Communication Protocol:**
- ALWAYS provide options + recommendation
- NEVER just ask "what should I do?"
- Report at milestones with clear summaries
- Escalate critical decisions with trade-offs

*The goal is verified, completed work - not supervised steps.*
EOF

# Verify installation
if grep -q "DISPATCHER/MANAGER MODE" "$CLAUDE_MD"; then
    echo ""
    echo "=================================="
    echo "Installation Complete!"
    echo "=================================="
    echo ""
    echo "Added to: $CLAUDE_MD"
else
    echo ""
    echo "=================================="
    echo "WARNING: Installation may have failed"
    echo "=================================="
    echo ""
    echo "Could not verify DISPATCHER/MANAGER MODE in $CLAUDE_MD"
    echo "Please check the file manually."
    exit 1
fi
echo ""
echo "USAGE:"
echo ""
echo "Start any Claude Code session with:"
echo ""
echo '  I want to use the Dispatcher/Manager pattern for this project.'
echo '  Objective: [your goal]'
echo '  Constraints: [limitations]'
echo '  Quality Level: ELEVATED'
echo ""
echo "=================================="
echo ""
echo "For the full agent definition, see AGENT.md in this folder."
echo ""
