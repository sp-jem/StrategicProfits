# How the Copy Modernizer Works

Visual overview of the system architecture and data flow.

---

## Overview: The Three-Layer System

```mermaid
graph TD
A[Your Copy] --> B[Layer 1: Contrast<br>86 surgical rules]
B --> C[Layer 2: Current<br>7 dimensions + 12 principles]
C --> D[Layer 3: Hormozi<br>16 voice rules - optional]
D --> E[Modernized Copy<br>+ Change Log + Scores]
```

Each layer can run independently or as part of the combined `/modernize-all` pipeline.

---

## Layer 1: Contrast (Surgical Replacement)

```mermaid
graph TD
A[Input Copy] --> B[Pattern Scanner]
B --> C{Match found?}
C -->|Yes| D[Apply replacement rule]
C -->|No| E[Keep original text]
D --> F[Log rule ID + change]
E --> F
F --> G{More patterns?}
G -->|Yes| B
G -->|No| H[Output: Clean copy<br>+ Change log]
```

**What it scans for (16 categories):**

```mermaid
graph TD
A[86 Rules] --> B[Headlines H1-H8]
A --> C[Leads L1-L8]
A --> D[Body B1-B14]
A --> E[Urgency U1-U8]
A --> F[CTAs C1-C8]
A --> G[Proof P1-P7]
A --> H[Formatting F1-F6]
A --> I[Bullets BL1-BL7]
A --> J[Rhetorical R1-R6]
A --> K[Tone T1-T8]
A --> L[Email E1-E5]
A --> M[Guarantee GU1-GU4]
A --> N[VSL V1-V4]
A --> O[Story S1-S4]
A --> P[Objection O1-O5]
A --> Q[Offer OP1-OP4]
```

---

## Layer 2: Current (Dimension Analysis)

```mermaid
graph TD
A[Post-Contrast Copy] --> B[Score 7 Dimensions<br>1-5 each]
B --> C{Any below 3?}
C -->|Yes| D[Apply modern patterns<br>for that dimension]
C -->|No| E[Keep as-is]
D --> F[12 Principles Check]
E --> F
F --> G{All pass?}
G -->|Yes| H[Output: Modern copy<br>+ Scores + Principles]
G -->|No| I[Fix failing principles]
I --> H
```

**The 7 Dimensions:**

```mermaid
graph TD
A[7 Shift Dimensions] --> B[D1: Urgency<br>Manufactured vs Authentic]
A --> C[D2: Proof<br>Stacking vs Execution]
A --> D[D3: CTAs<br>Commands vs Instructions]
A --> E[D4: Headlines<br>Dense vs Specific]
A --> F[D5: Objections<br>Confrontational vs Empathetic]
A --> G[D6: Rhythm<br>Dense vs Breathing]
A --> H[D7: Tone<br>Aggressive vs Advisor]
```

---

## Layer 3: Hormozi Voice (Optional)

```mermaid
graph TD
A[Post-Current Copy] --> B{Audience fits<br>Hormozi voice?}
B -->|Yes| C[Apply 16 voice rules]
B -->|No| D[Skip - note in output]
C --> E[52 vocabulary swaps]
C --> F[22 transition replacements]
C --> G[Cadence adjustment]
E --> H[Output: Voice-polished copy]
F --> H
G --> H
```

---

## Conflict Resolution (modernize-all)

When rules from different layers apply to the same text:

```mermaid
graph TD
A[Conflict Detected] --> B{Contrast vs Current?}
B -->|Disagree| C[Current wins<br>broader pattern]
B -->|Agree| D[Both apply]
A --> E{Current vs Hormozi?}
E -->|Disagree| F[Current wins<br>general modern]
E -->|Agree| G[Both apply]
A --> H{All three?}
H --> I[Most are complementary<br>True conflicts are rare]
```

---

## File Structure

```mermaid
graph TD
A[~/.claude/skills] --> B[modernize-contrast]
A --> C[modernize-current]
A --> D[modernize-hormozi]
A --> E[modernize-all]
B --> B1[SKILL.md]
B --> B2[references]
B2 --> B3[replacement-rules.md<br>86 rules]
B2 --> B4[arena-analysis.md]
C --> C1[SKILL.md]
C --> C2[references]
C2 --> C3[modern-patterns.md<br>12 principles + 7 dims]
C2 --> C4[dated-patterns.md<br>85 patterns with IDs]
C2 --> C5[before-after-examples.md<br>16 examples]
D --> D1[SKILL.md]
D --> D2[references]
D2 --> D3[voice-patterns.md<br>16 rules + 52 vocab + 22 transitions]
E --> E1[SKILL.md]
E --> E2[references]
E2 --> E3[merged-rules.md<br>122 rules + conflict table]
E2 --> E4[cross-reference-matrix.md]
```
