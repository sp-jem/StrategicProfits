# Copy Modernizer v1.0

Modernizes any direct response copy from "sounds like 2010" to "sounds like 2026" -- without gutting the strategic architecture.

---

## What This Does For You

If you've ever gotten copy from the arena (or written it yourself, or hired a copywriter), and it came back sounding like an infomercial -- ALL CAPS emphasis, "Dear Friend" openers, "ACT NOW!" buttons, fake countdown timers -- this skill system fixes that.

It preserves every proof point, every objection handled, every belief shift, every story. It only changes the **surface language**: the word choices, formatting, tone markers, and delivery style that make copy sound dated.

The system includes 4 skills that can be used individually or together:

1. **modernize-contrast** -- Surgical pattern replacement. Finds specific dated patterns (86 rules across 16 categories) and replaces them with modern equivalents. The safest, most conservative option.
2. **modernize-current** -- Full dimension analysis. Scores your copy on 7 dimensions and 12 principles, then rewrites anything scoring below 3/5. The most thorough single-pass option.
3. **modernize-hormozi** -- Voice transformation. Rewrites in Alex Hormozi's specific voice (third-grade words, short/long cadence, math-based urgency). Optional -- only use when the audience fits.
4. **modernize-all** -- Three-pass pipeline combining all three in priority order (Contrast first, Current second, Hormozi optional third). The most comprehensive option.

---

## How It Works

Each skill reads your copy, analyzes it against its reference library, and rewrites the surface language while preserving the persuasion architecture underneath.

- **Contrast** uses 86 find-and-replace rules organized by copy element (headlines, leads, body, urgency, CTAs, proof, formatting, bullets, rhetorical patterns, tone, email, guarantees, VSL, stories, objections, offers)
- **Current** scores against 7 shift dimensions (Urgency, Proof, CTAs, Headlines, Objections, Rhythm, Tone) and verifies against 12 modern copy principles
- **Hormozi** applies 16 voice rules with 52 vocabulary replacements and 22 transition patterns
- **All** runs the three in sequence with a conflict resolution system

Every change is logged with a rule ID so you can audit exactly what changed and why.

---

## Installation

### Mac (Terminal)

```bash
cd ~/Downloads/copy-modernizer-v1
chmod +x install.sh
./install.sh
```

### Windows (PowerShell)

```powershell
cd $env:USERPROFILE\Downloads\copy-modernizer-v1
.\install.ps1
```

If you get an execution policy error on Windows:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

## What Gets Installed

All 4 skill folders are copied to `~/.claude/skills/`:

```
~/.claude/skills/
  modernize-contrast/
    SKILL.md
    references/replacement-rules.md
    references/arena-analysis.md
  modernize-current/
    SKILL.md
    references/modern-patterns.md
    references/dated-patterns.md
    references/before-after-examples.md
  modernize-hormozi/
    SKILL.md
    references/voice-patterns.md
  modernize-all/
    SKILL.md
    references/merged-rules.md
    references/cross-reference-matrix.md
```

No API keys needed. No external dependencies. Just Claude Code.

---

## How to Use

### Quick Start (Most Common)

Paste your copy into Claude Code and type:

```
/modernize-all
```

Or provide a file path:

```
/modernize-all path/to/your-copy.md
```

### Individual Skills

```
/modernize-contrast    # Surgical replacements only (safest)
/modernize-current     # Full dimension analysis (most thorough)
/modernize-hormozi     # Hormozi voice (use when audience fits)
```

### Which One Should I Use?

| Situation | Use This |
|-----------|----------|
| Just want to clean up dated patterns quickly | `/modernize-contrast` |
| Want the most modern-sounding result | `/modernize-current` |
| Writing for a Hormozi-style audience | `/modernize-hormozi` |
| Want the most comprehensive pass | `/modernize-all` |
| Not sure | `/modernize-all` (it handles everything) |

### What You Get Back

1. **Section A: Modernized Copy** -- Full rewritten version, ready to use
2. **Section B: Change Log** -- Every change with rule ID, original text, and replacement
3. **Section C: Scores** -- Before/after dimension scores (1-5 scale)
4. **Section D: Remaining Issues** -- Anything that still needs manual attention

---

## Requirements

- Claude Code installed and working
- That's it. No API keys, no external services, no dependencies.

---

## Troubleshooting

**"Skill not found" when typing /modernize-all:**
- Make sure the installation completed successfully
- Check that the folders exist at `~/.claude/skills/modernize-all/`
- Restart Claude Code after installation

**Output seems too conservative (not enough changes):**
- Use `/modernize-current` or `/modernize-all` instead of `/modernize-contrast`
- Contrast is intentionally conservative -- it only replaces specific patterns

**Output changes too much (lost the original voice):**
- Use `/modernize-contrast` for the lightest touch
- The change log shows every modification -- you can revert specific changes

**Hormozi voice doesn't fit my brand:**
- Skip `/modernize-hormozi` entirely
- When using `/modernize-all`, the Hormozi pass is automatically skipped if it doesn't fit the copy's tone

**Mac-specific:**
- If `chmod +x install.sh` fails, try: `bash install.sh`

**Windows-specific:**
- If execution policy blocks the installer: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`
- Use PowerShell (not Command Prompt) to run the installer

---

*Packaged by Rich Schefren - Strategic Profits*
