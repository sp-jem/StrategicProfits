# Dated Copy Patterns to Detect

These patterns signal 2005-2015 era direct response copywriting. When found, replace with the corresponding modern pattern from `modern-patterns.md`.

**Version:** 2.0 | **Patterns:** 85 | **Categories:** 12
**Cross-reference:** Each pattern has a unique ID (DP-XX-#) for change log tracking. Modern replacements reference corresponding contrast rules (H1-H8, etc.) from `replacement-rules.md`.

---

## Category 1: Headlines (DP-H1 through DP-H9)

| ID | Pattern | Example | Why It's Dated | Modern Replacement | Contrast Rule |
|----|---------|---------|----------------|--------------------|---------------|
| DP-H1 | ALL CAPS headline | "EXPOSED: The Secret System That..." | Reads as shouting or spam in 2026 | Sentence case. Word choice carries weight. | H1 |
| DP-H2 | "Attention [Audience]!" opener | "Attention Entrepreneurs!" | Nobody responds to being addressed like a PA announcement | Just start talking to them. No announcement needed. | H8 |
| DP-H3 | "Discover The Secret/Little-Known..." | "Discover The Little-Known Secret To..." | "Secret" triggers skepticism; readers have seen 10,000 of these | State what you found and how: "What I found after 2,400 split tests" | H6 |
| DP-H4 | "How To [X] In Just [Y] Days!" | "How To Build A 6-Figure Business In Just 30 Days!" | Unrealistic timeframes without qualification read as hype | Specific claims with real timelines: "went from $12K to $89K in 7 months" | H5 |
| DP-H5 | "WARNING: Don't [X] Until..." | "WARNING: Don't Start A Business Until You Read This" | WARNING is a spam trigger, reads as manufactured alarm | Drop the label. Start with the information. | H8 |
| DP-H6 | Dense single-line headline doing all the work | "How I Went From A Desperate Nerd To Making $10K/Month And How You Can Too" | Modern copy splits this into headline + subheading | 1-2 lines max. Use subhead for expansion. | H3 |
| DP-H7 | "What Every [X] Needs To Know About [Y]" | "What Every Coach Needs To Know About Client Acquisition" | Vague knowledge-gap framing | Concrete cost: "If you're doing [X], this is probably costing you [$specific]" | H5 |
| DP-H8 | Forbidden knowledge / conspiracy framing | "The Secret [Industry] Doesn't Want You to Know" | Triggers eye-rolls from sophisticated audiences | Direct statement: "I tested 340 campaigns. Here's what works." | H6 |
| DP-H9 | Curiosity gap clickbait | "You Won't Believe What Happened Next" | Readers have been burned by clickbait; creates distrust | State the surprising thing directly. | H7 |

## Category 2: Leads / Openings (DP-L1 through DP-L9)

| ID | Pattern | Example | Why It's Dated | Modern Replacement | Contrast Rule |
|----|---------|---------|----------------|--------------------|---------------|
| DP-L1 | "Dear Friend" / "Dear Fellow Entrepreneur" | Any formal salutation | Signals form letter / mass-produced | Skip salutation. Start talking. | L6 |
| DP-L2 | "If you're like most [X], you're probably..." | "If you're like most entrepreneurs, you're probably struggling..." | Patronizing; assumes reader needs to be told their own situation | "You already know [specific thing]." Assume intelligence. | L5 |
| DP-L3 | "Imagine waking up to..." | "Imagine waking up to passive income flowing into your account" | Hypothetical dream scenes feel like manipulation | Specific real scene: "Last Tuesday, I opened my laptop and..." | R5 |
| DP-L4 | "What if I told you there was a way..." | "What if I told you there was a way to double your revenue?" | Just tell them. Skip the preamble. | Tell them there IS a way. State it. | R2, R6 |
| DP-L5 | "I need to make a confession..." | "I need to make a confession about my marketing results" | Theatrical | Direct admission: "I screwed this up for two years." | L4 |
| DP-L6 | Triple rhetorical question opener | "Are you tired of...? Have you tried...? What if...?" | Multiple questions feel like a sales script | One statement that names the situation. | L8, R1 |
| DP-L7 | Manufactured "dark night of the soul" opener | "It was 3 AM and I was about to lose everything..." | Overdone origin story template | Real moment with specific detail, or skip it. | V3 |
| DP-L8 | "I was skeptical at first, but..." | Used in both leads and testimonials | Everyone's skeptical. No one cares. | Start with the result, then explain. | L7, S1 |
| DP-L9 | "They said it couldn't be done..." / accusation opening | "The gurus told you it's about discounts..." | Reads as adversarial and conspiratorial | Open with a specific scene or direct insight. | L1 |

## Category 3: Body Copy Filler (DP-B1 through DP-B11)

| ID | Pattern | Example | Why It's Dated | Modern Replacement | Contrast Rule |
|----|---------|---------|----------------|--------------------|---------------|
| DP-B1 | "But that's not all..." | Transition to next section/bonus | Infomercial cadence | Just present the next thing. | B14, R4 |
| DP-B2 | "Here's the shocking truth..." | "Here's the shocking truth about email marketing" | "Shocking" is never shocking to modern readers | "Here's what actually happened." | B6 |
| DP-B3 | "The fact of the matter is..." | Any usage | Pure filler phrase | Cut it. Start with the fact. | B10 |
| DP-B4 | "Listen, I'm going to level with you..." | Before a supposedly honest statement | Announcing honesty implies previous dishonesty | Just be honest. Don't announce it. | B12 |
| DP-B5 | "You see, the problem is..." | Before stating a problem | "You see" reads as condescending | State the problem directly. | B11 |
| DP-B6 | "Now, I know what you're thinking..." | Before objection handling | Overused mind-reading frame | "The obvious question is [X]. Fair." | B13 |
| DP-B7 | "Let me explain..." / "Allow me to demonstrate..." | Before an explanation | Just explain. Don't announce it. | P2 |
| DP-B8 | "Here's the thing about [X] most people don't get:" | Carlton-derived opener | Overused to the point of cliche. Once per piece max. | B9 |
| DP-B9 | Escalation language ("even crazier", "even more incredible") | "And then I did something even crazier:" | Feels manufactured, erodes trust | State the next fact plainly. | B2 |
| DP-B10 | "Not [X]. Not [Y]. BUT [Z]!" triple reveal | "Not a chatbot. Not a tool. But a COMPLETE SYSTEM!" | Infomercial construction | One contrast: "Not X. Instead, Y." | B3 |
| DP-B11 | "Everything changed" / "That's when it all clicked" (repeated) | Used 3+ times in a single piece | Once max. More is lazy. | Specific: "I went from [X] to [Y]." | B7, S3 |

## Category 4: Emphasis / Formatting (DP-F1 through DP-F7)

| ID | Pattern | Example | Why It's Dated | Modern Replacement | Contrast Rule |
|----|---------|---------|----------------|--------------------|---------------|
| DP-F1 | ALL CAPS for emphasis | "This is ABSOLUTELY the most POWERFUL system" | Use **bold** instead. CAPS = shouting | Bold for selective emphasis. | B1, F1 |
| DP-F2 | Multiple exclamation points | "This changes everything!!!" | One max. Zero is better. Period = confidence. | Period. Let content create excitement. | T1 |
| DP-F3 | Scare quotes around "gurus" / "experts" | The so-called "gurus" | Reads as bitter/conspiratorial in 2026 | Name specific people or don't reference. | L3 |
| DP-F4 | Long dense paragraphs (5+ sentences) | 8+ lines with no break | Max 3 lines on mobile. | 1-3 sentences per paragraph. | F2 |
| DP-F5 | Underlining for emphasis | Underlined text in body copy | Bold only. Underlines look like broken links. | **Bold text** only. | F4 |
| DP-F6 | Red text / yellow highlight / rainbow colors | Multiple colors for emphasis | Looks like spam. | Single accent color max. Use formatting hierarchy. | F5 |
| DP-F7 | Dense bullet stacks (20+ items) | Unbroken wall of 30 bullets | Diminishing returns after 12. | Group under subheads, 7-12 per group. | F6 |

## Category 5: Urgency / Scarcity (DP-U1 through DP-U9)

| ID | Pattern | Example | Why It's Dated | Modern Replacement | Contrast Rule |
|----|---------|---------|----------------|--------------------|---------------|
| DP-U1 | Resetting countdown timer | Timer that resets on page reload | Everyone knows this is fake | Tie to real event or remove. | U6 |
| DP-U2 | "Only [X] spots left!" without evidence | "Only 7 spots remaining!" | Universal skepticism | Explain the cap: "50 max because I review everyone's work." | U7 |
| DP-U3 | "This offer expires at midnight!" | Arbitrary deadline | Needs genuine business reason | Real timeline: "Enrollment closes March 10 because cohort starts March 15." | U1 |
| DP-U4 | "I may never offer this again" | False scarcity | They always offer it again | "Next enrollment opens in April." | U1 |
| DP-U5 | "The price DOUBLES tomorrow!" | Without structural reason | Needs real explanation | State the real price schedule and why. | U1 |
| DP-U6 | "Don't be left behind!" | FOMO language | Replace with specific opportunity cost | "Your competitors are already doing this." | U8 |
| DP-U7 | "Act now or lose out forever!" | Manufactured permanence | Nothing is permanent; readers know it | State what happens if they wait, honestly. | U4 |
| DP-U8 | "The clock is ticking!" | Generic time pressure | Needs specifics | "48 hours. Setup takes 4." | U2 |
| DP-U9 | "Not because of some fake deadline" | Defending urgency | If you have to say it's not fake, they already suspect | Just state the real reason. | U5 |

## Category 6: CTAs (DP-C1 through DP-C8)

| ID | Pattern | Example | Why It's Dated | Modern Replacement | Contrast Rule |
|----|---------|---------|----------------|--------------------|---------------|
| DP-C1 | "ACT NOW!" | Any urgent command CTA | Replace with outcome-focused instruction | "Here's what to do next." | C1 |
| DP-C2 | "CLICK HERE NOW!" | Generic imperative button | Specify what happens | "Get the Framework" / "Start my free trial" | C7 |
| DP-C3 | "Don't miss out on this incredible opportunity!" | Hype CTA | "If this makes sense for where you are, [action]" | C3 |
| DP-C4 | "You literally have NOTHING to lose!" | Over-promising risk reversal | "If it doesn't work, I'll refund you. You keep everything." | GU2 |
| DP-C5 | "Click the button below RIGHT NOW!" | Commanding + urgency | "Scroll down. You'll see the signup form." | C1 |
| DP-C6 | Multiple stacked CTAs with escalating urgency | Each button more aggressive | Consistent calm CTAs throughout | C8 |
| DP-C7 | "CLAIM YOUR SPOT!" / command-structure buttons | Power verbs on buttons | "See if this is right for you" / "Join now" | C6 |
| DP-C8 | "Start [dreaming/winning/printing money]!" | Cliche close | Specific first step: "Start with Module 1" | C4 |

## Category 7: Proof / Testimonials (DP-P1 through DP-P8)

| ID | Pattern | Example | Why It's Dated | Modern Replacement | Contrast Rule |
|----|---------|---------|----------------|--------------------|---------------|
| DP-P1 | Vague testimonials | "This changed my life!" -- John D. | Need full name, situation, specific result | Named case study with metrics. | P4 |
| DP-P2 | Stacking 20+ testimonials | Wall of quotes | 3-5 strong case studies outperform 20 generic | Quality over quantity. | P6 |
| DP-P3 | Unverifiable income claims | "Students have made millions" | Specific, named, time-bounded results only | Include baseline, timeline, effort, context. | P7 |
| DP-P4 | Logo wall without context | "As seen in Forbes, CNN, Inc..." | Needs what was said, not just logos | "I wrote about this for Inc. [link]" | P5 |
| DP-P5 | Authority through assertion | "I'm one of the world's leading experts" | Show don't tell | Specific numbers: "2,400 split tests across 340 campaigns" | T8 |
| DP-P6 | "Thousands of satisfied customers" | Vague aggregate social proof | Specific: "487 people currently in the community" | P4 |
| DP-P7 | "PROOF THIS ISN'T JUST THEORY" header | Defensive proof framing | "Here's what happened." Or just go into the case study. | P1 |
| DP-P8 | "But don't just take my word for it..." | Separating proof from pitch | Weave proof into the narrative. | P3 |

## Category 8: Bullets / Fascinations (DP-BL1 through DP-BL7)

| ID | Pattern | Example | Why It's Dated | Modern Replacement | Contrast Rule |
|----|---------|---------|----------------|--------------------|---------------|
| DP-BL1 | "The AMAZING secret to..." | Adjective-loaded fascination | "How to [specific outcome] (page 47)" | BL1 |
| DP-BL2 | "How to INSTANTLY..." | Impossible speed claims | "The fastest path to [X] I've found" | BL2 |
| DP-BL3 | "The #1 mistake that's KILLING your..." | Impersonal + hyperbolic | "The mistake I kept making until [specific moment]" | BL3 |
| DP-BL4 | "Little-known technique..." | Mystery-based bullets | "Something I learned from [specific source]" | BL4 |
| DP-BL5 | 30+ bullets stacked | Diminishing returns | 7-12 bullets, each doing real work | BL5 |
| DP-BL6 | "And much, MUCH more!" | End of bullet list | End with your strongest bullet | BL5 |
| DP-BL7 | Adjective stacking ("INCREDIBLE, PROVEN, POWERFUL") | Multiple superlatives per bullet | One specific claim per bullet. | BL6 |

## Category 9: Group / Binary Patterns (DP-G1 through DP-G4)

| ID | Pattern | Example | Why It's Dated | Modern Replacement | Contrast Rule |
|----|---------|---------|----------------|--------------------|---------------|
| DP-G1 | "Group A vs Group B" binary | "Group A stays broke. Group B gets rich." | Single most dated arena pattern | Tell ONE person's story. | G1 |
| DP-G2 | "Which group will you be in?" | Close using group binary | Specific next-step instruction | G2 |
| DP-G3 | Rigged comparison | One group obviously the loser | Acknowledge old way was reasonable. | G3 |
| DP-G4 | "There are two types of people..." | False dichotomy | Real situations are nuanced. | G1 |

## Category 10: Tone / Voice (DP-T1 through DP-T9)

| ID | Pattern | Example | Why It's Dated | Modern Replacement | Contrast Rule |
|----|---------|---------|----------------|--------------------|---------------|
| DP-T1 | "You deserve..." | "You deserve financial freedom" | Aspirational language triggers skepticism | Direct address: "You're probably thinking..." | T5 |
| DP-T2 | Formal/professorial tone | "It is imperative that one considers..." | Conversational: "Here's what you need to think about" | T7 |
| DP-T3 | Stage-performative voice | Reads like a keynote speech | Write like talking to one person | P1 |
| DP-T4 | "My friend" / "My dear reader" | Forced intimacy | Just talk to them directly | L6 |
| DP-T5 | "You owe it to yourself" | Guilt-based motivation | State the outcome; let them decide | T5 |
| DP-T6 | Power verbs: "DISCOVER" / "UNLEASH" / "UNLOCK" | Marketing-speak | Plain verbs: "learn", "use", "get" | T2 |
| DP-T7 | "Revolutionary" / "Groundbreaking" / "Game-changing" | Unsupported superlatives | "It's the best I've found" | T3 |
| DP-T8 | Manufactured enthusiasm ("I'm SO excited!") | Performative emotion | Matter-of-fact: "This outperformed everything else." | T4 |
| DP-T9 | Marketing jargon ("leverage", "optimize", "monetize") | Inside-baseball language | Plain words: "use", "fix", "make money from" | T7 |

## Category 11: Email Patterns (DP-E1 through DP-E5)

| ID | Pattern | Example | Why It's Dated | Modern Replacement | Contrast Rule |
|----|---------|---------|----------------|--------------------|---------------|
| DP-E1 | Hard-close every email | "BUY NOW before midnight!" | Daily value > occasional hard sell | Soft CTA when it serves content. | E1 |
| DP-E2 | Hype subject lines | "REVEALED: The $10M Secret To..." | Signals spam | Conversational: "weird thing happened yesterday" | E2 |
| DP-E3 | Email-as-sales-letter | 2,000-word email with full offer | Save full pitch for sales page | 200-word story + link. | E3 |
| DP-E4 | "Dear [First Name]," formal opening | Formal email greeting | No salutation, or casual opener. | E4 |
| DP-E5 | Multiple CTAs per email | 5 different links | One link, one action. | E5 |

## Category 12: Offer / Guarantee (DP-O1 through DP-O7)

| ID | Pattern | Example | Why It's Dated | Modern Replacement | Contrast Rule |
|----|---------|---------|----------------|--------------------|---------------|
| DP-O1 | Value stacking with inflated prices | "Module 1 ($2,997 value!)" | Readers don't believe it | State what each component DOES. | OP1 |
| DP-O2 | Price drop sequence | "Not $10,000... Not $5,000..." | Transparent pricing preferred | State price directly with one real comparison. | OP2 |
| DP-O3 | 8-12 bonuses with inflated values | 10 bonuses = "$27,000 in value" | 2-3 bonuses that earn their place. | OP3 |
| DP-O4 | Time-triggered artificial bonuses | "Order in next 15 minutes for bonus!" | If it's part of the offer, just include it. | OP4 |
| DP-O5 | ALL CAPS guarantee language | "RISK-FREE IRON-CLAD GUARANTEE!!!" | State guarantee plainly. | GU1 |
| DP-O6 | "You have NOTHING to lose!" | Over-promising risk reversal | Acknowledge time investment; state specific terms. | GU2 |
| DP-O7 | "Double/triple your money back" | Unbelievable guarantee | Simple, credible refund terms. | GU4 |

---

## Quick Reference: Pattern Count

| Category | Patterns | IDs |
|----------|----------|-----|
| Headlines | 9 | DP-H1 through DP-H9 |
| Leads/Openings | 9 | DP-L1 through DP-L9 |
| Body Copy Filler | 11 | DP-B1 through DP-B11 |
| Emphasis/Formatting | 7 | DP-F1 through DP-F7 |
| Urgency/Scarcity | 9 | DP-U1 through DP-U9 |
| CTAs | 8 | DP-C1 through DP-C8 |
| Proof/Testimonials | 8 | DP-P1 through DP-P8 |
| Bullets/Fascinations | 7 | DP-BL1 through DP-BL7 |
| Group/Binary | 4 | DP-G1 through DP-G4 |
| Tone/Voice | 9 | DP-T1 through DP-T9 |
| Email | 5 | DP-E1 through DP-E5 |
| Offer/Guarantee | 7 | DP-O1 through DP-O7 |
| **TOTAL** | **85** | |
