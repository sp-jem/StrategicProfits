# Modern Copy Patterns Library

Synthesized from analysis of current (2024-2026) high-converting direct response copy across Hormozi, Brunson, Suby, Todd Brown, Stefan Georgi, Ben Settle, and the broader business/coaching market.

**Version:** 2.0 | **Cross-references:** All dimensions link to `dated-patterns.md` (DP-XX) and `replacement-rules.md` (rule IDs)

---

## The 12 Modern Copy Principles

| ID | Principle | Test Question | Dated Patterns It Fixes |
|----|-----------|---------------|------------------------|
| P1 | Sound like a person talking, not a copywriter writing | Would you say this out loud to a friend? | DP-T2, DP-T3, DP-T4, DP-L1 |
| P2 | Every sentence earns its place | Does removing this sentence lose proof, clarity, or emotional resonance? | DP-B1, DP-B3, DP-B4, DP-B7 |
| P3 | Specificity as credibility | Are there exact numbers, named people, real timelines? | DP-P1, DP-P3, DP-P5, DP-P6, DP-H4 |
| P4 | Admit what's hard, limited, or failed | Does the copy acknowledge at least one struggle or limitation? | DP-T1, DP-T5, DP-T8 |
| P5 | One idea per paragraph, max 3 lines on mobile | Does any paragraph contain two unrelated points? | DP-F4 |
| P6 | Bold for emphasis, not CAPS | Is ALL CAPS used anywhere? Replace with bold. | DP-F1, DP-H1 |
| P7 | Real urgency only | Is every deadline tied to a genuine business constraint? | DP-U1 through DP-U9 |
| P8 | CTA = instructions, not commands | Does the CTA tell them what happens next, step by step? | DP-C1 through DP-C8 |
| P9 | Proof through process, not just outcomes | Does proof show HOW the result was achieved, not just THAT it was? | DP-P1, DP-P3 |
| P10 | Anti-hype as trust signal | Does the copy actively reject at least one inflated promise? | DP-T6, DP-T7, DP-H3, DP-H8 |
| P11 | One story, one point, under 200 words | Does any story exceed 200 words or try to make multiple points? | DP-B11 |
| P12 | Designed for two reading speeds | Does the skim path (headline > subheads > bold > bullets > CTA) tell a complete story? | DP-F4, DP-F7 |

---

## 7 Shift Dimensions

### Dimension 1: Urgency
**Dated position:** Manufactured (fake deadlines, artificial scarcity, resetting countdown timers)
**Modern position:** Authentic (real enrollment windows, genuine capacity limits, opportunity cost framing)
**Dated patterns:** DP-U1 through DP-U9

**Modern urgency patterns:**
- Real scarcity with real reasons: "I cap at 50 because I do weekly reviews of everyone's work"
- Opportunity cost: "Every month you're running this manually costs you about 40 hours"
- Competitive gap: "Your competitors are already doing this -- not all of them, but the ones growing fastest"
- Status quo pain: "You can keep doing what you're doing. It's working okay. The question is whether okay is enough"
- Reverse deadline framing: Put the reason FIRST, then the deadline
- Math-based urgency (Hormozi pattern): "Every hour you spend on [unprofitable thing] is an hour not spent on [profitable thing]"

**Real-world example (from Perplexity Q2 research):**
> Classic 2005 email: "WARNING: Slots Fill Fast -- Click Below Now Before This $597 Program Reaches Capacity."
> Modern 2025 equivalent: "Early-bird pricing of $297 ends January 31 -- $497 after that date."

### Dimension 2: Proof
**Dated position:** Testimonial stacking (quantity over quality, vague attribution)
**Modern position:** Execution proof (case studies, process documentation, real-time data)
**Dated patterns:** DP-P1 through DP-P8

**Modern proof patterns:**
- Named, specific social proof: "Sarah Chen used this to go from $12K/mo to $89K/mo in 7 months. She sells handmade ceramics on Shopify."
- Screenshot/artifact proof: References to real, verifiable artifacts (Stripe screenshots, Analytics)
- Process proof: "Here's the actual spreadsheet I used. Column A is what I tried. Column B is what happened."
- Damaging admissions: "This takes about 3 weeks to see results. If you need something tomorrow, this isn't it."
- Specific case studies over generic testimonials: Before-state, what was broken, what changed, after-state with numbers
- Mechanism proof (Stefan Georgi's RMBC pattern): Explain WHY the solution works, not just THAT it works

**Real-world example (from Perplexity Q2 research):**
> Classic 2008: "Real Success Stories: John increased his income by 300% in just 6 months!"
> Modern 2025: "Case Study: Michael Chen, Digital Marketing Manager. 156 qualified leads in month one (up from 12/month baseline). Conversion rate improved from 8% to 19%. Customer acquisition cost decreased from $89 to $31. View his LinkedIn profile here."

### Dimension 3: CTAs
**Dated position:** Command-based ("ACT NOW!", "CLICK HERE!", "Don't miss out!")
**Modern position:** Outcome-focused instructions ("Get the Framework", "Book Your Strategy Call")
**Dated patterns:** DP-C1 through DP-C8

**Modern CTA patterns:**
- Specify what happens next: "Download the Framework" not "Click Here"
- Reduced urgency in button language: "Join the Cohort" not "CLAIM YOUR SPOT"
- Outcome-focused: "Start the Assessment" not "Submit Your Information"
- Include reassurance: "We'll send you access immediately. No spam, just the training."
- Instructions, not commands: "Scroll down. You'll see the signup form. Takes about 30 seconds."
- Calm walkthrough: "Here's what to do next. 1. Click the button. 2. Fill out the short form. 3. Check your email."
- Benefit-oriented button text: "Access My Results" outperforms "Click Here" (per CTA effectiveness research)

**Real-world example (from Perplexity Q2 research):**
> Classic 2012: "CLAIM YOUR 30-DAY FREE TRIAL NOW!" (all caps, high-contrast button)
> Modern 2025: "Try 30 Days Free -- No Credit Card Required" (soft button, neutral design)

### Dimension 4: Headlines
**Dated position:** Dense, curiosity-withholding, all-caps, announcement-style
**Modern position:** Specific, benefit-forward, story-led, with subheading doing heavy lifting
**Dated patterns:** DP-H1 through DP-H9

**Modern headline patterns:**
- Story beat + specific outcome: "I rebuilt my entire funnel in 3 days. Here's exactly what I changed."
- Anti-hype + admission: "I spent 3 years figuring out why my ads didn't work. Here's what I found."
- Method-forward: "The $5k Client Recruitment Framework That Booked Me 12 High-Ticket Clients"
- Headline + subheading combo replaces one long dense headline
- Concrete cost of inaction: "If you're doing [X], this is probably costing you [$specific]"
- "Say What It Is": "Email Automation for Small Businesses" (clarity > mystery)
- "Say What You Get": "Hire Qualified Candidates 50% Faster"
- "Say What You're Able to Do": "Build Your Entire Sales Funnel Without Hiring a Developer"

**Real-world example (from Perplexity Q2 research):**
> Classic 2010 weight loss: "Doctors HATE This One Shocking Hack to Melt Belly Fat While You Sleep -- No Exercise, No Diet"
> Modern 2025 equivalent: "How to Lose 15-25 Pounds in 12 Weeks -- With Our Medically-Supervised Program"

### Dimension 5: Objection Handling
**Dated position:** Confrontational ("doubters never succeed", hesitation = character flaw)
**Modern position:** Empathetic specificity ("what specifically concerns you?", root-cause approach)
**Dated patterns:** DP-T1, DP-T5, DP-B6

**Modern objection patterns:**
- Root-cause approach: "What specifically do you want to think through? Is it the investment? The time? Whether it works for your situation?"
- Pre-objection resolution in page structure: Address pricing, time commitment, fit before they object
- Proof-based resolution: Respond with case studies from similar situations, not emotional pressure
- Transparency about fit: "This program is perfect if you already have a list. It's probably not right if you're starting from zero."
- Acknowledge hesitation as valid: "That makes sense" before addressing the specific concern
- Empathetic validation + evidence: Validate concern as legitimate, then provide specific data

**Real-world example (from Perplexity Q2 research):**
> Classic 2008 time objection: "Some people say they don't have time. These people are the same ones who say they don't have time to exercise. The truth is, you make time for what matters."
> Modern 2025: "We know you're busy. That's why we designed this for people with full-time jobs. Average time commitment: 45 minutes per week. 73% of our students complete the program while working full-time."

### Dimension 6: Rhythm
**Dated position:** Relentless density (sentence after sentence building pressure, no breathing room)
**Modern position:** Strategic pauses (white space, shorter paragraphs, room to process)
**Dated patterns:** DP-F4, DP-F7

**Modern rhythm patterns:**
- Max 3 lines per paragraph on mobile (1-2 sentences)
- Subheads every 200-300 words that tell a story even if you only read subheads
- Strategic white space -- emptiness signals confidence
- Sentence fragments for emphasis: "Not perfectly. Not yet. But close."
- Conversational punctuation: dashes, ellipses, parenthetical asides
- Short/long alternation (Hormozi cadence): Short punch. Short punch. Long flowing sentence with story. Short takeaway.
- Let strong statements breathe -- paragraph break after a powerful line, no immediate explanation

### Dimension 7: Tone
**Dated position:** Aggressive seller ("You need this!", confrontational, performative authority)
**Modern position:** Knowledgeable advisor (conversational authority, earned confidence, strategic vulnerability)
**Dated patterns:** DP-T1 through DP-T9

**Modern tone patterns:**
- Contractions always ("you're" not "you are")
- Parenthetical asides showing personality: "(I know, I was surprised too)"
- Casual qualifiers: "basically," "pretty much," "kind of"
- Direct address without formality: "look," "here's the thing"
- Earned confidence through specificity, not through claims: "I've run 2,400 split tests across 340 campaigns over 6 years" not "I'm one of the world's leading experts"
- Anti-hype: "No secrets. No hacks. No shortcuts."
- Vulnerability: "I was wrong about this for three years."
- Self-deprecation (real, not performative): "I was the world's worst marketer"
- Third-grade vocabulary: "use" not "leverage", "fix" not "optimize", "get" not "acquire"

---

## Cross-Cutting Modern Patterns

### Accessibility-First Vocabulary
Modern high-converting copy uses third-grade vocabulary. Hormozi eliminates adverbs. Brunson uses story-based explanation. The pattern: if a 12-year-old can't understand it, rewrite it.
**Fixes:** DP-T2, DP-T9

### Conversational Punctuation
Dashes, ellipses, line breaks, and parenthetical asides create the rhythm of speech on the page. This isn't sloppy -- it's intentional pacing that signals "this is a person talking."
**Fixes:** DP-T2, DP-T3

### Vulnerability as Credibility
Admitting struggles, failures, limitations, and uncertainty paradoxically increases trust. "Our first version was terrible. Here's what we fixed." This works because readers assume that someone willing to admit failure is more likely to be honest about success.
**Fixes:** DP-T1, DP-T8, DP-P5

### Strategic Understatement
The most credible modern copy undersells rather than oversells: "It's the best system I've found. And I've tested a lot of them." vs. "This is the MOST POWERFUL system ever created."
**Fixes:** DP-T6, DP-T7, DP-H4

### Systems/Mechanism Language
Modern copy names the HOW, not just the WHAT. "The $5k Client Recruitment Framework" tells you there's a specific system. Proprietary mechanism naming (Todd Brown's E5 Method, Hormozi's Value Equation) creates differentiation and credibility.
**Fixes:** DP-H3, DP-H8

### Implementation Focus
The most effective modern copy addresses HOW implementation works, not just outcome promises. "Module 2 walks you through building your first funnel. Most people finish this in a weekend." This removes the gap between wanting and doing.
**Fixes:** DP-O1, DP-H4

### Community Positioning
Modern offers increasingly position products as gateways to communities, not just information delivery. "Join 487 people who are implementing this together" beats "Get access to the course."
**Fixes:** DP-P6

---

## What Modern Does NOT Mean

1. **Not casual to the point of unprofessional.** Conversational and sloppy are different things.
2. **Not anti-persuasion.** All strategic depth (proof architecture, objection handling, belief shifting) stays. Only surface language changes.
3. **Not short for the sake of short.** Long-form still converts. But every paragraph must earn its place.
4. **Not anti-direct-response.** The psychological principles are timeless. Only the packaging evolved.
5. **Not "eliminate all urgency."** Real urgency still works. Manufactured urgency doesn't.
6. **Not "sound like Hormozi."** Hormozi is one data point. The goal is "sound like a real person in 2026."
7. **Not "strip all emotion."** Emotional resonance is critical. But earned emotion through real stories beats manufactured emotion through hype.
