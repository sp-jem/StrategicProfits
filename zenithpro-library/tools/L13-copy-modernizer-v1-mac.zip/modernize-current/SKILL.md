---
name: modernize-current
description: Modernizes copy based on what's currently converting at scale. Not one person's voice -- the shared linguistic patterns across ALL top-converting modern direct response copy (2024-2026).
license: Private
triggers:
  - /modernize-current
  - modernize current patterns
  - update copy to modern style
  - make this sound current
metadata:
  version: 1.0.0
  author: Rich Schefren
  category: copywriting
  updated: 2026-02-01
---

# Copy Modernizer: Current Converting Patterns

Modernizes copy based on what's actually converting at scale right now (2024-2026). Not one person's voice -- this skill encodes the shared linguistic patterns across Hormozi, Brunson, Suby, Todd Brown, and the broader market of high-ticket business/coaching offers.

## When to Use

- When copy needs to sound like 2026, not 2010
- When the strategic structure is solid but the voice/tone feels off
- When copy sounds like "a copywriter wrote this" instead of "a person is talking to me"
- After arena output to apply modern best practices
- Before publishing any direct response copy

## What It Does

1. Accepts copy input (pasted text or file path)
2. Analyzes against 12 modern copy principles and 7 linguistic shift dimensions
3. Rewrites the surface layer while preserving strategic architecture
4. Outputs modernized version + change log

## What It Does NOT Do

- Clone any single voice (this is pattern-based, not voice-matching)
- Rewrite the strategic argument or offer structure
- Shorten copy arbitrarily (long-form still works -- it just has to earn every paragraph)
- Remove all urgency (replaces manufactured urgency with authentic urgency)
- Make copy "casual" at the expense of authority

## Quick Usage

```
/modernize-current
```

Then paste your copy or provide a file path.

## Process

### Step 1: Ingest

Read the full copy. Understand the strategic intent, argument flow, offer structure, and emotional arc before touching anything.

### Step 2: Analyze Against 7 Shift Dimensions

For each dimension, assess the copy's current position (dated vs. modern):

1. **Urgency** -- Manufactured (fake deadlines, artificial scarcity) vs. Authentic (real reasons, opportunity cost, competitive gap)
2. **Proof** -- Testimonial stacking vs. Execution proof (case studies, process proof, behind-the-scenes)
3. **CTAs** -- Command-based ("ACT NOW") vs. Outcome-focused ("Get the Framework")
4. **Headlines** -- Dense/curiosity-withholding vs. Specific/benefit-forward with subheadings
5. **Objection Handling** -- Confrontational ("doubters never succeed") vs. Empathetic specificity ("what specifically concerns you?")
6. **Rhythm** -- Relentless density vs. Strategic pauses and breathing room
7. **Tone** -- Aggressive seller vs. Knowledgeable advisor / conversational authority

### Step 3: Apply Modern Patterns

For each dated element found, apply the corresponding modern pattern from `references/modern-patterns.md`. Reference the specific pattern ID in the change log.

**Critical constraints:**
- Preserve every proof point, just repackage the delivery
- Preserve every objection handled, just change the handling style
- Preserve every story, just modernize the framing
- Preserve the core argument -- change the clothes, not the skeleton

### Step 4: Apply the 12 Principles Check

Before finalizing, verify the modernized copy passes all 12 principles from `references/modern-patterns.md`:

1. Sounds like a person talking, not a copywriter writing
2. Every sentence earns its place
3. Specificity as credibility (exact numbers, named people, real timelines)
4. Admits what's hard, limited, or failed
5. One idea per paragraph, max 3 lines on mobile
6. Bold for emphasis, not CAPS
7. Real urgency only
8. CTA = instructions, not commands
9. Proof through process, not just outcomes
10. Anti-hype as trust signal
11. One story, one point, under 200 words per story
12. Designed for two reading speeds (skim path tells complete story)

### Step 5: Output

**Section A: Modernized Copy**
Full rewritten version, ready to use.

**Section B: Change Log**

| Line | Original | Modernized | Dimension | Pattern ID | Reason |
|------|----------|------------|-----------|-----------|--------|
| 3 | "DISCOVER THE SECRET" | "Here's what I found after 3 years of testing" | Headlines | MP-H2 | Curiosity-withholding -> Specific admission |

**Section C: Modernization Score**
Rate the original on each of the 7 dimensions (1-5 scale, 5 = fully modern) and show the after score.

## Reference Files

- `references/modern-patterns.md` -- The complete modern pattern library with IDs
- `references/dated-patterns.md` -- What to detect (the "before" patterns)
- `references/before-after-examples.md` -- Concrete transformation examples from real copy
