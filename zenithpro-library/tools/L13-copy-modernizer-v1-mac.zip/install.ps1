# Copy Modernizer v1.0 - Windows Installer
# Installs 4 copy modernization skills to ~/.claude/skills/

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillsDir = Join-Path $env:USERPROFILE ".claude\skills"

Write-Host ""
Write-Host "Copy Modernizer v1.0 - Installer" -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan
Write-Host ""

# Check if ~/.claude/skills exists
if (-not (Test-Path $SkillsDir)) {
    Write-Host "Creating skills directory at $SkillsDir"
    New-Item -ItemType Directory -Path $SkillsDir -Force | Out-Null
}

# Check for existing installation
$Existing = $false
foreach ($Skill in @("modernize-contrast", "modernize-current", "modernize-hormozi", "modernize-all")) {
    if (Test-Path (Join-Path $SkillsDir $Skill)) {
        $Existing = $true
        break
    }
}

if ($Existing) {
    Write-Host "Existing Copy Modernizer installation detected." -ForegroundColor Yellow
    $Confirm = Read-Host "Overwrite? (y/n)"
    if ($Confirm -ne "y" -and $Confirm -ne "Y") {
        Write-Host "Installation cancelled."
        exit 0
    }
    Write-Host ""
}

# Install each skill
$Skills = @("modernize-contrast", "modernize-current", "modernize-hormozi", "modernize-all")

foreach ($Skill in $Skills) {
    $SourceDir = Join-Path $ScriptDir $Skill
    $DestDir = Join-Path $SkillsDir $Skill

    if (Test-Path $SourceDir) {
        # Create skill directory and references subdirectory
        $RefsDir = Join-Path $DestDir "references"
        if (-not (Test-Path $RefsDir)) {
            New-Item -ItemType Directory -Path $RefsDir -Force | Out-Null
        }

        # Copy SKILL.md
        Copy-Item -Path (Join-Path $SourceDir "SKILL.md") -Destination (Join-Path $DestDir "SKILL.md") -Force

        # Copy all reference files
        $SourceRefs = Join-Path $SourceDir "references"
        if (Test-Path $SourceRefs) {
            Get-ChildItem -Path $SourceRefs -File | ForEach-Object {
                Copy-Item -Path $_.FullName -Destination (Join-Path $RefsDir $_.Name) -Force
            }
        }

        Write-Host "  Installed: $Skill" -ForegroundColor Green
    } else {
        Write-Host "  WARNING: $Skill folder not found in package" -ForegroundColor Yellow
    }
}

Write-Host ""

# Verify installation
Write-Host "Verifying installation..."
$Pass = 0
$Fail = 0

foreach ($Skill in $Skills) {
    $SkillFile = Join-Path $SkillsDir "$Skill\SKILL.md"
    if (Test-Path $SkillFile) {
        $Pass++
    } else {
        $Fail++
        Write-Host "  FAILED: $Skill\SKILL.md not found" -ForegroundColor Red
    }
}

Write-Host ""
if ($Fail -eq 0) {
    Write-Host "Installation complete. All 4 skills installed successfully." -ForegroundColor Green
} else {
    Write-Host "Installation completed with $Fail error(s). Check above for details." -ForegroundColor Red
}

Write-Host ""
Write-Host "Installed to: $SkillsDir"
Write-Host ""
Write-Host "Skills installed:"
Write-Host "  /modernize-contrast  - Surgical pattern replacement (86 rules)"
Write-Host "  /modernize-current   - Full dimension analysis (7 dimensions, 12 principles)"
Write-Host "  /modernize-hormozi   - Hormozi voice transformation (16 rules)"
Write-Host "  /modernize-all       - Combined three-pass pipeline"
Write-Host ""
Write-Host "Usage: Open Claude Code and type /modernize-all then paste your copy."
Write-Host ""
