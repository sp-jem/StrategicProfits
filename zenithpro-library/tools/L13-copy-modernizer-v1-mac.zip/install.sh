#!/bin/bash
set -e

# Copy Modernizer v1.0 - Mac/Linux Installer
# Installs 4 copy modernization skills to ~/.claude/skills/

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILLS_DIR="$HOME/.claude/skills"

echo ""
echo "Copy Modernizer v1.0 - Installer"
echo "================================="
echo ""

# Check if ~/.claude/skills exists
if [ ! -d "$SKILLS_DIR" ]; then
    echo "Creating skills directory at $SKILLS_DIR"
    mkdir -p "$SKILLS_DIR"
fi

# Check for existing installation
EXISTING=0
for SKILL in modernize-contrast modernize-current modernize-hormozi modernize-all; do
    if [ -d "$SKILLS_DIR/$SKILL" ]; then
        EXISTING=1
        break
    fi
done

if [ "$EXISTING" -eq 1 ]; then
    echo "Existing Copy Modernizer installation detected."
    read -p "Overwrite? (y/n): " CONFIRM
    if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
        echo "Installation cancelled."
        exit 0
    fi
    echo ""
fi

# Install each skill
for SKILL in modernize-contrast modernize-current modernize-hormozi modernize-all; do
    if [ -d "$SCRIPT_DIR/$SKILL" ]; then
        # Create skill directory
        mkdir -p "$SKILLS_DIR/$SKILL/references"

        # Copy SKILL.md
        cp "$SCRIPT_DIR/$SKILL/SKILL.md" "$SKILLS_DIR/$SKILL/SKILL.md"

        # Copy all reference files
        if [ -d "$SCRIPT_DIR/$SKILL/references" ]; then
            cp "$SCRIPT_DIR/$SKILL/references/"* "$SKILLS_DIR/$SKILL/references/" 2>/dev/null || true
        fi

        echo "  Installed: $SKILL"
    else
        echo "  WARNING: $SKILL folder not found in package"
    fi
done

echo ""

# Verify installation
echo "Verifying installation..."
PASS=0
FAIL=0
for SKILL in modernize-contrast modernize-current modernize-hormozi modernize-all; do
    if [ -f "$SKILLS_DIR/$SKILL/SKILL.md" ]; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
        echo "  FAILED: $SKILL/SKILL.md not found"
    fi
done

echo ""
if [ "$FAIL" -eq 0 ]; then
    echo "Installation complete. All 4 skills installed successfully."
else
    echo "Installation completed with $FAIL error(s). Check above for details."
fi

echo ""
echo "Installed to: $SKILLS_DIR"
echo ""
echo "Skills installed:"
echo "  /modernize-contrast  - Surgical pattern replacement (86 rules)"
echo "  /modernize-current   - Full dimension analysis (7 dimensions, 12 principles)"
echo "  /modernize-hormozi   - Hormozi voice transformation (16 rules)"
echo "  /modernize-all       - Combined three-pass pipeline"
echo ""
echo "Usage: Open Claude Code and type /modernize-all then paste your copy."
echo ""
