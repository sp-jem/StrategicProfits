# Hormozi Voice Patterns

Extracted from 471 Alex Hormozi video transcripts (2.5M+ words). These are the specific linguistic patterns that define his voice.

**Version:** 2.0 | **Rules:** 16 | **Vocabulary:** 52 | **Transitions:** 22

---

## The 16 Voice Rules

### Rule 1: Third-Grade Words

Replace formal/marketing vocabulary with plain language.

| Replace This | With This |
|-------------|-----------|
| "implement" | "do" |
| "utilize" / "leverage" | "use" |
| "generate revenue" | "make money" |
| "generate leads" | "get people who want to buy" |
| "optimize" | "make better" / "fix" |
| "materials" / "resources" | "stuff" |
| "elements" / "components" | "things" |
| "substantial" / "significant" | "a lot" |
| "obtain" / "acquire" / "secure" | "get" |
| "considerable" / "massive" | "big" |
| "execute" / "deploy" | "do" |
| "monetize" | "make money from" |
| "delivers results" / "produces outcomes" | "works" |
| "remarkable" / "extraordinary" | "cool" or "pretty cool" |
| "challenging" / "demanding" | "hard" |
| "facilitate" | "help" |
| "methodology" / "framework" | "the way it works" / "the system" |
| "paradigm" | never use this word |
| "synergy" | never use this word |
| "scalable" | "it grows" / "it works at scale" |
| "actionable insights" | "stuff you can actually do" |
| "value proposition" | "what you get" / "why it matters" |
| "deliverables" | "what you get" |
| "customer acquisition" | "getting customers" |
| "churn reduction" | "keeping people" |
| "conversion rate" | "the percentage of people who buy" |
| "onboard" | "get them started" / "bring them in" |
| "infrastructure" | "the back-end stuff" / "the plumbing" |
| "iterate" | "try again" / "do it again but better" |
| "bandwidth" | "time" / "capacity" |
| "stakeholders" | "the people involved" |
| "ROI" | "what you get back" / "the return" |
| "KPIs" | "the numbers that matter" |
| "ecosystem" | "the whole thing" / "everything around it" |
| "incentivize" | "give them a reason to" |
| "trajectory" | "where things are heading" |
| "disruptive" | never use this word |
| "innovative" | "new" / "different" |
| "streamline" | "simplify" / "make faster" |
| "curate" | "pick" / "choose" |
| "ideate" | "come up with ideas" |
| "pivot" | "change direction" / "switch" |
| "deep dive" | "look closely at" / "dig into" |
| "pain point" | "problem" / "the thing that sucks" |
| "touchpoint" | "the places they interact with you" |
| "cadence" (marketing usage) | "how often" / "the rhythm" |
| "robust" | "solid" / "strong" |
| "granular" | "specific" / "detailed" |
| "holistic" | "the whole picture" / "everything together" |
| "low-hanging fruit" | "the easy wins" / "the obvious stuff" |
| "move the needle" | "actually change something" / "make a dent" |
| "circle back" | "come back to this" |
| "unpack" | "break down" / "explain" |

**One exception:** Hormozi uses "fundamentally" as his single sophisticated word, for emphasis only.

### Rule 2: The Cadence

Alternate between two modes:

**Mode 1: Short declarative punches** (3-5 words)
- "That is power."
- "Proof will always outdo promise."
- "That's pretty much it."
- "They don't care about you."
- "Everyone buys something."
- "It's that simple."

**Mode 2: Extended conversational runs** (20-40+ words)
Long flowing sentences with mid-sentence corrections ("and so," "but the thing is," "which is"), self-interruptions, and stories that circle back.

**The pattern:** Short. Short. Long with embedded story. Short that lands the takeaway.

**Never:** Three long sentences in a row without a short punch. Three short punches in a row without context.

**Example from transcript:**
> "Proof will always outdo promise. So the reason at the very beginning of this video I said we spent tens of millions of dollars on ads last year between our portfolio companies -- so this isn't like we don't have an agency, that's actually us spending money in our actual companies -- so it's not like me taking credit for all the clients that I have. It's like these are companies that I own that we spent money on to generate revenue. So we risk real money behind these things."

### Rule 3: Specific Number Anchors

Every proof needs an oddly-specific number:
- "$46.2 million" not "over $46 million"
- "$17 million a month" not "eight figures"
- "13 years" not "over a decade"
- "36:1 return" not "incredible returns"
- "500,000 people" not "hundreds of thousands"
- "$106 million in 72 hours" not "nine figures in a weekend"
- "100,000 in sales in a day" not "six figures in a day"
- "14 to 32 locations" not "more than doubled"

If no specific number exists, delete the vague claim. "Massive results" with no number is worse than nothing.

### Rule 4: Conversational Transitions

| Kill This | Use This |
|-----------|----------|
| "Furthermore..." | "And so..." |
| "In addition..." | "On top of that..." |
| "However..." | "But here's the thing..." |
| "Therefore..." | "And so what ends up happening is..." |
| "For example..." | "Think about it like this..." |
| "In conclusion..." | "Big picture..." / "So the point is..." |
| "It's important to note..." | "And here's the crazy part..." |
| "Let me explain..." | "So here's how I think about this..." |
| "Consider this..." | "Think about it this way..." |
| "As a result..." | "So what happened was..." |
| "Consequently..." | "And so..." |
| "Nevertheless..." | "But still..." |
| "Notwithstanding..." | delete the sentence |
| "First and foremost..." | "So first..." / "Number one..." |
| "With that being said..." | "So..." / "Now..." |
| "In terms of..." | "When it comes to..." / "For..." |
| "It should be noted that..." | "Here's what's interesting..." |
| "In other words..." | "Meaning..." / "So basically..." |
| "The takeaway here is..." | "So the point is..." |
| "Moving on to..." | "Now..." / "Next thing..." |
| "To elaborate..." | "So what I mean by that is..." |
| "As mentioned previously..." | "Remember when I said..." |

**Signature tic:** "And so" is Hormozi's most used transition. Use it freely.

### Rule 5: Preemptive Objection Handling

Structure:
1. Name the objection directly ("Before you think this is just another [X]...")
2. Concede the valid part ("And people still don't do it. Myself included.")
3. Redirect ("Not perfectly. Not with judgment yet. But with 80-90% accuracy? Absolutely.")

Never attack the reader for having the objection. Never use "If you're the type of person who makes excuses..." framing.

### Rule 6: Math-Based Urgency

Replace manufactured scarcity with opportunity cost calculations:

**Kill:** "Only 7 spots left!" / "Offer expires at midnight!" / "Act now!"

**Use:**
- "Every hour you spend on [unprofitable thing] is an hour not spent on [profitable thing]"
- "The only thing worse than a $1,000 offer to someone with a $100 budget is a $100 offer to someone with a $1,000 budget. Because you lose $900."
- "You'll watch OTHER people start using this. And you'll realize the gap isn't knowledge anymore. It's execution."
- Let the reader's situation create the urgency, not your deadline
- Cost-of-delay math: "If this saves you 10 hours a week and your time is worth $200/hour, every week you wait costs you $2,000"

### Rule 7: Short Stories (Under 200 Words)

Rules:
- Every story has ONE point. State it before or after. Never both.
- Include specific sensory details (pizza shop, clown check, 11pm at the desk)
- 200 words max for written copy
- "And then something clicked" is allowed ONCE per piece. Not repeatedly.

### Rule 8: Anti-Hype

Hormozi actively undercuts his own hype:
- "I'm not going to tell you this is easy..."
- "This will either be the best presentation you've ever heard, the worst, or somewhere in between. That is a promise."
- "Not perfectly. But with 80-90% accuracy."
- "As the world's worst marketer, I sent my first email this year. Pretty big stuff." (sarcasm)

**Rule:** For every strong claim, add one qualifier or admission. If you catch yourself selling too hard, pull back.

### Rule 9: Calm CTA Instructions

**Kill:** "BUY NOW!" / "CLAIM YOUR SPOT!" / "DON'T MISS OUT!"

**Use:**
- "Here's what to do next."
- "Scroll down. You'll see a red button. Click it. Enter your info. Takes about 30 seconds."
- "You pick ONE course. You go through Module 1."
- Walk them through the physical act of buying, step by step, calmly.

**The Anti-Close Close:** "I don't want your money if this doesn't transform how you execute."

### Rule 10: Let Statements Breathe

After a strong statement, add a paragraph break. Don't explain what you just said. Let it sit.

"Proof will always outdo promise."

[white space]

Then continue. The silence after a strong line does more work than three sentences of explanation.

### Rule 11: The Rule of One

From Hormozi's "The Copy Rule I Learned From The Best Copywriter I Know" -- referencing Michael Masterson/Agora:

**Every piece of copy centers on ONE big idea.** Not three benefits. Not five angles. One.

- "91 of the top 100 offers of all time centered around a single concept"
- The idea must be: easy to understand, easy to believe, and interesting/unique
- Sub-bullets reinforce the ONE idea, they don't introduce new ones
- "The ones that do best are the simplest, the most direct, and the clearest to understand"
- If you have 15 great points, pick the best one. Kill the rest. They dilute.

**Test:** Can a reader explain your offer's core idea in one sentence? If not, you have toss-salad copy.

### Rule 12: The Sacrificial Lamb Close

From Hormozi's supplement-selling story -- the most powerful trust-building tactic:

**Give something away to a competitor to gain trust for everything else.**

- "Hey, you can get this one for cheaper down the street at Costco. You don't need to get this one from me."
- After making that one cross-out, "everyone bought what I recommended afterwards"
- The concession proves you're not just trying to take their money
- Choose the lowest-margin item as your sacrificial lamb
- Works because: acting in their self-interest (not yours) earns trust faster than any claim

**In copy:** Recommend a free alternative for one component. Then sell the rest with earned credibility. "You don't need us for [X] -- here's a free tool that handles it. What you DO need us for is [Y]."

### Rule 13: The Assumed Close

From Hormozi's "How to Close Deals Without Resistance":

**Don't ask IF they want it. Ask WHICH ONE they want.**

- "Do you want chocolate or vanilla?" -- not "Do you want protein?"
- "Do you want the monthly or annual plan?" -- not "Are you ready to sign up?"
- "Do you want to just use the card you have on file?"
- The prospect chooses between two options that both involve buying from you

**In copy:** Frame the CTA as choosing between packages, not deciding whether to buy. "Pick the plan that fits: Starter ($X) or Growth ($Y)." Not "Ready to transform your business?"

### Rule 14: Questions Control Conversations

From Hormozi's 3A reframing framework:

**The person asking questions is in control. Never answer a trap question directly.**

- Prospect: "How many certifications do your trainers have?" → You: "Which certifications are you looking for specifically?"
- Prospect: "That's expensive." → You: "Compared to what?"
- Reframe by asking a question about their question
- Three types of questions: mining (extracting info), agreement (getting yes), and negatively-inclined (Chris Voss "no"-based)

**In copy:** Use the reader's likely question as a section header, then answer with a reframe. "Is this worth $997?" becomes "What would it cost you to figure this out yourself?"

### Rule 15: Credibility Frontload, Then Disappear

Establish authority in ONE sentence, then get out of the way:
> "I crossed $100 million in net worth by age 32. I sold my first big company for $46.2 million."

Then immediately pivot to value for the reader. The credibility is a setup, not the show.

**Rules:**
- One sentence of credentials. Two max.
- Then never mention yourself again until you need a story
- Pair authority with vulnerability: "I was the world's worst marketer. I sent my first email this year."
- Never stack credentials across multiple paragraphs
- Never return to credentials mid-piece

### Rule 16: The "Fair Enough" Micro-Close

From Hormozi's favorite close (via Jordan Belfort):

**Use reciprocal agreement language, not hype language.**

- "Fair enough?" after making a concession
- "Does that sound reasonable?" instead of "Isn't this amazing?"
- "That's a fair expectation, right?" instead of "This is going to blow your mind!"
- Neutral-tone questions get easier agreement than positive-hype questions

**In copy:** End sections with "Fair?" or "Make sense?" rather than "Exciting, right?" or "Can you imagine?"

---

## Tone Markers

### Self-Deprecation (Real, Not Performative)
- "I hate money apparently"
- "I was the world's worst marketer"
- "Pretty big stuff" (sarcasm about something actually big)
- "I sent my first email this year. Pretty big stuff." (self-mocking)
- "I don't think this guy is that bright -- and he was doing $80K a month"

### Direct Address Without Formality
- "hear me out"
- "think about it this way"
- "stay with me"
- "fair?"
- "look --"
- "so check this out"
- "here's what's interesting"

### Casual Intensifiers
- "way [bigger]"
- "pretty cool"
- "pain in the ass"
- "straight up"
- "dude"
- "holy shit" (or near-equivalent)
- "like" (used freely as a conversational filler, not avoided)

### Credibility Frontload
Establish authority in ONE sentence, then immediately pivot to value:
> "I've been in business for 13 years. I've sold nine companies. My last company I sold for $46.2 million. My current portfolio does just over $17 million a month."

Then stop talking about yourself. The credibility is a setup, not the show.

### Vulnerability Pairing
Always pair authority with admission:
- "I've made a very good living... But here's what I've watched happen..."
- "I was the world's worst marketer. I sent my first email this year."
- "I literally just again and again and again, I just kept getting beat up"
- "I had 15 or 20 consultations... no after no after no after no"

---

## Hormozi Proof Patterns

### Pattern 1: The Specific Number Anchor
Every proof statement uses oddly specific numbers. Never rounded, never vague.
- "$46.2 million" not "over $46 million"
- "$106 million in 72 hours" not "nine figures quickly"
- "14 to 32 locations" not "more than doubled"
- "91 of the top 100 offers" not "most top offers"
- "500,000 people registered" not "hundreds of thousands"

### Pattern 2: The Credibility-Then-Pivot
State credentials in one breath, then immediately serve the listener:
> "We had a portfolio of six companies doing $85 million a year. And so I want to talk to you about..."

The credentials exist only to earn permission to teach. They're not the content.

### Pattern 3: Process Proof Over Outcome Proof
Show the HOW, not just the WHAT:
- "We secret-shopped the business. Here's what we found." (not "We grew it 10x")
- "I went and called back all these webinar leads that never showed up" (showing the specific tactic)
- "I had a pre-sale questionnaire... then got their credit card... then understood current situation... then desired state... then obstacle" (step-by-step process)

### Pattern 4: The Damaging Admission
Undercut your own story to build trust:
- "As the world's worst marketer, I sent my first email this year"
- "I couldn't get webinars, I couldn't get VSLs, I couldn't get all the fancy stuff to work"
- "I was probably like 15 orientations deep and I just had no after no after no"
- "It felt horrible. I literally just kept getting beat up."

### Pattern 5: Third-Party Proof Through Story
Instead of "our clients get results," tell ONE client's specific story:
- "Sandy Smith... saw me working out... asked me to help with her food... met at a pizza shop... talked for an hour and a half... she writes a $100 check... it was a clown check"
- Names, places, sensory details. Not "Client A achieved 300% growth."

### Pattern 6: The "I Was Worse Than You" Opening
Start from a position below the audience:
- "I was really struggling"
- "I saw this guy I went to college with. I didn't think he was that much smarter than me."
- "He was doing $70-80K a month in supplements. My mind broke."
- Creates identification (you were where I am) and hope (you got out).

---

## Hormozi Story Structure

### The Signature Story Arc (5 beats, under 200 words)

1. **Specific scene** -- time, place, sensory detail ("During a layover, I saw this guy I used to go to college with")
2. **The gap** -- something that doesn't match expectations ("He's doing $80K a month in supplements. I didn't think this guy was that bright.")
3. **The emotional shift** -- the moment something changes ("My mind broke. I was like, if this guy can do this...")
4. **The action** -- what you did differently ("I came back 100% committed. Every single client, I was like, hey buy these supplements.")
5. **The specific result** -- with a number ("I made my first supplement sale. And then I was able to teach it to people and they closed 80-90%.")

### Story Rules
- ONE story, ONE point. State the point before or after. Never both.
- Specific sensory details: pizza shop, clown check, 11pm at the desk, nice ring and nice purse
- Include dialogue: "She was like, 'Which one do you like?' I was like, 'Chocolate.' She was like, 'All right, I'll take one of those.'"
- Include failure before success: "15 orientations deep... no after no after no"
- 200 words max for written copy
- "And then something clicked" / "That's when it hit me" -- allowed ONCE per piece

### The Layover Story Template
Hormozi frequently uses chance encounters as story vehicles:
- Setting up a mundane scene (airport, gym, store)
- Encountering someone unexpected
- Learning something that breaks your mental model
- Taking immediate action based on the insight
- Getting a specific measurable result

---

## Hormozi Objection Handling

### Pattern 1: Name-Concede-Redirect
1. **Name it first:** "Before you think this is just another [X]..."
2. **Concede the valid part:** "And people still don't do it. Myself included."
3. **Redirect:** "Not perfectly. Not with judgment yet. But with 80-90% accuracy? Absolutely."

### Pattern 2: The "Fair Enough" Reciprocal
When price is the objection, make a concession and ask for reciprocal agreement:
- "What if we did this instead? Fair enough?"
- "That sounds reasonable, right?"
- Never argue. Make a move, then check for agreement.

### Pattern 3: The Ghost Product / Sacrificial Lamb
Pre-emptively give something away to neutralize the "you just want my money" objection:
- "You can get this one at Costco. You don't need to buy it from me."
- "Here's a free resource that covers [X]. What you need us for is [Y]."
- Cross out one thing from the list. They'll buy everything else.

### Pattern 4: Reframe the Question
Never answer trap questions directly. Ask a question about the question:
- "How much does it cost?" → "What are you comparing it to?"
- "How many certifications?" → "Which certifications are you looking for?"
- "Is it worth it?" → "What would it cost you to figure this out yourself?"

### Pattern 5: The "Everyone Has Some Money" Frame
When people say they can't afford it:
- "Everyone has some money. And everyone has this problem."
- Offer a downsell through exchange, not discount: remove a component, reduce scope
- The person who sets the terms of the exchange has the power
- Never beg. Never sound desperate. "Commission breath" kills the sale.

### Pattern 6: Empathetic Validation Before Evidence
Acknowledge the objection as reasonable before addressing it:
- "That's a lot. I get it." → then reframe
- "Look, I was skeptical too when I first heard about this." → then share what changed
- Never: "Some people worry about that. Those people don't understand..." (dismissive)

---

## Adverb Elimination Guide

| Delete This | Stronger Alternative |
|------------|---------------------|
| "quickly build" | "build in 3 days" / just "build" |
| "significantly increase" | "double" / "go from X to Y" |
| "dramatically improve" | "fix" / "go from broken to working" |
| "incredibly powerful" | "powerful" (or delete) |
| "really important" | "important" (or just state why) |
| "extremely effective" | "it works" |
| "basically" | keep -- this is Hormozi's word |
| "fundamentally" | keep -- this is Hormozi's emphasis word |
| "honestly" / "frankly" | "straight up" or delete |
| "very" | always delete |
| "literally" | delete unless it's literally literal |
| "absolutely" | "yes" or delete |
| "completely" | delete or use specific: "100%" |
| "truly" | delete |
| "simply" | delete or "just" |
| "actually" | keep sparingly -- Hormozi uses it |
| "essentially" | "basically" (his preferred version) |
| "particularly" | "especially" or delete |
| "tremendously" | use a number instead |
| "exponentially" | "10x" or specific multiplier |

**The rule:** Adverbs are "placeholders for shitty verbs." If you need an adverb, you picked the wrong verb. Replace "quickly build" with "build in 3 days." Replace "significantly increase" with "double." Replace "dramatically improve" with "fix."

---

## Hormozi Signature Phrases

These phrases appear repeatedly across 471 transcripts and define his voice:

| Phrase | Usage |
|--------|-------|
| "And so..." | Primary transition (most frequent) |
| "But here's the thing..." | Pivot to unexpected point |
| "Think about it like this..." | Reframe / analogy setup |
| "Fair?" / "Fair enough?" | Micro-close after any point |
| "Pretty much" | Casual qualifier |
| "Straight up" | Emphasis / honesty signal |
| "Pain in the ass" | Describing friction |
| "The crazy part is..." | Flagging counterintuitive data |
| "Not perfectly. But..." | Qualified claim (anti-hype) |
| "That is power." | Landing a key insight |
| "Everyone buys something." | Reframe on affordability objections |
| "I was the world's worst [X]" | Vulnerability opener |
| "Here's what to do next." | CTA opener |
| "The point is..." | Summary / takeaway signal |
| "It's that simple." | Closing a concept (after making it simple) |
| "And I was like, 'Holy shit.'" | Genuine reaction in stories |
| "If this guy can do this..." | Proof by comparison |
| "So what ended up happening was..." | Story continuation transition |
| "Big picture..." | Zooming out to conclusion |
| "Does that make sense?" | Check-in / micro-close |
