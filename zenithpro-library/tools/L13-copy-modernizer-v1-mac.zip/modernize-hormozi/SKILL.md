---
name: modernize-hormozi
description: Rewrites copy in Hormozi's specific voice -- short declaratives, no adverbs, active voice, narrative honesty, specific numbers, conversational directness. Extracted from 471 video transcripts.
license: Private
triggers:
  - /modernize-hormozi
  - hormozi voice
  - rewrite in hormozi style
  - make this sound like hormozi
metadata:
  version: 1.0.0
  author: Rich Schefren
  category: copywriting
  updated: 2026-02-01
---

# Copy Modernizer: Hormozi Voice

Rewrites copy in Alex Hormozi's specific voice -- short declaratives, third-grade vocabulary, no adverbs, active voice, narrative honesty, specific numbers, conversational directness. Extracted from analysis of 471 video transcripts (2.5M+ words).

## When to Use

- When copy needs to sound like Hormozi specifically (not just "modern")
- When the target audience follows Hormozi and expects that voice
- When copy reads as formal, academic, or "copywriter-y"
- After arena output when Hormozi voice is the desired register
- For business/coaching offers where conversational authority matters

## What It Does

1. Accepts copy input (pasted text or file path)
2. Applies Hormozi's 10 voice rules from `references/voice-patterns.md`
3. Rewrites the surface layer while preserving strategic architecture
4. Outputs Hormozi-voiced version + change log

## What It Does NOT Do

- Replace the strategic argument or offer structure
- Add Hormozi-specific frameworks (Value Equation, etc.) -- this is voice only
- Make copy casual to the point of unprofessional
- Work for every audience -- this is specifically Hormozi's register

## Quick Usage

```
/modernize-hormozi
```

Then paste your copy or provide a file path.

## Process

### Step 1: Ingest

Read the full copy. Map the strategic architecture: proof points, objection handling, stories, CTAs, belief shifts. These elements stay. Only the voice changes.

### Step 2: Apply the 10 Hormozi Voice Rules

For each rule, scan the copy and transform:

1. **Third-grade words** -- Replace all formal/marketing vocabulary. "Implement" -> "do." "Generate leads" -> "get people who want to buy." "Leverage" -> "use." "Optimize" -> "fix." Check against the word replacement table in `references/voice-patterns.md`.

2. **Alternate short punches with long flows** -- Break up any sequence of 3+ sentences of similar length. Insert short declarative punches (3-5 words) between longer explanations. Pattern: Short. Short. Long with story. Short that lands the point.

3. **Lead with specific numbers** -- Replace every rounded number with an exact one. "$50K" -> "$47,000." "Over a decade" -> "13 years." "Significant revenue" -> "$17 million a month." If no specific number exists, remove the vague claim entirely.

4. **Kill formal transitions** -- Replace: "Furthermore" -> "And so." "However" -> "But here's the thing." "Therefore" -> "And so what ends up happening is." "In conclusion" -> "Big picture." "For example" -> "Think about it like this."

5. **Name objections first** -- Find every objection-handling section. Restructure to: Name the objection directly -> Concede the valid part -> Redirect to why the core value holds. Remove any confrontational objection handling.

6. **Urgency through math, not timers** -- Replace every manufactured deadline with opportunity cost math. "This offer expires" -> "Every month you don't do this costs you [specific $]." Remove countdown timers, "only X left," and fake scarcity.

7. **Short stories with one point** -- Cap every story at 200 words max. Ensure each story makes exactly one point. Add specific sensory details. Remove any story that serves no strategic purpose.

8. **Undercut hype** -- Find every superlative or hype claim. Either (a) replace with understated version, or (b) add a self-deprecating qualifier. "The most powerful system" -> "The best one I've found." Add at least one anti-hype statement per page.

9. **CTA = calm instructions** -- Rewrite all CTAs as step-by-step instructions. Remove all caps, exclamation points, and urgency language from buttons and CTA text. "ACT NOW!" -> "Here's what to do next."

10. **Let strong statements breathe** -- After every strong claim or insight, add a paragraph break. Create one-sentence paragraphs. Add white space. Remove any unnecessary explanation after a statement that already landed.

### Step 3: Adverb Elimination

Scan for all adverbs (-ly words, "very," "really," "extremely," "incredibly"). For each:
- Delete it if the sentence works without it
- Replace with a stronger verb if needed: "quickly built" -> "built in 3 days"
- "Incredibly powerful" -> "powerful" (or delete the whole phrase)

### Step 4: Active Voice Pass

Convert all passive constructions to active voice:
- "Results were achieved" -> "We got results"
- "The system was designed to" -> "I built this to"
- "Revenue was generated" -> "We made $X"

### Step 5: Output

**Section A: Hormozi-Voiced Copy**
Full rewritten version, ready to use.

**Section B: Change Log**

| Line | Original | Hormozi Version | Rule # | Reason |
|------|----------|----------------|--------|--------|
| 3 | "Implement our comprehensive system" | "Do the thing" | R1 | Third-grade words |

**Section C: Voice Score**
Rate the original on each of the 10 rules (1-5 scale, 5 = fully Hormozi) and show the after score.

## Reference Files

- `references/voice-patterns.md` -- The complete Hormozi voice pattern library with word replacement tables, cadence rules, and examples from transcripts
