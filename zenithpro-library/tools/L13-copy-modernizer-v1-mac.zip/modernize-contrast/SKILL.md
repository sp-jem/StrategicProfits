---
name: modernize-contrast
description: Surgical copy modernizer. Detects specific dated direct response patterns and replaces them with modern equivalents. Based on contrast analysis of arena output vs. current converting copy.
license: Private
triggers:
  - /modernize-contrast
  - modernize this copy contrast
  - fix dated copy patterns
  - update old copy language
metadata:
  version: 1.0.0
  author: Rich Schefren
  category: copywriting
  updated: 2026-02-01
---

# Copy Modernizer: Contrast Mode

Detects and replaces specific dated direct response patterns with modern equivalents. The most surgical of the modernizer skills -- applies concrete pattern-matching rules derived from comparing arena-generated copy against current high-converting copy.

## When to Use

- After the copywriting arena produces a draft
- When reviewing any direct response copy that feels "2005-2015"
- When copy sounds like an infomercial, uses ALL CAPS emphasis, or has manufactured urgency
- As a post-production pass on any sales copy before publishing

## What It Does

1. Accepts copy input (pasted text or file path)
2. Scans for 40+ specific dated patterns across 7 categories
3. Replaces each dated pattern with its modern equivalent
4. Preserves the strategic/architectural layer (proof structure, objection handling, belief shifts)
5. Outputs the modernized version + a detailed change log

## What It Does NOT Do

- Rewrite strategic structure (keeps the persuasion architecture intact)
- Change the core argument or offer positioning
- Remove urgency entirely (replaces manufactured urgency with authentic urgency)
- Dumb down or shorten copy unnecessarily
- Clone any single voice (this skill is pattern-replacement, not voice-matching)

## Quick Usage

```
/modernize-contrast
```

Then paste your copy or provide a file path.

## Input

The user provides copy in one of these ways:
- Paste directly into chat
- Provide a file path to a markdown or text file
- Reference a specific arena output by project name

## Process

### Step 1: Ingest and Read

Read the full copy. Do NOT skim. Understand the strategic intent, the argument flow, and the offer structure before changing anything.

### Step 2: Pattern Detection

Scan every line against the replacement rules in `references/replacement-rules.md`. For each match, flag it with the rule ID.

### Step 3: Apply Replacements

For each flagged pattern:
1. Identify the dated pattern and its rule ID
2. Generate the modern replacement, preserving the strategic intent
3. Log the change

**Critical constraint:** When replacing a pattern, preserve:
- The underlying persuasion mechanism
- The proof being offered
- The specific claim or number
- The emotional target
- The narrative flow

Only change the **surface language** -- the word choices, formatting, tone markers, and delivery style.

### Step 4: Output

Produce two sections:

**Section A: Modernized Copy**
The full rewritten copy, ready to use.

**Section B: Change Log**
A table showing every change made:

| Line | Original | Modernized | Rule | Reason |
|------|----------|------------|------|--------|
| 3 | "THEY LIED TO YOU" | "I didn't know this until last year" | H2 | Accusation-lead -> Admission-lead |
| 7 | "LIES." | "Here's what actually works." | L2 | Standalone accusation -> State what IS true |

## Rules Reference

All replacement rules are in `references/replacement-rules.md`. The rules are organized by copy element:

- **H1-H5**: Headlines
- **L1-L6**: Leads/Openings
- **G1-G3**: Group A/B Patterns
- **B1-B9**: Body Copy
- **U1-U5**: Urgency/Scarcity
- **C1-C5**: CTAs/Closes
- **P1-P4**: Proof Sections
- **F1-F4**: Formatting

## Arena Context

This skill was built by analyzing actual arena output from:
- Black Friday Profit System (Clayton, Evaldo, Deutsch, Carlton drafts)
- CEO Performance Institute (Clayton, Carlton, Deutsch, Evaldo drafts)
- AI Execution Engine (Carlton-primary synthesis draft)

The arena's strategic/architectural layer is strong. The language/surface layer is where modernization happens. See `references/arena-analysis.md` for methodology-specific observations.

## Quality Check

After modernization, verify:
1. No ALL CAPS emphasis remains (except brand names or acronyms)
2. No "LIES." / "WRONG." / "BULL." standalone sentences remain
3. No "Group A / Group B" binaries remain
4. No "ACT NOW" / "RIGHT NOW" urgency commands remain
5. No multiple P.S. sections remain
6. The skim path (headlines + subheads + bold + bullets) tells a complete story
7. Paragraphs are 1-3 sentences max
8. The strategic argument is fully preserved
