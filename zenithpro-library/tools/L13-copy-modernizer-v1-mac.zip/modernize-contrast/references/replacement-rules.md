# Modernize-Contrast: Complete Replacement Rules

Master reference of dated-to-modern pattern replacements. Organized by copy element. Each rule has an ID for change log tracking.

**Version:** 2.0 | **Rules:** 86 | **Categories:** 16
**Sources:** Perplexity Deep Research Q1-Q3, Claude Deep Research Q1, fetched sales pages (ProDentim, JavaBurn, Secret Email System, etc.), VSL teardowns, arena contrast analysis, approach-1/2/3 voice references, modern-vs-dated-research.md

---

## Headlines (H1-H8)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| H1 | ALL CAPS words in headlines ("THEY LIED", "EXPOSED", "REVEALED") | Lowercase. Let word choice carry the weight. | "THEY LIED TO YOU About Black Friday" -> "I spent three Black Fridays grinding for $15K while a guy down the street cleared $680K" |
| H2 | Accusation-lead headlines ("They don't want you to know", "The gurus are hiding") | Admission-lead headlines ("I didn't know this until...", "I was wrong about this for...") | "EXPOSED: The Secret System That..." -> "I spent 3 years figuring out why my ads didn't work. Here's what I found." |
| H3 | Headlines longer than 3 lines on screen | 1-2 lines max. Use subhead for expansion. | 7-line rhetorical question -> Short statement + one-line setup |
| H4 | Rhetorical question headlines spanning 5+ lines | Short statement + one-line setup | "How Does A Guy Who Failed..." (7 lines) -> "I had $47K in courses. Finished four. Implemented zero." + "Then AI changed the math." |
| H5 | Superlative claims ("The MOST powerful", "The ULTIMATE") | Specific claims with numbers ("went from $X to $Y", "in X days") | "The MOST POWERFUL system ever created" -> "The system that took me from $12K to $89K months in 7 months" |
| H6 | Forbidden knowledge framing ("The Secret [X] Don't Want You to Know", "Hidden for 30 years") | Direct statement of what you found and how ("I tested 340 campaigns over 6 years. Here's what works.") | "The Secret Doctors Don't Want You to Know" -> "What I found after reviewing 2,400 split tests across 6 years" |
| H7 | Curiosity gap vagueness ("You Won't Believe What Happened Next", "This Will Shock You") | State the thing. If it's surprising, the reader will feel it. | "What She Did Next Was Shocking" -> "She cut her ad spend by 60% and tripled her leads. Here's the one change she made." |
| H8 | "WARNING:" / "ATTENTION:" / "ALERT:" opener | Drop the label. Start with the information. | "WARNING: Don't Buy Any Course Until You Read This" -> "Most courses teach theory. This one runs the system for you." |

---

## Leads / Openings (L1-L8)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| L1 | Opening with "The gurus told you..." or "They said..." | Open with a specific scene. A moment. A Tuesday at 9:47 AM. | "The gurus told you it's about discounts..." -> "It's 9:47 AM on a Tuesday. Your phone rings." |
| L2 | "LIES." / "WRONG." / "BULL." as standalone sentence | State what IS true instead of accusing what isn't. | "LIES." -> "Here's what actually works." |
| L3 | Scare quotes around "gurus" / "experts" / "coaches" | Name specific people or don't reference others at all. | The "gurus" told you -> [Name] taught me / Most people believe |
| L4 | "I need to tell you something that's going to sound absolutely insane" | Just tell them. If it's insane, they'll feel it. | Cut the preamble. Start with the thing. |
| L5 | "If you're like most [X]..." | "You already know [specific thing]." Assume intelligence. | "If you're like most entrepreneurs..." -> "You already know your email sequence isn't converting." |
| L6 | "Dear Fellow [X]" salutation | Skip salutation. Start talking. Or use "Look --" | "Dear Fellow Entrepreneur" -> [deleted, start with first line of copy] |
| L7 | "I was skeptical at first, but..." opener (used in testimonials and stories) | Start with the specific thing that happened, not the skepticism. | "I was skeptical at first, but then I tried it and made $15K" -> "I made $15K in my first month. Here's what I did differently." |
| L8 | Stacking three rhetorical questions as opener ("Are you tired of...? Do you wish...? What if...?") | One statement that names the situation. | "Are you tired of working 80-hour weeks? Do you wish you could..." -> "You're working 80-hour weeks and the revenue isn't matching the effort." |

---

## Group A / Group B Patterns (G1-G3)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| G1 | "There are two types of [X]..." | Tell ONE person's story. Let the reader place themselves. | "Two types of store owners..." -> "Last Black Friday, my friend Jake cleared $340K in profit selling kitchen gadgets." |
| G2 | Group A (losers) vs Group B (winners) binary | Show a specific person's before/after. Real name if possible. | Group A: $12K / Group B: $340K -> "Jake's competitor -- better products, bigger list -- made $23K. Same weekend." |
| G3 | Rigged comparison where one group is obviously bad | Acknowledge the old way was reasonable. Show why a new approach works better. | "Group A is running the same failing playbook" -> "He was doing everything right by the old playbook. The math just changed." |

---

## Body Copy (B1-B14)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| B1 | ALL CAPS for emphasis throughout body copy ("EXECUTE", "DOES THE WORK", "PROFIT") | Bold for selective emphasis. Or use stronger words that don't need caps. | "An AI agent that DOES THE WORK" -> "An agent that holds the expert's complete system and **runs it on command**" |
| B2 | Escalation language ("even crazier", "even more powerful", "even more incredible") | State the next fact plainly. If it's powerful, the reader will feel it. | "And then I did something even crazier:" -> "Then I took it further." |
| B3 | "Not [X]. Not [Y]. BUT [Z]!" triple reveal construction | Streamline to one contrast: "Not X. Instead, Y." Or: "Not X. An agent that [specific thing]." | "Not a chatbot. Not a tool. But a COMPLETE SYSTEM!" -> "Not a chatbot. An agent that holds the complete system and runs it." |
| B4 | Scare quotes on straw-man alternatives ("helps you brainstorm", "gives you ideas") | Name the alternative plainly without scare quotes. | Not a tool that "helps you brainstorm" -> Not a brainstorming tool |
| B5 | "PLUG-AND-PLAY" / "DONE-FOR-YOU" / "TURNKEY" / "SET-AND-FORGET" | Plain language: "ready to use", "built for you", "works out of the box" | "These are PLUG-AND-PLAY" -> "They're ready to use. No setup. Pick one and run it." |
| B6 | "Here's the shocking truth..." / "Here's what nobody tells you..." / "The dirty secret is..." | "Here's what actually happened..." or just state the truth directly | "Here's the shocking truth about AI" -> "Here's what happened when I tested it" |
| B7 | Repeated "everything changed" / "that's when everything changed" / "and then it all clicked" | Specific: state what actually changed. "I went from [X] to [Y]." Use ONE "something clicked" per piece max. | "Everything changed" -> "I went from 4 hours per draft to 20 minutes" |
| B8 | "Let me be clear:" / "Make no mistake:" / "Listen carefully:" | Just be clear. Don't announce clarity. | "Let me be clear: this is not a course." -> "This is not a course." |
| B9 | "Here's the thing..." / "Here's the thing about [X] most people don't get:" (overused) | Use ONCE per piece, maximum. Replace extras with direct statements. | Third "here's the thing" in a draft -> [cut, start with the statement] |
| B10 | "The fact of the matter is..." / "The truth is..." / "The reality is..." filler openers | Cut the filler. Start with what the matter/truth/reality actually is. | "The fact of the matter is, most businesses fail" -> "Most businesses fail." |
| B11 | "You see, the problem is..." / "You see," as patronizing verbal tic | "The problem is..." or just state the problem directly. | "You see, the problem is nobody teaches implementation" -> "Nobody teaches implementation." |
| B12 | "Listen, I'm going to level with you..." / "I'm going to be completely honest with you..." | Just level with them. Just be honest. Don't announce it. | "Listen, I'm going to level with you about this industry..." -> [deleted, start with the honest statement] |
| B13 | "Now, I know what you're thinking..." followed by a straw-man objection | "The obvious question is [X]. Fair. Here's the answer." | "Now, I know what you're thinking -- this sounds too good to be true" -> "The obvious question: why would this work when nothing else has? Fair." |
| B14 | "But that's not all..." / "And it gets even better..." infomercial bridges | Just present the next thing. No bridge needed. | "But that's not all! You also get..." -> [new paragraph] "Module 3 covers..." |

---

## Urgency / Scarcity (U1-U8)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| U1 | "Window closes forever" / "Last chance ever" / "Never offered again" | State the real timeline and real consequence. | "This window closes forever" -> "I'm accepting new clients only during February because I'm bringing current clients into implementation phase." |
| U2 | "The clock is ticking/running" / generic time pressure | Be specific with math: "48 hours. Setup takes 4." | "The clock is running." -> "Black Friday is in 48 hours. This system takes about 4 hours to set up." |
| U3 | "Your choice." / "The decision is yours." as mic-drop close | Don't close with a false binary. Close with a clear next step. | "Your choice." -> "You already know how last year went." |
| U4 | "Or widen permanently" / permanent negative consequences for inaction | Be honest about real timeline: "Another chance next year. But that's 12 months of [status quo]." | "The gap widens permanently" -> "You'll have another shot next year. That's 12 more months running the old play." |
| U5 | "Not because of some fake deadline" / defending your urgency | If you have to say it's not fake, the reader already suspects. Just state the real reason without the defense. | "Not because of some fake deadline. Because Black Friday starts in 48 hours" -> "Black Friday starts in 48 hours. Either you have the system running by then or you don't." |
| U6 | Countdown timers that reset on page refresh | If using a timer, tie it to a real event (cohort start, price increase date). Or remove it entirely. | Evergreen countdown timer -> "Cohort 4 starts March 15. Enrollment closes March 10." |
| U7 | "Only [X] spots left!" with no credible reason for the cap | If there IS a cap, explain why: capacity, coaching bandwidth, server limits. If there isn't, drop it. | "Only 7 spots left!" -> "I cap enrollment at 50 because I review everyone's work weekly. I can't do that for 500 people." |
| U8 | "Don't be left behind!" / "Don't let your competitors get ahead!" / fear-of-missing-out guilt | Let the reader's own situation create the urgency. State the opportunity cost. | "Don't be left behind while your competitors use AI!" -> "Your competitors are already doing this. Not all of them, but the ones growing fastest." |

---

## CTAs / Closes (C1-C8)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| C1 | "ACT NOW" / "RIGHT NOW" / "IMMEDIATELY" / "ORDER TODAY" | "Here's what to do next" / "next" / "you'll have access within minutes" | "HERE'S EXACTLY WHAT TO DO RIGHT NOW" -> "Here's what to do next." |
| C2 | ALL CAPS section headers for CTA areas | Normal case. Calm authority. | "ORDER NOW AND GET INSTANT ACCESS" -> "Get access now" |
| C3 | "Don't wait!" / "Don't miss this!" / "Don't let this pass you by!" | Remove entirely. If the copy did its job, they don't need to be told not to wait. | "Don't miss this incredible opportunity!" -> [deleted] |
| C4 | "Start [dreaming/winning/printing money]!" cliche closes | Specific first step: "Start with Module 1" / "Pick one course and run it" | "Stop grinding. Start printing money." -> "Start with Module 1. Pick one methodology. Run it on your next project." |
| C5 | Multiple P.S. sections (P.S., P.P.S., P.P.P.S.) | One P.S. maximum with genuine value add. If you need three, the body copy missed something. | P.S. + P.P.S. + P.P.P.S. -> Single P.S. with the strongest point |
| C6 | "CLAIM YOUR SPOT!" / "CLAIM YOUR COPY!" / command-structure CTAs | Invitation language: "See if this is right for you" / "Try it for 30 days" | "CLAIM YOUR SPOT NOW!" -> "See if this is a fit. Try it for 30 days -- no credit card required." |
| C7 | Button text using power verbs ("SEIZE", "DEMAND", "UNLOCK", "UNLEASH") | Benefit-oriented button text: "Start my free trial" / "Get access" / "Join now" | "UNLEASH YOUR POTENTIAL NOW" -> "Start my free trial" |
| C8 | Single CTA only at bottom of page after full read-through | Multiple CTAs placed strategically throughout -- some readers are ready early. | One "Buy Now" at the end -> CTA after proof section, after offer breakdown, and at close |

---

## Proof Sections (P1-P7)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| P1 | "PROOF THAT..." / "PROOF THIS ISN'T JUST THEORY" headers | "Here's what happened." Or no header -- just go into the case study. | "PROOF THIS ISN'T JUST THEORY" -> "Here's what happened when I tested it." |
| P2 | "Let me show you..." / "Let me explain..." / "Allow me to demonstrate..." | Just show. Just explain. Don't announce it. | "Let me show you what this looks like in practice." -> [deleted, go straight to the example] |
| P3 | "But don't just take my word for it..." | Include the proof inline. Don't frame it as separate from the pitch. | "Don't take my word for it -- here's what Sarah said:" -> [weave Sarah's result into the narrative] |
| P4 | Vague testimonials ("This changed my life!" -- John D.) | Named, specific, verifiable: "Sarah Chen went from $12K/mo to $89K/mo in 7 months. She sells ceramics on Shopify." | "Amazing results! Highly recommend! -- J.D." -> "Sarah used this to go from $12K/mo to $89K/mo in 7 months selling handmade ceramics on Shopify." |
| P5 | "As seen in [logo wall]" without context | If you've been featured, say what the feature was about and link to it. | Row of logos (Forbes, Inc, Entrepreneur) -> "I wrote about this framework for Inc Magazine in 2024. [link] Here's what happened after." |
| P6 | Stacking 20+ testimonials in a wall | 3-5 strong, specific testimonials outperform 20 generic ones. Quality over quantity. | 20 short vague testimonials -> 4 detailed case studies with names, numbers, timelines, and context |
| P7 | Income/result claims with no context ("$50,000 in 30 Days!") | Include the baseline, the timeline, the effort, and what's NOT included. | "$50,000 in 30 Days!" -> "Michael went from 12 leads/month to 156 in month one. His cost per lead dropped from $89 to $31. Full case study here." |

---

## Formatting (F1-F6)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| F1 | ALL CAPS for section headers | Title Case or Sentence case | "HERE'S WHAT YOU GET" -> "Here's what you get" |
| F2 | Long paragraphs (5+ sentences) | 1-3 sentences per paragraph. White space between. | Dense 8-sentence paragraph -> Break into 3-4 short paragraphs |
| F3 | No skim path (wall of text) | Bold + subheads must tell a complete story if you only read those | Add subheads every 200-300 words; bold key claims |
| F4 | Underlines for emphasis | Bold only. Underlines look like hyperlinks on screen. | Underlined text -> **Bold text** |
| F5 | Red text / yellow highlight / multiple font colors for emphasis | Single accent color maximum. Let formatting hierarchy (H1/H2/bold/regular) do the work. | Red + yellow + blue text -> Black text with **bold** for emphasis |
| F6 | Dense bullet stacks of 20+ items with no grouping | Group bullets under subheads (7-12 per group max). Each bullet does real work. | 30-bullet feature dump -> 3 groups of 5-7 bullets, each group under a benefit-oriented subhead |

---

## Bullets / Fascinations (BL1-BL7)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| BL1 | "The AMAZING secret to..." | "How to [specific outcome] (page 47)" | "The AMAZING secret to doubling your list" -> "How to add 1,000 subscribers in 30 days without paid ads (Module 3)" |
| BL2 | "How to INSTANTLY..." | "The fastest path to [X] I've found" | "How to INSTANTLY boost conversions" -> "The split test that doubled my conversion rate in one afternoon" |
| BL3 | "The #1 mistake that's KILLING your..." | "The mistake I kept making until [specific moment]" | "The #1 mistake KILLING your sales" -> "The pricing mistake I made for two years before a client pointed it out" |
| BL4 | "Little-known technique..." / "Secret method..." | "Something I learned from [specific person/source]" | "A little-known technique for..." -> "Something I picked up from running 2,400 split tests" |
| BL5 | "And much, MUCH more!" as final bullet | Don't. End with your strongest bullet. | "And much, MUCH more!" -> [deleted -- end on strongest bullet] |
| BL6 | Adjective-stacked bullets ("The INCREDIBLE, PROVEN, POWERFUL method...") | One specific claim per bullet. No stacking adjectives. | "The INCREDIBLE, POWERFUL, PROVEN method to..." -> "The method that generated 34% more leads in our Q3 test" |
| BL7 | Page-reference fascinations with no specificity ("A secret on page 12 that will blow your mind") | Specific outcome: "The 3-step email sequence on page 12 that recovered $23K in abandoned carts" | "A secret on page 12 that will blow your mind" -> "The email template on page 12 that recovered $23K in abandoned carts for one Shopify store" |

---

## Rhetorical Patterns (R1-R6)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| R1 | Stacking 3+ rhetorical questions in a row | One question, then answer it. | "Are you tired of...? Do you wish...? What if...?" -> "You're probably wondering why none of this has worked. Here's what I found." |
| R2 | "What if I told you..." | Just tell them. | "What if I told you there was a way to..." -> "There's a way to [X]. Here's how it works." |
| R3 | "Imagine if..." used more than once per piece | One "imagine" max. Replace extras with "Think about..." or specific scenes. | Third "imagine if" -> "Last month, Sarah [specific thing that happened]" |
| R4 | "But wait, there's more!" / infomercial cadence | Just present the next thing. No bridge needed. | "But wait, there's more!" -> [deleted, start next section] |
| R5 | "Imagine waking up to..." hypothetical future painting | Specific real scene: "Last Tuesday, I opened my laptop and..." | "Imagine waking up to $10,000 in your account" -> "Last Tuesday I checked Stripe. $10,247. While I was asleep." |
| R6 | "What if there was a way to..." permission-seeking framing | Tell them there IS a way. | "What if there was a way to double your revenue without working more?" -> "There's a way to double your revenue without adding hours. Here's how it works." |

---

## Tone Markers (T1-T8)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| T1 | Exclamation point stacking (!! or !!!) | Period. Let the content create excitement. One ! per 500 words max. | "This is incredible!!!" -> "This is the best result I've seen." |
| T2 | "DISCOVER" / "UNLEASH" / "UNLOCK" / "HARNESS" power verbs | Plain verbs: "learn", "use", "get", "find" | "UNLEASH the power of AI" -> "Use AI to do the work" |
| T3 | "Revolutionary" / "Groundbreaking" / "Game-changing" superlatives | "It's the best I've found" / "This changed how I think about [X]" | "This revolutionary system" -> "This system (it's the best I've tested)" |
| T4 | Manufactured enthusiasm ("I'm SO excited to share this!") | Matter-of-fact delivery. If it's good, say why specifically. | "I'm SO excited about this!" -> "This outperformed everything else I tested." |
| T5 | "You deserve..." aspirational language | "You're probably thinking..." direct address of actual mental state | "You deserve financial freedom!" -> "You're probably thinking this sounds too simple. Here's why it works." |
| T6 | "Literally" used for emphasis (not literally literal) | Delete it. Or replace with a specific number. | "This will literally change your life" -> "This changed how I run my business" |
| T7 | Marketing jargon as selling language ("leverage", "optimize", "monetize", "scale") | Plain words: "use", "fix/improve", "make money from", "grow" | "Leverage our proprietary framework to optimize your monetization strategy" -> "Use this system to make more money from what you're already doing" |
| T8 | "World-class" / "Best-in-class" / "Industry-leading" self-descriptions | Specific credential or result: state what you did, let them judge the class. | "Our world-class team" -> "Our team has managed $600M in ad spend across 340 campaigns" |

---

## Email Patterns (E1-E5)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| E1 | Hard-close every email with aggressive CTA ("BUY NOW before midnight!") | One email, one idea. Soft CTA only when it serves the content. Daily value > occasional hard sell. | "CLICK HERE NOW before this offer DISAPPEARS!" -> "If this resonates, here's the link. If not, tomorrow's email covers [next topic]." |
| E2 | "Discover The Millionaire's Secret" / hype subject lines | Conversational subject lines that sound like a friend texting | "REVEALED: The $10M Secret To..." -> "weird thing happened with my ads yesterday" |
| E3 | Long emails that try to be complete sales letters | Short, punchy, one-idea emails. Save the full pitch for the sales page. | 2,000-word email with offer breakdown -> 200-word story + "full details here" link |
| E4 | "Dear [First Name]," formal email opening | No salutation, or casual: "Hey --" / "Quick thing:" / Just start talking. | "Dear Richard," -> "So I tried something stupid last week." |
| E5 | Multiple links/CTAs per email pulling attention in different directions | One link. One action. Repeated 2-3 times max in different contexts. | 5 different links in one email -> Same link placed after the hook, after the proof, and in the P.S. |

---

## Guarantee Language (GU1-GU4)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| GU1 | "RISK-FREE NO-QUESTIONS-ASKED IRON-CLAD 100% MONEY-BACK GUARANTEE!!!" (all caps, stacked adjectives) | State the guarantee plainly and specifically. | "RISK-FREE IRON-CLAD UNCONDITIONAL GUARANTEE!!!" -> "If it doesn't work for you, email me within 60 days. Full refund. You keep everything." |
| GU2 | "You literally have NOTHING to lose!" | You do have something to lose -- time, attention. Acknowledge that. | "You have NOTHING to lose and EVERYTHING to gain!" -> "The only risk is your time. This takes about 4 hours to implement. If it doesn't work, you get a full refund." |
| GU3 | Guarantee sections longer than the offer description | Keep the guarantee shorter than the offer. 2-3 sentences. | Half-page guarantee section -> "60-day money-back guarantee. Email support@[x].com. Full refund, no questions." |
| GU4 | "Double your money back" / unbelievable guarantee promises | Simple, credible, easy-to-execute refund terms | "Triple your money back if it doesn't work!" -> "Try it for 60 days. If you don't see results, I'll refund every penny." |

---

## VSL-Specific Patterns (V1-V4)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| V1 | Premature authority introduction (credentials dump in first 60 seconds) | Hook with the problem or result first. Credentials come AFTER the audience is interested. | "Hi, I'm Dr. Smith, board-certified in..." (second sentence) -> Lead with the discovery/result, introduce yourself at the 2-3 minute mark |
| V2 | Aggressive escalating CTAs every 2 minutes through the VSL | One calm CTA at the reveal, one at the close. Let the content sell. | "Click the button NOW!" repeated 8 times -> "When you're ready, the button is below. Let me walk you through what you get." |
| V3 | Manufactured dark-night-of-soul opener ("I was at rock bottom, about to lose everything...") | Real moment with specific detail. If the dark night was real, give the specific scene. If it wasn't, don't manufacture it. | "I was seconds away from bankruptcy, my wife was leaving, the dog was sick..." -> "I was sitting in my car outside the office at 11pm, doing the math on a napkin. The numbers didn't work." |
| V4 | "Stay with me because what I'm about to reveal will change everything" retention hooks | Provide immediate micro-value so they WANT to stay. Don't beg for attention. | "Stay with me, this is going to blow your mind" -> "Here's the first thing I changed -- and it's something you can do today, even without buying anything." |

---

## Story / Narrative Patterns (S1-S4)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| S1 | Overuse of "I was skeptical but..." origin stories (everyone's skeptical, no one cares) | Start with the result, then explain what you did differently. Skepticism is assumed. | "I was skeptical, but I tried it and wow..." -> "I tried the three-step process and my leads went from 12/month to 156." |
| S2 | Stories longer than 200 words that meander before making a point | One story, one point, under 200 words. State the point before OR after. Never both. | 600-word backstory -> 150-word story with specific sensory details + one clear takeaway |
| S3 | "And then something clicked..." / "That's when the lightbulb went off..." / "Suddenly it all made sense" (used repeatedly) | Use ONE of these per piece maximum. Replace extras with specific: "I realized [X] was the problem, not [Y]." | Third "something clicked" -> "I realized I'd been optimizing the wrong metric. Traffic wasn't the problem. Conversion was." |
| S4 | Constructed stories that didn't happen (fake specificity) | If you don't have a real story, use a case study or skip the story. | "I was standing in line at Starbucks when it hit me..." [never happened] -> [Use an actual client case study or data point instead] |

---

## Objection Handling Patterns (O1-O5)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| O1 | "If you're the type of person who makes excuses..." / shaming the objection | Validate the concern, then provide evidence. | "If you're the type who always finds a reason not to act..." -> "I understand price is a real consideration. Here's what makes it worth it:" |
| O2 | "You can't afford NOT to do this!" / reversed-cost guilt | State the opportunity cost with real math, then let them decide. | "You can't afford NOT to invest in yourself!" -> "You're currently spending about 40 hours/month doing this manually. That's 40 hours you could be [specific alternative]." |
| O3 | Dismissing time objections ("If you REALLY wanted it, you'd find the time") | Acknowledge the constraint, show how the product fits within it. | "Stop making excuses about time" -> "We designed this for people with full-time jobs. Average time commitment: 45 minutes/week. 73% of students complete it while working full-time." |
| O4 | "This isn't for everyone" used as exclusivity play (when it obviously IS for everyone) | If there ARE real disqualifiers, state them honestly. If there aren't, drop the false exclusivity. | "This isn't for tire-kickers or people who don't take action" -> "This works best for [specific situation]. If you're in [different situation], [alternative] might be a better fit." |
| O5 | Attacking competitor solutions by name or category ("Unlike those other programs that just give you theory...") | Focus on what yours does, not what others don't. | "Unlike those other useless courses..." -> "This includes implementation support. You don't just learn -- you build." |

---

## Offer Presentation (OP1-OP4)

| ID | Dated Pattern | Modern Replacement | Example |
|----|--------------|-------------------|---------|
| OP1 | Value stacking with inflated prices ("Module 1: $2,997 value! Module 2: $4,997 value! Total value: $47,000!") | State what each component DOES, not what it's "worth". | "Module 1 ($2,997 value)" -> "Module 2 walks you through building your first funnel. Most people finish this in a weekend." |
| OP2 | "But you won't pay $47,000... You won't even pay $10,000... Today, for the first time ever..." price drop sequence | State the price directly. One comparison only (if real): "That's less than one month of [tool they already pay for]." | "Not $10,000... Not $5,000... Not even $1,000..." -> "It's $497. That's less than what most people spend on one month of ads that don't convert." |
| OP3 | Bonus stacking (8-12 bonuses, each with inflated value) | 2-3 bonuses that genuinely complement the core offer. Each one earns its place. | 10 bonuses totaling "$27,000 in value" -> "Two bonuses: [specific thing that solves specific gap] and [specific thing that accelerates results]." |
| OP4 | "If you act in the next [X] minutes, I'll also throw in..." artificial time-triggered bonuses | If a bonus has real limited availability, explain why. If not, just include it in the offer. | "Order in the next 15 minutes and get this bonus worth $997!" -> "Everyone who joins gets [bonus]. It's part of the package." |

---

## Quick Reference: Rule Count by Category

| Category | Rules | IDs |
|----------|-------|-----|
| Headlines | 8 | H1-H8 |
| Leads/Openings | 8 | L1-L8 |
| Group A/B Patterns | 3 | G1-G3 |
| Body Copy | 14 | B1-B14 |
| Urgency/Scarcity | 8 | U1-U8 |
| CTAs/Closes | 8 | C1-C8 |
| Proof Sections | 7 | P1-P7 |
| Formatting | 6 | F1-F6 |
| Bullets/Fascinations | 7 | BL1-BL7 |
| Rhetorical Patterns | 6 | R1-R6 |
| Tone Markers | 8 | T1-T8 |
| Email Patterns | 5 | E1-E5 |
| Guarantee Language | 4 | GU1-GU4 |
| VSL Patterns | 4 | V1-V4 |
| Story/Narrative | 4 | S1-S4 |
| Objection Handling | 5 | O1-O5 |
| Offer Presentation | 4 | OP1-OP4 |
| **TOTAL** | **86** | |
