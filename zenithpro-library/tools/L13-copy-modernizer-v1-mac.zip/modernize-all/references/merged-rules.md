# Merged Modernization Rules: Priority-Ordered Master Ruleset

**Version:** 1.0 | **Total Rules:** 122 (86 contrast + 20 current-dimension + 16 hormozi)

This file consolidates all modernization rules across the three skill layers, ordered by execution priority. When rules conflict, the resolution table at the bottom governs.

---

## Tier 1: Contrast Rules (Highest Priority -- Surgical Replacements)

These are pattern-level find-and-replace rules. Apply first because they're the most specific and least ambiguous.

**Source:** `modernize-contrast/references/replacement-rules.md`

### Headlines (H1-H8)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| H1 | ALL CAPS words in headlines | Lowercase + bold for emphasis |
| H2 | Accusation-lead ("They lied to you") | Admission-lead ("I spent 3 years getting this wrong") |
| H3 | Headlines > 3 screen lines | 1-2 lines + subhead doing heavy lifting |
| H4 | Rhetorical question headlines (5+ lines) | Statement + specific outcome |
| H5 | Superlative claims ("most powerful ever") | Specific before/after numbers |
| H6 | "Discover the little-known secret..." | Anti-secret: "Here's what actually works" |
| H7 | Curiosity-gap vagueness | Benefit-forward clarity |
| H8 | "WARNING: Don't [X] until..." | Story-lead or specific cost of inaction |

### Leads (L1-L8)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| L1 | "The gurus told you..." | Specific scene opening |
| L2 | "LIES." / "WRONG." standalone | Factual contradiction with evidence |
| L3 | Scare quotes on "gurus"/"experts" | Name specific alternatives tried |
| L4 | "I need to tell you something insane" | Just tell them the thing |
| L5 | "If you're like most [X]..." | Assume intelligence, start specific |
| L6 | "Dear Fellow [X]" salutation | No salutation or "Look --" |
| L7 | "I need to make a confession..." | State the admission directly |
| L8 | 3+ stacked rhetorical questions | One question, then answer it |

### Body Copy (B1-B14)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| B1 | ALL CAPS emphasis in body | **Bold** or stronger word choice |
| B2 | Escalation language ("even crazier") | Plain statement of next fact |
| B3 | "Not X. Not Y. BUT Z!" triple reveal | Single contrast statement |
| B4 | Scare quotes on straw-man alternatives | Name specific alternatives by name |
| B5 | "PLUG-AND-PLAY" / "DONE-FOR-YOU" | Plain language: "ready to use" |
| B6 | "Here's the shocking truth..." | State the truth without announcement |
| B7 | Repeated "everything changed" | Specific change with number |
| B8 | "Let me be clear:" / "Make no mistake:" | Delete and just be clear |
| B9 | "Here's the thing..." overuse (3+) | Use once max, vary phrasing |
| B10 | "But that's not all..." | Delete or just list next item |
| B11 | "You see, the problem is..." | State the problem directly |
| B12 | "Listen, I'm going to level with you" | Just level with them |
| B13 | "The fact of the matter is..." | Delete (pure filler) |
| B14 | "REVOLUTIONARY" / "GROUNDBREAKING" | Specific: what it does differently |

### Urgency (U1-U8)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| U1 | "Window closes forever" | Real timeline + real consequence |
| U2 | "The clock is ticking" | Math-based urgency (cost per week of delay) |
| U3 | "Your choice." mic-drop close | Specific next step with empathy |
| U4 | "Permanently" / permanent negative | Time-bound realistic consequence |
| U5 | "Not because of some fake deadline" | Don't defend urgency, state the reason |
| U6 | Countdown timers that reset | Genuine enrollment windows with reason |
| U7 | "Only [X] spots left!" (static) | Capacity constraint with explanation |
| U8 | FOMO shaming ("don't be left behind") | Competitive reality without shame |

### CTAs (C1-C8)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| C1 | "ACT NOW" / "RIGHT NOW" | "Here's what to do next" |
| C2 | ALL CAPS CTA headers | Sentence case, calm tone |
| C3 | "Don't wait!" / "Don't miss this!" | Let the copy do the work, delete |
| C4 | "Stop [neg]. Start [pos]!" bumper sticker | Specific first implementation step |
| C5 | Multiple P.S. sections | One P.S. max with genuine new point |
| C6 | "Click Here" / "Submit" buttons | Outcome-focused: "Get the Framework" |
| C7 | Power verb commands ("CLAIM YOUR SPOT") | Calm instructions: "Join the Cohort" |
| C8 | Multiple competing CTAs | One primary CTA, one secondary max |

### Proof (P1-P7)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| P1 | "PROOF THAT..." headers | Just present the evidence |
| P2 | "Let me show you..." / "Let me explain..." | Just show them |
| P3 | "But don't just take my word for it..." | Integrate proof into narrative |
| P4 | Vague testimonials ("changed my life" -- John D.) | Named + specific + verifiable |
| P5 | Logo wall without context | Explain what each feature covered |
| P6 | 20+ stacked testimonials | 3-5 specific with process detail |
| P7 | "I'm one of the world's leading experts" | Demonstrate with specific numbers |

### Formatting (F1-F6)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| F1 | ALL CAPS section headers | Sentence case with bold |
| F2 | Paragraphs > 3 lines on mobile | Max 2 sentences per paragraph |
| F3 | No skim path (wall of text) | Subheads every 200-300 words |
| F4 | Underlines for emphasis | Bold or italics |
| F5 | Color/highlight abuse | Strategic bold only |
| F6 | 30+ bullet stacking | Max 12 bullets, then new section |

### Bullets (BL1-BL7)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| BL1 | "The AMAZING secret to..." | Specific outcome with number |
| BL2 | "How to INSTANTLY..." | Honest timeline |
| BL3 | "The #1 mistake KILLING your..." | Specific mistake with consequence |
| BL4 | "Little-known technique..." | Named technique with attribution |
| BL5 | "And much, MUCH more!" | Delete or add one more real bullet |
| BL6 | Adjective-stacking bullets | One descriptor max per bullet |
| BL7 | Vague fascinations with no specifics | Concrete details or delete |

### Rhetorical (R1-R6)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| R1 | 3+ rhetorical questions stacked | One question, then answer |
| R2 | "What if I told you..." | Just tell them |
| R3 | "Imagine if..." used 2+ times | One "imagine" per piece max |
| R4 | "But wait, there's more!" | Delete (infomercial) |
| R5 | "Have you ever wondered..." | Rewrite as direct statement |
| R6 | Permission-seeking ("Can I be honest?") | Just be honest |

### Tone (T1-T8)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| T1 | Exclamation point stacking (!!!) | One ! per 500 words max |
| T2 | "DISCOVER" / "UNLEASH" / "UNLOCK" | Plain verbs: "find" / "use" / "get" |
| T3 | "Revolutionary" / "Groundbreaking" | Specific what's different |
| T4 | Manufactured enthusiasm ("SO excited!") | Earned enthusiasm through specifics |
| T5 | "You deserve..." aspirational | Address actual situation |
| T6 | "Literally" (non-literal usage) | Delete |
| T7 | Jargon / corporate buzzwords | Plain language equivalent |
| T8 | Self-describing ("As an expert...") | Demonstrate through evidence |

### Email Patterns (E1-E5)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| E1 | Hype subject lines ("DISCOVER THE SECRET") | Curiosity through specifics |
| E2 | Multi-idea emails | One idea per email |
| E3 | Fake-urgency subjects ("LAST CHANCE") | Real deadline with reason |
| E4 | Sales-letter format in email body | Conversational, one-screen length |
| E5 | Clickbait subjects | Honest preview of content |

### Guarantee Language (GU1-GU4)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| GU1 | "100% MONEY-BACK GUARANTEE!!!" | Calm guarantee with specific conditions |
| GU2 | "ZERO RISK!" | Acknowledge real risk, minimize it |
| GU3 | "You literally have NOTHING to lose!" | State what the guarantee actually covers |
| GU4 | Guarantee longer than the offer | Keep guarantee concise |

### VSL Patterns (V1-V4)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| V1 | "Don't click away" / viewer retention threats | Earn attention through value |
| V2 | 10-minute problem agitation before solution | Solution hint by minute 2 |
| V3 | "What you're about to discover..." | Just start the content |
| V4 | Fake casual ("hey, it's [name] here") | Natural opening tied to content |

### Story/Narrative (S1-S4)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| S1 | Stories > 200 words | Edit to under 200, one point |
| S2 | Multiple morals per story | One story, one point |
| S3 | "And then everything changed" x2+ | Use once max |
| S4 | Stories without specific details | Add names, places, numbers |

### Objection Handling (O1-O5)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| O1 | "If you're the type who makes excuses..." | "What specifically concerns you?" |
| O2 | "Doubters never succeed" | Validate concern, provide evidence |
| O3 | "I know what you're thinking" (3+ times) | Use once, then vary the approach |
| O4 | Dismissing objections as character flaws | Root-cause approach with data |
| O5 | "You owe it to yourself" | "Here's what others in your situation found" |

### Offer Presentation (OP1-OP4)
| ID | Pattern to Kill | Replacement |
|----|----------------|-------------|
| OP1 | "$10,000 VALUE -- Yours for $47!" | State what each component does |
| OP2 | "FREE BONUS" for every component | 2-3 genuine bonuses max |
| OP3 | Price anchoring with fake comparisons | Price anchoring against real alternatives |
| OP4 | "But that's not all!" between bonuses | Clean list format |

---

## Tier 2: Current Dimension Rules (Medium Priority -- Modern Best Practices)

These are dimension-level analysis rules. Apply after contrast replacements to catch patterns the surgical rules missed.

**Source:** `modernize-current/references/modern-patterns.md` + `dated-patterns.md`

| ID | Dimension | Test Question | Action If Failing |
|----|-----------|---------------|-------------------|
| D1 | Urgency | Is ALL urgency tied to genuine business constraints? | Replace manufactured with opportunity-cost math |
| D2 | Proof | Does proof show HOW results were achieved, not just THAT they were? | Add process detail to each proof element |
| D3 | CTAs | Do CTAs tell the reader what happens next, step by step? | Rewrite as calm instructions |
| D4 | Headlines | Are headlines specific, benefit-forward, with subhead doing heavy lifting? | Shorten to 1-2 lines + add subhead |
| D5 | Objections | Is handling empathetic and root-cause? | Replace confrontation with validation + evidence |
| D6 | Rhythm | Max 3 lines per paragraph? Subheads every 200-300 words? | Break up dense paragraphs, add subheads |
| D7 | Tone | Does it sound like a knowledgeable advisor, not an aggressive seller? | Contractions, casual qualifiers, earned confidence |

### 12 Principles Check (applied after dimension analysis)

| ID | Principle | Pass/Fail Test |
|----|-----------|---------------|
| P1 | Sound like a person talking | Would you say this out loud to a friend? |
| P2 | Every sentence earns its place | Does removing it lose proof, clarity, or resonance? |
| P3 | Specificity as credibility | Exact numbers, named people, real timelines? |
| P4 | Admit what's hard or limited | At least one struggle or limitation acknowledged? |
| P5 | One idea per paragraph | No paragraph contains two unrelated points? |
| P6 | Bold for emphasis, not CAPS | ALL CAPS used anywhere? Replace with bold. |
| P7 | Real urgency only | Every deadline tied to genuine constraint? |
| P8 | CTA = instructions | Tells them what happens next, step by step? |
| P9 | Proof through process | Shows HOW, not just THAT? |
| P10 | Anti-hype as trust signal | Actively rejects at least one inflated promise? |
| P11 | One story, one point, under 200 words | Any story exceeds 200 words or makes multiple points? |
| P12 | Designed for two reading speeds | Skim path (headline > subheads > bold > bullets > CTA) tells complete story? |

---

## Tier 3: Hormozi Voice Rules (Lowest Priority -- Optional Layer)

These are voice-level transformations. Apply last as an optional polish. **Skip this tier if the copy's brand voice doesn't align with Hormozi's conversational style.**

**Source:** `modernize-hormozi/references/voice-patterns.md`

| ID | Rule | What It Does |
|----|------|-------------|
| HV1 | Third-Grade Words | Replace formal vocabulary: "implement" → "do", "leverage" → "use" |
| HV2 | The Cadence | Alternate short punches (3-5 words) with long runs (20-40 words) |
| HV3 | Specific Number Anchors | "$46.2 million" not "over $46 million" |
| HV4 | Conversational Transitions | "And so..." not "Furthermore...", "But here's the thing..." not "However..." |
| HV5 | Preemptive Objection Handling | Name-concede-redirect pattern |
| HV6 | Math-Based Urgency | Cost-of-inaction calculations replace manufactured scarcity |
| HV7 | Short Stories | Under 200 words, one point, specific sensory details |
| HV8 | Anti-Hype | For every strong claim, add one qualifier or admission |
| HV9 | Calm CTA Instructions | "Here's what to do next" not "ACT NOW" |
| HV10 | Let Statements Breathe | Paragraph break after strong statements, no explanation |
| HV11 | Rule of One | Every piece centers on ONE big idea |
| HV12 | Sacrificial Lamb Close | Give away one thing to competitor to earn trust for everything else |
| HV13 | Assumed Close | "Which plan do you want?" not "Ready to buy?" |
| HV14 | Questions Control | Reframe trap questions with questions about the question |
| HV15 | Credibility Frontload | One sentence of credentials, then disappear |
| HV16 | "Fair Enough" Micro-Close | Neutral agreement language, not hype language |

---

## Conflict Resolution Table

When rules from different tiers apply to the same text:

| Conflict | Winner | Rationale |
|----------|--------|-----------|
| Contrast H1 (no ALL CAPS) vs Hormozi HV2 (short punches) | Both apply -- short punches in bold, not CAPS | Rules complement, no conflict |
| Contrast U1-U8 (kill fake urgency) vs Hormozi HV6 (math urgency) | Apply both: kill fake, replace with math | Rules complement, no conflict |
| Current D7 (advisor tone) vs Hormozi HV1 (third-grade words) | Current wins on vocabulary level if audience is sophisticated | Hormozi vocabulary too casual for B2B enterprise |
| Current D6 (rhythm/white space) vs Hormozi HV10 (let breathe) | Both apply | Rules complement, no conflict |
| Contrast T2 (kill power verbs) vs Hormozi HV1 (plain verbs) | Both apply -- replace "UNLEASH" with "use" | Rules complement |
| Current P3 (specificity) vs Hormozi HV3 (specific numbers) | Both apply | Rules complement |
| Current D5 (empathetic objections) vs Contrast O1 (kill dismissive) | Both apply | Rules complement |
| Contrast B5 (kill "PLUG-AND-PLAY") vs Hormozi HV1 (plain language) | Both say the same thing: use plain language | Identical intent |
| Current D4 (benefit-forward headlines) vs Contrast H2 (admission-lead) | Contrast wins for cold traffic; Current wins for warm traffic | Context-dependent |
| Current P10 (anti-hype) vs Hormozi HV8 (anti-hype) | Both apply | Rules complement |

**General rule:** Most "conflicts" are actually complementary rules approaching the same principle from different angles. True conflicts are rare and context-dependent (audience sophistication, traffic temperature, brand voice).

---

## Quick Reference: Execution Checklist

```
□ Pass 1: Scan for all 86 contrast patterns (H, L, B, U, C, P, F, BL, R, T, E, GU, V, S, O, OP)
  → Log every replacement with rule ID

□ Pass 2: Score 7 dimensions (D1-D7), each 1-5
  → For any dimension < 3/5, apply modern patterns
  → Run 12 Principles check (P1-P12), flag failures

□ Pass 3 (optional): Apply Hormozi voice rules (HV1-HV16)
  → Skip if brand voice doesn't align
  → Note in output if skipped and why

□ Pass 4: Final verification
  → Re-check 12 Principles
  → Flag anything still failing
  → Score dimensions again for before/after comparison
```
