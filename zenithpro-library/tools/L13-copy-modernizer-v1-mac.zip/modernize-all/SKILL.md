---
name: modernize-all
description: Combined copy modernizer applying the strongest rules from contrast (surgical replacements), current (modern best practices), and hormozi (voice patterns). Priority-ordered to resolve conflicts between approaches.
license: Private
triggers:
  - /modernize-all
  - modernize everything
  - full modernization pass
  - modernize all dimensions
metadata:
  version: 1.0.0
  author: Rich Schefren
  category: copywriting
  updated: 2026-02-01
---

# Copy Modernizer: Full Stack

Runs the combined wisdom of all three modernization approaches -- contrast (surgical pattern replacement), current (modern best practices), and hormozi (voice-specific patterns). Not a simple concatenation: a priority-ordered synthesis that resolves conflicts and applies the strongest rules from each.

## When to Use

- When you want the most thorough modernization pass possible
- When copy needs work across multiple dimensions simultaneously
- When you're not sure which specific modernizer to use
- As a final pass before publishing any direct response copy
- After arena output when maximum modernization is needed

## What It Does

1. Accepts copy input (pasted text or file path)
2. Runs three sequential passes with priority ordering
3. Resolves conflicts between approaches
4. Outputs modernized version + comprehensive change log

## Priority Order (When Rules Conflict)

1. **Contrast rules first** (most specific/surgical) -- Pattern-level replacements from `~/.claude/skills/modernize-contrast/references/replacement-rules.md`
2. **Current patterns second** (modern best practices) -- Dimension-level analysis from `~/.claude/skills/modernize-current/references/modern-patterns.md`
3. **Hormozi voice third** (stylistic layer, optional) -- Voice-level transformation from `~/.claude/skills/modernize-hormozi/references/voice-patterns.md`

**Conflict resolution:**
- If contrast and current disagree, current wins (broader pattern > specific rule)
- If current and hormozi disagree, current wins (general modern > single voice)
- Hormozi voice is applied as an optional layer -- it never overrides the other two
- All three agree that strategic architecture (proof points, belief shifts, offer structure) is preserved

## Process

### Pass 1: Surgical Replacement (Contrast)

Scan the copy against the replacement rules in `~/.claude/skills/modernize-contrast/references/replacement-rules.md`. Apply direct pattern replacements:

- H1-H8: Headlines
- L1-L8: Leads
- B1-B14: Body copy filler
- U1-U8: Urgency
- C1-C8: CTAs
- P1-P7: Proof
- F1-F6: Formatting
- BL1-BL7: Bullets
- R1-R6: Rhetorical patterns
- T1-T8: Tone patterns
- E1-E5: Email patterns
- GU1-GU4: Guarantee language
- V1-V4: VSL patterns
- S1-S4: Story/narrative
- O1-O5: Objection handling
- OP1-OP4: Offer presentation

Log every replacement with rule ID.

### Pass 2: Dimension Analysis (Current)

Analyze the copy (post-Pass 1) against the 7 shift dimensions from `~/.claude/skills/modernize-current/references/modern-patterns.md`:

1. Urgency -- Is all urgency authentic?
2. Proof -- Is proof showing process, not just outcomes?
3. CTAs -- Are CTAs outcome-focused instructions?
4. Headlines -- Are headlines specific + benefit-forward?
5. Objection Handling -- Is handling empathetic, not confrontational?
6. Rhythm -- Is there breathing room and strategic white space?
7. Tone -- Does it sound like a knowledgeable advisor, not an aggressive seller?

For any dimension scoring below 3/5, apply the corresponding modern patterns. Log each change with dimension reference.

Then verify against the 12 Modern Copy Principles (P1-P12).

### Pass 3: Voice Polish (Hormozi -- Optional)

Apply Hormozi voice patterns from `~/.claude/skills/modernize-hormozi/references/voice-patterns.md`:

- Third-grade vocabulary replacement
- Cadence adjustment (short/long alternation)
- Formal transition elimination
- Adverb elimination
- Active voice conversion

**Important:** This pass is optional. If the copy's target audience or brand doesn't align with Hormozi's voice, skip this pass. Note in the output that Pass 3 was skipped and why.

### Pass 4: Final Verification

Run the modernized copy through the 12 Principles Check:

1. Sounds like a person talking, not a copywriter writing
2. Every sentence earns its place
3. Specificity as credibility
4. Admits what's hard, limited, or failed
5. One idea per paragraph, max 3 lines on mobile
6. Bold for emphasis, not CAPS
7. Real urgency only
8. CTA = instructions, not commands
9. Proof through process, not just outcomes
10. Anti-hype as trust signal
11. One story, one point, under 200 words per story
12. Designed for two reading speeds

Flag any principle that still fails after all three passes.

## Output

**Section A: Modernized Copy**
Full rewritten version, ready to use.

**Section B: Change Log (by Pass)**

### Pass 1: Contrast Replacements
| Line | Original | Replacement | Rule ID |
|------|----------|-------------|---------|

### Pass 2: Current Pattern Updates
| Line | Original | Updated | Dimension | Principle |
|------|----------|---------|-----------|-----------|

### Pass 3: Hormozi Voice (if applied)
| Line | Original | Hormozi Version | Rule # |
|------|----------|----------------|--------|

**Section C: Scores**

| Dimension | Before | After |
|-----------|--------|-------|
| D1: Urgency | X/5 | X/5 |
| D2: Proof | X/5 | X/5 |
| D3: CTAs | X/5 | X/5 |
| D4: Headlines | X/5 | X/5 |
| D5: Objections | X/5 | X/5 |
| D6: Rhythm | X/5 | X/5 |
| D7: Tone | X/5 | X/5 |

| 12 Principles | Before (pass/fail) | After (pass/fail) |
|---------------|--------------------|--------------------|
| P1-P12 | ... | ... |

**Section D: Remaining Issues**
Any principles or dimensions that still need work after all passes, with specific recommendations.

## Reference Files

**Local references (read these first):**
- `~/.claude/skills/modernize-all/references/merged-rules.md` -- Priority-ordered master ruleset (122 rules across 3 tiers)
- `~/.claude/skills/modernize-all/references/cross-reference-matrix.md` -- Maps every rule across all three skill layers

**Source skill references (for deep detail when needed):**
- `~/.claude/skills/modernize-contrast/references/replacement-rules.md` (86 rules, 16 categories)
- `~/.claude/skills/modernize-contrast/references/arena-analysis.md`
- `~/.claude/skills/modernize-current/references/modern-patterns.md` (12 principles, 7 dimensions)
- `~/.claude/skills/modernize-current/references/dated-patterns.md` (85 patterns with IDs)
- `~/.claude/skills/modernize-current/references/before-after-examples.md` (16 examples)
- `~/.claude/skills/modernize-hormozi/references/voice-patterns.md` (16 rules, 52 vocab, 22 transitions)
