---
name: revenue-reporting-builder
description: Aggregates performance numbers from Go HighLevel, Everflow, Stripe, and Thrivecart into a unified daily or weekly revenue report for Flexxable and Flexx Digital. Eliminates the 5-6 hours per week Graham spends manually pulling and formatting numbers. Use when Graham pastes numbers from any of these platforms, when he wants a formatted daily dashboard, or when he says "compile the numbers," "build the daily report," "what does the funnel look like today," or "run the weekly summary."
license: proprietary
metadata:
tags:
  - program/ctd
---
# Revenue Reporting Builder

## Purpose

Transforms manually pulled numbers from GHL, Everflow, Stripe, and Thrivecart into a single formatted daily or weekly performance report â replacing fragmented dashboards with one clean output.

**Keywords:** reporting, GHL, Go HighLevel, Everflow, Stripe, Thrivecart, revenue, daily dashboard, weekly summary, book funnel, ROYA, client reporting, ad tracking, Facebook Ads, funnel performance, Database Reactivation, Flexxable, Flexx Digital

---

## Instructions

### Quick Start

1. Paste today's numbers in any format â raw exports, screenshots described, or just the figures
2. Tag which system each set of numbers came from
3. Claude formats into the standard report, flags anomalies, and calculates trends
4. Copy into Slack, send to Dan, or save to vault

### Minimum Requirements Before Starting

To produce a complete daily report, the following are required at minimum:
- Facebook Ads spend for the period
- Book funnel stats (opt-ins, conversion rate, upsell/downsell revenue) from Everflow or GHL
- Stripe or Thrivecart revenue total for the period
- Any Flexx Digital client performance numbers if available

**If any data is missing:** build the report with what's available and flag the missing sections clearly â do not wait for complete data before starting.

---

### Step 1 â Ingest and Normalize

Parse raw numbers regardless of format:

- **From GHL:** Contact counts, pipeline stage counts, conversion rates
- **From Everflow:** Click counts, conversion events, offer-level revenue, affiliate performance
- **From Stripe/Thrivecart:** Gross revenue, new charges, refunds, failed payments count
- **From Facebook Ads Manager:** Spend, CPL, CPC, frequency, ROAS if available

**Normalize all currency to GBP (Â£) unless Graham specifies otherwise.** If USD amounts are provided, flag the exchange rate used.

### Step 2 â Build the Daily Dashboard

Produce the report in this exact format:

---

**FLEXXABLE DAILY DASHBOARD**
**Date:** [Date]
**Compiled:** [Time]

---

**BOOK FUNNEL**

| Metric | Today | Yesterday | 7-Day Avg | Target |
|--------|-------|-----------|-----------|--------|
| Ad Spend | Â£[X] | Â£[X] | Â£[X] | Â£[X] |
| Opt-ins | [X] | [X] | [X] | [X] |
| CPL | Â£[X] | Â£[X] | Â£[X] | Â£[X] |
| Upsell Revenue | Â£[X] | Â£[X] | Â£[X] | â |
| Downsell Revenue | Â£[X] | Â£[X] | Â£[X] | â |
| ROAS | [X]x | [X]x | [X]x | [X]x |

**ROYA PIPELINE**

| Stage | Count Today | Movement |
|-------|-------------|---------|
| New Leads | [X] | +[X] / -[X] |
| Calls Booked | [X] | +[X] / -[X] |
| Calls Completed | [X] | +[X] / -[X] |
| Enrolled | [X] | +[X] / -[X] |

**REVENUE SUMMARY**

| Source | Today | MTD | MoM Trend |
|--------|-------|-----|-----------|
| Book Funnel | Â£[X] | Â£[X] | [Up/Down X%] |
| Upsells | Â£[X] | Â£[X] | [Up/Down X%] |
| ROYA | Â£[X] | Â£[X] | [Up/Down X%] |
| **Total** | **Â£[X]** | **Â£[X]** | |

**FLEXX DIGITAL â CLIENT ACCOUNTS**

| Client | Leads Reactivated | Calls Booked | Revenue Delivered | Status |
|--------|------------------|--------------|-------------------|--------|
| [Client Name] | [X] | [X] | Â£[X] | Green / Amber / Red |

**ADMIN QUEUE**
- Failed payments today: [X] â Action: [sent recovery sequence / pending]
- Helpscout tickets open: [X] â Priority: [any urgent flags]
- Refunds processed today: [X] â Total: Â£[X]

**FLAGS AND ANOMALIES**
[Populate only when something is outside normal range or requires attention]
- [Flag 1 â specific, actionable]

---

### Step 3 â Calculate and Call Out Trends

After the dashboard, provide 3-5 sentences of analytical commentary covering:
- Lead cost movement vs. 7-day average (improving / worsening / stable)
- Whether MTD revenue is on track (at/ahead/behind required pace)
- The single metric that stands out as the one to watch
- Any pattern across the last three data points if historical data is available

**Keep commentary to what action the numbers suggest. Do not explain what the numbers mean â Graham already knows.**

### Step 4 â Weekly Summary Mode

When Graham requests a weekly summary:

**FLEXXABLE WEEKLY SUMMARY**
**Week of:** [Monday Date] â [Sunday Date]

| Metric | This Week | Last Week | % Change |
|--------|-----------|-----------|---------|
| Total Ad Spend | Â£[X] | Â£[X] | [X%] |
| Total Opt-ins | [X] | [X] | [X%] |
| Average CPL | Â£[X] | Â£[X] | [X%] |
| Total Revenue | Â£[X] | Â£[X] | [X%] |
| New ROYA Enrollments | [X] | [X] | [X%] |
| Failed Payments Recovered | Â£[X] | Â£[X] | [X%] |
| Support Tickets Resolved | [X] | [X] | â |

**Week narrative:** [2-3 sentences: what happened this week, what to watch next week]

**Decision points for Dan:** [Any number Dan Wardrope needs to see and act on]

---

### Anomaly Detection Rules

Flag automatically when:
- CPL increases more than 20% day-over-day (potential creative fatigue or audience saturation)
- ROAS drops below 1.0x for the book funnel (spending more on ads than recovering in immediate funnel revenue)
- Failed payments exceed 3 in a single day (possible billing platform issue or card update problem)
- ROYA pipeline calls booked drops to zero for two consecutive days (likely scheduling or Calendly issue)
- Any Flexx Digital client shows zero new leads for 72 hours (potential AI agent or integration failure)

**Flag format:**
> FLAG: [Metric] is [X%] outside normal range. [One sentence on the most likely cause.] Action suggested: [Specific next step â check X, contact Y, pull Z report.]

### Flexx Digital Client Reporting Mode

When Graham needs client-facing Flexx Digital reports, produce:

---

**FLEXX DIGITAL â DATABASE REACTIVATION REPORT**
**Client:** [Name]
**Period:** [Date range]
**Prepared by:** Graham Connolly, Flexx Digital

**RESULTS THIS PERIOD**

| Metric | This Period | Since Launch | Notes |
|--------|-------------|--------------|-------|
| Leads Contacted | [X] | [X] | |
| Replies Received | [X] | [X] | Reply rate: [X%] |
| Calls Booked | [X] | [X] | Book rate: [X%] |
| Calls Completed | [X] | [X] | Show rate: [X%] |
| Revenue Generated | Â£[X] | Â£[X] | Confirmed + pipeline |

**WHAT HAPPENED THIS PERIOD:**
[2-3 sentences on what the agent did, sequences deployed, optimizations made]

**NEXT 30 DAYS:**
[What's planned â next sequence, new segment to reactivate, any changes to the AI agent]

---

**Client report rule:** Show results first, process second. Never write a client report that spends more words on process than on numbers.

---

## Operating Rules

- **Never invent numbers.** If a data point is missing, show a dash and label it "not provided."
- **ROAS calculation rule:** For the book funnel, ROAS includes only direct funnel revenue (upsells/downsells). Do not include ROYA revenue in book funnel ROAS â that is a separate calculation with a longer attribution window.
- **If Graham provides numbers from memory:** flag them as "Graham estimate â verify against platform" before including in the report.
- **If all data sources are missing:** do not produce a blank report. Prompt: "No data provided for today. Paste numbers from any available source and I'll build what I can and flag what's missing."
- **Dashboard save location:** `04 Ad Tracking/daily-dashboard-[date].md` in Graham's vault unless he specifies otherwise.

---

## Reference

**Target configuration:** Graham stores CPL targets and monthly revenue targets at `04 Ad Tracking/report-targets.md`. Update the TARGET column in the dashboard format once baseline targets are established.

**Dependencies:** None. Works from numbers Graham pastes in any format. No API connections required â Graham pulls manually and pastes.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Invent missing numbers | Show a dash and label "not provided" |
| Include ROYA revenue in book funnel ROAS | Separate calculation â longer attribution window |
| Accept memory estimates without flagging | Flag as "Graham estimate â verify against platform" |
| Produce a blank report when data is missing | Prompt for any available source first |
| Write client reports that focus on process over numbers | Results first, process second |

## Before You Respond

- [ ] Do I have GHL, Everflow, Stripe, and Thrivecart numbers (or noted missing)?
- [ ] Am I using GBP (Â£) currency?
- [ ] Have I separated ROYA from book funnel ROAS?
- [ ] Are all memory estimates flagged for verification?
- [ ] Does the client report lead with results?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
