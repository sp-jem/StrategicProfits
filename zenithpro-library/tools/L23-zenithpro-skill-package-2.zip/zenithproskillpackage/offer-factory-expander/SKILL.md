# Offer Factory: Concept Expander

---
name: offer-factory-expander
description: "Use when a concept has been selected from the Deepener and needs full business-context development before the Architect builds the blueprint."
---

## Purpose

The Engine generates divergent volume (150+ concepts). The Deepener scores and filters. But between "this concept scored well" and "here's the blueprint" sits a critical gap: **nobody has pulled the full business context toward the selected concept to understand what it actually means operationally.**

The Expander does convergent synthesis. It takes ONE concept and asks: Given everything happening in the business right now â the priorities, the team, the existing products, the pipeline, the blockers â what does this concept ACTUALLY look like when it hits reality? Not 5 competing versions. One definitive model with all the context baked in.

**Pipeline position:** Stage 6 of 8
```
Decomposer â Synthesizer â Autopsy â Engine â Deepener â EXPANDER â Architect â Ecosystem
```

**Upstream:** Deepener or Engine output (concept with scores, pattern, mechanism)
**Downstream:** Architect (takes the expanded model and produces the build-ready blueprint)

---

## Invocation

```
/offer-factory-expander [concept identifier] [Engine run file]
```

**Arguments:**
- `concept identifier` (required) â concept name, ID (e.g., "CP2", "XP-2"), or title from Deepener/Engine output
- `Engine run file` (optional) â path to full Engine run for cross-referencing in Step 5

**Examples:**
```
/offer-factory-expander "Gillette Razor Model" "Offer Factory/Engine Runs/Connect the Dots - Full Run (Context) - 2026-03-12.md"
/offer-factory-expander CP2 from ZenithPro Engine run
/offer-factory-expander "D3 Franchise"
/offer-factory-expander "SOW Season Pass" (no Engine file â Step 5 will be skipped)
```

---

## Input Requirements

**Required:**
- One concept to expand (name, ID, or pasted description)
- The concept must be findable in Deepener output, Engine run, or provided directly

**Optional but valuable:**
- Engine run file (enables Step 5: Cross-Concept Mapping)
- Deepener output (provides scores, feasibility data, variations)

---

## The 8-Step Execution Process

### CRITICAL: No VS-CoT

This skill does NOT use Verbalized Sampling. The Engine uses VS-CoT because it needs divergent generation (many candidates, probability-tagged). The Expander does convergent synthesis â one definitive model pulled from real business context. Generate one answer per question, make it the best answer, move on.

---

### Step 1: Concept Deep Read

**Goal:** Extract the full concept profile so you know exactly what you're expanding.

**Search order:**
1. Check Deepener output files in `Offer Factory/Developed Concepts/` for a match
2. Check Engine run files in `Offer Factory/Engine Runs/` for a match
3. If concept identifier is an ID (e.g., "CP2"), search Engine run for that ID
4. If concept was pasted directly, use what was provided

**Extract:**
- Concept name and one-line description
- Origin (which Engine mode, which run)
- Probability score (p=X.XX) if available
- Novelty/Fit/Revenue scores (N/F/R) if available
- Structural pattern(s) at work (from the 30 patterns)
- The mechanism â what specifically makes this concept work
- Target product/program it applies to
- Deepener assessment (if it went through Deepener)

**If concept is not found:** Search by name fragments across all files in `Offer Factory/`. Report the 3 closest matches and ask which one to expand. This is the ONE case where you stop and ask â if the concept itself can't be identified.

**Output:** Concept Profile section in the document.

---

### Step 2: Business Context Audit

**Goal:** Pull live context about the target product/program so the expansion is grounded in current reality, not hypothetical.

**Bounded search â max 8-12 files, fixed priority order:**

| Priority | Source | What to Look For | Max Files |
|----------|--------|-------------------|-----------|
| 1 | `priorities.md` in project root or Core Context | Current priorities, blockers, active initiatives for this product | 1 |
| 2 | Product registry (`~/.claude/skills/product-registry/`) | Product structure, pricing, positioning, current state | 1-2 |
| 3 | Offer Factory artifacts for this product (autopsies, component inventories) | Structural gaps, existing components, what's been tried | 3-4 |
| 4 | Program development folder (`Strategic-Profits/00 Program Development/[product]/`) | Active development work, team assignments, timelines | 1-2 |
| 5 | Core Context (`000 Core Context/`) | Team capabilities, business model, revenue streams | 1-2 |

**Rules:**
- Do NOT crawl the vault looking for more context. 8-12 files is the cap.
- If a source doesn't exist (e.g., no product registry entry), skip it and note it was skipped.
- Extract what's relevant to THIS concept. Don't summarize entire documents.
- Convert any relative dates to absolute dates (e.g., "next month" â "April 2026").

**Output:** Business Context section â current state, active priorities, team, blockers, and assets relevant to this concept.

---

### Step 3: Problem-Concept Fit

**Goal:** Diagnose the SPECIFIC problem this concept solves right now. Not "this is a good idea" â but "this is the right idea for THIS moment because [specific problem]."

**Process:**
1. From Step 2, identify the top 1-3 problems/blockers/gaps in the target product/program
2. From Step 1, identify the mechanism by which this concept addresses those problems
3. Write the fit diagnosis: "The problem is [X]. This concept solves it by [Y]. The fit is [tight/moderate/loose] because [Z]."

**If the concept is REJECTED by the Deepener:** Note the Deepener's assessment, then proceed anyway. The Expander's job is to give Rich a full picture, not to filter. Flag the rejection prominently but don't let it stop the expansion.

**Output:** Problem Diagnosis section â the specific problem, why this concept is the right structural response, and fit assessment.

---

### Step 4: Pattern Application

**Goal:** Map the abstract pattern to a concrete operational model. This is the core synthesis step â where "Gillette Razor Model" becomes "monthly Capability Packs with 5 defined components."

**Process:**
1. Name the structural pattern from Step 1 (e.g., "Platform + Consumable")
2. Create the analogy table: Pattern Element â Business Application

| Pattern Element | Applied To |
|----------------|-----------|
| [Abstract component] | [Concrete implementation] |

3. Define the operational model:
   - **Components:** What are the 3-7 concrete components of this model?
   - **Calendar:** What's the production/delivery cadence?
   - **Owners:** Who does what? (Use real team names â Rich, Nicole, Jessica, Ben, Irish, Harry, etc.)
   - **Dependencies:** What must exist before this works?
   - **The mechanism in action:** Walk through one cycle of the model operating

4. If the concept is TACTICAL (not structural) â e.g., a pricing tweak, a guarantee structure, a conversion tool â skip the analogy table and focus on the operational delta: what changes, what stays the same, what's the before/after.

**Output:** Pattern Application section with analogy table (if structural), full operational model, production calendar, and ownership assignments.

---

### Step 5: Cross-Concept Mapping

**Goal:** Scan the full Engine catalog and find all concepts that fit within or enhance the expanded model. This is where a single concept becomes an ecosystem.

**Requires:** Engine run file (if not provided, skip this step entirely and note it was skipped)

**Process:**
1. Read the Engine run file
2. For each concept in the run, ask: "Does this concept feed into, enhance, extend, or become a component of the expanded model?"
3. Organize matching concepts into categories:
   - **Content Factories** â concepts that generate raw material for the model
   - **Model Components** â concepts that become new features within the model
   - **Business Model Enhancements** â concepts that make the model stickier/more profitable
   - **Theme Expanders** â concepts that suggest specific instances/variations of the model
   - **Ecosystem Connectors** â concepts that link this model to other products

4. For each matching concept, include: ID, name, scores, and 2-3 sentences on how it fits

**Output:** Cross-Concept Catalog section organized by category, with fit explanations.

---

### Step 6: Impact Quantification

**Goal:** Revenue scenarios, lock-in mechanisms, ecosystem effects, and competitive moat.

**Process:**

**Revenue scenarios (3 tiers):**

| Scenario | Assumptions | Monthly | Annual |
|----------|-------------|---------|--------|
| Conservative | [Low member count, low price] | $X | $X |
| Base | [Moderate assumptions] | $X | $X |
| Optimistic | [High member count, upsells] | $X | $X |

Use real pricing from Step 2 (product registry, existing offers). Don't invent prices â use what exists or what the concept specifies.

**Lock-in mechanisms:** What makes this hard to leave? List each mechanism and rate its strength (structural / economic / psychological / social).

**Ecosystem effects:** How does this concept change the value of OTHER products in the portfolio? (e.g., "CTD becomes the razor installer, increasing E3 subscription conversion by X%")

**Competitive moat:** What would a competitor need to replicate this? How long would it take them?

**Output:** Impact Quantification section with revenue table, lock-in analysis, ecosystem effects, and moat assessment.

---

### Step 7: Decision Points

**Goal:** Identify 3-6 specific decisions Rich must make before this moves to the Architect, with options and suggested defaults.

**Format for each decision:**

#### Decision [N]: [Title]

**The question:** [Specific question Rich needs to answer]

**Options:**
- **Option A:** [Description] â [Pro] / [Con]
- **Option B:** [Description] â [Pro] / [Con]
- **Option C:** [Description] (if applicable)

**Suggested default:** [Which option and why]

**Rules:**
- Decisions must be SPECIFIC. Not "what's the strategy?" but "Single tier at $97 or three tiers at $97/$147/$297?"
- Include a suggested default for every decision. Rich can override, but he shouldn't have to start from zero.
- If a decision depends on another decision, note the dependency.
- Don't manufacture decisions. If something is obvious from the context, just state it as a given.

**Output:** Decision Points section with 3-6 formatted decisions.

---

### Step 8: Implementation Path

**Goal:** 30-day timeline with real dates, real owners, real deliverables, and checkboxes.

**Format:**

**Week 1: [Date range]**
- [ ] [Deliverable] â [Owner] â [What specifically gets produced]
- [ ] [Deliverable] â [Owner]

**Week 2: [Date range]**
- [ ] ...

**Week 3: [Date range]**
- [ ] ...

**Week 4: [Date range]**
- [ ] ...

**Rules:**
- Use actual calendar dates (calculate from today's date)
- Use real team member names from Step 2
- Every checkbox must have a concrete deliverable, not an activity ("Pack assembled and QA'd" not "Work on the pack")
- If something depends on a Decision Point from Step 7, note it: "[Depends on Decision 2]"
- Include a "suggested priorities.md update" block at the end that Rich can copy-paste â but do NOT automatically update priorities.md

**Output:** Implementation Path section with dated, owned, checkboxed timeline + suggested priorities.md update block.

---

## Output Format

**Location:** `Offer Factory/Developed Concepts/[Concept Name] - Expanded - [Date].md`

**Structure:**

```markdown
# [Concept Name]: [Pattern/Model Description]

**Date:** [YYYY-MM-DD]
**Origin:** [Engine Run ID / scores]
**Pattern:** [Structural pattern]
**Purpose:** [One sentence â what this expansion proves/proposes]

---

## The Problem This Solves

[Step 3 output â specific problem diagnosis, not generic value prop]

---

## [Pattern Name] Applied to [Product]

### The Core Insight
[The pattern explained in 2-3 sentences]

### Applied:
[Analogy table from Step 4]

### Why This Works for [Product] Specifically
[3-4 numbered reasons grounded in business context from Step 2]

---

## [Operational Model Name] Structure

[Step 4 output â components, calendar, ownership, one-cycle walkthrough]

---

## The Production Calendar

[Monthly and/or weekly cycle tables from Step 4]

---

## How This Transforms [Product]'s Economics

[Step 6 output â revenue scenarios, retention mechanics, lock-in]

---

## [Relevant Integration Section â e.g., "How SOW Distinctions Flow to E3"]

[If the concept involves cross-product integration, detail the specific mechanism]

---

## What Rich Needs to Decide

[Step 7 output â formatted decisions with options and defaults]

---

## Implementation: First 30 Days

[Step 8 output â dated, owned, checkboxed timeline]

---

## Engine Run Cross-Reference: [N] Concepts That Fit

[Step 5 output â categorized catalog of related concepts, or "Skipped â no Engine run file provided"]

---

## Summary

[2-3 paragraph synthesis: what this concept means for the business, why now, what happens if Rich says yes]
```

**Notes on the template:**
- Section headers adapt to the specific concept. The Gillette doc has "How SOW Distinctions Flow to E3" â another concept might have "How This Changes the CTD Funnel" or might not need an integration section at all.
- The cross-reference section goes near the end because it's supplementary. The core argument is in the first half.
- The summary is last, not first. Rich reads top-down and wants the problem + solution before the summary.

---

## Edge Cases

| Situation | Handling |
|-----------|----------|
| Concept not found | Search by name fragments across all Offer Factory files. Report 3 closest matches. Ask which one. (Only case that stops execution.) |
| No Engine run file provided | Skip Step 5. Note "Cross-Concept Mapping skipped â no Engine run file provided. Re-run with Engine file to add this section." |
| No product registry entry | Proceed with Offer Factory artifacts (autopsies, component inventories). Note the gap. |
| Concept was REJECTED by Deepener | Proceed anyway. Flag the rejection prominently in Step 1 and Step 3. Let Rich decide. |
| Tactical concept (not structural) | Skip analogy table in Step 4. Focus on operational delta (before/after). Revenue section focuses on conversion lift, not standalone revenue. |
| Multiple products involved | Step 2 pulls context for ALL involved products (still within 8-12 file cap). Step 4 maps the model across products. |
| Concept already has a Blueprint | Note that a Blueprint exists. The Expander adds business context and cross-concept mapping that the Architect doesn't produce. Both documents are valuable. |

---

## What This Skill Does NOT Do

- **Does not score or rank.** That's the Deepener's job.
- **Does not generate alternatives.** That's the Engine's job. The Expander takes ONE concept and goes deep.
- **Does not produce a build-ready blueprint.** That's the Architect's job. The Expander produces the strategic case and operational model; the Architect produces the component list, tech spec, and fulfillment plan.
- **Does not update priorities.md.** It produces a suggested update block. Rich copy-pastes if he approves.
- **Does not use VS-CoT.** Convergent synthesis, not divergent generation.

---

## Integration Notes

**Typical flow:**
1. Engine generates 150+ concepts with VS-CoT diversity
2. Deepener scores top 10-20, produces ranked backlog
3. Rich selects 1-3 concepts from the backlog
4. **Expander** takes each selected concept and produces the full context-aware expansion
5. Rich reviews expansion, makes decisions at Decision Points
6. Architect takes the approved expansion and produces the build-ready blueprint
7. Ecosystem Designer checks how the new offer fits the portfolio

**The Expander's unique value:** It's the only stage that reads the BUSINESS (priorities, team, blockers, active work) and connects it to the CONCEPT. The Engine doesn't know about today's priorities. The Deepener doesn't know about team capacity. The Architect doesn't diagnose problems. The Expander is the convergence point where concept meets context.
