/**
 * Obsidian Vault Detector
 * Scans common locations for .obsidian folders and reports found vaults.
 */

const fs = require('fs');
const path = require('path');
const os = require('os');

const HOME = os.homedir();

// Common locations where Obsidian vaults live
const SEARCH_PATHS = [
  path.join(HOME, 'Documents'),
  path.join(HOME, 'Documents', 'Obsidian'),
  path.join(HOME, 'Desktop'),
  path.join(HOME, 'HQ'),
  path.join(HOME, 'Obsidian'),
  path.join(HOME, 'Notes'),
  path.join(HOME, 'Vaults'),
  HOME
];

function findVaults(dir, depth = 0, maxDepth = 3) {
  const vaults = [];
  if (depth > maxDepth) return vaults;

  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });

    // Check if this directory IS a vault
    const hasObsidian = entries.some(e => e.isDirectory() && e.name === '.obsidian');
    if (hasObsidian) {
      vaults.push(dir);
      return vaults; // Don't recurse into vaults (nested vaults are rare)
    }

    // Recurse into subdirectories
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      if (entry.name.startsWith('.') || entry.name === 'node_modules' || entry.name === '.Trash') continue;

      const subPath = path.join(dir, entry.name);
      vaults.push(...findVaults(subPath, depth + 1, maxDepth));
    }
  } catch (e) {
    // Permission denied or other FS error — skip
  }

  return vaults;
}

// Also check Obsidian's own config for known vaults
function getObsidianConfigVaults() {
  const vaults = [];
  const configPath = path.join(HOME, 'Library', 'Application Support', 'obsidian', 'obsidian.json');

  try {
    if (fs.existsSync(configPath)) {
      const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      if (config.vaults) {
        for (const [id, vault] of Object.entries(config.vaults)) {
          if (vault.path && fs.existsSync(vault.path)) {
            vaults.push(vault.path);
          }
        }
      }
    }
  } catch (e) {
    // Config not readable
  }

  return vaults;
}

// Run detection
console.log('Scanning for Obsidian vaults...\n');

const found = new Set();

// Method 1: Obsidian's own config (most reliable)
const configVaults = getObsidianConfigVaults();
configVaults.forEach(v => found.add(v));

// Method 2: Filesystem scan
for (const searchPath of SEARCH_PATHS) {
  if (fs.existsSync(searchPath)) {
    const vaults = findVaults(searchPath);
    vaults.forEach(v => found.add(v));
  }
}

const results = Array.from(found).sort();

if (results.length === 0) {
  console.log('No Obsidian vaults found.');
  console.log('You can manually provide your vault path.');
} else {
  console.log(`Found ${results.length} vault(s):\n`);
  results.forEach((v, i) => {
    console.log(`  ${i + 1}. ${v}`);
  });
}

// Output as JSON for script consumption
console.log('\n---JSON---');
console.log(JSON.stringify({ vaults: results }));
