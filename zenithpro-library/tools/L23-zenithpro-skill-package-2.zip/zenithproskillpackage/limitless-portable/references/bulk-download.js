/**
 * Limitless AI Portable Bulk Downloader
 *
 * Self-configuring — reads config.json for API key and output path.
 * No hardcoded paths, team names, or vault-specific settings.
 */

const fs = require('fs');
const path = require('path');
const https = require('https');
const os = require('os');

// Load config
const CONFIG_PATH = path.join(__dirname, 'config.json');

if (!fs.existsSync(CONFIG_PATH)) {
  console.error('\nNo config.json found. Run setup first.');
  console.error('Ask Claude to "set up limitless" or "download my limitless recordings".\n');
  process.exit(1);
}

const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));

if (!config.apiKey || !config.vaultPath || !config.outputFolder) {
  console.error('\nConfig is incomplete. Delete config.json and re-run setup.\n');
  process.exit(1);
}

// Resolve output directory
const OUTPUT_DIR = path.join(config.vaultPath, config.outputFolder);
const API_KEY = config.apiKey;
const API_BASE = 'api.limitless.ai';
const TIMEZONE = config.timezone || 'America/New_York';

// Convert a Date or ISO string to YYYY-MM-DD in local time
function toLocalDate(input) {
  const d = input instanceof Date ? input : new Date(input);
  return d.toLocaleDateString('en-CA', { timeZone: TIMEZONE });
}

// Convert a Date or ISO string to YYYY-MM-DD HH:MM:SS in local time
function toLocalDateTime(input) {
  const d = input instanceof Date ? input : new Date(input);
  const date = d.toLocaleDateString('en-CA', { timeZone: TIMEZONE });
  const time = d.toLocaleTimeString('en-GB', { timeZone: TIMEZONE, hour12: false });
  return `${date} ${time}`;
}

// Date range — overridable via env vars
const FROM_DATE = process.env.MEETING_FROM_DATE || '2024-01-01';
const TO_DATE = process.env.MEETING_TO_DATE || toLocalDate(new Date());

// Recording type detection patterns
const RECORDING_TYPES = [
  { pattern: /meeting|call|session/i, type: 'Meeting' },
  { pattern: /discussion|conversation/i, type: 'Discussion' },
  { pattern: /interview/i, type: 'Interview' },
  { pattern: /brainstorm/i, type: 'Brainstorm' },
  { pattern: /planning/i, type: 'Planning Session' },
  { pattern: /strategy/i, type: 'Strategy Session' },
  { pattern: /review/i, type: 'Review' },
  { pattern: /training|workshop/i, type: 'Training' },
  { pattern: /presentation|webinar/i, type: 'Presentation' },
  { pattern: /standup|stand-up/i, type: 'Standup' }
];

function makeRequest(endpoint, params = {}) {
  return new Promise((resolve, reject) => {
    const queryString = new URLSearchParams(params).toString();
    const pathWithQuery = queryString ? `${endpoint}?${queryString}` : endpoint;

    const options = {
      hostname: API_BASE,
      path: pathWithQuery,
      method: 'GET',
      headers: {
        'X-API-Key': API_KEY,
        'Accept': 'application/json'
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          if (res.statusCode === 429) {
            reject(new Error('Rate limited - waiting...'));
            return;
          }
          if (res.statusCode === 401) {
            reject(new Error('Invalid API key. Delete config.json and re-run setup.'));
            return;
          }
          if (res.statusCode !== 200) {
            reject(new Error(`HTTP ${res.statusCode}: ${data.substring(0, 200)}`));
            return;
          }
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error(`Parse error: ${data.substring(0, 200)}`));
        }
      });
    });

    req.on('error', reject);
    req.end();
  });
}

function formatDuration(seconds) {
  if (!seconds) return 'Unknown';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  if (mins > 60) {
    const hours = Math.floor(mins / 60);
    const remainMins = mins % 60;
    return `${hours}h ${remainMins}m`;
  }
  return `${mins}m ${secs}s`;
}

function detectRecordingType(title, content) {
  const text = `${title || ''} ${content || ''}`.toLowerCase();
  for (const rt of RECORDING_TYPES) {
    if (rt.pattern.test(text)) return rt.type;
  }
  return 'Recording';
}

function extractTopicsFromContent(content) {
  const topics = new Set();
  if (!content) return [];

  const headingMatches = content.match(/^#{2,3}\s+(.+)$/gm);
  if (headingMatches) {
    headingMatches.forEach(h => {
      const topic = h.replace(/^#+\s*/, '').trim();
      if (topic.length > 3 && topic.length < 60 && !topic.toLowerCase().includes('transcript')) {
        topics.add(topic);
      }
    });
  }

  return Array.from(topics).slice(0, 6);
}

function extractSpeakers(lifelog) {
  const speakers = new Set();

  // From speakers array
  if (lifelog.speakers) {
    lifelog.speakers.forEach(s => {
      const name = s.name || s.speakerName || '';
      if (name && name.length > 1 && name !== 'Unknown') {
        speakers.add(name.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' '));
      }
    });
  }

  // From transcript
  if (lifelog.transcript && Array.isArray(lifelog.transcript)) {
    lifelog.transcript.forEach(line => {
      const speaker = line.speakerName || line.speaker_name || line.speaker || '';
      if (speaker && speaker.length > 1 && speaker !== 'Unknown') {
        speakers.add(speaker);
      }
    });
  }

  // From markdown content — look for **Name:** patterns
  const content = lifelog.markdown || '';
  const speakerMatches = content.match(/\*\*([^*]{2,30})\*\*:/g);
  if (speakerMatches) {
    speakerMatches.forEach(m => {
      const name = m.replace(/\*\*/g, '').replace(/:$/, '').trim();
      if (name.length > 1 && name.length < 30) {
        speakers.add(name);
      }
    });
  }

  return Array.from(speakers).slice(0, 10);
}

function buildYAMLFrontmatter(lifelog) {
  const startTime = lifelog.startTime || lifelog.start_time;
  const endTime = lifelog.endTime || lifelog.end_time;

  let dateStr = toLocalDate(new Date());
  if (startTime) {
    try { dateStr = toLocalDate(startTime); } catch (e) {}
  }

  const speakers = extractSpeakers(lifelog);
  const topics = extractTopicsFromContent(lifelog.markdown || lifelog.summary || '');
  const recordingType = detectRecordingType(lifelog.title, lifelog.markdown);

  let duration = null;
  if (startTime && endTime) {
    duration = (new Date(endTime) - new Date(startTime)) / 1000;
  }

  let yaml = '---\n';
  yaml += `date: ${dateStr}\n`;
  yaml += `source: Limitless AI\n`;
  yaml += `type: "${recordingType}"\n`;

  if (speakers.length > 0) {
    yaml += `speakers:\n`;
    speakers.forEach(s => { yaml += `  - "${s}"\n`; });
  }

  if (topics.length > 0) {
    yaml += `topics:\n`;
    topics.forEach(t => { yaml += `  - "${t.replace(/"/g, '\\"')}"\n`; });
  }

  if (duration) {
    yaml += `duration: ${formatDuration(duration)}\n`;
  }

  if (lifelog.id) {
    yaml += `id: "${lifelog.id}"\n`;
  }

  yaml += '---\n\n';
  return yaml;
}

function buildMarkdown(lifelog) {
  const l = lifelog;
  let md = buildYAMLFrontmatter(l);

  md += `# ${l.title || 'Untitled Lifelog'}\n\n`;

  const startTime = l.startTime || l.start_time;
  const endTime = l.endTime || l.end_time;

  let dateStr = 'Unknown';
  if (startTime) {
    try { dateStr = toLocalDateTime(startTime); } catch (e) {}
  }

  md += `> **Date:** ${dateStr}\n`;
  md += `> **Source:** Limitless AI\n`;

  if (startTime && endTime) {
    const duration = (new Date(endTime) - new Date(startTime)) / 1000;
    md += `> **Duration:** ${formatDuration(duration)}\n`;
  }

  if (l.id) {
    md += `> **ID:** ${l.id}\n`;
  }

  md += `\n---\n\n`;

  if (l.summary) {
    md += `## Summary\n\n${l.summary}\n\n`;
  }

  if (l.markdown) {
    md += `## Content\n\n${l.markdown}\n\n`;
  } else if (l.contents && Array.isArray(l.contents)) {
    md += `## Content\n\n`;
    l.contents.forEach(content => {
      if (content.type === 'heading1') {
        md += `# ${content.content || ''}\n\n`;
      } else if (content.type === 'heading2') {
        md += `## ${content.content || ''}\n\n`;
      } else if (content.type === 'heading3') {
        md += `### ${content.content || ''}\n\n`;
      } else if (content.type === 'blockquote') {
        md += `> ${content.content || ''}\n\n`;
      } else if (content.type === 'bullet') {
        md += `- ${content.content || ''}\n`;
      } else if (content.speakerName || content.speaker_name) {
        const speaker = content.speakerName || content.speaker_name || 'Speaker';
        const text = content.content || content.text || '';
        md += `**${speaker}:** ${text}\n\n`;
      } else if (content.content) {
        md += `${content.content}\n\n`;
      }
    });
  }

  if (l.actionItems && l.actionItems.length > 0) {
    md += `## Action Items\n\n`;
    l.actionItems.forEach(item => {
      md += `- [ ] ${item.text || item.content || item}\n`;
    });
    md += '\n';
  }

  if (l.transcript && Array.isArray(l.transcript)) {
    md += `## Transcript\n\n`;
    l.transcript.forEach(line => {
      const speaker = line.speakerName || line.speaker_name || line.speaker || '';
      const text = line.text || line.content || '';
      if (speaker) {
        md += `**${speaker}:** ${text}\n\n`;
      } else if (text) {
        md += `${text}\n\n`;
      }
    });
  }

  md += `---\n*Downloaded from Limitless AI: ${new Date().toISOString()}*\n`;
  return md;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

(async () => {
  console.log('\n========================================');
  console.log('  Limitless AI Portable Downloader');
  console.log('========================================\n');
  console.log(`  Vault: ${config.vaultPath}`);
  console.log(`  Output: ${config.outputFolder}`);
  console.log(`  Range: ${FROM_DATE} to ${TO_DATE}\n`);

  // Ensure output directory exists
  if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
    console.log(`  Created output folder: ${OUTPUT_DIR}\n`);
  }

  // Phase 1: Fetch lifelogs
  console.log(`Phase 1: Fetching lifelogs...\n`);

  const allLifelogs = [];
  let cursor = null;
  let pageNum = 1;

  while (true) {
    try {
      const params = {
        date: FROM_DATE,
        timezone: TIMEZONE,
        limit: 50,
        direction: 'asc',
        include_markdown: true,
        include_headings: true
      };

      if (cursor) params.cursor = cursor;

      const response = await makeRequest('/v1/lifelogs', params);

      if (response.data && response.data.lifelogs && response.data.lifelogs.length > 0) {
        const filtered = response.data.lifelogs.filter(l => {
          const startTime = l.startTime || l.start_time;
          if (!startTime) return true;
          const date = startTime.split('T')[0];
          return date >= FROM_DATE && date <= TO_DATE;
        });

        allLifelogs.push(...filtered);
        console.log(`  Page ${pageNum}: Found ${response.data.lifelogs.length} lifelogs, ${filtered.length} in range (total: ${allLifelogs.length})`);

        if (response.meta && response.meta.lifelogs && response.meta.lifelogs.nextCursor) {
          cursor = response.meta.lifelogs.nextCursor;
        } else {
          break;
        }
      } else {
        break;
      }

      pageNum++;
      await sleep(350);

      if (pageNum > 100) {
        console.log('  Reached page limit (100)');
        break;
      }
    } catch (e) {
      if (e.message.includes('Rate limited')) {
        console.log('  Rate limited, waiting 10 seconds...');
        await sleep(10000);
        continue;
      }
      console.error(`  Error on page ${pageNum}: ${e.message}`);
      break;
    }
  }

  // Also check each date in range for any missed
  console.log('\n  Checking each date in range...');
  const startDate = new Date(FROM_DATE);
  const endDate = new Date(TO_DATE);

  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
    const dateStr = d.toISOString().split('T')[0];

    try {
      const params = {
        date: dateStr,
        timezone: TIMEZONE,
        limit: 50,
        include_markdown: true,
        include_headings: true
      };

      const response = await makeRequest('/v1/lifelogs', params);

      if (response.data && response.data.lifelogs && response.data.lifelogs.length > 0) {
        const existingIds = new Set(allLifelogs.map(l => l.id));
        const newLogs = response.data.lifelogs.filter(l => !existingIds.has(l.id));

        if (newLogs.length > 0) {
          allLifelogs.push(...newLogs);
          console.log(`  ${dateStr}: Found ${newLogs.length} new lifelogs (total: ${allLifelogs.length})`);
        }
      }

      await sleep(350);
    } catch (e) {
      if (e.message.includes('Rate limited')) {
        console.log('  Rate limited, waiting 10 seconds...');
        await sleep(10000);
        d.setDate(d.getDate() - 1);
        continue;
      }
    }
  }

  console.log(`\nFound ${allLifelogs.length} total lifelogs\n`);

  if (allLifelogs.length === 0) {
    console.log('No lifelogs found. Check:');
    console.log('  - Is your API key correct?');
    console.log('  - Is your pendant connected and recording?');
    console.log('  - Are there recordings in this date range?');
    return;
  }

  // Show sample
  console.log('Sample lifelogs:');
  allLifelogs.slice(0, 10).forEach((l, i) => {
    const startTime = l.startTime || l.start_time;
    const date = startTime ? startTime.split('T')[0] : 'no date';
    console.log(`  ${i + 1}. ${(l.title || 'Untitled').substring(0, 50)} (${date})`);
  });
  console.log('');

  // Phase 2: Save
  console.log('Phase 2: Saving lifelogs...\n');

  let downloaded = 0, skipped = 0, errors = 0;

  for (let i = 0; i < allLifelogs.length; i++) {
    const l = allLifelogs[i];
    const progress = `[${i + 1}/${allLifelogs.length}]`;
    const title = l.title || 'Untitled';

    console.log(`${progress} ${title.substring(0, 55)}`);

    try {
      const startTime = l.startTime || l.start_time;
      let dateStr = toLocalDate(new Date());
      if (startTime) {
        try {
          const d = new Date(startTime);
          if (!isNaN(d.getTime())) dateStr = toLocalDate(d);
        } catch (e) {}
      }

      const safeTitle = title
        .replace(/[\/\\:*?"<>|]/g, '-')
        .replace(/\s+/g, ' ')
        .substring(0, 50)
        .trim();

      const filename = `${dateStr} ${safeTitle} (Limitless).md`;
      const filepath = path.join(OUTPUT_DIR, filename);

      if (fs.existsSync(filepath)) {
        console.log('   -> exists');
        skipped++;
        continue;
      }

      const md = buildMarkdown(l);
      fs.writeFileSync(filepath, md);
      console.log('   -> saved');
      downloaded++;
    } catch (e) {
      console.log(`   -> error: ${e.message.substring(0, 50)}`);
      errors++;
    }
  }

  console.log('\n========================================');
  console.log('  Complete!');
  console.log(`  Downloaded: ${downloaded}`);
  console.log(`  Skipped (exists): ${skipped}`);
  console.log(`  Errors: ${errors}`);
  console.log(`  Saved to: ${OUTPUT_DIR}`);
  console.log('========================================\n');
})();
