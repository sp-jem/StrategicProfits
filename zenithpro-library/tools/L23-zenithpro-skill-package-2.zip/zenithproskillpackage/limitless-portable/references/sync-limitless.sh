#!/bin/bash
# Limitless daily sync — checks last 2 days
# Run manually or set up as a cron/launchd job

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

export MEETING_FROM_DATE=$(date -v-1d +%Y-%m-%d)
export MEETING_TO_DATE=$(date +%Y-%m-%d)

node "$SCRIPT_DIR/bulk-download.js"
