---
name: limitless-portable
description: Portable Limitless AI Pendant downloader. First-run setup walks user through API key creation, auto-detects their Obsidian vault, and asks where to save recordings. No hardcoded paths. Works for anyone with a Limitless pendant and Node.js.
---

# Limitless Portable — Pendant Recording Downloader

Self-configuring Limitless AI downloader. Works out of the box for anyone with a pendant and Node.js.

## Trigger Phrases

- "download my limitless recordings"
- "set up limitless"
- "limitless download"
- "pull my pendant recordings"
- "sync limitless"

## First-Run Setup (Claude walks the user through this)

When invoked and no `config.json` exists in `references/`, walk the user through setup:

### Step 1: API Key

Tell the user:

**You need a Limitless API key. Here's how to get one:**

1. Open https://app.limitless.ai in your browser
2. Log in with the account connected to your pendant
3. Click your profile icon (top right)
4. Click **"Developer"** or **"API"**
5. Click **"Create API Key"**
6. Copy the key — it starts with `sk-`

Then ask: **"Paste your API key here."**

### Step 2: Vault Detection

Run the detection script to find Obsidian vaults:

```bash
node ~/.claude/skills/limitless-portable/references/detect-vault.js
```

This scans common locations for `.obsidian` folders. Present the results to the user and ask which vault to use. If no vaults found, ask for the path manually.

### Step 3: Output Folder

Ask: **"Where in your vault do you want pendant recordings saved? Give me a folder name (e.g., 'Meetings/Pendant Recordings' or 'Limitless')."**

### Step 4: Save Config

Write the config to `references/config.json`:

```json
{
  "apiKey": "sk-...",
  "vaultPath": "/Users/name/Documents/Obsidian/MyVault",
  "outputFolder": "Meetings/Pendant Recordings",
  "timezone": "America/New_York",
  "setupComplete": true
}
```

Confirm to user: **"Setup complete. Your recordings will save to [vault]/[folder]. Run this skill anytime to pull new recordings."**

## After Setup — Running Downloads

Once `config.json` exists, run:

```bash
node ~/.claude/skills/limitless-portable/references/bulk-download.js
```

### Download Options

**All recordings (default):**
```bash
node ~/.claude/skills/limitless-portable/references/bulk-download.js
```

**Specific date range:**
```bash
MEETING_FROM_DATE='2026-01-15' MEETING_TO_DATE='2026-01-20' \
  node ~/.claude/skills/limitless-portable/references/bulk-download.js
```

**Yesterday + today (daily sync):**
```bash
bash ~/.claude/skills/limitless-portable/references/sync-limitless.sh
```

## Output Format

Each recording saves as Obsidian-compatible markdown:

```markdown
---
date: 2026-01-15
source: Limitless AI
type: "Meeting"
duration: 45m 30s
topics:
  - "Project Planning"
id: "abc123"
---

# Meeting Title

> **Date:** 2026-01-15 14:30:00
> **Source:** Limitless AI
> **Duration:** 45m 30s

---

## Summary
[AI-generated summary]

## Content
[Structured content]

## Action Items
- [ ] Action item 1

## Transcript
**Speaker 1:** What they said...
```

## Requirements

- Node.js 18+
- Limitless AI account with Pendant
- Obsidian vault (or any folder — vault detection is a convenience)

## Reconfiguration

Delete `references/config.json` and re-run the skill to go through setup again.
