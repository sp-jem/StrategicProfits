---
name: ghl-review-responder
description: Drafts sentiment-appropriate, brand-voice responses to customer reviews â positive, neutral, or negative â with context awareness and escalation handling. Works from pasted review text. Can optionally look up the reviewer in GHL if contact details are provided. Use when a review needs a response, for batch review cleanup, or when a negative review needs immediate damage control. Trigger phrases: "respond to this review," "draft a review response," "reply to review," "negative review," "bad review response," "review management," "review reply," "customer review," "respond to feedback," "review response template."
license: proprietary
metadata:
tags:
  - program/ctd
  - ghl
  - reviews
  - reputation
---
# GHL Review Responder

## Purpose

Takes a pasted customer review, identifies its sentiment, determines the appropriate response strategy, and drafts a complete, brand-voice response â human, specific, and non-defensive â that either amplifies the positive or professionally contains the negative. Handles escalation routing for reviews that require manager attention or legal awareness.

## Instructions

### Step 1 â Classify the Review

Read the full review. Classify it across three dimensions:

**Sentiment:**
- POSITIVE (4-5 stars, enthusiastic or grateful tone)
- NEUTRAL/MIXED (3 stars, some praise + some criticism)
- NEGATIVE (1-2 stars, complaint, frustration, or warning others)

**Nature:**
- EXPERIENCE FEEDBACK â Comments on service, product quality, results, staff
- PROCESS FEEDBACK â Comments on onboarding, communication, scheduling, billing
- OUTCOME FEEDBACK â Comments on results achieved (or not achieved)
- PERSONAL ATTACK â Targets a specific person in the business
- FACTUALLY INCORRECT â Contains claims that are demonstrably false
- POTENTIAL LEGAL EXPOSURE â Mentions legal action, regulatory complaints, or defamation risk

**Tone:**
- Constructive (even if critical)
- Emotional (frustrated, disappointed, angry)
- Vindictive (written to hurt, not to help)
- Gracious (positive, appreciative)

Record all three dimensions. They determine the response strategy below.

### Step 2 â Contact Lookup (Optional)

If the reviewer's name is visible AND the user wants to check if they're a known GHL contact:

Call `get_contact` or `search_contacts` with the reviewer's name or email (if provided in the review).

If a match is found:
- Note their history: client, lead, past buyer, support case
- Check their tags for any flags (refund requested, support escalation, VIP, etc.)
- This context informs the response tone â a VIP client gets more personal acknowledgment; a known complaint-pattern contact gets more carefully worded response

If no match is found or no lookup is requested: proceed without GHL data.

### Step 3 â Determine Response Strategy

Apply these rules WITHOUT exception:

| Sentiment | Nature | Strategy |
|-----------|--------|----------|
| POSITIVE | Any | Express gratitude, personalize, amplify the relationship, invite them back |
| NEUTRAL/MIXED | Experience/Process | Acknowledge both sides, address the criticism specifically, show what's being done |
| NEUTRAL/MIXED | Outcome | Acknowledge disappointment, offer to continue the conversation offline |
| NEGATIVE | Constructive | Acknowledge, validate the frustration without admitting fault, offer resolution path |
| NEGATIVE | Emotional | De-escalate, show empathy, move conversation offline immediately |
| NEGATIVE | Vindictive | Brief, professional, factual â do not engage with the emotion |
| NEGATIVE | Factually Incorrect | Politely and factually correct without being combative |
| NEGATIVE | Personal Attack | STOP. Flag for manager before drafting. Do not respond to personal attacks without management approval. |
| NEGATIVE | Potential Legal Exposure | STOP. Flag for manager AND legal review. Do NOT draft a public response. |

**For Personal Attacks and Legal Exposure:** Output a STOP notice instead of a draft:

```
HOLD â DO NOT RESPOND YET

This review [contains a personal attack against [name] / contains language that may carry legal implications].

Recommended action:
1. Do not respond publicly until [manager / legal counsel] has reviewed
2. Document the review with a screenshot
3. [For legal: Consider consulting legal counsel before any public response]

When you're ready to proceed with management guidance, return to this skill with a draft direction.
```

### Step 4 â Draft the Response

Write a complete response using the strategy assigned in Step 3. Apply brand voice standards throughout.

#### Brand Voice Standards (apply to ALL responses)

- Human, not corporate. Write like a real person, not a PR department.
- Specific, not generic. Reference something from the actual review text.
- Proportionate. Match the length of the response to the seriousness of the review. A glowing 5-star review gets 2-4 sentences. A complex negative gets 4-7 sentences.
- Ownership without admission. You can acknowledge someone had a bad experience without admitting fault. "We're sorry to hear this wasn't the experience you were hoping for" is not an admission.
- Never defensive, never dismissive.
- NEVER copy-paste the same template for multiple reviews. Every response must reference the actual review content.

**PROHIBITED phrases (instant fail if present):**
- "We value your feedback"
- "We strive for excellence"
- "We take these matters seriously"
- "Thank you for bringing this to our attention"
- "We apologize for any inconvenience"
- "We're sorry you feel that way"
- Any phrase that could appear in any response to any review on any business (generic = fail)

#### Response Formats by Sentiment

**POSITIVE response format:**
```
[First name or "Hi [name]"],

[Genuine, specific acknowledgment of what they mentioned â reference their actual words or experience]

[One sentence that amplifies the relationship: what you love about having clients like them OR what their kind of result represents]

[Invitation to return or continue the journey together â specific, not generic]

[Name, title, business]
```

**NEUTRAL/MIXED response format:**
```
[First name],

[Start with the positive part of their experience â acknowledge it genuinely]

[Address the criticism directly: what happened, what you understand, what it means to you that it fell short]

[What's being done or what they can do next: specific action, not vague promise]

[Invitation to continue the conversation privately to resolve fully]

[Name, title, business]
```

**NEGATIVE â Constructive or Emotional response format:**
```
[First name],

[Lead with acknowledgment of their experience â not "we're sorry you feel that way" but genuine recognition of what they went through]

[One sentence of context (not excuse): show you understand how this happened without deflecting]

[Clear next step: what you'd like to do to make this right OR what they can do to resolve it]

[Private channel invitation: "I'd like to speak with you directly â please reach out to [name] at [contact]"]

[Name, title, business]
```

**NEGATIVE â Factually Incorrect response format:**
```
[First name],

[Acknowledge they had an experience worth sharing â brief]

[Politely and factually correct the specific inaccuracy: "I want to make sure any readers have accurate information: [factual statement]"]

[Offer to discuss further privately]

[Name, title, business]
```

**NEGATIVE â Vindictive response format:**
```
[First name],

[One sentence: acknowledge they shared feedback]

[One sentence: brief factual statement about what your business provides or represents]

[Offer: "If there's something specific we can help with, we're here â [contact method]"]

[Name]
```

### Step 5 â Quality Check

Before delivering the draft, run this check internally. Report failures.

- [ ] Does the response reference something specific from the actual review?
- [ ] Is any prohibited phrase present? (If yes: rewrite)
- [ ] Is the tone proportionate to the sentiment?
- [ ] Is the length appropriate? (Positive: 2-4 sentences; Negative: 4-7 sentences; Vindictive: 3 sentences max)
- [ ] Does a negative response offer a private path to resolution?
- [ ] Is this response something the business owner would be proud to have their name on?
- [ ] Did any STOP condition apply that was overlooked?

If any check fails, fix before delivering.

### Step 6 â Output

Deliver the draft with:

---

## Review Response Draft

**Platform:** [Google / Facebook / Yelp / etc.]
**Review sentiment:** [POSITIVE / NEUTRAL-MIXED / NEGATIVE]
**Review nature:** [Experience / Process / Outcome / Factually Incorrect / etc.]
**Response strategy:** [Strategy applied]
**GHL contact match:** [Found: [name + any notable context] / Not looked up / No match found]

### Drafted Response

[Full response â ready to copy and paste]

---

**Character count:** [#] (platform limit reference: Google ~4,000 / Facebook ~8,000 / Yelp ~5,000)

**Notes:**
[Any flags, recommendations, or escalation notes. If no flags: "No flags â response is clear to post."]

---

## Batch Review Mode

If the user provides multiple reviews at once:
1. Classify all reviews first â present the full classification table before drafting any
2. Flag any STOP conditions immediately
3. Produce drafts in order: NEGATIVE first (highest urgency), then NEUTRAL, then POSITIVE
4. Never skip a review â every review in the batch gets a response

Classification table format:

| # | Reviewer | Platform | Stars | Sentiment | Nature | Priority | Action |
|---|---------|---------|-------|-----------|--------|----------|--------|
| 1 | [Name] | [Platform] | [#] | [+/0/-] | [Type] | [High/Med/Low] | [Draft / STOP] |

## Constraints

- NEVER draft a response to a review without reading the full review text. If no review is pasted, ask for it before proceeding.
- NEVER use any prohibited phrase. These phrases appear in every generic review response and signal that no real human read the review.
- NEVER respond to personal attacks or legally sensitive reviews without manager review. ALWAYS issue a STOP notice and halt until manager guidance is received.
- ALWAYS offer a private path to resolution in negative responses. Public back-and-forth escalates, never resolves.
- NEVER defend the business in a way that invalidates the customer's experience. Even factually wrong reviews get a human response before a factual correction.
- ALWAYS check character limits for the platform before finalizing. A response over the platform limit cannot be posted.
- NEVER assume a review is fake or malicious based on negative sentiment alone. Treat every reviewer as a real person until the pattern clearly indicates otherwise.
- ALWAYS run the quality check (Step 5) before delivering. A response that fails quality check must be rewritten â it is not delivered in its failing state.
- If the business provides industry-specific voice guidelines (clinical, professional services, consumer brand), apply them above the default brand voice standards.
- NEVER include internal operational details in a public review response â staff schedules, refund policy verbatim, pricing structures, internal process details. Those conversations belong offline.
- NEVER produce the same response structure for multiple reviews in a batch. Each response must reference the actual content of its specific review.
- ALWAYS classify all three dimensions (Sentiment, Nature, Tone) before writing the response. A response drafted without classification may apply the wrong strategy.
- NEVER let a STOP condition go unnoticed in a batch. Flag it immediately and visibly â process other reviews, but the STOP review must be clearly marked as blocked.

## Reference

**MCP Server:** BusyBee3333 GHL MCP

**Tools used in this skill:**
- `get_contact` â Look up reviewer by name or email in GHL (optional, when reviewer is identifiable)
- `search_contacts` â Search for reviewer if only a name is known

**Note on reviews API:** GHL's reviews API has limited availability in the current MCP implementation. This skill works entirely from pasted review text. CRM lookup is supplemental context, not a requirement.

**Platforms this skill covers:**
- Google Business Profile
- Facebook / Meta
- Yelp
- Trustpilot
- GHL Review Widget
- Any text-based review platform (paste and go)

**No configuration required** beyond the user pasting review text and identifying the platform.
