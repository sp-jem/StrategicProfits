---
name: alliance-scout
description: Researches, scores, and builds outreach sequences for strategic alliance partners. Marshall's primary bottleneck is the research required to identify qualified alliance prospects across all channels. Use when Marshall wants to find new alliance partners, needs outreach materials for a specific partner, is preparing for an alliance call, or says anything like "find me alliances," "who should I partner with," "research this person," or "build my outreach for [name/company]."
license: proprietary
vault_path: "[YOUR_VAULT]/Marshall Sylver/Strategic Alliances/"
metadata:
tags:
  - program/ctd
---
# Alliance Scout

Eliminates the research bottleneck in Marshall Sylver's alliance acquisition process. Researches potential partners, scores them against Marshall's criteria, builds the outreach sequence, and prepares Marshall for every alliance conversation with a briefing that takes under 5 minutes to review.

## Constraints

**NEVER build outreach for a prospect who scores below 14/20.** Score every prospect before writing a single line of outreach. Below-threshold prospects are logged at the end of the document only â they never appear in the main deliverable.

**NEVER fabricate audience sizes, list sizes, event attendance numbers, or revenue history.** Research is sourced or it is marked [UNVERIFIED]. Presenting invented numbers as research will damage Marshall's credibility in conversations with sophisticated operators who know their own numbers.

**NEVER write outreach that sounds like a vendor asking for list access.** Marshall presents opportunities. Every line of Touch 1 is written from a position of peer-to-peer value, not supplication.

**NEVER open Touch 1 with "I'd like to explore a mutually beneficial partnership" or any variation of that phrase.** This is the most overused opener in JV outreach. It signals a form letter and guarantees deletion.

**NEVER include more than one call to action in any outreach touch.** One touch, one ask.

**NEVER speculate on a prospect's agenda in the call prep brief without at least one data point to support it.** Label every inference as [INFERRED] and every confirmed fact with its source.

**NEVER produce outreach as a "template to customize."** Every outreach touch is a finished draft ready to send as written, or with only Marshall's personal additions.

## Keywords
strategic alliance, joint venture, partnership research, outreach sequence, partner prospect, JV partner, speaking bureau, event promoter, list partner, revenue share, Marshall Sylver alliances, cold outreach, partnership email, referral partner, alliance call prep

## Quick Start

1. Tell Marshall: "Run alliance-scout for [name or category]"
2. Options:
   - Provide a specific name or organization to research: "Research Tony Robbins Events for a stage partnership"
   - Provide a category to source prospects: "Find 10 business/personal development event promoters who book celebrity closers"
   - Provide an existing contact to build outreach for: "Build outreach for [Name], here's what I know about them: [context]"
3. Claude researches, scores, and produces the full package
4. Marshall reviews, adds personal notes, and approves outreach

## Alliance Scoring Criteria

Before producing any research or outreach, score every prospect on four criteria. Use a 1-5 scale per criterion. Minimum qualifying score: 14/20.

| Criterion | What to Evaluate | Score (1-5) |
|-----------|-----------------|-------------|
| Audience Alignment | Does their audience match Marshall's buyer profile â business owners, aspiring success stories, personal development seekers? | |
| Platform Reach | What is their list size, event attendance, or audience scale? Can they move real numbers? | |
| Monetization Sophistication | Have they sold high-ticket programs before? Do they understand revenue-share deals? Will Marshall need to educate them on the model? | |
| Reciprocity Potential | Is there something Marshall can offer them in exchange that they genuinely want â access to Marshall's list, a speaking slot, a hypnosis demo, content for their audience? | |

**Minimum to proceed:** 14/20. Document scores for every prospect researched. Do not build outreach for prospects below 14.

## Core Workflow

### Phase 1 â Prospect Research

For each prospect (specific individual or company), research and document the following. Flag any item that could not be verified as [UNVERIFIED]:

**PROSPECT PROFILE: [Name / Organization]**

**Basic Identity:**
- Full name and title
- Company / platform name
- Primary business model (events, online courses, coaching, media, etc.)
- Industry / niche

**Platform Scale:**
- Estimated email list size (source if available)
- Social media following (platforms and numbers)
- Event scale (if applicable: how many events per year, typical attendance)
- Podcast/YouTube audience (if applicable)

**Alliance History:**
- Have they partnered with speakers, closers, or product sellers before?
- Who have they promoted or partnered with? (Name specific examples if findable)
- Do they have a track record of honoring revenue-share arrangements?
- Any red flags: refund disputes, affiliate non-payment, reputation issues?

**Audience Profile:**
- Demographics: Who attends their events or buys their products?
- Psychographics: What do their buyers want? What are they afraid of?
- Price tolerance: What have they paid for products from this person's recommendations?
- Overlap with Marshall's ideal buyer?

**Reciprocity Intelligence:**
- What does this prospect want that they don't have?
- Could Marshall's audience, stage access, or content provide real value to them?
- Is there a live demo opportunity â Marshall's hypnosis demonstrations are a unique offer no other speaker can match

**Contact Intelligence:**
- Best contact method (email, DM, through their team, through mutual contact)
- Known mutual connections Marshall could use as a warm intro
- Best timing signals (upcoming events, launches, gaps in their calendar)

**Alliance Score:** [total /20 with breakdown]

---

### Phase 2 â Outreach Sequence

For prospects who score 14+, build a 3-touch outreach sequence. Written in Marshall's voice: direct, confident, with a hint of intrigue. Marshall does not grovel. He presents an opportunity.

**Touch 1 â The Pattern Interrupt (Day 1)**

Do not open with "I'd like to explore a mutually beneficial partnership." Everyone says that.

Open with something specific to them: a result they got, something about their audience, a specific event Marshall noticed. Then get to the point.

Template structure:
- Sentence 1: Reference something specific about them â not generic praise
- Sentence 2-3: Who Marshall is in one compelling fact and one specific result
- Sentence 4-5: The specific opportunity â what Marshall is proposing and why it fits their world
- Sentence 6: The ask â simple, direct, no ambiguity

Maximum 150 words. Subject line must open a loop, not describe the email.

**Touch 2 â The Value Drop (Day 4, no reply)**

Send something useful with no ask. A piece of content, a resource, an insight that is relevant to their specific audience or business. One paragraph. One link or resource. "No response needed â just thought this would be useful for your audience" or equivalent.

This touch exists to prove Marshall is not just a taker. It reframes from "vendor wanting access to your list" to "peer sharing something valuable."

**Touch 3 â The Honest Close (Day 8, still no reply)**

Direct. Honest. Acknowledges they haven't replied. Gives them an easy out if it's not the right fit â but makes the opportunity clear one more time. Does not beg. Does not follow up after this.

Example framing: "I'll keep this brief â if the partnership angle doesn't interest you, no problem at all. If it does, here's the simplest next step: [action]."

---

### Phase 3 â Alliance Call Prep Brief

For prospects who have agreed to a conversation, produce a one-page prep brief Marshall reads in under 5 minutes before the call.

**ALLIANCE CALL BRIEF: [Name]**
**Call Date:** [date]
**Duration:** [expected]

**Who They Are (30-second version):**
[Two sentences. What they do, who they serve, what makes them important in their world.]

**Their Likely Agenda:**
[What do they want from this call? What are they hoping Marshall can offer them?]

**Marshall's Objective:**
[What is the specific outcome Marshall wants from this call â speaking slot, list access, revenue share deal, referral arrangement?]

**The Offer to Present:**
[Specific terms Marshall should propose â structure, split, what Marshall provides, what they provide. Do not leave this vague going into the call.]

**Their Top 3 Concerns (anticipated):**
1. [Concern 1 â e.g., "Will Marshall's content fit my audience?"]
   Response: [How to address it]
2. [Concern 2]
   Response:
3. [Concern 3]
   Response:

**The Hook That Applies to Them Specifically:**
[What is the single most compelling thing Marshall can say to this specific person â the thing that applies uniquely to their world, not a generic pitch?]

**Mutual Connections to Reference:**
[Names of any shared contacts, events both attended, etc.]

**The Ask â State It Exactly:**
[Word-for-word how Marshall should close the call with a specific ask. Not "we should explore this further" â a specific next step with a specific action.]

---

## Output Format

For category research (sourcing new prospects):
- Research summary for each prospect found
- Score card with breakdown
- Ranked list: top prospects at the top, below-threshold prospects at the bottom with note on why they didn't qualify
- Outreach sequences for all qualifying prospects

For single prospect research:
- Full prospect profile
- Score with breakdown
- 3-touch outreach sequence
- Call prep brief (if a meeting is already scheduled)

Save to: `[YOUR_VAULT]/Marshall Sylver/Strategic Alliances/[Prospect Name] - [Date].md`

Replace `[YOUR_VAULT]` with the path to your vault folder (e.g., `~/Documents/Obsidian/Active-Brain/00 Projects`).

## Operating Rules

- All research must be sourced. Flag [UNVERIFIED] on anything that could not be confirmed through findable sources. Never fabricate audience sizes, list sizes, or event attendance numbers.
- Outreach is written to be sent as written, or with Marshall's minor additions. It is not a starting template â it is a finished draft.
- Touch 2 (the value drop) requires a real piece of content or resource. If none applies to this specific prospect, write: "Marshall should send: [specific type of content that would be relevant to this prospect's audience]" and let Marshall choose. Never invent a resource.
- Never build outreach for prospects who score below 14/20. Document the score and the specific criteria that caused the disqualification.
- If Marshall provides a name and no other context, use web research to build the full profile before scoring. Do not score until research is complete.
- Alliance call prep briefs are built from research only. Every item labeled as an inference is marked [INFERRED]. Do not present inferences as facts.

## When To Call This Skill

- When Marshall identifies a potential alliance partner and needs research before reaching out
- When building a prospect list for a specific campaign or speaking push
- Before any alliance call â always produce the call prep brief
- When evaluating inbound partnership proposals â score them against the criteria before Marshall spends time on the call
- On a regular cadence: "Find 10 new alliance prospects this week" â run weekly as needed

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Build outreach for prospects below 14/20 | Log them in a separate section â never in main deliverable |
| Fabricate audience sizes, list sizes, or attendance | Mark [UNVERIFIED] on anything unsourced |
| Write outreach that sounds like a vendor asking | Peer-to-peer value framing â Marshall presents, not pitches |
| Open with "mutually beneficial partnership" | Specific reference to something about them |
| Include multiple CTAs in a single touch | One touch, one ask |
| Invent resources for Touch 2 value drop | State the content type needed and let Marshall choose |

## Before You Respond

- [ ] Did I score the prospect before writing any outreach?
- [ ] Is the score at least 14/20?
- [ ] Is every research item either sourced or marked [UNVERIFIED]?
- [ ] Does Touch 1 avoid the "mutually beneficial" opener?
- [ ] Is every inference in the call brief labeled [INFERRED]?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)

## After Delivery

Ask Marshall:
1. "Do any of these need a personal note added to the outreach? Is there anything you know about this person that would change the angle?"
2. "Should I schedule follow-up reminders for Touches 2 and 3 in your system?"
3. "Who approved for outreach this week â should I build a tracking log for responses?"
