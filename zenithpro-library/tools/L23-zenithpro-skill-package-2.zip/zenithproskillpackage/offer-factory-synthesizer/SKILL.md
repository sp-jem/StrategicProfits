# Offer Factory: Cross-Product Synthesizer

---
name: offer-factory-synthesizer
description: "Use after all products have been decomposed, to surface cross-product connections, overlaps, gaps, and combination opportunities."
---

## Purpose

Individual product inventories show what's INSIDE each product. The Synthesizer shows what's BETWEEN them â shared assets being delivered redundantly, natural pairings never combined, gaps in the portfolio where no product serves a need, and combination opportunities that create value exceeding any single product.

## Invocation

```
/offer-factory-synthesizer
```

No arguments needed â it reads all Component Inventories from the Product Components folder.

---

## Input Requirements

**Required:**
- At least 2 Product Component Inventories in:
  `Active-Brain/00 Projects/01 Behavioral Intelligence/Offer Factory/Product Components/`

**Optimal:**
- All 9 product inventories completed
- Offer Autopsies of current offers (for structural pattern context)

---

## Execution Process

### Phase 1: Load All Inventories

Read every `[Product Name] - Component Inventory.md` file in the Product Components folder.

Build an in-memory index:
- Total component count across all products
- Components by category (content, frameworks, prompts, relationships, community, audience, fulfillment, brand)
- Components by product

### Phase 2: Overlap Analysis

Find components that appear in multiple products (same content, same framework, same access):

**Exact Overlaps** â The identical asset delivered in multiple products
- Flag: Redundancy or deliberate reinforcement?
- Flag: Could be extracted into a shared asset accessed by all

**Near Overlaps** â Similar but not identical versions across products
- Flag: Consolidation opportunity? Or do the differences serve different audiences?
- Flag: Could the best version replace all others?

**Audience Overlaps** â Same buyers appearing in multiple product communities
- Flag: What's the typical purchase path?
- Flag: Where are buyers dropping off the ascension?

### Phase 3: Gap Analysis

Map what's NOT covered anywhere in the portfolio:

**Topic Gaps** â Subjects the audience needs that no product teaches
**Format Gaps** â Delivery formats not represented (e.g., all video, no toolkits)
**Price Point Gaps** â Missing rungs on the value ladder
**Audience Gaps** â Buyer segments not served by any product
**Lifecycle Gaps** â Stages of the customer journey with no product

### Phase 4: Connection Mapping

For every component in every product, check against every component in every OTHER product:

**Natural Pairings** â Components from different products that would combine into something powerful
- Example: SOW expert interviews + ZenithPro frameworks = implementation case studies
- Example: Force Multiplier intensive format + Maximum Profit content = accelerated profit program

**Upgrade Bridges** â Components in Product A that create desire for Product B
- These are natural ascension triggers

**Downgrade Bridges** â Components in Product B that could be extracted as entry points to Product A
- These are natural front-end creators

**Amplification Pairs** â Components that make each other more valuable when combined
- Neither works as well alone as they do together

### Phase 5: Combination Opportunities

Generate specific combination concepts:

**New Front-End Ideas** â Components extractable as standalone low-ticket or free offers
- Must be genuinely valuable on its own
- Must create desire for a paid product

**New Back-End Ideas** â Components combinable into premium offers
- Must exceed the value of either component alone
- Must serve a need the current portfolio doesn't fill

**Repackaging Ideas** â Same components, different container
- Content that's currently a lesson â could be a toolkit
- Framework that's taught â could be a certification
- Community access that's bundled â could be standalone

**Bundle Ideas** â Multi-product packages for specific outcomes
- "The AI Implementation Bundle" (components from ZenithPro + Force Multiplier + SOW)
- "The Growth System" (components from multiple products targeting one outcome)

### Phase 6: Portfolio Health Assessment

Overall evaluation:
- **Coherence Score** â Do all products tell one story, or are they fragmented?
- **Ascension Clarity** â Is there an obvious path from cheapest to most expensive?
- **Redundancy Level** â How much overlap exists, and is it intentional?
- **Coverage Score** â What percentage of the target audience's needs are served?
- **Leverageability** â What percentage of assets are being used in only one product?

---

## Output

### File Location
```
Active-Brain/00 Projects/01 Behavioral Intelligence/Offer Factory/Cross-Product Map/Cross-Product Synthesis - [Date].md
```

### Document Structure

```markdown
# Cross-Product Synthesis
**Date:** [Date]
**Products Analyzed:** [count] ([list names])
**Total Components Indexed:** [count]

## Portfolio Summary
[2-3 paragraph overview of what the synthesis reveals]

## Overlap Map

### Exact Overlaps
[Table: Component | Products | Recommendation]

### Near Overlaps
[Table: Component A | Product A | Component B | Product B | Similarity | Recommendation]

### Audience Overlaps
[Venn diagram description of buyer overlap between products]

## Gap Analysis

### Topic Gaps
[What's missing]

### Format Gaps
[Delivery formats not represented]

### Price Point Gaps
[Missing value ladder rungs]

### Audience Gaps
[Unserved segments]

### Lifecycle Gaps
[Journey stages with no product]

## Connection Map

### Natural Pairings (Top 20)
[Ranked list of cross-product component pairings with combination concept]

### Upgrade Bridges
[Product A component â creates desire for â Product B]

### Downgrade Bridges
[Product B component â extractable as â front-end for Product A]

### Amplification Pairs
[Components that multiply each other's value]

## Combination Opportunities

### New Front-End Ideas
[Ranked list with components, source products, concept description]

### New Back-End Ideas
[Ranked list]

### Repackaging Ideas
[Ranked list]

### Bundle Ideas
[Ranked list]

## Portfolio Health

| Metric | Score | Notes |
|--------|-------|-------|
| Coherence | /10 | |
| Ascension Clarity | /10 | |
| Redundancy Level | Low/Med/High | |
| Coverage | /10 | |
| Leverageability | % | |

## Recommendations
[Top 5 strategic recommendations from this analysis]
```

---

## Integration

- **Feeds into Offer Engine:** The Engine uses overlap maps, gaps, and pairing data to generate targeted ideas
- **Feeds into Ecosystem Designer:** The portfolio health assessment becomes the starting point for ecosystem-level redesign
- **Should be re-run:** Whenever a new product is decomposed or an existing product changes significantly
