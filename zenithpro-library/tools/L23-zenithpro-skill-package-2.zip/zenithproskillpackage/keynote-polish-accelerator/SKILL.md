---
name: keynote-polish-accelerator
description: Accelerates the final polish phase of Keith's Keynote presentations â the stage where perfectionism kills momentum and hours disappear. Takes a Keynote that's "mostly done" and produces a structured punch list of specific improvements: slide-by-slide copy edits, flow issues, weak transitions, unclear talking points, and missing proof elements. Eliminates the open-ended polishing loop. Use when Keith is stuck in revision on a Keynote for DWM training, EMF Gone sales, or Level 5 events.
license: proprietary
metadata:
tags:
  - program/ctd
---
# Keynote Polish Accelerator

## Purpose

Converts the open-ended "polish the Keynote" task into a bounded, completable punch list â so Keith stops spending hours on marginal improvements and ships.

## Keywords
Keynote, presentation, slides, polish, revisions, refinement, DWM training, sales presentation, Level 5 events, Brian Ridgway, EMF Gone, talking points, slide copy, presentation review, bottleneck

## Instructions

### Quick Start

1. Export or paste the Keynote content: slide titles + bullet points + speaker notes (if available). Use Keynote's File > Export > Plain Text for large decks.
2. Specify what the presentation is for: who is the audience, what is the outcome (sell / teach / inspire / convince)?
3. Specify how much polish time remains: "I want to be done in 90 minutes" or "30 minutes maximum."
4. Review the punch list â slide-by-slide, specific, actionable, timed.

### Minimum Requirements Before Starting

Do not generate a punch list without all of these confirmed:
- Presentation content (slide titles and copy â rough is acceptable)
- Presentation purpose: sell / train / inspire / event keynote
- Audience: who is in the room or watching?
- Time constraint: how long does Keith have to make edits?
- Ship date: when does this need to be final?

If Keith does not specify a time budget, ask exactly this before proceeding: "How much time do you want to spend on polish? I'll scope the punch list to fit that window."

If the presentation content has not been shared, do not proceed. Ask for the content â generic advice without seeing the actual slides is not a punch list, it is filler.

If Keith pastes only slide titles with no bullets or speaker notes, flag this before generating: "I have the titles only. The punch list will be limited without slide copy. Share what you have â even rough bullets â and I'll work from that."

### Core Workflow

**Step 1 â Full Read, No Comments**
Read the complete presentation content without stopping to comment. Form an overall impression:
- Is the flow logical? (Problem â Solution â Proof â Offer â CTA, or whatever structure is appropriate)
- Is there a clear outcome the audience is meant to reach by the end?
- Where are the energy drops? (Slides that would lose the audience's attention)
- What is missing that would make this more convincing?

Do not give feedback during this step. Complete the full read first.

**Step 2 â Time Budget Allocation**
Given the time available, allocate it before generating the punch list:
- 10% â Flow and structure issues (do slides need to be reordered or cut?)
- 50% â Slide-level copy edits (highest-value polish)
- 20% â Talking points and transition lines between slides
- 20% â Proof and credibility elements

State this allocation to Keith before the punch list begins. Example for 60 minutes: ~6 min on flow, ~30 min on copy, ~12 min on transitions, ~12 min on proof.

**Step 3 â Punch List Generation**
Generate a numbered punch list organized by priority (not by slide order). Most impactful changes first.

Each item must include:
- Specific slide number or section (not "improve the intro")
- Actionable instruction with specific language (not "make this clearer" â say "Replace 'enhanced performance' with a specific result like 'cut your cost per lead by 40%'")
- Time estimate (2 min / 5 min / 10 min) â time estimates must reflect actual work required, not optimistic minimums
- Priority designation: Essential, High Value, or Nice-to-Have

**Step 4 â Stop Here Line**
After all items, include a stopping point. This is not optional â every punch list must end with this line or a variation of it:

"When you've completed items 1-[X], the presentation is ready to deliver. Items [Y-Z] are improvements that do not meaningfully change outcomes â skip them if you're short on time."

This line is the purpose of the tool. A punch list without it enables the perfectionism loop the tool exists to end.

## Reference

### Company Voice Standards

**DWM:** Training presentations for Facebook ads clients and students. Audience wants tactics, proof, and clear frameworks. They are skeptical and metric-oriented. Copy edits push toward specific numbers and direct claims.

**EMF Gone:** Sales presentations and event materials. Audience ranges from health-conscious consumers to partners. Dr. Herman's credibility is a key asset. Copy edits lead with his authority and stay compliance-safe.

**Level 5 Mentoring:** Brian Ridgway's content on inner work and identity. Audience is high-achievers. Presentation tone is reflective, not tactical. Copy edits preserve the spacious, introspective quality â do not import DWM's metric-driven language into Level 5 materials.

## Output

```markdown
# KEYNOTE POLISH PUNCH LIST
**Presentation:** [Name/purpose]
**Audience:** [Who]
**Polish time budget:** [X minutes]
**Ship date:** [Date]
**Generated:** [Date]

---

## TIME ALLOCATION
- Flow review: ~[X] min (items [#-#])
- Copy edits: ~[X] min (items [#-#])
- Transitions: ~[X] min (items [#-#])
- Proof/credibility: ~[X] min (items [#-#])

---

## STRUCTURE ISSUES (Complete First)

**Item 1 â [Description]** | [X min] | ESSENTIAL
*Slide:* [#]
*Issue:* [What is wrong â specific]
*Fix:* [Exact instruction]

[Continue for all structure issues]

---

## COPY EDITS (Highest Density of Impact)

**Item [#] â [Description]** | [X min] | ESSENTIAL / HIGH VALUE
*Slide:* [#]
*Current:* "[exact current text]"
*Change to:* "[suggested replacement]"
*Why:* [One sentence â why this matters for this specific audience]

[Continue for all copy edits]

---

## TRANSITIONS & TALKING POINTS

**Item [#] â [Description]** | [X min] | HIGH VALUE / NICE-TO-HAVE
*Between slides:* [# â #]
*Issue:* [Why the transition is weak or unclear]
*Bridge line:* "[Suggested spoken transition Keith could use to connect the two slides]"

---

## PROOF & CREDIBILITY

**Item [#] â [Description]** | [X min] | ESSENTIAL / HIGH VALUE
*Slide:* [#]
*Missing:* [What proof element is absent or weak]
*Add:* [Specific suggestion â a stat, testimonial type, case study format, or visual]

---

## STOP HERE LINE

**This presentation is ready when you've completed items [#] through [#].**

Items [#] through [#] are improvements only â skip them if your time is up. The difference between completing them and not completing them will not meaningfully affect your outcome.

**Estimated completion time for essential items:** [X minutes]

---

## OPTIONAL (Only if time allows)

[Items marked Nice-to-Have â clearly separated so Keith knows these are not required]
```

## Constraints

- Never review visual design (fonts, colors, slide backgrounds). This skill covers content and copy only. The bottleneck is content decisions, not design.
- Never suggest adding new slides unless a critical structural element is missing. The goal is polish, not expansion.
- Never generate a punch list without a "Stop Here" line. A list without this line makes the tool complicit in the perfectionism loop it exists to end.
- Every copy edit must include the current text and the suggested replacement. "Improve this slide" is not a punch list item.
- Time estimates must reflect actual required work. If fixing an issue takes 20 minutes, say 20 minutes â not 5. Underestimating times defeats the purpose of scoped polish.
- Prioritize by impact on outcome, not by location in the deck. The highest-priority edit is the one that most affects whether the audience does what Keith wants.
- Company voice is non-negotiable: DWM edits push toward metric specificity, Level 5 edits preserve reflective tone, EMF Gone edits lead with Dr. Herman's credibility. Do not mix these voices.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Review visual design (fonts, colors, layouts) | Content and copy only â design is not the bottleneck |
| Suggest adding new slides | Polish, not expansion â unless a critical structural element is missing |
| Generate a punch list without a Stop Here line | Stop Here is mandatory â it ends the perfectionism loop |
| Say "improve this slide" | Cite current text â replacement text â why |
| Underestimate time per item | Honest estimates â 20 min means 20 min, not 5 |
| Mix company voices | DWM = metrics, Level 5 = reflective, EMF Gone = Dr. Herman's authority |

## Before You Respond

- [ ] Do I have the actual presentation content (not just a description)?
- [ ] Do I know the audience and purpose?
- [ ] Do I have a time budget for polish?
- [ ] Am I applying the correct company voice (DWM / EMF Gone / Level 5)?
- [ ] Does the punch list end with a Stop Here line?

## When To Use This Skill

- When Keith has a Keynote that's "almost done" but he cannot stop tinkering
- Before any presentation Keith needs to hand off to team for use without him
- When Keith is workshopping presentations with partners (Brian at Level 5, Dr. Herman at EMF Gone) and needs a structured revision plan
- When a Keynote is needed for a specific date and Keith needs to scope the polish to fit the time available

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
