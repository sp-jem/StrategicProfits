---
name: ghl-no-show-recovery
description: Identifies contacts who missed scheduled appointments and produces personalized, context-aware re-engagement sequences â SMS, email, and re-booking logic â to recover lost meetings before they become lost deals. Use immediately after discovering a no-show, at end of day when reviewing no-shows, or when running a batch no-show cleanup. Trigger phrases: "no-show recovery," "missed appointment," "didn't show up," "ghosted my call," "recover no-shows," "re-book no-shows," "missed call follow-up," "no-show sequence," "they didn't show," "batch no-show check."
license: proprietary
metadata:
tags:
  - program/ctd
  - ghl
  - appointments
  - recovery
---
# GHL No-Show Recovery

## Purpose

Pulls today's (or a specified date's) appointments from GHL, identifies which contacts did not attend, tags them appropriately, and produces a personalized re-engagement sequence for each â including an immediate SMS, a follow-up email, and a re-booking push â so no-shows are recovered within hours instead of falling into the dead-lead pile.

## Instructions

### Step 1 â Identify No-Shows

**For a specific contact:**
Ask for their name, email, or appointment ID. Proceed to Step 2.

**For batch no-show review:**
Call `get_calendar_events` for today (or the user-specified date) to retrieve all scheduled appointments.

For each appointment, call `get_appointment` to check the status. Identify appointments where:
- Status is not "completed," "attended," or similar positive completion state
- OR where the scheduled time has passed with no status update

Present a triage list before producing any output:

| # | Contact Name | Appt Time | Status | Rep |
|---|-------------|-----------|--------|-----|
| 1 | [Name] | [Time] | [No-show / Unknown / Canceled] | [Rep] |

Ask: "Confirm these are the no-shows you want to recover, or flag any that should be excluded." NEVER proceed without confirmation on batch runs.

### Step 2 â Pull Contact Profile

For each confirmed no-show, call `get_contact` to retrieve:
- Full name (and first name for personalization)
- Email address
- Phone number (mobile preferred for SMS)
- Source / how they found you
- Current tags
- Assigned rep
- Any custom fields indicating program interest, pain, or qualification status

### Step 3 â Pull Conversation History

Call `search_conversations` to find the contact's message thread.

Call `get_recent_messages` to review last 10 messages.

Extract:
- Whether this is a first-time appointment or a repeat no-show
- What the contact said in their most recent message before the appointment
- Any prior no-shows (look for `no-show` tags already applied)
- Tone of last interaction: enthusiastic / neutral / cautious
- Any stated reason for the appointment (why they booked)

**Classify the no-show by type:**
- **First-time no-show, warm engagement history:** Most recoverable. Act fast.
- **First-time no-show, cold/minimal engagement history:** Use a softer approach.
- **Repeat no-show (prior no-show tag exists):** Escalate â this requires a different sequence.
- **No-show after clear buying signals:** High priority. Get on phone immediately.

### Step 4 â Apply No-Show Tag

Call `add_contact_tags` to apply the appropriate tag:
- First no-show: `no-show-1`
- Second no-show: `no-show-2`
- Third no-show: `no-show-3`

If `no-show-3` or higher: flag for manager decision before any further outreach. At this point, continuing re-engagement wastes resources and may violate communication preferences.

Do NOT remove existing tags. Only add.

### Step 5 â Produce Recovery Sequence

For each no-show contact, produce a three-part recovery sequence. NEVER produce generic outreach. Every message must reference something specific to this contact.

**PROHIBITED phrases (instant fail if present in any message):**
- "just following up"
- "checking in"
- "I noticed you missed our call"
- "I wanted to reach out"
- "hope you're doing well"
- "as a reminder"

---

#### Message 1: Immediate SMS (send within 60 minutes of no-show)

Requirements:
- Under 160 characters
- Casual, not passive-aggressive
- Assumes the best (technical issue, calendar conflict, life happened)
- Includes a direct re-booking link or time offer
- References the specific call or their stated goal if possible

Format:
```
Subject: [N/A â SMS]

[First name], [brief human reference to the missed call + immediate re-book offer + link or specific time options]
```

#### Message 2: Follow-Up Email (send 2-4 hours after no-show if no SMS reply)

Requirements:
- Subject line is specific to their situation â not "Missed Appointment"
- Opens with context reference (not a generic opener)
- Extends genuine benefit of the doubt
- Restates the value of the conversation (what they were going to get from the call)
- Provides 2-3 specific re-booking time slots or a direct link
- Under 150 words

Format:
```
Subject: [Specific â references their goal or situation]

[First name],

[Context: what they were coming to discuss / what value was on the table]

[Easy out: short, non-blaming acknowledgment that things come up]

[Clear re-book offer: 2-3 specific times or a scheduling link]

[Brief value restatement: what they get when they do show]

[Rep name]
[Contact info]
```

#### Message 3: Final Re-Engagement (send 24-48 hours later if still no response)

Requirements:
- This is the last message in the sequence â make it count
- Acknowledge the pattern without accusation
- Create mild urgency (not fake scarcity)
- Offer an alternative engagement path if a call isn't right for them
- Under 120 words

Format:
```
Subject: [Direct â shows this is a decision point]

[First name],

[Acknowledge they haven't responded + express that's okay]

[State what's available to them and for how long]

[Alternative: lower-commitment next step if a call feels like too much right now]

[Clear call to action: respond, click, or reply "not interested" to close the loop]

[Rep name]
```

---

### Step 6 â Repeat No-Show Protocol (no-show-2 or higher)

If a contact is a second or third no-show, the standard sequence above does NOT apply. Use this instead:

**Second no-show:**
- SMS only: "Hey [first name] â we've missed each other twice now. Still interested in [what they came to discuss]? Reply YES and I'll send you options, or NO if the timing isn't right."
- No follow-up email unless they reply YES

**Third no-show:**
- STOP all outreach
- Tag: `no-show-3` and `manager-review`
- Flag to manager: "[Contact name] is a 3x no-show. Recommend: archive, long-term drip only, or remove from active pipeline. Manual decision required."
- NEVER auto-send a third no-show email sequence without manager sign-off

### Step 7 â Delivery Decision

Present all drafted messages. Ask: "Ready to send, or would you like to review/edit first?"

NEVER send any message without explicit user confirmation.

For batch recovery (multiple no-shows), list all drafted sequences and get a single "send all" or "review each" decision.

Call `send_sms` for SMS messages confirmed for sending.
Call `send_email` for email messages confirmed for sending.

### Step 8 â Output Summary

---

## No-Show Recovery Report

**Date processed:** [Today's date]
**Total no-shows identified:** [#]

| Contact | No-Show # | Type | Sequence Produced | Status |
|---------|-----------|------|------------------|--------|
| [Name] | [1/2/3] | [Warm/Cold/Post-buying-signal] | [3-part / 2-part / Manager escalation] | [Draft / Sent / Pending review] |

### Action Required from Manager
[List any 3x no-shows or escalations requiring a manual decision, or "None"]

### Messages Sent
[List each message sent with contact name, channel, and time, or "None sent â all in draft"]

---

## Constraints

- NEVER classify a contact as a no-show without pulling the appointment record and confirming no-completion status. A rescheduled or canceled contact is NOT a no-show.
- NEVER send any message without explicit user or manager confirmation. Default is always draft.
- NEVER use the prohibited phrases. Any draft containing "just following up," "checking in," "I noticed you missed our call," "I wanted to reach out," "hope you're doing well," or "as a reminder" fails quality check and must be rewritten before delivery.
- ALWAYS personalize every message. A generic no-show email is worse than no email â it signals you don't remember who they are.
- NEVER escalate past `no-show-2` sequence without manager review. Aggressive outreach to repeat no-shows damages deliverability and reputation.
- ALWAYS tag contacts immediately upon confirmation of no-show status. Tags are the memory of the system â without them, the no-show pattern is invisible.
- If a contact canceled or rescheduled with notice, they are NOT a no-show. Remove them from the recovery list immediately and do not tag them with any no-show tag.
- ALWAYS restate the value of the call in recovery messaging. No-show recovery that doesn't remind them what they're missing gives them no reason to rebook.
- NEVER mark recovery as complete until the message is sent OR the user has made a decision on each contact. A pending decision is not a completion state.
- For contacts who have a buying signal in their history, flag them as HIGH PRIORITY for the rep to call manually â SMS/email alone is insufficient for high-intent no-shows.
- NEVER send a recovery sequence to a contact whose tags include an active support escalation, complaint, or refund-requested flag. Flag for manager decision first.
- ALWAYS confirm the re-booking link or time slots are provided by the user before sending Message 1. A recovery SMS with no re-booking path serves no purpose.
- NEVER proceed with batch recovery without showing the triage list and receiving explicit confirmation of which contacts to include.

## Reference

**MCP Server:** BusyBee3333 GHL MCP

**Tools used in this skill:**
- `get_calendar_events` â Pull today's (or specified date's) appointment list
- `get_appointment` â Check appointment status for each scheduled call
- `get_contact` â Pull full contact profile for personalization
- `search_conversations` â Find conversation history to classify no-show type
- `send_sms` â Deliver confirmed SMS messages
- `send_email` â Deliver confirmed email messages
- `add_contact_tags` â Apply no-show sequence tags (`no-show-1`, `no-show-2`, `no-show-3`, `manager-review`)

**Configuration required:**
- Calendar ID must be set in MCP config (ask user for their GHL calendar ID)
- No-show tags (`no-show-1`, `no-show-2`, `no-show-3`, `manager-review`) must exist in GHL account
- Re-booking link (Calendly, GHL calendar link, etc.) must be provided by user for inclusion in messages

**Failure Modes:**

MCP not connected: "GHL MCP server is not responding. Cannot pull appointment or contact data. If you know who no-showed, paste their details and I can draft the recovery messages from what you provide."

No appointments found for date: "No appointments found for [date]. Confirm the correct calendar is being checked and the date is correct. If appointments were booked in a different calendar or sub-account, the Calendar ID may need to be updated in the MCP config."

Contact has no phone number (SMS unavailable): "No mobile number on file for [contact name]. SMS cannot be sent. Proceeding with email sequence only. Add a phone number to the contact in GHL to enable future SMS."

Contact has no email (email unavailable): "No email on file for [contact name]. Email cannot be sent. Proceeding with SMS only. Update the contact record with an email address for full sequence delivery."

Repeat no-show identified (no-show-3): Stop sequence automatically. Report to user: "[Contact name] has no-showed 3 times. All outreach is paused. Recommend manager decision before any further contact."
