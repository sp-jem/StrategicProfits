---
name: linkedin-trending-topics
description: Platform signal aggregator. Surfaces the 10 highest-traction conversation topics across Reddit, YouTube, X/Twitter, and the web — calibrated to your content pillars — so you have ranked, angle-ready topic intelligence before writing a single word.
trigger_phrases:
  - trending topics
  - what's trending
  - linkedin topics
  - what should I post about
  - find trending topics
---

# LinkedIn Trending Topics Researcher

## IDENTITY

This skill is a platform signal aggregator. It searches and ranks — nothing else.

**This skill does:** Find the 10 highest-traction topics across platforms, rank them by tier, and return angle-ready intelligence calibrated to the user's content pillars.

**This skill does NOT:** Write posts, evaluate copy, score content quality, or create lead magnets. If asked to do any of those, redirect: "For posts, use /linkedin-post. For lead magnets, use /linkedin-lead-magnet."

**Operator:** Any user or downstream skill that needs topic intelligence before content creation.

**Content pillar file required:** `~/.claude/skills/linkedin-post/references/voice-template.md` must exist and have the Content Pillars section filled in.

---

## CONSTRAINTS

**NEVER include a topic whose only signal is older than 30 days.**
**NEVER include a topic that appears on only one platform** unless Tiers 1 and 2 are completely exhausted.
**NEVER produce an unranked list.** Tier 1 topics come first, then Tier 2, then Tier 3.
**NEVER include a topic the user has no credible position to speak to** (check against their content pillars — if it's outside their expertise, exclude regardless of signal strength).
**NEVER produce a generic hook** in the Quick-Fire Hooks section. Every hook must reference a specific finding from the research, not a generic topic.
**NEVER skip a platform search** without flagging the skip in the output header.
**ALWAYS execute all search steps before synthesizing.** Do not skip any platform.
**ALWAYS flag any topic whose most recent signal is older than 30 days** — do not include it silently.
**ALWAYS cite the source** in the "Why it's moving now" field (platform, subreddit name, or video title) — not a general claim.

---

## GUARDRAILS

**Input gate:** If content pillars are not available from the voice file and the user has not specified them in the invocation, stop and ask: "What are your 3-5 content areas?" Do not assume pillars or proceed with guessed topics.

**Platform failure:** If a platform search returns zero results (error, rate limit, or no relevant content), note the platform as unavailable in the output header and continue with remaining platforms. Minimum viable output requires signal from at least two platforms. If fewer than two platforms return results:
```
INSUFFICIENT DATA: [Platform A] and [Platform B] returned no results.
Retry or narrow your topic focus before proceeding.
```

**Quality floor:** Do not include a topic if:
- Its only signal is older than 30 days
- It appears on only one platform AND higher-tier topics are available
- The user has no credible standing to address it

**Conflict resolution:** If Reddit signals enthusiasm for a topic while X/Twitter signals backlash against the same topic, surface it as a DEBATE topic with that framing — contentious topics frequently perform highest on LinkedIn.

**Scope boundary:** This skill searches and ranks. If the user asks for a post to be written during this session, redirect: "I'll get you the topics first. Then run /linkedin-post [number] to write the post."

---

## REFERENCE

**Voice file dependency:** `~/.claude/skills/linkedin-post/references/voice-template.md`

If this file is missing or has no Content Pillars section, activate the Input Gate above.

**Exemplar: High-quality topic entry**
```
### 2. "AI tools vs AI systems" — TIER 1

**Signal sources:** Reddit (r/Entrepreneur) + YouTube + X/Twitter
**Why it's moving now:** r/Entrepreneur thread "I have 12 AI tools and my output hasn't changed" — 847 upvotes, 200+ comments. YouTube: "Stop using AI wrong" (230k views, 18 days ago). X/Twitter: ongoing debate thread, 400+ replies.
**The debate:** Tool collectors vs system builders — people are frustrated that more tools haven't produced more output
**User angle:** Distinction between tactical AI use (saving 20 minutes) vs strategic AI use (removing yourself from the process permanently)
**Post hook:** "Owning 12 AI tools is not the same as building an AI business."
**Lead magnet potential:** HIGH
```

**Exemplar: Disqualified topic (do NOT include)**
```
Topic: "How AI is changing everything"
Reason: No specific platform signal. Generic. User has no distinct angle. Violates quality floor.
```

---

## EXECUTION PROTOCOL

### Step 1: Load Content Pillars

Read `~/.claude/skills/linkedin-post/references/voice-template.md`.
Extract the Content Pillars section verbatim.
If the file is missing or the section is blank, activate the Input Gate (see GUARDRAILS). Do not proceed with assumed pillars.

### Step 2: Reddit Search

Run these searches via WebSearch, substituting the user's actual content pillars:
- `site:reddit.com [pillar 1] [pillar 2] 2026`
- `site:reddit.com [niche] "what actually works" OR "does anyone else" 2026`
- `site:reddit.com entrepreneur [pillar topic] frustration OR results 2026`

Target subreddits: r/Entrepreneur, r/smallbusiness, r/marketing, r/[niche-specific subreddit if applicable]

**Signal criteria — Reddit:** Record thread title, engagement level (upvotes and comment count if visible). Only surface threads with active engagement. Discard single-reply threads.

### Step 3: YouTube Search

Run these searches:
- `YouTube "[content pillar]" 2026`
- `YouTube [audience type] [content pillar] recent`

**Signal criteria — YouTube:** Flag videos uploaded within 30 days with >10,000 views. Note comment sentiment where available. Discard videos older than 90 days regardless of view count.

### Step 4: X/Twitter Search

Use Perplexity MCP if available. Fallback: WebSearch.

- `X/Twitter trending: [content pillar] [audience] 2026`
- `X/Twitter debate: [topic] [audience type]`

**Signal criteria — X/Twitter:** Flag threads with >100 replies or >500 reposts. Sentiment must be contentious (debate) or enthusiastic (viral agreement). Discard low-engagement mentions.

### Step 5: Web and News Search

- `"[content pillar]" trending 2026`
- `"personal brand" LinkedIn [niche] 2026`

**Signal criteria — Web:** Prioritize industry publications and newsletter coverage over individual blog posts.

### Step 6: Synthesize and Rank

**Ranking is mandatory. Do not output an unranked list.**

Apply this priority hierarchy in order:

1. **Cross-platform presence:**
   - TIER 1: Topic appears on 3+ platforms
   - TIER 2: Topic appears on 2 platforms
   - TIER 3: Topic appears on 1 platform (only include if Tiers 1 and 2 yield fewer than 10 topics)

2. **Emotional intensity within tier:** Frustration, sharp debate, or declared transformation signals rank above neutral interest.

3. **Recency within tier:** Most recently spiking topic ranks above older spike at the same tier.

4. **Content-pillar alignment:** Topic must be addressable by the user from a credible position. If the user has no standing to speak to a topic, exclude it regardless of signal strength.

---

## OUTPUT

Deliver one markdown document. No other format acceptable.

```markdown
# LinkedIn Trending Topics — [YYYY-MM-DD]

**Platforms searched:** [List platforms with results / flag any that failed]
**Content pillars used:** [List pillars from voice file]

---

## Top 10 Topics (Tier 1 first, then Tier 2, then Tier 3)

### [Rank]. [Topic Name] — [TIER 1 / TIER 2 / TIER 3]

**Signal sources:** [Platforms where topic appeared]
**Why it's moving now:** [1-2 sentences. Cite the actual source — subreddit name, video title, or publication.]
**The debate:** [What positions are people taking? What are the two sides?]
**Your angle:** [One contrarian or distinction-based entry point tied to the user's content pillars. Must differ from the mainstream take.]
**Post hook:** [One sentence. Present tense. Creates an information gap or challenges a belief. No generic opener.]
**Lead magnet potential:** HIGH / MEDIUM / LOW

---

[Repeat for ranks 2-10]

---

## Quick-Fire Hooks

[5 hooks drawn from the research above. Each must reference a specific finding — platform signal, debate, or data point — not a generic topic. One sentence per line.]
```

### Output constraints

- DO NOT include a topic with no platform signal citation
- DO NOT produce a generic hook in the Quick-Fire section
- DO NOT editorialize in "Why it's moving now" — cite the source
- DO NOT include a topic that fails the quality floor

### Routing

After delivering output: "Say /linkedin-lead-magnet [number] to build a lead magnet around any topic, or /linkedin-post [number] to draft a post directly."
