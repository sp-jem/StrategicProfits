---
name: ghl-post-call-processor
description: Processes a sales or support call transcript into structured CRM updates, follow-up tasks, opportunity changes, and ready-to-send messages â without any manual data entry. Use immediately after any call to capture what happened, what was promised, what changed, and what goes out next. Trigger phrases: "process this call," "call recap," "update CRM from call," "post-call," "call notes to CRM," "what did I promise," "follow up after call," "call debrief," "log this call," "transcript to tasks."
license: proprietary
metadata:
tags:
  - program/ctd
  - ghl
  - calls
  - intelligence
---
# GHL Post-Call Processor

## Purpose

Takes a raw call transcript (or structured call notes) and converts it into five concrete outputs: a CRM contact note, follow-up tasks with deadlines, opportunity stage updates, a drafted follow-up email, and an optional SMS. Eliminates the manual CRM entry that kills post-call momentum and lets important commitments slip.

## Instructions

### Step 1 â Extract Call Intelligence

Read the full transcript. Extract and structure the following:

**Participants:**
- Contact name (prospect/client side)
- Rep name (your side)
- Date and time of call (if stated)
- Call duration (if stated)

**Call Classification:**
- Type: Discovery / Follow-up / Demo / Proposal / Objection Handling / Closing / Support / Check-in
- Outcome: Positive (moving forward) / Neutral (no decision) / Negative (not interested) / Inconclusive

**Key Discussion Points:**
List every substantive topic discussed. Do not summarize to the point of losing specificity.

**Commitments Made (Your Side):**
List every promise, next action, or deliverable the rep committed to. Format: "[Who] will [what] by [when if stated]."

**Commitments Made (Contact Side):**
List every action the contact said they would take. Format: "[Contact] will [what] by [when if stated]."

**Objections Raised:**
List each objection verbatim or near-verbatim. Label each: ADDRESSED (and how) or UNRESOLVED.

**Buying Signals:**
Any positive indicators: questions about pricing, timeline, onboarding, references, or "what happens next."

**Red Flags:**
Any concern indicators: mentioned competitor, stalled timeline, budget hesitation, decision by committee, expressed doubt.

**Agreed Next Step:**
The single most important next action both parties agreed to. If no next step was agreed to, flag: "No next step established on this call â this is a risk."

### Step 2 â Create Contact Note

Call `create_contact_note` with a structured note. The note must include ALL of the following sections. NEVER collapse into free-form text.

Note format:

```
CALL NOTE â [Date]
Type: [Discovery / Follow-up / Demo / Proposal / Objection Handling / Closing / Support / Check-in]
Outcome: [Positive / Neutral / Negative / Inconclusive]
Rep: [Name]
Duration: [If known]

DISCUSSION SUMMARY
[3-5 bullet points covering main topics. Specific, not generic.]

COMMITMENTS â OUR SIDE
â¢ [Action 1] by [date/timeframe]
â¢ [Action 2] by [date/timeframe]

COMMITMENTS â CONTACT SIDE
â¢ [Action 1] by [date/timeframe]

OBJECTIONS
â¢ [Objection] â [ADDRESSED: how] or [UNRESOLVED]

BUYING SIGNALS
â¢ [Signal or "None"]

RED FLAGS
â¢ [Flag or "None"]

AGREED NEXT STEP
[Single clear next action with date/method]
```

### Step 3 â Create Follow-Up Tasks

For every commitment made on your side, call `create_contact_task` with:
- Title: specific action (not "follow up with contact")
- Due date: the committed date if stated; otherwise 24 hours from call for hot commitments, 48 hours for standard
- Assigned user: the rep who was on the call (if known)
- Priority: HIGH for commitments made verbally to the contact; NORMAL for internal prep items

REQUIRED: Every task must have a due date. NEVER create a task with no deadline.

If a commitment was made with no specific date, set the due date to 24 hours and flag: "No deadline stated on call â defaulted to 24 hours. Confirm with rep."

### Step 4 â Update Opportunity

Call `search_opportunities` or `get_opportunity` to locate the active opportunity for this contact (search by contact name or email).

Based on the call outcome, call `update_opportunity_status` or `update_opportunity` as appropriate:

| Call Outcome | Stage Action |
|--------------|-------------|
| Positive â agreed to demo | Move to Demo Scheduled |
| Positive â agreed to proposal | Move to Proposal Sent |
| Positive â verbal yes | Move to Closing / Contract Sent |
| Neutral â needs more info | Stay in current stage; update notes |
| Negative â not interested | Move to Lost; add loss reason |
| Inconclusive â follow up pending | Stay in current stage; update last contact date |

If no opportunity exists for this contact: "No active opportunity found for [contact name]. Create one manually in GHL or confirm this is not a sales contact."

NEVER move an opportunity forward without a clear positive signal from the transcript. Do not advance based on the rep's optimism.

### Step 5 â Draft Follow-Up Email

Draft a complete follow-up email based on the call. This email must:
- Reference the specific call and what was discussed (not generic opener)
- Confirm all commitments made on both sides
- Restate the agreed next step with a specific date/time or link
- Address any unresolved objection with a brief response if appropriate
- Not exceed 200 words

PROHIBITED phrases (auto-fail if present): "just following up," "as per our conversation," "per our discussion," "I wanted to reach out," "checking in."

Format the email:

```
Subject: [Specific to this call â not generic]

[Contact first name],

[Opener that references what specifically was discussed]

[Confirm commitments â yours and theirs]

[Restate next step with date/method]

[One-sentence close]

[Rep name]
```

After drafting, call `send_email` ONLY if the user has explicitly said "send it" or "send the follow-up." Default behavior is DRAFT ONLY â present the email and ask: "Ready to send, or do you want to edit first?"

### Step 6 â Draft SMS (Conditional)

If the call outcome is Positive AND the contact provided a mobile number AND the agreed next step is time-sensitive (same day or next day), draft an SMS:

Requirements:
- Under 160 characters
- References the specific next step
- Not a generic "great talking to you" message
- Includes a direct link or clear action if applicable

Call `send_sms` ONLY if the user says "send it." Same default-to-draft rule as email.

### Step 7 â Output Summary

Produce a final summary of all actions taken:

---

## Post-Call Processing Report

**Contact:** [Name]
**Call date:** [Date]
**Call type:** [Type] | **Outcome:** [Outcome]
**Rep:** [Rep name]

### CRM Actions Completed
- [x] Contact note created â [Note ID if returned]
- [x] Tasks created: [list each task title and due date]
- [x] Opportunity updated: [from stage] â [to stage]
- [ ] Follow-up email: DRAFTED (not sent) / SENT
- [ ] Follow-up SMS: DRAFTED (not sent) / SENT / NOT APPLICABLE

### Commitments Logged
**Your side:**
[List each]

**Contact side:**
[List each]

### Agreed Next Step
[Restate clearly â do not let this get buried]

### Risks / Flags
[List unresolved objections, missing deadlines, no-next-step risk, or "None"]

---

## Constraints

- NEVER process a call without a pasted transcript or structured notes. If only a contact name is provided with no call content, ask for the transcript before proceeding.
- NEVER invent call content. Every note, task, and message must trace to the transcript.
- NEVER send email or SMS without explicit user confirmation. Default is always draft.
- NEVER create a task without a deadline. "Follow up soon" is not a task.
- ALWAYS flag when no next step was established. This is the most common deal-killer and must appear prominently in the Risks section.
- NEVER advance an opportunity stage on optimism alone. Stage changes require a specific positive signal from the transcript.
- ALWAYS draft the email before asking to send â never present an empty template.
- NEVER use prohibited phrases in drafted messages: "just following up," "as per our conversation," "per our discussion," "I wanted to reach out," "checking in."
- ALWAYS confirm which rep was on the call before assigning tasks. If unknown, flag as "Rep unknown â assign manually."
- NEVER log a note shorter than 5 bullet points in the Discussion Summary. Thin notes are useless in 30 days when the rep can't remember the call.
- If the call was clearly negative (not interested, do not contact), flag for manager review before any outreach is drafted.
- ALWAYS include the Agreed Next Step in the Post-Call Processing Report summary. If no next step was established, state it explicitly as a risk â do not omit the section.
- NEVER omit unresolved objections from the Risks section. Every UNRESOLVED objection is a deal risk that must surface in the output.

## Reference

**MCP Server:** BusyBee3333 GHL MCP

**Tools used in this skill:**
- `update_contact` â Update contact fields post-call (last contact date, custom fields)
- `create_contact_note` â Write the structured call note to the contact record
- `create_contact_task` â Create deadline-bound follow-up tasks
- `send_email` â Send or draft the follow-up email
- `send_sms` â Send or draft the follow-up SMS
- `update_opportunity` â Update opportunity fields and notes
- `update_opportunity_status` â Move opportunity to new pipeline stage

**Configuration required:**
- GHL pipeline stage names must match exactly what this skill references (or user must supply correct stage names)
- Rep user IDs must be known for task assignment (ask user if unclear)

**Failure Modes:**

MCP not connected: "GHL MCP server is not responding. CRM updates cannot be written. Save the processed output below to a local file and enter manually when the connection is restored."

No opportunity found for contact: "No active opportunity found for [contact name]. If this is a sales contact, create an opportunity manually. Proceeding with note and task creation only."

Transcript too short to extract actionable data: "The transcript provided does not contain enough information to extract commitments, objections, or a next step. Provide a longer transcript or structured call notes with: what was discussed, what was promised, and what happens next."

Contact not found in GHL: "Cannot locate [contact name] in GHL. The note and tasks cannot be attached. Confirm the contact exists or create them first with `create_contact`."
