---
name: client-education-builder
description: Builds plain-English client education booklets for Hassaan & Associates practice areas â First Time Home Buyers, Estate clients, Corporate clients, and others. Use when Fay wants to create or update a client guide, explain a legal process in plain language, build a digital info product, or says anything like "write a client guide," "explain this to clients," "first time home buyer booklet," "estate process guide," or "digital product."
license: proprietary
tags:
  - program/ctd
  - client/fay-hassaan
---
# Client Education Builder

Produces plain-English client education booklets for Hassaan & Associates. Turns Fay's legal expertise into guides that reduce client anxiety, reduce repetitive questions, and serve as the foundation for digital info products.

---

## MINIMUM REQUIREMENTS BEFORE STARTING

Do not draft any booklet until confirmed:
- Which practice area (First Time Home Buyers | Estate Administration | Wills and POA | Corporate)
- Intended use: printed booklet for clients | PDF emailed at intake | digital product for sale
- Any existing content to incorporate (optional â Q&A emails, verbal explanations, FAQs)

If no practice area is specified, ask: "Which booklet are we building â First Time Home Buyers, Estate Administration, Wills and Powers of Attorney, or Corporate Services? And will this be a client handout, an email attachment, or a paid digital product?"

---

## PRACTICE AREA PLAYBOOKS

The following content maps define the required sections for each practice area. Sections may be added, removed, or reordered based on Fay's direction â but the map is the starting point, not a suggestion.

### Playbook 1: First Time Home Buyers

**Audience:** Ontario first-time home buyers unfamiliar with the legal closing process.
**Tone:** Warm, reassuring, plain English. No Latin. No jargon without explanation.

Required sections:
1. Welcome and Why You Need a Real Estate Lawyer
2. The Timeline (from accepted offer to closing â in days from closing date)
3. What You Need to Provide (ID, mortgage instructions, deposit receipts, insurance certificate)
4. What We Do Behind the Scenes (title search, mortgage review, Statement of Adjustments, transfer documents)
5. Closing Day (what to expect, what to bring, what you sign, how the keys work)
6. The Statement of Adjustments (each line explained in plain English)
7. After Closing (what to keep, what to register, when your deed arrives)
8. Common Questions (top 10 questions first-time buyers ask)
9. Our Offices (Milton and Grimsby contact information, hours)

Tone model: "Closing day feels like the big day â and it is. But by the time you're in our office, almost everything is already done. You're signing documents that formalize what we've already arranged. Here's exactly what to bring and what to expect."

---

### Playbook 2: Estate Administration / Probate

**Audience:** People who have just lost a family member and need to administer an estate.
**Tone:** Compassionate, clear, practical. Acknowledge the emotional weight without dwelling on it.

Required sections:
1. What Happens When Someone Dies (legal process overview; what probate is and when you need it)
2. The Executor's Role (what you're responsible for; what the lawyer handles)
3. What You Need to Bring to the First Meeting (will, death certificate, asset list, financial statements)
4. The Probate Process in Ontario (step by step: application, certificate, asset distribution timeline)
5. Common Assets and How They're Handled (bank accounts, real property, RRSP/RRIF, vehicles, business interests)
6. What This Costs (government fees, legal fees, estate trustee compensation â frank explanation)
7. How Long It Takes (realistic timeline by complexity level)
8. Your Responsibilities as Executor (what you can and can't do before probate is granted)
9. Common Questions (top 10 from grieving families)
10. Our Offices (contact information and what to bring to the first appointment)

---

### Playbook 3: Wills and Powers of Attorney

**Audience:** Anyone making a Will or POA for the first time, or updating after a life event.
**Tone:** Matter-of-fact, not scary. Normalize the process.

Required sections:
1. Why This Matters (what happens if you die without a Will in Ontario â intestacy rules, briefly)
2. What a Will Does (executor, beneficiaries, guardianship if children, specific bequests)
3. What a Will Doesn't Do (joint assets, RRSP beneficiaries, life insurance)
4. Types of Power of Attorney (Continuing POA for Property vs. POA for Personal Care; when each applies)
5. What to Think About Before Your Appointment (beneficiaries, executor, guardianship wishes)
6. The Appointment Process (what to bring, how long it takes, what you sign)
7. After Your Will Is Done (where to store it, who to tell, when to update it)
8. Common Questions (8â10 Qs covering digital assets, blended families, minor beneficiaries, pets)
9. Our Offices (contact information)

---

### Playbook 4: Corporate Services

**Audience:** Entrepreneurs incorporating for the first time, or existing business owners needing corporate legal work.
**Tone:** Professional but accessible. Treat the reader as smart, not as a lawyer.

Required sections:
1. Why Incorporate? (liability protection, tax planning, professional credibility)
2. Ontario vs. Federal Incorporation (which is right for your business)
3. What You'll Need to Decide (company name, directors, shareholders, share structure)
4. What Incorporation Includes (articles, corporate minute book, registers, initial resolutions)
5. Shareholder Agreements (what they are and why you need one even with a trusted partner)
6. Ongoing Corporate Maintenance (annual returns, resolutions, minute book updates)
7. Our Fees (what's included, what costs extra)
8. Common Questions (8â10 Qs covering sole proprietor vs. corporation, holding companies, foreign directors)
9. Our Offices (contact information)

---

## CORE WORKFLOW

### Step 1 â Confirm the Playbook and Customizations

Before writing, confirm:
- Which practice area
- Intended use (printed / emailed / for sale)
- Sections to add, remove, or emphasize
- Any existing client Q&As or emails to incorporate

### Step 2 â Draft the Booklet

Write the full booklet in section order. Required writing standards:
- Reading level: Grade 8 or below
- No Latin phrases
- Legal terms used only when necessary, always defined immediately after
- No sentence over 30 words
- Active voice throughout ("We will" not "it will be")
- Canadian spelling throughout (colour, favour, neighbour, cheque)
- Ontario-specific law only â if another province's rules apply, flag it as "outside the scope of this guide"
- Every section ends with a "Next step" or clear takeaway sentence

### Step 3 â Produce the Booklet Structure

```markdown
# [Title]
**Hassaan & Associates, P.C.**
**Milton: 330 Bronte Street South, Suite 204, Milton, ON L9T 7X1**
**Grimsby: [Address]**
**Phone: [Number] | Email: legal@hassaanlaw.ca | www.hassaanlaw.ca**

---

[Section 1 heading]

[Content]

---

[Section 2 heading]

[Content]

... (continue all required sections)

---

## Questions? We're Here.

[Closing paragraph â warm, direct, invites contact. Not "don't hesitate to reach out." Something specific about calling the office.]

**Milton office:** [number] | [address]
**Grimsby office:** [number] | [address]
**Email:** legal@hassaanlaw.ca
```

### Step 4 â Digital Product Version (if applicable)

If Fay specifies this will be sold, add a second pass:
- Add a cover page with a product title (not just a guide title)
- Add a testimonial placeholder section
- Add a "What to Do Next" section with a call to book a consultation at Hassaan & Associates
- Do not change the legal content of any section â only add the commercial framing

---

## GUARDRAILS

- Every booklet produced is a draft for Fay's review and legal sign-off. Mark every output "DRAFT â For Fay's Review" at the top. No client should receive a booklet that Fay has not approved.
- Never make specific legal claims about outcomes (e.g., "you will save X in taxes"). Describe options; Fay advises on outcomes in the client relationship.
- Ontario law only. Do not import rules from other provinces without explicit flagging.
- Every booklet must include the office addresses, phone number, and email. A guide that does not drive a consultation call is incomplete.
- Canadian spelling on every draft. No exceptions.
- If producing a digital product version, do not alter legal accuracy in service of marketing framing.

---

## OUTPUT SAVE LOCATION

`06 Marketing & JV/Client Education/[BookletName]-draft-[YYYY-MM-DD].md`

## Edge Cases

1. **5th practice area not in the 4 playbooks** â Flag: "This practice area isn't in the standard 4 playbooks. Fay should confirm scope and required sections before content is drafted."
2. **Client is outside Ontario** â Stop and flag. Ontario law only â do not import other provinces' rules without explicit instruction.
3. **Existing Fay content conflicts with template structure** â Preserve Fay's content verbatim; adjust the template structure around it. Legal accuracy is non-negotiable.
4. **Digital product request without consultation CTA** â Stop and flag. Every booklet must drive a consultation â digital products without a CTA are incomplete.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Make specific legal outcome claims | Describe options â Fay advises on outcomes |
| Import rules from other provinces | Ontario law only â flag if client is outside |
| Use American spelling | Canadian spelling on every draft |
| Send a client a booklet without Fay's sign-off | Every output labeled "DRAFT â For Fay's Review" |
| Alter legal accuracy for marketing framing | Commercial wrapper only â legal content stays untouched |
| Omit office addresses and contact info | Every booklet drives a consultation call |

## Before You Respond

- [ ] Is this one of the 4 standard practice areas?
- [ ] Am I using Canadian spelling?
- [ ] Is the content Ontario-specific?
- [ ] Have I included both office contacts and email?
- [ ] Is the output labeled "DRAFT â For Fay's Review"?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Edge Cases, Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
