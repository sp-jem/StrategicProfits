---
name: client-stage-communicator
description: Generates stage-appropriate client communication for every phase of the Lockwood College Prep and Yesterday's Debt client lifecycle. Covers eight distinct stages from pre-engagement through loan repayment â drafts emails, follow-up sequences, document request templates, and escalation notices. Eliminates Christine's follow-up inconsistency by giving her exact language for every situation. Use when drafting any client-facing communication at LCP or Yesterday's Debt.
license: proprietary
metadata:
tags:
  - program/ctd
  - client/pearl-lockwood
---
# Client Stage Communicator

Generates stage-specific client communication for Lockwood College Prep and Yesterday's Debt. Every email, every document request, every escalation sequence â written to match where the client is in the process, what they need to do next, and what happens if they don't respond.

## Keywords
client email, follow-up, document request, FAFSA, CSS Profile, award letter, escalation, onboarding, financial aid, loan repayment, LCP, Yesterday's Debt, AWOL client, no-response sequence, stage communication, Christine workflow

## HARD CONSTRAINTS â Read Before Anything Else

- NEVER guess at financial figures in client communication. If Pearl needs to state a specific dollar amount, she supplies it â do not estimate.
- NEVER state a deadline in client communication without Pearl confirming the date is correct first.
- NEVER send more than one action request per email. Multiple asks reduce response rates.
- NEVER send a Variant C (escalation) email without Pearl's awareness. C variants go out under Pearl's name â Pearl must know before they're sent.
- NEVER overstate what a financial aid appeal can achieve. Use "I believe we can pursue more" not "I can get you $X more."
- NEVER use language that could be characterized as a debt collection communication in Yesterday's Debt emails. Yesterday's Debt provides professional advisory services, not debt collection. FDCPA compliance is non-negotiable.
- NEVER send a generic template without personalizing it for the specific client. Subject lines and body must reference the client's name and specific missing items â not placeholders.
- Christine does NOT have authority to send Variant C without Pearl's knowledge.

## Quick Start

1. Name the stage (see Stage List below)
2. Describe what the client needs to do or what happened (e.g., "no documents in 10 days")
3. Confirm: LCP or Yesterday's Debt
4. Confirm: who sends it (Pearl or Christine) â this changes the tone
5. Output is a complete draft ready to send, with any unfilled fields flagged explicitly

## Stage List â Lockwood College Prep

| Stage | What's Happening | Key Communication Needs |
|-------|-----------------|------------------------|
| **Stage 1: Pre-Filing Strategy** | Advisory session, income/asset strategy before any forms are filed | Meeting prep, summary recap, action list |
| **Stage 2: Onboarding & Document Collection** | Collecting tax returns, asset statements, divorce docs, business returns | Document request, missing item follow-up, escalation |
| **Stage 3: FAFSA Filing** | Filing the FAFSA, resolving SAI issues, identity verification | Filing confirmation, correction requests, student account setup |
| **Stage 4: CSS Profile Filing** | Completing CSS Profile for profile schools | Profile checklist, document coordination, deadline urgency |
| **Stage 5: Post-Filing Document Fulfillment** | Schools request additional verification documents | Specific document requests, upload confirmation, deadline tracking |
| **Stage 6: Award Letter Collection** | Getting ALL award letters before May 1 decision deadline | Award letter request, reminder sequence, urgency escalation |
| **Stage 7: Award Letter Consultation** | Helping family understand their letters and decide | Meeting summary, appeal recommendation, comparison delivery |
| **Stage 8: Appeal** | Writing and submitting an appeal to increase aid | Appeal letter delivery, school-specific submission instructions, follow-up |

## Stage List â Yesterday's Debt

| Stage | What's Happening | Key Communication Needs |
|-------|-----------------|------------------------|
| **Stage A: Initial Consultation** | Assessing loan portfolio for consolidation/repayment plan | Intake request, document list, consultation summary |
| **Stage B: Plan Design** | Analyzing SAVE, PAYE, ICR, RAP, OBBBA (One-Time Borrower-Based Adjustment) options | Plan comparison delivery, recommendation memo |
| **Stage C: Implementation** | Filing consolidation, enrolling in income-driven repayment | Action checklist, studentaid.gov guidance, confirmation tracking |
| **Stage D: Annual Recertification** | Income recertification for IDR plans | Recertification reminder, document request, deadline urgency |

## Core Workflow

### Step 1 â Identify Stage and Situation

Ask (or infer from context):
- Which stage is this client in?
- Which business (LCP or Yesterday's Debt)?
- What specifically is needed: initial outreach, follow-up (how many days since last contact?), escalation, or a meeting summary?
- Who sends it: Pearl directly, or Christine?

If Christine is sending it, the tone is warm but firm. If Pearl sends it directly, the tone is authoritative and precise.

### Step 2 â Select Template Variant

Each stage has three variants:

**Variant A â Initial Contact**
First outreach on this topic. Warm, clear, gives full context.

**Variant B â Follow-Up (7-10 Days No Response)**
Friendly reminder. Emphasizes deadline or consequence if relevant.

**Variant C â Escalation (15+ Days No Response)**
Firm. States consequences explicitly (missed deadline, delayed filing, lost aid opportunity). Creates urgency without alarm.

### Step 3 â Generate Communication

Produce the full email draft. Every draft includes:

- **Subject line** (specific to the action needed, not generic)
- **Body** (complete â not a template with [NAME] blanks Pearl has to fill in, but ready-to-send with any blanks flagged)
- **Action item for client** stated in the final sentence, specific and singular (one ask per email)
- **Christine note** (if applicable): brief instruction on what Christine should do if no response within X days

---

## Stage 1 â Pre-Filing Strategy Communication

### Variant A: Pre-Strategy Meeting Prep

**Subject:** Your Pre-Filing Strategy Session â What to Prepare

**Body:**
[Parent First Name],

Your pre-filing strategy session with Pearl is scheduled for [Date/Time]. This is your most important conversation of the college planning process â the decisions we make before submitting any financial aid forms can directly affect how much aid your family receives.

To make the most of our time, please have the following ready:

- Your most recent federal tax return (2023 if you're filing for the 2025-26 aid year)
- A rough estimate of your current savings and investment account balances
- If you own a business: your business tax return and any S-Corp distributions from last year
- If you own real estate beyond your primary home: current value and mortgage balance
- Your student's college list â even a rough one

We'll also discuss any significant changes in your financial situation since last year's tax return was filed.

If you have questions before our meeting, reply to this email or text [talk2pearl.com or phone].

Looking forward to it,
Pearl Lockwood
Lockwood College Prep

---

### Variant A: Post-Strategy Meeting Summary

**Subject:** Your Pre-Filing Strategy Summary â Action Items Before We File

**Body:**
[Parent First Name],

Thank you for meeting with me today. Here's a summary of what we covered and what needs to happen before we file.

**Your Strategy for [Student Name]'s Financial Aid:**

[Pearl fills in 2-4 specific decisions from the session. Examples:]
- We are NOT listing the beach property on FAFSA â federal methodology exempts primary home equity but does not exempt additional real estate. We discussed the implication.
- We are timing the retirement contribution to [plan type] before the filing date to reduce reportable assets.
- [Student Name]'s UTMA account balance will be reported as a student asset â we discussed how this affects the SAI calculation.

**Before We File â Your Action Items:**
1. [Specific action, specific deadline]
2. [Specific action, specific deadline]

**My Action Items:**
1. [What Pearl is doing next]

If anything has changed or you have questions about any of the above, contact me before [date] â changes made after we file are significantly harder to correct.

Pearl Lockwood
Lockwood College Prep

---

## Stage 2 â Onboarding & Document Collection

### Variant A: Initial Document Request

**Subject:** Documents Needed to File â [Student Name]

**Body:**
[Parent First Name],

We're ready to begin filing for [Student Name]. To complete the FAFSA [and CSS Profile, if applicable], I need the following from you.

**Required Documents â Please Upload to [Google Drive folder link] by [Date]:**

- [ ] 2023 federal tax return (1040, all pages)
- [ ] W-2s for both parents (if filing jointly)
- [ ] Current bank and investment account statements (all accounts, current month)
[Add school-specific items Pearl knows are needed based on the college list]

**If any of the following apply, I also need:**
- [ ] Business tax return (if you own an S-Corp, LLC, or partnership)
- [ ] Divorced/separated: non-custodial parent's 2023 tax return
- [ ] Prior-prior year returns if income has significantly changed

**Deadline:** Please upload everything by [Date]. If we miss this window, your filing will be delayed and you may lose priority aid consideration at [List affected schools].

If you're unsure about any item, reply to this email â Christine can help you identify what you need.

Pearl Lockwood
Lockwood College Prep
(Christine is copying you on this email and will be your point of contact for document questions.)

**Christine: If no upload by [Date+7], send Variant B.**

---

### Variant B: Document Follow-Up (7-10 Days)

**Subject:** Still Missing Documents â [Student Name] Filing at Risk

**Body:**
[Parent First Name],

I want to make sure [Student Name]'s financial aid application doesn't fall behind. We're still missing [list specific items Christine identifies as missing from the drive] from your document upload.

These items are required before we can file. Without them, we cannot meet the priority deadline for [School Names].

Missing items:
- [Item 1]
- [Item 2]

Please upload to [Google Drive link] or email them directly to [Christine's email] by [Date].

If you have already sent these and they're not showing up in our system, please let Christine know: [Christine contact].

Pearl Lockwood
Lockwood College Prep

---

### Variant C: Document Escalation (15+ Days)

**Subject:** Urgent â Filing Cannot Proceed Without Your Documents

**Body:**
[Parent First Name],

I need to hear from you today. We have been waiting [X days] for the documents required to file [Student Name]'s financial aid forms.

If we do not receive these documents by [hard deadline], I cannot file before the priority deadline for [School Name(s)]. Missing the priority deadline at [school] historically costs families [$3,000â$10,000] in aid â the school awards remaining funds to applicants who filed on time.

Items still missing:
- [Item 1]
- [Item 2]

Please respond to this email, upload to [link], or call Christine at [number] today.

If you are facing a situation that is preventing you from responding â travel, medical issue, or anything else â please tell us so we can adjust. We want to help you, but we cannot file without these documents.

Pearl Lockwood
Lockwood College Prep

---

## Stage 6 â Award Letter Collection

### Variant A: Initial Award Letter Request (March)

**Subject:** Your Award Letters Are Coming In â Here's What I Need

**Body:**
[Parent First Name],

Congratulations to [Student Name] â decisions are arriving and award letters are coming with them. Here's what I need you to do as each one comes in.

**For every school that admits [Student Name]:**
1. Forward the award letter email to [Pearl's email]
2. If the letter is only available in a student portal, take a screenshot or copy the text and send it to me

I need to see every letter â including from schools you're already ruling out. The letters from lower-cost schools often give us leverage to appeal for more aid at your preferred school.

I'll be comparing all the letters and reaching out to schedule a call once I have them all â or once we're close to the May 1 deadline.

The schools we're watching most closely for [Student Name]:
- [School 1]
- [School 2]
- [School 3]

Do not make a deposit at any school before we talk.

Pearl Lockwood
Lockwood College Prep

---

### Variant C: Award Letter Escalation (May 1 Approaching)

**Subject:** May 1 Deadline â I Need Your Letters Before We Lose the Option to Appeal

**Body:**
[Parent First Name],

The May 1 national deadline for college enrollment decisions is [X days] away. I have not yet received award letters from [School Names], and I need them before I can do my job.

Once May 1 passes, most schools close the appeal window. That means any additional aid I could have negotiated for [Student Name] will not be available.

Please send me everything you have today â even if the letters seem incomplete or confusing. I'll figure out what's missing.

Reply to this email with the letters attached or forwarded.

Pearl Lockwood
Lockwood College Prep

---

## Stage 8 â Appeal Communication

### Variant A: Appeal Letter Delivery to Family

**Subject:** [Student Name]'s Appeal to [School Name] â Ready to Submit

**Body:**
[Parent First Name],

The appeal letter for [School Name] is ready. I've attached it to this email.

**Before you submit:**
1. Read it carefully â if anything is factually incorrect about your family's situation, tell me before it goes out
2. Do not change the language or add to it without discussing with me first â appeals are carefully calibrated
3. Submission instructions for [School Name]: [Specific instructions â email to aid office, submit via portal, include student ID, etc.]
4. Submit by [Date] â most schools have a soft window that closes after [Date]

After you submit, forward me the confirmation or screenshot. I'll follow up with the school if we don't hear back within [10-14 business days].

Pearl Lockwood
Lockwood College Prep

---

## Stage D â Yesterday's Debt: Annual Recertification

### Variant A: Recertification Reminder (90 Days Out)

**Subject:** Your Income-Driven Repayment Plan Requires Annual Recertification by [Date]

**Body:**
[Client First Name],

Your [SAVE / PAYE / ICR / RAP] repayment plan requires annual income recertification. Your deadline is [Date].

If you miss this deadline, your payment will revert to a standard repayment amount â which is typically significantly higher than your income-driven payment.

**What you need to do:**
1. Go to studentaid.gov/idr and log in with your FSA ID
2. Select "Recertify" for your current plan
3. Submit your income documentation (2023 tax return or pay stubs if income has changed)

**Important:** If your income has changed significantly from last year â either up or down â contact me before you recertify. A change in income may qualify you for a different plan that saves more money.

Please confirm when you've submitted your recertification.

Pearl Lockwood
Yesterday's Debt

---

### Variant C: Recertification Escalation (30 Days Out)

**Subject:** URGENT â Recertification Due in 30 Days â Missing This Will Increase Your Payment

**Body:**
[Client First Name],

Your income-driven repayment plan recertification is due in [30 days] â [Date].

I have not received confirmation that you have submitted it. If this is missed, your loan servicer will recalculate your payment at the standard (non-income-based) rate. For most of my clients, this means a payment increase of $[range] per month.

This is a real deadline with real financial consequences. Please recertify today at studentaid.gov/idr.

If you are having trouble with the studentaid.gov portal or FSA ID login, reply to this email and I will walk you through it.

Pearl Lockwood
Yesterday's Debt

---

## Christine's Operating Instructions

These templates are designed for Christine to execute on Pearl's behalf. Christine's role in using this skill:

1. **Identify the stage** â Christine knows where each client is in the process
2. **Check the last contact date** â determine whether to send Variant A, B, or C
3. **Fill in the client name and specific missing items** â never send a generic template without personalizing it
4. **Send from the appropriate email** â LCP communications from the LCP account, Yesterday's Debt from that account
5. **Log it** â note in the client file that the communication was sent and on what date
6. **Follow the embedded Christine notes** â each escalation template includes the instruction for Christine's next action if no response

**Christine never sends Variant C without Pearl's approval.** Escalation emails go out under Pearl's name and carry Pearl's authority â Pearl needs to know before they're sent.

## Failure Modes and Required Responses

| Situation | Required Response |
|-----------|------------------|
| Pearl asks for a draft but has not confirmed the deadline | Produce the draft with [DATE â PEARL TO CONFIRM] in every deadline field. Do not estimate or omit. |
| Christine requests a Variant C | Produce it, but add a header: "HOLD â REQUIRES PEARL'S AWARENESS BEFORE SENDING." |
| Yesterday's Debt email risks sounding like a collection notice | Flag the specific phrase and offer a compliant alternative. Never send language that could trigger FDCPA concerns. |
| Email would require more than one action from the client | Split into two emails or restructure so the primary ask is singular. Flag this to Pearl. |
| Appeal communication overstates achievable outcome | Rewrite to "we will pursue" rather than "we will get." Flag the change. |
| Client has not responded after Variant C (30+ days silent) | Stop manual outreach. Add to 90-day nurture sequence. Flag for Pearl: "This client is unresponsive after full escalation. Recommend closing the active file and adding to quarterly check-in list." |

## When To Use This Skill

- When drafting any stage-specific email for an enrolled LCP client or active Yesterday's Debt client
- When Christine needs exact language for a follow-up or escalation
- When Pearl wants a consistent communication sequence for a client who has gone quiet
- When a client has missed a document deadline and needs Variant B or C escalation
- NOT for prospect/marketing emails â this is for enrolled clients in active service stages only

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Send a generic template without personalizing | Every email must reference the client's name and specific missing items |
| Include more than one action request per email | One ask per email â split into two if needed |
| Let Christine send Variant C without Pearl | Escalation requires Pearl's awareness before sending |
| Overstate what an appeal can achieve | "We will pursue" not "We will get you $X" |
| Use language resembling debt collection in YD emails | Advisory services framing only â FDCPA compliance non-negotiable |
| Use this skill for prospect marketing emails | This is for enrolled clients in active lifecycle stages only |

## Coverage Note

**Templates currently available for:** Stages 1, 2, 6, 8 (LCP) and Stage D (Yesterday's Debt). Stages 3, 4, 5 (LCP) and Stages A, B, C (YD) are defined in the Stage List but templates are not yet built. For those stages, Pearl drafts manually or requests templates be generated on demand.

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added When To Use, Anti-Patterns, Coverage Note, Version History (Gauntlet QA pass)

## Save Location

Templates and sent drafts: `[Pearl's Vault]/Client Communications/[Stage Name]/[Client Last Name]-[Date].md`
