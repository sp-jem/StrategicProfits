---
name: ad-creative-factory
description: Produces Facebook ad creative briefs, hooks, body copy, and headline variants for Flexxable's book funnel and Flexx Digital's agency offers. Use when Graham needs new ad angles, when current ads are fatiguing, when he wants to test new hooks for the Facebook-to-book-to-ROYA funnel, or when he says anything like "write me some ads," "I need new hooks," "my CPAs are up," "create ad variants," or "what angles should I test."
license: proprietary
metadata:
tags:
  - program/ctd
---
# Ad Creative Factory

## Purpose

Generates Facebook ad hooks, body copy, creative briefs, and test variants specifically for Flexxable's book funnel and Flexx Digital's Database Reactivation AI Agent service â without starting from a blank page.

**Keywords:** Facebook ads, ad copy, ad creative, ad hooks, book funnel, ROYA, lead generation, direct response, ad variants, ad angles, creative brief, copy testing, CPL, CPA, database reactivation, Flexxable, Flexx Digital, paid advertising

---

## Instructions

### Quick Start

1. Specify which funnel: Flexxable book funnel, Flexx Digital Database Reactivation service, or both
2. Optionally share current CPA or hook score and paste the current ad if one is running
3. Claude produces 5 hook variants, 3 body copy variants, and a creative brief for the best angle
4. Review â one pass of feedback if needed â then export to Facebook Ads Manager

### Minimum Requirements Before Starting

**Do not write a single word of copy until these are confirmed:**
- Which product or funnel the ad is for (book funnel vs. Database Reactivation vs. ROYA upsell)
- Target audience â if not specified, default to business owners and marketing managers for Flexxable, agency owners for Flexx Digital
- Any hard constraints: budget level, image vs. video, cold vs. warm audience

**If Graham has a current top performer to beat, request it before starting.** Writing against a control is always better than writing from scratch.

---

### Step 1 â Identify the Funnel and Audience

**Funnel A â Flexxable Book Funnel:**
- Product: Flexxable book (direct mail + digital)
- Traffic source: Facebook/Instagram cold audiences
- Goal: low-cost book opt-in â upsells/downsells â ROYA high-ticket program
- Audience: business owners, agency owners, marketing managers in UK/Ireland (primary) and English-speaking markets
- Key promise: more clients, better systems, less chaos using AI-driven lead generation methods
- The funnel is a tripwire â book price is low, monetization is in the backend

**Funnel B â Flexx Digital Database Reactivation AI Agent:**
- Product: Done-for-you AI agent that reactivates dormant leads in a business's existing database
- Buyer: Agency owners, established businesses with 1,000+ dormant leads in CRM
- Key promise: turn cold dead leads into booked appointments and revenue â without new ad spend
- Objection to counter: "We've tried reactivation before." Counter: the AI agent approach is different from email blasts or manual outreach

**Funnel C â ROYA High-Ticket (backend only):**
- Upsell from book funnel â never cold traffic
- Audience already trusts Flexxable â warm audience writing rules apply

### Step 2 â Generate Hook Variants

Produce 5 distinct hooks for the specified funnel. Apply a different framework for each:

1. **The Specific Number Hook** â Quantifies the pain or the result ("Most agency owners waste Â£2,300/month on an admin job AI can do in 90 seconds")
2. **The Contrarian Hook** â Contradicts conventional wisdom in the niche ("Stop trying to generate new leads until you've done this first")
3. **The Pattern Interrupt Identity Hook** â Causes a specific reader type to self-identify ("If you run a service business with 1,000+ leads sitting dead in your CRM...")
4. **The Future Pacing Hook** â Opens with the reader already in the desired future state ("What it looks like when your old dead leads start booking calls again â without you doing anything")
5. **The Direct ROI Hook** â Leads with a pound amount and a mechanism ("Â£47,000 from leads our client had written off. Here's the system we used.")

For each hook, state:
- The hook text (1-2 sentences)
- The angle/framework used
- Which audience segment it speaks to most
- Why it should work or why to test it

**Every set of variants must include at least one hook leading with a specific number. Vague hooks are untestable.**

### Step 3 â Write Body Copy Variants

Produce 3 body copy variants (60-150 words each, appropriate for Facebook feed):

**Variant 1 â Story/Problem format:** Problem scenario â mechanism â offer
**Variant 2 â Social Proof format:** Specific result from a real client type â how â offer
**Variant 3 â Curiosity/Teaser format:** Mechanism framed as what people don't know â open loop â offer resolves it

**Rules per funnel:**
- Flexxable book funnel: close every variant with a CTA that emphasizes the low risk of the book offer
- Flexx Digital: close with a consultation or demo CTA â never a product purchase CTA

### Step 4 â Produce the Creative Brief

Always produce a creative brief alongside copy. Never deliver copy alone.

```
AD CREATIVE BRIEF
Funnel: [Funnel A / B / C]
Format: [Static image / Video / Carousel]
Primary hook: [The winning hook from Step 2 â Graham picks or Claude recommends]
Headline: [3 options]
Body copy: [Selected variant from Step 3]
CTA button: [Single option â Learn More / Get Free Book / Book a Call]

VISUAL DIRECTION:
Tone: [Clean and professional / Disruptive / Testimonial-forward]
Key visual element: [What should appear in the image/thumbnail â person, screenshot, number]
Text overlay: [Yes/No â if yes, specify the text]
Brand requirements: [Flexxable or Flexx Digital colors/logo placement]

TESTING NOTES:
Test this against: [Current control if known, or "establish baseline"]
Primary variable being tested: [Hook / Image / Offer / Audience]
Success metric: [CPL target / CPA target]
Kill threshold: [At what spend or CPL to stop this creative]
```

### Step 5 â Optional: Competitive Angle Check

If Graham specifies a competitor or market context, identify:

**Angles likely saturated:**
- Generic "AI will transform your business" messaging
- "Work less, earn more" lifestyle messaging
- Webinar-style talking head ads without specific numbers

**Angles underexploited:**
- The cost of the status quo (how much the broken current system is costing them per month)
- Specificity of the mechanism ("Database Reactivation AI Agent" â use the name, not just "AI")
- Risk reversal for service skeptics ("we've tried vendors before" objection)

---

### Ad Fatigue Response Mode

When Graham reports an ad is dying or CPA is climbing, run this diagnostic first:

1. **Hook fatigue or creative fatigue?** If CPA climbed after consistent volume, it's likely frequency fatigue on the creative. If it climbed immediately, it may be an offer or audience issue.
2. **What to swap first:** Hook is the fastest A/B test. Swap the hook, keep everything else identical.
3. **Never swap hook + image + body simultaneously.** Isolate one variable per test.

**Recommended three-week test sequence:**
- Week 1: New hook against same image and body (isolate hook impact)
- Week 2: If hook improves CPA, test new image with winning hook
- Week 3: If both improved, test body copy variant

---

## Operating Rules

- **Never write a Flexxable cold traffic ad that assumes brand awareness.** Write as if the reader has never heard of Flexxable.
- **Never make a specific income claim** ("make Â£10,000 in 30 days") without flagging the compliance risk. Reframe as "here's what clients have achieved" with specific client attribution â and flag the compliance issue explicitly.
- **Never recommend changing more than one creative variable simultaneously.** State this explicitly if Graham requests multiple simultaneous changes.
- **UK/Ireland primary market:** Spelling, references, and tone must feel British first, not American direct response.
- **Mechanism-forward always:** The Database Reactivation AI Agent and the n8n/GHL methodology are selling points â name them specifically.
- **Dan Wardrope voice:** Approachable authority. Not a tech bro, not a suit. Someone who gets their hands dirty.

---

## Reference

**Data inputs:** Any performance data Graham provides â Everflow/Facebook Ads export, current ad body copy. No API connections required.

**Creative direction contact:** Alan Cotter (videographer/designer) is the brief recipient. Address briefs to him by name.

**Dependencies:** None. Works from funnel information and performance data Graham provides. Optional: paste current ad body copy or Everflow/Facebook Ads data for tighter analysis.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Write cold ads assuming brand awareness | Write as if the reader has never heard of Flexxable |
| Make specific income claims without compliance flag | Reframe as "clients have achieved" with attribution + flag |
| Change multiple creative variables simultaneously | One variable per test â isolate the cause |
| Write in American direct response tone | UK/Ireland voice first â British spelling, references |
| Omit the mechanism | Name the Database Reactivation AI Agent and n8n/GHL methodology |
| Write a tech-bro voice | Dan Wardrope voice: approachable authority, hands-on |

## Before You Respond

- [ ] Do I know the funnel (A/B/C/D)?
- [ ] Do I know the ad fatigue status?
- [ ] Am I writing in UK/Ireland voice?
- [ ] Did I flag any income claims for compliance?
- [ ] Am I addressing the brief to Alan Cotter?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
