---
name: webinar-content-engine
description: Builds complete SKI webinar content packages from a topic and a handful of bullet points. Produces a full webinar outline, opening hook, teaching content structure, proof points, and close â in Scott's voice, ready for presentation. Designed for Scott's 2-3x per month webinar cadence to financial advisors. Use when Scott needs to build a new webinar, refresh an existing one, or repurpose a boot camp module into a standalone webinar. Always check for an existing webinar on the topic before starting from scratch.
license: proprietary
metadata:
tags:
  - program/ctd
  - client/scott-keffer
---
# Webinar Content Engine

Builds production-ready SKI webinar frameworks from minimal input. Scott gives a topic and a few ideas. The engine gives him a complete outline, opening hook, teaching content, proof structure, and close â ready to present.

## Keywords
webinar content, SKI webinar, advisor webinar, financial advisor training, webinar outline, webinar script, boot camp module, Scott Keffer, direct mail, affiliate marketing, live webinar, 7X advisor, affluent clients

## Quick Start

1. Give Scott's topic and a brief description of the intended audience for this webinar (prospects / current clients / boot camp attendees)
2. Optionally: provide 3-5 bullet points of the key ideas Scott wants to teach
3. Optionally: specify any client proof points or case studies to include
4. Claude produces the full webinar package
5. Review â flag anything that needs Scott's specific language or examples
6. Save to: `SKI-Vault/08_Content/Webinars/[YYYY-MM-DD]-[Topic]-webinar.md`

No scripts required. Works from a topic sentence and rough notes.

## Minimum Requirements Before Starting

Before beginning, verify:

- Webinar topic provided (at least a sentence describing what it's about)
- Audience identified (prospects / existing coaching clients / boot camp registrants)

If no audience is specified, default to: prospects â financial advisors who have heard of SKI but haven't enrolled in a program. This is SKI's primary webinar audience.

Check whether `SKI-Vault/09_PersonalBrandDNA/SKI-Voice-Profile.md` exists. If it does, read it and apply it throughout all outputs. If it does not exist, apply the SKI Voice Guidelines at the bottom of this skill and note: "Voice Profile not found â baseline voice guidelines applied. Run advisor-voice-extractor for a more accurate match."

## Core Workflow

### Step 1 â Establish the Webinar's One Job

Every SKI webinar has one job. Before building any content, state it:

"The one job of this webinar is: [verb] [specific outcome for the financial advisor]."

Examples:
- "The one job of this webinar is to make advisors believe they can double revenue while cutting their client count in half â and then enroll them in the next boot camp."
- "The one job of this webinar is to demonstrate that the advisors who are growing right now all have one thing in common â and that thing is teachable."

If Scott's topic doesn't suggest a single clear job, ask before proceeding: "What's the one thing you want advisors to believe or do differently after this webinar?"

### Step 2 â Build the Webinar Architecture

SKI webinars follow a specific structure tuned for financial advisors:

**Phase 1: The Environment (0-10 min)**
- Why now? What's happening in the financial services industry right now that makes this topic urgent?
- The contrast: Most advisors [doing the wrong thing] vs. the top performers [doing the right thing]
- Scott's credibility: Not a resume recitation â a specific result or observation that establishes he's been in the room with the people who solved this problem

**Phase 2: The Core Teaching (10-45 min)**
- 3-5 key distinctions (not tips â distinctions: the shift in understanding that changes behavior)
- Each distinction follows the structure: [The belief advisors currently hold] â [Why that belief produces the plateau] â [The different way the top advisors think] â [What changes when you adopt this thinking]
- Specific named frameworks if applicable (7X Advisor Model, Affluent Engagement System, etc.)
- Proof woven in, not saved for the end: real client results, real dollar amounts, real situations

**Phase 3: The Bridge (45-55 min)**
- What does an advisor need to actually implement this?
- What's the gap between "knowing this" and "having it working in my practice"?
- What does the boot camp / coaching program / done-for-you system provide that closes that gap?

**Phase 4: The Close (55-75 min)**
- The offer: specific, with clear deliverables and clear outcome
- The urgency: real, not manufactured (limited seats / close date / bonus that expires)
- The decision frame: "The advisors who [took action] / The advisors who [waited]" â what happened to each group

### Step 3 â Produce the Full Webinar Package

#### OUTPUT 1: Webinar Overview (1 page)

```
WEBINAR: [Title]
Date: [TBD or specific date]
Audience: [Prospects / Clients / Boot Camp]
One Job: [stated clearly]
Runtime: [estimated â typically 60-90 min]
Offer: [what is being sold / what is the call to action]
```

#### OUTPUT 2: Opening Hook (5 min section, ~600 words)

The hook does three things in order:
1. Grabs attention with the environment statement (what's happening right now that makes this urgent for advisors)
2. Establishes Scott's right to teach this (one specific, credibility-establishing thing â not a list)
3. States the promise: "By the end of this, you're going to [specific outcome]"

Write the hook fully â not bullets, but the actual words Scott would say. This is the most important part. If the hook doesn't work, advisors disengage.

SKI hook voice: Direct. No warm-up. Lead with the environment or the contrast. Do not open with "Welcome, I'm so excited to have you here." Open with the problem or the opportunity â the thing that made advisors show up.

#### OUTPUT 3: Teaching Content Outline (section headers + bullets)

For each of the 3-5 key distinctions:

**DISTINCTION [N]: [Name â should be memorable, not generic]**

- The wrong belief: [what most advisors currently think]
- Why it produces the plateau: [the mechanism â why this belief leads to the result they don't want]
- The right way to think about it: [the shift]
- What changes: [specific, observable behavior changes when an advisor adopts this thinking]
- Proof: [Client name if usable, or "one advisor we worked with" + specific result]
- Teaching tool: [diagram / list / framework / story â what visual or structural element supports this point]

#### OUTPUT 4: Bridge to Offer (transition section, ~400 words)

This connects the teaching to the close. It should:
- Acknowledge what advisors now understand that they didn't before the webinar
- Identify the gap: what they know vs. what it takes to actually implement
- Position the boot camp / program / system as the implementation path â not the education path (they just got educated for free)
- Transition naturally: "So here's what we put together for advisors who want to stop figuring this out alone..."

Write this fully. The bridge is where most webinar presenters lose money â they teach well and then close awkwardly. This section must feel like a natural continuation, not a gear shift.

#### OUTPUT 5: Close and Offer Presentation (~500 words)

Include:
- Clear offer statement: what exactly is being offered (boot camp / program / system) with dates, location/format, price
- The "what you get" â 5-7 specific deliverables, not vague benefits
- The result promise: what advisors will have or be able to do after completing the program
- Urgency element: specific reason to decide now
- The decision contrast: "Advisors who [enrolled last time / took action] are now [specific result]. Advisors who [waited / stayed comfortable] are still [the plateau]."
- The CTA: single, clear, specific â one URL or one phone number, not multiple options

#### OUTPUT 6: Q&A Preparation (5 most likely questions)

Based on the webinar content, list the 5 questions advisors are most likely to ask â and draft Scott's answers. These are not just content questions â include buying objections that surface as questions ("Is this for someone at my stage?", "How do I know this will work for my specific niche?").

---

## SKI Voice Guidelines (Use When Voice Profile Not Available)

If `SKI-Voice-Profile.md` is not accessible, apply these baseline rules:

1. Lead with the bottom line. Never bury the point.
2. Use specific numbers. Not "more clients" â "double your business with half the clients."
3. Write for veteran advisors, not rookies. Assume the reader has been in the industry 15+ years and is skeptical of generic advice.
4. The contrast structure: "The average advisor does X / The advisors in our program do Y." Use this consistently.
5. No therapy language. No "journey," "explore," "discover your path." Direct and functional.
6. Credibility through specificity: "427 presentations" beats "hundreds of presentations." "Tens of thousands of advisors trained" beats "many advisors."
7. Proof before close. Never close without a specific client result that mirrors what the audience wants.

## Quality Standards

- The hook must be written in full â not bullets. Opening energy is set by the first 3 sentences. Bullets cannot replicate that.
- Every distinction must be a genuine distinction â a shift in understanding, not a tip or tactic.
- The bridge section must be at minimum 300 words. A bridge under 300 words cannot close the gap between teaching and selling without breaking the webinar's flow.
- The offer section must name the specific program with specific deliverables. "You'll learn to grow your practice" is not an offer.

## Constraints

- Never open with a welcome or a thank-you. SKI webinars open with content.
- Never produce a close that uses artificial urgency ("This offer disappears at midnight!" or manufactured scarcity). Every urgency element must be verifiable: real seat limits, real dates, real bonus expiry. If Scott has not provided a real urgency element, ask before inventing one.
- Never produce a generic "5 tips for advisors" outline. Every SKI webinar teaches distinctions â shifts in thinking that change behavior â not tips.
- Never estimate the webinar runtime outside the 60-90 minute range for a full webinar. If the content scope requires less than 60 minutes, flag it: this may be a boot camp module, not a standalone webinar.
- Never produce more than 5 key distinctions in the teaching section. More than 5 distinctions produces an unfocused webinar that advisors cannot act on.
- If Scott has an existing webinar on this topic, request the transcript or outline before producing a new one. The goal is to upgrade and expand what already works, not to start from scratch and drift from the proven structure.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Open with a welcome or thank-you | Open with the environment statement or contrast |
| Produce a "5 tips for advisors" outline | Teach distinctions â shifts in thinking, not tactics |
| Use manufactured urgency or scarcity | Verifiable urgency only (real dates, real seats, real bonuses) |
| Close without proof before the offer | Client result that mirrors audience desire always precedes the close |
| Produce more than 5 distinctions | 5 maximum â more creates an unfocused webinar |
| Start from scratch when an existing webinar exists | Request the transcript and upgrade what works |

## Before You Respond

- [ ] Do I have the webinar topic and audience?
- [ ] Have I stated the One Job clearly?
- [ ] Did I check if an SKI Voice Profile exists?
- [ ] If existing webinar on topic: did I request the transcript first?
- [ ] Does the offer section name specific deliverables (not vague benefits)?
- [ ] Is the bridge section at least 300 words?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)

## Save Location

`SKI-Vault/08_Content/Webinars/[YYYY-MM-DD]-[Topic-Slug]-webinar.md`

For webinars that become templates (topics Scott runs repeatedly), also save to:
`SKI-Vault/11_Templates/[Topic-Slug]-webinar-template.md`
