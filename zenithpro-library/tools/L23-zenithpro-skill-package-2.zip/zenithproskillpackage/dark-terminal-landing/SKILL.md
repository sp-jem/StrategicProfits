---
name: dark-terminal-landing
description: Creates premium dark-mode pages with terminal/hacker aesthetic. Two layouts available â (1) Landing Page with terminal window hero, scroll-triggered animations, conversion-optimized sections, and (2) Docs/Playbook with fixed sidebar nav, scroll spy, progress bar, platform toggle tabs. Both share the same design DNA â Syne + JetBrains Mono fonts, dark #050505 backgrounds, neon green/gold accents, scan-line overlays. Use when building sales pages, product pages, documentation, playbooks, or guides with a technical/premium feel.
---

# Dark Terminal Page Builder

Creates self-contained HTML pages with a premium dark terminal aesthetic. Two layout options available. Every page is a complete, standalone HTML file with all CSS inline â no external dependencies except Google Fonts.

## TWO LAYOUTS

### Layout 1: Landing Page (Single-Scroll Sales Page)
Best for: Product pages, sales pages, skill showcases, conversion pages.
Features: Terminal window hero with typing animation, scroll-triggered section reveals, hello bar, testimonial walls, code comparisons, skill cards, proof stats, CTA blocks.

### Layout 2: Docs/Playbook (Sidebar + Content)
Best for: Documentation, playbooks, guides, tutorials, long-form reference pages.
Features: Fixed 280px sidebar with navigation, scroll spy, progress bar, platform toggle tabs, tip/warning boxes, output showcase boxes, section anchors.

## DESIGN SYSTEM REFERENCE

### For Landing Pages:
- `references/design-system.css` â Full CSS with variables, components, animations, responsive breakpoints
- `references/component-library.md` â HTML patterns for every component with usage notes
- `references/page-architecture.md` â Section ordering, content strategy, conversion flow

### For Docs/Playbook Pages:
- `references/docs-layout.css` â Full CSS for sidebar layout, navigation, docs-specific components
- `references/docs-components.md` â HTML patterns for sidebar, cards, tips, output boxes, tables, scripts

**Read the relevant reference files for the chosen layout before generating any page.**

## WHAT THIS SKILL PRODUCES

A single `.html` file containing:
1. Complete `<head>` with meta tags, OG tags, Google Fonts import
2. Inline `<style>` block with the full design system
3. Semantic HTML body with all sections
4. Inline `<script>` for scroll-triggered animations
5. Fully responsive (mobile-first breakpoints at 400px, 600px, 700px, 768px, 900px)

## GENERATION PROCESS

### Step 1: Gather Requirements
Ask the user for:
- **Product/service name** â what's being sold
- **Price point** â for the price block display
- **Key features** (3-8) â for skill cards
- **Target audience** â for qualification section
- **Testimonials** (if available) â for social proof
- **CTA destination** â where the button links
- **Optional: Creative assets** â images for creative grid

If the user provides a brief or existing copy, extract these elements from it.

### Step 2: Map Content to Sections
Using the page architecture from `references/page-architecture.md`, map the user's content to the standard section flow:

1. Hello Bar (optional announcement)
2. Terminal Window Hero (product intro + price + CTA)
3. Problem Section (what's broken)
4. Social Proof Wall (testimonials)
5. How It Works (code comparison blocks)
6. Platform/Compatibility (where it works)
7. Features/Skills Breakdown (numbered skill cards)
8. Creative Showcase (optional, if visual product)
9. Featured Testimonial Hero
10. Trust/Proof Stats
11. Clarification (is/isn't lists)
12. Qualification (for/not-for lists)
13. Final CTA Block
14. Footer

**Not all sections are required.** Minimum viable page: Hero + Problem + Features + CTA.

### Step 3: Generate the HTML
Build the complete page following these rules:

**Typography:**
- Display: Syne (400-800 weight) for headings
- Mono: JetBrains Mono (400-600 weight) for code, numbers, labels
- Never mix â headings are always Syne, technical elements always JetBrains Mono

**Color discipline:**
- Background: #050505 primary, #0a0a0a secondary, #111111 tertiary
- Text: #f5f5f5 primary, #999999 secondary, #555555 muted
- Accent green (#00ff88): terminal elements, positive indicators, badges
- Accent gold (#ffd60a): price, CTAs, highlights, hover states, featured items
- Red (#ff5f57): negative indicators only (the "bad" side of comparisons)

**Animation rules:**
- Terminal typing animation plays on page load (1.5s)
- Hero elements stagger-fade (2.0s, 2.1s, 2.2s, 2.3s, 2.4s delays)
- All sections below the fold use scroll-triggered fade-up (IntersectionObserver)
- Card hovers: translateY(-2px to -4px) + border color change + box-shadow
- Skill cards hover: translateX(4px) + gold left border shadow
- CTA button: shimmer effect on hover + translateY(-2px)

**Overlay effects:**
- Noise SVG texture at 3% opacity (fixed, full-screen)
- Scan lines at 40% opacity (fixed, full-screen)
- Both use pointer-events: none

### Step 4: Validate
Before delivering, verify:
- [ ] All CSS variables defined in `:root` / `.skills-page`
- [ ] Google Fonts import for Syne + JetBrains Mono
- [ ] Noise + scan-line overlays present
- [ ] Terminal window has dots (red/yellow/green), title, typing animation
- [ ] All sections have scroll-triggered `.visible` class
- [ ] IntersectionObserver script at bottom of page
- [ ] Responsive breakpoints for all grid components
- [ ] CTA buttons have shimmer + hover effects
- [ ] No external CSS or JS dependencies
- [ ] Page works when opened directly in browser (file://)

## CUSTOMIZATION OPTIONS

The user can request modifications to the base aesthetic:

| Customization | How to Apply |
|--------------|-------------|
| Different accent color | Replace `--accent-gold` values |
| No terminal hero | Start with standard hero section |
| Wider layout | Change max-width from 880px |
| Light mode variant | Invert the color palette (rare) |
| Multiple CTA colors | Use green for primary, gold for secondary |
| Video embed | Add responsive iframe in hero or showcase |
| Accordion FAQ | Add collapsible sections with JS toggle |

## OUTPUT LOCATION

Save generated pages to the user's specified location, or default to:
`YOUR-OBSIDIAN-VAULT/00 Projects/[Project Name]/[page-name].html`

## EXAMPLE INVOCATIONS

- "Build me a dark terminal landing page for my new AI course"
- "Create a skills showcase page like the Vibe Marketer"
- "Make a product page for Force Multiplier with the terminal aesthetic"
- "/dark-terminal-landing for ZenithPro"
