# Component Library — Dark Terminal Landing Pages

Every HTML pattern needed to build a page. Copy these structures and fill in content.

---

## 1. Page Wrapper

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PAGE_TITLE</title>
  <meta name="description" content="PAGE_DESCRIPTION">

  <!-- OG Tags -->
  <meta property="og:title" content="PAGE_TITLE">
  <meta property="og:description" content="PAGE_DESCRIPTION">
  <meta property="og:type" content="website">
  <meta property="og:url" content="PAGE_URL">

  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="PAGE_TITLE">
  <meta name="twitter:description" content="PAGE_DESCRIPTION">

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">

  <style>
    /* PASTE COMPLETE design-system.css HERE */
  </style>
</head>
<body>
  <div class="skills-page">
    <!-- ALL SECTIONS GO HERE -->

    <script>
      /* PASTE scroll-observer.js HERE */
    </script>
  </div>
</body>
</html>
```

---

## 2. Hello Bar

```html
<div class="hello-bar">
  <span class="hello-bar-icon">EMOJI_HERE</span>
  <span class="hello-bar-text">ANNOUNCEMENT_TEXT <span class="hello-bar-highlight">HIGHLIGHTED_WORD</span></span>
</div>
```

**Usage:** Optional top-of-page announcement. Gold-to-green gradient background.

---

## 3. Terminal Window (Hero)

```html
<div class="skills-container">
  <div class="terminal-window">
    <div class="terminal-header">
      <div class="terminal-dots">
        <span class="terminal-dot red"></span>
        <span class="terminal-dot yellow"></span>
        <span class="terminal-dot green"></span>
      </div>
      <span class="terminal-title">WINDOW_TITLE — e.g. "product-name ~ skills"</span>
    </div>
    <div class="terminal-body">

      <!-- Command line with typing animation -->
      <div class="command-line">
        <span class="prompt">$</span>
        <span class="typed-text">COMMAND_TEXT — e.g. "install vibe-skills --unlock-all"</span>
        <span class="cursor"></span>
      </div>

      <!-- Badge -->
      <div class="skills-badge">
        BADGE_ICON BADGE_TEXT — e.g. "20+ PROFESSIONAL AI SKILLS"
      </div>

      <!-- Main headline -->
      <h1>HEADLINE_PART_1<br><span class="highlight">HIGHLIGHTED_PART</span></h1>

      <!-- Subhead -->
      <p class="subhead">SUBHEADLINE_TEXT</p>

      <!-- Price block -->
      <div class="price-block">
        <span class="price">$PRICE</span>
        <span class="price-meta">PRICE_CONTEXT — e.g. "ONE-TIME // LIFETIME ACCESS"</span>
      </div>

      <!-- CTA Button -->
      <a href="CTA_URL" class="cta-primary">
        CTA_TEXT
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <path d="M5 12h14M12 5l7 7-7 7"/>
        </svg>
      </a>

      <!-- Subtext -->
      <p class="cta-subtext">SUBTEXT — e.g. "instant access // no subscription"</p>

    </div>
  </div>
</div>
```

**Usage:** Always the first major section. The typing animation auto-plays on load.

---

## 4. Section Block (Generic Pattern)

```html
<div class="skills-section-block">
  <div class="skills-container">
    <div class="section-number">// 01 — SECTION_LABEL</div>
    <h2>SECTION_HEADLINE</h2>
    <p>SECTION_BODY_TEXT</p>

    <!-- Section-specific content goes here -->

  </div>
</div>
```

**Usage:** Every below-fold section uses this wrapper. The `skills-section-block` class triggers scroll-fade animation via IntersectionObserver.

---

## 5. Code Comparison (Before/After)

```html
<div class="code-compare">
  <!-- Negative (Before) -->
  <div class="code-block negative">
    <div class="code-header">
      NEGATIVE_LABEL — e.g. "// without-skills.txt"
    </div>
    <div class="code-content">
      LINE_1<br>
      LINE_2<br>
      LINE_3
      <div class="result">NEGATIVE_RESULT — e.g. "→ output: mediocre"</div>
    </div>
  </div>

  <!-- Positive (After) -->
  <div class="code-block positive">
    <div class="code-header">
      POSITIVE_LABEL — e.g. "// with-skills.txt"
    </div>
    <div class="code-content">
      LINE_1<br>
      LINE_2<br>
      LINE_3
      <div class="result">POSITIVE_RESULT — e.g. "→ output: professional"</div>
    </div>
  </div>
</div>
```

**Usage:** Side-by-side comparison. Red border = negative, green border = positive. Stacks on mobile.

---

## 6. Platform Grid

```html
<div class="platforms-section">
  <div class="platforms-grid">
    <div class="platform-card">
      <div class="platform-icon">EMOJI</div>
      <h4>PLATFORM_NAME</h4>
      <p>PLATFORM_DETAIL</p>
    </div>
    <!-- Repeat for each platform (ideally 4) -->
  </div>
  <p class="platforms-note">NOTE_TEXT</p>
</div>
```

**Usage:** 4-column grid showing compatibility, tools, or categories. Green hover border.

---

## 7. Skill Cards (Numbered Feature List)

```html
<div class="skills-grid">

  <!-- Optional layer label -->
  <div class="layer-label">LAYER_NAME — e.g. "Foundation Layer"</div>

  <div class="skill-card">
    <div class="skill-number">01</div>
    <div>
      <div class="skill-name">FEATURE_NAME</div>
      <p class="skill-desc">FEATURE_DESCRIPTION</p>
    </div>
  </div>

  <!-- Repeat for each feature -->

  <!-- Optional: another layer label for grouped features -->
  <div class="layer-label">LAYER_NAME_2</div>

  <div class="skill-card">
    <div class="skill-number">05</div>
    <div>
      <div class="skill-name">FEATURE_NAME</div>
      <p class="skill-desc">FEATURE_DESCRIPTION</p>
    </div>
  </div>

</div>
```

**Usage:** Numbered list of features/skills. Gold hover with left-slide effect. Layer labels optional for grouping.

---

## 8. Creative Showcase Grid

```html
<div class="creative-pack-section skills-section-block">
  <div class="skills-container">
    <div class="section-number">// SECTION_NUMBER — LABEL</div>
    <h2>SECTION_HEADLINE</h2>
    <p>SECTION_DESCRIPTION</p>

    <div class="creative-showcase">
      <div class="creative-grid">
        <div class="creative-card">
          <img src="IMAGE_URL" alt="ALT_TEXT">
          <div class="creative-label">LABEL</div>
        </div>
        <!-- Repeat (ideally 4 or 8) -->
      </div>
    </div>

    <!-- Optional: skills list within creative section -->
    <div class="creative-skills-list">
      <div class="creative-skill-item">
        <span class="creative-skill-num">01</span>
        SKILL_NAME
      </div>
      <!-- Repeat -->
    </div>

  </div>
</div>
```

**Usage:** Visual product showcase. Square images in 4-col grid. The outer section has a subtle gradient background and gold border.

---

## 9. Testimonial Wall

```html
<div class="testimonials-section skills-section-block">
  <div class="skills-container">
    <div class="testimonials-header">
      <h2>HEADER_TEXT</h2>
      <p>SUBHEADER_TEXT</p>
    </div>

    <div class="testimonials-wall">
      <!-- Standard card -->
      <div class="testimonial-card">
        <div class="testimonial-text">"TESTIMONIAL_QUOTE"</div>
        <div class="testimonial-meta">
          <span class="testimonial-author">AUTHOR_NAME</span>
          <span class="testimonial-source x-source">SOURCE — e.g. "via X"</span>
        </div>
      </div>

      <!-- Featured card (gold accent) -->
      <div class="testimonial-card featured">
        <div class="testimonial-text">"FEATURED_QUOTE"</div>
        <div class="testimonial-meta">
          <span class="testimonial-author">AUTHOR_NAME</span>
          <span class="testimonial-source community-source">SOURCE</span>
        </div>
      </div>

      <!-- Repeat (ideally 6-9 for 3-col grid) -->
    </div>
  </div>
</div>
```

**Source classes:** `.x-source` (gray) for Twitter/X, `.community-source` (green) for community/direct.

---

## 10. Featured Testimonial Hero

```html
<div class="testimonial-hero">
  <div class="testimonial-hero-text">"BIG_QUOTE_TEXT"</div>
  <p class="testimonial-hero-subtext">CONTEXT_TEXT</p>
  <div class="testimonial-hero-author">
    <span class="testimonial-hero-name">AUTHOR_NAME</span>
    <span class="testimonial-hero-handle">@HANDLE</span>
    <span class="testimonial-hero-badge">BADGE — e.g. "50k+ followers"</span>
  </div>
</div>
```

**Usage:** Single featured testimonial with gold gradient background and radial glow.

---

## 11. Proof/Stats Card

```html
<div class="proof-card">
  <div class="proof-stat">STAT — e.g. "10,847"</div>
  <p class="proof-label">STAT_DESCRIPTION — e.g. "users have installed these skills"</p>
</div>
```

**Usage:** Big gold number with glow effect. Use for social proof metrics.

---

## 12. Check List (Positive)

```html
<ul class="check-list">
  <li>POSITIVE_ITEM_1</li>
  <li>POSITIVE_ITEM_2</li>
  <li>POSITIVE_ITEM_3</li>
</ul>
```

**Usage:** Green checkmark icons. Use for "This IS..." or "This is FOR you if..." sections.

---

## 13. X List (Negative)

```html
<ul class="x-list">
  <li>NEGATIVE_ITEM_1</li>
  <li>NEGATIVE_ITEM_2</li>
  <li>NEGATIVE_ITEM_3</li>
</ul>
```

**Usage:** Red X icons. Use for "This is NOT..." or "This is NOT for you if..." sections.

---

## 14. Emphasis Block Quote

```html
<p class="emphasis-text">QUOTE_OR_KEY_INSIGHT</p>
```

**Usage:** Gold left-border pull quote. Use for key insights between sections.

---

## 15. Final CTA Block

```html
<div class="final-cta skills-section-block">
  <div class="skills-container">
    <h2>CLOSING_HEADLINE</h2>
    <p class="roi-line">VALUE_PROPOSITION_TEXT</p>

    <div class="price-block">
      <span class="price">$PRICE</span>
      <span class="price-meta">PRICE_CONTEXT</span>
    </div>

    <a href="CTA_URL" class="cta-primary">
      CTA_TEXT
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <path d="M5 12h14M12 5l7 7-7 7"/>
      </svg>
    </a>

    <p class="install-hint">REASSURANCE_TEXT — e.g. "instant access // cancel anytime"</p>
  </div>
</div>
```

---

## 16. Footer

```html
<footer class="skills-footer">
  <div class="skills-container">
    <p>FOOTER_TEXT — e.g. "&copy; 2026 Brand Name. All rights reserved."</p>
    <p class="built-note">CREDIT_TEXT — e.g. "Built with care."</p>
  </div>
</footer>
```

---

## 17. Scroll Animation Script

Place this at the bottom of the page, before closing `</div>` of `.skills-page`:

```html
<script>
  // Scroll-triggered section reveal
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });

  document.querySelectorAll('.skills-section-block').forEach(block => {
    observer.observe(block);
  });
</script>
```

**This script is required.** Without it, all sections below the fold remain invisible.

---

## 18. Mini Testimonials (2-col)

```html
<div class="testimonials-mini">
  <div class="testimonial-mini">
    "SHORT_QUOTE"
    <div class="testimonial-mini-author">— AUTHOR_NAME</div>
  </div>
  <div class="testimonial-mini">
    "SHORT_QUOTE"
    <div class="testimonial-mini-author">— AUTHOR_NAME</div>
  </div>
</div>
```

**Usage:** Smaller 2-column testimonial grid for supplementary social proof within sections.
