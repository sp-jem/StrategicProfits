# Page Architecture — Dark Terminal Landing Pages

## Section Flow & Conversion Logic

The page follows a deliberate psychological sequence. Each section builds on the previous one to move the visitor from curiosity to purchase.

---

## STANDARD SECTION ORDER

```
1. Hello Bar          → Create urgency/context
2. Terminal Hero      → Hook + Price + Primary CTA
3. Problem (01)       → Agitate the pain
4. Social Proof Wall  → Interrupt skepticism early
5. How It Works (02)  → Before/after code comparison
6. Platform Grid      → Remove "will this work for me?" objection
7. Features (03)      → Numbered skill/feature cards
8. Creative Showcase  → Visual proof (if applicable)
9. Testimonial Hero   → Single powerful endorsement
10. Trust Stats (04)  → Big number social proof
11. Clarification (05)→ Is/Isn't lists to set expectations
12. Qualification (06)→ For you / Not for you
13. Final CTA         → Price + Button + Reassurance
14. Footer            → Copyright
```

---

## SECTION DETAILS

### 1. Hello Bar
**Purpose:** Immediate context. Usually announces a sale, new release, or scarcity.
**Content:** One line. Icon + text + highlighted keyword.
**When to skip:** If there's no time-sensitive announcement.

### 2. Terminal Window Hero
**Purpose:** This is the entire above-fold experience. Must communicate:
- What this is (badge)
- Why it matters (headline)
- What it costs (price block)
- What to do next (CTA button)

**Command line:** Use a terminal-style command relevant to the product. Examples:
- `install product-name --premium`
- `deploy ai-skills --all`
- `activate force-multiplier --lifetime`

**Headline formula:** Short first line + `<br>` + gold highlighted second line.
Keep to 6-10 words total. The highlight should be the transformation/outcome.

**Subhead:** 1-2 sentences expanding the headline. Max 480px width.

**Price:** Big mono number with glow. Add context like "ONE-TIME" or "LIFETIME ACCESS."

**CTA:** Uppercase, action verb. "GET INSTANT ACCESS" / "UNLOCK NOW" / "START BUILDING"

### 3. Problem Section
**Purpose:** Name the pain the visitor is experiencing.
**Section number:** `// 01`
**Structure:**
- 2-3 paragraphs describing the problem
- Optional: emphasis-text pull quote
- End with transition to solution

**Voice:** Empathetic but direct. "You're not bad at this. The tools are."

### 4. Social Proof Wall
**Purpose:** Break skepticism before going deeper into features.
**Placement:** Early — before the feature breakdown. This is counterintuitive but effective.
**Layout:** 3-column grid of testimonial cards. Include 1-2 `featured` cards.
**Count:** 6-9 testimonials. Odd numbers feel more organic.

### 5. How It Works (Code Comparison)
**Purpose:** Show the transformation in concrete terms.
**Section number:** `// 02`
**Format:** Side-by-side code blocks — red (without) vs green (with).
**Content:** Make the "before" painful and specific. Make the "after" clean and impressive.
**Result lines:** End each block with a `result` showing the outcome.

### 6. Platform Grid
**Purpose:** Answer "does this work with my setup?"
**Layout:** 4 cards with emoji icons, name, and detail.
**Examples:** Different tools, platforms, AI models, or use cases.
**Green hover:** Signals compatibility/approval.

### 7. Features / Skills Breakdown
**Purpose:** The meat. Every feature, numbered and described.
**Section number:** `// 03`
**Structure:** Use `layer-label` dividers to group features into categories.
**Cards:** Each skill card has a number (01-XX), name, and 1-line description.
**Hover effect:** Gold left-border slide — gives a sense of selection/activation.

### 8. Creative Showcase
**Purpose:** Visual proof for visual products. Show the output quality.
**Layout:** 4-column image grid with labels. Square aspect ratio.
**When to skip:** If the product isn't visual.
**Special treatment:** This section gets a gradient background and gold border to feel premium.

### 9. Testimonial Hero
**Purpose:** One powerful, specific endorsement that carries authority.
**Placement:** After features, before stats. Acts as a transition.
**Include:** Name, handle/title, badge (follower count, company, credential).

### 10. Trust Stats
**Purpose:** Big, glowing number that makes the product feel established.
**Section number:** `// 04`
**Format:** Single `proof-card` with massive stat + description.
**Examples:** "10,847 installs" / "$2.4M generated" / "500+ students"

### 11. Clarification (Is/Isn't)
**Purpose:** Manage expectations. Prevent refunds. Filter wrong buyers.
**Section number:** `// 05`
**Structure:**
- `check-list` for what it IS
- `x-list` for what it ISN'T
**Keep balanced:** 4-6 items in each list.

### 12. Qualification (For/Not For)
**Purpose:** Final filter. Make the right buyer feel chosen.
**Section number:** `// 06`
**Structure:**
- "This is for you if..." → `check-list`
- "This is NOT for you if..." → `x-list`
**Tone:** Direct. No hedging. The "not for" list should make the wrong buyer self-select out.

### 13. Final CTA
**Purpose:** Last conversion point. Centered, clean, decisive.
**Include:**
- Compelling headline (not just "buy now")
- ROI line framing the value
- Price block (repeat from hero)
- CTA button (same as hero)
- Install hint / reassurance text
**Radial glow:** The background has a subtle gold radial gradient for warmth.

### 14. Footer
**Purpose:** Legal minimum. Copyright, optional links.
**Keep minimal.** This page is about one action — don't add navigation.

---

## MINIMUM VIABLE PAGE

Not every section is needed. Minimum:
1. Terminal Hero (with price + CTA)
2. Problem Section
3. Features (skill cards)
4. Final CTA

This gives you: hook → pain → solution → action.

---

## CONTENT TONE GUIDELINES

| Element | Voice |
|---------|-------|
| Headlines | Bold, compressed, no filler words |
| Subheads | Conversational, slightly technical |
| Body text | Clear, direct, benefit-focused |
| Code blocks | Literal or pseudo-code style |
| Badge text | ALL CAPS MONO, feels like a system message |
| CTA text | Action verb, uppercase |
| Section numbers | `// 01 — LABEL` format, feels like code comments |
| Price | Just the number, no dollar signs in surrounding text |

---

## ANIMATION TIMING

| Element | Delay | Duration | Effect |
|---------|-------|----------|--------|
| Terminal window | 0s | 0.8s | Fade up + scale |
| Typing text | 0.3s | 1.5s | Character reveal |
| Badge | 1.8s | 0.5s | Fade up |
| Headline | 2.0s | 0.6s | Fade up |
| Subhead | 2.1s | 0.6s | Fade up |
| Price | 2.2s | 0.6s | Fade up |
| CTA button | 2.3s | 0.6s | Fade up |
| CTA subtext | 2.4s | 0.6s | Fade up |
| Below-fold sections | On scroll | 0.8s | Fade up (40px) |

The hero sequence creates a "boot-up" feeling — the terminal loads, the command types, then content appears in sequence. This is core to the aesthetic and should not be shortened or removed.

---

## RESPONSIVE BEHAVIOR SUMMARY

| Breakpoint | Changes |
|------------|---------|
| Desktop (>900px) | Full layout, all grids at max columns |
| Tablet (768-900px) | Testimonials → 2 col, platforms → 2 col |
| Mobile (600-768px) | Terminal padding reduces |
| Small (400-600px) | Code compare → 1 col, creative → 2 col, testimonials → 1 col |
| Tiny (<400px) | Platform grid → 2 col tight |

The page is mobile-first in feel but desktop-first in CSS. All breakpoints use max-width media queries.
