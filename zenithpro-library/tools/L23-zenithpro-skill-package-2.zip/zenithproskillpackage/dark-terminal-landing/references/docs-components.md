# Docs/Playbook Component Library — Dark Terminal Design System

This layout is for documentation, playbooks, guides, and long-form content pages with sidebar navigation. Same design DNA as the landing page, different structure.

---

## 1. Page Wrapper

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PAGE_TITLE</title>
  <meta name="description" content="PAGE_DESCRIPTION">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    /* PASTE COMPLETE docs-layout.css HERE */
  </style>
</head>
<body>
  <!-- Mobile nav toggle (hidden on desktop) -->
  <button class="mobile-nav-toggle" onclick="document.querySelector('.sidebar').classList.toggle('open')">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M3 12h18M3 6h18M3 18h18"/>
    </svg>
  </button>

  <!-- Progress bar -->
  <div class="progress-bar">
    <div class="progress-bar-fill" id="progressFill"></div>
  </div>

  <div class="layout">
    <aside class="sidebar">
      <!-- Sidebar content -->
    </aside>
    <main class="main">
      <div class="content">
        <!-- Page content -->
      </div>
    </main>
  </div>

  <script>
    /* PASTE scripts HERE (progress bar, scroll spy, platform toggle) */
  </script>
</body>
</html>
```

---

## 2. Sidebar Structure

```html
<aside class="sidebar">
  <!-- Header with logo -->
  <div class="sidebar-header">
    <a href="#" class="sidebar-logo">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
      </svg>
      BRAND_NAME
    </a>

    <!-- Optional: Platform toggle -->
    <div class="platform-toggle">
      <button class="platform-btn active" data-platform="platform1">PLATFORM_1</button>
      <button class="platform-btn" data-platform="platform2">PLATFORM_2</button>
      <button class="platform-btn" data-platform="platform3">PLATFORM_3</button>
    </div>
  </div>

  <!-- Navigation -->
  <nav class="sidebar-nav">
    <div class="nav-section">
      <div class="nav-section-title">SECTION_GROUP_NAME</div>
      <a href="#section-id" class="nav-link active">Section Name</a>
      <a href="#sub-section-id" class="nav-link nav-link-sub">Sub Section</a>
      <a href="#another-section" class="nav-link">Another Section</a>
    </div>

    <div class="nav-section">
      <div class="nav-section-title">ANOTHER_GROUP</div>
      <a href="#section-3" class="nav-link">Section Three</a>
      <a href="#section-4" class="nav-link">Section Four</a>
    </div>
  </nav>

  <!-- Footer with CTA -->
  <div class="sidebar-footer">
    <a href="CTA_URL" class="sidebar-cta">CTA_TEXT</a>
  </div>
</aside>
```

---

## 3. Content Section with Anchor

```html
<h2 id="section-id" class="section-anchor">Section Headline</h2>
<p>Section body text goes here.</p>
```

**Key:** The `id` must match the sidebar `href`. The `section-anchor` class provides scroll-margin-top offset.

---

## 4. Subsection (H3)

```html
<h3 id="sub-section-id" class="section-anchor">Subsection Name</h3>
<p>Subsection content.</p>
```

**H3 headings render in green** (`--accent-green`) by default.

---

## 5. Lead Paragraph

```html
<p class="lead">This is a larger, white-text paragraph used for key introductory statements.</p>
```

---

## 6. Card with Icon Header

```html
<div class="card">
  <div class="card-header">
    <div class="card-icon">ICON_TEXT</div>
    <h4>Card Title</h4>
  </div>
  <p>Card content text here.</p>
</div>
```

**Icon text:** Use a single emoji, number, or 1-2 letter abbreviation.

---

## 7. Positive/Negative Cards

```html
<!-- Positive (green) -->
<div class="card positive">
  <h4>What This Does Right</h4>
  <p>Description of the positive aspect.</p>
</div>

<!-- Negative (red) -->
<div class="card negative">
  <h4>Common Mistake</h4>
  <p>Description of what goes wrong.</p>
</div>
```

---

## 8. Skill/Feature Cards in Grid

```html
<div class="grid-2">
  <div class="skill-card">
    <div class="skill-type">CATEGORY</div>
    <div class="skill-name">Feature Name</div>
    <p class="skill-desc">Brief description of what this feature does.</p>
  </div>
  <div class="skill-card">
    <div class="skill-type">CATEGORY</div>
    <div class="skill-name">Feature Name</div>
    <p class="skill-desc">Brief description of what this feature does.</p>
  </div>
</div>
```

---

## 9. Tip Box (Green)

```html
<div class="tip">
  <div class="tip-title">PRO TIP</div>
  <p>Helpful advice or best practice.</p>
</div>
```

---

## 10. Warning Box (Gold)

```html
<div class="warning">
  <div class="warning-title">IMPORTANT</div>
  <p>Critical information or caveat.</p>
</div>
```

---

## 11. Output Box (Showcase)

```html
<div class="output-box">
  <h4>OUTPUT_LABEL — e.g. "EXAMPLE OUTPUT"</h4>
  <p>The actual output content, examples, or results.</p>
</div>
```

**Usage:** Show example AI outputs, code results, or deliverables. Green left border with subtle gradient.

---

## 12. Blockquote

```html
<blockquote>
  <p>A key insight or important quote that should stand out from the surrounding text.</p>
</blockquote>
```

**Gold left border**, card background, italic text.

---

## 13. Code Block

```html
<pre><code>
// Example code or configuration
const config = {
  theme: "dark",
  accent: "#00ff88"
};
</code></pre>
```

---

## 14. Inline Code

```html
<p>Use the <code>--accent-green</code> variable for highlights.</p>
```

**Green text** with green-dim background.

---

## 15. Comparison Grid

```html
<div class="compare-grid">
  <div class="card positive">
    <h4>Do This</h4>
    <p>The right approach.</p>
  </div>
  <div class="card negative">
    <h4>Not This</h4>
    <p>The wrong approach.</p>
  </div>
</div>
```

---

## 16. Table

```html
<table>
  <thead>
    <tr>
      <th>Column 1</th>
      <th>Column 2</th>
      <th>Column 3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Value 1</td>
      <td>Value 2</td>
      <td>Value 3</td>
    </tr>
  </tbody>
</table>
```

**Headers:** Mono font, uppercase, muted color, card background.

---

## 17. Platform-Toggled Content

```html
<!-- Content that only shows for a specific platform -->
<div class="platform-content active" data-platform="platform1">
  <p>This content shows when Platform 1 tab is active.</p>
</div>
<div class="platform-content" data-platform="platform2">
  <p>This content shows when Platform 2 tab is active.</p>
</div>
```

---

## 18. Required Scripts

### Progress Bar

```html
<script>
  // Progress bar
  window.addEventListener('scroll', () => {
    const fill = document.getElementById('progressFill');
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress = (scrollTop / docHeight) * 100;
    fill.style.width = progress + '%';
  });
</script>
```

### Scroll Spy (Active Nav Highlighting)

```html
<script>
  // Scroll spy for sidebar nav
  const sections = document.querySelectorAll('.section-anchor');
  const navLinks = document.querySelectorAll('.nav-link');

  const scrollSpy = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        navLinks.forEach(link => link.classList.remove('active'));
        const activeLink = document.querySelector(`.nav-link[href="#${entry.target.id}"]`);
        if (activeLink) activeLink.classList.add('active');
      }
    });
  }, {
    threshold: 0,
    rootMargin: '-20% 0px -70% 0px'
  });

  sections.forEach(section => scrollSpy.observe(section));
</script>
```

### Platform Toggle

```html
<script>
  // Platform content toggle
  document.querySelectorAll('.platform-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const platform = btn.dataset.platform;

      // Update buttons
      document.querySelectorAll('.platform-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      // Update content
      document.querySelectorAll('.platform-content').forEach(c => c.classList.remove('active'));
      document.querySelectorAll(`.platform-content[data-platform="${platform}"]`).forEach(c => c.classList.add('active'));
    });
  });
</script>
```

### Mobile Sidebar Close on Link Click

```html
<script>
  // Close mobile sidebar on nav link click
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
      document.querySelector('.sidebar').classList.remove('open');
    });
  });
</script>
```
