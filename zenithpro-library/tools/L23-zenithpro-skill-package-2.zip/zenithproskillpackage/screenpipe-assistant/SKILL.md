---
name: screenpipe-assistant
description: Screenpipe intelligence skill — manual invocation only via /screenpipe-assistant. Do NOT auto-trigger. Explicit slash command required.
invocation: explicit
---

# Screenpipe Assistant

On-demand intelligence from Rich's Screenpipe recordings. Three modes: meeting extraction, activity summary, and action item scanning.

## When to Use

- **Meetings**: After a call, extract the full transcript from Screenpipe audio
- **Activity**: "What did I work on today/yesterday/this morning?"
- **Actions**: "What did I commit to doing?" / "Find my action items"
- **Daily Briefing**: The collector script (`collect-screenpipe.py`) runs automatically as part of `/daily-briefing`. This skill is for ad-hoc queries.

## Usage

```
/screenpipe-assistant                           # Activity summary for today
/screenpipe-assistant meetings                  # Extract today's meeting transcripts
/screenpipe-assistant meetings yesterday        # Yesterday's meetings
/screenpipe-assistant activity this morning     # What did I work on this morning
/screenpipe-assistant activity Feb 12           # Specific date
/screenpipe-assistant actions                   # Scan for action items today
/screenpipe-assistant actions this week         # Scan the whole week
```

## Prerequisites

- Screenpipe running locally (check: `curl localhost:3030/health`)
- Screenpipe MCP server configured in `~/.claude/.mcp.json`
- MCP tools available: `search-content`, `search-ui-events`, `get-ui-event-stats`, `export-video`

## Execution: Mode 1 — Meeting Transcripts

### When user says "meetings" or asks about calls/meetings

1. **Parse the time range** from the user's request. Default: today.

2. **Find meeting app activity** via OCR:
   ```
   search-content with content_type=ocr, app_name for each of:
   - "zoom.us"
   - "Microsoft Teams"
   - "Google Meet"
   - "Webex"
   ```

3. **Find audio transcriptions** in the same time range:
   ```
   search-content with content_type=audio
   ```

4. **Cross-reference**: Match audio segments to time windows where meeting apps were on screen.

5. **For each detected meeting, extract:**
   - Start/end time (from first/last meeting app OCR frame)
   - App used (Zoom, Teams, etc.)
   - Window title (often contains meeting name/participants)
   - Full audio transcript (all audio segments during meeting window)
   - Key participants (from audio speaker identification if available)

6. **Clean and format** the transcript:
   - Remove duplicate/overlapping audio segments
   - Group by speaker when speaker_id is available
   - Add timestamps every few minutes for navigation
   - Identify who was speaking based on context

7. **Write to Obsidian**:
   ```
   YOUR-OBSIDIAN-VAULT/01 Strategic Profits/Meetings/Screenpipe/{YYYY-MM-DD} - {Meeting Name}.md
   ```

   Format:
   ```markdown
   # {Meeting Name}

   **Date:** {YYYY-MM-DD}
   **Time:** {start} - {end} ET
   **Duration:** {X} minutes
   **App:** {Zoom/Teams/etc.}
   **Source:** Screenpipe (auto-extracted)

   ## Transcript

   **{HH:MM}** {Speaker if known}: {text}

   **{HH:MM}** {Speaker if known}: {text}

   ...

   ## Key Points
   - {extracted key points}

   ## Action Items
   - {any commitments or todos mentioned}
   ```

8. **Report** what was extracted and where it was saved.

---

## Execution: Mode 2 — Activity Summary

### When user says "activity", "what did I work on", or no mode specified

1. **Parse the time range**. Default: today so far.
   - "today" / no arg → today 00:00 to now
   - "yesterday" → yesterday full day
   - "this morning" → today 00:00 to 12:00
   - "this afternoon" → today 12:00 to now
   - "Feb 12" / specific date → that full day

2. **Collect all three data types in parallel** (use MCP tools):

   a. **Screen activity** (OCR):
      ```
      search-content: content_type=ocr, limit=200
      ```

   b. **Audio transcriptions**:
      ```
      search-content: content_type=audio, limit=100
      ```

   c. **App usage stats**:
      ```
      get-ui-event-stats: with start_time/end_time
      ```

   d. **App switches** (for workflow patterns):
      ```
      search-ui-events: event_type=app_switch, limit=100
      ```

3. **Synthesize into activity blocks**:
   - Group by 30-minute windows
   - For each window: primary app, what was visible (OCR text summary), any audio
   - Identify the dominant activity per block:
     - **Coding** (Claude Terminal, VS Code, Terminal)
     - **Writing** (Obsidian, Google Docs, Notion)
     - **Research** (Chrome, Safari — look at window titles for topics)
     - **Communication** (Slack, Messages, email)
     - **Meetings** (Zoom, Teams)
     - **Design** (PowerPoint, Figma, Canva)
     - **Admin** (Finder, System Settings, Shortcuts)

4. **Generate the summary**:

   ```markdown
   # Activity Summary: {Date/Range}

   ## Overview
   - **Active time:** {X hours} ({first activity} to {last activity})
   - **Top apps:** {app1} ({X}%), {app2} ({Y}%), {app3} ({Z}%)
   - **Dominant activity:** {category}

   ## Timeline

   | Time | Activity | Apps | Notes |
   |------|----------|------|-------|
   | 9:00-9:30 | SOW episode work | Obsidian, PowerPoint | Editing slides for multiplier window |
   | 9:30-10:00 | Research | Chrome | Dan Shipper articles on Every.to |
   | ... | ... | ... | ... |

   ## What You Worked On
   1. **{Project/Topic}** — {what specifically, based on window titles and OCR}
   2. **{Project/Topic}** — {details}

   ## Audio Snippets
   - [{timestamp}] "{transcription text}"

   ## App Usage
   | App | Time Est. | Frames | Primary Windows |
   |-----|-----------|--------|-----------------|
   | Obsidian | ~{X}min | {N} | Claude Terminal, Note to Rich |
   | Chrome | ~{X}min | {N} | Every.to, Amazon |
   ```

5. **Write to Obsidian** (if full-day summary):
   ```
   YOUR-OBSIDIAN-VAULT/00 Personal Intelligence/Daily Briefings/Activity-Log-{YYYY-MM-DD}.md
   ```

   For ad-hoc queries (partial day), just display in chat.

---

## Execution: Mode 3 — Action Item Scanner

### When user says "actions", "action items", "commitments", "todos"

1. **Parse the time range**. Default: today.

2. **Scan audio transcriptions** for action language:
   - "need to", "have to", "should", "must", "will do"
   - "action item", "follow up", "deadline"
   - Time references: "by tomorrow", "by Friday", "next week", "ASAP"
   - Assignment language: "assigned to", "your job is", "take care of"
   - Commitment language: "I'll", "I will", "I'm going to", "let me"

3. **Scan screen text** for task-related content:
   - ClickUp task titles visible on screen
   - Slack messages with action items
   - Email subjects mentioning deadlines
   - Notes or documents with TODO/checkbox patterns

4. **Cross-reference with context**:
   - Who was Rich talking to when the commitment was made?
   - What app was active (meeting = stronger commitment signal)?
   - Was it Rich committing or someone else?

5. **Categorize and output**:

   ```markdown
   # Action Items Detected: {Date/Range}

   ## Commitments Rich Made
   | Time | Context | Commitment | To Whom | Urgency |
   |------|---------|------------|---------|---------|
   | 2:30 PM | Zoom call | "I'll review the copy by tomorrow" | Nicole | High |
   | 3:15 PM | Slack | Need to update the landing page | Team | Medium |

   ## Commitments Made to Rich
   | Time | Context | Commitment | From Whom |
   |------|---------|------------|-----------|
   | 2:45 PM | Zoom call | "I'll send the analytics report" | Jessica |

   ## Detected TODOs (from screen)
   - [{app}] {todo text} — seen at {time}

   ## Deadlines Mentioned
   - "{deadline text}" — {context}
   ```

6. **Write to Obsidian** if significant items found:
   ```
   YOUR-OBSIDIAN-VAULT/00 Personal Intelligence/Daily Briefings/Action-Items-{YYYY-MM-DD}.md
   ```

---

## Integration with Daily Briefing

The `collect-screenpipe.py` script in the daily-briefing pipeline handles the automated daily pull. This skill is for:
- **On-demand queries** ("What did I work on this morning?")
- **Deeper extraction** (full meeting transcripts vs. the summary in the briefing)
- **Ad-hoc action item scanning** independent of the briefing schedule

The data flows:
```
Screenpipe (always recording)
    ↓
collect-screenpipe.py → daily briefing (automated, summarized)
    ↓
/screenpipe-assistant → on-demand deep queries (this skill)
```

## Output Locations

| Output | Path |
|--------|------|
| Meeting transcripts | `YOUR-OBSIDIAN-VAULT/01 Strategic Profits/Meetings/Screenpipe/` |
| Activity logs | `YOUR-OBSIDIAN-VAULT/00 Personal Intelligence/Daily Briefings/` |
| Action items | `YOUR-OBSIDIAN-VAULT/00 Personal Intelligence/Daily Briefings/` |

## Error Handling

- **Screenpipe not running**: Check `curl localhost:3030/health`. If down, tell user to start it.
- **No data for date**: Screenpipe may not have been running that day. Report clearly.
- **Audio degraded**: Common — Screenpipe audio can go stale. OCR data is usually reliable.
- **Noisy OCR**: Screen text contains UI chrome, menus, etc. Focus on focused windows and filter out short/repetitive text.

---

*Screenpipe Assistant v1.0*
*On-demand screen intelligence for Rich*
