---
name: linkedin-lead-magnet
description: Turn any topic into a high-converting LinkedIn lead magnet. Researches the topic, writes the content with a self-critique pass, publishes it directly to your website via API, and drafts 3 LinkedIn post variations. Returns a live URL ready to drop in comments.
trigger_phrases:
  - create a lead magnet
  - lead magnet
  - linkedin lead magnet
  - make a lead magnet
  - turn this into a lead magnet
---

# LinkedIn Lead Magnet Creator

## PURPOSE

This skill builds lead magnets and publishes them live to the user's website. It handles the full pipeline: research → write → self-critique → publish → draft posts.

**This skill does:** Research a topic, write a 500-1500 word lead magnet in the user's voice, publish it to their website via API, and produce 3 LinkedIn post variations that link to the live page.

**This skill does NOT:** Write blog posts, sales pages, long-form essays, or email sequences. For posts without a lead magnet, use /linkedin-post.

**Identity boundary:** If asked for any format other than a lead magnet + LinkedIn posts, redirect to the appropriate skill.

**Voice file required:** `~/.claude/skills/linkedin-post/references/voice-template.md` — must exist and contain filled content (not placeholder text).

**Site config required:** `~/.claude/skills/linkedin-lead-magnet/site-config.json` — must exist with platform credentials. If missing, lead magnet saves to Desktop.

---

## OPERATING CONSTRAINTS

**NEVER produce output without completing all 8 steps in sequence.**
**NEVER publish to the live site without completing the self-critique gate (Step 6A) first.**
**NEVER proceed past Step 2 if the voice file is missing or has fewer than 3 filled sections.**
**NEVER proceed past Step 4 if research returns fewer than 3 usable, specific insights.**
**ALWAYS validate the API response before reporting the live URL to the user.**
**ALWAYS keep the lead magnet under 1,500 words. If over, cut — do not ask the user what to cut.**

**Binary style rules — apply to every sentence of the lead magnet:**
- ALWAYS start the lead magnet with a counterintuitive claim, not a definition
- NEVER use "synergy," "leverage," "holistic," "game-changing," "paradigm," or "thought leader"
- ALWAYS include at least one specific number or data point per section
- NEVER write a generic CTA ("click here," "learn more") — CTA must name a specific outcome
- ALWAYS write hooks under 15 words, NEVER start with "I"
- NEVER use passive voice
- NEVER bury the point — lead with the insight, support after
- ALWAYS write at sixth-grade reading level (short sentences, simple words)

---

## GUARDRAILS

**Missing voice file:**
```
BLOCKED: Voice file not found or not configured.
Run /linkedin-voice-setup first to populate your voice file from your proof stack.
```

**Missing or incomplete site config:**
"Your site-config.json isn't set up yet. See SETUP.md for instructions — takes 3 minutes. For now, I'll save the lead magnet to ~/Desktop/lead-magnet-[slug].md."

**Research gate (activate before Step 5):**
If research returns fewer than 3 specific, non-obvious insights, do not proceed to writing. Surface to user: "Research on this topic returned thin results. I found [N] specific insights — not enough for a lead magnet that will actually stand out. Narrow the topic or try a different angle?"

**Sufficient research (proceed to Step 5):**
- Found 2+ specific misconceptions with evidence
- Identified 1 contrarian angle the user can credibly own given their voice file
- Found at least 1 non-obvious insight not in the top-3 generic results

**API error handling:**
- HTTP 401/403: Stop. Report credentials error. Do not retry. Tell user to check site-config.json.
- HTTP 404: Stop. Report endpoint not found. Tell user to verify site URL and API endpoint.
- HTTP 5xx: Retry once. If still failing, fall back to Desktop save.
- No `link` in response: Do not report a live URL. Report: "Page may have published but URL was not returned. Check your site at [site_url]/[slug]."

---

## REFERENCE — QUALITY EXEMPLARS

### Strong lead magnet title
"5 AI Mistakes Killing Your Team's Productivity (And What To Do Instead)"
- Specific number + outcome + contrarian angle

### Weak lead magnet title (never produce)
"How To Use AI In Your Business"
- No number, no outcome, no angle, no audience

### Strong section with "My Take"
```
**The Real Problem: You're automating the wrong things first**

Most people automate email and social first. That's backwards.

Email is judgment-heavy. Social requires taste. These are your last automation targets, not your first.

Start with the process that repeats most often with the least variation. That's where AI compounds.

*My Take: I spent 3 months automating our newsletter before I realized I was protecting the one thing I should have kept human. The writing IS the product.*
```

### Weak section (never produce)
```
You should think about AI carefully. There are many ways AI can help your business.
It's important to consider your unique situation and leverage the right tools for your needs.
```
This is what gets generated without constraints. It is worthless.

### Strong LinkedIn hook
"Most AI implementation projects fail in the first 30 days." (13 words, no "I", specific claim, creates tension)

### Weak LinkedIn hook (never produce)
"I wanted to share some thoughts about how AI is changing the way we work today." (Opens with "I", no tension, no claim)

---

## EXECUTION

### Step 1: Clarify Input

Parse the user's input for:
- **Topic** (required)
- **Target audience** (read from voice-template.md, or ask once if missing)
- **URL slug** (derive from topic: "5 AI mistakes" → `/5-ai-mistakes`)
- **Format** (default: numbered playbook. Options: playbook, mistake list, framework doc, checklist, comparison guide)

If a YouTube URL is provided, fetch the transcript first and use as source material.

### Step 2: Load Voice File

Check that `~/.claude/skills/linkedin-post/references/voice-template.md` exists and has filled content in at least 3 sections. If missing or unfilled, activate the Missing Voice File guardrail.

Extract:
- Authority statement (WHO YOU ARE)
- Core beliefs (the contrarian angle for this lead magnet)
- Most relevant distinction (pull from the Distinctions section)
- Specific credentials and proof points to cite
- Website URL (from Lead Magnet CTA section)

### Step 3: Load Site Config

Read `~/.claude/skills/linkedin-lead-magnet/site-config.json`. If missing or `platform: none`, activate the Missing Site Config guardrail and continue to Step 4 (will save to Desktop at Step 7).

### Step 4: Research the Topic

Run 2-3 searches using WebSearch or Perplexity MCP. Research must cover all three vectors before proceeding:
1. Current conversation: what are people actively saying about this topic?
2. Common misconceptions: what do people get wrong? (This becomes the user's angle)
3. Non-obvious insight: what specific, credible point can the user bring that others don't say?

After research, apply the Research Gate. If fewer than 3 usable insights found, activate the gate — do not proceed.

### Step 5: Design the Lead Magnet

**Title formula:** `[Number] [Specific Outcome] [Target Audience] Can [Do/Get] [Time/Qualifier]`

**Structure:**
```
Hook (1-2 sentences): The counterintuitive truth that makes them say "wait, tell me more"

The Real Problem: [Reframe the conventional wisdom — what do people get wrong?]

[3-7 Sections, each with:]
  - Headline
  - Core insight (what most people miss)
  - Specific, actionable implementation
  - Optional: "My Take" — 1 sentence grounded in real experience from voice file

CTA at bottom: [Specific outcome — links to user's community, program, or newsletter]
```

**Format selection:**
- **The Playbook:** "Here's exactly how I do X in context Y"
- **The Mistake List:** "The [N] mistakes killing your [outcome] (and the fixes)"
- **The Framework Doc:** "The system I use to [outcome] — explained"
- **The Checklist:** "Before you do X, run through this"
- **The Comparison Guide:** "Option A vs Option B: what actually matters"

### Step 6: Write the Lead Magnet

Write in the user's voice per voice file. Apply all Binary Style Rules from the OPERATING CONSTRAINTS section to every sentence.

Target: 500-1,500 words. If at limit, cut — don't pad.

### Step 6A: Self-Critique Gate (Required — do not skip)

Before proceeding to publish, evaluate the draft against all gates:

**Content gates:**
- [ ] Title follows the formula: number + outcome + audience + qualifier
- [ ] Lead opens with a counterintuitive claim, not a definition
- [ ] Every section has at least one specific number or data point
- [ ] "The Real Problem" section exists and genuinely reframes conventional wisdom (not just restates it with different words)
- [ ] CTA names a specific outcome
- [ ] Word count is under 1,500

**Style gates:**
- [ ] No hedge language: "it's worth noting," "important to remember," "you may want to consider"
- [ ] No passive voice
- [ ] No banned buzzwords (see OPERATING CONSTRAINTS)
- [ ] Every paragraph has one idea only
- [ ] Read aloud: sounds like a credible expert, not like AI

**If any gate fails:** Fix the failing element. NEVER publish a draft that fails a gate. Do not report the gate failure to the user — just fix it and proceed.

### Step 7: Publish to Website

Read site-config.json to determine platform and credentials.

**WordPress:**
```bash
curl -s -X POST "{site_url}/wp-json/wp/v2/pages" \
  -H "Authorization: {auth_header}" \
  -H "Content-Type: application/json" \
  -d '{"title":"[title]","content":"[HTML]","slug":"[slug]","status":"publish"}'
```

Convert markdown to HTML before posting: `##` → `<h2>`, `###` → `<h3>`, bullets → `<ul><li>`, paragraphs → `<p>`, `**text**` → `<strong>text</strong>`.

**Webflow:**
```bash
curl -s -X POST "https://api.webflow.com/v2/collections/{collection_id}/items" \
  -H "Authorization: Bearer {api_token}" \
  -H "Content-Type: application/json" \
  -d '{"isArchived":false,"isDraft":false,"fieldData":{"name":"[title]","slug":"[slug]","body":"[content]"}}'
```

**After publishing — validate before reporting:**
1. HTTP status must be 200 or 201. If not, activate API Error Handling guardrail — do not report a URL.
2. Response `status` field must be "publish" not "draft" or "pending". If not live, do not report it as live.
3. `link` field must be present and begin with `http`. If absent, use the Site Not Found message from API Error Handling.
4. Report the URL only after all 3 checks pass.

**Fallback (if publish fails or platform is "none"):** Save to `~/Desktop/lead-magnet-[slug].md`. Tell the user: "Couldn't publish automatically — saved to ~/Desktop/lead-magnet-[slug].md. Paste it into your site at [site_url]/[slug], then drop that URL in your LinkedIn comments."

### Step 8: Draft 3 LinkedIn Post Variations

Write in the user's voice per voice file. All 3 end with the live page URL (or Desktop file path if fallback).

**Variation 1 — Results-Led:** Open with a specific result or transformation from the voice file credentials.
**Variation 2 — Pain-First:** Open with the frustration the audience feels. End with the lead magnet as the solution.
**Variation 3 — Contrarian:** Open with the counterintuitive claim. Tease the insight. End with URL.

Rules for all posts:
- Line 1: under 15 words, never starts with "I"
- Body: 4-7 short paragraphs
- End: "Link in comments" (user pastes the URL as first comment)
- Total: 150-250 words

---

## OUTPUT

```markdown
# Lead Magnet: [Title]

**Live at:** [full page URL]
(or "Saved to ~/Desktop/lead-magnet-[slug].md" if fallback)

---

## The Lead Magnet

[Full content here]

---

## LinkedIn Post — Option 1: Results-Led
[Post text — ends with "Link in comments"]

## LinkedIn Post — Option 2: Pain-First
[Post text — ends with "Link in comments"]

## LinkedIn Post — Option 3: Contrarian
[Post text — ends with "Link in comments"]

---

## Next Steps
1. Pick your post and copy it into LinkedIn
2. Publish it
3. Drop this URL in the first comment: [live URL]
4. Run /linkedin-trending-topics for your next topic
```
