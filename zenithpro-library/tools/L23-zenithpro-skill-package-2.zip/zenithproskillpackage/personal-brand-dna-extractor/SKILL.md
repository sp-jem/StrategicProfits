---
name: personal-brand-dna-extractor
description: Extracts your unique brand DNA from existing materials and creates 8 AI-optimized files that power all copywriting and webinar systems with YOUR voice, YOUR stories, YOUR credentials.
version: 1.0.0
author: Rich Schefren
---
2
# Personal Brand DNA Extractor

## PURPOSE

This skill extracts personal brand DNA from existing materials and generates 8 AI-optimized markdown files:

1. **01-VOICE-AND-TONE.md** - Writing patterns, signature phrases, persuasion style
2. **02-CREDENTIALS.md** - Quantified achievements, authority claims, scale markers
3. **03-TESTIMONIALS.md** - Organized social proof, tiered by strength
4. **04-ORIGIN-STORIES.md** - Narrative with "when to use" context
5. **05-MENTEES-AND-CLIENTS.md** - Client transformations, documented results
6. **06-PERSONAL-DETAILS.md** - Humanizing elements, background, interests
7. **07-CORE-PHILOSOPHY.md** - Frameworks, contrarian beliefs, principles
8. **CLAUDE.md** - Index file and usage guide

These files power Arena systems and expert skills, enabling AI to write in the user's authentic voice.

---

## INSTRUCTIONS

When invoked, execute this 8-phase extraction process:

### PHASE 1: INTRODUCTION & MATERIAL COLLECTION

Display introduction:

```markdown
# Personal Brand DNA Extractor

I'll extract your unique brand DNA from your existing materials and create 8 AI-optimized files.

**You'll get:**
- Voice and tone patterns (how you write)
- Quantified credentials (your authority claims)
- Organized testimonials (social proof)
- Origin stories (your narrative)
- Client transformations (proof of results)
- Personal details (humanizing elements)
- Core philosophy (your frameworks)
- Usage guide (how to use with Arena/Skills)

**Time required:** 20-30 minutes

Ready to begin?
```

Then collect materials by asking:

**Website/Online Presence:**
1. "What's your main website URL?"
2. "LinkedIn profile URL? (or type 'skip')"
3. "Any other online profiles? (Medium, Twitter/X, about.me, etc.) (or 'skip')"

**Documents & Content:**
4. "Do you have any documents I should analyze? (Bios, transcripts, presentations) Provide file paths or URLs (or 'skip')"
5. "Path to folder containing your content? (or 'skip')"

**Testimonials & Social Proof:**
6. "URL to testimonials page? (or 'skip')"
7. "LinkedIn recommendations? (or 'skip')"
8. "Case studies or portfolio page? (or 'skip')"

**Additional:**
9. "Anything else I should review? (URLs or file paths) (or 'skip')"

Store responses as:
```
source_materials:
  websites: [...]
  social_profiles: [...]
  documents: [...]
  testimonials: [...]
```

---

### PHASE 2: SOURCE VALIDATION

For each source:
1. **URLs**: Use WebFetch to validate (don't fetch full content yet)
2. **File paths**: Use Read to verify file exists
3. **Folders**: Use Glob to list contents

Classify each as: website, social profile, document, testimonial collection, or other.

Display validation results:
```markdown
## Validating Your Materials

â Main website ([domain]) - Accessible
â LinkedIn profile - Accessible
â ï¸ Medium profile - Not found (404)
â Documents folder - [N] files found

**Ready to analyze:**
- [N] websites
- [N] documents
- [N] social profiles

**Skipped:** [list any failed sources]

Proceeding to extraction...
```

**Error handling:**
- If ALL fail: Request at least one valid source
- If SOME fail: Note gaps, proceed with valid sources
- If empty: Note gap, continue

---

### PHASE 3: PARALLEL EXTRACTION - SPAWN 7 TASK AGENTS

Display:
```markdown
## Extracting Your Brand DNA

Spawning 7 specialized agents in parallel...

â³ Voice Archaeologist (Dr. James Liu) - Analyzing writing patterns...
â³ Credibility Architect (Dr. Elena Vasquez) - Quantifying achievements...
â³ Testimonial Curator (Dr. Elena Vasquez) - Organizing social proof...
â³ Story Miner (Marcus Chen) - Extracting origin stories...
â³ Results Tracker (Dr. Elena Vasquez) - Documenting transformations...
â³ Humanizer (Marcus Chen) - Finding personal details...
â³ Philosophy Distiller (Dr. Maya Patel) - Distilling frameworks...

This will take 5-10 minutes depending on material volume.
```

**CRITICAL: Spawn all 7 agents in parallel using Task tool with 7 concurrent calls.**

Each agent receives:
- **Persona** with background and behavior
- **Validated sources** to analyze
- **Extraction requirements** (what to find)
- **Output format** (structured data schema)
- **Quality threshold** (85% ELEVATED)

---

#### AGENT 1: VOICE ARCHAEOLOGIST

Spawn with Task tool, prompt:

```
You are Dr. James Liu - Research methodology specialist with 30 years analyzing communication patterns. Exhaustive coverage. No gaps. Document everything. Cross-reference patterns across all sources.

TASK: Extract voice patterns, signature phrases, and writing style

SOURCES PROVIDED:
[List all validated sources]

EXTRACTION REQUIREMENTS:
1. Signature phrases (recurring expressions, unique word choices) - Target: 20+
2. Sentence patterns (structure, length, rhythm, rhetorical devices) - Target: 10+
3. Tone characteristics across 4+ dimensions (authority, formality, emotion, humor)
4. Persuasion techniques with examples - Target: 7+
5. Contrarian positions (statements against conventional wisdom) - Target: 5+

METHOD:
- Use WebFetch to analyze all website copy
- Use Read to analyze all documents
- Identify patterns that repeat across multiple sources (track frequency)
- Extract distinctive or memorable phrases
- Note context for each element

OUTPUT FORMAT - Return as structured markdown:

## Voice Extraction Results

### Signature Phrases
| Phrase | Context | Frequency | Example Sentence |
|--------|---------|-----------|------------------|
| [phrase] | [when used] | [N times] | [full example] |

### Sentence Patterns
1. **[Pattern name]**: [Description]
   - Example: "[sentence]"
   - When used: [context]

### Tone Characteristics
- **Authority Level**: [High/Medium/Low] - [Evidence]
- **Formality**: [Formal/Moderate/Casual] - [Evidence]
- **Emotional Intensity**: [High/Medium/Low] - [Evidence]
- **Humor**: [Frequent/Occasional/Rare] - [Evidence]

### Persuasion Techniques
1. **[Technique]**: [Description]
   - Example: "[quote]"
   - When to deploy: [context]

### Contrarian Positions
1. **"[Position]"**
   - Conventional wisdom: "[standard belief]"
   - Their stance: "[different belief]"
   - Use when: [context]

QUALITY THRESHOLD: ELEVATED (85%)
- Minimum: 10+ phrases, 5+ patterns, 3+ tone dimensions
- Excellent: 20+ phrases, 10+ patterns, detailed analysis

Self-assess confidence and report any gaps.

DELIVERABLE: Complete markdown extraction following above format
```

---

#### AGENT 2: CREDIBILITY ARCHITECT

Spawn with Task tool, prompt:

```
You are Dr. Elena Vasquez - 20 years quantitative research, Stanford PhD, obsessive about data integrity. Never accept claims without evidence. Question everything. Cite sources.

TASK: Quantify achievements and transform into authority claims

SOURCES PROVIDED:
[List all validated sources]

EXTRACTION REQUIREMENTS:
1. Quantified achievements (numbers, scale, impact) - Target: 10+
2. Industry firsts or innovations - Target: 3+
3. Formal credentials (education, certifications, experience)
4. Scale markers (clients served, revenue, years in business) - Target: 5+
5. Media coverage or recognition - Target: 3+
6. Awards or notable acknowledgments

METHOD:
- Look for numbers: "20 years", "$50M in sales", "5,000 clients"
- Look for superlatives: "first to", "only one who", "pioneered"
- Find credentials in bios, about pages
- Find media mentions, press coverage
- Transform vague claims into specific quantified statements

OUTPUT FORMAT - Return as structured markdown:

## Credentials Extraction Results

### Quantified Achievements
#### Business Scale
- **[Achievement]**: [Numbers + timeframe + category]

#### Client Impact
- **[Achievement]**: [Numbers + context]

#### Industry Recognition
- **[Achievement]**: [Details + significance]

### Industry Firsts & Innovations
1. **[First/Innovation]**
   - What: [Description]
   - When: [Year]
   - Significance: [Why it matters]
   - Use when: [Context for credibility claim]

### Formal Credentials
**Education:**
- [Degree, Institution, Year]

**Experience:**
- [N] years in [Industry/Role]

**Certifications:**
- [Certification, Organization]

### Scale Markers
| Metric | Number | Context |
|--------|--------|---------|
| Clients Served | [N] | [Timeframe/context] |
| Years in Business | [N] | [Since when] |
| Revenue Generated | $[N] | [For clients/self] |

### Media Coverage & Recognition
- **[Outlet]** ([Year]) - [Type: article/interview/column]

### Awards & Rankings
- **[Award]** - [Organization, Year]

### Authority Statement Templates
1. **Bio Long**: "[Name] has [main achievement]. Over [X] years, [they've] [accomplishments]. [Name] has [credentials/recognition]."
2. **Bio Short**: "[Name] is a [title] who [value prop]. [Key credential]."
3. **Introduction**: "With [X years] in [field] and [achievement], [Name] [positioning]."

QUALITY THRESHOLD: ELEVATED (85%)
- Minimum: 3+ quantified achievements, basic credentials
- Excellent: 10+ quantified achievements, comprehensive portfolio

Self-assess confidence and report any gaps.

DELIVERABLE: Complete markdown extraction following above format
```

---

#### AGENT 3: TESTIMONIAL CURATOR

Spawn with Task tool, prompt:

```
You are Dr. Elena Vasquez - Analytical specialist. Never accept claims without evidence. Categorize rigorously. Document everything.

TASK: Find, organize, and categorize social proof

SOURCES PROVIDED:
[List all validated sources]

EXTRACTION REQUIREMENTS:
1. Direct testimonials (client quotes) - Target: 20+ across tiers
2. Case study results (before/after transformations) - Target: 5+
3. Social media praise (LinkedIn recommendations, mentions)
4. Indirect social proof (client logos, associations, speaking)
5. Tier testimonials by strength: Tier 1 (Legendary), Tier 2 (Strong), Tier 3 (Community)

TIERING CRITERIA:
- **Tier 1 Legendary**: Specific, quantified, impressive results. Best for sales pages.
- **Tier 2 Strong**: Good specificity and credibility. For trust-building.
- **Tier 3 Community**: Shorter, less specific. For volume.

METHOD:
- Scrape testimonials pages if provided
- Extract LinkedIn recommendations
- Look for quote blocks on website
- Find case study data
- Categorize by strength AND use case

OUTPUT FORMAT - Return as structured markdown:

## Testimonials Extraction Results

### Tier 1: Legendary Testimonials
(Target: 5+)

#### [Client Name/Type]
**Quote**: "[Full testimonial]"
**Attribution**: [Name, Title/Company]
**Result**: [Specific quantified outcome]
**Timeframe**: [Duration]
**When to Use**: [Context - e.g., "For aggressive ROI claims"]

### Tier 2: Strong Testimonials
(Target: 10+)

#### [Client Name/Type]
**Quote**: "[Full testimonial]"
**Attribution**: [Name, credentials]
**Result**: [Outcome]
**When to Use**: [Context]

### Tier 3: Community Testimonials
(Target: 20+)

- "[Quote]" - [Name]
- "[Quote]" - [Name]

### Case Studies
(Target: 5+)

#### Case Study: [Client Name/Pseudonym]

**Before:**
- [Metric 1]: [Before state]
- [Metric 2]: [Before state]
- Challenge: [Struggle]

**Journey:**
- [What implemented]
- [Timeline]
- [Key milestones]

**After:**
- [Metric 1]: [After state] ([% improvement])
- [Metric 2]: [After state] ([% improvement])
- Outcome: [Transformation summary]

**Quote**: "[Client testimonial]"
**When to Use**: [Context]

### Indirect Social Proof

**Client Logos/Lists:**
- [Company/Person]

**Association Memberships:**
- [Association]

**Speaking Engagements:**
- [Event/Organization] ([Year])

### Social Proof by Use Case

**For Financial Results Claims:**
- [Best testimonial for money results]

**For Time Freedom Claims:**
- [Best testimonial for time/lifestyle]

**For Impact/Mission Claims:**
- [Best testimonial for meaning/purpose]

QUALITY THRESHOLD: ELEVATED (85%)
- Minimum: 5+ testimonials across tiers
- Excellent: 20+ testimonials, multiple case studies, all tiers represented

Self-assess confidence and report any gaps.

DELIVERABLE: Complete markdown extraction following above format
```

---

#### AGENT 4: STORY MINER

Spawn with Task tool, prompt:

```
You are Marcus Chen - Award-winning creative director, 15 years at top agencies. Push boundaries. Generate unexpected combinations. Value originality over safety. Find the narrative gold.

TASK: Mine origin stories and structure narratives with context

SOURCES PROVIDED:
[List all validated sources]

EXTRACTION REQUIREMENTS:
1. Personal origin story (how they got started) - Target: 1+
2. Business origin story (why they started company) - Target: 1+
3. Breakthrough moment stories (key turning points) - Target: 3+
4. Failure/struggle stories (vulnerable moments) - Target: 2+
5. Client transformation stories (hero's journey) - Target: 5+
6. "How I discovered X" stories (framework origin) - Target: 2+

STORY STRUCTURE (use for each):
- Setup (context, before state)
- Conflict (problem, struggle, turning point)
- Resolution (how solved, lesson learned)
- Application (when to use this story)
- Emotional tone
- Key quote

METHOD:
- Look in About pages, bio sections
- Read blog posts or articles for personal anecdotes
- Check for "my story" or "how I started" sections
- Extract mini-stories from longer content
- Structure each story with full narrative arc

OUTPUT FORMAT - Return as structured markdown:

## Stories Extraction Results

### Personal Origin Story
(Target: 1)

#### [Story Title]

**Setup (Before):**
[Who they were, where they were, what life looked like]

**Conflict (The Struggle):**
[What went wrong, what they tried, what failed, dark moment]

**Turning Point:**
[The moment/decision/insight that changed everything]

**Resolution (After):**
[What they did differently, how it worked, where they are now]

**The Lesson:**
[What they learned, what they want others to know]

**Emotional Tone**: [Vulnerable/Triumphant/Inspiring/Cautionary]

**When to Use:**
- [Context 1]
- [Context 2]

**Key Quote**: "[Most memorable line from this story]"

### Business Origin Story
(Target: 1)

#### [Story Title]

**Setup:**
[What they saw in market, what frustrated them, what was missing]

**Conflict:**
[The problem they wanted to solve, why existing solutions failed]

**The Mission:**
[Why they started this, what they set out to change]

**Resolution:**
[What they built, how it's different, who they serve]

**The Vision:**
[Where they're taking it, what future they're building]

**When to Use:**
- [Context 1]
- [Context 2]

### Breakthrough Moment Stories
(Target: 3+)

#### [Story 1 Title]

**Before**: [The struggle or plateau]
**The Moment**: [What happened, discovery, insight]
**After**: [How it changed everything]
**The Principle**: [The takeaway/framework that emerged]
**When to Use**: [Context]

### Failure/Struggle Stories
(Target: 2+)

#### [Story 1 Title]

**The Mistake**: [What they did wrong]
**The Consequences**: [What happened as result]
**What They Learned**: [Hard-won lesson]
**How to Avoid It**: [Advice for others]
**When to Use**: [Context - builds trust through vulnerability]

### Client Transformation Stories
(Target: 5+)

#### [Client Name/Pseudonym]

**Who They Were:**
[Background, situation, struggles]

**The Before State:**
- [Metric 1]: [Before]
- [Pain Point]: [Specific struggle]

**The Journey:**
[What they did, what framework used, the process]

**The Turning Point:**
[Key moment or insight that created breakthrough]

**The After State:**
- [Metric 1]: [After] ([Change])
- [Transformation]: [How life changed]

**Client Quote**: "[In their own words]"
**When to Use**: [Context]

### "How I Discovered..." Stories
(Target: 2+)

#### How I Discovered [Framework Name]

**The Problem**: [What they were trying to solve]
**What Wasn't Working**: [Conventional approaches tried]
**The Breakthrough**: [The insight or discovery]
**How It Works**: [Brief explanation]
**The Results**: [What it's done for them and clients]
**When to Use**: [Context]

### Story Selection Guide

| Goal | Use This Story Type |
|------|---------------------|
| Establish relatability | Personal Origin, Failure Stories |
| Build credibility | Breakthrough Stories, Client Transformations |
| Position against competition | Business Origin |
| Teach a principle | "How I Discovered" Stories |
| Create emotional connection | Personal struggles, Client stories |
| Demonstrate expertise | Breakthrough, Framework origin |

QUALITY THRESHOLD: ELEVATED (85%)
- Minimum: 3+ stories across different layers
- Excellent: 10+ stories covering all categories with full context

Self-assess confidence and report any gaps.

DELIVERABLE: Complete markdown extraction following above format
```

---

#### AGENT 5: RESULTS TRACKER

Spawn with Task tool, prompt:

```
You are Dr. Elena Vasquez - Quantitative research expert. Never accept claims without evidence. Question everything. Document rigorously.

TASK: Document client transformations with quantified results

SOURCES PROVIDED:
[List all validated sources]

EXTRACTION REQUIREMENTS:
1. Financial transformations (revenue, profit, growth) - Target: 10+
2. Time freedom transformations (hours, lifestyle) - Target: 5+
3. Impact/scale transformations (clients served, reach) - Target: 5+
4. Satisfaction/fulfillment transformations (qualitative) - Target: 5+
5. Before/after metrics for each
6. Timeframes (how long)
7. Attribution (what caused change)

METHOD:
- Look for case studies
- Extract from testimonials with numbers
- Find results sections on sales pages
- Check for client success stories
- Always quantify when possible

OUTPUT FORMAT - Return as structured markdown:

## Results Extraction

### Financial Transformations
(Target: 10+)

#### [Client Name/Type 1]

**Before:**
- Revenue: [Amount]
- Profit Margin: [%]
- Growth Rate: [%]

**After:**
- Revenue: [Amount] ([% increase])
- Profit Margin: [%] ([change])
- Growth Rate: [%] ([change])

**Timeframe**: [Duration]
**What Changed**: [Specific actions, systems, frameworks]
**Attribution**: [What caused transformation]
**Quote**: "[Client testimonial]"
**When to Use**: [Context - e.g., "For ROI-focused sales copy"]

### Time Freedom Transformations
(Target: 5+)

#### [Client Name/Type 1]

**Before:**
- Hours Worked: [Per week]
- Revenue: [Amount]
- Stress Level: [Qualitative]

**After:**
- Hours Worked: [Per week] ([Reduction])
- Revenue: [Amount] ([Change])
- Lifestyle: [Description]

**Timeframe**: [Duration]
**What Changed**: [Specific systems]
**Quote**: "[Client testimonial]"
**When to Use**: [Context]

### Impact/Scale Transformations
(Target: 5+)

#### [Client Name/Type 1]

**Before:**
- Clients Served: [Number]
- Delivery Model: [1-on-1, group, etc.]
- Reach: [Description]

**After:**
- Clients Served: [Number] ([Multiplier])
- Delivery Model: [Scaled model]
- Reach: [New reach]

**Timeframe**: [Duration]
**What Changed**: [Scalability systems]
**Quote**: "[Client testimonial]"
**When to Use**: [Context]

### Satisfaction/Fulfillment Transformations
(Target: 5+)

#### [Client Name/Type 1]

**Before:**
- Feeling: [Burned out, stressed, trapped, etc.]
- Work Satisfaction: [Low/Medium/High]
- Life Balance: [Description]

**After:**
- Feeling: [Energized, fulfilled, free, etc.]
- Work Satisfaction: [High]
- Life Balance: [Improved state]

**Timeframe**: [Duration]
**What Changed**: [Mindset shifts, systems, lifestyle changes]
**Quote**: "[Client testimonial]"
**When to Use**: [Context]

### Results by Industry/Niche

#### [Industry 1]
- [Client 1 result summary]
- [Client 2 result summary]

**Common Pattern**: [What typically happens for this niche]

### Results by Framework/Method

#### [Framework Name]

**Typical Results:**
- [Outcome 1]: [Range or average]
- [Outcome 2]: [Range or average]
- [Timeframe]: [Typical duration]

**Example Clients:**
1. [Client 1]: [Result]
2. [Client 2]: [Result]

### Aggregate Results

- **Total Clients Served**: [Number]
- **Average Revenue Increase**: [%] in [Timeframe]
- **Average Time Reduction**: [Hours] per week
- **Success Rate**: [%] achieve [Outcome]
- **Total Value Created**: $[Amount] in client results

### Results Selection Guide

| Copy Context | Use These Results |
|--------------|-------------------|
| ROI-focused sales page | Financial transformations (best 3-5) |
| Lifestyle positioning | Time freedom transformations |
| Mission-driven copy | Impact/scale transformations |
| Testimonials section | Mix of all categories |
| Case study | Full transformation (one client, all metrics) |

QUALITY THRESHOLD: ELEVATED (85%)
- Minimum: 3+ transformations with numbers
- Excellent: 15+ transformations across all categories

Self-assess confidence and report any gaps.

DELIVERABLE: Complete markdown extraction following above format
```

---

#### AGENT 6: HUMANIZER

Spawn with Task tool, prompt:

```
You are Marcus Chen - Creative specialist. Find the human story. Push boundaries. Value originality. Make them 3-dimensional.

TASK: Extract personal details that humanize the profile

SOURCES PROVIDED:
[List all validated sources]

EXTRACTION REQUIREMENTS:
1. Location/geography (where based, origin) - Target: 2 data points
2. Family details (if shared publicly)
3. Hobbies and interests outside work - Target: 10+
4. Personal background (origin, education, early career)
5. Personality traits (how they describe themselves) - Target: 5+
6. Fun facts or quirks - Target: 5+
7. Values and what matters to them - Target: 5+

METHOD:
- Read About page personal sections
- Check social media bios
- Look for personal anecdotes in content
- Find mentions of hobbies, interests, family
- **ONLY extract what's publicly shared - don't invent**

OUTPUT FORMAT - Return as structured markdown:

## Personal Details Extraction

### Location & Geography

**Current**: [City, State/Country]
**Origin**: [Where from originally]
**Story**: [Any interesting geographic context]

### Background

**Early Life:**
[Origin story, upbringing, formative experiences - only what's publicly shared]

**Education:**
- [Degree, Institution, Year]

**Early Career:**
[First jobs, career path before current business, pivotal moments]

**Influences:**
- **Mentors**: [Names if mentioned]
- **Books/Ideas**: [Key influences]
- **Experiences**: [Life experiences that shaped them]

### Family & Personal Life

**Sharing Level**: [Open / Selective / Private]

**Public Information:**
[Only what they've shared publicly]

**How They Reference Family:**
[If/how they mention family in content]

### Interests & Hobbies
(Target: 10+)

#### Primary Interests

1. **[Interest 1]**
   - Details: [How serious, how often, interesting facts]
   - Connection to work: [If any]
   - Quote: "[If they've said something quotable]"

2. **[Interest 2]**
   - Details: [Specifics]
   - Connection to work: [If any]

#### Other Interests
- [Interest 6]
- [Interest 7]
- [Interest 8]

### Personality Traits
(Target: 5+)

| Trait | Evidence |
|-------|----------|
| [Trait 1] | [How this shows up in their content] |
| [Trait 2] | [Evidence or self-description] |
| [Trait 3] | [How this manifests] |

### Values & Beliefs
(Target: 5+)

#### Core Values

1. **[Value 1]**
   - Evidence: [How this shows up]
   - Quote: "[Relevant quote]"

2. **[Value 2]**
   - Evidence: [How this shows up]

#### What They Stand Against
- [Thing 1]
- [Thing 2]
- [Thing 3]

### Fun Facts & Quirks
(Target: 5+)

- [Fun fact 1]
- [Fun fact 2]
- [Fun fact 3]
- [Quirk 1]
- [Quirk 2]

### Life Philosophy Quotes

> "[Quote about life, values, or personal beliefs]"

> "[Another philosophical quote]"

### How to Use Personal Details in Copy

**For Relatability:**
Use: [Interests audience shares, background similarities, common struggles]

**For Humanization:**
Use: [Quirks, hobbies, fun facts that make them 3-dimensional]

**For Values Alignment:**
Use: [Core values statements when they align with offer]

**For Differentiation:**
Use: [Unique combinations that create interesting contrast]

### What NOT to Use

- [Any details they keep private]
- [Family specifics unless they share openly]
- [Health information unless public]
- [Anything that feels intrusive]

QUALITY THRESHOLD: ELEVATED (85%)
- Minimum: 3+ interests, basic profile complete
- Excellent: 10+ interests, rich personal context

Self-assess confidence and report any gaps.

DELIVERABLE: Complete markdown extraction following above format
```

---

#### AGENT 7: PHILOSOPHY DISTILLER

Spawn with Task tool, prompt:

```
You are Dr. Maya Patel - Cross-domain integration specialist, pattern recognition expert. Connect disparate ideas. Find unexpected relationships. Synthesize coherently.

TASK: Extract frameworks, contrarian beliefs, and core principles

SOURCES PROVIDED:
[List all validated sources]

EXTRACTION REQUIREMENTS:
1. Named frameworks (proprietary systems created) - Target: 3+
2. Core principles (beliefs that drive their work) - Target: 5+
3. Contrarian positions (what they believe others don't) - Target: 5+
4. Mental models (how they think about problems) - Target: 3+
5. Recurring themes (concepts that appear everywhere)

METHOD:
- Look for named systems ("The X Framework", "Y System")
- Find principle statements ("I believe...", "The key is...")
- Identify what they argue against (conventional wisdom)
- Extract mental models from explanations
- Note recurring concepts across content

OUTPUT FORMAT - Return as structured markdown:

## Philosophy Extraction

### Proprietary Frameworks
(Target: 3+)

#### [Framework 1 Name]

**Overview**: [One-sentence description]
**Purpose**: [What problem does this solve?]
**Origin**: [When/how was it created?]

**Components:**
1. **[Component 1]**: [Description]
2. **[Component 2]**: [Description]
3. **[Component 3]**: [Description]
4. **[Component 4]**: [Description]

**How It Works:**
[Step-by-step process or explanation]

**Results**: [What happens when applied]

**When to Use in Copy:**
- [Context 1]
- [Context 2]
- [Context 3]

**Key Quote**: "[Memorable quote about this framework]"

### Core Principles
(Target: 5+)

#### 1. [Principle Name]

**Statement**: "[The principle in one sentence]"
**Explanation**: [What this means, why it matters]
**Evidence**: [How they demonstrate this]
**Application**: [How this shows up in their work/advice]
**In Their Words**: "[Quote exemplifying this]"
**Use in Copy**: [When/how to reference]

### Contrarian Beliefs
(Target: 5+)

#### 1. [Contrarian Belief]

**Their Position**: "[What they believe]"
**Conventional Wisdom**: "[What most people believe]"
**Why They Disagree**: [Their reasoning, evidence]
**Implications**: [What this means for clients/strategy]
**Proof/Evidence**: [Results, examples, logic]

**Use in Copy:**
- Positioning against competitors
- Creating pattern interrupt
- Establishing thought leadership

**Key Quote**: "[Quotable contrarian statement]"

### Mental Models
(Target: 3+)

#### [Mental Model 1]

**Description**: [What is this model?]
**How It Works**: [The logic/mechanics]
**Why It Matters**: [What insight does this provide?]
**Example**: [Real-world example]
**Application**: [When to use this mental model]

**Visual:**
```
[ASCII diagram if applicable, or description of visual]
```

### Recurring Themes

| Theme | Frequency | Description | How It Manifests |
|-------|-----------|-------------|------------------|
| [Theme 1] | High/Medium/Low | [What it is] | [Where/how it shows up] |
| [Theme 2] | High/Medium/Low | [What it is] | [Where/how it shows up] |

### Philosophical Influences

- **[Influence 1]**: [Person/book/idea] - [How it influenced them]
- **[Influence 2]**: [Person/book/idea] - [How it influenced them]

### The Worldview

**How They See The Problem:**
[Their diagnosis of what's wrong in their industry/audience's situation]

**How They See The Solution:**
[Their approach to fixing it, their methodology]

**Their Mission:**
[What they're trying to change/accomplish in the world]

**Their Vision:**
[Where they want to take this, what future they're building]

### Framework Application Guide

| Use Case | Apply This Framework |
|----------|---------------------|
| [Context 1] | [Framework + brief application] |
| [Context 2] | [Framework + brief application] |
| [Context 3] | [Framework] |

### Philosophy in Copy

**For Authority:**
Use: [Frameworks as proprietary methodology, contrarian beliefs as differentiation]

**For Teaching:**
Use: [Mental models to explain concepts, principles to guide application]

**For Positioning:**
Use: [Contrarian beliefs to separate from competitors, mission to align with values]

**For Proof:**
Use: [Framework results, principle-based success stories]

QUALITY THRESHOLD: ELEVATED (85%)
- Minimum: 1+ framework, 2+ principles, 2+ contrarian beliefs
- Excellent: 3+ frameworks, 5+ principles, 5+ contrarian beliefs

Self-assess confidence and report any gaps.

DELIVERABLE: Complete markdown extraction following above format
```

---

### AFTER SPAWNING ALL 7 AGENTS

Wait for all agents to complete. As each completes, update progress:

```markdown
â Voice Archaeologist - Complete (found N signature phrases)
â Credibility Architect - Complete (quantified N achievements)
â³ Testimonial Curator - In progress...
[etc.]
```

Collect all agent outputs.

---

### PHASE 4: QUALITY ASSESSMENT & GAP FILLING

Review all agent outputs. Calculate quality scores:

```markdown
## Extraction Quality Report

Voice Patterns:     [âââââ] X% - [Assessment]
Credentials:        [âââââ] X% - [Assessment]
Testimonials:       [âââââ] X% - [Assessment]
Origin Stories:     [âââââ] X% - [Assessment]
Client Results:     [âââââ] X% - [Assessment]
Personal Details:   [âââââ] X% - [Assessment]
Core Philosophy:    [âââââ] X% - [Assessment]

**Overall Quality**: X%
```

If any dimension < 60%, identify critical gaps and ask:

```markdown
**Critical Gaps Identified:**
- [Area]: [Specific issue]

Would you like to fill these gaps now? (Y/N)

If YES: I'll ask targeted questions (5-10 min)
If NO: I'll proceed with what we have (you can edit files later)
```

If user says YES, ask targeted questions for each gap.

---

### PHASE 5: SYNTHESIS & FORMATTING

Synthesize all agent outputs into 7 markdown files using this template structure:

**01-VOICE-AND-TONE.md:**
```markdown
# Voice and Tone Patterns

> This file documents [Name]'s distinctive voice, writing style, and persuasion patterns.

---

## Signature Phrases

[Table from Voice Archaeologist output]

## Writing Patterns

[From Voice Archaeologist output]

## Tone Characteristics

[From Voice Archaeologist output]

## Persuasion Techniques

[From Voice Archaeologist output]

## Contrarian Positions

[From Voice Archaeologist output]

## Voice Guidelines for AI

When writing as [Name]:
- DO: [Synthesized from patterns]
- DON'T: [Synthesized from patterns]
- SIGNATURE MOVES: [Synthesized from techniques]

---

*Last Updated: [Date]*
*Extracted from: [list of sources]*
```

**02-CREDENTIALS.md:**
```markdown
# Credentials and Authority Claims

> This file documents [Name]'s quantified achievements, credentials, and authority markers.

---

[Content from Credibility Architect output, formatted per template]

---

*Last Updated: [Date]*
*Extracted from: [list of sources]*
```

**03-TESTIMONIALS.md:**
```markdown
# Testimonials and Social Proof

> This file organizes [Name]'s testimonials and social proof by strength and use case.

---

[Content from Testimonial Curator output, formatted per template]

---

*Last Updated: [Date]*
*Extracted from: [list of sources]*
```

**04-ORIGIN-STORIES.md:**
```markdown
# Origin Stories and Narratives

> This file documents [Name]'s key stories with full context and "when to use" guidance.

---

[Content from Story Miner output, formatted per template]

---

*Last Updated: [Date]*
*Extracted from: [list of sources]*
```

**05-MENTEES-AND-CLIENTS.md:**
```markdown
# Client Results and Transformations

> This file documents measurable client transformations and results.

---

[Content from Results Tracker output, formatted per template]

---

*Last Updated: [Date]*
*Extracted from: [list of sources]*
```

**06-PERSONAL-DETAILS.md:**
```markdown
# Personal Details and Humanizing Elements

> This file documents [Name]'s personal background, interests, and humanizing details.

---

[Content from Humanizer output, formatted per template]

---

*Last Updated: [Date]*
*Extracted from: [list of sources]*
```

**07-CORE-PHILOSOPHY.md:**
```markdown
# Core Philosophy and Frameworks

> This file documents [Name]'s proprietary frameworks, principles, and mental models.

---

[Content from Philosophy Distiller output, formatted per template]

---

*Last Updated: [Date]*
*Extracted from: [list of sources]*
```

---

### PHASE 6: USER REVIEW (OPTIONAL)

Ask:
```markdown
## Review Your Brand DNA (Optional)

I've generated your 8 Brand DNA files. Would you like to:

1. Review all files now (I'll show you each one)
2. Review specific files (which ones?)
3. Skip review (files are ready, you can edit manually later)
```

If user reviews, show each file sequentially and collect corrections.

---

### PHASE 7: FILE GENERATION & DELIVERY

Ask where to save:
```markdown
## Where should I save your Brand DNA files?

1. Project folder: [Current project]/_AI-COPYWRITING-RESOURCES/
2. Skills folder: ~/.claude/skills/[your-name]-brand-dna/
3. Both locations (recommended)
4. Custom location

Which option? (1, 2, 3, or 4)
```

Generate all 8 files using Write tool:
- 7 content files
- 1 CLAUDE.md index file

Display confirmation:
```markdown
## Generating Your Brand DNA Files

â Created: 01-VOICE-AND-TONE.md
â Created: 02-CREDENTIALS.md
â Created: 03-TESTIMONIALS.md
â Created: 04-ORIGIN-STORIES.md
â Created: 05-MENTEES-AND-CLIENTS.md
â Created: 06-PERSONAL-DETAILS.md
â Created: 07-CORE-PHILOSOPHY.md
â Created: CLAUDE.md (index file)

**Saved to**: [Full path]

All files validated â
```

---

### PHASE 8: USAGE GUIDE & COMPLETION

Display:
```markdown
## â Your Brand DNA is Ready!

**Location**: [Full path]

**What you have:**
- 01-VOICE-AND-TONE.md - Your writing patterns and signature phrases
- 02-CREDENTIALS.md - Quantified achievements for authority claims
- 03-TESTIMONIALS.md - Organized social proof
- 04-ORIGIN-STORIES.md - Your narrative with "when to use" context
- 05-MENTEES-AND-CLIENTS.md - Client transformations
- 06-PERSONAL-DETAILS.md - Humanizing elements
- 07-CORE-PHILOSOPHY.md - Your frameworks and principles
- CLAUDE.md - Index and usage guide

---

## How to Use Your Brand DNA

### With Webinar Arena
```bash
/webinar-arena
```
All 6 experts create webinars in YOUR voice automatically.

### With Individual Expert Skills
```bash
/clayton
/deutsch
/webinar-fladlien
```
Each expert uses your Brand DNA automatically.

### Manual Reference
Copy-paste from any file when writing copy yourself.

---

## Next Steps

1. **Test it**: Run `/webinar-arena` or any expert skill and see the difference
2. **Review files**: Open and read through each file, make manual edits if needed
3. **Update anytime**: Re-run `/personal-brand-dna-extractor` or edit files directly

---

**Your Brand DNA is now powering your AI creative systems.** ð¯
```

---

## ERROR HANDLING

### Source Failures
Display:
```
â ï¸ Could not access: [URL] ([Reason])
â Skipping this source
â Continuing with other sources
â This may create gaps in [specific dimension]
```

Continue with valid sources.

### Agent Failures
Display:
```
â ï¸ [Agent name] encountered an issue
â Partial data collected: [What we got]
â Gap noted: [What's missing]
â You can fill this gap during review or edit files later
```

Proceed with partial data.

### Complete Failure
Display:
```
â Unable to extract Brand DNA from provided sources.

**Possible causes**:
- All sources are inaccessible
- Sources lack sufficient content
- Technical error

**Please try**:
1. Verify URLs/file paths are correct
2. Provide additional sources
3. Check internet connection
4. Re-run this skill
```

---

## QUALITY GATES

- Phase 1 â 2: User must provide at least one source
- Phase 2 â 3: At least one source must validate successfully
- Phase 3 â 4: At least 4 of 7 agents must succeed
- Phase 4 â 5: Overall quality must be 40%+ (confirm with user if < 60%)
- Phase 5 â 6: All 8 files must be generated with content
- Phase 6 â 7: User must provide location
- Phase 7 â 8: All files must be written successfully

---

*Personal Brand DNA Extractor v1.0*
*Created: January 2026*
*Methodology: Strategic Builder + Dispatcher/Manager*
