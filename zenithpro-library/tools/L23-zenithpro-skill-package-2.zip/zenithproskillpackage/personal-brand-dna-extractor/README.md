# Personal Brand DNA Extractor v1.0

**Extracts your unique brand DNA from existing materials and creates 8 AI-optimized files that power all copywriting and webinar systems with YOUR voice, YOUR stories, YOUR credentials.**

---

## What This Does

When you run `/personal-brand-dna-extractor`, this skill automatically:

1. **Collects Materials** - Gathers your website, social profiles, documents, testimonials
2. **Validates Sources** - Checks accessibility and organizes by type
3. **Spawns 7 Specialist Agents** - Each extracts a different dimension of your brand:
   - Voice Archaeologist - Writing patterns, signature phrases
   - Credibility Architect - Quantified achievements, authority claims
   - Testimonial Curator - Social proof organized by strength
   - Story Miner - Origin stories with "when to use" context
   - Results Tracker - Client transformations with metrics
   - Humanizer - Personal details and humanizing elements
   - Philosophy Distiller - Frameworks, contrarian beliefs, principles
4. **Synthesizes & Formats** - Organizes all findings into AI-optimized markdown files
5. **Delivers 8 Files** - Ready to use with Arena systems and expert skills

**Result:** Instead of generic AI output, every Arena competition and expert skill writes in YOUR authentic voice.

---

## What You'll Get

### The 8 Brand DNA Files

1. **01-VOICE-AND-TONE.md** - Your writing patterns, signature phrases, persuasion style
2. **02-CREDENTIALS.md** - Quantified achievements, authority claims, scale markers
3. **03-TESTIMONIALS.md** - Organized social proof, tiered by strength
4. **04-ORIGIN-STORIES.md** - Your narrative with "when to use" context
5. **05-MENTEES-AND-CLIENTS.md** - Client transformations, documented results
6. **06-PERSONAL-DETAILS.md** - Humanizing elements, background, interests
7. **07-CORE-PHILOSOPHY.md** - Frameworks, contrarian beliefs, principles
8. **CLAUDE.md** - Index file and usage guide

### Quality Targets

Each agent has specific quality targets:
- **Voice Patterns**: 20+ signature phrases, 10+ sentence patterns
- **Credentials**: 10+ quantified achievements
- **Testimonials**: 20+ testimonials across 3 tiers
- **Stories**: 10+ stories across 4 layers
- **Results**: 15+ client transformations
- **Personal Details**: 10+ interests, complete profile
- **Philosophy**: 3+ frameworks, 5+ contrarian beliefs

### Where Files Are Saved

You choose the location during extraction:
- **Project folder**: `[Your Project]/_AI-COPYWRITING-RESOURCES/`
- **Skills folder**: `~/.claude/skills/[your-name]-brand-dna/`
- **Both locations**: Recommended for easy review + global access

---

## Who This Is For

- **ZenithPro members** using Arena systems and want personalized output
- **AI Team Training students** who want webinars and copy in their voice
- **Entrepreneurs and consultants** building thought leadership content
- **Course creators** who want AI to capture their teaching style
- **Anyone** tired of generic AI-generated content

---

## How It Works

### Phase 1: Material Collection (5 min)
You provide:
- Website URL
- LinkedIn profile (optional)
- Other social profiles (optional)
- Documents/transcripts (optional)
- Testimonials page URL (optional)

**Minimum required:** At least one accessible source

### Phase 2: Validation (1 min)
System validates all sources and shows what's accessible

### Phase 3: Parallel Extraction (10-15 min)
7 agents run simultaneously analyzing all materials

### Phase 4: Quality Assessment (2 min)
System scores extractions and identifies gaps
- Offers gap-filling if quality is low (optional)

### Phase 5: Synthesis (5 min)
Organizes all data into template structure

### Phase 6: User Review (5 min - optional)
You can review and correct files before finalization

### Phase 7: Delivery (1 min)
Generates and saves all 8 files to your chosen location

### Phase 8: Usage Guide
Shows you how to use your Brand DNA with Arena systems and expert skills

**Total Time: 20-30 minutes**

---

## What Makes This Powerful

### Before Brand DNA
When you run `/webinar-arena` or any expert skill:
- Generic AI voice
- No personal stories
- Vague credentials
- Missing social proof
- Generic examples

### After Brand DNA
Same skills automatically:
- Write in YOUR voice (signature phrases, tone, style)
- Use YOUR stories (with context for when to use each)
- Reference YOUR credentials (quantified achievements)
- Include YOUR testimonials (organized by strength)
- Apply YOUR frameworks (proprietary methodologies)

**No extra work required.** The Brand DNA files are detected and loaded automatically.

---

## Requirements

Before installing, you'll need:

1. **Claude Code** installed and working
2. **Materials to analyze**: Website, LinkedIn, or documents
3. **20-30 minutes** for the extraction process

That's it. No API keys, no Python dependencies, no complex setup.

---

## Installation

### Mac/Linux (Terminal)

```bash
cd ~/Downloads/personal-brand-dna-extractor
chmod +x install.sh
./install.sh
```

### Windows (PowerShell)

```powershell
cd ~/Downloads/personal-brand-dna-extractor
.\install.ps1
```

The installer will:
1. Create `~/.claude/skills/personal-brand-dna-extractor/` directory
2. Copy the skill file
3. Verify installation
4. Show you how to use it

Takes about 5 seconds.

---

## Usage

After installation, open Claude Code and say:

```
/personal-brand-dna-extractor
```

Or simply:

```
Extract my brand DNA
```

Claude will guide you through the 8-phase process.

### First-Time Extraction

**What to have ready:**
1. Your main website URL
2. LinkedIn profile URL (optional but recommended)
3. Path to any documents you want analyzed (optional)
4. URL to testimonials page (optional)

**Tip:** The more sources you provide, the richer your Brand DNA will be.

### Using Your Brand DNA

Once extracted, your Brand DNA is automatically used by:

**Webinar Arena:**
```
/webinar-arena
```
All 6 experts create webinars in YOUR voice

**Individual Expert Skills:**
```
/clayton
/deutsch
/webinar-fladlien
/webinar-brunson
```
Each expert uses your Brand DNA automatically

**Manual Reference:**
Open any of the 7 content files and copy-paste when writing copy yourself

---

## What Each Agent Does

### Voice Archaeologist (Dr. James Liu)
Extracts your writing DNA:
- Signature phrases (recurring expressions)
- Sentence patterns (structure, rhythm)
- Tone characteristics (authority, formality, emotion)
- Persuasion techniques
- Contrarian positions

**Output:** 01-VOICE-AND-TONE.md

### Credibility Architect (Dr. Elena Vasquez)
Quantifies your authority:
- Numbers-based achievements
- Industry firsts and innovations
- Formal credentials
- Scale markers (clients, revenue, years)
- Media coverage and recognition

**Output:** 02-CREDENTIALS.md

### Testimonial Curator (Dr. Elena Vasquez)
Organizes social proof:
- Tier 1: Legendary testimonials (best for sales pages)
- Tier 2: Strong testimonials (trust-building)
- Tier 3: Community testimonials (volume)
- Case studies with before/after metrics
- Indirect proof (logos, speaking, associations)

**Output:** 03-TESTIMONIALS.md

### Story Miner (Marcus Chen)
Extracts narratives:
- Personal origin story
- Business origin story
- Breakthrough moments
- Failure/struggle stories
- Client transformation stories
- "How I discovered X" stories

**Output:** 04-ORIGIN-STORIES.md

### Results Tracker (Dr. Elena Vasquez)
Documents transformations:
- Financial results (revenue, profit, growth)
- Time freedom results (hours, lifestyle)
- Impact/scale results (clients served, reach)
- Satisfaction/fulfillment results
- All with before/after metrics

**Output:** 05-MENTEES-AND-CLIENTS.md

### Humanizer (Marcus Chen)
Makes you 3-dimensional:
- Location and geography
- Personal background
- Hobbies and interests
- Personality traits
- Values and beliefs
- Fun facts and quirks

**Output:** 06-PERSONAL-DETAILS.md

### Philosophy Distiller (Dr. Maya Patel)
Captures your thinking:
- Proprietary frameworks
- Core principles
- Contrarian beliefs
- Mental models
- Recurring themes

**Output:** 07-CORE-PHILOSOPHY.md

---

## Quality Assurance

### Self-Assessment
Each agent self-assesses quality and reports confidence level

### Quality Scoring
System calculates overall quality score (target: 85%+)

### Gap Identification
If quality is low (<60%), system identifies specific gaps

### Gap-Filling (Optional)
You can answer targeted questions to fill critical gaps

### Manual Editing
All files are standard Markdown - edit anytime

---

## Updating Your Brand DNA

### When to Update
- New major achievement
- New testimonials collected
- Voice/style evolution
- New frameworks developed
- Significant life changes

### How to Update
Simply re-run the extraction:
```
/personal-brand-dna-extractor
```

Choose whether to:
- Overwrite existing files (fresh start)
- Save to new location (compare versions)
- Manually merge (best of both)

---

## Technical Details

### Agent Architecture
- **7 specialized agents** run in parallel
- Each has distinct persona and expertise
- All use same validated sources
- Independent extraction with cross-referencing
- Quality gates at 70%, 85%, 95% thresholds

### File Format
- Standard Markdown (.md files)
- AI-optimized structure
- Human-readable and editable
- Compatible with all Arena systems

### Privacy
- All processing happens locally
- No data sent to external services
- Files stored on your machine only
- You control where files are saved

---

## Troubleshooting

### "All sources are inaccessible"
- Verify URLs are correct and publicly accessible
- Try providing file paths to local documents instead
- Check internet connection

### "Quality score is too low"
- Provide more sources (website + LinkedIn + documents works best)
- Use gap-filling option to answer targeted questions
- Manually edit files after extraction

### "Agent failed"
- System will continue with other agents
- Partial data is better than no data
- You can manually edit files to fill gaps

### "Can't find my Brand DNA files"
- Check project folder: `_AI-COPYWRITING-RESOURCES/`
- Check skills folder: `~/.claude/skills/[name]-brand-dna/`
- Re-run extraction and note the save location

---

## Integration with Other Systems

### Webinar Arena v2.0
Automatically detects and loads Brand DNA before spawning experts

### Individual Copywriter Skills
- `/clayton`, `/deutsch`, `/evaldo`, `/carlton`
- Each detects and loads Brand DNA automatically

### Individual Webinar Skills
- `/webinar-fladlien`, `/webinar-brunson`, `/webinar-cage`
- `/webinar-kern`, `/webinar-joon`, `/webinar-kennedy`
- Each detects and loads Brand DNA automatically

### Manual Integration
For any skill that doesn't auto-detect:
- Copy relevant sections from Brand DNA files
- Paste into prompts or context
- Reference specific elements as needed

---

## Best Practices

### For Best Results
1. **Provide multiple sources** - Website + LinkedIn + documents gives richest extraction
2. **Include testimonials page** - Critical for social proof extraction
3. **Use gap-filling** - Answer targeted questions if quality is low
4. **Review before finalizing** - Quick review catches any obvious errors
5. **Update regularly** - Re-run extraction when you have new achievements

### What NOT to Do
1. **Don't provide private materials** - Only use publicly shared content
2. **Don't skip validation** - Let system check sources before extraction
3. **Don't ignore gaps** - Low-quality extraction means Arena output will be generic
4. **Don't overwrite without backup** - Save to new location first if unsure

---

## Support

### Questions?
- Check this README first
- Review the SKILL.md file for technical details
- Test with a small extraction to see how it works

### Issues?
- Verify Claude Code is up to date
- Check that sources are accessible
- Try with fewer sources to isolate problem

---

## Version History

**v1.0.0** (January 2026)
- Initial release
- 7 specialist agents
- 8 output files
- Parallel extraction
- Quality assessment
- Gap-filling
- User review
- Auto-integration with Arena systems

---

## Credits

Created by Rich Schefren - Strategic Profits

Part of the ZenithPro program and AI Team Training curriculum.

---

**Ready to give Arena systems your unique voice?**

Install now and run your first extraction.
