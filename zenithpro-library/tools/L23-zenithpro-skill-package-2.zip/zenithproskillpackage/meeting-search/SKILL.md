# Meeting Transcript Search

Search and query meeting transcripts from Fireflies AI, Read AI, and Limitless AI stored in Obsidian.

## Folder Structure

```
01 Strategic Profits/2026 Meetings/
âââ Scheduled Meetings/     (Fireflies + Read AI - formal meetings)
âââ Pendant Recordings/     (Limitless - continuous capture)
```

## Quick Search Commands

### Search by Person
Find all meetings with a specific person:
```bash
grep -rl "Nicole" "~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/01 Strategic Profits/2026 Meetings/" --include="*.md"
```

### Search by Topic/Keyword
Find meetings mentioning a topic:
```bash
grep -rl "ZenithPro" "~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/01 Strategic Profits/2026 Meetings/" --include="*.md"
```

### Search with Context
Show matching lines with surrounding context:
```bash
grep -r "marketing strategy" "~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/01 Strategic Profits/2026 Meetings/" --include="*.md" -B 2 -A 2
```

### List by Date
Find meetings from a specific date:
```bash
ls "~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/01 Strategic Profits/2026 Meetings/Scheduled Meetings/" | grep "2026-01-15"
```

## YAML Frontmatter Fields

All meeting files include searchable metadata:

```yaml
---
date: 2026-01-15
source: Fireflies AI | Read AI | Limitless AI
type: "ZenithPro Session" | "1:1 Meeting" | "Copy Clinic" | etc.
participants:
  - "Rich Schefren"
  - "Nicole M"
topics:
  - "Marketing strategy"
  - "Product launch"
duration: 45m 30s
url: "https://..."
---
```

## Obsidian Dataview Queries

### All Meetings with a Person
```dataview
TABLE type, date, duration
FROM "01 Strategic Profits/2026 Meetings"
WHERE contains(participants, "Nicole M")
SORT date DESC
```

### Meetings by Type
```dataview
TABLE participants, date
FROM "01 Strategic Profits/2026 Meetings"
WHERE type = "ZenithPro Session"
SORT date DESC
```

### Meetings by Topic
```dataview
TABLE type, participants, date
FROM "01 Strategic Profits/2026 Meetings"
WHERE contains(topics, "marketing")
SORT date DESC
```

### Recent Meetings (Last 7 Days)
```dataview
TABLE type, participants, source
FROM "01 Strategic Profits/2026 Meetings"
WHERE date >= date(today) - dur(7 days)
SORT date DESC
```

### All 1:1 Meetings
```dataview
TABLE participants, date, duration
FROM "01 Strategic Profits/2026 Meetings"
WHERE type = "1:1 Meeting"
SORT date DESC
```

### Meetings by Source
```dataview
TABLE type, participants, date
FROM "01 Strategic Profits/2026 Meetings"
WHERE source = "Limitless AI"
SORT date DESC
```

### Meetings with Action Items
```dataview
TABLE type, participants, date
FROM "01 Strategic Profits/2026 Meetings"
WHERE contains(file.content, "- [ ]")
SORT date DESC
```

## Known Participants

The system recognizes these team members:
- Rich Schefren (CEO/Founder)
- Nicole M (Operations Lead)
- Ashley Shaw (Growth/Sales)
- Michelle Mattison (Marketing Manager)
- Tom Hammaker (Growth Partner)
- Ben Thole (Tech Lead)
- Jessica Middlebrook (Executive Assistant)
- Joseph Conrad (Creative Lab)
- Katrine (Customer Service)
- Irish Arenal (Publishing Tech)
- Jem Erroba (Creative/Design)

## Meeting Types

The system detects these meeting types:
- ZenithPro Session
- ZenithMind Session
- Copy Clinic
- Office Hours
- 1:1 Meeting
- Strategic Partner Call
- SOW Session
- Team Meeting
- Copywriter Call
- Client Call
- Interview
- Webinar
- Workshop
- Bonus Q&A
- Expert Session

## Common Search Scenarios

### "What did Rich and Nicole discuss last week?"
```bash
grep -rl "Nicole" "~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/01 Strategic Profits/2026 Meetings/Scheduled Meetings/" --include="2026-01-1*.md"
```

### "Find all ZenithPro sessions"
```bash
grep -l 'type: "ZenithPro Session"' "~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/01 Strategic Profits/2026 Meetings/"*/*.md
```

### "What meetings mentioned the product launch?"
```bash
grep -rl "product launch\|launch\|launching" "~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/01 Strategic Profits/2026 Meetings/" --include="*.md"
```

### "Show me the transcript from yesterday's meeting with Ashley"
```bash
# Find the file
ls "~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/01 Strategic Profits/2026 Meetings/Scheduled Meetings/" | grep "$(date -v-1d +%Y-%m-%d)"
# Then read the specific file
```

### "What action items came from meetings this week?"
```bash
grep -r "- \[ \]" "~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/01 Strategic Profits/2026 Meetings/" --include="2026-01-1*.md"
```

## Integration with Download Skills

This skill works with:
- `fireflies-downloader` - Downloads from Fireflies AI
- `read-ai-downloader` - Downloads from Read AI
- `limitless-downloader` - Downloads from Limitless AI

All downloaders save to the same folder structure with consistent YAML frontmatter tags.

## iMessage Search (Supplementary)

For comprehensive conversation history, also search iMessages:

### Find Group Chats by Participants
```bash
sqlite3 ~/Library/Messages/chat.db "
SELECT c.chat_identifier, GROUP_CONCAT(h.id, ', ') as participants
FROM chat c
JOIN chat_handle_join chj ON c.ROWID = chj.chat_id
JOIN handle h ON h.ROWID = chj.handle_id
WHERE c.chat_identifier LIKE 'chat%'
GROUP BY c.chat_identifier
HAVING participants LIKE '%PHONE_NUMBER%'
LIMIT 10;"
```

### Read Messages from a Chat
```bash
sqlite3 ~/Library/Messages/chat.db "
SELECT
    datetime(m.date/1000000000 + strftime('%s','2001-01-01'), 'unixepoch', 'localtime') as date,
    CASE WHEN m.is_from_me = 1 THEN 'Rich' ELSE 'Other' END as sender,
    m.text
FROM message m
JOIN chat_message_join cmj ON m.ROWID = cmj.message_id
JOIN chat c ON c.ROWID = cmj.chat_id
WHERE c.chat_identifier = 'CHAT_IDENTIFIER'
AND m.text IS NOT NULL
ORDER BY m.date DESC
LIMIT 50;"
```

### Key Team Phone Numbers
Look up contacts in AddressBook database:
```bash
sqlite3 ~/Library/Application\ Support/AddressBook/Sources/*/AddressBook-v22.abcddb "
SELECT r.ZFIRSTNAME, r.ZLASTNAME, p.ZFULLNUMBER
FROM ZABCDRECORD r
LEFT JOIN ZABCDPHONENUMBER p ON r.Z_PK = p.ZOWNER
WHERE r.ZFIRSTNAME LIKE '%NAME%' AND p.ZFULLNUMBER IS NOT NULL;"
```

## Tips

1. **Use Scheduled Meetings for formal calls** - These have better transcription quality
2. **Use Pendant Recordings for ambient context** - Captures informal conversations
3. **Combine grep with file reading** - Find files first, then read the relevant ones
4. **Use Dataview for Obsidian** - More powerful queries with metadata
5. **Search YAML frontmatter** - Faster than full-text search for participants/topics
