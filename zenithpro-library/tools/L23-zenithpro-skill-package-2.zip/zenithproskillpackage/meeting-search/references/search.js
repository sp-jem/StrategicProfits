#!/usr/bin/env node
/**
 * Meeting Transcript Search Tool
 *
 * Quick search across all meeting transcripts from Fireflies, Read AI, and Limitless.
 *
 * Usage:
 *   node search.js "keyword"                    # Search all meetings
 *   node search.js --person "Nicole"            # Find meetings with person
 *   node search.js --type "ZenithPro"           # Find by meeting type
 *   node search.js --date "2026-01-15"          # Find by date
 *   node search.js --topic "marketing"          # Find by topic
 *   node search.js --recent 7                   # Last 7 days
 *   node search.js --actions                    # Find meetings with action items
 */

const fs = require('fs');
const path = require('path');

const BASE_DIR = '~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/01 Strategic Profits/2026 Meetings';
const SCHEDULED_DIR = path.join(BASE_DIR, 'Scheduled Meetings');
const PENDANT_DIR = path.join(BASE_DIR, 'Pendant Recordings');

function getAllMeetingFiles() {
  const files = [];

  // Get scheduled meetings
  if (fs.existsSync(SCHEDULED_DIR)) {
    fs.readdirSync(SCHEDULED_DIR)
      .filter(f => f.endsWith('.md'))
      .forEach(f => files.push({ path: path.join(SCHEDULED_DIR, f), type: 'scheduled' }));
  }

  // Get pendant recordings
  if (fs.existsSync(PENDANT_DIR)) {
    fs.readdirSync(PENDANT_DIR)
      .filter(f => f.endsWith('.md'))
      .forEach(f => files.push({ path: path.join(PENDANT_DIR, f), type: 'pendant' }));
  }

  return files;
}

function parseYAMLFrontmatter(content) {
  const match = content.match(/^---\n([\s\S]*?)\n---/);
  if (!match) return {};

  const yaml = {};
  const lines = match[1].split('\n');
  let currentKey = null;
  let currentArray = null;

  lines.forEach(line => {
    if (line.match(/^(\w+):\s*$/)) {
      // Array start
      currentKey = line.match(/^(\w+):/)[1];
      currentArray = [];
      yaml[currentKey] = currentArray;
    } else if (line.match(/^\s+-\s+"?(.+?)"?$/)) {
      // Array item
      if (currentArray) {
        currentArray.push(line.match(/^\s+-\s+"?(.+?)"?$/)[1]);
      }
    } else if (line.match(/^(\w+):\s*"?(.+?)"?$/)) {
      // Key: value
      const [, key, value] = line.match(/^(\w+):\s*"?(.+?)"?$/);
      yaml[key] = value;
      currentKey = null;
      currentArray = null;
    }
  });

  return yaml;
}

function searchFiles(files, options) {
  const results = [];

  files.forEach(({ path: filePath, type }) => {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const yaml = parseYAMLFrontmatter(content);
      const filename = path.basename(filePath);

      let match = true;

      // Keyword search
      if (options.keyword) {
        const lower = content.toLowerCase();
        match = match && lower.includes(options.keyword.toLowerCase());
      }

      // Person search
      if (options.person) {
        const participants = yaml.participants || [];
        const lower = options.person.toLowerCase();
        match = match && (
          participants.some(p => p.toLowerCase().includes(lower)) ||
          content.toLowerCase().includes(lower)
        );
      }

      // Type search
      if (options.type) {
        match = match && yaml.type && yaml.type.toLowerCase().includes(options.type.toLowerCase());
      }

      // Date search
      if (options.date) {
        match = match && filename.includes(options.date);
      }

      // Topic search
      if (options.topic) {
        const topics = yaml.topics || [];
        const lower = options.topic.toLowerCase();
        match = match && (
          topics.some(t => t.toLowerCase().includes(lower)) ||
          content.toLowerCase().includes(lower)
        );
      }

      // Recent days
      if (options.recent) {
        const dateMatch = filename.match(/^(\d{4}-\d{2}-\d{2})/);
        if (dateMatch) {
          const fileDate = new Date(dateMatch[1]);
          const cutoff = new Date();
          cutoff.setDate(cutoff.getDate() - options.recent);
          match = match && fileDate >= cutoff;
        }
      }

      // Action items
      if (options.actions) {
        match = match && content.includes('- [ ]');
      }

      if (match) {
        results.push({
          file: filename,
          path: filePath,
          type: type,
          date: yaml.date || 'unknown',
          meetingType: yaml.type || 'unknown',
          participants: yaml.participants || [],
          source: yaml.source || 'unknown',
          duration: yaml.duration || ''
        });
      }
    } catch (e) {
      // Skip files that can't be read
    }
  });

  return results;
}

function printResults(results, showContent = false) {
  if (results.length === 0) {
    console.log('\nNo matching meetings found.\n');
    return;
  }

  console.log(`\nFound ${results.length} matching meetings:\n`);
  console.log('â'.repeat(80));

  results.forEach((r, i) => {
    console.log(`${i + 1}. ${r.file}`);
    console.log(`   Type: ${r.meetingType} | Source: ${r.source} | Date: ${r.date}`);
    if (r.participants.length > 0) {
      console.log(`   Participants: ${r.participants.slice(0, 5).join(', ')}${r.participants.length > 5 ? '...' : ''}`);
    }
    if (r.duration) {
      console.log(`   Duration: ${r.duration}`);
    }
    console.log('');
  });

  console.log('â'.repeat(80));
  console.log(`Total: ${results.length} meetings\n`);
}

// Parse command line arguments
const args = process.argv.slice(2);
const options = {};

for (let i = 0; i < args.length; i++) {
  if (args[i] === '--person' && args[i + 1]) {
    options.person = args[++i];
  } else if (args[i] === '--type' && args[i + 1]) {
    options.type = args[++i];
  } else if (args[i] === '--date' && args[i + 1]) {
    options.date = args[++i];
  } else if (args[i] === '--topic' && args[i + 1]) {
    options.topic = args[++i];
  } else if (args[i] === '--recent' && args[i + 1]) {
    options.recent = parseInt(args[++i]);
  } else if (args[i] === '--actions') {
    options.actions = true;
  } else if (!args[i].startsWith('--')) {
    options.keyword = args[i];
  }
}

// Show help if no options
if (Object.keys(options).length === 0) {
  console.log(`
Meeting Transcript Search
âââââââââââââââââââââââââ

Usage:
  node search.js "keyword"              Search all meetings for keyword
  node search.js --person "Nicole"      Find meetings with person
  node search.js --type "ZenithPro"     Find by meeting type
  node search.js --date "2026-01-15"    Find by date
  node search.js --topic "marketing"    Find by topic
  node search.js --recent 7             Last N days
  node search.js --actions              Meetings with action items

Examples:
  node search.js --person "Rich" --recent 7
  node search.js --type "1:1" --person "Nicole"
  node search.js "product launch"
`);
  process.exit(0);
}

// Run search
console.log('\nð Searching meeting transcripts...');
const files = getAllMeetingFiles();
console.log(`   Scanning ${files.length} files...`);

const results = searchFiles(files, options);
results.sort((a, b) => b.date.localeCompare(a.date)); // Sort by date desc

printResults(results);
