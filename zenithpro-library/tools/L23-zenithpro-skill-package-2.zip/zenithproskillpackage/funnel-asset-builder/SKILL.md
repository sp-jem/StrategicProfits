---
name: funnel-asset-builder
description: |
  Orchestrate full funnel asset production for any client. Takes markdown copy + brand assets and produces all HTML pages, PDFs, and shareable packages. Use when asked to "build the funnel assets", "produce the funnel", "create all funnel pieces", "funnel production for [client]", "build all the pages", or "make all the assets".
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, Agent
---

# Funnel Asset Builder

Orchestrate the complete funnel asset production pipeline. Takes a client's markdown copy and brand assets and produces production-ready HTML pages, PDFs, and self-contained shareable packages.

**This is the master orchestrator.** It calls three sub-skills in the correct order:
1. `brand-html-converter` — Markdown → Branded HTML
2. `lead-magnet-pdf-builder` — HTML → Print-ready PDF
3. `html-share-packager` — HTML → Self-contained shareable HTML

---

## STEP 1: SOURCE DISCOVERY

Locate everything for the client:

```bash
# Client folder
[YOUR_CLIENT_FOLDER]/

# Required sources
├── Brand/*Brand*.md           # Brand reference (colors, fonts)
├── Brand/*.png, *.jpg         # Logo files, headshots
├── Deliverables/*.md          # Markdown copy files
└── Voice DNA                  # .claude/skills/[client]-voice/SKILL.md
                               # OR Downloads/*voice*.md

# Optional sources
├── *MASTER*Funnel*.md         # Funnel master (pricing, flow)
├── *Tripwire*.md              # Tripwire copy
├── Landing Pages/*.md         # Landing page copy
└── *Thank*You*.md             # Thank you page spec
```

### Asset Type Detection

Scan the Deliverables and related folders for markdown files. Classify each:

| Filename Pattern | Asset Type | Output |
|-----------------|-----------|--------|
| `*Lead-Magnet*`, `*5-Money*`, `*Guide*` | lead-magnet | HTML + PDF |
| `*Landing*Page*` | landing-page | HTML + SHARE |
| `*Thank*You*` | thank-you-page | HTML + SHARE |
| `*Welcome*Email*`, `*Email*` | email-mockup | HTML + PDF |
| `*Tripwire*Sales*` | landing-page (sales) | HTML + SHARE |

---

## STEP 2: INVENTORY & CONFIRM

Present to user before building:

```markdown
## Funnel Asset Production Plan

**Client:** [Name]
**Brand Reference:** [path] ✓
**Voice DNA:** [path] ✓ (or ✗ — will use neutral tone)

### Assets to Build

| # | Source File | Asset Type | Outputs |
|---|-----------|-----------|---------|
| 1 | [filename.md] | lead-magnet | HTML, PDF |
| 2 | [filename.md] | landing-page | HTML, SHARE |
| 3 | [filename.md] | thank-you-page | HTML, SHARE |
| 4 | [filename.md] | email-mockup | HTML, PDF |

### Image Assets Available
- [list logos, headshots, other images]

### Missing Items
- [anything not found that's needed]

**Proceed with build?**
```

Wait for user confirmation unless CLAUDE.md standing authorizations apply.

---

## STEP 3: BUILD SEQUENCE

Execute in dependency order:

```
Phase A: HTML Production (can be parallel if independent)
─────────────────────────────────────────────────────────
1. Read brand reference → Extract CSS custom properties
2. Read Voice DNA → Extract sign-off, tone, avoid-list
3. For each asset (in order):
   a. Read source markdown
   b. Apply brand-html-converter logic
   c. Save HTML to Deliverables/
   d. Run voice compliance check

Phase B: PDF Generation (depends on Phase A)
─────────────────────────────────────────────
4. For each PDF-destined asset:
   a. Verify print CSS
   b. Run lead-magnet-pdf-builder
   c. Save PDF to Desktop
   d. Verify no clipping

Phase C: Share Packaging (depends on Phase A)
─────────────────────────────────────────────
5. For each share-destined asset:
   a. Run html-share-packager
   b. Save SHARE HTML to Desktop
   c. Verify offline rendering
```

### Build Order Priority

1. **Lead magnet** — Core asset, everything else references it
2. **Landing page** — Drives traffic to lead magnet
3. **Thank you page** — Post-download experience
4. **Welcome email** — Immediate follow-up
5. **Tripwire/sales page** — If applicable

---

## STEP 4: QUALITY GATES

Run after EACH asset (not just at the end):

### Per-Asset Checks
- [ ] Brand colors match hex values from brand reference
- [ ] Font stack correct with fallbacks
- [ ] Logo renders (correct variant for background)
- [ ] No placeholder text (no `[PLACEHOLDER]`, no `#` hrefs)
- [ ] Sign-off matches Voice DNA
- [ ] No fabricated content
- [ ] Visual variety (no 3+ white sections in a row)

### Landing Page Specific
- [ ] Form above the fold
- [ ] Email-only field (reduce friction)
- [ ] Social proof visible
- [ ] CTA buttons: accent color, 18px+, uppercase, first-person copy
- [ ] Form inputs visible against background

### PDF Specific
- [ ] File size reasonable (>50KB)
- [ ] No blank pages
- [ ] Last page not clipped
- [ ] Sign-off visible

### Share Package Specific
- [ ] Opens without network
- [ ] All images render
- [ ] Fonts display correctly
- [ ] File size <25MB for email attachment

---

## STEP 5: DELIVERY

### File Placement

```
Deliverables/ (canonical versions)
├── [Asset-Name].html          # Branded HTML
├── [Asset-Name]-Copy.md       # Source markdown (if not already there)
└── [images used by HTML]      # Copied here if not already present

Desktop/ (for sharing)
├── [Asset-Name]-SHARE.html    # Self-contained version
├── [Asset-Name].pdf           # Print-ready PDF
└── [Asset-Name]-SHARE.html    # (each share asset)
```

### Delivery Manifest

After all assets are built, present:

```markdown
## Delivery Manifest

**Client:** [Name]
**Date:** [Date]
**Quality Level:** [STANDARD/ELEVATED/CRITICAL]

### Produced Assets

| Asset | Deliverables/ | Desktop/ | Status |
|-------|-------------|----------|--------|
| Lead Magnet | ✓ HTML | ✓ PDF | PASS |
| Landing Page | ✓ HTML | ✓ SHARE | PASS |
| Thank You Page | ✓ HTML | ✓ SHARE | PASS |
| Welcome Email | ✓ HTML | ✓ PDF | PASS |

### Quality Summary
- Voice compliance: [PASS/FAIL]
- Brand compliance: [PASS/FAIL]
- Source verification: [PASS/FAIL]
- Technical quality: [PASS/FAIL]

### Open Items
- [Any placeholders, missing URLs, items needing client input]
```

---

## STEP 6: POST-BUILD

After delivery:
1. Suggest running voice critic if one exists for the client
2. Note any URLs that need to be filled in (booking links, scorecard URLs)
3. Flag any social proof numbers that need client verification
4. Recommend CRO audit for landing pages via dedicated agent

---

## INTEGRATION

This skill orchestrates:
- `brand-html-converter` — HTML production
- `lead-magnet-pdf-builder` — PDF generation
- `html-share-packager` — Share packaging

Quality review via:
- `[client]-critic` — Voice compliance
- `funnel-qc-agent` — Full quality audit

Works alongside:
- `funnel-one-pager` — Defines what to build
- `email-sequence-architect` — Writes the email copy
- `landing-page-copy` — Writes landing page copy
- `offer-architect` — Defines offer structure

---
