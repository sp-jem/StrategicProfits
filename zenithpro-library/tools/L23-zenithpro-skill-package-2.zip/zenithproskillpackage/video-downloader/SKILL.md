---
name: sp-video-downloader
description: Downloads videos from YouTube and other platforms for offline viewing, editing, or archival. Handles various formats and quality options.
---

# Video Downloader

This skill downloads videos from YouTube and other platforms directly to your computer.

## When to Use This Skill

- Downloading YouTube videos for offline viewing
- Saving educational content for reference
- Archiving important videos
- Getting video files for editing or repurposing
- Downloading your own content from platforms
- Saving conference talks or webinars
- **Downloading transcripts from YouTube channels or playlists**

## What This Skill Does

1. **Downloads Videos**: Fetches videos from YouTube and other platforms
2. **Quality Selection**: Lets you choose resolution (480p, 720p, 1080p, 4K)
3. **Format Options**: Downloads in various formats (MP4, WebM, audio-only)
4. **Batch Downloads**: Can download multiple videos or playlists
5. **Metadata Preservation**: Saves title, description, and thumbnail
6. **Transcript Downloads**: Downloads transcripts from channels, playlists, or individual videos

## How to Use

### Basic Download

```
Download this YouTube video: https://youtube.com/watch?v=...
```

```
Download this video in 1080p quality
```

### Audio Only

```
Download the audio from this YouTube video as MP3
```

### Playlist Download

```
Download all videos from this YouTube playlist: [URL]
```

### Batch Download

```
Download these 5 YouTube videos:
1. [URL]
2. [URL]
...
```

## YouTube Transcript Downloader

For downloading transcripts (not video files), use the script in Mission Control:
`{VAULT}/00 Mission Control/youtube-transcripts/`

### Quick Start Commands

```bash
cd "{VAULT}/00 Mission Control/youtube-transcripts"

# Download from a channel (only videos with captions)
python3 download_transcripts_v2.py --channel CHANNEL_NAME

# Download from a channel (ALL videos - uses Deepgram for those without captions)
python3 download_transcripts_v2.py --channel CHANNEL_NAME --deepgram

# Limit to first N videos (good for testing)
python3 download_transcripts_v2.py --channel CHANNEL_NAME --deepgram --limit 10

# Custom output location
python3 download_transcripts_v2.py --channel CHANNEL_NAME --deepgram --output ~/Desktop/transcripts
```

### Script Options

- `--channel, -c` - YouTube channel name (without @)
- `--deepgram, -d` - Use Deepgram as fallback when no captions available
- `--threads, -t` - Number of parallel threads (default: 10)
- `--limit, -l` - Limit number of videos to process
- `--output, -o` - Output directory
- `--name, -n` - Output file name (without extension)

### Output Files

Scripts generate two files:
- **Markdown (.md)** - Human-readable with video titles, URLs, and full transcripts
- **JSON (.json)** - Machine-readable format for further processing

Default output location: `~/Documents/youtube_transcripts/`

## Example

**User**: "Download this YouTube video: https://youtube.com/watch?v=abc123"

**Output**:
```
Downloading from YouTube...

Video: "How to Build Products Users Love"
Channel: Lenny's Podcast
Duration: 45:32
Quality: 1080p

Progress: Ã¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂÃ¢ÂÂ 100%

Ã¢ÂÂ Downloaded: how-to-build-products-users-love.mp4
Ã¢ÂÂ Saved thumbnail: how-to-build-products-users-love.jpg
Ã¢ÂÂ Size: 342 MB

Saved to: ~/Downloads/
```

**Inspired by:** Lenny's workflow from his newsletter

## Important Notes

Ã¢ÂÂ Ã¯Â¸Â **Copyright & Fair Use**
- Only download videos you have permission to download
- Respect copyright laws and platform terms of service
- Use for personal, educational, or fair use purposes
- Don't redistribute copyrighted content

## Tips

- Specify quality if you need lower file size (720p vs 1080p)
- Use audio-only for podcasts or music to save space
- Download to a dedicated folder to stay organized
- Check file size before downloading on slow connections
- For transcripts, use `--deepgram` flag for videos without auto-captions

## Common Use Cases

- **Education**: Save tutorials and courses for offline learning
- **Research**: Archive videos for reference
- **Content Creation**: Download your own content from platforms
- **Backup**: Save important videos before they're removed
- **Offline Viewing**: Watch videos without internet access
- **Transcript Library**: Build a searchable library of video transcripts

