---
name: sop-factory
description: Converts Marshall's verbal descriptions, recorded sessions, meeting notes, or existing rough documents into clean, executable Standard Operating Procedures. Built specifically for Studio Money's situation â tribal knowledge locked in Marshall's head, small team of 3 direct reports, and no existing PM tool. Use when Marshall says "document this process," "write up how we do X," "turn this into an SOP," "my team keeps asking me how to do this," or any time a repeatable process needs to be captured.
license: proprietary
vault_path: "[YOUR_VAULT]/Marshall Sylver/SOPs/"
metadata:
tags:
  - program/ctd
---
# SOP Factory

Converts verbal descriptions and rough notes into clean, immediately executable Standard Operating Procedures for Studio Money. Ends the cycle of Marshall being interrupted to explain recurring processes to his team. Built for a 3-person team with no project management tool â outputs are simple enough to be run from a Slack message or an Obsidian note.

## Constraints

**NEVER invent process steps that Marshall did not describe.** If a step appears to be missing between two described steps, surface the gap explicitly: "It sounds like [step] should happen between Step X and Step Y â is that correct?" Do not fill gaps with assumptions and do not proceed past the gap until Marshall confirms or denies.

**NEVER use passive voice in any step.** "Confirmation email is sent" must become "Send confirmation email." Every step starts with a verb. If it does not start with a verb, it is not a step â it is a note.

**NEVER use jargon the team would not know.** If Marshall invents a term, use that exact term, put it in quotes on first use, and define it immediately.

**NEVER write an SOP for a process Marshall described in under 60 seconds without running Interview Mode.** A 60-second verbal description will be missing critical decision points, edge cases, or tools. Interview Mode is not optional for thin input.

**NEVER allow an SOP to exceed 15 steps without splitting it.** If a process requires more than 15 steps, define a handoff point and produce two SOPs. One long SOP is two SOPs with no handoff â and handoffs are where processes break.

**NEVER write "Done When" criteria that are vague.** "Process is complete when the team is finished" is not a criterion. "Process is complete when the GHL contact record shows tag [X] applied and confirmation email shows as Delivered in GHL" is a criterion.

**NEVER write a GHL SOP using Keap terminology.** Marshall is actively migrating from Keap to GHL. All new SOPs are written for GHL. When converting a Keap SOP, add a prominent note at the top: "Converted from Keap to GHL â verify GHL sub-account structure matches these steps before team use."

## Keywords
standard operating procedure, SOP, process documentation, team training, tribal knowledge, workflow, how-to, procedure, repeatable process, delegation, team management, Executive Assistant, Studio Money operations, GHL workflow, Keap migration, Noteworthy

## Quick Start

1. Tell Marshall: "Run SOP Factory â here's the process I want documented: [description]"
2. Options for input:
   - Verbal description: Marshall explains the process in his own words (paragraph, bullet points, anything)
   - Recording/transcript: Paste a transcript from a call where Marshall explained the process
   - Existing rough draft: Paste any partial documentation that exists
   - Just a process name: "We need an SOP for how we handle new client onboarding" â Claude will interview Marshall for the steps
3. Claude produces a clean SOP, verifies completeness, and saves it to the SOP vault
4. Marshall reviews â one pass, approve or note what's missing
5. Team-ready document available in 20 minutes

No configuration required. Works from whatever input Marshall provides.

## Interview Mode (When Input Is Just a Process Name)

If Marshall provides only the name of a process without the steps, enter Interview Mode. Ask these questions one at a time â not as a list â and build the SOP from the answers:

1. "Who does this process? Is it always the same person, or can any team member do it?"
2. "What triggers this process â what needs to happen before this starts?"
3. "Walk me through the steps in order. Don't worry about being perfect â just describe what actually happens."
4. "What tools or systems are used? (GHL, Slack, Noteworthy, Keynote, QuickBooks?)"
5. "What does 'done' look like? How does the person doing this know they've finished correctly?"
6. "What goes wrong? What are the most common mistakes or edge cases?"
7. "Is there anything that has to be done a specific way for legal, financial, or client relationship reasons?"

After gathering answers, produce the full SOP â do not ask for more input unless a critical step is missing.

## Core Workflow

### Step 1 â Extract All Steps

Read or listen to the full input before extracting any steps. Do not start building the SOP while still reading input. Complete the full read first.

Identify:
- The process trigger (what starts this)
- Every discrete action in sequence
- Every decision point (if X, do Y; if Z, do W)
- Every tool or system touched
- The completion criteria (how you know you're done)
- Common failure points

### Step 2 â Build the SOP

Produce the SOP in the format below. Every SOP has the same structure â this predictability makes it easier for Marshall's team to follow.

---

**SOP: [Process Name]**
**Owner:** [Person responsible â Executive Assistant / Bookkeeper / Video Production / Marshall]
**Version:** 1.0
**Created:** [Date]
**Last Updated:** [Date]
**Tools Required:** [List all tools â GHL, Slack, QuickBooks, Noteworthy, Keynote, etc.]

---

**TRIGGER**
What starts this process:
[One sentence. "This SOP starts when [specific event]." Be specific â not "when needed" but "when a new speaking inquiry arrives in the inbox" or "when Marshall approves a new program to launch."]

---

**OUTCOME**
What this process produces when completed correctly:
[One sentence. The measurable end state.]

---

**STEPS**

| # | Step | Who | Tool | Notes |
|---|------|-----|------|-------|
| 1 | [Action â start with a verb: "Open," "Send," "Create," "Log," "Confirm"] | [Owner] | [Tool] | [Any conditional logic or critical note] |
| 2 | | | | |
| 3 | | | | |
[Continue for all steps]

---

**DECISION POINTS**

If any steps involve a decision (if/then logic), document them separately here so the table stays clean.

**Decision [#]: [What is the decision]**
- If [condition A]: go to Step [X]
- If [condition B]: go to Step [Y]
- If [condition C]: [escalate to Marshall / flag for review]

---

**DONE WHEN**
This process is complete when:
- [ ] [Specific completion criterion 1]
- [ ] [Specific completion criterion 2]
- [ ] [Specific completion criterion 3 â if applicable]

[Maximum 3 criteria. If you need more, the SOP should be split into two SOPs.]

---

**COMMON MISTAKES**

| Mistake | Why It Happens | How to Prevent It |
|---------|---------------|-------------------|
| [Mistake 1] | [Root cause] | [Specific prevention step] |
| [Mistake 2] | [Root cause] | [Specific prevention step] |

[Maximum 3. If Marshall hasn't described failures, write: "No failures documented in v1.0 â update this section after first team run."]

---

**ESCALATE TO MARSHALL WHEN**
- [Situation 1 â the team member cannot proceed without Marshall's input]
- [Situation 2]

[If Marshall wants to be involved in zero decisions on this process, write "No escalation points â process should complete without Marshall input."]

---

**RELATED SOPs**
- [Name of SOP that typically runs before this one, if applicable]
- [Name of SOP that typically runs after this one, if applicable]

---

### Step 3 â Verify Completeness

After producing the SOP, run a self-check before delivering:

- [ ] Does every step start with a verb?
- [ ] Is every tool named specifically (GHL vs. "CRM", QuickBooks vs. "accounting software")?
- [ ] Can a new team member who has never done this process complete it using only this document?
- [ ] Are all decision points documented in the Decision Points section?
- [ ] Is the trigger specific enough that there's no ambiguity about when to start?
- [ ] Are the "Done When" criteria measurable, not vague?

If any check fails, fix the SOP before delivering it.

### Step 4 â Save and Confirm

Save the SOP to: `[YOUR_VAULT]/Marshall Sylver/SOPs/[Process Name].md`

Replace `[YOUR_VAULT]` with the path to your vault folder (e.g., `~/Documents/Obsidian/Active-Brain/00 Projects`).

Confirm the save path in the response.

---

## GHL Migration SOPs (Priority Category)

Marshall is actively migrating from Keap to Go High Level. Any SOPs that touch contact management, email sending, automation, or pipeline management should be written for GHL â not Keap. If an existing Keap SOP is provided for update, produce a GHL version and note clearly: "This SOP has been converted from Keap to GHL. Verify that GHL sub-account structure matches these steps before team use."

Standard GHL processes to prioritize if not yet documented:
- New contact entry and tagging
- Lead nurture sequence activation
- Pipeline stage movement
- Follow-up task creation
- Event registration confirmation workflow
- Post-event close sequence trigger

---

## Output Format

**Single SOP request:** Produce the full SOP document. Ask for Marshall's review before finalizing.

**Bulk SOP session ("let's document 5 processes today"):** Build a session queue. Run through each process in order. After each SOP, confirm: "SOP [X] complete. Moving to [next process name] â ready?"

**Transcript input:** Extract every process described in the transcript and ask Marshall to confirm which ones to formalize: "I found [X] processes in this recording. Which should I document first?"

---

## Operating Rules

- Never invent steps that were not described by Marshall. If a step appears to be missing, surface the gap explicitly before proceeding.
- Do not use jargon Marshall's team would not know. If Marshall uses a term, use that exact term. If it is a term he invented, put it in quotes the first time and define it immediately.
- SOPs must be executable by Marshall's actual team: an Executive Assistant, a Bookkeeper, and a Video Production person. If a step requires technical knowledge those roles do not have, flag it prominently: [REQUIRES TECHNICAL SKILL â confirm which team member can execute this before deploying]
- Version every SOP starting at 1.0. When updating an existing SOP, increment the version number and add a one-line change note at the top of the document.
- Keep every SOP to one page when possible. If a process requires more than 15 steps, split into two SOPs with an explicit handoff point defined between them.
- Every step starts with a verb. Passive voice is not permitted in any step description.
- Run the self-check in Step 3 â Verify Completeness on every SOP before delivery. Do not skip it.

## When To Call This Skill

- Any time Marshall explains a process verbally to a team member â that explanation should be captured immediately
- Before delegating a new task to the team â document it first so the delegation is clean
- During the GHL migration â every process that touched Keap needs a GHL version
- After a team mistake â "We need an SOP for this so it never happens again"
- Quarterly process review â audit existing SOPs for accuracy against how the team actually runs things

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Invent process steps Marshall didn't describe | Surface the gap: "Should [step] happen between X and Y?" |
| Use passive voice in any step | Every step starts with a verb â "Send," "Open," "Create" |
| Write an SOP from a 60-second description | Run Interview Mode â thin input always has missing decision points |
| Allow an SOP to exceed 15 steps | Split into two SOPs with a defined handoff point |
| Write vague "Done When" criteria | Make every criterion measurable and specific |
| Use Keap terminology in new SOPs | All new SOPs are GHL â convert and verify |

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Version History (Gauntlet QA pass)

## After Delivery

Ask Marshall:
1. "Is this complete? Is there any step the team needs to know that isn't in here?"
2. "Who is the primary owner of this process? Should their name be on the Owner line?"
3. "Should this SOP go into the team's shared Obsidian vault so all three of them can access it?"
