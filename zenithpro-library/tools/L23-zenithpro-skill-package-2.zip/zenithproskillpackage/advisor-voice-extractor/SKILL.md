---
name: advisor-voice-extractor
description: Extracts Scott Keffer's distinct coaching voice from existing writing samples â direct mail pieces, boot camp brochures, webinar scripts, coaching notes, email sequences â and produces a reusable SKI Voice Profile. The profile is the reference document all other SKI agents and skills use to match Scott's voice in generated content. Built for the financial advisor niche where credibility, directness, and peer authority determine whether content converts. Use before generating any content that will carry Scott's name or represent SKI. Re-run whenever Scott provides new writing samples that reveal patterns not captured in the current profile.
license: proprietary
metadata:
tags:
  - program/ctd
  - client/scott-keffer
---
# Advisor Voice Extractor

Analyzes Scott Keffer's writing and speaking samples to produce a reusable SKI Voice Profile. Every AI-generated piece â email, direct mail, webinar script, coaching framework â matches Scott's actual voice, not a generic coaching persona.

## Keywords
Scott Keffer, SKI voice, advisor coaching voice, financial advisor coach, direct mail voice, boot camp voice, coaching tone, SKI style, voice profile, writing samples, webinar voice

## Quick Start

1. Provide 2-5 samples of Scott's writing or speaking (direct mail copy, boot camp brochures, email sequences, coaching scripts, webinar transcripts)
2. Specify the primary content type this profile will power ("Direct mail" or "Webinar scripts" or "All SKI content")
3. Claude analyzes all samples and produces the full SKI Voice Profile
4. Review the test sample â if it's off, say what sounds wrong and Claude refines
5. Save as `SKI-Vault/09_PersonalBrandDNA/SKI-Voice-Profile.md`

## Minimum Requirements Before Starting

Before beginning analysis, verify:

- At least 2 samples of Scott's writing or speaking totaling at least 500 words combined
- At least one sample from a marketing or sales context (direct mail, brochure, webinar)

If only coaching notes or internal documents are available, proceed â but flag that the profile may need refinement once marketing samples are added.

If Scott has boot camp brochure copy or direct mail pieces, prioritize those. SKI's primary medium is direct response â the voice profile must capture direct response Scott, not internal-memo Scott.

## Core Workflow

### Step 1 â Ingest All Samples

Read every sample completely before beginning analysis. For each sample note:
- Type: (direct mail / boot camp brochure / email / webinar script / coaching notes / speaking transcript)
- Audience: (financial advisors being sold to / advisors already in the program / team members)
- Intent: (acquire new clients / teach / motivate / retain)

Financial advisor coaches speak differently to prospects than to clients. Note which mode each sample represents. The voice profile must capture both â they will differ.

### Step 2 â Deep Analysis Pass

Analyze across seven dimensions, with financial advisor coaching specifics in mind:

**1. Sentence Rhythm**
- Average sentence length â count it, don't estimate
- Does Scott use the short declarative + elaboration pattern common in direct response? ("Most advisors do X. Wrong move. Here's why.")
- Does he use numbered lists in sales material but continuous prose in coaching?
- How does he handle complexity â does he break it down or charge through it?

**2. Vocabulary and Domain**
- Does he use financial services jargon? Does he translate it or assume the reader knows?
- What specific phrases or terms appear across multiple samples? (These are fingerprints â "affluent clients," "double your business," "half the clients," "7X Advisor")
- Does he use aspirational language ("the top advisors do X") or problem language ("most advisors are stuck because X")?
- Income and revenue figures â does he quote specific numbers from client results? How often?

**3. Emotional Register**
- Is his dominant tone authoritative peer or outside-expert? (Financial advisor coaches who were advisors speak differently than those who weren't â determine which Scott sounds like)
- How does he handle credibility claims? (Mentions of 30 years, 427 presentations, tens of thousands trained â does he weave these in or lead with them?)
- Is there urgency in his copy? How does he create it without feeling manufactured?
- Does he use social proof (client results) or authority proof (his track record) more often?

**4. Structural Habits**
- How does direct mail open? (Problem statement? Bold claim? Story?)
- How does webinar content open? (Same or different from DM?)
- Where does the proof enter? Early, middle, or late?
- How does he close? (Clear single CTA or multiple options?)
- Does he use the "most advisors / top advisors" contrast structure?

**5. What This Voice NEVER Does**
Scan for deliberate absences:
- Does he ever use therapy-adjacent language ("healing," "journey," "explore")?
- Does he use vague language ("might," "perhaps," "possibly") or is he declarative?
- Does he use corporate jargon ("leverage synergies," "move the needle") or plain language?
- Does he hedge claims or state them flatly?
- Does he ever write in a confessional tone or does he stay authoritative?

**6. Signature Moves**
Look for recurring Scott-specific patterns:
- The "X by doing Y with Z" construction (his frameworks often compress outcome + method + specificity)
- Specific named systems: how does he introduce them? ("The 7X Advisor Model," "The Affluent Engagement System" â does he always capitalize? Always explain on first use?)
- Client result citations â how specific? ("$1.54M in extra income" â this level of precision is a fingerprint)
- The contrast structure: "the average advisor / the 7X advisor" â does this appear regularly?

**7. Point of View and Distance**
- Does he write as a peer who figured something out, or as an authority looking down the path?
- "You" vs. "most advisors" â which is his default second-person?
- How much does he reveal about himself vs. leading with client results?
- Does he write in first person in sales material or stay third/second?

### Step 3 â Write the SKI Voice Profile

Use the format below. Every observation backed by a direct quote from the samples.

### Step 4 â Generate Test Sample

Write a 200-word sample in the extracted voice on one of these topics (Scott's core territory):
- "Why most advisors plateau at the same revenue level year after year"
- "What separates a $1M advisory practice from a $5M advisory practice"
- "The mistake advisors make when trying to attract affluent clients"

This is the validation step. The profile is only as good as what it produces.

## SKI Voice Profile Format

```markdown
# Scott Keffer â SKI Voice Profile
**Generated:** [Date]
**Source samples:** [list types and approximate word counts]
**Primary use:** [Direct mail / Webinar scripts / All SKI content]

---

## The Essence
[One paragraph describing what this voice sounds like. Specific enough to brief a writer who has never read Scott's work. Not "direct and knowledgeable" â that describes every business coach. What makes this voice distinctly Scott Keffer: the combination of specific financial advisor language, the peer-authority positioning, the emphasis on specific numbers and outcomes, the contrast structure between average advisors and top performers.]

---

## Sentence Patterns
[Description with evidence and direct quotes]

**Examples:**
> "[direct quote]"
> "[direct quote]"

---

## Vocabulary
[Financial services domain vocabulary, aspirational vs. problem framing, specific phrases that are SKI fingerprints]

**SKI Fingerprint Phrases:**
- "[phrase that appears multiple times]"
- "[phrase that appears multiple times]"
- "[phrase that appears multiple times]"

---

## Emotional Register
[Authoritative peer or outside expert? How credibility is established. Social proof vs. authority proof balance.]

**Evidence:**
> "[direct quote]"

---

## Structural Habits
**Opens with:** [pattern]
**Closes with:** [pattern]
**Proof placement:** [early / middle / late / threaded throughout]
**Lists/formatting:** [pattern]

---

## What This Voice NEVER Does
- [Specific absence â stated as a rule]
- [Specific absence]
- [Specific absence]
- [Specific absence]
- [Specific absence]

---

## Signature Moves
- **[Move name]:** [Description] â Example: > "[quote]"
- **[Move name]:** [Description] â Example: > "[quote]"
- **[Move name]:** [Description] â Example: > "[quote]"

---

## Point of View and Distance
[How Scott positions relative to his reader â peer or authority, distance, intimacy level]

---

## Test Sample
**Topic:** [chosen topic from the list above]
**Word count:** [~200]

[The generated sample â written fully in the extracted voice]

---

## Usage Instructions
When writing in Scott's voice:
1. [Rule derived from sentence rhythm analysis]
2. [Rule derived from vocabulary â include the specific financial advisor language]
3. [Rule derived from emotional register â peer authority, not outside expert]
4. [Rule derived from structural habits]
5. [Rule derived from "never does" section]
6. [Rule derived from signature moves â the contrast structure, the specific numbers]
7. [Rule derived from POV/distance]

**Quick test before submitting:** Would a veteran financial advisor read this and think "this guy has been in the room with advisors for 30 years" â or would they think "this sounds like a generic business coach"? If the latter, start over.
```

## Quality Standards

- Every observation must be backed by a direct quote. If you can't quote it, remove it.
- The "Never Does" section must list actual absences from the samples, not assumed ones.
- The test sample must demonstrate the voice under pressure â pick the hardest topic where generic coaching advice would be easiest to drift to. Scott's voice should still be distinguishable.
- The fingerprint phrases section must include real phrases from the samples, not invented ones.

## Constraints

- Never produce a generic "professional coaching voice" profile. The output must be specific enough that someone could write a SKI direct mail piece without it reading like it was written by someone else.
- Never skip the test sample. A Voice Profile that has not been validated has not been built.
- Never invent fingerprint phrases. Every phrase listed in the "SKI Fingerprint Phrases" section must appear verbatim in at least one sample.
- Never list an absence in "What This Voice NEVER Does" unless you verified that absence by scanning all samples.
- If all samples are the same type (only webinar transcripts, only brochures), flag this limitation explicitly â list the missing sample types and note that the profile may shift when those types are added.
- If the combined word count of all samples is under 500 words, stop and request more material before proceeding. A profile built on under 500 words is unreliable.
- Financial services compliance note: Scott's audience is financial advisors who work in a regulated industry. Nothing in the voice profile should encourage content that could expose advisors to compliance issues. His voice avoids specific investment claims â note this if it appears in the samples.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Produce a generic "professional coaching voice" | Specific enough to write a SKI direct mail piece without drift |
| Invent fingerprint phrases | Every phrase must appear verbatim in at least one sample |
| Skip the test sample | A profile that hasn't been validated hasn't been built |
| List "never does" items without verifying across all samples | Scan every sample before flagging an absence |
| Build a profile on less than 500 words | Stop and request more material |
| Overwrite an existing profile without reading the prior one | Incorporate prior findings â Voice Profile evolves |

## Before You Respond

- [ ] Do I have at least 500 words across at least 2 samples?
- [ ] Do I have at least one marketing/sales sample?
- [ ] Have I backed every observation with a direct quote?
- [ ] Have I produced the 200-word test sample?
- [ ] Does the test sample pass the "veteran advisor recognition" check?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)

## Save Location

`SKI-Vault/09_PersonalBrandDNA/SKI-Voice-Profile.md`

This is the master document. All other SKI agents and skills that generate content in Scott's voice must reference this file. Never produce a new profile that overwrites an existing one without first reading and incorporating the prior profile's findings.
