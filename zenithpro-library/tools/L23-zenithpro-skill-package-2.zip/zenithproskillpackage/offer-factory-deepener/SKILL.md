# Offer Factory: Offer Deepener

---
name: offer-factory-deepener
description: "Use when you have promising ideas from the Offer Engine and need them pressure-tested, scored, and ranked before selecting a winner for the Architect."
---

## Purpose

The Engine generates volume. The Deepener generates depth. It takes 5-20 promising concepts and pressure-tests each one, producing a ranked backlog organized by strategic priority: Can it actually be built? What assets already exist? What's missing? What are 3-5 variations? What could go wrong? Who specifically wants this?

## Invocation

```
/offer-factory-deepener [concept name or Engine run file]
```

**Examples:**
```
/offer-factory-deepener "The AI Skills Marketplace" from ZenithPro Engine run
/offer-factory-deepener Top 3 from latest Engine run
/offer-factory-deepener [paste concept description]
```

---

## Input Requirements

**Required:**
- 5-20 offer concepts (or 'all' to deepen the full Engine catalog)

**Strongly recommended:**
- Product Component Inventories (to map what exists vs. what's needed)
- Offer Autopsies (to check for cannibalization)
- Cross-Product Synthesis (for combination opportunities)

---

## Execution Process

### For Each Concept:

#### Step 1: Concept Clarification

Restate the concept with precision:
- **One-sentence description:** What is this, in plain language?
- **The buyer's sentence:** How would the buyer describe this to a friend?
- **Category:** What does the buyer mentally file this under?
- **Structural patterns at work:** Which of the 30 patterns power this concept?

#### Step 2: Asset Mapping

Map every component needed to build this offer against what already exists:

| Needed | Exists? | Source | Gap |
|--------|---------|--------|-----|
| [Component] | Yes/Partial/No | [Which product] | [What's missing] |

**Tally:**
- Components that already exist: [count] ([percentage])
- Components that need adaptation: [count]
- Components that must be created from scratch: [count]

#### Step 3: Feasibility Stress Test

Answer honestly:

**Build feasibility:**
- Can this be built with existing infrastructure? (Yes/Partial/No)
- What new tech/platforms are needed?
- What new content must be created?
- Estimated build effort: Minimal (days) / Moderate (weeks) / Significant (months)

**Market feasibility:**
- Does this audience exist and is it reachable?
- Is there demonstrated demand for something like this?
- What's the competitive landscape?
- What's the likely price sensitivity?

**Operational feasibility:**
- Can this be delivered at the expected quality level?
- What's the marginal cost per customer?
- Does this scale or does it require Rich's personal time?
- What's the support burden?

**Cannibalization check:**
- Does this compete with any existing product?
- If yes: Is it additive (expands market) or substitutive (steals from existing)?
- Would current customers feel devalued?

#### Step 4: Variation Generation

Generate 3-5 variations of the concept:

**Variation types to consider:**
- **Price variation:** Same concept at a different price point (and what changes)
- **Scope variation:** Bigger or smaller version
- **Audience variation:** Same concept for a different buyer
- **Delivery variation:** Same concept, different format
- **Timeline variation:** Compressed or extended version
- **Automation variation:** More or less human involvement

For each variation:
- What changes from the original
- What new opportunities it opens
- What new risks it introduces
- How it relates to the existing portfolio

#### Step 5: Risk Assessment

**What could go wrong:**
- Market risk (nobody wants this)
- Execution risk (can't build it to quality)
- Brand risk (doesn't fit Rich's positioning)
- Cannibalization risk (kills existing revenue)
- Operational risk (too hard to deliver)
- Timing risk (too early or too late)

**For each risk:** Rate likelihood (Low/Med/High) and impact (Low/Med/High). Flag any risks that are both High/High â those are dealbreakers unless mitigated.

#### Step 6: Revenue Modeling

Rough revenue estimates (not precise â directional):

| Scenario | Price | Volume | Revenue | Margin |
|----------|-------|--------|---------|--------|
| Conservative | | | | |
| Base | | | | |
| Optimistic | | | | |

**Revenue type:** One-time / Recurring / Hybrid
**LTV consideration:** Does this create upsell opportunity?
**Acquisition cost assumption:** Existing audience / Paid traffic / Both

#### Step 7: Strategic Fit Assessment

How does this concept fit the bigger picture?

- **Value ladder position:** Where does this sit? (Front-end, mid-ticket, back-end)
- **Ecosystem role:** Does this fill a gap? Create a new entry point? Upgrade path?
- **Brand alignment:** Does this reinforce or dilute Rich's positioning?
- **Resource allocation:** Is this worth the opportunity cost?
- **Learning value:** Even if this doesn't work, what would you learn?

---

## Output

### File Location
```
Active-Brain/00 Projects/01 Behavioral Intelligence/Offer Factory/Developed Concepts/[Concept Name] - Deepened - [Date].md
```

### Document Structure

```markdown
# Concept Deep Dive: [Concept Name]
**Source:** [Engine run reference]
**Date:** [Date]
**Backlog Rank:** #[rank] of [total]
**Category:** Immediate Build | Short-Term (30 days) | Medium-Term (90 days) | Strategic Hold | Research Needed
**Confidence:** [1-10] (how confident are we in the assessment)

## Concept Summary
[Step 1 output]

## Asset Map
[Step 2 output â table of existing vs. needed components]

## Feasibility Assessment
[Step 3 output â build, market, operational, cannibalization]

## Variations

### Variation 1: [Name]
[Description, opportunities, risks, portfolio fit]

### Variation 2: [Name]
[...]

[...up to 5 variations...]

## Risk Matrix

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| [Risk] | L/M/H | L/M/H | [How to address] |

## Revenue Model
[Step 6 output â conservative/base/optimistic]

## Strategic Fit
[Step 7 output]

## Recommendation
[Clear recommendation: pursue which variation at what priority, or park/reject with reasoning]

## Next Step
- If PURSUE: Send to Offer Architect (`/offer-factory-architect`)
- If EXPLORE: What specific questions need answering first
- If PARK: Under what conditions to revisit
- If REJECT: Why, and what to learn from the exercise
```

### Backlog Summary (Always Included)

When processing multiple concepts, always produce a master backlog at the END of the output file:

## Master Backlog â Ranked by Strategic Priority

| Rank | Concept | Category | Revenue | Build | Confidence | Key Insight |
|------|---------|----------|---------|-------|------------|-------------|
| 1 | [Name] | Immediate | $XXX | X days | 9/10 | [One line] |
| 2 | [Name] | Short-Term | $XXX | X wks | 8/10 | [One line] |
| ... | ... | ... | ... | ... | ... | ... |

**How to use this backlog:**
- Rich selects which concepts to send to the Architect
- The Deepener's ranking is a recommendation, not a decision
- Concepts ranked low may still be the right choice depending on Rich's current priorities
- "Research Needed" concepts need specific questions answered before they can be properly ranked
- The backlog is a LIVING document â re-run with updated context to re-rank

---

## Batch Processing (Default Mode)

The Deepener is designed to process concepts in BATCHES, not one at a time. When processing a batch:

1. **Deepen all concepts** through the 7-step process
2. **Rank them** against each other using this framework:

**Ranking Criteria (weighted):**
| Factor | Weight | What It Measures |
|--------|--------|-----------------|
| Strategic fit with current priorities | 30% | Does this help what Rich is actively selling/building? |
| Revenue potential (risk-adjusted) | 25% | Expected value, not best case |
| Build effort (inverted) | 20% | Easier to build = ranked higher |
| Novelty/differentiation | 15% | Does this create competitive advantage? |
| Portfolio synergy | 10% | Does this make other products more valuable? |

3. **Categorize each concept:**
   - **Immediate Build** â Can start this week, clear path, no blockers
   - **Short-Term (30 days)** â Needs some prep but nothing major
   - **Medium-Term (90 days)** â Significant build, worth planning for
   - **Strategic Hold** â Great idea, wrong time (document why and when to revisit)
   - **Research Needed** â Can't rank without specific information (list exactly what's needed)

4. **Produce the Master Backlog** summary table
5. **Flag the top 3** with expanded "Why this, why now" reasoning

---

## Integration

- **Input from:** Offer Engine runs
- **Output to:** Offer Architect (for concepts marked PURSUE)
- **Feedback to Engine:** Patterns in what ranks high vs. low â update Engine scoring. Concepts that consistently rank low for the same reason â flag to Engine to deprioritize that pattern. Concepts that rank high â flag to Engine to explore that territory further.
