---
name: stripe-analytics
description: Complete Stripe analytics for Strategic Profits. Query daily sales, revenue by product, subscription metrics, failed payments, and historical comparisons. Use for daily reports, ad-hoc queries, and business intelligence.
---

# Stripe Analytics Skill

## Overview

Full-access analytics for the Strategic Profits Stripe account. Provides:
- Daily/weekly/monthly revenue summaries
- Revenue breakdown by product line
- Transaction details with customer info
- Subscription and MRR metrics
- Failed payment analysis
- Period-over-period comparisons

## Quick Commands

| Query | What It Does |
|-------|--------------|
| "Yesterday's sales" | Full summary of previous day |
| "Today's sales so far" | Current day transactions |
| "This week's revenue" | Week-to-date summary |
| "Last 7 days by product" | Product breakdown for past week |
| "Zenith Pro sales this month" | Single product deep dive |
| "Failed payments yesterday" | Payment failure analysis |
| "MRR breakdown" | Current subscription metrics |
| "Compare this week to last week" | Period comparison |

## Product Categories

The skill automatically categorizes Stripe products:

| Category | Matches |
|----------|---------|
| **Zenith Pro** | Zenith Pro, ZPro, ZPRO variants |
| **ZenithMind OS** | ZenithMind, Zenith Mind, Zenith E3 |
| **Steal Our Winners** | SOW, Steal Our Winners |
| **$50K Prompts** | $50,000 Prompts |
| **GeniusOS** | GeniusOS, Genius OS |
| **Rich's Brain** | Rich's Brain |
| **Zenith Power Stack** | Power Stack |

## How To Use

### Daily Report
```
"Generate yesterday's daily sales report"
```

Returns:
- Total revenue (gross, refunds, net)
- Transaction count (successful/failed)
- Revenue by product category
- Top transactions list
- Failed payment summary with reasons

### Product Deep Dive
```
"How much has Zenith Pro sold this month?"
"Show me all Steal Our Winners transactions this week"
```

### Subscription Metrics
```
"What's our current MRR?"
"How many active subscriptions do we have?"
"Show subscription churn this month"
```

### Comparisons
```
"Compare this week to last week"
"How does December compare to November?"
```

## API Access

This skill uses the Stripe API with these endpoints:

| Endpoint | Purpose |
|----------|---------|
| `/v1/charges` | Transaction data |
| `/v1/balance` | Current balance |
| `/v1/balance_transactions` | Fees and net amounts |
| `/v1/subscriptions` | Active/churned subs |
| `/v1/products` | Product catalog |
| `/v1/refunds` | Refund data |
| `/v1/disputes` | Chargebacks |

## Configuration

**API Key Location:** `~/.claude/skills/stripe-analytics/references/config.json`

The API key is stored securely and never exposed in outputs.

## Output Formats

The skill can output in multiple formats:
- **Summary** - Quick overview with key metrics
- **Detailed** - Full transaction list with customer info
- **CSV** - Exportable format for spreadsheets
- **Comparison** - Side-by-side period analysis

## Integration with Daily Report

This skill is designed as a component for a larger daily business report. It can be called by:
- `daily-report` orchestrator skill (future)
- Direct user queries
- Automated scripts

## Metrics Available

### Revenue Metrics
- Gross revenue
- Net revenue (after refunds)
- Average transaction value
- Revenue by product
- Revenue by time period

### Transaction Metrics
- Successful transaction count
- Failed transaction count
- Failure rate
- Failure reasons breakdown

### Subscription Metrics
- Active subscription count
- Monthly Recurring Revenue (MRR)
- Churn rate
- New vs renewed subscriptions

### Customer Metrics
- New customers
- Repeat customers
- Customer lifetime value (LTV)
