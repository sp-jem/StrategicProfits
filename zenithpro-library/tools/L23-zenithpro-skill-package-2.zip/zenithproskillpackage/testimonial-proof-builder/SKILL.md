---
name: testimonial-proof-builder
description: Transforms raw client wins, feedback, stories, and testimonials into polished, persuasion-ready proof assets for Level 5 Mentoring. Takes messy inputs â a client message, a Zoom call transcript, a Facebook comment, a voice memo summary â and produces a testimonial library with specific formats for landing pages, emails, ads, and sales conversations. Use when Abigail says "I got great feedback from a client," "can you turn this into a testimonial," "help me collect proof," or "I need more social proof for this campaign."
license: proprietary
metadata:
tags:
  - program/ctd
---
# Testimonial Proof Builder

Converts raw client feedback and wins into a polished, organized proof library that Level 5 Mentoring can deploy across every marketing channel â landing pages, emails, ads, sales calls, and webinars.

## Keywords
testimonial, social proof, client win, case study, before/after, transformation story, proof, client feedback, review, results

## Quick Start

1. Paste the raw input (client message, email reply, transcript excerpt, voice note summary, Facebook comment â anything)
2. Optionally: tell me which campaign or topic this testimonial is most relevant to
3. Optionally: tell me where you plan to use it (landing page? email? ad?)
4. I produce polished formats + add it to the library log
5. Review and confirm before saving

---

## Why This Exists

Abigail's stated goal: systematic testimonial collection. Right now, client wins come in through many channels (Zoom calls, emails, DMs, Facebook group posts) and disappear or get underused. This skill creates a consistent process to capture, transform, and organize proof so it is always available when copy needs it.

---

## What Counts as Usable Input

This skill works with any of the following:

- **Direct client messages** â copy/paste from email, SMS, DM, Facebook
- **Zoom call highlights** â a summary or transcript excerpt where a client shares a win
- **Survey responses** â from post-masterclass or program-completion surveys
- **Facebook group posts** â from the Level 5 Mentoring community
- **Verbal reports** â "Abigail told me a client said..." (reconstruct in quotes, flag as paraphrase)
- **Before/after descriptions** â what the client's life looked like before, and what changed

If the input is extremely short (under 30 words with no specifics), ask for elaboration before proceeding: "Can you tell me more about what changed for them? The more specific the detail, the stronger the testimonial."

---

## Core Workflow

### Step 1 â Extract the Transformation

Read the raw input and identify:

1. **Who:** What do we know about this person? (age range, what they struggled with, how long they'd been trying)
2. **Before:** What was their situation / pain / frustration before working with Brian/Level 5?
3. **Mechanism:** What specifically did the Spellbreaking method help them do? (feel safer? stop a specific misperception? shift a specific relationship pattern?)
4. **After:** What changed? Be specific â "I feel better" is weak; "I had a $12,000 month after three months of nothing" is strong
5. **Time frame:** How quickly did the change happen? (speed is proof of mechanism, not just effort)

If the raw input doesn't contain all five elements, note what's missing and ask for it. Missing specifics = unusable proof.

### Step 2 â Produce Polished Formats

For each testimonial, produce all four formats:

---

**FORMAT A: Full Narrative (For Landing Pages and Sales Pages)**
150â250 words. Tells the complete before/after story in the client's voice. Uses first person. Reads like the client wrote it â not like a press release. Ends with the most powerful result sentence.

---

**FORMAT B: Pull Quote (For Email Headers and Ad Copy)**
1â3 sentences. The single most arresting moment from the testimonial. Should work as a standalone statement without context. Example: *"I'd spent $40,000 on coaching and therapy over 10 years. In three weeks with Brian, I understood why none of it had stuck â and it finally did."*

---

**FORMAT C: Bullet Point (For Stacked Proof Sections)**
One line, results-focused. Example: *"Client went from constant financial anxiety to her first $10K month â in 60 days of the Spellbreaking method."*

---

**FORMAT D: Conversation Version (For Sales Calls and Webinar Delivery)**
How to tell this story verbally in 45â60 seconds. Written as if Abigail or Brian is sharing it: "I had a client who..." Scripted but sounds natural.

---

### Step 3 â Tag and Categorize

After producing formats, assign:

**Transformation domain:**
- [ ] Money / financial
- [ ] Health / body
- [ ] Relationships / love
- [ ] Self-perception / confidence
- [ ] Multiple domains

**Campaign relevance:**
- [ ] 5C Manifestation
- [ ] Money Freedom Process 4.0
- [ ] Quantum Time Travel
- [ ] Spellbreak for a Living
- [ ] Unclench
- [ ] General Spellbreaking / Level 5 Mentoring
- [ ] New campaign: [name]

**Audience match:**
- [ ] Spiritually oriented
- [ ] Prior self-help consumer
- [ ] Trauma background
- [ ] Long-time seeker (5+ years trying)
- [ ] Skeptic who became believer

**Strength rating:**
- **A: Specific result + timeline + mechanism** â use everywhere, name prominently
- **B: Specific result, missing timeline or mechanism** â strong, use in body copy
- **C: Emotional transformation, no measurable result** â use for trust/resonance, not conversion
- **D: Too vague to use as-is** â return to source for more detail

### Step 4 â Add to Testimonial Library

After Abigail confirms, add to the running library log at:
`AI-Training/00 System/testimonial-library.md`

Format for library entry:

```
## [Client First Name or Initials] â [Domain] â [Date Added]
**Strength:** [A / B / C]
**Relevant campaigns:** [list]
**Pull quote:** "[quote]"
**File:** [location of full formats if saved separately]
```

---

## Output Expectations

Every run produces:
1. The four polished formats
2. Tags and category assignments
3. Strength rating with explanation
4. A note on what's missing (if anything) that would upgrade the strength rating
5. Confirmation of library addition

---

## Constraints

- NEVER fabricate specifics that were not in the source material. If a result is not stated, do not invent it. Missing specifics = ask for them.
- NEVER attribute a testimonial to a real name without Abigail's explicit confirmation that the client has consented.
- NEVER rate a testimonial as Strength A without all five elements present: Who / Before / Mechanism / After / Time frame.
- NEVER publish or finalize a testimonial without Abigail's review confirmation.
- NEVER frame a client's past struggle as weakness or failure. The old paradigm failed them; they did not fail.
- NEVER over-polish into corporate language. Emotional authenticity is the asset â preserve it.
- ALWAYS flag paraphrased content: *[Paraphrased from client communication â confirm wording with client before publishing]*
- ALWAYS default to first name only (e.g., "Sandra M.") or anonymized identifier (e.g., "A 52-year-old business owner from Texas") unless Abigail explicitly approves full attribution.
- ALWAYS add privacy status to every library entry.
- If source input is under 30 words with no specifics: ask exactly one targeted question to extract the missing element before proceeding.
- If a client has verbally consented to full name use but Abigail has not confirmed it in this session: default to first name only and flag for Abigail to confirm before publishing.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Fabricate specifics not in the source | Ask for the missing detail |
| Use full names without confirmed consent | Default to first name only or anonymized identifier |
| Rate as Strength A without all 5 elements | Be honest about what's missing |
| Over-polish into corporate language | Preserve emotional authenticity |
| Frame the client's past as personal failure | The old paradigm failed them â not the other way around |
| Produce a partial output (3 of 4 formats) | All 4 formats every time |

## Before You Respond

- [ ] Do I have raw client feedback to work from?
- [ ] Have I identified all 5 transformation elements (Who/Before/Mechanism/After/Time)?
- [ ] Is the strength rating honest?
- [ ] Am I defaulting to first-name-only attribution?
- [ ] Is every format traceable to the source material?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History, consent handling clarification (Gauntlet QA pass)

## Output Block

Every run produces all four formats plus metadata. No partial outputs.

1. FORMAT A: Full Narrative (150-250 words, landing page / sales page use)
2. FORMAT B: Pull Quote (1-3 sentences, email headers / ad copy)
3. FORMAT C: Bullet Point (one line, stacked proof sections)
4. FORMAT D: Conversation Version (45-60 second verbal script)
5. Tags: domain / campaign relevance / audience match / strength rating
6. Library entry confirmation: `AI-Training/00 System/testimonial-library.md`
7. Missing elements note (if any) with follow-up question to strengthen rating
