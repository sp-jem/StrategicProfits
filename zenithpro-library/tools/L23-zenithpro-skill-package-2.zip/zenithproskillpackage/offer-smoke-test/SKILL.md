---
name: offer-smoke-test
description: Validates willingness to pay BEFORE building a full funnel. Creates a minimal viable sales page + small ad test ($50-$150) to confirm real humans will buy. Prevents weeks of wasted funnel building on unvalidated offers.
triggers:
  - "smoke test"
  - "validate my offer"
  - "test my offer"
  - "will people buy this"
  - "offer validation"
  - "minimum viable test"
user_invocable: true
---

# Offer Smoke Test

**Purpose:** Answer "Will real people pay for this?" with minimal time and money. Before building a full funnel, email sequences, and ad creative library — put a simple page in front of real buyers and see if they click "buy."

**Why this exists:** The pipeline currently goes from offer creation straight to full funnel build (weeks of work). If the offer doesn't convert, all that work is wasted. A $50-$150 smoke test in 48-72 hours tells you if the offer has legs.

---

## EXECUTION PROTOCOL

### Step 1: Confirm Prerequisites

Before running a smoke test, verify:
- [ ] Offer exists (from offer-arena or manually created)
- [ ] Price point is set
- [ ] They can describe the offer in 1-2 sentences
- [ ] They have $50-$150 for a quick ad test
- [ ] They have a Facebook/Meta ad account (or can set one up today)
- [ ] They have a payment processor (Stripe, PayPal, Gumroad, etc.) — if not, redirect to `payment-tech-setup` first

**If they don't have a payment processor:** They cannot smoke test with real purchases. Options:
1. Run `payment-tech-setup` first (adds 1-2 hours)
2. Use a "waitlist" smoke test instead (measures interest, not purchases) — less reliable but still useful

---

### Step 2: Build the Minimum Viable Sales Page

This is NOT a full sales page. It's the bare minimum to test purchase intent.

**Page structure (one page, 5 sections max):**

```
1. HEADLINE — The core promise (1 sentence)
2. SUBHEAD — Who it's for + what they get (1-2 sentences)
3. 3-5 BULLET POINTS — Key benefits/inclusions
4. PRICE + CTA BUTTON — "Get [Offer] for $XX" or "Join Now — $XX"
5. SIMPLE GUARANTEE — "30-day money-back guarantee" or similar
```

**What NOT to include:**
- No long-form copy
- No video
- No testimonials (unless they already exist)
- No elaborate design
- No upsells or order bumps

**Build options (fastest to slowest):**
1. **Gumroad/Payhip product page** — 15 minutes, payment built in
2. **Carrd.co** — 30 minutes, connect Stripe via button
3. **Google Doc + Stripe payment link** — 10 minutes, ugliest but fastest
4. **landing-page-copy skill (minimal mode)** + any page builder — 1-2 hours

**Produce the copy for them.** Write the headline, subhead, bullets, and CTA based on their offer. Keep it under 200 words total.

---

### Step 3: Set Up the Smoke Test Ad

**Ad structure (1 campaign, 1 ad set, 2-3 ads):**

| Setting | Value |
|---------|-------|
| Objective | Sales (if pixel exists) or Traffic (if no pixel) |
| Budget | $20-$50/day for 3 days |
| Audience | Broad in their niche (interest-based, 1-3 interests) |
| Placements | Advantage+ (let Meta optimize) |
| Ad format | Single image or short text post |

**Write 2-3 simple ad variations:**
- Ad 1: Direct offer (Here's what you get, here's the price, click to buy)
- Ad 2: Problem-solution (Struggling with X? Here's the fix — $XX)
- Ad 3: Curiosity angle (I just launched X for people who Y — link in comments)

**Ad copy rules:**
- Under 125 words per ad
- Clear price in the ad (don't hide it)
- Link directly to the sales page
- No gimmicks, no clickbait

---

### Step 4: Define Success Criteria BEFORE Launching

| Metric | Minimum Viable | Strong Signal | Home Run |
|--------|---------------|---------------|----------|
| **Link clicks** | 50+ | 100+ | 200+ |
| **Landing page views** | 40+ | 80+ | 150+ |
| **Add to cart / click CTA** | 3+ | 8+ | 15+ |
| **Purchases** | 1+ | 3+ | 5+ |
| **CPA** | Under 3x break-even | Under 2x break-even | Under break-even |

**Interpretation guide:**

| Result | What It Means | Next Step |
|--------|--------------|-----------|
| 0 purchases, low CTR on ads | Ad creative problem — offer might be fine | Test different ad angles, don't abandon offer yet |
| 0 purchases, good CTR, no CTA clicks | Page problem — headline/bullets not compelling | Rewrite the page, test again |
| 0 purchases, good CTR, CTA clicks but no buy | Price or trust problem | Test lower price, add guarantee, add 1 testimonial |
| 1-2 purchases | Offer has signal — worth building the full funnel | Proceed to funnel build with confidence |
| 3+ purchases | Strong validation — build fast, this converts | Proceed to full funnel build immediately |
| 5+ purchases in 3 days | Exceptional — the offer is hot | Skip to full funnel + scale plan |

---

### Step 5: Run the Test (3-Day Protocol)

**Day 0 (Setup):**
- Page live with working payment
- Test the purchase flow yourself (or have a friend test)
- Ads submitted for review
- Pixel/tracking confirmed (if available)

**Day 1:**
- Ads go live
- Check: Are ads approved? Are they spending?
- Do NOT change anything on Day 1 (let it breathe)

**Day 2:**
- Check metrics: CTR, CPC, page views, CTA clicks
- If CTR < 1%: Ad creative is the problem, not the offer
- If CTR > 2% but 0 CTA clicks: Page is the problem
- Make ONE change if clearly needed (swap weakest ad for new version)

**Day 3:**
- Final metrics check
- Calculate: Total spend / purchases = Actual CPA
- Compare to break-even CPA from CPA Calculator
- Make the call: PROCEED / ITERATE / PIVOT

---

### Step 6: Deliver the Smoke Test Report

```markdown
# Offer Smoke Test Report
**[Offer Name] | [Date Range]**

## Test Setup
- **Offer:** [Name] at $[Price]
- **Page:** [URL or platform]
- **Budget:** $[Total spent]
- **Duration:** 3 days
- **Audience:** [Description]

## Results

| Metric | Result |
|--------|--------|
| Total ad spend | $XXX |
| Impressions | X,XXX |
| Link clicks | XXX |
| CTR | X.XX% |
| CPC | $X.XX |
| Page views | XXX |
| CTA clicks | XX |
| Page conversion rate | X.X% |
| Purchases | X |
| Revenue | $XXX |
| CPA | $XXX |
| ROAS | X.Xx |

## Verdict: [PROCEED / ITERATE / PIVOT]

### What Worked
- [Specific element that performed well]

### What Didn't
- [Specific element that underperformed]

### Diagnosis
[Where in the funnel did people drop off? Ad → Page → CTA → Purchase]

## Recommendation
[1-3 specific next steps based on results]

### If PROCEED:
- Move to full funnel build (funnel-strategy-selector → landing-page-copy → funnel-asset-builder)
- Use winning ad angle as foundation for full ad creative
- Expected CPA at scale: $XX-$XX (based on smoke test data)

### If ITERATE:
- [Specific changes to test next]
- Budget for iteration round: $XX
- Expected timeline: 2-3 more days

### If PIVOT:
- [What the data suggests is wrong — offer, price, audience, or positioning]
- Recommended action: [Revise offer / Change price / Different audience / Back to demand-architect]
```

---

## WAITLIST VARIANT (No Payment Processor)

If they can't take payments yet, run a waitlist version:

**Page change:** Replace "Buy Now — $XX" with "Join the Waitlist — Launching [Date]"
**What it tests:** Interest, not purchase intent (weaker signal)
**Success criteria:**
- 10+ waitlist signups from $50 spend = proceed
- 5-9 signups = promising but uncertain
- Under 5 = weak signal, investigate

**Important:** A waitlist signup is NOT the same as a purchase. Multiply conversion expectations by 0.3x when projecting from waitlist to actual sales.

---

## RULES

1. **Speed over perfection.** The smoke test page should take under 2 hours to build. If it's taking longer, it's too complicated.
2. **Real money only.** Free signups don't validate willingness to pay. Always prefer purchase tests over waitlist tests.
3. **Don't optimize during the test.** 3 days, minimal changes. You're gathering data, not optimizing a funnel.
4. **Price must be visible.** Don't hide the price behind a sales call. The whole point is testing if people will pay THIS price.
5. **Kill it if it's dead.** If 0 purchases and 0 CTA clicks after $100 spend, the data is clear. Don't throw good money after bad.
6. **One offer per test.** Don't test 3 offers simultaneously. Test one, get data, decide.
7. **Save everything.** Screenshot the ad metrics, the page, the results. This data informs the full funnel build.

---

## OUTPUT LOCATION

Save report to:
```
[Obsidian Vault]/[Project Folder]/Smoke-Test-Report-[Offer]-[Date].md
```

---

## INTEGRATION NOTES

**Upstream (consumes from):**
- `offer-arena` — The offer to test (winner.md or any finalized offer)
- `demand-architect` — Audience targeting hints from psychographic profiles
- `cpa-calculator-budget-planner` — Break-even CPA for success criteria

**Downstream (feeds into):**
- PROCEED → `funnel-strategy-selector` → full funnel build
- ITERATE → Re-run smoke test with changes
- PIVOT → Back to `offer-arena` (audit mode) or `demand-architect`

**This replaces guessing with data.** A $100 smoke test that saves 3 weeks of building the wrong funnel is the best ROI in the entire pipeline.
