# SCORECARD: offer-smoke-test
**Date:** 2026-03-26
**Grader:** skill-grader agent (batch)

## Scores

| Dimension | Score | Notes |
|-----------|-------|-------|
| Structural Quality | 4/5 | Clean frontmatter, 6-step protocol in logical sequence. The placement of success criteria definition BEFORE launching (Step 4 before Step 5) is the standout structural choice. Interpretation guide table is precise and covers the key diagnostic branches. Rules section (7 rules) is strong, particularly Rule 5 (kill rule) and Rule 2 (real money only). Minor deduction for Day 2 "make ONE change if clearly needed" being undefined in measurable terms. |
| Output Quality | 4/5 | Smoke Test Report template is clean. PROCEED / ITERATE / PIVOT verdict with distinct next-step paths is well-structured. Diagnosis field (Ad → Page → CTA → Purchase funnel attribution) is the right analytical frame. Waitlist variant section is a good safety valve with appropriate 0.3x multiplier caveat. Deduction: no field in the report template to flag statistical validity concerns (e.g., total click volume before verdict). |
| Integration Quality | 4/5 | Upstream connections (offer-arena, demand-architect, cpa-calculator) are correct. Downstream fork (PROCEED → funnel-strategy-selector, ITERATE → re-run, PIVOT → offer-arena) is complete and correctly mapped. The bidirectional relationship with product-delivery-builder (smoke test can run before OR after product build) is implicitly handled but not explicitly noted — worth a line in integration notes for clarity. |
| Student-Readiness | 4/5 | "3-Day Protocol" structure with Day 0/1/2/3 instructions is highly accessible. The interpretation guide converts metric data into plain-language diagnoses — a non-technical person can read "0 purchases, good CTR, CTA clicks but no buy = price or trust problem" and know exactly what to do. Rule 4 (price must be visible) is a counter-intuitive instruction that non-technical users wouldn't know without being told. Slight weakness: the kill rule ("$100 and 0 purchases") could cause a non-technical user to prematurely abandon a viable offer if they don't have context on statistical significance. |
| Conversion Effectiveness | 4/5 | This skill's entire purpose is preventing wasted funnel-building investment. The explicit ROI framing ("a $100 smoke test that saves 3 weeks of building the wrong funnel") is the right sales pitch for why to do this step. The PROCEED → full funnel build path maintains pipeline momentum. The PIVOT → offer-arena path recovers the investment rather than leaving the user stranded. Deduction: the premature kill risk (ad algorithm hasn't optimized by Day 3 at low spend levels) could cause valid offers to get killed — this directly undermines the conversion effectiveness of the entire pipeline. |
| **Overall** | **4.0/5.0** | |

## Strengths

- Success criteria defined before launching is the skill's best design choice. It prevents post-hoc rationalization of results and creates a clear decision framework independent of outcome attachment.
- Interpretation guide table (0 purchases + low CTR = ad problem, not offer) is the most useful diagnostic framework in the skill. It prevents the #1 mistake: abandoning a good offer because the ad creative was weak.
- The PROCEED / ITERATE / PIVOT verdict structure with fully specified next steps for each is complete — no dead ends.
- Waitlist variant with explicit 0.3x multiplier caveat is an honest and useful safety valve. The warning that waitlist signups ≠ purchases is appropriately prominent.
- Rule 6 (one offer per test) prevents the most common amateur mistake of running multiple simultaneous tests that produce uninterpretable data.

## Must-Fix Items

- **Fix kill rule to require minimum click volume, not just spend:** Rule 5 and the Day 3 protocol trigger a PIVOT decision based on "$100 spend with 0 purchases and 0 CTA clicks." At low budget levels ($20-$30/day), Meta's algorithm may not generate enough link clicks to produce statistically valid data by Day 3. Add: "Before declaring PIVOT: confirm you have at least 30 link clicks. If under 30 clicks after $100 spend, extend by 2 days or increase daily budget before concluding. Low impression-to-click ratio means the algorithm hasn't found your audience yet — this is a budget problem, not an offer problem."
- **Add ad account status to prerequisites (Step 1):** Add: "Meta/Facebook ad account is active, not restricted, and has run at least one campaign before. Brand-new ad accounts require 24-72 hours for first campaign approval — factor this into your 3-day test timeline."
- **Scale success criteria to total ad spend:** Replace flat purchase count thresholds with spend-proportional targets: "At $50 spend: 1 purchase = minimum viable. At $100: 2 purchases. At $150: 3 purchases." This prevents misclassifying a $50 spend with 1 purchase as a weak result when it's actually on target for spend level.

## Certification

CERTIFIED — Overall 4.0/5.0 meets the minimum threshold. No individual dimension falls below 4.0. Three must-fix items identified; the kill rule fix is the highest priority as it can cause a user to prematurely abandon a viable offer. The skill's core logic (minimal page, 3-day test, diagnostic tree) is sound and operable in its current state.
