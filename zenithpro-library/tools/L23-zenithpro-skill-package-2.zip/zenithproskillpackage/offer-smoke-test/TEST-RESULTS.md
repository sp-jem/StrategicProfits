# TEST RESULTS: offer-smoke-test
**Date:** 2026-03-26
**Test Type:** Structural review + adversarial scenarios
**Skill Version:** Initial build

---

## Structural Review

### Are instructions complete and unambiguous?
**Rating: STRONG PASS**

The 6-step protocol is logical and sequenced correctly: prerequisites → build minimal page → set up ad → define success criteria BEFORE launching (critical) → run the 3-day test → deliver report. Step 4 (success criteria defined before launching) is the standout design choice — most people define success after the fact, which leads to cherry-picking interpretations.

The interpretation guide table (0 purchases + low CTR = ad problem; 0 purchases + good CTR + no CTA clicks = page problem; etc.) is a genuinely useful diagnostic tree. It prevents the most common mistake: abandoning a good offer because of a bad ad, or blaming the audience when the page is the problem.

One ambiguity: Day 2 rule says "Make ONE change if clearly needed" but doesn't define what "clearly needed" means in a testable way. Recommended addition: "Clearly needed = CTR under 0.5% after $30+ spent. Do not change anything based on fewer impressions."

### Does input gathering cover all needed data?
**Rating: PASS**

Prerequisites (Step 1) are comprehensive: offer exists, price set, 1-2 sentence description capability, $50-$150 budget, ad account, payment processor. The payment processor check with redirect to payment-tech-setup is correct gating behavior. The "waitlist variant" for users without payment processing is a good safety valve with appropriate caveats (0.3x multiplier on conversion expectations).

Gap: No prerequisite check for whether they have a Facebook/Meta ad account that is NOT currently restricted or in review. A new ad account can take 24-72 hours to get approved for the first campaign. This should be in Step 1 prerequisites.

### Is the output format clear and actionable?
**Rating: STRONG PASS**

The Smoke Test Report template is clean. PROCEED / ITERATE / PIVOT verdict with different next-step paths for each is well-structured. The "Diagnosis" field (where in the funnel did people drop: Ad → Page → CTA → Purchase) is the correct analytical frame — it forces attribution before recommendation.

The conditional "If PROCEED" section pointing to funnel-strategy-selector and noting the winning ad angle as foundation is exactly the right handoff.

### Are integration notes upstream/downstream correct?
**Rating: PASS with note**

Upstream correctly lists offer-arena, demand-architect, and cpa-calculator-budget-planner. Downstream correctly forks to funnel-strategy-selector (PROCEED), iterate loop (ITERATE), or offer-arena audit (PIVOT). One note: the integration section mentions this skill can run before product is fully built (it's listed as downstream of product-delivery-builder but the product-delivery-builder SKILL.md also lists smoke-test as something that can run "pre-sell" before the product is built). The bidirectional ordering between these two is intentional but should be noted explicitly in integration notes to avoid confusion.

### Bugs or gaps found?

| # | Issue | Severity |
|---|-------|----------|
| BUG 1 | No prerequisite check for ad account approval status (new accounts need 24-72hr review) | MEDIUM |
| BUG 2 | Day 2 "make ONE change if clearly needed" is not measurably defined | LOW |
| BUG 3 | Success criteria table uses absolute purchase counts (1+, 3+, 5+) regardless of ad spend level — $50 spend vs. $150 spend should have different minimum viable thresholds | MEDIUM |
| BUG 4 | No instruction for how to handle refunds during the smoke test period (someone buys, then refunds before you decide to proceed) | LOW |
| BUG 5 | The waitlist variant 0.3x multiplier is stated without sourcing — reasonable estimate but presented as fact | LOW |

---

## Adversarial Test 1: Success Criteria Gaming

**Scenario:** User spent $140 over 3 days. Got 2 purchases but the ad CTR was unusually high (4.2%) and both purchases came from a single ad set targeting a very narrow audience (family members? friends?). They want to declare PROCEED.

**Expected behavior:**
- 2 purchases meets "Minimum Viable" signal (1+ = minimum viable)
- BUT the skill's interpretation guide should surface suspicious patterns
- CTR of 4.2% is well above typical benchmarks (1-2%) — could indicate narrow/warm audience
- 2 purchases from $140 = $70 CPA
- Depends on break-even CPA from CPA Calculator — if price is $47 and COGS is $5, break-even CPA = $42. Then $70 CPA > break-even = technically above break-even CPA threshold
- Success criteria says "CPA: Under 3x break-even" = minimum viable. $70 vs $42 break-even = 1.67x → Strong Signal territory on CPA
- But narrow audience / possible non-arm's-length buyers is not addressed by the skill at all

**Gap identified:** The skill has no instruction for validating whether purchases are from a genuinely cold audience vs. warm/known contacts. For smoke test validity, purchases should come from cold traffic. The interpretation guide should add: "If all purchases came from one targeting group that includes people who know you, re-run against cold audience before declaring PROCEED."

**Verdict: MARGINAL PASS** — The math checks out (2 purchases, CPA in range), but the skill has no cold-traffic validation step, which is a legitimate gap for someone who might not understand why this matters.

---

## Adversarial Test 2: Premature Kill vs. Patient Data Collection

**Scenario:** Day 3. User has spent $90. 0 purchases. 180 impressions, 2 link clicks, 0.4% CTR. They want to declare PIVOT and build a new offer.

**Expected behavior:**
- CTR of 0.4% = under 1% → "Ad creative is the problem, not the offer" (per interpretation guide)
- 2 link clicks from 180 impressions is extremely low volume — statistically insufficient to conclude anything
- $90 spent, 2 clicks = $45 CPC which is absurdly high → ad is not being served well (budget too low for Meta's algorithm to optimize)
- The $20-$50/day budget for a 3-day test may be too low for Meta to exit the Learning Phase meaningfully
- At $20/day, Meta needs ~50 conversion events to exit Learning Phase. A 3-day test at $20/day will almost never exit Learning Phase for a new account.

**Gap identified:** Rule 5 ("Kill it if it's dead: 0 purchases and 0 CTA clicks after $100 spend") is the right kill rule, but this scenario has 2 CTA clicks (technically not 0) and only $90 spent. The skill's interpretation guidance doesn't address the minimum statistical significance requirement. With 2 clicks, there's no data to make a PIVOT decision — the problem is budget and impression volume, not the offer.

**The skill should add to Day 3 protocol:** "If total link clicks < 30: You don't have enough data yet. Spend another $30-$50 before making a call. Low click volume means the algorithm hasn't found your audience yet, not that the offer is dead."

**Verdict: FAIL on premature kill guidance** — The current $100 kill rule triggers too early for low-volume scenarios where the algorithm hasn't had enough data to optimize. A user following the skill literally would PIVOT a potentially viable offer based on 2 clicks. The minimum viable data threshold should be click volume (30+ clicks), not just dollar spend.

---

## Summary of Findings

| Test | Scenario | Result | Key Issue |
|------|----------|--------|-----------|
| Structural | Complete review | PASS with 5 bugs | BUG 1 (ad account status) and BUG 3 (spend-scaled success criteria) are medium severity |
| Adversarial 1 | Gaming success criteria with warm-audience purchases | MARGINAL PASS | Missing cold-traffic validation check |
| Adversarial 2 | Premature kill with insufficient data volume | FAIL | Kill rule triggers on spend amount, not click volume — causes premature PIVOT decisions |

## Recommendations

1. **Fix kill rule to include click volume threshold:** Add to Day 3 and Rule 5: "Do not declare PIVOT if total link clicks are under 30 — you don't have statistically meaningful data regardless of spend. Extend by 2 days or increase daily budget before calling it dead."
2. **Add ad account approval prerequisite:** Add to Step 1: "Meta ad account is active and not in restricted/review status. New accounts may require 24-72 hours for first campaign approval — factor this into your timeline."
3. **Scale success criteria by spend level:** Replace flat purchase counts with spend-adjusted targets: "At $50 total spend: 1+ purchase is minimum viable. At $100 total spend: 2+ purchases. At $150 total spend: 3+ purchases. Adjust proportionally."
4. **Skill is ready for scoring** — the premature kill issue is a real gap but affects edge cases. Core architecture is sound.
