---
name: offer-arena
description: >
  Orchestrates competitive offer creation where 5 expert methodologies (Perry Belcher, John Carlton,
  Clayton Makepeace, Alex Hormozi, offer-architect) plus strategic synthesis compete head-to-head
  on the same brief. Produces 6 complete offer versions, has each critiqued, revises, judges for
  marketplace effectiveness, declares a winner, and evolves skills through learning. Use when:
  "offer arena", "compete my offer", "which offer approach wins", "battle-test my offer",
  "run offer competition", or when a student wants to see multiple expert approaches to the same offer.
version: 1.0.0
author: Strategic Profits
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/offer-arena"
  called_by: [user]
  outputs_to: [Obsidian vault project folder]
---

# Offer Arena v1.0

## What This Skill Does

The Offer Arena runs structured competitions where 5 offer methodologies compete on the same brief. Each competition:

1. Produces 6 complete offer versions (5 experts + 1 synthesis)
2. Has each version critiqued by its methodology's standards
3. Revises based on critique
4. Judges all entries for marketplace irresistibility
5. Declares a winner and produces learning
6. Tracks which methodologies win for which offer types

---

## NON-NEGOTIABLE RULES

| Rule | Consequence of Violation |
|------|--------------------------|
| EVERY expert MUST be spawned as SUB-AGENT via Agent tool | Output lacks methodology depth |
| Sub-agent loads the skill then EXECUTES the methodology | Skill loading into context alone produces nothing |
| ALL 6 entries MUST be produced before ANY judgment | Incomplete competition |
| Ledger MUST be saved after EVERY phase | Progress cannot be recovered |
| User override ALWAYS takes precedence over judge | Arena serves user, not algorithm |
| ALL project output goes to Obsidian vault, NEVER to `~/.claude/` | Output lost outside user's vault |
| Sub-agents MUST receive persona context optimized for the brief | 15-30% performance loss without persona priming |
| Truth documents (when present) are MANDATORY reading for all experts | Accuracy requirement |

**CRITICAL EXECUTION PATTERN:**
- **WRONG:** Orchestrator calls Skill tool -> Skill loads into orchestrator's context -> Orchestrator writes offer
- **RIGHT:** Orchestrator spawns sub-agent via Agent tool -> Sub-agent loads skill -> Sub-agent writes offer -> Returns output

---

## THE 5 OFFER ARCHITECTS + SYNTHESIS

### 1. Perry Belcher
**Skill:** `perry-offer-architecture`
**Strength:** Opportunity type classification, Points of Belief reduction, reframing repair to opportunity
**Best for:** Offers that need to shift how buyers see the category
**Persona:** Strategic categorizer. Sees every offer as one of four opportunity types. Obsessed with reducing points of belief to 1.
**Voice:** Southern confidence with mathematical precision. Makes complex positioning feel obvious.

### 2. John Carlton
**Skill:** `carlton-offers`
**Strength:** Guarantee engineering, risk reversal architecture, bonus stacking, conservative positioning
**Best for:** Offers where buyer risk is the primary conversion barrier
**Persona:** Risk-obsessed guarantee engineer. Every offer element exists to remove a reason NOT to buy.
**Voice:** Bar-room directness. No fluff, no hype, just irrefutable logic for why buying is the safe choice.

### 3. Clayton Makepeace
**Skill:** `clayton-offers`
**Strength:** Price psychology, multi-layer value architecture, emotional sequencing, offer structure
**Best for:** Offers that need sophisticated price-to-value framing
**Persona:** Analytical value architect. Builds offers in layers where each layer multiplies perceived value.
**Voice:** Analytical precision with emotional undercurrent. Makes complex value math feel intuitive.

### 4. Alex Hormozi
**Skill:** `hormozi-grand-slam-offer`
**Strength:** Value Equation optimization, constraint reduction, "so good they feel stupid saying no"
**Best for:** Offers that need to be category-of-one irresistible
**Persona:** Constraint optimizer. Maximizes Dream Outcome x Likelihood, minimizes Time x Effort.
**Voice:** Direct, specific, no-BS. Numbers over adjectives. Results over promises.

### 5. Offer Architect (Structural Baseline)
**Skill:** `offer-architect`
**Strength:** 5-layer value stacking, stress testing, price anchoring, structural completeness
**Best for:** Baseline structural soundness â ensures nothing is missing
**Persona:** Structural purist. Every element valued, every risk reversed, every claim anchored.
**Voice:** Forensic analyst. Comparison tables, specific numbers, evidence-based.

### 6. Synthesis
**Approach:** Combines the strongest elements from all 5 based on brief analysis
**Strength:** Integration â takes the best guarantee from Carlton, best value framing from Clayton, best constraint reduction from Hormozi, best positioning from Perry, best structure from offer-architect
**Best for:** When no single methodology covers all the brief's needs
**Voice:** Unified â the reader never sees the seams.

---

## MANDATORY EXECUTION SEQUENCE

### PHASE 0: PRE-FLIGHT CHECKS

| Step | Check | Validation |
|------|-------|------------|
| 0.1 | All 5 expert skills exist | perry-offer-architecture, carlton-offers, clayton-offers, hormozi-grand-slam-offer, offer-architect |
| 0.2 | Obsidian output path writable | Test file created successfully |
| 0.3 | Ledger accessible | `~/.claude/offer-arena/ledger.md` exists or created |

**GATE:** All checks passed? Proceed. Any failure? STOP and report.

---

### PHASE 0.5: ROUTING â NEW OR EXISTING OFFER?

**Before doing anything else, ask the student:**

> Do you already have an offer you'd like to improve, or are you building one from scratch?
>
> 1. **Build from scratch** â I'll have 5 expert methodologies each create a competing offer for you
> 2. **Improve my existing offer** â I'll have 5 experts diagnose what's working, what's not, and produce a revised version

- If **Option 1** â proceed to Phase 1 (standard competition flow)
- If **Option 2** â ask them to paste or provide their existing offer document, then jump to **Audit Phase 1** (see AUDIT mode section below)

**Do NOT skip this question.** Even if the user ran `/offer-arena` with no mode flag, always ask.

---

### PHASE 1: SETUP

**OUTPUT PATH:** All project output MUST be saved to:
```
[Obsidian Vault]/00 Projects/Offer Arena/{competition_name}/
```

| Step | Action | Validation |
|------|--------|------------|
| 1.1 | Create project folder in Obsidian vault | Folder exists |
| 1.2 | Parse brief â extract: product, price, buyer, dream outcome, constraints, truth docs | All variables populated |
| 1.3 | Initialize ledger entry | Entry visible in `~/.claude/offer-arena/ledger.md` |
| 1.4 | Read truth documents (if provided) | Consumption receipt produced |

**GATE:** Project folder created? Brief parsed? Truth docs consumed? -> Proceed to Phase 2

---

### PHASE 2: PARALLEL OFFER DRAFTING

Spawn the 5 expert sub-agents in parallel. After all 5 complete, spawn Synthesis (which reads their outputs). Each receives:
- The brief
- Truth documents (if any)
- Persona context (from section above)
- Output file path

**Sub-Agent Spawn Template:**
```
Agent tool invocation:
  subagent_type: "general-purpose"
  description: "[Expert] offer design"
  prompt: |
    # PERSONA CONTEXT
    [Insert persona from THE 5 OFFER ARCHITECTS section]

    # OUTPUT FILE PATH (CRITICAL)
    Write your completed offer to:
    [vault]/00 Projects/Offer Arena/{competition_name}/round-{N}/drafts/{expert}-offer.md

    # YOUR TASK
    Design a complete offer using the [methodology] methodology.

    ## Step 1: Load Your Methodology
    Use the Read tool to read the full SKILL.md file at:
    ~/.claude/skills/[skill-name]/SKILL.md
    This is your methodology. Follow it completely.

    ## Step 2: Read the Brief
    [Full brief here]

    ## Step 3: Execute Your Methodology
    Follow the skill's complete workflow. Produce the FULL offer architecture.
    Include: value stack, pricing, guarantee, bonuses, urgency, stress test results.

    ## Step 4: Write to File
    Save complete offer to the OUTPUT FILE PATH.
    Return ONLY: "Offer saved to [path], compliance: [PASS/FAIL]"

    # CONSTRAINTS
    - Stay in character as [Persona].
    - Every claim must be traceable to the brief.
    - MUST write to file path directly.
```

| Step | Action | Validation |
|------|--------|------------|
| 2.1 | Spawn Perry sub-agent | File exists with Perry signature elements |
| 2.2 | Spawn Carlton sub-agent | File exists with Carlton signature elements |
| 2.3 | Spawn Clayton sub-agent | File exists with Clayton signature elements |
| 2.4 | Spawn Hormozi sub-agent | File exists with Hormozi signature elements |
| 2.5 | Spawn offer-architect sub-agent | File exists with structural completeness |
| 2.6 | Spawn Synthesis sub-agent | File exists with combination rationale |
| 2.7 | Verify all 6 draft files exist | 6 files in drafts/ folder |

**GATE:** All 6 files present? -> Proceed to Phase 3

---

### PHASE 3: CRITIQUE (Parallel)

Each offer is critiqued against its own methodology's standards.

| Expert | Critic Focus |
|--------|-------------|
| Perry | Does the offer correctly classify opportunity type? Are points of belief minimized? |
| Carlton | Is the guarantee bulletproof? Is risk truly reversed? Are bonuses justified? |
| Clayton | Does the price architecture work? Is value layering compelling? Is emotional sequence right? |
| Hormozi | Does the Value Equation score high enough? Are all 4 levers optimized? Does it pass the Stupid Test? |
| offer-architect | Are all 5 layers present? Do all stress tests pass? Is price properly anchored? |
| Synthesis | Is the combination strategic? Do elements work together? Is the voice unified? |

Spawn critic sub-agents with the marketplace-judge agent type. Each critic:
1. Reads the offer
2. Grades against methodology standards (A+ through F)
3. Lists specific fixes (not vague suggestions)
4. Saves critique to `round-{N}/critiques/{expert}-critique.md`

**GATE:** All 6 critiques saved? -> Proceed to Phase 4

---

### PHASE 4: REVISION (Parallel)

Each expert receives their critique and revises.

Spawn revision sub-agents â same persona as Phase 2, but now include:
- Original offer
- Critique with specific fixes
- Instruction: "Address every fix. Do not lose what already works."

Output: `round-{N}/revisions/{expert}-revised.md`

**GATE:** All 6 revised offers saved? -> Proceed to Phase 5

---

### PHASE 5: JUDGMENT

Spawn a single marketplace-judge agent that reads all 6 revised offers and evaluates:

**Judgment Criteria (Offer-specific, NOT copy-specific):**

| Criterion | Weight | What It Measures |
|-----------|--------|-----------------|
| **Irresistibility** | 25% | Would the target buyer feel stupid saying no? |
| **Value Architecture** | 20% | Is the value stack compelling and properly valued? |
| **Risk Reversal** | 15% | Is the guarantee strong enough to eliminate fear? |
| **Price Psychology** | 15% | Does the pricing feel like arbitrage, not cost? |
| **Structural Completeness** | 10% | Is anything missing? (Bonuses, urgency, guarantee, payment options) |
| **Differentiation** | 10% | Does this offer feel like a category of one? |
| **Stress Test Results** | 5% | Did it pass the Stupid/Swap/Objection/Math/Urgency tests? |

**Judge Output:** `round-{N}/judgment.md`

```markdown
# Offer Arena Judgment: {competition_name} Round {N}

## Entries Evaluated
[List all 6 with 1-line summary of approach]

## Scoring Matrix
| Entry | Irresistible (25%) | Value (20%) | Risk (15%) | Price (15%) | Complete (10%) | Different (10%) | Stress (5%) | TOTAL |
|-------|--------------------|-------------|------------|-------------|----------------|-----------------|-------------|-------|
| Perry | X/10 | X/10 | X/10 | X/10 | X/10 | X/10 | X/10 | X/100 |
| [etc.] | | | | | | | | |

## WINNER: [Expert]
Score: XX/100
[Why this offer wins in the marketplace â specific evidence]

## RUNNER-UP: [Expert]
Score: XX/100
[What made this strong, why it lost]

## Key Insights
- [What worked across entries]
- [What no entry solved well]
- [Surprising finding]

## Methodology Win Pattern
- This offer type ([description]) favors: [methodology] because [reason]
```

**GATE:** Winner declared with scoring? -> Proceed to Phase 6

---

### PHASE 6: LEARNING INTEGRATION

After judgment:

1. **Update win ledger** at `~/.claude/offer-arena/ledger.md`:
```markdown
## Competition: {name} | Date: {date}
- Winner: {expert} (Score: XX/100)
- Runner-up: {expert} (Score: XX/100)
- Offer type: {type}
- Price point: ${X}
- Key insight: {what the winner did differently}
```

2. **Update win rates** at `~/.claude/offer-arena/win-rates.md`:
```
OFFER METHODOLOGY WIN RATES
Perry:          XX% (X/X)
Carlton:        XX% (X/X)
Clayton:        XX% (X/X)
Hormozi:        XX% (X/X)
offer-architect: XX% (X/X)
Synthesis:      XX% (X/X)
```

3. **Extract winning patterns**: What techniques from the winner could be taught to other methodologies?

4. **Save competition summary** to project folder: `arena-summary.md`

---

## OUTPUT STRUCTURE

```
[Obsidian Vault]/00 Projects/Offer Arena/{competition_name}/
âââ brief.md
âââ truth-docs/ (if provided)
âââ round-1/
â   âââ drafts/
â   â   âââ perry-offer.md
â   â   âââ carlton-offer.md
â   â   âââ clayton-offer.md
â   â   âââ hormozi-offer.md
â   â   âââ offer-architect-offer.md
â   â   âââ synthesis-offer.md
â   âââ critiques/
â   â   âââ {expert}-critique.md (x6)
â   âââ revisions/
â   â   âââ {expert}-revised.md (x6)
â   âââ judgment.md
âââ round-2/ (if multi-round)
â   âââ [same structure]
âââ final/
â   âââ winner.md (the winning offer, ready to use)
â   âââ learning-summary.md
âââ arena-summary.md
```

---

## MODES

### `full` â Complete Competition (default)
All phases: drafting, critique, revision, judgment, learning.
Produces all 6 offers + winner declaration.

### `quick` â Speed Round
Single round, no critique/revision cycle.
Draft -> Judge -> Winner.
Use when: need fast comparison, will iterate later.

### `head-to-head [expert1] vs [expert2]`
Only 2 experts compete (plus synthesis).
Use when: narrowed down to 2 approaches, need tiebreaker.

### `audit` â Diagnose & Improve an Existing Offer
Ingests an existing offer document, runs all 5 expert methodologies as diagnostic lenses, and produces a revised offer with a gap report. Use when: student already has an offer and wants to improve it, not start from scratch.

**Audit Execution Sequence:**

#### Audit Phase 1: Ingest Existing Offer
| Step | Action | Validation |
|------|--------|------------|
| A1.1 | Read the existing offer document completely | Consumption receipt produced |
| A1.2 | Extract: product, price, buyer, dream outcome, value stack, guarantee, bonuses, urgency mechanism | All variables populated |
| A1.3 | Create project folder: `[Vault]/00 Projects/Offer Arena/{offer-name}-audit/` | Folder exists |
| A1.4 | Save original offer as `original-offer.md` in project folder | File saved |

#### Audit Phase 2: Expert Diagnostics (Parallel)
Spawn all 5 expert sub-agents in parallel. Each receives:
- The full existing offer document
- Their methodology skill file
- Instruction: "Diagnose this offer through YOUR methodology lens. Do NOT rewrite from scratch."

Each expert produces:

```markdown
# {Expert} Diagnostic: {Offer Name}

## Methodology Lens
[1-2 sentence summary of what this methodology looks for]

## Stress Test Results
| Test | Pass/Fail | Evidence |
|------|-----------|----------|
| [Methodology-specific tests] | | |

## Strengths (What's Working)
- [Specific element] â why it works from this methodology's perspective

## Gaps (What's Missing or Weak)
- [Specific gap] â what the methodology prescribes instead
- [Specific gap] â severity: HIGH/MEDIUM/LOW

## Recommended Fixes (Specific, Not Vague)
1. [Fix] â exact change with before/after example
2. [Fix] â exact change with before/after example
3. [Fix] â exact change with before/after example

## Revised Elements
[Only the elements this expert would change, fully rewritten]
```

Output: `audit/diagnostics/{expert}-diagnostic.md` (x5)

**GATE:** All 5 diagnostics saved? -> Proceed to Audit Phase 3

#### Audit Phase 3: Synthesis â Combined Fix Plan
Spawn a Synthesis sub-agent that reads all 5 diagnostics and produces:

```markdown
# Combined Diagnostic: {Offer Name}

## Overall Grade: [A through F]
[1-paragraph summary of offer health]

## Consensus Strengths (2+ experts agree)
- [Element] â validated by: {experts}

## Consensus Gaps (2+ experts flagged)
- [Gap] â flagged by: {experts} â severity: HIGH/MEDIUM/LOW

## Expert-Specific Insights (unique to one methodology)
- [Perry only]: [insight]
- [Carlton only]: [insight]
- [etc.]

## Priority Fix List (Ranked by Impact)
| # | Fix | Source Expert(s) | Severity | Effort |
|---|-----|-----------------|----------|--------|
| 1 | [Highest-impact fix] | {experts} | HIGH | [Low/Med/High] |
| 2 | [Next fix] | {experts} | HIGH | |
| [etc.] | | | | |

## Revised Offer (Complete)
[The full offer document with ALL consensus fixes applied.
Maintains the original structure and voice where possible.
Marks changes with <!-- CHANGED: reason --> comments.]
```

Output: `audit/combined-diagnostic.md` and `audit/revised-offer.md`

#### Audit Phase 4: Before/After Comparison
Produce a comparison document:

```markdown
# Before/After: {Offer Name}

## Score Comparison
| Criterion | Original | Revised | Delta |
|-----------|----------|---------|-------|
| Irresistibility | X/10 | X/10 | +X |
| Value Architecture | X/10 | X/10 | +X |
| Risk Reversal | X/10 | X/10 | +X |
| Price Psychology | X/10 | X/10 | +X |
| Structural Completeness | X/10 | X/10 | +X |
| Differentiation | X/10 | X/10 | +X |
| Stress Tests | X/5 passed | X/5 passed | +X |

## Key Changes Made
1. [Change] â why (from {expert} diagnostic)
2. [Change] â why
3. [Change] â why

## What Was Kept Unchanged (And Why)
- [Element] â already strong per {experts}
```

Output: `audit/before-after.md`

**Audit Quality Gate:**
- [ ] Original offer ingested with consumption receipt
- [ ] All 5 expert diagnostics produced
- [ ] Combined diagnostic identifies consensus + unique insights
- [ ] Priority fix list ranked by impact
- [ ] Revised offer preserves original structure where possible
- [ ] Before/after comparison with scores
- [ ] No fabricated proof points in revised offer

---

## QUALITY GATE

Before declaring competition complete:

- [ ] All 6 offers produced and saved to disk
- [ ] All offers address the same brief (no drift)
- [ ] Critiques reference methodology-specific standards
- [ ] Revisions address specific critique points
- [ ] Judgment uses all 7 criteria with weights
- [ ] Winner declared with specific evidence (not preference)
- [ ] Ledger updated with results
- [ ] Win rates recalculated
- [ ] Arena summary saved to project folder
- [ ] No fabricated proof points in any offer
