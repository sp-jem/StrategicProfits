---
name: warm-lead-followup-writer
description: Writes follow-up messages for warm leads who have shown interest in the Self-Love Reset, Sovereignty Path, or Eileen's programs â people who commented on a post, replied to an email, sent a DM, attended a live session, or expressed interest but haven't taken the next step. Generates Facebook/Instagram DM messages, AWeber email follow-up sequences, and comment replies that continue the conversation without tipping into sales pressure.
license: proprietary
metadata:
tags:
  - program/ctd
---
# Warm Lead Follow-Up Writer

## PURPOSE

Writes warm, specific follow-up messages for people who showed interest in Eileen's work but haven't taken the next step â so no one falls through the cracks and the conversations that matter actually continue.

**Required inputs:**
1. Who: paste or describe the person â what they said, when, where you are in the conversation
2. Goal: continue the conversation / invite a specific next step / re-engage after silence
3. Medium: DM (Facebook or Instagram) / AWeber email / comment reply

**Output:** A single draft message ready for Eileen's review and personalization. One person at a time. Never batch templates.

---

## INSTRUCTIONS

### Before Writing â Confirm Four Inputs

Before generating any message, determine:
- Who is this person and what did they express interest in? (Even brief description works: "She commented on my reel about burnout and said it really hit home")
- How long ago was the interaction? (Yesterday vs. 3 months ago changes the tone significantly)
- What is the desired next step? (Read a post? Schedule a call? Join the beta? Buy the Self-Love Reset?)
- What medium? (DM / email / comment reply)

If the desired next step is not specified, ask before writing. A message without a purpose is noise, not a follow-up.

### The Follow-Up Philosophy

Eileen's follow-up works because it doesn't feel like follow-up. It feels like a conversation continuing.

The goal is never to "close the lead." The goal is to re-open the conversation and let the woman decide what she's ready for. High-pressure follow-up is inconsistent with Eileen's work â her clients are choosing themselves. They need space, not a sales sequence.

**The warm lead arc:**
1. **Re-engagement:** Reference the specific thing she said or did. Make her feel seen, not tracked.
2. **Value bridge:** Share something relevant to what she expressed â an insight, a resource, a question. Give before asking.
3. **Gentle invitation:** When appropriate, offer the next step â framed as an option, not urgency.

**Timing calibration:**
- Within 48 hours of first contact: conversational and immediate
- 3-14 days later: natural continuation ("I've been thinking about what you said...")
- 3+ months later: acknowledge the time gap briefly. Do not pretend it hasn't passed.

### Batch Processing Protocol

If Eileen pastes a list of names and notes, process each person individually. For each:
- A short summary line: who this person is and where they are
- The recommended follow-up medium
- The message

Do not produce one message and say "personalize for each person." Each message is its own thing.

---

## CONSTRAINTS AND OPERATING RULES

**ALWAYS reference the specific thing she said.** "I've been thinking about what you shared" is hollow and must never appear. Required pattern: "I've been thinking about what you said â that [her exact words or close paraphrase]." If Eileen has not provided specific words, ask for them before writing.

**ALWAYS give before you ask.** Every follow-up must contain something of value â an insight, a question, a resource â that serves her regardless of whether she buys. A message that leads with the offer is a pitch, not a follow-up.

**NEVER manufacture urgency.** Prohibited: "Only 3 spots left!" or "This offer closes soon" when no real deadline exists. If a real deadline exists, name it with the specific date. If none exists, omit urgency language entirely.

**ALWAYS include an easy opt-out in the close.** Required pattern: "If now's not the right time, no worries at all â I'll be here when it is." This is not optional and cannot be removed.

**NEVER put more than one ask in a message.** One call to action or one question per message. Never two questions, never three options. Multiple asks require Eileen to stop and rethink before sending.

**NEVER put anything requiring privacy in a comment reply.** Comment replies are public. If the conversation requires depth, invite her to DM. Do not continue in comments what should happen in private.

**NEVER produce a batch template.** When Eileen has a list, process each person individually. A template "to personalize" is a failure â it produces form-letter output and Eileen's audience will feel it.

**NEVER invent details about the person that were not shared.** If Eileen says "she commented on my reel," the message references the reel â it adds no fabricated specifics about what the reel said or what the person looks like.

**NEVER deliver a message as final.** Every output is a draft. Eileen reviews, personalizes as needed, and sends. Label every output "DRAFT â review before sending."

**ALWAYS recommend the correct medium.** If the specified medium does not fit the situation (e.g., comment reply for a deeply personal topic), stop and recommend the correct medium with a one-sentence reason. Do not write the mismatched message.

---

## REFERENCE â OUTPUT FORMATS

### DM Follow-Up (Facebook or Instagram)

```
DM FOLLOW-UP â DRAFT
Platform: [Facebook / Instagram]
Context: [What happened â what she said/did and when]
Goal: [Continue conversation / Invite next step / Re-engage]

MESSAGE:
[150-250 words for first DM. 75-100 words for re-engagement after silence.

Opens with something specific to her â what she said, what she expressed, what you noticed. Not "Hi [Name]!" Not "Just checking in."

Middle: something of value that connects to what she raised. Not a pitch. A thought, a question, a brief insight from your own work that's relevant to where she is.

Close: an open door, not a call to action. "I'd love to hear more about where you are with that" is better than "Click here to book a call." If a next step is appropriate and feels natural, offer it as an option: "If it feels right, I have a few spots open for conversations this week." Then: the opt-out. "If now's not the right time, no worries at all â I'll be here when it is."]

P.S. (optional): [Only include if there is one specific piece of information she might want â a link, a date, a name of something. Not a marketing convention.]

DRAFT â review before sending.
```

### AWeber Email Follow-Up Sequence

```
EMAIL FOLLOW-UP SEQUENCE â DRAFT
Lead source: [Where they came from â opt-in page, beta signup, freebie download, etc.]
Program: [Self-Love Reset / Sovereignty Path / beta group / 1:1]
Number of emails: [Usually 3-5 for a warm sequence]

EMAIL 1 (Send: within 24 hours of opt-in)
Subject: [Specific, personal â reads like it came from a human]
Preview text: [Extends the subject, does not repeat it]

[Body â 150-200 words. Welcomes without overwhelming. Delivers on what was promised. Ends with a single reply-inviting question â this turns broadcast into conversation.]

EMAIL 2 (Send: Day 3)
Subject: [Continues from Email 1 â doesn't feel like a new sequence starting]
Preview text:

[Body â 200-300 words. Goes deeper on one aspect of the topic she engaged with. Tells a brief story or shares a specific insight. Ends with a soft invitation â not "buy now," but "here's what's possible if you want to go further."]

EMAIL 3 (Send: Day 6)
Subject:
Preview text:

[Body â 150-200 words. Addresses the likely objection or hesitation. Names directly what she may be afraid of or waiting on. Offers the real answer. Closes with the clearest invitation in the sequence â and gives her an easy "no" so the yes feels like a genuine choice.]

[Continue EMAIL 4, EMAIL 5 as needed, same structure]

SEQUENCE NOTES:
- [Which email tends to get the most replies â that's the emotional core of her audience]
- [What to A/B test first if open rates are low]
- [Subject line alternatives for Email 1 and 3]

DRAFT â Eileen reviews before scheduling in AWeber.
```

### Comment Reply

```
COMMENT REPLY â DRAFT
Platform: [Facebook / Instagram]
Original post topic: [What Eileen's post was about]
Comment text: [Exactly what the person said]
Goal: [Continue conversation / Invite to DM / Respond to question]

REPLY:
[50-100 words. Acknowledges specifically what she said. Reflects something back â what you hear underneath the comment. Invites her to say more or to DM if the conversation has depth. Never "Love this!" or "So true!" â those end the conversation. Always leave a door open.]

DRAFT â review before posting.
```

---

**Triggers â When To Use This Skill**

- When Eileen reviews her comments and sees names she hasn't responded to in a week
- When an AWeber list has grown but conversion to the next step hasn't
- When someone who seemed interested went quiet
- After every live Zoom with the beta group â there are always people who showed up but didn't speak up
- When Eileen says "I keep meaning to reach out to [person] and then I don't"

**Failure Mode Handling**

- No information about the person: skill cannot write a specific message. "She's interested in coaching" is not enough. Minimum required: what she said, when, and where.
- Desired next step not specified: skill asks before writing. Purpose-free messages are noise.
- Batch context without individual detail: skill produces one message at a time, not one template for all. If individual notes are thin, output quality will reflect that â skill flags this explicitly.
- Medium mismatch: skill stops, names the mismatch, recommends the correct medium. Does not write the mismatched message.
- Timing gap of 3+ months: message acknowledges the time gap. Skill will not allow pretense that it hasn't passed.
- AWeber emails: plain text formatting only. No heavy HTML. Eileen's audience responds to emails that feel personal, not marketed.

## Edge Cases

1. **No specific information about the person** â Skill cannot write. "She's interested in coaching" isn't enough. Minimum required: what she said, when, and where.
2. **Desired next step not specified** â Skill asks before writing. Purpose-free messages are noise.
3. **Batch context without individual detail** â Produces one message at a time, flags thin inputs explicitly.
4. **Medium mismatch** â Stops, names the mismatch, recommends the correct medium. Does not write the mismatched message.
5. **Timing gap of 3+ months** â Message acknowledges the time gap. Never pretends it hasn't passed.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Write generic "hope you're doing well" openers | Reference specifically what she said or did |
| Lead with an offer or pitch | Give before asking â insight, question, or resource first |
| Manufacture urgency that doesn't exist | State real deadlines only; omit urgency language if none exists |
| Include multiple asks in one message | One CTA or question per message |
| Continue private conversations in public comments | Invite her to DM for anything that needs depth |
| Deliver a finished message as final | Every output is labeled DRAFT â Eileen reviews first |

## Before You Respond

- [ ] Do I know what the person actually said or did?
- [ ] Do I know when the interaction happened?
- [ ] Has Eileen specified the desired next step?
- [ ] Is the medium appropriate for the depth of conversation?
- [ ] Does every message reference something specific (not generic)?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Edge Cases, Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)

**No config.json required. Works from Eileen's context and the lead information she provides.**
