---
name: linkedin-voice-setup
description: One-time setup. Reads your proof-stack-builder output and auto-populates your LinkedIn voice file. Run once after proof-stack-builder finishes — then all 3 LinkedIn skills are immediately ready to use.
trigger_phrases:
  - linkedin voice setup
  - setup my linkedin voice
  - populate voice file
  - setup linkedin from proof stack
---

# LinkedIn Voice Setup

## PURPOSE

This skill reads a completed proof-stack-builder output file and populates the LinkedIn voice configuration used by all three LinkedIn skills (linkedin-post, linkedin-lead-magnet, linkedin-trending-topics). It runs once, at setup.

**This skill does:**
- Find and read the proof-stack-builder output file
- Extract authority statement, beliefs, distinctions, proof points, audience profile, and content pillars
- Write extracted data to `~/.claude/skills/linkedin-post/references/voice-template.md`
- Confirm what was populated and flag what requires manual input

**This skill does NOT:**
- Create, invent, or synthesize content that was not in the proof stack
- Write LinkedIn posts (that is linkedin-post's job)
- Run more than once per proof stack version without user confirmation
- Proceed if the target voice-template.md path does not exist

**Success criteria:** Voice file contains zero placeholder text in sections where proof stack data was available, and every gap is labeled `[Not found in proof stack — add manually]` rather than left blank or filled with invented content.

## TRIGGER

User invokes `/linkedin-voice-setup` after running proof-stack-builder.

---

## CONSTRAINTS

**NEVER invent content.** If a section of the voice file cannot be filled from the proof stack, write `[Not found in proof stack — add manually]`. Do NOT write plausible-sounding placeholder content. Fabricated voice data produces generic posts that defeat the entire system.

**NEVER overwrite a field that already contains real content** unless the user explicitly requested a re-run. Before writing, check whether voice-template.md already has populated sections.

**ALWAYS verify the target path exists** (`~/.claude/skills/linkedin-post/references/voice-template.md`) before writing. If it does not exist:
```
BLOCKED: The linkedin-post skill is not installed at the expected location.
Install linkedin-post first, then re-run /linkedin-voice-setup.
```

**ALWAYS confirm extraction completeness before proceeding.** If fewer than 3 of the 7 sections can be populated from the proof stack, surface this before writing: "Only [N] of 7 voice sections have data in your proof stack. The setup will work but your voice file will need significant manual input. Continue?"

**NEVER report setup as complete** if the write to voice-template.md failed or produced no changes.

**NEVER proceed with a file under 500 words.** Flag it: "The proof stack file I found appears incomplete ([N] words). A full proof stack is typically 1,500+ words. Is this the right file?"

---

## REFERENCE — EXEMPLARS

### Good extraction: CORE BELIEFS section

```
**Most business owners think more traffic is the answer. It isn't.** The real problem is always the offer — and until you fix that, you're paying to amplify a broken message.

**Tactical advice is the most expensive kind.** It solves the symptom while the underlying positioning problem compounds. Tactics without strategy equals faster failure.

**You don't have a marketing problem. You have a clarity problem.** When you can describe your customer's pain better than they can, they assume you have the solution.
```

### Bad extraction (NEVER produce this)

```
I believe in helping entrepreneurs grow their businesses using proven strategies.
I am passionate about providing value to my clients and seeing them succeed.
I think that with the right mindset, anything is possible.
```

This is what gets generated when the model invents rather than extracts. It is worthless for LinkedIn differentiation and will produce generic posts every time.

### Good extraction: Gap handling

```
**YOUR DISTINCTIONS:**
- The "Positioning Audit" framework [from proof stack — deploy immediately]
- Revenue per employee as core metric [from proof stack — deploy immediately]
- [Not found in proof stack — add manually: any proprietary method names or contrast frameworks you use]
```

---

## EXECUTION

### Step 1: Find the Proof Stack Output

Look for the proof-stack output file in these locations (in order):

1. `~/Documents/` — search for any file matching `*proof-stack*.md` (newest first)
2. `~/Desktop/` — search for any file matching `*proof-stack*.md`
3. `~/.claude/skills/linkedin-voice-setup/proof-stack-output.md` — manual drop location

Use the Glob tool with pattern `~/Documents/*proof-stack*.md` and `~/Desktop/*proof-stack*.md`. If multiple files exist, use the most recently modified.

**After running Glob — verify before reading:**
- If no files returned: proceed to the not-found message below
- If files returned: confirm the filename contains a recognizable date or business name. A file named `proof-stack-template.md` is the blank template — skip it.
- If the file is under 500 words: flag and ask before proceeding (see CONSTRAINTS)
- A file named with the pattern `[business-name]-proof-stack-[date].md` is the correct target

**If nothing found:**
"I couldn't find your proof-stack output automatically. Drop the full file path here and I'll read it. (It was saved as [business-name]-proof-stack-[date].md — check ~/Documents/ or ~/Desktop/)"

Read the full file content once found.

### Step 2: Extract the Key Sections

Extract these 7 sections from the proof stack. For each, follow the Source/Target guidance. If no source data exists for a section, write `[Not found in proof stack — add manually]` — never invent.

**WHO YOU ARE (authority statement):**
- Source: The one-sentence bio from the BIO PROOF LANGUAGE output (OUTPUT 2)
- Supplement with: years of experience, who they help, their proprietary method name if confirmed
- Target: 2-4 sentences establishing authority. No unearned status words ("renowned," "leading," "top," "guru").

**CORE BELIEFS:**
- Source: Contrarian positions confirmed during the proof stack interview phase; differentiation from competitors noted in the market analysis
- Target: 3-5 statements in the format `**[Belief statement].** [Why — one sentence.]`

**YOUR DISTINCTIONS:**
- Source: Named frameworks, proprietary methods, "X vs Y" contrasts confirmed in the interview
- Target: List of 5-10 distinctions the user can build posts around

**YOUR CREDENTIALS & PROOF:**
- Source: PROOF INVENTORY, Tier 1 items — confirmed, deployable evidence
- Target: Bulleted list of specific proof points with numbers, client types, and measurable outcomes

**YOUR AUDIENCE:**
- Source: Market analysis phase — who responds to this type of proof, what frustrations drive them
- Target: Who they are, their core frustration, what they want, what repels them

**YOUR CONTENT PILLARS:**
- Source: Main categories of the user's work, their proof vectors, topics they have confirmed evidence in
- Target: 3-5 topic areas with 1-line descriptions

**YOUR LEAD MAGNET CTA:**
- Source: The user's website URL (from proof stack research or site-config.json)
- Target: Site URL + CTA phrase (e.g., "Link in comments")

### Step 3: Write the Voice File

Write the extracted data to `~/.claude/skills/linkedin-post/references/voice-template.md`.

Rules:
- Replace ALL placeholder/instruction text (lines starting with `>`) with real extracted content
- Keep section headers — the format must remain consistent for downstream skills
- Use only information confirmed in the proof stack
- Write beliefs and authority statements in first person
- Every gap is labeled `[Not found in proof stack — add manually]` — never blank, never invented

### Step 4: Confirm and Show

After writing, show the user:

```markdown
## Voice File Populated

Your LinkedIn voice file has been configured from your proof stack.

**Populated from proof stack:**
- WHO YOU ARE: [1-sentence preview]
- Core beliefs: [N] extracted
- Distinctions: [N] extracted
- Proof points: [N] Tier 1 items loaded
- Audience: [1-line summary]
- Content pillars: [N] identified

**Needs your input:**
- [List any sections that received the [Not found] label]

**Voice file location:** ~/.claude/skills/linkedin-post/references/voice-template.md

You're ready. Try:
  /linkedin-trending-topics — find what your audience is discussing now
  /linkedin-post [any idea] — write a post in your voice
  /linkedin-lead-magnet [topic] — create a lead magnet and publish it to your site
```

### Step 5: Optional Calibration Test

Offer: "Want me to write one test post to confirm your voice is calibrated? Give me any topic."

If yes — write one LinkedIn post using the newly populated voice file. Show it. Ask: "Does this sound like you? If a specific section is off (too formal, wrong industry framing, missing a key credential), tell me which section of the voice file to adjust."

Do not offer to "adjust the voice file" generically — ask for the specific field and the correction.

---

## OUTPUT

The primary deliverable is the populated voice file written to disk. The confirmation message in Step 4 is the output shown to the user. No additional formatting required.
