---
name: titans-outbound-sequencer
description: Builds complete outbound sales sequences for recruiting Titans of Industry mastermind members. Takes a prospect name, background, and current business situation and produces a full multi-touch DM + email sequence written in Steve Larsen's provocateur voice. Use when Steve wants to reach out to a specific prospect, when prepping outreach for Marley to execute, or when systematizing the path from 20 to 50 Titans members. Trigger phrases include "write outreach for," "DM sequence for," "recruit [name] to Titans," or "build a sequence."
license: proprietary
metadata:
tags:
  - program/ctd
---
# Titans Outbound Sequencer

Builds personalized multi-touch outbound sequences to recruit 7-figure entrepreneurs into Titans of Industry.

---

## Purpose

Produce a finished 5-touch DM + email outbound sequence personalized to a specific prospect. Output is copy-ready to execute â not a template, not a framework, not a guide. Every touch is a finished message written in Steve Larsen's voice, ready for Steve or Marley to send without editing.

---

## Instructions

### Step 1 â Prospect Profile Build

From the information provided, construct a one-paragraph internal brief:
- Who this person is in the market
- What they're likely struggling with at their level (7+ figures typically: team chaos, revenue plateau, isolation at the top, wrong seat, partner friction)
- Why Titans specifically solves something real for them â not generically, but for this person
- The hook: what angle will get their attention first

### Step 2 â Sequence Architecture

Build a 5-touch sequence across two channels (DM + email). Structure:

| Touch | Channel | Timing | Objective |
|-------|---------|--------|-----------|
| Touch 1 | DM | Day 1 | Pattern interrupt. No pitch. |
| Touch 2 | Email | Day 3 | Context + credibility. First mention of Titans. |
| Touch 3 | DM | Day 6 | Social proof + curiosity hook. |
| Touch 4 | Email | Day 10 | Direct invitation. Why them. Why now. |
| Touch 5 | DM | Day 14 | Final follow-up. Closes the loop. |

### Step 3 â Write All 5 Touches

Write each touch in full. Not templates. Not placeholders. Finished copy ready to send.

**Steve's voice rules:**
- Opens without throat-clearing. First sentence is the thing.
- Provocateur energy â says what other people won't say. Names the real problem.
- Short paragraphs. DMs: 1-3 sentences max per paragraph.
- Ends with a clear single next step â never multiple options.
- Never begs. The offer is strong. The tone reflects that.

---

## Operating Rules

**NEVER begin writing the sequence until all three required inputs are confirmed.** A generic sequence is worse than no sequence. If inputs are thin, ask before producing output.

**NEVER pitch in Touch 1.** Touch 1 is human-to-human contact. Any Touch 1 that mentions Titans, a price, or an invitation is a disqualifying failure â rewrite it before delivering.

**NEVER use hype language.** Prohibited: "incredible opportunity," "game-changing," "life-changing," "synergy," or any equivalent. Steve does not talk like this. Flag and remove any such phrase before output is delivered.

**NEVER state the Titans price ($25K + $2,500/month) anywhere in the sequence.** Price is disclosed on the call, not in outreach. Including it in the sequence is a disqualifying error.

**NEVER produce a generic sequence.** If the prospect information is too thin to personalize, state: "The prospect profile is too thin to write a specific sequence. Provide [specific missing details] before I proceed." Do not fill gaps with invented details.

**NEVER use "we" framing.** Steve's voice is first-person singular. Every touch is Steve reaching out as Steve, not as a company or team.

**NEVER include multiple CTAs in a single touch.** One next step per message. Two options in a single message is a constraint violation â rewrite before delivering.

**ALWAYS adjust voice when Marley is executing.** If Steve notes Marley is the sender, produce warmer, relationship-first copy and label the output "Marley voice." Do not write Marley's voice as Steve's.

**Failure modes:**
- If prospect name is provided but no background: STOP. Ask for business context and entry point before proceeding.
- If a voice note or rough description is provided: extract the three required elements (name, background, entry point) from it before building â do not ask for what is already in the input.
- If Steve requests a sequence for someone he has never met and has no mutual connection: flag the cold-contact risk. Touch 1 becomes an observation about their work or market â never a reference to a prior interaction that didn't happen. Open with something specific Steve noticed (a post, a podcast appearance, a business move) that shows genuine attention, not familiarity.

---

## Output Format

```
TITANS OUTBOUND SEQUENCE
Prospect: [Name]
Built: [Date]
Current Titans count: [X] of 50 target
Voice: [Steve / Marley]

---

PROSPECT BRIEF (internal, not sent)
[2-3 sentence read on this person â why they're right for Titans and what angle to use]

---

TOUCH 1 â DM (Send Day 1)
[Finished DM copy â 2-4 sentences. No pitch. Pattern interrupt.]

---

TOUCH 2 â EMAIL (Send Day 3)
Subject: [Subject line]

[Finished email â 150-200 words. Context + who Steve is + first mention of Titans as a soft reference, not a pitch.]

---

TOUCH 3 â DM (Send Day 6)
[Finished DM â 3-5 sentences. Drop a specific Titans result or member win. Curiosity hook at the end.]

---

TOUCH 4 â EMAIL (Send Day 10)
Subject: [Subject line]

[Finished email â 200-250 words. Direct invitation. Why this specific person. What they'd get from the room. Single CTA: "Want me to send you details?"]

---

TOUCH 5 â DM (Send Day 14)
[Finished DM â 2-3 sentences. Closes the loop. No desperation. Clean.]

---

EXECUTION NOTE
[One sentence on the best order of operations â which channel to lead with for this specific prospect and why]
```

---

## Reference

**Titans of Industry program specs:**
- Price: $25K entry + $2,500/month
- Target member: 7-figure entrepreneur, $1M+ revenue minimum
- Core pain it solves: team chaos, revenue plateau, isolation at the top, wrong seat, partner friction
- Target count: 50 members (from approximately 20)
- Operators: Steve Larsen (outreach), Marley Larsen (warm introductions, relationship-first outreach)
- Pipeline management: titans-pipeline-tracker perpetual agent
- Sending: not automated here â this skill produces copy only

**This skill does NOT:**
- Automate sending (that is a GHL workflow)
- Manage pipeline tracking (that is the titans-pipeline-tracker perpetual agent)
- Write follow-up after a prospect responds (that is live conversation)

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Pitch in Touch 1 | Human-to-human contact only â no Titans mention |
| Use hype language ("incredible opportunity") | Steve's voice is direct and grounded â not promotional |
| Include the price in any touch | Price disclosed on call only |
| Write a generic sequence | Every touch references this specific prospect's situation |
| Use "we" framing | First-person singular â Steve reaching out as Steve |
| Include multiple CTAs in one message | One next step per touch |

## Before You Respond

- [ ] Do I have the prospect's name?
- [ ] Do I have their business background and current situation?
- [ ] Do I know Steve's entry point (how he knows of them)?
- [ ] Is this Steve's voice or Marley's voice?
- [ ] Does Touch 1 avoid any mention of Titans, price, or invitation?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History, cold-contact specificity fix (Gauntlet QA pass)

**Related tools:**
- titans-pipeline-tracker (perpetual agent) â tracks who's in what stage
- titans-sales-agent (agent) â call prep and pipeline audit
- ghl-funnel-brief (skill) â if a landing page is needed for a specific prospect
