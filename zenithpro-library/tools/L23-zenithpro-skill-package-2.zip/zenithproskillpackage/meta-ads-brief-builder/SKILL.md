---
name: meta-ads-brief-builder
description: Converts Keith's strategic intent into a complete, ready-to-execute Meta ads brief â including objective, audience targeting parameters, creative direction, copy angles, and budget allocation â for any of his three companies (DWM, EMF Gone, Level 5). Eliminates the back-and-forth between Keith and Brandon Dauphinais (support/ads). Use when Keith wants to launch or restructure a campaign, brief a new test, hand off a campaign to Brandon, or document what's currently running and why.
license: proprietary
metadata:
tags:
  - program/ctd
---
# Meta Ads Brief Builder

## Purpose

Takes Keith's rough campaign intent and produces a full Meta advertising brief â structured, accountable, and ready to hand to Brandon or a future ads team member without Keith explaining it twice.

## Keywords
Meta ads, Facebook ads, campaign brief, ad creative, audience targeting, DWM, EMF Gone, Level 5, Brandon, campaign handoff, ad copy, ad creative direction, campaign strategy, audience segmentation, retargeting

## Instructions

### Quick Start

1. Specify which company and campaign objective (example: "DWM â generate webinar registrations for our Facebook ads training")
2. Paste any relevant context: current funnel, existing audiences, budget, past performance
3. Review the complete brief
4. Hand the brief to Brandon or use it to manage Brandon's work

### Minimum Requirements Before Starting

Do not generate a brief without all four of these confirmed:
- Which company: DWM / EMF Gone / Level 5
- Campaign objective (awareness / leads / sales / webinar registrations / retargeting)
- Approximate budget range
- Any constraints (offers that are off-limits, audiences to exclude, markets to target)

If the campaign objective is unclear, ask exactly one clarifying question: "What do you want someone to do after seeing this ad?" Do not ask multiple clarifying questions in one response.

If budget is not provided, ask for it before generating â a brief without a budget is not a brief.

### Core Workflow

**Step 1 â Establish Campaign Intent**
Confirm:
- Company
- Objective (what action do we want from the audience?)
- Offer being promoted (specific product, service, or lead magnet)
- Budget (daily or total campaign budget)
- Timeline (launch date, end date if applicable)
- What's already running (to avoid overlap or cannibalization)

**Step 2 â Audience Architecture**
Define:
- Primary audience (cold): demographics, interests, behaviors, lookalike seeds
- Warm audience (retargeting): who qualifies (video viewers, page visitors, email list, past buyers)
- Exclusions: who should NOT see this ad (current customers if new buyer campaign, etc.)
- Geographic targeting (US only? Specific states? International?)

**Step 3 â Creative Direction**
Specify:
- Hook concept (what stops the scroll â question, bold claim, problem statement, pattern interrupt)
- Visual direction (what type of creative: talking head, static image, carousel, UGC-style)
- Keith's role in the creative (on-camera presenter? Voice only? Neither?)
- 3 copy angle options (different emotional entry points â one fear-based, one aspiration-based, one curiosity-based)

**Step 4 â Ad Copy**
Write full ad copy for the top 2 angles:
- Primary text (the scrolling copy above the creative â 125 characters for mobile truncation point, full version below)
- Headline (under the creative â 27 characters for mobile)
- Description (optional â used in some placements)
- Call to action button selection

**Step 5 â Campaign Structure**
Recommend:
- Campaign objective (Awareness / Traffic / Engagement / Leads / Sales / App promotion)
- Ad set count and testing strategy (ABO â Ad Set Budget Optimization vs CBO â Campaign Budget Optimization), how many ad sets, how many ads per set
- Placement recommendation (Advantage+ or manual; which placements to include/exclude)
- Budget split if multiple ad sets

**Step 6 â Handoff Package**
Deliver a formatted document Keith can send directly to Brandon.

## Reference

### Company Context

**Dominate Web Media (DWM)**
- Audience: business owners, marketers, entrepreneurs who run or want to run Meta ads
- Team contact: Brandon Dauphinais handles support and ads execution
- Core offer: Facebook ads training, coaching, done-for-you services
- Brand position: Keith as the authority on Meta advertising â hands-on, proven, no fluff
- Tone: direct, practitioner-to-practitioner

**EMF Gone**
- Partners: Dr. Lonnie Herman (product), Joakim Hansson (ops â transitioning out as of April 2026, Abigail Morgan acquiring partnership %), Natalia Hansson (finance/support)
- Product: EMF protection supplement / health product
- Audience: health-conscious adults, EMF-sensitive individuals, biohackers, parents concerned about wireless exposure
- Tone: educational, credible, solution-focused â Dr. Herman's expertise as anchor
- Regulatory note: flag any health claims that require compliance review before running

**Level 5 Mentoring**
- Partners: Brian D. Ridgway (creator), Abigail Morgan (CEO)
- Audience: high-achievers seeking personal development, inner work, identity-level growth
- Tone: introspective, aspirational, personal transformation â not hustle-culture
- Note: As of April 2026, Joakim transitioning out; Abigail acquiring partnership %. Verify current ownership structure before generating Level 5 briefs.

## Output

```markdown
# META ADS BRIEF
**Company:** [DWM / EMF Gone / Level 5]
**Campaign Name:** [Descriptive name]
**Prepared by Keith / Date:** [Date]
**Handed to Brandon:** [Date]

---

## CAMPAIGN OBJECTIVE
[What this campaign is designed to accomplish â specific and measurable]

## OFFER BEING PROMOTED
[Exact product/service/lead magnet with price or value, URL of destination]

## BUDGET
- Daily budget: $[X] or Total budget: $[X]
- Campaign duration: [Start date â End date or ongoing]

---

## AUDIENCE

**Cold Audiences (new people)**
- Audience 1: [Name] â [Targeting parameters: interests, behaviors, demographics]
- Audience 2: [Name] â [Targeting parameters]

**Warm Audiences (retargeting)**
- Retargeting 1: [Name] â [Who qualifies: e.g., "Watched 50%+ of any video in past 180 days"]
- Retargeting 2: [Name] â [Who qualifies]

**Exclusions**
- [Who to exclude and why]

**Geography:** [Countries, states, or regions]

---

## CREATIVE DIRECTION

**Hook concept:** [What stops the scroll â describe the opening moment]
**Format:** [Talking head video / Static image / Carousel / UGC-style]
**Keith on camera:** [Yes / No / Voice only]
**Visual notes:** [Specific instructions for Brandon or creative team]

---

## COPY â ANGLE 1: [Angle Name]
**Emotional entry point:** [Fear / Aspiration / Curiosity / Frustration]

**Primary text (full):**
[Full ad copy]

**Primary text (mobile truncation point â first 125 characters):**
[First 125 characters]

**Headline:** [Under 27 characters]

**Description (optional):** [Short supporting line]

**CTA button:** [Learn More / Sign Up / Get Quote / Download / etc.]

---

## COPY â ANGLE 2: [Angle Name]
**Emotional entry point:** [Fear / Aspiration / Curiosity / Frustration]

**Primary text (full):**
[Full ad copy]

**Primary text (mobile truncation point):**
[First 125 characters]

**Headline:** [Under 27 characters]

**CTA button:** [CTA]

---

## CAMPAIGN STRUCTURE

**Campaign objective in Ads Manager:** [Awareness / Traffic / Engagement / Leads / Sales]
**Budget method:** [ABO / CBO]
**Ad sets:** [Number] ad sets â [List them with their audiences]
**Ads per ad set:** [Number] â [Which copy angles]
**Placements:** [Advantage+ / Manual â if manual, specify]

---

## COMPLIANCE NOTES
[Any claims, testimonials, or before/after language that needs review before running â especially for EMF Gone health claims]

---

## SUCCESS METRICS
- Primary KPI: [CPA / CPL / ROAS / CTR â pick one]
- Target: [$X CPA / X% CTR / XxROAS]
- Review checkpoint: [When to evaluate â e.g., "After $[X] spend or [X] days"]

---

## NOTES FOR BRANDON
[Anything Keith wants Brandon to know that doesn't fit the structured fields above]
```

## Constraints

- Never write EMF Gone ad copy without flagging health claims for compliance review. No exceptions.
- Never generate a brief without a defined objective and budget â these are non-negotiable inputs. If missing, ask before proceeding.
- Never recommend Advantage+ audiences without noting whether Keith's existing custom audiences are large enough to seed lookalikes effectively.
- If Keith has provided past campaign data, reference it in every relevant section. Never generate a brief that ignores existing performance history.
- Copy must match the company voice exactly: DWM is practitioner authority, EMF Gone is health credibility, Level 5 is transformational depth. Do not blend these voices.
- Every creative direction note must be specific enough for Brandon to execute without a call with Keith. If Keith would normally have to explain it verbally, write it out.
- Do not generate a brief that requires follow-up clarification. If information is missing, ask before generating.
- If Keith provides past performance data (CTR, CPA, ROAS), cite it when recommending structure. Generic recommendations that ignore known data are not acceptable.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Generate a brief without objective and budget | Ask for both before producing anything |
| Write EMF Gone copy without compliance flag | Flag every health claim for review â no exceptions |
| Blend company voices across DWM/EMF/Level 5 | Each company has distinct tone â match exactly |
| Produce creative direction Brandon can't execute solo | Write it out â if Keith would explain it verbally, put it in writing |
| Ignore past campaign performance data | Cite it in every relevant section when provided |
| Recommend Advantage+ without checking seed size | Note whether custom audiences are large enough for effective lookalikes |

## Before You Respond

- [ ] Do I have the company (DWM / EMF Gone / Level 5)?
- [ ] Do I have the campaign objective?
- [ ] Do I have the budget?
- [ ] Am I applying the correct company voice?
- [ ] If EMF Gone: have I flagged health claims for compliance?
- [ ] Is the brief complete enough for Brandon to execute without a call?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History, ABO/CBO expansion, Level 5 ownership verification note (Gauntlet QA pass)

## When To Use This Skill

- Any time Keith wants to launch a new Meta campaign for DWM, EMF Gone, or Level 5
- When restructuring a campaign that stopped performing
- When briefing Brandon on a new test
- When documenting what's currently running (for accountability and institutional knowledge)
- When Keith is preparing a new offer and needs to think through the ad architecture
