---
name: ghl-pipeline-report
description: Pull live pipeline data from GoHighLevel and produce a written health analysis with prioritized action recommendations. Trigger when someone says "pipeline report," "how's the pipeline," "pipeline health," "deal status," "opportunity report," "what's in the pipeline," "pipeline review," "stalled deals," "close rate," "revenue forecast," "pipeline analysis," or any request to understand the current state of GHL opportunities.
license: proprietary
metadata:
tags:
  - program/ctd
  - ghl
  - pipeline
---
# GHL Pipeline Report

## Purpose

Pull live opportunity and pipeline data from GoHighLevel and convert raw stage data into a written health analysis â including win rate, velocity, stall detection, stage distribution, and prioritized action recommendations â so the operator can make sales decisions without manually digging through GHL.

## Instructions

### Step 1 â Retrieve Pipeline Structure

Call `get_pipelines` to get all pipelines and their stage definitions.

Display the pipeline inventory before proceeding:

```
Pipelines found: [N]
[Pipeline Name] â [N] stages: [Stage 1] â [Stage 2] â ... â [Closed Won] / [Closed Lost]
```

Ask the operator: "Which pipeline should I report on? (All / [specific name])" â or proceed with all if context makes the scope clear.

### Step 2 â Pull Opportunity Data

Call `search_opportunities` to retrieve all open opportunities, filtered by pipeline if specified.

For each opportunity retrieved, extract:
- Opportunity name
- Contact/company name
- Pipeline and current stage
- Monetary value (if set)
- Date created
- Date last updated
- Status (open / won / lost)
- Assigned owner

Calculate days since last update for each record: today's date minus last updated date.

### Step 3 â Produce Stage Distribution Table

REQUIRED output â do not skip this section:

| Stage | Count | Total Value | Avg Days in Stage | % of Pipeline |
|-------|-------|-------------|-------------------|--------------|
| [Stage Name] | [N] | $[X] | [N] days | [X]% |
| **TOTAL** | [N] | $[X] | â | 100% |

Sort stages in pipeline order (earliest to latest). NEVER sort alphabetically.

### Step 4 â Stall Detection

Flag any opportunity that has not been updated in 14+ days as stalled.

REQUIRED stall table:

| Opportunity | Contact | Stage | Days Stalled | Value | Owner |
|-------------|---------|-------|-------------|-------|-------|
| [name] | [name] | [stage] | [N] days | $[X] | [owner] |

Sort by Days Stalled descending (worst stalls first).

Produce a stall verdict:
- **0 stalled:** "Pipeline velocity is healthy â no opportunities are sitting idle."
- **1-3 stalled:** "Minor stall risk. [N] deal(s) need attention this week."
- **4+ stalled:** "Pipeline health is degraded. [N] deals are stalled â immediate triage required."

### Step 5 â Revenue Summary

Produce a revenue snapshot:

```
PIPELINE REVENUE SUMMARY
------------------------
Open Pipeline Value:        $[X]
Stalled Value at Risk:      $[X] ([X]% of open pipeline)
Average Deal Value:         $[X]
Largest Open Deal:          [name] â $[X] (stage: [stage])
Smallest Open Deal:         [name] â $[X] (stage: [stage])
```

If no monetary values are set on any opportunity: "Revenue values are not set in GHL. Ask the pipeline owner to add deal values for accurate forecasting."

### Step 6 â Action Recommendations

Produce a numbered action list sorted by priority. NEVER produce a vague recommendation like "follow up on deals." Every recommendation must name the specific opportunity and state the exact action.

REQUIRED format:

**Priority Action List â [Date]**

| # | Priority | Opportunity | Action Required | Owner | Do By |
|---|----------|-------------|----------------|-------|-------|
| 1 | Critical | [name] | [specific action] | [owner] | [date] |
| 2 | High | [name] | [specific action] | [owner] | [date] |

Priority tiers:
- **Critical** â Stalled 30+ days, high value, or at risk of closing lost
- **High** â Stalled 14-29 days, or in a closing stage with no update
- **Medium** â Recent activity but needs a defined next step
- **Watch** â Moving normally, no action needed but flag for awareness

### Step 7 â Status Update Option

After displaying the report, offer: "Want me to update the status of any opportunity to Closed Won or Closed Lost? Provide the opportunity name and new status."

If the operator confirms, call `update_opportunity_status` with the correct opportunity ID. Show the updated record after completion.

## Constraints

- NEVER produce a pipeline report with fabricated data. All figures must come from live MCP tool calls.
- NEVER assume pipeline names or stage names. Always call `get_pipelines` first to retrieve the actual pipelines in the account â never hard-code stage or pipeline names.
- NEVER recommend advancing or closing an opportunity without first showing the current record and stage.
- NEVER mark a deal as Closed Won or Closed Lost without explicit operator instruction and confirmation.
- ALWAYS show the full stall table even if there are no stalled deals â state "No stalled deals" explicitly so the operator knows the check was run.
- NEVER omit the stage distribution table â it is the core diagnostic. Skipping it makes the report useless.
- ALWAYS include the data retrieval timestamp in the report header so the operator knows how fresh the data is.
- NEVER skip the revenue summary if any deal values are set. Zero-value pipelines must be flagged explicitly.
- ALWAYS assign a "Do By" date to every action recommendation. NEVER fabricate a "Do By" date without basis â if no deadline context exists, set it to 5 business days from today and flag: "Default deadline applied â confirm with pipeline owner."
- NEVER modify opportunity data during the report phase. The report is read-only. Modifications happen only in Step 7 after explicit instruction.
- ALWAYS flag if `search_opportunities` returns a truncated result set â state the limit and ask if the operator wants to paginate.
- NEVER produce vague action recommendations. Every recommended action must name the specific opportunity, state the exact action, name the owner, and include a "Do By" date.
- ALWAYS call `get_pipelines` before `search_opportunities` â the pipeline structure must be confirmed before opportunity data is interpreted.

## Reference

**MCP Tools Used:**
- `get_pipelines` â Retrieve all pipeline definitions and stage names
- `search_opportunities` â Pull all opportunities (filterable by pipeline, status, stage)
- `get_opportunity` â Get full detail on a single opportunity by ID
- `update_opportunity_status` â Change an opportunity's status to Won, Lost, or Open

**Configuration Requirements:**
- GHL MCP server (BusyBee3333) must be connected and authenticated
- GHL Location ID must be configured in the MCP server
- Operator must have opportunity read permissions (write required for Step 7 status updates)

**Failure Modes:**

MCP not connected: State: "GHL MCP server is not responding. Pipeline report cannot be generated. Verify the BusyBee3333 MCP server is running and authenticated."

No opportunities returned: State: "No open opportunities found in [pipeline name / all pipelines]. Possible causes: all deals are closed, the pipeline is empty, or the location filter is incorrect. Verify in GHL."

No pipeline value data: Flag prominently: "Deal values are not set. The revenue summary section cannot be completed. Instruct the pipeline owner to add $ values to all open opportunities for accurate forecasting."

`get_pipelines` returns no pipelines: State: "No pipelines found in this GHL account. Either no pipelines have been created, or the API key does not have access to this location. Verify location settings in the MCP server configuration."

Partial data (some fields missing): Do not omit rows from the report. Fill missing fields with "â" and add a note at the bottom: "Fields marked 'â' were not set in GHL. Recommend updating these records."

**Output Format:**

Every pipeline report contains, in order:
1. **Report Header** â pipeline scope, data retrieved timestamp, location
2. **Pipeline Inventory** â all pipelines and stages found
3. **Stage Distribution Table** â count, value, avg days per stage
4. **Stall Detection Table** â all stalled deals with days count
5. **Stall Verdict** â plain-language health verdict
6. **Revenue Summary** â open pipeline value, at-risk value, averages
7. **Priority Action List** â numbered, named, deadline-assigned
8. **Next Step Prompt** â offer to update statuses or drill into a specific deal
