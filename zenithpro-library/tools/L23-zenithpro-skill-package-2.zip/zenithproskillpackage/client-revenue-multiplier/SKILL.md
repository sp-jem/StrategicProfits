---
name: client-revenue-multiplier
description: Identifies and executes every revenue opportunity inside Alla's existing client base â Yura (YBR Roofing $1K/mo), Vasya (Vector Sleep $500/mo), MitoActivity, SchoolSharp, Zephyr Gallery â without adding new clients. Finds upsells, cross-sells, expansion opportunities, and stalled relationships. Drafts the actual outreach. The fastest path to revenue is always the people already paying you. Use when Alla says anything like "upsell," "expand a client," "I need more money from existing clients," "client review," "client expansion," "Yura," "Vasya," or "what can I do with my current clients."
license: proprietary
metadata:
tags:
  - program/ctd
---
# Client Revenue Multiplier

Maps every revenue opportunity inside Alla's existing client roster before going hunting for new ones. Finds what's being left on the table, drafts the ask, and handles the awkward "can I charge more for this?" question with a clear, direct framework. Fastest path to cash is always through existing relationships.

## Keywords
upsell, client expansion, existing clients, cross-sell, client revenue, YBR Roofing, Vector Sleep, MitoActivity, SchoolSharp, Zephyr Gallery, retainer expansion, new services, client review, client outreach

## Quick Start

1. Tell me which mode:
   - **"Full client audit"** â Review all active clients for expansion opportunities
   - **"Client [name]"** â Focus on one specific client
   - **"Stalled client [name]"** â Client who's gone quiet (SchoolSharp, Zephyr Gallery)
   - **"Rate increase [client]"** â Build the case and draft the ask for a rate increase
   - **"Pitch [service] to [client]"** â Draft outreach to offer a new service to an existing client
2. I run immediately.

## Alla's Current Client Map

| Client | Service | Monthly Revenue | Status | Notes |
|--------|---------|----------------|--------|-------|
| Yura (YBR Roofing) | SEO/web | $1,000/mo | Active | Primary anchor client |
| Vasya (Vector Sleep) | SEO/web | $500/mo | Active | Lower rate, good relationship |
| MitoActivity | SEO tweaks | Variable | Active (minimal) | Waiting on scope clarity |
| SchoolSharp | TBD | $0 (not started) | Stalled â waiting on access | |
| Zephyr Gallery | TBD | $0 (not started) | Stalled â waiting on client | |

**Current monthly revenue: $1,500/mo**
**Target: $10,000/mo**
**Gap: $8,500/mo**

---

## Core Modes

---

### MODE 1: FULL CLIENT AUDIT

**Trigger:** "Full client audit"

Produce a revenue map for every active client.

**ALLA GEYKHMAN â CLIENT REVENUE AUDIT**
**Date:** [Date]

For each active client:

---

**[CLIENT NAME]**

Current: $[X]/mo for [service]

**Expansion opportunities:**

| Opportunity | Service | Estimated Value | Ask Type | Probability |
|-------------|---------|----------------|----------|-------------|
| [opp] | [service] | $[X]/mo or one-time | Upsell/New service/Rate increase | High/Medium/Low |

**Highest-value move:** [The single best expansion opportunity and why]

**Outreach script:** [If Alla should reach out, provide the exact message. One paragraph. Casual but professional. Specific to the client relationship.]

**Stalled client activation plan:** [For SchoolSharp and Zephyr Gallery â what to do to unblock them]

---

After all clients:

**REVENUE SUMMARY**

| Client | Current | Potential (conservative) | Action Required |
|--------|---------|------------------------|----------------|
| Yura (YBR Roofing) | $1,000 | $[X] | [action] |
| Vasya (Vector Sleep) | $500 | $[X] | [action] |
| MitoActivity | $variable | $[X] | [action] |
| SchoolSharp | $0 | $[X] | [action] |
| Zephyr Gallery | $0 | $[X] | [action] |
| **TOTAL** | **$1,500** | **$[X]** | |

**Gap to $10K/month from existing clients: $[X]**
**Gap that requires new clients: $[X]**

---

### MODE 2: SINGLE CLIENT DEEP DIVE

**Trigger:** "Client [name]"

Pull everything known about one client and produce:

**[CLIENT] EXPANSION ANALYSIS**

What they're getting now:
- [List current services]
- [Current investment]
- [Length of relationship]

What they almost certainly need but aren't getting from Alla:
- [Gap 1]: [Evidence it exists + how to position the ask]
- [Gap 2]: [Evidence it exists + how to position the ask]
- [Gap 3]: [Evidence it exists + how to position the ask]

The one ask to make next:
[Specific service, specific price, specific reason this client will say yes]

Draft outreach (email or text â match client's preferred channel):

---

[Message draft â uses Alla's casual, direct style. Acknowledges the existing relationship. One clear ask. No hedging.]

---

### MODE 3: STALLED CLIENT ACTIVATION

**Trigger:** "Stalled client [name]" (SchoolSharp or Zephyr Gallery)

These clients have not started. Revenue is $0. Alla is waiting on them.

Produce:

**[CLIENT] â ACTIVATION PLAN**

Why they've stalled: [Best guess based on known info]

What Alla controls vs. what she's waiting on:
- Alla controls: [list]
- Waiting on client for: [specific items]

**Activation sequence:**

Step 1 â Reopen the conversation (send today):
[Exact message â casual, direct, no guilt. Frames what's needed from them in one sentence. Creates urgency without pressure.]

Step 2 â If no response in 5 days:
[Follow-up message â one line. "Hey [name], still waiting on [X] to get started. Shoot me a quick reply." Nothing elaborate.]

Step 3 â If still no response after 10 days:
[Decision point message â "I have capacity to start your project but I'm going to need to hear back by [date] or I'll need to push it to [next window]. No pressure â just want to make sure I hold your spot."]

Decision rule: If no response after Step 3 â archive the client. Move time to active prospects. Do not chase indefinitely.

---

### MODE 4: RATE INCREASE

**Trigger:** "Rate increase [client]"

Build the case and draft the ask for a rate increase with an existing client.

**RATE INCREASE CASE â [CLIENT]**

Current rate: $[X]/mo
Target rate: $[Y]/mo
Increase: $[Z]/mo ([%]%)

**Justification (pick the strongest 2-3):**
- Results delivered: [Specific SEO or web outcomes â rankings improved, traffic increased, conversions â use numbers if available]
- Scope creep: [Work currently being done that wasn't in original scope]
- Market rate: [What comparable services cost â Alla's enterprise background + AI capability is not commodity pricing]
- AI implementation value: [If Alla has added AI tools to their stack that they didn't pay for]
- Length of relationship + reliability: [Consistent delivery over X months is worth paying for]

**Timing rules:**
- Never ask for a rate increase the week before invoice
- Best time: After a visible win (traffic spike, new ranking, successful project delivery)
- Never apologize for the ask

**The message:**

---

[Draft â direct but warm. Opens with a result or a moment from the relationship. States the new rate and effective date. Gives them enough notice (30 days). Doesn't over-explain. Invites a conversation if they want to talk through it.]

---

### MODE 5: NEW SERVICE PITCH

**Trigger:** "Pitch [service] to [client]"

Draft outreach to offer a specific new service to an existing client. Most relevant services Alla can pitch:

- AI automation audit (from ai-audit-packager skill)
- AI tool setup and configuration
- Content writing / SEO content packages (Pakistan team produces, Alla QAs)
- Website redesign or CRO (conversion rate optimization)
- LinkedIn outreach automation setup
- Email marketing setup
- Reporting and analytics dashboard

**Format:**

**[SERVICE] PITCH â [CLIENT]**

Why this client specifically:
[2 sentences on why this service fits this client's current situation]

The pitch (message or email):

---

[Draft â opens with something specific to their business. Names the problem it solves. States the offer and investment clearly. Ends with a specific call to action: "Want to hop on a 20-minute call this week to see if this makes sense for you?"]

---

## Operating Rules

- NEVER suggest finding new clients before mining the existing list fully. Existing clients are always the first revenue lever.
- NEVER write an outreach draft that waffles or over-explains. One relationship acknowledgment, one clear ask, one CTA. Nothing more.
- NEVER frame Alla's rates as a burden on the client. $1,000/mo for a CISSP + 25-year enterprise veteran + AI-enhanced operations is a deal, not a premium. Price confidently.
- NEVER recommend a rate increase within 7 days of an invoice date. Timing kills the ask.
- NEVER archive a stalled client (SchoolSharp, Zephyr Gallery) before completing all three activation steps with the required wait periods between them.
- ALWAYS include Pakistan team capacity in any expansion scope. Raza + Muneeb + Youssef absorb execution. More client revenue does not require more of Alla's time if scoped correctly.
- ALWAYS position AI capability as an upsell into every existing client. Every SEO client â roofing, mattresses, activity tracking â can benefit from AI-enhanced operations.
- If Alla does not provide specific results data (rankings improved, traffic numbers): do not fabricate them. Draft the rate increase or pitch using relationship tenure and service scope as justification instead.

## Output Block

Every mode produces a labeled deliverable:

- Full Client Audit: revenue map table per client + revenue summary with gap calculation
- Single Client Deep Dive: current state + gap analysis + one next ask + outreach draft
- Stalled Client Activation: 3-step message sequence with decision rule at step 3
- Rate Increase: justification case + email draft with effective date
- New Service Pitch: why-this-client rationale + outreach draft with specific CTA

## Save Location

`01 - Business/Clients/Active/[Client Name]/expansion-plan-[date].md`
`01 - Business/Clients/Active/[Client Name]/outreach-drafts/[date].md`

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Suggest finding new clients before mining existing | Existing clients are always the first revenue lever |
| Write outreach that waffles | One relationship acknowledgment, one clear ask, one CTA |
| Frame Alla's rates as a burden | $1K/mo for CISSP + 25yr enterprise is a deal, not a premium |
| Recommend a rate increase within 7 days of invoice | Timing kills the ask â wait for the right window |
| Archive a stalled client before full 3-step activation | Complete all three steps with required wait periods |
| Fabricate results data | Use relationship tenure and scope as justification instead |

## Before You Respond

- [ ] Have I identified which mode (Audit / Deep Dive / Stalled / Rate Increase / New Pitch)?
- [ ] Am I mining existing clients before new-client thinking?
- [ ] Is Pakistan team capacity scoped into expansion?
- [ ] Are all results data points real (not fabricated)?
- [ ] Does every outreach draft have one clear CTA?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
