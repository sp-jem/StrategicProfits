---
name: coaching-session-multiplier
description: Transforms raw coaching session inputs â whiteboard photos, audio files, rough notes â into six structured outputs for the financial advisor client and SKI's internal pipeline. Produces a session summary, 3-step implementation plan, shareable key distinction, follow-up accountability prompt, webinar content seed, and IP log entry. Upgrades every session delivery without adding to Scott's time. Use when Scott has just completed a coaching call or Zoom and has raw materials to turn into a finished package.
license: proprietary
metadata:
tags:
  - program/ctd
  - client/scott-keffer
---
# Coaching Session Multiplier

Converts raw session materials into six structured outputs: a client deliverable package and parallel IP extraction for SKI's marketing and product pipeline. One session in, six outputs out.

## Keywords
session summary, coaching deliverable, whiteboard, advisor coaching, financial advisor, client recap, implementation plan, content extraction, SKI, Scott Keffer, coaching output, post-session, session notes

## Quick Start

1. Provide raw session inputs: whiteboard photo(s), audio transcript or summary, and the client's name + session date
2. Optionally: specify the primary theme or breakthrough moment from the session ("The big shift today was X")
3. Claude processes all inputs and produces the full package
4. Review each section â the client deliverable and the IP extraction are separate outputs
5. Save to: `SKI-Vault/01_Clients/[Client Name]/Sessions/[Date]-session-package.md`

No scripts required. Works from photos, transcripts, and your own notes.

## Minimum Requirements Before Starting

Before beginning, verify:

- Client name and session date provided
- At least ONE of the following: whiteboard photo, audio transcript, session notes
- Approximate session theme (what was the primary focus?)

If no materials are provided beyond a client name, ask: "What was the main topic or breakthrough from this session? Even a 2-sentence description gives me enough to work with."

## Core Workflow

### Step 1 â Ingest All Materials

Process all provided inputs:
- Whiteboard photos: extract every framework, diagram, list, number, and label visible
- Audio transcripts: identify the core concepts, the client's key questions, Scott's key answers, and any moments of breakthrough ("that changes everything" â note these)
- Session notes: read fully, flag anything that reads as a key distinction or reusable framework

Do not begin drafting until all materials are fully processed.

### Step 2 â Identify the Core Distinction

Every session Scott runs has a single most-important idea â the thing the client needs to act on. Identify it before drafting anything. Name it as a single sentence: "The core distinction in this session is: [X]."

If multiple strong ideas are present, rank them and proceed with the top one as the primary focus. Others become supplementary.

### Step 3 â Produce the Six-Output Package

#### OUTPUT 1: Client-Facing Session Summary (1 page)

Structure:
- **Session:** [Client Name] | [Date] | [Duration if known]
- **What We Covered:** 3-5 bullet points, each 1-2 sentences. Plain English, no jargon. Written as if explaining to a smart friend, not a textbook.
- **The Big Shift:** 1 paragraph. The single most important idea from the session. Written in Scott's direct, bottom-line-first voice. This is what the client should remember in 6 months.
- **The Framework:** If a diagram or model was presented, describe it clearly in text (do not rely on the whiteboard photo being readable). Name it if it has a name; if not, create a working name.

Tone: Direct. Specific to this client's situation. Not generic coaching-speak. Scott's voice â bottom line first, then supporting detail, then next action.

---

#### OUTPUT 2: 3-Step Implementation Plan

What the client does in the next 30 days to activate the session's key insight. Each step:
- **Step [N]: [Action name]**
  - What to do: [Specific, concrete action]
  - Why this first: [One sentence on the logic]
  - How to know it's done: [The completion signal â not "work on it" but a clear finish line]
  - Time required: [Realistic estimate for a financial advisor with a book of business]

Steps must be sequenced correctly â Step 2 should be impossible to do before Step 1 is complete. If the steps can be done in any order, resequence them.

---

#### OUTPUT 3: Key Distinction (Shareable Format)

One reusable insight from this session, formatted for direct use in Scott's content pipeline. Suitable for a direct mail piece, webinar slide, or LinkedIn post without further polishing.

Format:
- **Distinction:** [The insight, stated as a contrast or reframe â "Most advisors do X, but the top 1% do Y" or "The mistake is thinking X, but the truth is Y"]
- **Proof:** [One example from the session, or one data point Scott referenced, that validates the distinction]
- **Application:** [What an advisor does differently once they have this distinction]
- **Source:** [Session with [Client Name], [Date] â for IP tracking only, not published]

This is a raw asset. It goes into Scott's content pipeline, not directly to the client.

---

#### OUTPUT 4: Follow-Up Accountability Prompt

A single question Scott sends to the client 7-10 days after the session to check implementation progress. The question should:
- Reference the specific action from Step 1 of the implementation plan
- Be answerable in 1-2 sentences (not an essay question)
- Create mild accountability pressure without being salesy or lecture-y
- Sound like it came from someone who was personally in the session and remembers the specific thing the client said they were going to do

Format:
> **7-Day Check-In for [Client Name]:**
> "[Question text]"

---

#### OUTPUT 5: Webinar/Content Seed

One idea for a SKI webinar or boot camp module that emerges directly from this session. This is the answer to: "If this insight came up in coaching, how many of the 50 clients need to hear this?"

Format:
- **Content Seed:** [Working title for the webinar topic]
- **The Hook:** [One sentence that would make a financial advisor click on the webinar registration]
- **What it teaches:** [3 bullet points on the content]
- **Why now:** [Why this is timely for Scott's audience â what's happening in financial services that makes this relevant in 2025-2026]
- **Format fit:** [Webinar / Boot Camp Module / Direct Mail piece / Done-For-You System â pick the best fit based on complexity]

---

#### OUTPUT 6: SKI IP Log Entry

A single-line entry for Scott's knowledge base â captures the session's core insight in a format that can be accumulated over time into a searchable library of coaching distinctions.

Format:
> `[Date] | [Client Type/Profile] | [Core Distinction] | [Application] | [Tags: revenue-model, client-acquisition, team-leverage, etc.]`

This accumulates into the "What Scott Knows" library â the foundation for future products and Sharon's replacement documentation.

---

## Quality Standards

- The client-facing summary must be readable in under 5 minutes. If it takes longer, shorten it.
- The implementation plan must be specific enough that the client could hand it to an assistant and have them start Step 1 without further explanation.
- The key distinction must be usable as-is in a marketing piece â no polish needed later.
- The content seed must reference something real from this session, not a generic advisor topic.
- The IP log entry must be written in 2 minutes or less â it's a log entry, not an essay.

## Constraints

- Never produce generic coaching language ("leverage your strengths," "focus on what matters"). Every output must reference something specific from this session.
- Never produce a client deliverable that reads like it was generated by AI. Scott's voice: bottom line first, direct, specific, no fluff.
- Never skip the IP Log Entry â this is the foundation of Scott's long-term knowledge capture and Sharon's replacement documentation.
- Never let the Client-Facing Session Summary exceed one page. If the content exceeds one page, cut â do not expand the page.
- Never produce an implementation plan step that the client could begin before completing the prior step. Steps must be sequenced so that Step N is a prerequisite for Step N+1.
- If a whiteboard photo is provided but unreadable (too dark, too blurry, key text obscured), flag it immediately: "Whiteboard photo [X] is unreadable â [describe the problem]. I will proceed from transcript/notes only. Please resend a clearer photo if the whiteboard contained content not covered in the transcript."
- If materials are too sparse to produce all six outputs at quality, produce what you can and flag what's missing: "I have enough for Outputs 1-4, but the webinar seed needs more context â what was the specific advisor situation that prompted this topic?"

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Use generic coaching language ("leverage your strengths") | Reference specific content from this session |
| Produce a deliverable that reads like AI output | Scott's voice: bottom line first, direct, no fluff |
| Skip the IP Log Entry | Always produce â this is the foundation of Scott's knowledge capture |
| Let the client summary exceed one page | Cut content, not expand the page |
| Sequence steps where Step 2 can start before Step 1 is done | Enforce strict dependency order |
| Fabricate whiteboard content when photo is unreadable | Flag the unreadable photo and proceed from transcript |

## Before You Respond

- [ ] Do I have the client name and session date?
- [ ] Have I identified the core distinction as a single sentence?
- [ ] Are all 6 outputs produced (or missing outputs explicitly flagged)?
- [ ] Is the implementation plan specific enough that an assistant could execute Step 1?
- [ ] Does every output reference something specific from this session?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)

## Save Location

Session packages: `SKI-Vault/01_Clients/[Client Name]/Sessions/[YYYY-MM-DD]-session-package.md`
IP Log entries: `SKI-Vault/02_Frameworks/SKI-IP-Log.md` (append each entry)
Content seeds: `SKI-Vault/08_Content/Content-Seeds.md` (append each entry)
