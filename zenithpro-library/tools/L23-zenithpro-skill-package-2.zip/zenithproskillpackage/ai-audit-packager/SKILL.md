---
name: ai-audit-packager
description: Turns Alla's deep AI capability into a structured, sellable AI Business Audit service. A client hires her, she assesses their operations, and this skill builds the deliverable: a scored audit report, a prioritized implementation roadmap, and a proposal for ongoing support. Her application goal was exactly this â "I come to a business, assess it, suggest how AI can help, install it, and if they want, keep supporting them." This skill makes that a real product. Use when Alla says anything like "AI audit," "assess a client's business," "AI implementation proposal," "client AI readiness," or "package my AI services."
license: proprietary
metadata:
tags:
  - program/ctd
---
# AI Audit Packager

Turns Alla's AI expertise into a repeatable, deliverable product. Takes client business information and produces a professional AI Business Audit â scored, prioritized, and positioned to justify an ongoing retainer. The audit is how Alla gets paid for what she already knows.

## Keywords
AI audit, AI implementation, business assessment, AI readiness, automation audit, AI proposal, client audit, AI consulting, AI services package, implementation roadmap

## Quick Start

1. Tell me which mode:
   - **"New audit [business name]"** â Start a full AI audit for a new client
   - **"Audit report [business name]"** â Generate the formal report from completed discovery
   - **"Proposal [business name]"** â Generate the proposal and pricing after the audit
   - **"Discovery questions [industry]"** â Get the discovery interview questions for a specific industry
2. Provide what you know about the business. I build the rest.

## Who This Is For

Alla Geykhman, who has built 100+ Claude Code skills, automated pipelines with cron jobs and Pinecone, managed multi-tool AI stacks. She is not selling AI theory â she has deployed real AI systems in a live business. The audit is her proof of work turned into a service. DFS lead generation ($1K commission per client to Lena Polnet) is a parallel track â this skill also generates qualified prospects for that pipeline.

## The Product Architecture

**Tier 1: AI Business Audit** â One-time deliverable
- What Alla delivers: 2-hour business assessment + full written audit report
- What it costs the client: $500-$1,500 depending on business size
- What it produces for Alla: A report that identifies implementation gaps AND a proposal for Tier 2

**Tier 2: AI Implementation** â Project-based
- Alla installs the specific automations identified in the audit
- Scoped from the audit. No guessing.
- Pakistan team (Raza, Muneeb, Youssef) handles execution; Alla manages + QAs
- Revenue: $2,000-$8,000 per project

**Tier 3: Ongoing AI Support Retainer** â Monthly recurring
- Alla monitors, troubleshoots, expands the implemented systems
- Revenue: $500-$1,500/month
- This is the path to the $10K/month Alla needs

---

## Core Workflow

### PHASE 1: DISCOVERY QUESTIONS

**Trigger:** "Discovery questions [industry]" or at start of "New audit"

Produce a tailored discovery script for the client's industry. Standard structure:

**DISCOVERY INTERVIEW GUIDE â [Business Name] â [Date]**

**Section 1: Operations Overview (10 min)**
1. Walk me through a typical day in your business â what does the team do start to finish?
2. How many hours per week do you or your team spend on tasks that feel repetitive?
3. What software tools do you use? (CRM, email, scheduling, accounting, social)
4. Where do things fall through the cracks most often?

**Section 2: Current Pain Points (10 min)**
5. What's the task you hate doing most that you still do every week?
6. What would you hire a person to do if you could afford it right now?
7. Are there things clients or customers complain about that you don't have time to fix?
8. Where are you leaving money on the table because the follow-up never happens?

**Section 3: AI Readiness (5 min)**
9. What AI tools are you using now, if any?
10. Have you tried to automate anything? What happened?
11. How comfortable is your team with learning new software?
12. What would have to be true for you to feel like this investment paid off?

**Section 4: Growth & Goals (5 min)**
13. What does your business look like in 12 months if things go well?
14. What's the single biggest bottleneck between where you are and that version?
15. What's your revenue now, and what are you targeting?

Industry-specific addons: [generate 5 additional questions specific to the client's industry]

---

### PHASE 2: AUDIT REPORT

**Trigger:** "Audit report [business name]" after discovery is complete

**Format:**

---

**AI BUSINESS AUDIT**
**Prepared for:** [Client Name / Company]
**Prepared by:** Alla Geykhman, AIG Web Methods
**Date:** [Date]
**Confidential**

---

**EXECUTIVE SUMMARY**

[2 paragraphs: what the business does, what Alla found, the single biggest opportunity.]

**Overall AI Readiness Score: [X]/10**

---

**SECTION 1: OPERATIONS MAP**

What the business runs on today (tools, team, processes). Table format:

| Function | Current Tool/Process | Manual Hours/Week | AI-Ready? |
|----------|---------------------|------------------|-----------|
| [function] | [tool or "manual"] | [hours] | Yes/Partial/No |

---

**SECTION 2: OPPORTUNITY SCORECARD**

Rate each automation opportunity:

| Opportunity | Impact (1-5) | Ease (1-5) | Priority Score | Estimated Time Saved/Week |
|-------------|-------------|-----------|---------------|--------------------------|
| [opportunity] | | | [Impact x Ease] | |

Sort by Priority Score, highest first.

**Top 3 opportunities by priority:**

**Opportunity 1: [Name]**
- What it is: [plain English description]
- Why it matters: [revenue or time impact, specific to this business]
- How to implement: [tools + approach â specific to what Alla has built and can install]
- Estimated time to build: [X hours]
- Expected ROI: [hours saved per week x hourly cost, or revenue recovered]

**Opportunity 2: [Name]**
[Same structure]

**Opportunity 3: [Name]**
[Same structure]

---

**SECTION 3: WHAT'S BROKEN**

Systems the business thinks are working that aren't. Be direct. This is the part where Alla's enterprise diagnostic experience shows.

| Issue | Evidence | Business Cost | Fix |
|-------|----------|--------------|-----|
| [issue] | [what Alla observed] | [estimated cost in time/money] | [recommendation] |

---

**SECTION 4: WHAT NOT TO DO**

AI tools or approaches that are commonly recommended but would be wrong for this specific business. Earns trust by saving the client from expensive mistakes.

- [Tool/approach]: [Why it's wrong for this client]
- [Tool/approach]: [Why it's wrong for this client]

---

**SECTION 5: RECOMMENDED NEXT STEPS**

Three actions the client can take with or without Alla:
1. [Immediate â can do this week with zero tech skills]
2. [Short-term â needs someone with AI capability]
3. [Medium-term â requires ongoing implementation]

---

### PHASE 3: PROPOSAL

**Trigger:** "Proposal [business name]" after audit report is complete

**Format:**

---

**AI IMPLEMENTATION PROPOSAL**
**For:** [Client Name]
**From:** Alla Geykhman, AIG Web Methods
**Following:** AI Business Audit â [Date]

---

**WHAT YOU'RE GETTING**

Based on the audit, here are the three highest-value automations I recommend implementing first:

**1. [Automation Name]**
- What it does: [plain English]
- What it replaces: [current manual process]
- Time saved: [X hours/week]
- Revenue impact: [if applicable]
- Build timeline: [X weeks]

**2. [Automation Name]**
[Same]

**3. [Automation Name]**
[Same]

**Total estimated time saved per week: [X hours]**
**Total implementation timeline: [X weeks]**

---

**INVESTMENT OPTIONS**

| Option | Includes | Investment | Timeline |
|--------|----------|------------|---------|
| Implementation Only | [Automations 1-3 built and installed] | $[X] | [X weeks] |
| Implementation + 90-Day Support | Above + monitoring, fixes, one expansion per month | $[X] | 90 days |
| Monthly Retainer (after implementation) | Ongoing monitoring, troubleshooting, expansion | $[X]/mo | Ongoing |

**My recommendation for [Client Name]:** [Specific option and why â based on their situation from the audit]

---

**HOW I WORK**

- You describe what you need. I build it.
- My Pakistan-based execution team handles implementation. I manage and QA everything.
- You get working systems, not decks about systems.
- If something breaks after delivery, I fix it. That's what the retainer is for.

---

**TO MOVE FORWARD**

[Specific next step with timeline â e.g., "Reply to this proposal by [date] and I'll have the first automation live within 2 weeks."]

---

## Operating Rules

- NEVER frame Alla's service as a freelancer guessing. Every output anchors to her real background: 25 years enterprise, CISSP, 100+ AI skills built and deployed. This is a security and AI professional with enterprise credentials.
- NEVER undersell. The audit fee ($500-$1,500) is entry-level pricing for what Alla delivers. The proposal is where real revenue is built.
- NEVER fabricate specifics about a client's business that were not provided in discovery. If critical information is missing, ask one focused question before generating the audit section.
- NEVER start the audit report without completing Phase 1 discovery first. Report without discovery = fiction.
- ALWAYS structure every audit section with a clear header and scannable table. High-cognitive-load days require pre-structured output.
- ALWAYS check for DFS fit when auditing a client. If the business is a fit for Lena Polnet's service, flag it explicitly. $1K commission per referral is high-leverage.
- ALWAYS include Pakistan team capacity in implementation scoping. Raza + team = execution. Alla = strategy, QA, client management. Do not scope as if Alla executes alone.
- If the client's budget is unclear: default to the lower tier ($500 audit, $2K implementation) in the proposal. Upsell from there.

## Output Block

Every phase produces a labeled, client-ready document:

- Phase 1: Formatted discovery interview guide with industry-specific addons
- Phase 2: Full AI Business Audit with executive summary, opportunity scorecard, and next steps â ready to PDF and deliver
- Phase 3: Proposal with investment options table and specific recommendation for this client

Abbreviate tables where needed. No audit section should require horizontal scrolling.

## Save Location

`01 - Business/Clients/Prospects/[Client Name]/audit-[date].md`
`01 - Business/Clients/Prospects/[Client Name]/proposal-[date].md`

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Frame Alla as a freelancer guessing | Anchor to 25 years enterprise, CISSP, 100+ AI skills built |
| Undersell the audit fee | $500-$1,500 is entry-level â proposal is where real revenue lives |
| Start the audit before Phase 1 discovery | Report without discovery is fiction â always discover first |
| Scope implementation as if Alla executes alone | Pakistan team (Raza +) = execution; Alla = strategy/QA |
| Skip the DFS fit check | $1K commission per Lena Polnet referral â always flag the fit |
| Fabricate client business specifics | Ask one focused question if critical info is missing |

## Before You Respond

- [ ] Am I in Phase 1 (Discovery), Phase 2 (Audit), or Phase 3 (Proposal)?
- [ ] If Phase 2 or 3: did Phase 1 discovery complete first?
- [ ] Did I check for DFS fit?
- [ ] Is the Pakistan team scoped into the implementation?
- [ ] Is the pricing anchored to Alla's enterprise credentials?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
