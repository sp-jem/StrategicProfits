---
name: whop-analytics
description: Complete Whop analytics for Strategic Profits. Query memberships, payments, customers, products, and revenue. Use for data exports, daily reports, and business intelligence. Requires MCP server restart.
---

# Whop Analytics Skill

## Overview

Full-access analytics for the Strategic Profits Whop account via MCP server. Provides:
- Membership and subscription data
- Payment history and revenue
- Customer/member records
- Product and plan information
- Invoice records
- Export capabilities for historical analysis

## Prerequisites

The Whop MCP server must be connected. If tools are unavailable, restart Claude Code.

**MCP Config:** `YOUR-OBSIDIAN-VAULT/.mcp.json`
**Data Output:** `YOUR-OBSIDIAN-VAULT/01 Strategic Profits/00 Admin/00 Acounting/WAP/`

## Quick Commands

| Query | What It Does |
|-------|--------------|
| "Download all Whop data" | Full export to dated folder |
| "List all Whop products" | Show product catalog |
| "Show active memberships" | Current subscriptions |
| "Whop payments this month" | Recent payment history |
| "Whop customer list" | Export all members |
| "Sync recent Whop data" | Incremental update |

## Full Data Download Workflow

When user requests "Download all Whop data":

### Step 1: Verify MCP Connection
Check that Whop MCP tools are available. If not, instruct user to restart Claude Code.

### Step 2: Create Export Folder
```
01 Strategic Profits/00 Admin/00 Acounting/WAP/exports/YYYY-MM-DD/
```

### Step 3: Export Data (in order)

1. **Products & Plans**
   - List all products â `products.json`
   - List all plans â `plans.json`
   - List promo codes â `promo_codes.json`

2. **Memberships**
   - List all memberships (paginate if needed) â `memberships.json`
   - Include status, plan, customer, dates

3. **Payments**
   - List all payments (paginate, may be large) â `payments.json`
   - Include amount, status, customer, date

4. **Members/Customers**
   - List all members â `members.json`
   - Include email, phone, created date

5. **Invoices**
   - List all invoices â `invoices.json`

### Step 4: Generate Summary
Create `summary.md` with:
- Export date/time
- Record counts per entity
- Total revenue calculation
- Active vs canceled membership counts
- Any errors or incomplete data

## MCP Tools Reference

The Whop MCP server exposes these tools (once connected):

### Memberships
| Tool | Purpose |
|------|---------|
| `list_memberships` | Get all memberships with filters |
| `retrieve_membership` | Get single membership details |
| `cancel_membership` | Cancel a membership |
| `pause_membership` | Pause a membership |
| `resume_membership` | Resume paused membership |

### Payments
| Tool | Purpose |
|------|---------|
| `list_payments` | Get payment history |
| `retrieve_payment` | Get payment details |
| `create_payment` | Create manual payment |
| `refund_payment` | Issue refund |
| `list_fees` | Get fees per payment |

### Products
| Tool | Purpose |
|------|---------|
| `list_products` | Get all products |
| `retrieve_product` | Get product details |
| `list_plans` | Get pricing plans |
| `list_promo_codes` | Get discount codes |

### Members
| Tool | Purpose |
|------|---------|
| `list_members` | Get customer list |
| `retrieve_member` | Get customer details |

### Invoices
| Tool | Purpose |
|------|---------|
| `list_invoices` | Get all invoices |
| `retrieve_invoice` | Get invoice details |

## Pagination Handling

Most list endpoints return paginated results. When downloading full data:
1. Check if response has `has_more` or `next_cursor`
2. Continue fetching until all pages retrieved
3. Combine all results before saving

## Integration Points

### Daily Briefing
- Pull new memberships (last 24h)
- Pull payment failures
- Pull cancellations

### Weekly Briefing / E3
- Revenue totals
- Membership growth/churn
- Top products

### Comparison with Stripe
- Cross-reference revenue between platforms
- Identify which products on which platform
- Unified reporting

## Output Location

All exports go to:
```
YOUR-OBSIDIAN-VAULT/01 Strategic Profits/00 Admin/00 Acounting/WAP/exports/YYYY-MM-DD/
```

Analysis and reports go to:
```
YOUR-OBSIDIAN-VAULT/01 Strategic Profits/00 Admin/00 Acounting/WAP/analysis/
```

## Error Handling

If MCP tools fail:
1. Log the error with timestamp
2. Note which data was successfully exported
3. Note which data failed
4. Provide retry instructions

If authentication fails:
1. Check API key in `.mcp.json`
2. Verify key hasn't expired
3. Confirm key has required permissions

## Notes

- API key stored in `YOUR-OBSIDIAN-VAULT/.mcp.json` (Bearer token)
- Large accounts may take time for full export
- Consider running full export overnight if data is substantial
- Incremental syncs are preferred for daily operations
