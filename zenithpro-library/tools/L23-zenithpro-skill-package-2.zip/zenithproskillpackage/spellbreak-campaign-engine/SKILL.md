---
name: spellbreak-campaign-engine
description: Takes any Spellbreaking concept, topic, or masterclass title and produces a complete marketing campaign package for Level 5 Mentoring â including campaign outline, landing page copy, email sequence (5â7 emails), and ad angles. All output is calibrated to Brian D. Ridgway's Spellbreaking methodology and the Level 5 Mentoring audience: frustrated self-help seekers 30+, spiritually oriented, trauma-aware, who have tried everything and haven't gotten lasting results. Use when Abigail says "build a campaign," "write a launch sequence," "I need a landing page for [masterclass]," or "write ads for [topic]."
license: proprietary
metadata:
tags:
  - program/ctd
---
# Spellbreak Campaign Engine

Produces complete, ready-to-deploy marketing campaigns for Level 5 Mentoring â landing pages, email sequences, and ad angles â all rooted in Brian D. Ridgway's Spellbreaking method and calibrated for Abigail's spiritually-oriented, trauma-aware audience.

## Keywords
campaign, launch, email sequence, landing page, ad copy, masterclass, Spellbreaking, Level 5 Mentoring, Brian Ridgway, sales copy, funnel, promotion sequence

## Quick Start

1. Tell me the campaign topic, masterclass name, or concept (e.g., "Quantum Time Travel," "5C Manifestation," "Unclench")
2. Optionally: give me the primary promise or angle you want to lead with
3. Optionally: paste any existing copy, outlines, or notes you have for this campaign
4. I produce the full campaign package
5. Review, give feedback, iterate

No external tools required. Works from what you provide.

---

## The Spellbreaking Framework (Always Applied)

Every campaign built with this skill rests on Brian's core insight:

> People aren't failing because they lack information, willpower, or strategy. They're failing because they feel unsafe â and when people feel unsafe, they misperceive reality and make choices that keep them stuck. The Spellbreaking method works at the root level: when a person feels genuinely safe, their misperceptions dissolve and they naturally begin creating their preferred reality.

**The audience (never forget this):**
- 30+, often 40sâ60s
- Spiritually oriented â they believe in something larger than themselves
- Trauma-aware â many have done "the work" and still feel stuck
- Frustrated self-help consumers â they've read the books, done the courses, attended the events
- Their core wound: "I must be broken because nothing has worked for me"
- Their core fear: "What if I try this and it doesn't work either?"
- Their core desire: Lasting change in money, health, and/or relationships â not just another temporary shift

**The enemy is not other programs â it's misperception.** Level 5 Mentoring's marketing names the invisible root cause (feeling unsafe â misperceiving reality), which explains why every other method failed. That is the positioning that makes Brian's method different from everything the prospect has tried.

---

## Minimum Requirements Before Starting

Before producing the campaign, confirm:
- Campaign topic or masterclass name
- Primary transformation offered (money? health? relationships? all three?)
- Any existing copy, outline, or notes to reference
- Delivery format (live masterclass? recorded? email series?)

If topic is unclear, ask one question only: "What is this campaign teaching or offering?" Then proceed.

---

## Core Workflow

### Step 1 â Campaign Brief

Produce a one-page internal brief before writing a word of copy:

```
CAMPAIGN BRIEF: [Campaign Name]
Primary promise: [The one transformation this campaign delivers]
Root cause named: [How Spellbreaking explains why they've struggled before]
Enemy: [What the prospect has tried that hasn't worked â never attack competitors, attack the old paradigm]
Audience entry point: [What frustration or desire brings them to this campaign]
Method mechanism: [The one thing Brian's approach does differently â feel safe â stop misperceiving â create preferred reality]
Proof point: [What results clients have gotten with this specific topic]
Offer: [What they're registering for / buying]
```

Present the brief and proceed immediately â do not wait for approval.

### Step 2 â Landing Page Copy

Structure:

**HEADLINE (choose the best from 3 options)**
Formats to test:
- The Root Cause Reveal: "The Real Reason [Desired Result] Keeps Eluding You (It Has Nothing to Do With [Common Belief])"
- The Permission Frame: "What If Getting [Desired Result] Was Never About Trying Harder?"
- The New Mechanism: "The [Method Name] That Helps Frustrated [Audience] Finally Get [Result] â Without [Old Method They've Failed With]"

**SUB-HEADLINE**
One sentence that names the specific audience and the specific transformation. Example: "A free masterclass for spiritually-oriented people who have done everything right and still can't crack [money / health / relationships]."

**BODY COPY STRUCTURE (in order)**
1. Open with their story (mirror what they've experienced â the trying, the progress, the backslide, the frustration)
2. Name the invisible root cause: feeling unsafe is why misperception happens, which is why nothing has lasted
3. Introduce Brian's discovery: the Spellbreaking insight that changed everything
4. Describe what happens when the spell breaks: real stories, real results, what life looks like after
5. What they'll learn / experience in this masterclass (3â5 bullet points, outcome-framed not topic-framed)
6. About Brian: credibility through transformation, not credentials
7. CTA: simple, specific, low-friction

**CTA BUTTON TEXT options (3):**
Give options like: "Yes, I Want to Finally Break Through" / "Register for the Free Masterclass" / "Save My Spot"

### Step 3 â Email Sequence (5â7 Emails)

Produce a complete sequence. Each email includes:
- Subject line (plus one A/B variant)
- Preview text
- Full body copy
- CTA

**Default sequence structure:**

| Email | Name | Purpose | Send Timing |
|-------|------|---------|-------------|
| 1 | The Enrollment Email | Welcome + set context for the masterclass | Immediately on registration |
| 2 | The Root Cause Reveal | Deepen understanding of why they've struggled | Day 2 pre-masterclass |
| 3 | The Permission Email | Shift their belief that change requires suffering | Day 3 pre-masterclass |
| 4 | The Day-Of Reminder | Drive attendance with a client transformation story | Morning of masterclass |
| 5 | The Replay / Urgency | For those who didn't attend or want to rewatch | Day after |
| 6 | The Bridge | Move attendees toward the next step / offer | Day 3 post-masterclass |
| 7 | The Last Chance | Final close for those on the fence | Day 5 post-masterclass |

**Email voice for Level 5 Mentoring:**
- Warm, not corporate
- Acknowledges the reader's intelligence and journey
- Never makes the reader feel stupid for having struggled
- Uses "you" frequently â this is intimate, one-to-one writing
- References spiritual orientation naturally, not performatively
- Short paragraphs (2â3 sentences max)
- Never uses urgency tactics that feel manufactured â urgency comes from the reader's own desire for change, not scarcity games

### Step 4 â Ad Angles (5 Variations)

Produce 5 distinct ad angles for Facebook/Instagram. Each includes:
- Hook line (first 1â2 sentences before "more" cutoff)
- Body copy (3â5 sentences)
- CTA

**Ad angle frameworks for this audience:**

1. **The Frustration Mirror** â Reflects exactly what they've experienced ("If you've done the journaling, the affirmations, the therapy, the seminars, and you're still in the same place...")
2. **The Permission Reframe** â Challenges the belief that change requires hard work/suffering
3. **The Root Cause Reveal** â Teases the invisible reason they've been stuck (feeling unsafe â misperception)
4. **The Before/After Story** â One client's transformation, named specifically (anonymized if needed)
5. **The Paradigm Shift** â What if the whole self-help industry has been addressing the symptom, not the cause?

---

## Constraints

- NEVER name the root cause mechanism without showing how it works. "Misperception from feeling unsafe" must be illustrated, not just labeled.
- NEVER write copy that attacks other self-help modalities by name. Attack the old paradigm, not specific competitors or teachers.
- NEVER use manufactured urgency: no fake countdown timers, no "only 47 spots left" without documented evidence.
- NEVER write copy that requires the reader to already believe in Spellbreaking to take action. The copy earns that belief â it does not assume it.
- NEVER imply the reader is naive, hasn't tried hard enough, or is responsible for their failures. The old paradigm failed them; they did not fail.
- NEVER deliver a full campaign package without completing the Campaign Brief (Step 1) first. Copy without positioning is noise.
- NEVER produce ad copy without specifying which of the 5 angle frameworks it follows.
- ALWAYS default to Abigail's voice (warm, direct, trauma-informed, spiritually grounded) unless Brian's voice is explicitly requested.
- ALWAYS write email body copy in short paragraphs: 2-3 sentences maximum per paragraph.
- ALWAYS reference the Quantum Time Travel campaign as primary voice anchor for any new campaign.
- ALWAYS save full campaign output to vault: `AI-Training/02 Campaigns/[Campaign Name]/`
- If campaign topic is unclear after one clarifying question: proceed with the most defensible interpretation and flag assumption explicitly.

## Output Block

Every run produces a labeled, deployment-ready package in this order:

1. Campaign Brief (internal â confirm before writing copy)
2. Landing page with 3 headline options, body, form, CTA options
3. Email sequence: 5-7 emails with subject lines, preview text, full body, CTA
4. Ad angles: 5 variations labeled by framework (frustration mirror / permission reframe / root cause reveal / before-after story / paradigm shift)

Save to: `AI-Training/02 Campaigns/[Campaign Name]/`

## Vault Reference Campaigns

- `AI-Training/02 Campaigns/Quantum Time Travel/` â primary voice reference (most complete)
- `AI-Training/02 Campaigns/5C Manifestation/` â masterclass copy reference
- `AI-Training/02 Campaigns/Unclench/` â email sequence and play sheet
- `AI-Training/02 Campaigns/Spellbreak for a Living/` â Q&A email series
- `AI-Training/02 Campaigns/Money Freedom Process 4.0/` â Q&A content

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Name the root cause without showing the mechanism | Illustrate how it works, not just label it |
| Attack other self-help modalities by name | Attack the old paradigm, not competitors |
| Use manufactured urgency | Only documented real urgency |
| Assume the reader already believes in Spellbreaking | Copy earns the belief, doesn't require it |
| Imply the reader failed | The old paradigm failed them â not the reverse |
| Write copy without completing the Campaign Brief first | Positioning first, copy second |

## Before You Respond

- [ ] Have I completed the Campaign Brief (Step 1)?
- [ ] Which voice â Abigail or Brian? (Default: Abigail)
- [ ] Is every ad angle labeled with its framework (1 of 5)?
- [ ] Have I referenced Quantum Time Travel as voice anchor?
- [ ] Are email paragraphs 2-3 sentences max?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
