---
name: brand-html-converter
description: |
  Convert markdown copy into professionally branded HTML using a client's brand guide. Produces landing pages, lead magnets, thank you pages, and email mockups. Use when asked to "convert to HTML", "build the HTML", "make this branded", "HTML version of", "branded page for [client]", or "build [asset type] for [client]".
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
---

# Brand HTML Converter

Convert markdown funnel copy into professionally branded HTML that matches a client's brand guide exactly. Produces production-ready assets for lead magnets, landing pages, thank you pages, and email mockups.

---

## STEP 1: SOURCE DISCOVERY

Locate all required source materials for the client:

```
Required:
├── Brand Reference    → [YOUR_CLIENT_FOLDER]/Brand/*Brand*.md
├── Voice DNA          → .claude/skills/[client]-voice/SKILL.md
│                        OR [Client]/Downloads/*voice*.md
├── Copy Source        → The markdown file to convert (provided by user)
└── Image Assets       → [Client]/Brand/*.png, *.jpg
                         [Client]/Deliverables/*.png, *.jpg

Optional:
├── Funnel Master      → [Client]/*MASTER*Funnel*.md OR *Tripwire*.md
└── Existing HTML      → [Client]/Deliverables/*.html (for style reference)
```

**If brand reference is missing:** Ask user for: primary color, accent color, font preference, logo file location.
**If Voice DNA is missing:** Flag it. Use neutral professional tone. Warn in delivery.

---

## STEP 2: BRAND EXTRACTION

Read the brand reference file and extract a CSS custom properties map:

```css
:root {
  --primary: [darkest/anchor brand color];
  --primary-light: [lighter variant if available];
  --accent: [CTA/button color — usually gold, orange, or blue];
  --accent-light: [lighter accent for backgrounds];
  --highlight: [contrast/emphasis color — for pullquotes, highlights];
  --dark: [text color, usually near-black];
  --cream: [warm background tint];
  --white: #ffffff;
  --gray: [muted text color];
}
```

### Color Mapping Rules

| Brand Guide Term | CSS Variable | Usage |
|-----------------|-------------|-------|
| Primary/anchor color | `--primary` | Headers, hero backgrounds, footer |
| Accent/CTA color | `--accent` | Buttons, links, active states |
| Light accent | `--accent-light` | Subtle backgrounds, badges |
| Contrast/highlight color | `--highlight` | Pullquotes, emphasis lines, special callouts |
| Body text | `--dark` | Paragraph text |
| Background tint | `--cream` | Section backgrounds for visual variety |

### Font Extraction

From brand guide, identify:
1. **Heading font** — Check if it's a system font (Copperplate, Georgia) or needs Google Fonts
2. **Body font** — Check if web-safe or needs Google Fonts
3. Build font stack with fallbacks:
   ```css
   --font-heading: '[Brand Font]', [Fallback], serif;
   --font-body: '[Brand Font]', -apple-system, sans-serif;
   ```

If Google Fonts needed, add the `<link>` tag in `<head>`.

### Image Inventory

List all available images:
- Logo variants (light, dark, inverted, favicon)
- Headshots (casual, professional)
- Any product/brand images

Choose appropriate variants based on background:
- Dark background → light/inverted logo
- Light background → dark/standard logo

---

## STEP 3: ASSET TYPE DETECTION

Determine the asset type from user request or markdown structure:

| Asset Type | Markers | Layout |
|-----------|---------|--------|
| `lead-magnet` | Numbered sections, educational content, sign-off | Long-form document with cover page |
| `landing-page` | Hero, CTA, benefits, opt-in form | Conversion page with sections |
| `thank-you-page` | Confirmation, next steps, upsell | Delivery + tripwire offer |
| `email-mockup` | Subject line, from field, body copy, P.S. | Styled email preview |

---

## STEP 4: BUILD HTML

### Base Structure (All Types)

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>[Asset Title]</title>
  [Google Fonts link if needed]
  <style>
    :root { [CSS custom properties from Step 2] }
    [Layout-specific styles]
    @media print { [Print overrides] }
  </style>
</head>
<body>
  [Layout-specific content]
</body>
</html>
```

### Layout: Lead Magnet

Key sections:
- Cover page (brand gradient background, title, subtitle, author, logo)
- Table of contents (optional)
- Numbered content sections with:
  - Section headers (heading font, primary color)
  - Body paragraphs (body font)
  - Pullquote blocks (highlight color border, italic)
  - Tip/callout boxes (accent-light background)
- Sign-off section (author name, title, warm closing)
- Final CTA page (accent button linking to next funnel step)

Print CSS requirements:
- `@page { size: letter; margin: 0; }` (margins in CSS, not browser)
- `page-break-before: always` on major sections
- `page-break-inside: avoid` on pullquotes, callout boxes, headers+first paragraph
- Final section: `padding-bottom: 100px` to prevent clipping

### Layout: Landing Page

Key sections (CRO-optimized order):
1. **Hero** — Dark primary background, headline, subhead, embedded email form, privacy note
2. **Social proof bar** — Subtle `--cream` background, trust metric
3. **Problem section** — White background, pain points
4. **Solution section** — What the lead magnet covers, checkmarks
5. **About/credibility** — Brief author bio (1 paragraph max), headshot
6. **Final CTA** — Embedded form (not just a button)

Form styling:
```css
.form-input {
  background: rgba(255,255,255,0.95);
  color: var(--dark);
  border: 2px solid rgba(255,255,255,0.3);
  padding: 16px 20px;
  font-size: 16px;
  border-radius: 6px;
}
```

CTA button sizing:
```css
.cta-button {
  background: var(--accent);
  color: white;
  font-size: 18px;
  font-weight: 600;
  padding: 18px 48px;
  border-radius: 8px;
  text-transform: uppercase;
  letter-spacing: 1px;
}
```

### Layout: Thank You Page

Key sections:
1. **Hero** — Primary gradient, confirmation message, delivery checklist
2. **SMS opt-in** — Cream background, phone mockup, opt-in benefit
3. **Teaching bridge** — Connect lead magnet topic to paid offer
4. **Tripwire offer** — Primary background, price badge (accent), offer items, CTA
5. **How it works** — Numbered steps
6. **Final CTA** — Offer CTA + "start with the free guide" fallback

### Layout: Email Mockup

Key sections:
1. **Email header** — Primary gradient, logo
2. **Meta bar** — Cream background: From, Trigger, Subject
3. **Subject line options** — Accent left-border box
4. **Email body** — White, with greeting, paragraphs, CTA buttons, pullquote, sign-off, P.S.
5. **Footer** — Cream, author name and title

CTA buttons in email:
```css
.email-cta {
  background: var(--accent);
  color: white;
  font-weight: 600;
  font-size: 15px;
  letter-spacing: 1px;
  text-transform: uppercase;
  text-decoration: none;
  padding: 16px 40px;
  border-radius: 6px;
}
```

---

## STEP 5: VOICE COMPLIANCE

If Voice DNA exists for the client:
1. Read the Voice DNA file completely
2. Verify sign-off matches documented pattern (e.g., "With clarity, Sara")
3. Check for avoid-list words in the copy
4. Verify terminology matches client vocabulary
5. If a voice critic exists (`.claude/skills/[client]-critic/`), run it

---

## STEP 6: VISUAL VARIETY RULES

Prevent "wall of white" syndrome:
- **Alternate section backgrounds:** white → cream → primary (dark) → white → cream
- **Never have 3+ consecutive white sections**
- Use primary gradient for hero AND at least one mid-page section
- Pullquotes use `--highlight` color (not the same as CTA)
- Active/selected cards use `--accent` background with white text

Contrast checks:
- Text on dark backgrounds: white or `--accent-light`
- Text on accent backgrounds: white
- Cards on dark backgrounds: white with box-shadow
- Form inputs on dark backgrounds: near-white background with dark text

---

## STEP 7: OUTPUT

Save to: `[YOUR_CLIENT_FOLDER]/Deliverables/[filename].html`

Also copy images needed by the HTML to the Deliverables folder if not already there.

**After building:** Suggest running `html-share-packager` for a shareable version and `lead-magnet-pdf-builder` for PDF output.

---

## QUALITY GATE

Before delivery, verify:
- [ ] All brand colors match hex values from brand reference
- [ ] Font stack includes proper fallbacks
- [ ] Logo renders (correct variant for background)
- [ ] No placeholder text remains (no `[PLACEHOLDER]` or `#` href)
- [ ] Sign-off matches Voice DNA pattern
- [ ] No fabricated content (quotes, numbers, stories)
- [ ] Section backgrounds alternate (no 3+ white sections)
- [ ] CTA buttons are accent color, 18px+ font, uppercase
- [ ] Form inputs visible against their background
- [ ] Print CSS present for PDF-destined assets

---

## INTEGRATION

Works with:
- `html-share-packager` → Make self-contained for sharing
- `lead-magnet-pdf-builder` → Generate print-ready PDF
- `funnel-asset-builder` → Orchestrated as part of full funnel production
- `[client]-voice` → Voice pattern matching
- `[client]-critic` → Voice quality audit
