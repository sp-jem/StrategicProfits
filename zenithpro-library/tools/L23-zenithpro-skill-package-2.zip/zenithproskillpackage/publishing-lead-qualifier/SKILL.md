---
name: publishing-lead-qualifier
description: Evaluates inbound leads and prospects against Game Changer Publishing's ideal client profile â entrepreneurs who want to build authority, generate leads, or create a legacy asset through a professionally published book. Scores leads on fit, urgency, budget alignment, and likely LTV. Produces a recommendation (pursue / nurture / pass) with a customized outreach angle. Use when Cris or the sales team has a new lead, inquiry, or referral and needs a fast read on whether to prioritize.
license: proprietary
metadata:
tags:
  - program/ctd
---
# Publishing Lead Qualifier

Qualifies inbound leads against GCP's ideal client profile and produces a scored recommendation with a customized pitch angle. Takes the guesswork out of which leads get Cris's attention and which go into nurture or get passed.

## Why This Exists

Game Changer Publishing's lead generation has shifted. The AI wave is disrupting the market Cris built GCP inside. She needs a traffic and lead gen strategy, and she needs to be able to quickly prioritize leads that come in â especially high-value referrals and partnership introductions â without them sitting in her inbox unqualified for days.

This skill does the pre-work: reads what's known about the prospect, scores them against GCP's ideal client, and delivers a recommendation plus a tailored first-touch message Cris can send or have the team send.

## Keywords
lead qualification, prospect scoring, ideal client profile, publishing client, book publishing, brand authority, outreach, sales pipeline, GCP, entrepreneur publisher

## Quick Start

1. Paste what you know about the prospect â could be a referral note, LinkedIn bio, website URL, a short description, an intake form response, or notes from a conversation
2. Optionally: specify the source (referral from whom, cold inquiry, conference lead, etc.)
3. Claude scores the lead and produces the qualification report + outreach message
4. Review and either act on the recommendation or adjust the score with additional context

## Minimum Requirements Before Starting

Before qualifying, verify at least one of the following:

- Prospect's name and company or industry
- What they do and who they serve
- Some indication of why they're interested in publishing (even a vague one)

If none of these are available, Claude will flag what information is needed before scoring.

## GCP Ideal Client Profile

**Best fit â all of these present:**
- Entrepreneur, coach, consultant, or expert with a genuine story or methodology
- Wants a book to generate leads, establish authority, or build a legacy
- Has an existing audience, platform, or network (doesn't need the book to build from zero)
- Can invest $10,000â$50,000+ in the publishing process (this is not self-publishing; it's premium publishing)
- Is motivated by outcome (more clients, speaking, brand credibility) not just by "writing a book"
- Decision-maker â not seeking approval from a board or committee

**Strong signals:**
- Has a defined audience they already serve
- Mentions specific business goals the book will serve (speaking fees, client acquisition, JV partnerships)
- Has been referred by a current GCP client or partner
- Is in a market where a book is a credible authority signal (business, health, finance, real estate, coaching)

**Weak signals â qualify carefully:**
- First-time entrepreneur with no existing audience
- Wants "passive income" from book sales (misunderstands GCP's model)
- Budget signals below $10K
- Academic or literary interest, not business interest
- Wants to retain all creative control â not a publishing collaboration mindset
- Timeline is vague and urgent at the same time ("I need this done in 3 months")

**Not a fit:**
- Fiction, memoir for personal reasons only, or niche hobby
- Looking for traditional publishing deal (agent + big house)
- Looking for self-publishing tools (KDP, IngramSpark DIY)
- Not willing to be involved in their own book

## Core Workflow

### Step 1 â Ingest and Classify

Read all available prospect information. Classify:
- **Source:** Referral / Cold Inquiry / Partnership Lead / Conference / Social Media / Other
- **Information quality:** Rich (enough to score confidently) / Thin (flag what's missing)

### Step 2 â Score Across Five Dimensions

Score each dimension 1â5 (5 = strongest possible fit):

**1. Outcome Alignment (1â5)**
Does the prospect want publishing for business reasons (authority, leads, credibility) or personal reasons (legacy, dream)? Business is a stronger commercial fit â they will invest more and see ROI more clearly.

**2. Audience and Platform Readiness (1â5)**
Does the prospect have an existing audience, network, or distribution? A book serves a platform. A platform-less author has a longer path to ROI and may struggle with motivation once they realize no one is reading.

**3. Budget Signals (1â5)**
Any signals about what they can or are willing to invest. 5 = clear signals they operate at the investment level GCP requires. 1 = signals that suggest they're price-shopping or expecting low-cost self-publishing.

**4. Decision Authority (1â5)**
Is this person the decision-maker? Solo founder / owner / CEO = 5. "I need to run it by my partner/board/spouse" = risk factor. Not disqualifying, but flags timeline risk.

**5. Urgency and Motivation (1â5)**
Is there a real deadline or catalyst driving interest? Speaking engagement, product launch, retirement, competitor movement, personal milestone? Urgency closes. Vague interest lingers.

**Total: [X/25]**

### Step 3 â Produce the Recommendation

**Score 20â25:** High-priority pursuit. Flag for Cris personally. This is a Calendly booking opportunity.

**Score 14â19:** Worth pursuing with qualification call. Move to sales team. Use customized outreach.

**Score 8â13:** Nurture track. Add to email list with value content. Not ready yet â check back in 3â6 months.

**Score 7 and below:** Pass. Do not invest sales time. If referred, thank the referrer and explain GCP's model so they can refer better next time.

### Step 4 â Produce the First-Touch Message

Write a first-touch outreach message (email or Google Chat) calibrated to:
- The specific business goal the prospect seems to have (based on available info)
- The source (warm if referred, value-first if cold)
- The appropriate urgency level (don't oversell a lukewarm prospect)

GCP's voice in outreach: direct, professional, warm. No hype. No pressure. The book is a business asset â treat it that way.

## Output Format

---

**GCP LEAD QUALIFICATION REPORT**
**Prospect:** [Name] â [Company / Industry]
**Source:** [Referral / Cold / Partnership / etc.]
**Date:** [Date]

---

**SCORE SUMMARY**

| Dimension | Score | Signal |
|-----------|-------|--------|
| Outcome Alignment | [1-5] | [Key indicator] |
| Audience Readiness | [1-5] | [Key indicator] |
| Budget Signals | [1-5] | [Key indicator] |
| Decision Authority | [1-5] | [Key indicator] |
| Urgency and Motivation | [1-5] | [Key indicator] |
| **Total** | **[X/25]** | |

**RECOMMENDATION:** [HIGH PRIORITY / PURSUE / NURTURE / PASS]

---

**PROFILE SUMMARY**

[2-3 sentences: who this person is, what they want, what makes them a fit or not]

**Fit factors:**
- [Specific positive signal]
- [Specific positive signal]

**Risk factors:**
- [Specific concern or gap]
- [Specific concern or gap]

---

**FIRST-TOUCH MESSAGE**

**To:** [Name]
**Subject:** [Subject line]

[3-paragraph message â opening acknowledges context or referral, middle connects their specific goal to what GCP delivers, close is a single low-friction ask: Calendly link, reply to learn more, or a question.]

---

**NOTES FOR CRIS**
[Anything specific she should know before the call â questions to ask, sensitivities flagged, how to position GCP's differentiation given this prospect's likely comparisons]

---

## Operating Rules

**What this skill does:**
- Scores each lead based only on information provided â not on assumptions or optimism
- Marks any unscoreable dimension as "Unknown" with a specific explanation of what would clarify it
- Produces one recommendation â a single word or short phrase â with no ambiguity
- Flags referred leads prominently regardless of score, because the referrer relationship is at stake
- If genuinely unclear on recommendation: outputs "Qualify Call Needed" plus exactly three questions that would resolve the ambiguity

**What this skill never does:**
- Never recommend "pursue" for a lead with Budget Signals scored below 2 â the only exception is a compelling strategic reason, which must be stated in writing before the recommendation
- Never produce a first-touch message that could apply to any prospect â every message references something specific from the prospect's information; generic messages are disqualified
- Never score a dimension higher to reach a preferred recommendation â score each dimension independently before reading the total
- Never recommend "High Priority" without at least one of these signals present: referral from a GCP client, explicit budget signal above $10K, or a stated specific business outcome the book must achieve
- Never omit the "Notes for Cris" section â even if the notes are "No sensitivities identified, proceed normally"

**Constraint rules:**
- If zero qualifying information is available (no name, no industry, no publishing intent), do not score â output a list of the minimum information needed and stop
- If a referred lead scores below 8 total, flag this to Cris before sending any outreach â referred lead handling is Cris's judgment call, not the qualification system's
- Recommendation thresholds are fixed: 20â25 = High Priority, 14â19 = Pursue, 8â13 = Nurture, 7 and below = Pass â no rounding up, no "borderline" category

## Before You Respond

- [ ] Do I have at least minimum info (name, industry, publishing intent)?
- [ ] Did I score each dimension independently before reading the total?
- [ ] Is the recommendation aligned with the fixed score thresholds?
- [ ] Is the first-touch message specific to this prospect (not generic)?
- [ ] Did I include Notes for Cris?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Before You Respond, Version History (Gauntlet QA pass)
