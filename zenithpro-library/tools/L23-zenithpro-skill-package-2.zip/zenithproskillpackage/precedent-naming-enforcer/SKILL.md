---
name: precedent-naming-enforcer
description: Audits and renames legal precedent files to the Hassaan & Associates naming standard â eliminating SCAN####, duplicate folders, empty folders, and inconsistent names across the Milton and Grimsby precedent libraries. Use when Fay needs to clean up the server, rename a batch of files, establish a naming convention, audit what's in a folder, or says anything like "clean up the server," "rename these files," "fix the naming," or "organize the precedents."
license: proprietary
tags:
  - program/ctd
  - client/fay-hassaan
---
# Precedent Naming Enforcer

Audits existing precedent files and produces rename instructions that comply with the Hassaan & Associates naming standard. Eliminates SCAN#### names, empty folders, duplicates, and inconsistent naming across Milton and Grimsby.

---

## MINIMUM REQUIREMENTS BEFORE STARTING

Do not produce any rename plan until all three conditions are met:
- A folder listing or file list is provided (from File Explorer, SharePoint, or vault index)
- Office is specified: Milton (Terminal Server) or Grimsby (SharePoint)
- Practice area is specified if narrowing to a single folder (optional for full-library audits)

If no file list is provided, say exactly: "Paste a folder listing from File Explorer or describe the files you want to rename. Include the office (Milton or Grimsby) and practice area if relevant. I'll produce a complete rename plan with a health report."

---

## THE HASSAAN & ASSOCIATES NAMING STANDARD

All files follow this structure:

```
[PracticeArea]-[DocumentType]-[Descriptor]-[Version].ext
```

### Practice Area Codes

| Code | Area |
|------|------|
| RE | Real Estate |
| EST | Estates / Wills |
| CORP | Corporate |
| LIT | Litigation |
| IMM | Immigration |
| ADMIN | Administrative |
| HR | Human Resources |
| GEN | General / Does not fit above |

### Document Type Labels

| Label | Meaning |
|-------|---------|
| PREC | Precedent (template document) |
| LETTER | Client letter or standard correspondence |
| FORM | Standard form or government form |
| POLICY | Internal policy document |
| CHECKLIST | Operational checklist |
| GUIDE | Client education guide or how-to |
| AGREEMENT | Agreement or contract template |
| RESOLUTION | Corporate resolution template |
| TRANSFER | Transfer documents |
| CLOSING | Closing documents or statements |

### Descriptor

Short plain-English description of the document. Maximum 4 words. No special characters except hyphens. Use title case.

Examples: `First-Time-Buyer-Instructions`, `Power-Of-Attorney`, `Share-Transfer-Agreement`, `Closing-Cost-Statement`

### Version

- `v1` for the first clean version
- `v2`, `v3` for revisions
- Omit version if there is clearly only one version and no revision history

### Naming Examples

| Old Name | New Name |
|----------|----------|
| SCAN0042.pdf | RE-FORM-Transfer-Statement-v1.pdf |
| Copy of Copy of Will 2019.docx | EST-PREC-Last-Will-Testament-v1.docx |
| krusell wills folder thing.docx | EST-PREC-Krusell-Acquired-Wills-v1.docx |
| Powers of attorney - FLANNAGAN.docx | EST-PREC-Power-Of-Attorney-v1.docx |
| corp res general.docx | CORP-RESOLUTION-General-Purpose-v1.docx |
| RE agreement updated FINAL v2 (1).docx | RE-AGREEMENT-Purchase-Sale-v2.docx |

---

## CORE WORKFLOW

### Step 1 â Ingest the File List

Read the full folder listing before producing any output. Do not categorize or rename as you go â read everything first.

For each file, note:
- Current file name and extension
- Apparent file type and content (infer from name, extension, and folder context)
- Office and folder location
- Practice area (infer from name or folder)
- Whether it appears to be a template/precedent, a client-specific document (should not be in precedents library), or a scan

### Step 2 â Categorize Each File

Assign each file to exactly one category:

**RENAME** â The file belongs in the precedents library and needs a compliant name.
**DELETE CANDIDATE** â Empty files, true duplicates, clearly obsolete content, or SCAN#### files that are not actual precedents. Never delete without Fay's confirmation â flag only.
**MOVE CANDIDATE** â The file belongs in a different folder or office.
**KEEP AS IS** â Name meets the standard or close enough. Note any minor improvements without forcing a rename.

Collision rule: If two files in the same folder would produce the same proposed new name, flag both as a collision â present both options and ask Fay to resolve before executing. Do not silently rename one with a suffix.

### Step 3 â Produce the Rename Table

**[OFFICE] PRECEDENT RENAME PLAN â [Folder Name]**
**Generated:** [Date]
**Files reviewed:** [Count]

**RENAME**

| # | Current Name | New Name | Practice Area | Notes |
|---|-------------|----------|---------------|-------|
| 1 | [old name] | [new name] | [area code] | [any note] |

**DELETE CANDIDATES** (Fay to confirm before deletion)

| # | File Name | Reason for Deletion Recommendation |
|---|-----------|-------------------------------------|
| 1 | [File] | [Reason â be specific; include "open to verify" if content is unknown] |

**MOVE CANDIDATES**

| # | File Name | Current Location | Recommended Location | Reason |
|---|-----------|-----------------|---------------------|--------|
| 1 | [File] | [Current folder] | [Target folder] | [Why] |

**NAMING COLLISIONS** (Fay to resolve before executing)

| # | File A | File B | Proposed Name (Conflicts) | Resolution Needed |
|---|--------|--------|--------------------------|-------------------|
| 1 | [File] | [File] | [Name] | [Describe the conflict] |

**KEEP AS IS**

| # | File Name | Notes |
|---|-----------|-------|
| 1 | [File] | [Meets standard / minor improvement: optional] |

### Step 4 â Server Health Report

After the tables:

> **PRECEDENT LIBRARY HEALTH â [Office] [Folder]**
> Total files reviewed: [N]
> Files to rename: [N]
> Delete candidates: [N] (requires Fay's confirmation)
> Move candidates: [N]
> Naming collisions: [N] (requires Fay's resolution)
> Files meeting standard: [N]
>
> **Biggest issues found:**
> 1. [Top issue]
> 2. [Second issue]
> 3. [Third issue]
>
> **Recommended cleanup order:**
> 1. [Highest impact, lowest risk]
> 2. [Next]
> 3. [Last]

---

## GUARDRAILS

- Never instruct deletion without Fay's explicit confirmation. Every delete candidate is flagged, not executed.
- If a file name gives no indication of content (SCAN####, generic names), flag as "content unknown â open to verify before deleting" rather than assuming it is worthless.
- Previous lawyer files (Grieves, Flannagan, Keir, Breen at Milton; Krusell at Grimsby) must be moved to a dedicated archive folder, not deleted. They may contain valid precedents or unresolved client commitments.
- Client-specific documents (with actual client names in the file name) must never remain in the precedents library â flag them for relocation to the correct client file.
- Naming collisions are never silently resolved. Surface every collision for Fay to decide.
- Milton uses Terminal Server paths; Grimsby uses SharePoint paths. The naming standard is identical across both offices.

---

## OUTPUT SAVE LOCATION

`03 Law Files/[Grimsby or Milton]/Precedents/rename-plan-[YYYY-MM-DD].md`

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Instruct deletion without Fay's confirmation | Every delete candidate is flagged, never executed |
| Assume SCAN#### files are worthless | Flag as "content unknown â open to verify" |
| Delete previous lawyer files (Grieves, Krusell, etc.) | Move to archive folder â may contain valid precedents |
| Leave client-specific documents in precedents library | Flag for relocation to correct client file |
| Silently resolve naming collisions | Surface every collision for Fay to decide |
| Mix Milton and Grimsby in one output | Separate outputs per office |

## Before You Respond

- [ ] Which office (Milton Terminal Server or Grimsby SharePoint)?
- [ ] Am I flagging delete candidates rather than executing?
- [ ] Are previous lawyer files marked for archive, not deletion?
- [ ] Are client-specific documents flagged for relocation?
- [ ] Are naming collisions surfaced for Fay's decision?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
