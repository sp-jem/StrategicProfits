#!/usr/bin/env python3
"""
UNIVERSAL TRANSCRIPTION SCRIPT
==============================
Transcribes ALL audio and video formats to Markdown.
Automatically converts problematic formats to WAV before transcription.

Usage:
    python universal_transcribe.py <folder1> [folder2] ...

Supports:
    VIDEO: mp4, m4v, mov, avi, flv, mkv, wmv, webm, 3gp, ogv, ts, vob, divx, asf, mpg, mpeg
    AUDIO DIRECT: mp3, m4a, wav
    AUDIO CONVERT: wma, flac, m4b, ogg, opus, aiff, aac
"""

import os
import sys
import subprocess
from pathlib import Path
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
import time
import tempfile

os.environ['PATH'] = '/usr/bin:/bin:/opt/homebrew/bin:~/Library/Python/3.9/bin:' + os.environ.get('PATH', '')

# Worker counts - M3 Ultra MAX POWER - 32 cores + GPU
PDF_WORKERS = 32
DOC_WORKERS = 32
TEXT_WORKERS = 32
EBOOK_WORKERS = 16
TRANSCRIBE_WORKERS = 32  # MAX - use all cores for transcription
CONVERT_WORKERS = 16     # MAX - convert-first formats (wma, flac, m4b)

# Formats that MLX Whisper handles directly
DIRECT_AUDIO = ['.mp3', '.MP3', '.m4a', '.M4A', '.wav', '.WAV']
DIRECT_VIDEO = [
    '.mp4', '.MP4', '.m4v', '.M4V', '.mov', '.MOV', '.avi', '.AVI',
    '.flv', '.FLV', '.mkv', '.MKV', '.wmv', '.WMV', '.webm', '.WEBM',
    '.3gp', '.3GP', '.ogv', '.OGV', '.mpg', '.MPG', '.mpeg', '.MPEG',
    '.ts', '.TS', '.vob', '.VOB', '.divx', '.DIVX', '.asf', '.ASF'
]

# Formats that need conversion to WAV first
CONVERT_FIRST = [
    '.wma', '.WMA', '.flac', '.FLAC', '.m4b', '.M4B',
    '.ogg', '.OGG', '.opus', '.OPUS', '.aiff', '.AIFF', '.aac', '.AAC'
]

def transcribe_direct(media_path):
    """Transcribe audio/video that MLX Whisper handles natively."""
    try:
        md_path = str(media_path) + '.md'
        if os.path.exists(md_path):
            return ('skip', media_path)

        result = subprocess.run(
            [
                sys.executable, '-c',
                f'''
import mlx_whisper
result = mlx_whisper.transcribe("{media_path}", path_or_hf_repo="mlx-community/whisper-large-v3-turbo")
print(result["text"])
'''
            ],
            capture_output=True, text=True, timeout=1800
        )

        if result.returncode == 0 and result.stdout.strip():
            with open(md_path, 'w', encoding='utf-8') as f:
                f.write(f"# {media_path.stem}\n\n")
                f.write(f"*Transcribed from: {media_path.name}*\n\n")
                f.write(result.stdout.strip())
            return ('success', media_path)
        return ('error', media_path, result.stderr[:200] if result.stderr else 'No output')
    except Exception as e:
        return ('error', media_path, str(e))

def transcribe_with_conversion(audio_path):
    """Convert to WAV first, then transcribe."""
    try:
        md_path = str(audio_path) + '.md'
        if os.path.exists(md_path):
            return ('skip', audio_path)

        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
            wav_path = tmp.name

        try:
            # Convert to WAV
            convert_result = subprocess.run(
                ['ffmpeg', '-y', '-i', str(audio_path), '-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', wav_path],
                capture_output=True, text=True, timeout=600
            )

            if convert_result.returncode != 0:
                return ('error', audio_path, f'ffmpeg: {convert_result.stderr[:80]}')

            if not os.path.exists(wav_path) or os.path.getsize(wav_path) == 0:
                return ('error', audio_path, 'Empty WAV')

            # Transcribe WAV
            result = subprocess.run(
                [
                    sys.executable, '-c',
                    f'''
import mlx_whisper
result = mlx_whisper.transcribe("{wav_path}", path_or_hf_repo="mlx-community/whisper-large-v3-turbo")
print(result["text"])
'''
                ],
                capture_output=True, text=True, timeout=1800
            )

            if result.returncode == 0 and result.stdout.strip():
                with open(md_path, 'w', encoding='utf-8') as f:
                    f.write(f"# {audio_path.stem}\n\n")
                    f.write(f"*Transcribed from: {audio_path.name}*\n\n")
                    f.write(result.stdout.strip())
                return ('success', audio_path)
            return ('error', audio_path, result.stderr[:100] if result.stderr else 'No output')

        finally:
            if os.path.exists(wav_path):
                os.remove(wav_path)

    except Exception as e:
        return ('error', audio_path, str(e))

def find_files(folders, extensions):
    """Find all files with given extensions."""
    files = []
    for folder in folders:
        folder_path = Path(folder)
        if not folder_path.exists():
            print(f"Warning: {folder} does not exist")
            continue
        for ext in extensions:
            files.extend(folder_path.rglob(f"*{ext}"))
    return files

def process_batch(func, items, desc, num_workers):
    """Process a batch in parallel."""
    if not items:
        return {'success': 0, 'skip': 0, 'error': 0}

    stats = {'success': 0, 'skip': 0, 'error': 0}
    total = len(items)
    start_time = time.time()

    print(f"\n{desc}: {total} files with {num_workers} workers")
    print("=" * 60)

    with ProcessPoolExecutor(max_workers=num_workers) as executor:
        futures = {executor.submit(func, item): item for item in items}
        completed = 0

        for future in as_completed(futures):
            completed += 1
            try:
                result = future.result()
                if result[0] == 'success':
                    stats['success'] += 1
                    print(f"  [{completed}/{total}] â {Path(result[1]).name[:50]}")
                elif result[0] == 'skip':
                    stats['skip'] += 1
                else:
                    stats['error'] += 1
                    print(f"  [{completed}/{total}] â {Path(result[1]).name[:40]} - {result[2][:30] if len(result) > 2 else 'Error'}")
            except Exception as e:
                stats['error'] += 1
                print(f"  [{completed}/{total}] â {str(e)[:50]}")

    elapsed = time.time() - start_time
    rate = total / elapsed if elapsed > 0 else 0
    print(f"  Done in {elapsed:.1f}s ({rate:.1f} files/sec)")
    print(f"  Success: {stats['success']}, Skip: {stats['skip']}, Error: {stats['error']}")
    return stats

def main():
    if len(sys.argv) < 2:
        print("Usage: python universal_transcribe.py <folder1> [folder2] ...")
        sys.exit(1)

    folders = sys.argv[1:]

    print("\n" + "=" * 60)
    print("UNIVERSAL TRANSCRIPTION")
    print("=" * 60)
    print(f"Folders: {len(folders)}")
    for f in folders:
        print(f"  - {f}")

    # Find all files
    print("\nScanning...")
    direct_audio = find_files(folders, DIRECT_AUDIO)
    direct_video = find_files(folders, DIRECT_VIDEO)
    convert_audio = find_files(folders, CONVERT_FIRST)

    total = len(direct_audio) + len(direct_video) + len(convert_audio)
    print(f"\nFound {total} files:")
    print(f"  Direct audio (mp3, m4a, wav): {len(direct_audio)}")
    print(f"  Direct video (mp4, mov, etc): {len(direct_video)}")
    print(f"  Convert-first (wma, flac, m4b): {len(convert_audio)}")

    all_stats = {}
    start = time.time()

    # Process direct formats first (faster)
    all_stats['audio'] = process_batch(transcribe_direct, direct_audio, "Audio (direct)", TRANSCRIBE_WORKERS)
    all_stats['video'] = process_batch(transcribe_direct, direct_video, "Video (direct)", TRANSCRIBE_WORKERS)

    # Then convert-first formats
    all_stats['convert'] = process_batch(transcribe_with_conversion, convert_audio, "Audio (convert-first)", CONVERT_WORKERS)

    # Summary
    elapsed = time.time() - start
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Total time: {elapsed/60:.1f} minutes")

    total_success = sum(s['success'] for s in all_stats.values())
    total_skip = sum(s['skip'] for s in all_stats.values())
    total_error = sum(s['error'] for s in all_stats.values())

    print(f"Success: {total_success}")
    print(f"Skipped: {total_skip}")
    print(f"Errors: {total_error}")

if __name__ == "__main__":
    main()
