#!/usr/bin/env python3
"""
FIX FAILED AUDIO TRANSCRIPTIONS
================================
Handles WMA, FLAC, M4B and other formats that MLX Whisper can't process directly.
Converts them to WAV first via ffmpeg, then transcribes.
"""

import os
import sys
import subprocess
from pathlib import Path
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
import time
import tempfile

os.environ['PATH'] = '/usr/bin:/bin:/opt/homebrew/bin:~/Library/Python/3.9/bin:' + os.environ.get('PATH', '')

# Number of parallel workers (fewer for this since ffmpeg conversion adds overhead)
NUM_WORKERS = 4

# Problematic formats that need conversion to WAV first
CONVERT_FIRST_EXTS = [
    '.wma', '.WMA',
    '.flac', '.FLAC',
    '.m4b', '.M4B',
    '.ogg', '.OGG',
    '.opus', '.OPUS',
    '.aiff', '.AIFF',
    '.aac', '.AAC'
]

def convert_and_transcribe(audio_path):
    """Convert problematic audio to WAV, then transcribe with MLX Whisper."""
    try:
        md_path = str(audio_path) + '.md'
        if os.path.exists(md_path):
            return ('skip', audio_path)

        # Create temp WAV file
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
            wav_path = tmp.name

        try:
            # Convert to WAV using ffmpeg
            convert_result = subprocess.run(
                ['ffmpeg', '-y', '-i', str(audio_path), '-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', wav_path],
                capture_output=True, text=True, timeout=600
            )

            if convert_result.returncode != 0:
                return ('error', audio_path, f'ffmpeg failed: {convert_result.stderr[:100]}')

            if not os.path.exists(wav_path) or os.path.getsize(wav_path) == 0:
                return ('error', audio_path, 'WAV conversion produced empty file')

            # Transcribe the WAV file
            result = subprocess.run(
                [
                    sys.executable, '-c',
                    f'''
import mlx_whisper
result = mlx_whisper.transcribe("{wav_path}", path_or_hf_repo="mlx-community/whisper-large-v3-turbo")
print(result["text"])
'''
                ],
                capture_output=True, text=True, timeout=1800
            )

            if result.returncode == 0 and result.stdout.strip():
                with open(md_path, 'w', encoding='utf-8') as f:
                    f.write(f"# {audio_path.stem}\n\n")
                    f.write(f"*Transcribed from: {audio_path.name}*\n\n")
                    f.write(result.stdout.strip())
                return ('success', audio_path)
            return ('error', audio_path, result.stderr[:200] if result.stderr else 'No transcription output')

        finally:
            # Clean up temp file
            if os.path.exists(wav_path):
                os.remove(wav_path)

    except Exception as e:
        return ('error', audio_path, str(e))

def find_failed_files(folders):
    """Find audio files that don't have corresponding .md files."""
    failed = []
    for folder in folders:
        folder_path = Path(folder)
        if not folder_path.exists():
            print(f"Warning: {folder} does not exist")
            continue

        for ext in CONVERT_FIRST_EXTS:
            for audio_file in folder_path.rglob(f"*{ext}"):
                md_path = str(audio_file) + '.md'
                if not os.path.exists(md_path):
                    failed.append(audio_file)

    return failed

def process_batch(items, num_workers):
    """Process a batch of items in parallel."""
    if not items:
        return {'success': 0, 'skip': 0, 'error': 0}

    stats = {'success': 0, 'skip': 0, 'error': 0}
    total = len(items)
    start_time = time.time()

    print(f"\nProcessing {total} files with {num_workers} workers")
    print("=" * 60)

    with ProcessPoolExecutor(max_workers=num_workers) as executor:
        futures = {executor.submit(convert_and_transcribe, item): item for item in items}
        completed = 0

        for future in as_completed(futures):
            completed += 1
            try:
                result = future.result()
                if result[0] == 'success':
                    stats['success'] += 1
                    print(f"  [{completed}/{total}] â {Path(result[1]).name[:50]}")
                elif result[0] == 'skip':
                    stats['skip'] += 1
                else:
                    stats['error'] += 1
                    print(f"  [{completed}/{total}] â {Path(result[1]).name[:40]} - {result[2][:30] if len(result) > 2 else 'Error'}")
            except Exception as e:
                stats['error'] += 1
                print(f"  [{completed}/{total}] â Exception: {str(e)[:50]}")

    elapsed = time.time() - start_time
    print(f"\nCompleted in {elapsed:.1f}s")
    print(f"Success: {stats['success']}, Skipped: {stats['skip']}, Errors: {stats['error']}")

    return stats

def main():
    if len(sys.argv) < 2:
        print("Usage: python fix_failed_audio.py <folder1> [folder2] ...")
        sys.exit(1)

    folders = sys.argv[1:]

    print("\n" + "=" * 60)
    print("FIX FAILED AUDIO TRANSCRIPTIONS")
    print("=" * 60)
    print(f"Folders to scan: {len(folders)}")
    for f in folders:
        print(f"  - {f}")

    print("\nScanning for failed transcriptions...")
    failed_files = find_failed_files(folders)

    print(f"\nFound {len(failed_files)} files needing transcription:")

    # Count by extension
    ext_counts = {}
    for f in failed_files:
        ext = f.suffix.lower()
        ext_counts[ext] = ext_counts.get(ext, 0) + 1

    for ext, count in sorted(ext_counts.items()):
        print(f"  {ext}: {count}")

    if not failed_files:
        print("\nNo failed files to process!")
        return

    # Process them
    stats = process_batch(failed_files, NUM_WORKERS)

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Total processed: {len(failed_files)}")
    print(f"Success: {stats['success']}")
    print(f"Errors: {stats['error']}")

if __name__ == "__main__":
    main()
