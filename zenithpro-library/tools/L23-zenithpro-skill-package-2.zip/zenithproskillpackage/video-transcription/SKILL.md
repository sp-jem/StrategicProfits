---
name: video-transcription
description: Transcribes local video files (MP4, MOV, etc.) to Markdown text files using MLX Whisper on Apple Silicon. Batch processes entire course folders with high-quality English transcription.
---

# Video Transcription (Local Files)

This skill transcribes video files from your local filesystem to Markdown text documents using MLX Whisper, optimized for Apple Silicon.

## Requirements

| Requirement | Details |
|-------------|---------|
| **Platform** | Apple Silicon Mac (M1/M2/M3/M4) |
| **Python** | 3.9 or later |
| **Disk Space** | ~3GB for Whisper model (one-time download) |
| **Dependencies** | MLX Whisper + ffmpeg |

## First-Time Setup (New Machine)

Run the setup script to install all dependencies:

```bash
bash ~/.claude/skills/video-transcription/setup.sh
```

This will:
1. Verify Apple Silicon architecture
2. Install MLX Whisper via pip
3. Download ffmpeg static binary to ~/bin/
4. Verify installation

**Note:** The first transcription will download the Whisper model (~3GB). Subsequent transcriptions are faster.

### Manual Installation (if preferred)

```bash
# Install MLX Whisper
pip3 install mlx-whisper

# Install ffmpeg
mkdir -p ~/bin
curl -L "https://evermeet.cx/ffmpeg/ffmpeg-7.1.1.zip" -o /tmp/ffmpeg.zip
unzip -o /tmp/ffmpeg.zip -d ~/bin/
chmod +x ~/bin/ffmpeg
```

### Verify Installation

```bash
# Check MLX Whisper (path varies by Python version)
~/.local/bin/mlx_whisper --help
# or
~/Library/Python/3.9/bin/mlx_whisper --help

# Check ffmpeg
~/bin/ffmpeg -version
```

---

## When to Use This Skill

- Transcribing course videos for text-based study
- Converting video lectures to searchable text
- Creating source material for framework extraction
- Building transcript libraries for AI processing
- Converting video content to readable Markdown files
- Preparing video content for the Source-to-Skill pipeline

## What This Skill Does

1. **Batch Transcription**: Processes entire folders of videos recursively
2. **High-Quality Output**: Uses Whisper large-v3-turbo model for accuracy
3. **Markdown Format**: Creates clean, readable Markdown files
4. **Resume Capability**: Skips already-transcribed files
5. **Apple Silicon Optimized**: Uses MLX for fast local processing

## Trigger Phrases

| Phrase | Action |
|--------|--------|
| "Transcribe the videos in [folder] to [output folder]" | Batch transcription |
| "Transcribe all videos in this folder..." | Local video transcription |
| "Convert these videos to text transcripts" | Video-to-text conversion |
| "Create Markdown transcripts from [course folder]" | Course transcription |
| "Setup video transcription on this machine" | Run setup script |

## How to Use

### Basic Usage

```
Transcribe the videos in /path/to/course/ to /path/to/output/
```

### Specific Course Example

```
Transcribe all the video files in:
/Volumes/personal_folder/Courses/Marketing Course/

And save the transcripts to:
~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/00 Projects/Source Material/
```

## Technology Stack

| Component | Purpose | Location |
|-----------|---------|----------|
| **MLX Whisper** | Speech-to-text (Apple Silicon optimized) | `~/Library/Python/3.x/bin/mlx_whisper` |
| **Whisper Model** | `mlx-community/whisper-large-v3-turbo` | Auto-downloaded on first use |
| **ffmpeg** | Audio extraction from video | `~/bin/ffmpeg` |
| **Python 3.9+** | Script execution | System Python or Homebrew |

### Supported Video Formats

- `.mp4` (most common)
- `.mov` (QuickTime)
- `.avi`
- `.mkv`
- `.webm`
- `.m4v`
- `.flv`
- `.ts`
- `.3gp`
- `.ogv`
- `.wmv`
- `.vob`
- `.divx`
- `.asf`

### Supported Audio Formats

**Direct transcription (MLX Whisper handles natively):**
- `.mp3` (most common)
- `.m4a`
- `.wav`

**Requires conversion to WAV first (handled automatically):**
- `.wma` (Windows Media Audio)
- `.flac` (lossless audio)
- `.m4b` (audiobooks)
- `.ogg` / `.opus`
- `.aiff`
- `.aac`

The skill automatically detects these formats and converts them to WAV via ffmpeg before transcription.

## Output Format

Each video creates a Markdown file with:

```markdown
# Video Title (from filename)

**Source:** [Course Name]
**Video:** original-filename.mp4

---

## Transcript

[Full transcript text here...]
```

## Processing Details

| Metric | Value |
|--------|-------|
| **Speed** | ~2-3 minutes per video (varies by length) |
| **Language** | English (optimized) |
| **Accuracy** | High quality with punctuation |
| **Subfolder Handling** | Recursive (processes all subfolders) |
| **Resume** | Skips files with existing transcripts |
| **Output Size** | ~30-70KB per transcript |

## Script Files

| File | Purpose |
|------|---------|
| `SKILL.md` | This documentation |
| `setup.sh` | One-time dependency installation |
| `scripts/universal_transcribe.py` | **Main script** - handles ALL formats with parallel processing |
| `scripts/fix_failed_audio.py` | Re-processes failed WMA/FLAC/M4B files |

### Universal Transcribe Script

The main transcription script that handles everything:

```bash
python ~/.claude/skills/video-transcription/scripts/universal_transcribe.py "/path/to/folder1" "/path/to/folder2"
```

Features:
- Parallel processing (8 workers for transcription, 4 for convert-first formats)
- Automatic WAV conversion for WMA, FLAC, M4B, OGG, OPUS, AIFF, AAC
- Skips already-transcribed files
- Progress tracking with success/error counts

### Fix Failed Audio Script

Re-processes audio files that failed in a previous run:

```bash
python ~/.claude/skills/video-transcription/scripts/fix_failed_audio.py "/path/to/folder"
```

This scans for WMA/FLAC/M4B/etc files without corresponding .md files and transcribes them.

### How the Script Works

1. Scans source folder recursively for video files
2. Creates output folder if needed
3. For each video:
   - Skips if transcript already exists
   - Runs MLX Whisper to transcribe
   - Saves JSON output
   - Extracts text and formats as Markdown
   - Cleans up temporary files
4. Reports progress throughout

## Example Session

**User**: "Transcribe the videos in /Volumes/external/Courses/Marketing Mastery/ and put them in my copywriting source folder"

**Claude**:
1. Checks if dependencies are installed (offers setup if not)
2. Creates transcription script with correct paths
3. Runs batch transcription
4. Reports progress: `[1/25] Transcribing: lesson-1-intro.mp4`
5. Continues until complete
6. Confirms all files saved to output location

## Common Use Cases

| Use Case | Input | Output |
|----------|-------|--------|
| Course transcription | `/Courses/Selling System/` | `/Source Material/Perry Belcher/` |
| Webinar archive | `/Webinars/2024/` | `/Webinar Transcripts/` |
| Workshop videos | `/Workshops/Framework Forge/` | `/Workshop Transcripts/` |
| Interview series | `/Interviews/Experts/` | `/Interview Library/` |

## Tips

1. **First run**: The Whisper model downloads on first use (~3GB). Allow extra time.
2. **Large batches**: The script runs in background - you can monitor progress
3. **External drives**: Make sure the drive is mounted and accessible
4. **Filename cleaning**: Script removes problematic characters from filenames
5. **Disk space**: Transcripts are small (~30-70KB each) but need temp space for JSON
6. **Resume**: If interrupted, just run again - it skips completed files
7. **New machine**: Run `bash ~/.claude/skills/video-transcription/setup.sh` first

## Integration with Source-to-Skill Pipeline

Transcripts created by this skill are perfect input for:
1. **Framework extraction** - Mine transcripts for teachable frameworks
2. **Skill building** - Create Claude skills from expert methodology
3. **Knowledge capture** - Convert video teaching to structured knowledge

Standard output location for copywriting source material:
```
~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/00 Projects/00 Code Setup - Agents - Skills - Workflows/001 Source Material - CopyWriting/[Expert Name]/
```

## Completed Transcriptions

| Course                | Expert        | Videos | Location             |
| --------------------- | ------------- | ------ | -------------------- |
| Escape Hatch          | Chris Hadad   | 31     | `.../Chris Hadad/`   |
| Secret Selling System | Perry Belcher | 25     | `.../Perry Belcher/` |

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "mlx_whisper not found" | Run setup script or `pip3 install mlx-whisper` |
| "ffmpeg not found" | Run setup script or download to ~/bin/ |
| "No such file or directory" | Ensure source path exists and drive is mounted |
| Slow first run | Normal - model is downloading (~3GB) |
| "Not Apple Silicon" | This skill requires M1/M2/M3/M4 Mac |

---

*Skill installed: December 24, 2025*
*Technology: MLX Whisper (whisper-large-v3-turbo) + ffmpeg*
*Setup script: ~/.claude/skills/video-transcription/setup.sh*
