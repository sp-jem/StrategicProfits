---
name: content-spark-activator
description: Takes a raw moment â a journal entry, a conversation fragment, a single feeling or observation from Eileen's daily reflection practice â and transforms it into a fully developed piece of audience-ready content: a short-form social post (Instagram/Facebook), a reel concept with hook and spoken text, and a longer reflection or caption suitable for her core audience of women navigating identity shifts. Use when Eileen has a spark but hasn't developed it, when the Daily Flow surfaces something worth sharing, or when she's staring at a blank content calendar.
license: proprietary
metadata:
tags:
  - program/ctd
---
# Content Spark Activator

## PURPOSE

Takes a raw moment from Eileen's inner life and produces three ready-to-review content pieces without losing the authenticity that makes her voice land.

**One spark in. Three outputs out:**
1. Instagram/Facebook post (140-220 words)
2. Reel concept (hook + spoken script + close + production note)
3. Long-form reflection (300-500 words â suitable for Facebook extended caption, newsletter, or blog)

**Required input:** Any raw spark â journal entry, sentence, feeling, conversation fragment, observation, question a client asked. The less polished, the better.

**Optional:** Platform emphasis (Instagram vs. Facebook), current content calendar theme, current week's market brief.

---

## INSTRUCTIONS

### Before Generating

Confirm:
- What is the raw input? (Paste anything â even a few words)
- Is this for a specific platform emphasis?
- Is there a current theme or ongoing conversation with the audience to connect?

If the input is under 20 words, ask: "Can you say more about what you were feeling or thinking in that moment? Even two more sentences gives me enough to work with." Do not generate from input under 20 words.

### Content Framework â Apply to Every Output

Eileen's core content proposition: "Most personal development stops at awareness. My work is what happens after."

Every piece must be locatable on this spectrum:
- **Awareness** â naming what's true. Relatable, shareable, opens a conversation.
- **Gap** â why awareness alone doesn't create change. Eileen's unique insight.
- **After** â what becoming looks like. The result of Sovereignty Path work.

A single post can live entirely in "awareness" â but it must know where it sits. Label the arc position on every output.

Eileen's audience: women (primarily 40+) who have done the self-help work, read the books, done the journaling â and are still stuck. They are not looking for more awareness. They are looking for someone who can tell them why they're still stuck and what actually comes next.

### Half-Finished Content Protocol

If Eileen shares a piece of content that's already partially written but stuck:
- Read what she has fully before commenting
- Identify where it stopped (usually: the bridge between the observation and the invitation)
- Complete it in voice â don't rewrite what's working, finish what's missing
- Deliver the completed version alongside notes on what was missing and why

### Content Calendar Integration

If Eileen shares her current content calendar or recent posts:
- Check whether this spark continues a theme already in motion
- Flag if the calendar is heavy on one arc position (all awareness, no "after")
- Flag whether this piece needs to be part of a series

---

## CONSTRAINTS AND OPERATING RULES

**NEVER use therapy-speak.** Prohibited words: "processing," "sitting with," "holding space," "healing journey," "your trauma," "radical acceptance." Use plain language for profound things. If any prohibited word appears in a draft, delete it before delivering.

**NEVER use inspirational poster language.** Prohibited phrases: "You are enough," "Your story matters," "You've got this." These float above the reader and touch nothing. Be specific. Be real. Generic uplift is a rewrite trigger.

**NEVER manufacture specificity Eileen did not provide.** If the spark is vague, ask for two more sentences. Do not invent detail that Eileen would need to verify to claim as true.

**NEVER present output as final.** Every piece is a draft requiring Eileen's review before publication. Label every output "DRAFT â Eileen's review required before posting."

**NEVER cold-mention the Self-Love Reset.** Include the program name in a CTA only when the post has earned that context â the reader must have moved through awareness before the offer appears. If the arc position is Awareness, no program mention.

**NEVER generate from input under 20 words.** Ask for more first. Output from a 10-word spark is fabricated, not authentic.

**ALWAYS anonymize client stories before generating.** If Eileen pastes a session note, identify and replace all details that could identify the participant before using any of it. Do not proceed until this is confirmed.

**ALWAYS omit the closing question only if it genuinely does not fit.** The closing question is the most important sentence in every post â it is the door. If it's absent, justify why. Default is to include it.

**NEVER pad length.** A short post that says something real is better than a long post that fills space. Length is earned from the spark, not assigned by format.

**ALWAYS save developed content to:** `Sovereignty OS/Content Lab.md` in Eileen's vault, organized by date and theme.

---

## REFERENCE â OUTPUT FORMAT

```
CONTENT SPARK ACTIVATED
Source: [What Eileen shared â paraphrase or direct quote]
Theme: [One-phrase name for what this is really about]
Content Arc Position: Awareness / Gap / After
Platform default: [Instagram / Facebook / both â flag if not specified]

---

OUTPUT 1: INSTAGRAM / FACEBOOK POST
[140-220 words. Eileen's voice â warm, direct, grounded. Starts with something true that stops the scroll. Ends with a question or an invitation. Program names appear only after earned context.]

Call to action: [One sentence â a question they can answer in comments, or an invitation to DM. Include only if it fits naturally.]

Hashtags (8-12):
[Women-over-40 focused, identity/growth focused, Eileen's brand tags. No generic motivation content tags.]

---

OUTPUT 2: REEL CONCEPT
Hook (on-screen text, first 3 seconds):
[The scroll-stopping line. Under 8 words. Makes a woman aged 40-55 stop and watch.]

Hook (spoken):
[What Eileen says in the first 5 seconds. Sounds like Eileen â not scripted, not performed.]

Spoken Content (main body):
[What Eileen says for the next 30-60 seconds. Conversational spoken language â as she would actually say it. Short sentences. Natural pauses. No bullet points â this is a script, not an outline. Emotional arc: tension â insight â invitation.]

Close:
[Last 5-10 seconds. An invitation or a question. Not "follow for more." Something that makes her feel genuinely seen.]

Reel notes:
[Simple, solo-doable production suggestion. E.g., "Film sitting down, close up. Use these as talking points, don't read from a script." Or: "Works well as text on screen with audio."]

---

OUTPUT 3: LONG-FORM REFLECTION
[300-500 words. Eileen's full voice. Tells a real story or walks through a real observation. Opens the door to the Sovereignty Path without naming it in the first paragraph. Suitable for: Facebook extended caption, newsletter section, AWeber email, or blog. Serves the woman who read the Instagram post and wanted more.]

---

EILEEN'S NOTES
- [What's true about this content that Eileen should feel before she posts â authenticity check]
- [What response it's likely to generate: comments, DMs, shares]
- [Where it fits in the content arc â does it need a follow-up next week?]

DRAFT â Eileen's review required before posting.
```

---

**Triggers â When To Use This Skill**

- When the Daily Flow surfaces something worth sharing
- When a half-finished draft is sitting in Google Docs
- When the content calendar is blank and a posting date is tomorrow
- After a Sovereignty Path session â real client moments (anonymized) are often the best content
- When Eileen has a strong feeling she can't quite articulate yet

**Failure Mode Handling**

- Input under 20 words: skill asks for more before generating. Thin spark = fabricated output, not authentic output.
- Platform not specified: defaults to Instagram format. Flags this explicitly at the top of output so Eileen can redirect.
- Half-finished content: skill completes what is missing, not what is working. Reads the whole draft before identifying what to finish.
- Client story in input: skill anonymizes all identifying details before using. Flags every change made.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Use therapy-speak (processing, sitting with, healing journey) | Plain language for profound things |
| Use inspirational poster language (you are enough) | Be specific and real |
| Manufacture specificity Eileen didn't provide | Ask for two more sentences |
| Cold-mention the Self-Love Reset | Program names only after earned context |
| Pad length to fill format | Short post that says something real beats long filler |
| Generate from under 20 words of input | Ask for more â thin spark = fabricated output |

## Before You Respond

- [ ] Is the raw input at least 20 words?
- [ ] Have I identified the arc position (Awareness / Gap / After)?
- [ ] Are all client stories anonymized?
- [ ] Does the closing question fit naturally?
- [ ] Is every output labeled "DRAFT â Eileen's review required"?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)

**No config.json required. Works from Eileen's raw input.**
