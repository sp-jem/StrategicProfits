---
name: ghl-campaign-builder
description: Design, populate, and launch a complete GoHighLevel campaign â including audience targeting, email templates, SMS messages, and workflow triggers. Trigger when someone says "build a campaign," "launch a campaign," "create an email campaign," "set up SMS outreach," "I want to run a campaign," "build an email sequence," "campaign setup," "trigger a workflow," "create a drip," "add contacts to a campaign," or any request to build and activate marketing outreach in GHL.
license: proprietary
metadata:
tags:
  - program/ctd
  - ghl
  - campaign
---
# GHL Campaign Builder

## Purpose

Design and launch complete GoHighLevel campaigns from a plain-English brief â including audience definition, email template creation, SMS drafting, campaign structure setup, and workflow triggering â without requiring the operator to navigate GHL manually. Produces a campaign blueprint for review before any sends are executed.

## Instructions

### Step 1 â Collect Campaign Brief

Extract from the operator's request:

| Field | Required? | Source |
|-------|-----------|--------|
| Campaign name | Yes | Operator |
| Campaign goal | Yes | Operator |
| Target audience | Yes | Operator (tags, segment, or criteria) |
| Message channels | Yes | Email / SMS / Both |
| Send timing | Yes | Immediate / Scheduled / Drip |
| Email subject(s) | If email | Operator or generate from goal |
| SMS message(s) | If SMS | Operator or generate from goal |
| Workflow to trigger | If workflow | Operator |
| Brand voice/tone | No | Operator (default: professional, direct) |

If required fields are missing, list them and ask once. Do not proceed until all required fields are provided.

### Step 2 â Define Audience

Call `search_contacts` using the tag(s), segment, or criteria the operator specified.

Display audience summary:

```
AUDIENCE SUMMARY
----------------
Search criteria: [tags / filters used]
Contacts found: [N]
Sample (first 5):
  1. [Name] â [email] â [tags]
  2. [Name] â [email] â [tags]
  ...
```

If the audience is larger than 500 contacts, flag: "Large audience detected ([N] contacts). Confirm this is the intended scope before proceeding."

If zero contacts are found: "No contacts match the criteria '[filter].' Adjust the audience definition before building the campaign."

### Step 3 â Build Email Template(s)

If the campaign includes email, call `create_email_template` for each email in the sequence.

Before creating, show the proposed template for review:

```
EMAIL TEMPLATE: [name]
Subject: [subject line]
Preview text: [preview]
Body:
---
[full email body]
---
```

Wait for operator approval or edits. After approval, call `create_email_template` and log the returned template ID.

Log after creation:
```
Email template created: [template name]
Template ID: [id]
```

### Step 4 â Draft SMS Message(s)

If the campaign includes SMS, produce the message copy before any send.

SMS rules (enforce strictly):
- 160 characters max for a single SMS segment
- No special characters that inflate character count (curly quotes, em dashes)
- Must include opt-out language if required by operator's compliance standards
- NEVER include a bare long URL â request a short URL from the operator

Display each SMS draft:

```
SMS DRAFT [#]:
--------------
Message: [full text]
Character count: [N] / 160
Opt-out: [Included / Not included â flag if missing]
```

### Step 5 â Create and Configure Campaign

Call `create_campaign` with the campaign name and configuration.

Then call `ghl_trigger_workflow` if a workflow is linked to the campaign.

Log all tool calls:

```
Tool called: create_campaign
Campaign name: [name]
Result: Campaign ID [id] created

Tool called: ghl_trigger_workflow
Workflow: [name / id]
Triggered for: [N] contacts
```

### Step 6 â Display Full Campaign Blueprint

Before any sends, present the complete campaign plan:

```
CAMPAIGN BLUEPRINT: [Campaign Name]
=====================================
Goal:           [goal]
Audience:       [N] contacts â [criteria]
Channels:       [Email / SMS / Both]
Timing:         [Immediate / Scheduled: date+time / Drip: interval]

EMAIL SEQUENCE:
  [1] "[Subject]" â Template ID: [id]
  [2] "[Subject]" â Template ID: [id]

SMS SEQUENCE:
  [1] "[Message preview...]" â [N] chars
  [2] "[Message preview...]" â [N] chars

WORKFLOW TRIGGER:
  [Workflow name] â triggers on: [event]

SEND TO:
  [N] contacts
  Sample: [Name], [Name], [Name]...

---
CONFIRM TO LAUNCH? (yes / no)
```

Do NOT proceed past this block until the operator explicitly confirms.

### Step 7 â Launch

After confirmation:

1. If immediate send â call `send_email` and/or `send_sms` for the defined audience
2. If tags should be applied before send â call `add_contact_tags` first
3. If workflow â call `ghl_trigger_workflow` with contact IDs
4. If campaign start â call `start_campaign`

Log every action:

```
[Action]: [Result]
  - send_email â [N] sent, [N] failed
  - send_sms â [N] sent, [N] failed
  - add_contact_tags â tags applied to [N] contacts
  - start_campaign â Campaign [name] active
```

### Step 8 â Launch Confirmation Report

```
CAMPAIGN LAUNCHED: [Campaign Name]
===================================
Status:         Active
Sent to:        [N] contacts
Email sends:    [N] / [N] succeeded
SMS sends:      [N] / [N] succeeded
Campaign ID:    [id]
Launched at:    [timestamp]

Failed sends: [N] â review in GHL > Conversations for delivery errors
```

## Constraints

- NEVER send email or SMS without displaying the full campaign blueprint (Step 6) and receiving explicit operator confirmation.
- NEVER assume an audience â always verify through `search_contacts` and display the contact count before proceeding.
- NEVER create email templates without showing the full body copy first. Templates written blind cannot be verified before they reach contacts.
- ALWAYS log every MCP tool call by name, with the key parameters passed and the result returned.
- NEVER trigger `start_campaign` and `ghl_trigger_workflow` simultaneously without the operator confirming which mechanism controls the send â using both can cause duplicate sends.
- ALWAYS enforce the 160-character SMS limit. If the draft exceeds it, rewrite to fit before presenting for review â do not simply warn.
- NEVER include bare long URLs in SMS messages. Flag and ask the operator to provide a shortened link.
- ALWAYS include a "Failed sends" count in the launch report â do not report "campaign launched" without accounting for delivery failures.
- NEVER proceed if the audience search returns zero contacts. The campaign cannot launch to an empty list.
- ALWAYS preserve the exact approved copy when creating templates and drafting sends. Do not silently rewrite after operator approval.
- NEVER fabricate contact lists. Audience must be defined through `search_contacts` with real tags, filters, or criteria â not assumed.
- NEVER trigger a workflow or start a campaign without displaying the full campaign brief and receiving confirmation.
- NEVER proceed if required campaign fields (goal, audience, channel) are absent. List the missing fields and wait.

## Reference

**MCP Tools Used:**
- `create_campaign` â Create the campaign structure in GHL
- `start_campaign` â Activate a created campaign
- `create_email_template` â Write and save an email template
- `search_contacts` â Pull and define the target audience
- `add_contact_tags` â Tag contacts for segmentation or campaign enrollment
- `send_sms` â Send an SMS message to a contact
- `send_email` â Send an email to a contact (using a template or inline)
- `ghl_trigger_workflow` â Trigger a GHL workflow for a specific contact

**Configuration Requirements:**
- GHL MCP server (BusyBee3333) must be connected and authenticated
- GHL Location ID must be configured in the MCP server
- Operator must have campaign create/send permissions in GHL
- SMS sending requires a GHL phone number provisioned for the location

**Failure Modes:**

MCP not connected: State: "GHL MCP server is not responding. No campaign can be built or launched until the connection is restored."

`create_campaign` fails: State the exact error. Do not attempt to send email or SMS directly as a workaround without informing the operator. The campaign structure must exist before sends proceed.

`send_email` / `send_sms` returns failures: List the failed contact IDs and reason. Do not mark the campaign as fully launched if any sends failed. Include failure count in the report.

Workflow ID not found (`ghl_trigger_workflow` error): State: "Workflow '[name]' was not found. Call `ghl_list_workflows` to retrieve available workflow IDs. Do not trigger an unknown workflow."

Audience larger than expected: Do not abort. Flag the count, show the sample, require explicit confirmation before launch.

Zero contacts in audience: Halt. Do not create templates or a campaign structure for an empty audience. "No contacts match the audience criteria. Redefine the audience before building this campaign."

**Output Format:**

Every campaign build produces, in order:
1. **Campaign Brief Confirmation** â extracted fields, flagged gaps
2. **Audience Summary** â contact count, criteria, 5-contact sample
3. **Email Template Drafts** â full body, subject, preview text (pre-creation)
4. **SMS Drafts** â full message, character count
5. **Campaign Blueprint** â complete structured summary with confirmation gate
6. **Tool Call Log** â every MCP call made during build
7. **Launch Confirmation Report** â final send counts, campaign ID, timestamp
