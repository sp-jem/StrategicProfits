# Offer Factory: Product Decomposer

---
name: offer-factory-decomposer
description: "Use when building the asset-level knowledge base for the Offer Factory system â inventorying what's inside a product for recombination and repackaging."
---

## Purpose

The Offer Factory can only generate ideas as good as its knowledge of what's INSIDE each product. This skill produces exhaustive component inventories â not marketing descriptions, but granular asset maps that show every piece that could be extracted, recombined, repackaged, or repurposed.

## Invocation

```
/offer-factory-decomposer [product name or path to product docs]
```

**Examples:**
```
/offer-factory-decomposer ZenithPro
/offer-factory-decomposer SOW
/offer-factory-decomposer Review all 9 products
```

---

## Input Requirements

**Required:**
- Product name

**Helpful (will produce richer output):**
- Product registry data (`~/.claude/skills/product-registry/references/products/`)
- Sales pages, webinar scripts, or offer descriptions
- Course outlines, lesson plans, module structures
- Customer testimonials or case studies
- Pricing and packaging details
- Community/support structure details

**If product info is sparse:** State what's known, flag what's missing, and produce the best inventory possible with clear `[NEEDS VERIFICATION]` tags on uncertain items.

---

## Execution Process

### Phase 1: Gather Everything Known

Read all available sources for this product:
1. Product registry (`~/.claude/skills/product-registry/references/products/[product]/`)
2. Vault search for product mentions (`Strategic-Profits/`, `Active-Brain/00 Projects/`)
3. Any sales pages, landing pages, or marketing materials in the vault
4. Zoom call transcripts that discuss the product (`Active-Brain/00 Zoom Reports/`)
5. Any provided files or descriptions

### Phase 2: Decompose Into 8 Asset Categories

For EACH category, list every discrete component. Be exhaustive â the value is in granularity.

#### 1. Content Assets
Individual pieces of teachable content that could theoretically stand alone.

For each:
- **Name** â What is it called?
- **Format** â Video lesson, PDF, template, worksheet, slide deck, audio, transcript
- **Topic** â What specific thing does it teach/cover?
- **Duration/Size** â How substantial is it?
- **Dependencies** â Does it require other content to make sense?
- **Standalone Score** (1-5) â Could this be extracted and sold/given independently?

#### 2. Framework & IP Assets
Named frameworks, proprietary methodologies, coined terms, unique models.

For each:
- **Name** â Exact name (including trademark designations)
- **Type** â Framework, model, system, methodology, diagnostic, protocol
- **What It Does** â One sentence on the transformation it produces
- **Complexity** â Simple (teachable in 5 min) / Medium (needs 30 min) / Deep (needs hours)
- **Novelty** â Is this unique to Rich, or a variation on something common?
- **Licensing Potential** (1-5) â Could others use this in their own programs?

#### 3. Prompt & Tool Assets
AI prompts, calculators, diagnostics, generators, templates that DO something.

For each:
- **Name** â What it's called
- **Function** â What it produces
- **Input Required** â What the user needs to provide
- **Output Quality** â How good is the output without human refinement?
- **Standalone Score** (1-5) â Could this be sold/given as a standalone tool?

#### 4. Relationship & Access Assets
Access to people, networks, experts, communities that come with the product.

For each:
- **What** â Describe the access
- **Who** â Who specifically (Rich, team members, guest experts, peer community)
- **Frequency** â How often (weekly calls, monthly, on-demand)
- **Exclusivity** â Is this access available elsewhere?
- **Value Driver** â Is this a primary reason people buy, or a bonus?

#### 5. Community Assets
Group elements, peer interactions, shared experiences.

For each:
- **Platform** â Where does it happen (Slack, Skool, Zoom, etc.)
- **Size** â Approximate member count
- **Activity Level** â Daily active, weekly, sporadic
- **Culture** â What's the vibe, norms, unwritten rules
- **Network Value** â Who's IN this community that makes it valuable?

#### 6. Audience & Data Assets
The audience itself, email lists, customer segments, behavioral data.

- **List size** by segment
- **Engagement metrics** if known
- **Buyer history** â What have these people already bought?
- **Psychographic profile** â What do they care about, fear, aspire to?
- **Reachability** â How easily can you communicate with them?

#### 7. Fulfillment & Delivery Assets
The infrastructure that delivers the product.

For each:
- **Mechanism** â How is it delivered?
- **Platform** â What tech stack?
- **Automation Level** â Fully automated, semi-automated, manual
- **Marginal Cost** â What does one more customer cost?
- **Scalability** â Can this handle 10x volume?

#### 8. Brand & Positioning Assets
Intangible assets that affect how the product is perceived.

- **Market Position** â Where does this sit in the competitive landscape?
- **Key Differentiators** â What makes this genuinely different?
- **Social Proof** â Testimonials, case studies, results, celebrity endorsements
- **Authority Signals** â Who endorses, recommends, or uses this?
- **Brand Associations** â What feelings/concepts does the product name evoke?

### Phase 3: Tag Every Component

After cataloging, go back and tag each component:

| Tag | Question |
|-----|----------|
| **Standalone** (1-5) | Could this be extracted and offered independently? |
| **Repackage** (1-5) | How easily could this be repackaged into a different format/context? |
| **Underleveraged** | Is this asset being used to its full potential? Flag if not. |
| **Pairs-With** | List specific components from OTHER products that would combine well |
| **Unique** | Is this asset unique to this product, or shared/overlapping with others? |

### Phase 4: Write the Component Inventory

Produce a single document per product with ALL components organized by category, fully tagged.

---

## Output

### File Location
```
Active-Brain/00 Projects/01 Behavioral Intelligence/Offer Factory/Product Components/[Product Name] - Component Inventory.md
```

### Document Structure

```markdown
# [Product Name] â Component Inventory
**Decomposed:** [Date]
**Sources:** [List what was read]
**Completeness:** [Percentage estimate â what's well-documented vs gaps]

## Summary Stats
- Content Assets: [count]
- Framework/IP Assets: [count]
- Prompt/Tool Assets: [count]
- Relationship Assets: [count]
- Community Assets: [count]
- Audience/Data Assets: [count]
- Fulfillment Assets: [count]
- Brand/Positioning Assets: [count]
- **Total Components:** [count]
- **Underleveraged Flags:** [count]
- **High Standalone Potential (4-5):** [count]

## 1. Content Assets
[Full inventory with all fields and tags]

## 2. Framework & IP Assets
[Full inventory with all fields and tags]

[...etc for all 8 categories...]

## Cross-Product Pairing Opportunities
[List every "Pairs-With" tag, grouped by the other product]

## Known Gaps
[What couldn't be determined from available sources]
[What needs verification from Rich]
```

---

## When Decomposing Multiple Products

Run Phase 1-4 for each product independently. After all products are decomposed, the Cross-Product Synthesizer skill (`/offer-factory-synthesizer`) reads all inventories and maps connections.

**Recommended order:** Start with the products that have the most available documentation (ZenithPro, SOW), then work outward. Products with less documentation will produce sparser inventories with more `[NEEDS VERIFICATION]` tags â that's expected and useful because it surfaces what Rich needs to document.

---

## Quality Standard

A good decomposition makes someone say "I didn't realize how much was in there." The value is in surfacing components that are invisible when you think about the product as a whole. Every named framework, every guest expert appearance, every template, every community channel â it all gets cataloged.

A bad decomposition reads like a marketing description. "ZenithPro teaches demand creation" is useless. "ZenithPro Lesson 1 teaches the D3 Demand Creation System which includes the 7 Belief Categories Taxonomy, the Belief Gap Analysis Framework, and the Ultimate Avatar Excavation System v2 prompt â each of which could be extracted as standalone tools" is what the Offer Factory needs.
