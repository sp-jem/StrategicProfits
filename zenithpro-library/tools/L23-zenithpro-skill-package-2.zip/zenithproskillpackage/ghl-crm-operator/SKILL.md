---
name: ghl-crm-operator
description: Execute any CRM operation in plain English â create, find, update, tag, segment, or deduplicate contacts in GoHighLevel. Trigger when someone says "add a contact," "find a lead," "update their info," "tag everyone who attended," "search for contacts," "merge duplicates," "segment my list," "create a contact," "look up someone in GHL," "update the CRM," "add tags," "remove tags," or any contact management request against GoHighLevel.
license: proprietary
metadata:
tags:
  - program/ctd
  - ghl
  - crm
---
# GHL CRM Operator

## Purpose

Execute any contact management operation in GoHighLevel through plain-English instructions â search, create, update, tag, segment, deduplicate â without requiring the operator to know GHL's tool names or parameter structure. Translates business intent into precise MCP tool calls and returns structured, readable results.

## Instructions

### Step 1 â Classify the Operation

Read the operator's request and classify into one of these operation types:

| Operation Type | Trigger Words | Primary Tool |
|----------------|--------------|--------------|
| **Search** | find, look up, search, who is, show me | `search_contacts` |
| **Create** | add, create, new contact | `create_contact` |
| **Read** | get info, show details, full record | `get_contact` |
| **Update** | change, update, edit, set | `update_contact` |
| **Tag â Add** | tag, add tag, label | `add_contact_tags` |
| **Tag â Remove** | untag, remove tag, strip label | `remove_contact_tags` |
| **Upsert** | create or update, sync, import | `upsert_contact` |
| **Deduplicate** | duplicates, merge, find dupes | `get_duplicate_contact` |

State the classified operation type before executing.

### Step 2 â Gather Required Fields

**For `search_contacts`:** Extract the search query (name, email, phone, or keyword). If no query is provided, ask for one â do not run a blank search.

**For `create_contact`:** Required: first name OR email. Collect from the request: first_name, last_name, email, phone, tags, custom fields. Flag any missing required fields before calling the tool.

**For `update_contact`:** Required: contact ID (get via search first if not provided). Then collect the fields to update. Show the before-state from `get_contact`, then the planned changes, then confirm before writing.

**For `add_contact_tags` / `remove_contact_tags`:** Required: contact ID and tag name(s). Confirm the tag list before applying.

**For `upsert_contact`:** Preferred deduplication key: email. If email is absent, use phone. Confirm the match key before upserting.

**For `get_duplicate_contact`:** Required: contact ID of the record to check against. Show all duplicates found before any action.

### Step 3 â Execute Tool Call

Call the appropriate MCP tool with the extracted parameters. Do not fabricate parameters not provided by the operator.

REQUIRED: Log each tool call made in the output:

```
Tool called: search_contacts
Query: "Sarah Johnson"
Result: [N] contacts returned
```

### Step 4 â Display Results

**For search results**, use this table format:

| ID | Name | Email | Phone | Tags | Last Updated |
|----|------|-------|-------|------|-------------|
| [id] | [name] | [email] | [phone] | [tags] | [date] |

Show a maximum of 20 results. If more exist, say: "Showing first 20 of [N] results. Narrow your search for better targeting."

**For create/update confirmations:**

```
Contact [Created / Updated]: [Name]
Contact ID: [id]
Fields set: [list of fields written]
Tags applied: [list, or "none"]
```

**For tag operations:**

```
Tags [Added / Removed]: [tag list]
Applied to: [contact name] (ID: [id])
```

**For deduplication results**, use this format:

| Duplicate ID | Name | Email | Phone | Created Date |
|-------------|------|-------|-------|-------------|
| [id] | [name] | [email] | [phone] | [date] |

Flag: "Manual review required before merging. GHL does not auto-merge â you must decide which record to keep."

### Step 5 â Confirm Write Operations

Before executing any create, update, tag, or upsert: display a confirmation block and wait for approval.

```
PLANNED ACTION: [operation type]
Contact: [name or ID]
Changes:
  - [field]: [old value] â [new value]
  - Tags to add: [list]
  - Tags to remove: [list]

Confirm? (yes / no)
```

NEVER proceed past this block until the operator responds "yes," "confirm," or equivalent. A non-response is not a confirmation.

## Constraints

- NEVER execute write operations (create, update, tag, delete) without first displaying the planned action and receiving explicit confirmation. Read-only operations (search, get) may proceed immediately.
- NEVER fabricate contact IDs, email addresses, phone numbers, or tag names. Use only data returned by MCP tools or explicitly provided by the operator.
- NEVER run `delete_contact` unless the operator has explicitly said "delete" and confirmed a second time stating the contact name. Deletion is irreversible.
- NEVER run `delete_contact` on the first request. A second explicit confirmation naming the contact is mandatory before deletion proceeds.
- ALWAYS run `search_contacts` before `get_contact` or any update when the contact ID is not already in hand.
- ALWAYS show the current contact record from `get_contact` before applying updates â never update blind.
- NEVER apply tags in bulk to a list unless the operator has confirmed which contacts are in scope. Always show the count and sample before bulk-tagging.
- ALWAYS display tool call logs (Step 3) in the output â the operator must be able to audit exactly what was called.
- NEVER assume a unique contact from a partial name. If `search_contacts` returns more than one match, list all matches and ask the operator to confirm which one.
- ALWAYS flag when a field being updated will overwrite an existing non-empty value. Show the old value so the operator can decide.
- NEVER run operations on contacts outside the confirmed GHL location/subaccount. If multiple locations are present, confirm which one before proceeding.
- NEVER proceed if the GHL Location ID is not configured in the MCP server. State: "GHL Location ID is not set. Configure it in the BusyBee3333 MCP server before executing any contact operations."
- NEVER create a misspelled tag. If a tag name cannot be confirmed against existing tags, state the concern before applying.

## Reference

**MCP Tools Used:**
- `create_contact` â Create a new contact record
- `search_contacts` â Search contacts by name, email, phone, or keyword
- `get_contact` â Retrieve full contact record by ID
- `update_contact` â Update fields on an existing contact
- `add_contact_tags` â Apply one or more tags to a contact
- `remove_contact_tags` â Remove one or more tags from a contact
- `upsert_contact` â Create or update contact, deduplicating by email or phone
- `get_duplicate_contact` â Find duplicate contacts for a given contact ID

**Configuration Requirements:**
- GHL MCP server (BusyBee3333) must be connected and authenticated
- GHL Location ID must be configured in the MCP server
- Operator must have contact read/write permissions in GHL

**Failure Modes:**

MCP not connected: State: "GHL MCP server is not responding. Verify the BusyBee3333 MCP server is running and the API key is valid. No CRM operations can be executed until connection is restored."

Search returns zero results: State: "No contacts found matching [query]. Possible causes: spelling variation, contact lives in a different location/subaccount, or contact does not yet exist. Want me to try an alternate search term or create a new contact?"

Contact ID not found on get/update: State: "Contact ID [id] was not found. It may have been deleted or belong to a different location. Run a search to locate the correct record."

Ambiguous contact match (multiple results for same name): Do NOT pick one. List all matches in the results table and ask: "Which of these contacts did you mean?"

Bulk operation on large list (>50 contacts): State the count, show a sample of 5 records, and require explicit confirmation before proceeding: "This will tag [N] contacts. Confirm to proceed."

Tag not found / typo in tag name: Do not create a misspelled tag. State: "Tag '[name]' was not applied â verify the tag name is correct in GHL. Existing tags on this contact: [list]."

**Output Format:**

All outputs use structured tables and labeled sections. No free-form prose in results. Every output includes:

1. **Operation Classification** â what type of action was taken
2. **Tool Call Log** â exactly which MCP tools were called and with what query
3. **Results Table or Confirmation Block** â structured display of what was found or changed
4. **Next Action Prompt** â suggested follow-on operation if relevant (e.g., "Want to tag these results?" or "Want to create a task for this contact?")
