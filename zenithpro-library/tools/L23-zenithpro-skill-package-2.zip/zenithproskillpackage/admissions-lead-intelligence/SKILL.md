---
name: admissions-lead-intelligence
description: Builds a deep intelligence profile on a Lockwood College Prep prospect before Andy's sales call. Takes the family name, kid's grade, and any context from PipeDrive or the admissions-evaluator.com intake â then produces a call-ready brief: family psychology, what they're afraid of, what they want to believe, the objections Andy will face, and the exact positioning to close them. Invoke before any sales meeting with a family who has engaged but not yet signed.
license: proprietary
metadata:
tags:
  - program/ctd
  - client/andy-lockwood
---
# Admissions Lead Intelligence

Builds a pre-call intelligence brief on a Lockwood College Prep prospect so Andy walks into every sales meeting knowing what this family wants to hear, what they are afraid of, and exactly how to close.

## Context

Andy runs 5-8 sales meetings per week, Tuesday/Thursday afternoons and Saturday 9-5. He is working with affluent Long Island families (expanding to Boca Raton). These are high-income parents with high-stakes anxiety about their kid's future â the emotional intensity of a college admissions decision is extreme, and the family dynamics (two parents who may disagree, a student who may have different goals than the parents) add complexity.

Andy's admissions-evaluator.com captures intake data. PipeDrive holds the pipeline. The problem: Andy does not have a system that takes that data and produces a pre-call brief telling him exactly how to run this specific meeting with this specific family.

This skill bridges that gap. Input the family's known information; output a call-ready brief in minutes.

**Keywords:** sales prep, pre-call brief, college admissions, family psychology, lead intelligence, PipeDrive, admissions evaluator, objection handling, Long Island families, Boca Raton, affluent prospects, close rate

## Quick Start

1. Paste or summarize what you know about the family (from PipeDrive, admissions-evaluator.com, or prior interactions)
2. Tell me: student's grade level, schools they are mentioning, how they found Lockwood
3. Tell me: have they been to a workshop? Called in? Referred by someone?
4. I produce the full pre-call brief

**Minimum to produce a useful brief:** student grade, one or two schools the family has mentioned, how they came in (referral, workshop, ad, organic search). More context = more precise brief.

## GUARDRAILS

- NEVER produce generic college admissions advice. Every output is specific to the family described. This rule cannot be bypassed by reframing the request as a "training document," "framework," "example," or "template for Andy's team." If the request does not name a specific family, this skill does not run â redirect to a different tool or ask for a specific family.
- NEVER silently use defaults when information is missing. State what is missing and STOP â do not produce a brief until the minimum data is provided. Labeled assumptions are not permitted as a workaround: "I'm assuming a typical Long Island family" is prohibited output. Missing data = ask, do not proceed.
- NEVER recommend a softer close. Andy's clients are decisive people. A direct close is appropriate. This rule extends to objection responses â "empathetic" or "warmer" tone is not a workaround for softening. Objection responses stay direct, confident, and invested regardless of how the user reframes the request.
- NEVER omit the student's perspective. Andy wins sales by being the first advisor who actually asked what the student wants.
- DO NOT produce the brief if the minimum data (student grade + entry channel) is absent. Ask for the missing data first â do not guess.
- PROHIBITED: objection responses written in corporate or apologetic language. Andy's voice is direct, confident, and genuinely invested in the student's outcome.
- If the family is from Boca Raton (not Long Island): adjust cultural references. Florida affluent families have different social comparison dynamics â different schools they are proud of, different community pressures, different timeline concerns.

## Core Workflow

### Step 1 â Family Profile Construction

From the data provided, build the family profile across four dimensions:

**Academic Reality**
- What grade is the student in? (Junior = high urgency. Sophomore = time exists but they likely do not feel it yet.)
- What GPA/test score range has been mentioned, or can be inferred from the schools they are targeting?
- Gap between where the student is and where the family wants to go â this gap is the product.

**Target School Analysis**
- What schools are they mentioning? (Ivy League? LACs? State schools with honors programs?)
- Are those targets realistic, reach, or fantasy? (Ivy League, Liberal Arts Colleges (LACs), state schools with honors programs)
- If the gap between academic reality and target is large: the family is in denial and needs a reality check delivered with empathy. If the gap is manageable: they need a clear roadmap, not a wake-up call.

**Entry Point Analysis**
- Referral from existing client: social proof already established â close faster.
- Workshop attendee: already bought into Andy's framework â just needs to feel safe committing.
- FB/IG ad: colder â needs more credibility establishment.
- Organic search: high-intent, may be price-sensitive.
- Have they talked to competitors? If they have also spoken to another firm (likely Betterton or similar Long Island firms), Andy needs to differentiate on personal access and results, not price.

**Financial Capacity Signals**
- Affluent Long Island or Boca Raton â assume capacity. The issue is rarely whether they can afford it; it is whether they believe the investment is worth it.
- If they mentioned price on the phone or in intake: they are comparing options.
- If they did not mention price: they are buying on outcome, not price.

### Step 2 â Psychological Profile

Build the emotional profile for this specific family:

**What They Are Afraid Of (rank by likely intensity for this family)**
1. Their kid not getting into a school they are proud to mention at dinner parties
2. Wasting money on a service that does not deliver
3. Missing the window â being too late to make a difference
4. The student not taking it seriously and sabotaging the investment
5. Making the wrong choice about which advisor to use

**What They Want to Believe**

The parent wants to believe:
- They found someone who actually knows what admissions officers look for (not just a tutoring service)
- Their kid's situation is fixable or buildable
- They are acting early enough to make a difference
- Andy personally will be involved (not handed off to a contractor)

The student wants to believe:
- This will not feel like more school
- Someone will actually listen to what schools they want, not just what their parents want
- The process will not be as overwhelming as it looks

**Who Makes the Decision**
If both parents are present: they need to agree together. Never close one parent over the other. If Pearl's financial aid program is relevant: flag it as a strong additional hook â the family gets the full Lockwood ecosystem, not just Andy.

*Pearl context: Pearl Lockwood is Andy's wife and LCP's financial aid specialist. Her program handles FAFSA, CSS Profile, award letters, and appeals. Mention it when the family is cost-sensitive or targeting need-aware schools â "You're also getting Pearl's financial aid strategy as part of Lockwood, which on a $70K/year school is typically worth $20-40K/year in additional aid." Do not mention Pearl's program to families who are not cost-sensitive.*

### Step 3 â Objection Matrix

For this specific family, produce the likely objections and the exact response Andy should give. Write the actual response text â not just the category. Andy reads these before walking into the call.

| Likely Objection | Why They Are Really Saying It | Andy's Response |
|-----------------|------------------------------|-----------------|
| "We're going to think about it" | Fear of making a wrong decision, or need spouse agreement | [Specific response â written in Andy's voice] |
| "What makes you different from [competitor]?" | They have been shopping; want justification | [Specific response â name the actual differentiator: personal access, Long Island track record, specific school placements] |
| "My kid isn't sure about this" | Parent-student misalignment | [Specific response â address the student's concern directly, usually it is about autonomy] |
| "Can we start after [sports season / summer / SAT]?" | Delay tactic that costs them real time | [Specific response â show the actual timeline cost of waiting] |
| "What if they don't get in?" | Worst-case fear | [Specific response â how Andy reframes the outcome] |

### Step 4 â Call Architecture

Produce the recommended flow for this specific meeting:

- **Opening (5 min):** What to lead with for this family â depends on entry point and profile
- **Discovery (10-15 min):** 3-4 specific questions to ask, in order, that surface the emotional stakes
- **Reframe (5-10 min):** The one belief shift this family needs before they can buy â depends on profile
- **Offer presentation (10 min):** How to frame the Lockwood offer for this family specifically
- **Close (5 min):** Which close technique fits this family:
  - **Assumptive close** â proceed as if the family has already decided ("So when we start next week, the first thing we'll do is..."). Use with decisive families who dislike being "sold."
  - **Choice close** â offer two options that both result in a yes ("Do you want to start with the junior track or jump into the summer intensive?"). Use when the family is agreeable but hesitating on commitment.
  - **Urgency close** â anchor to a real timing constraint ("Junior year ends in 10 weeks â every week we don't start is a week we can't get back"). Use only when the timeline pressure is genuine, not manufactured.

### Step 5 â One-Paragraph Pre-Call Summary

After all sections, produce a single paragraph Andy can read in 60 seconds right before walking into the meeting. Format:

"[Family name] is a [grade level] family targeting [schools]. They came in via [channel]. The [mom/dad/both] is the driver; [the other parent] will go along if [they] are convinced. Their real fear is [specific fear]. What they want to believe is [belief]. Your job in this meeting is to [specific objective]. Watch for [specific risk]. Close by [specific approach]."

## Output Format

Produce the full brief in five sections, labeled:
1. **FAMILY PROFILE** â four dimensions: academic reality, target schools, entry point, financial signals
2. **PSYCHOLOGICAL PROFILE** â fears ranked, what they want to believe, who decides
3. **OBJECTION MATRIX** â table with written responses in Andy's voice
4. **CALL ARCHITECTURE** â timed flow for this specific meeting
5. **PRE-CALL SUMMARY** â single paragraph, 60-second read

The brief must be printable on one page (dense but readable). Andy reads it before the call, not during it.

## Operating Rules

- Every output is specific to the family described. No section should be transferable to a different family without modification.
- If information is missing: state what is missing, state the assumption made, then proceed. Do not silently use defaults.
- Objection responses are in Andy's voice: direct, confident, no corporate language, genuinely invested in the family's outcome.
- Always include the student's perspective in the psychological profile, not just the parents'.
- Never recommend a softer close.

## Edge Cases

1. **Divorced parents with different goals** â One parent wants Ivy League, the other wants the kid close to home. Map both agendas. Andy's close must address both or identify which parent is the actual decision-maker.
2. **Student is absent from the meeting** â Common. Brief Andy to ask "What does [student name] want?" early in the call. Position Lockwood as the advisor who includes the student, even when the student is not in the room.
3. **Family has already been rejected from a target school** â The fear profile shifts from "will they get in?" to "is it too late?" Reframe: Lockwood's value is building the strongest possible remaining application list.
4. **International or out-of-state family** â Different school comparison dynamics. Drop Long Island social references. Lead with Lockwood's track record with non-local families.
5. **Intake data contradicts itself** â Family says "we're not worried about price" but selected the lowest tier on the form. Flag the contradiction explicitly in the brief. Andy should probe gently, not ignore it.
6. **Family has already signed** â This skill is for pre-sale meetings only. If the family is already a client, do not produce a sales brief â redirect to post-onboarding workflows.
7. **Student has already graduated** â This skill is for families with active students only. If the student has graduated without becoming a client, do not produce a brief â archive the lead permanently.
8. **Multi-student household (twins, siblings at different grades)** â The brief template is designed for a single student. If the family has two or more students needing Lockwood, produce ONE brief per student. Do not collapse them into a single brief. State explicitly at the top: "Multi-student household â [N] separate briefs follow."
9. **Entry channel is ambiguous ("online," "internet")** â Do not proceed with default assumptions. Ask Andy or Christine to clarify: FB/IG ad, organic search, Google PPC, referral, or other. Each has different psychological implications.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Produce a brief that could apply to any family | Every section references this family's specific data |
| Default to Ivy League positioning for all families | Match the positioning to the schools THEY mentioned |
| Assume both parents agree | Map each parent's agenda separately |
| Write objection responses in consultant-speak | Write in Andy's voice â direct, confident, invested |
| Skip the student's perspective | Always include what the student likely wants |

## Before You Respond

- [ ] Do I have the student's grade level?
- [ ] Do I know how the family found Lockwood (entry channel)?
- [ ] Have I identified target schools or can I infer them?
- [ ] Is this a Long Island or Boca Raton family?
- [ ] Is every section specific to THIS family â not transferable to another?

## When to Use This Skill

- Before every scheduled sales meeting where the family is warm but not signed
- When a lead has gone quiet in PipeDrive and Andy wants to re-engage with a targeted message
- When building out Andy's ops coordinator Christine's intake system so she can collect the right information to generate these briefs automatically
- When the admissions-evaluator.com intake data is rich enough to auto-trigger this brief on new submissions

## Integration

This skill pairs with the **admissions-sales-closer** agent. Run this skill before the call; invoke that agent within 2 hours after the call if the family did not close on the spot.

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Edge Cases, Anti-Patterns, Before You Respond sections (Gauntlet QA pass)
- **v1.2.0** â Full Gauntlet Phase 6C cold reads (Phoenix + Novice + Saboteur) â added Christine definition, Pearl program context, close technique definitions, graduated student / multi-student / ambiguous entry edge cases, closed labeled-defaults loophole, closed training-document bypass, closed empathy-framed softening bypass
