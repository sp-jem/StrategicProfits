# Offer Factory: Offer Architect

---
name: offer-factory-architect
description: "Use when you've selected a winning concept and need the full implementable offer blueprint â pricing, delivery, positioning, guarantee, and launch plan."
---

## Purpose

The Deepener validates feasibility and generates variations. The Architect turns the winning concept into a complete, implementable offer blueprint â every detail specified so that copywriters can write to it, tech can build it, and operations can deliver it.

## Invocation

```
/offer-factory-architect [concept name or Deepener file]
```

**Examples:**
```
/offer-factory-architect "The AI Skills Marketplace" from Deepener output
/offer-factory-architect [paste concept description]
```

---

## Input Requirements

**Required:**
- One offer concept (ideally from Deepener output with feasibility data)

**Strongly recommended:**
- Product Component Inventory for source product(s)
- Existing Offer Autopsies (to ensure differentiation)
- Cross-Product Synthesis (for component sourcing)

---

## Blueprint Sections

### 1. Offer Identity

- **Name:** Working name for the offer
- **One-Line Description:** What it is in one sentence
- **Buyer's Sentence:** How the ideal buyer describes it to a peer
- **Category:** What mental category the buyer files it under
- **Position Statement:** For [audience] who [situation], [offer name] is [category] that [key benefit] unlike [alternative] because [differentiator]

### 2. Target Buyer Profile

- **Primary buyer:** Who is this for, specifically?
- **Their current situation:** What's happening in their business/life right now?
- **The problem this solves:** What pain or desire does this address?
- **Why NOW:** What makes this timely for them?
- **Buyer readiness:** What must be true before they're ready to buy?
- **Disqualifiers:** Who is this NOT for?

### 3. The Offer Stack

Everything the buyer gets, organized for maximum perceived value:

**Core Offer:**
| Component | Description | Format | Source |
|-----------|-------------|--------|--------|
| [Name] | [What it is] | [Video/PDF/Tool/Access/etc.] | [Existing from X / New build] |

**Bonuses:**
| Bonus | Description | Value Anchor | Trigger |
|-------|-------------|-------------|---------|
| [Name] | [What it is] | [$ value] | [When/why this is offered] |

**Access Components:**
| Access | Description | Duration | Frequency |
|--------|-------------|----------|-----------|
| [Name] | [What they get access to] | [How long] | [How often] |

### 4. Pricing Architecture

- **Price point:** $[amount]
- **Price justification:** Why this number (value-based, market-based, or strategic)
- **Payment options:** Full pay / Payment plan / Monthly
- **Price anchoring:** What the comparison price is and how it's established
- **Early bird / launch pricing:** If applicable
- **Value stack total:** Sum of all component values (for the "you'd expect to pay" frame)

### 5. Guarantee Design

- **Type:** Money-back / Conditional / Better-than-risk-free / Performance / None
- **Duration:** [Timeframe]
- **Conditions:** What must the buyer do (if conditional)
- **Language:** Exact guarantee statement
- **Risk reversal logic:** What somatic/psychological effect this guarantee creates

### 6. Delivery Architecture

**Timeline:**
| Phase | What Happens | When | How |
|-------|-------------|------|-----|
| Purchase | [Immediate experience] | Day 0 | [Automated/Manual] |
| Onboarding | [First value delivery] | Day 1-3 | [Platform/Channel] |
| Core delivery | [Main content/service] | Week 1-X | [Drip/All-at-once/Live] |
| Ongoing | [Continued access/support] | Ongoing | [Platform/Channel] |

**Platform requirements:**
- Where content lives
- Where community lives
- Where calls happen
- Payment processor
- Email/automation

**Marginal cost per customer:** $[amount]
**Scalability assessment:** Can handle [X] customers without operational changes

### 7. Scarcity & Urgency Design

- **Scarcity type:** Real / Engineered / None
- **Mechanism:** Cohort limits / Time-limited / Price increases / Bonuses expire
- **Authenticity check:** Is this genuinely scarce, or does it need to be?
- **Urgency language:** Key phrases for the sales mechanism

### 8. Sales Mechanism

- **Primary channel:** Webinar / VSL / Sales page / Application / Direct outreach
- **Funnel structure:**
  1. [Traffic source] â
  2. [Lead capture] â
  3. [Nurture sequence] â
  4. [Sales event/page] â
  5. [Follow-up sequence] â
  6. [Close]
- **Key conversion points:** Where the sale happens and what needs to be true
- **Objection handling:** Top 5 objections and how the offer structure (not just copy) addresses them

### 9. Positioning vs. Existing Portfolio

- **Value ladder position:** Where this sits relative to other offers
- **Cannibalization risk:** Does this steal from existing products? If so, is that acceptable?
- **Ascension path:** What does the buyer do BEFORE this (if anything) and AFTER this?
- **Cross-sell opportunities:** What other products become natural next steps?
- **How this strengthens the ecosystem:** What does this offer add that the portfolio lacked?

### 10. Success Metrics

- **Launch target:** [Revenue / units / conversion rate]
- **Ongoing target:** [Monthly/quarterly revenue]
- **Leading indicators:** What signals early that this is working or not?
- **Kill criteria:** Under what conditions do you shut this down?
- **Iteration plan:** What do you test first if initial results are mediocre?

### 11. Build Checklist

Everything that needs to be created or configured to launch:

| Item | Owner | Status | Priority |
|------|-------|--------|----------|
| [Content piece] | [Who] | Not started | P1 |
| [Tech setup] | [Who] | Not started | P1 |
| [Copy asset] | [Who] | Not started | P2 |
| [Design asset] | [Who] | Not started | P2 |

### 12. Copy Brief

What the copywriter needs to know to write for this offer:

- **Big idea:** The single core concept
- **Primary emotion:** What the buyer should FEEL
- **Key proof points:** What evidence is available
- **Voice and tone:** How this should sound
- **Structural patterns in play:** Which of the 30 patterns drive this offer (so copy reinforces structure)
- **What NOT to say:** Language that would undermine the offer's positioning

---

## Output

### File Location
```
Active-Brain/00 Projects/01 Behavioral Intelligence/Offer Factory/Blueprints/[Offer Name] - Blueprint - [Date].md
```

### Document Structure

```markdown
# Offer Blueprint: [Offer Name]
**Date:** [Date]
**Source:** [Deepener concept reference]
**Status:** BLUEPRINT COMPLETE â Ready for build

## 1. Offer Identity
[Section 1]

## 2. Target Buyer
[Section 2]

## 3. Offer Stack
[Section 3]

## 4. Pricing
[Section 4]

## 5. Guarantee
[Section 5]

## 6. Delivery
[Section 6]

## 7. Scarcity & Urgency
[Section 7]

## 8. Sales Mechanism
[Section 8]

## 9. Portfolio Position
[Section 9]

## 10. Success Metrics
[Section 10]

## 11. Build Checklist
[Section 11]

## 12. Copy Brief
[Section 12]
```

---

## Integration

- **Input from:** Offer Deepener (developed concepts marked PURSUE)
- **Output to:** Copywriting Arena (copy brief becomes the competition brief), tech team (build checklist), operations (delivery architecture)
- **Validation layer:** After blueprint is complete, optionally run through Behavioral Intelligence thinker skills (Ariely pricing audit, Damasio somatic marker audit, Cialdini influence audit) for pressure-testing
