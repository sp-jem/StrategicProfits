# Offer Factory: Offer Ecosystem Designer

---
name: offer-factory-ecosystem
description: "Use when optimizing the full product portfolio â the value ladder, ascension path, entry points, cross-sells, and gaps between offers â not just a single offer."
---

## Purpose

Individual offers are optimized by the Architect. The Ecosystem Designer optimizes the RELATIONSHIPS between offers â the value ladder, the ascension path, the entry points, the cross-sells, and the overall portfolio strategy. It answers: "Given everything we have and everything we've generated â what's the OPTIMAL product ecosystem?"

## Invocation

```
/offer-factory-ecosystem
```

Or with specific focus:
```
/offer-factory-ecosystem focus:front-end
/offer-factory-ecosystem focus:ascension-path
/offer-factory-ecosystem focus:gaps
/offer-factory-ecosystem include-generated (includes Engine/Deepener output)
```

---

## Input Requirements

**Required:**
- Product Component Inventories for all products
- Cross-Product Synthesis

**Strongly recommended:**
- Offer Autopsies of all current offers
- Engine runs and Deepener output (to include generated ideas)
- Revenue data per product (if available from Stripe/Whop analytics)
- Customer journey data (who buys what, in what order)

---

## Execution Process

### Phase 1: Current Ecosystem Map

Map the entire current product portfolio:

**Value Ladder Visualization:**
```
$50K+ âââ [Product?]
$10K  âââ [Product?]
$5K   âââ ZenithMind Elite
$3K   âââ ZenithMind Plus
$2K   âââ ZenithMind
$500  âââ [Product?]
$97   âââ SOW (monthly)
$47   âââ [Product?]
$0    âââ [Free content/lead magnets]
```

For each position on the ladder:
- What product fills it?
- Is there a gap (no product at this price point)?
- Is there congestion (multiple products at same price point)?
- Is the ascension path clear (does completing product A create desire for product B)?

**Customer Journey Map:**
1. How do people first encounter Rich? (Entry points)
2. What's the typical first purchase?
3. What's the typical second purchase?
4. Where do people stall or leave?
5. What's the maximum ascension path (lowest to highest)?
6. How long does the full journey take?

**Revenue Distribution:**
- What percentage of revenue comes from each product?
- What percentage comes from front-end vs. back-end?
- Where is revenue concentrated vs. distributed?

### Phase 2: Ecosystem Health Diagnostics

#### Diagnostic 1: Entry Point Analysis
- How many entry points exist? (Should have 3-5 distinct entry points for different buyer types)
- Are entry points self-selecting? (Different buyer segments naturally find different entry points)
- Is the lowest-cost entry point compelling enough to create momentum?
- Is there a $0 entry point that delivers genuine value?

#### Diagnostic 2: Ascension Path Analysis
- Is there a clear, natural ascension from every entry point to the highest-ticket offer?
- Are there dead ends (products that don't lead anywhere)?
- Are there broken rungs (price jumps too large for the perceived value increase)?
- Does each product create desire for the next one, or are they independent?

#### Diagnostic 3: Coverage Analysis
- What buyer needs are NOT served by any product?
- What buyer STAGES are not served? (Aware but not ready â Ready but need help â Active and scaling â Advanced and optimizing)
- What delivery FORMATS are missing? (Done-for-you, done-with-you, do-it-yourself, toolkits, community-only)

#### Diagnostic 4: Redundancy Analysis
- Are any products competing with each other for the same buyer?
- Is there intentional overlap (reinforcement) vs. accidental overlap (confusion)?
- Would any products be better merged?

#### Diagnostic 5: Revenue Optimization
- Is the portfolio optimized for maximum LTV or maximum front-end revenue?
- Are there products that exist for strategic reasons (lead generation, authority building) but don't need to be profitable?
- What's the estimated revenue ceiling of the current ecosystem?

### Phase 3: Gap Identification & Recommendations

For each gap identified, generate a specific recommendation:

**Missing Rung:** A price point or value level with no product
- What should go there
- Whether an existing product can be repositioned to fill it
- Whether an Engine-generated concept fits

**Missing Entry Point:** A buyer segment with no natural entry
- What type of offer would capture them
- What existing component could become that entry point

**Broken Ascension:** Where the upgrade path isn't working
- What's missing between Product A and Product B
- Is it a value gap, a trust gap, or a relevance gap?
- Recommendation: bridge product, better positioning, or path redesign

**Dead End Product:** A product that doesn't lead anywhere
- Should it be connected to the ecosystem?
- Should it be deprecated?
- Should something be built downstream of it?

**Revenue Leak:** Where value is being left on the table
- Cross-sell opportunities not being executed
- Upsell paths not being presented
- Segments being underserved

### Phase 4: Ideal Ecosystem Design

Design the optimal portfolio â what the ecosystem SHOULD look like:

**Ideal Value Ladder:**
- Every rung defined with product, price, buyer, and ascension trigger
- Clear entry points for each buyer segment
- No dead ends
- Maximum 2x-3x price jumps between rungs
- Each product creates desire for the next

**Ideal Customer Journeys:**
Map 3-5 ideal customer journeys:
1. The brand-new buyer who starts at $0
2. The hot lead who starts mid-funnel
3. The returning customer who's been away
4. The competitor refugee who comes with skepticism
5. The referral who arrives pre-sold

For each journey: entry â first purchase â momentum builder â core offer â premium â ongoing relationship

**New Products Needed:**
- What doesn't exist yet that the ecosystem requires
- Prioritized by strategic impact and build effort
- Cross-referenced with Engine output (do any generated ideas fill these slots?)

### Phase 5: Implementation Roadmap

**Quick Wins (This Quarter):**
- Repositioning, repricing, or reconnecting existing products
- Cross-sell sequences that don't exist yet
- Entry points that can be created from existing components

**Medium-Term (Next 2 Quarters):**
- New products to build using existing components
- Ascension bridges to create
- Revenue optimization changes

**Strategic (6-12 Months):**
- New products requiring significant creation
- Major portfolio restructuring
- New market segments to enter

---

## Output

### File Location
```
Active-Brain/00 Projects/01 Behavioral Intelligence/Offer Factory/Ecosystem/Ecosystem Design - [Date].md
```

### Document Structure

```markdown
# Offer Ecosystem Design
**Date:** [Date]
**Products Analyzed:** [count]
**Generated Concepts Included:** [Yes/No, count]

## Current Ecosystem Map
[Phase 1 â value ladder, customer journey, revenue distribution]

## Ecosystem Health Report

| Diagnostic | Score | Key Finding |
|-----------|-------|-------------|
| Entry Points | /10 | [Summary] |
| Ascension Path | /10 | [Summary] |
| Coverage | /10 | [Summary] |
| Redundancy | /10 | [Summary] |
| Revenue Opt | /10 | [Summary] |
| **Overall** | **/50** | |

## Gaps & Recommendations

### Critical Gaps (Fix First)
[Gaps that are actively costing revenue or losing customers]

### Strategic Gaps (Build Next)
[Gaps that represent growth opportunities]

### Nice-to-Have Gaps (When Resources Allow)
[Gaps that would improve but aren't urgent]

## Ideal Ecosystem Blueprint
[Phase 4 â the vision of what the portfolio should become]

## Customer Journey Maps
[3-5 ideal journeys through the ecosystem]

## Implementation Roadmap

### Quick Wins (This Quarter)
[Prioritized list with effort estimates]

### Medium-Term
[Prioritized list]

### Strategic
[Prioritized list]

## Revenue Impact Estimate
[Rough estimate of revenue impact from implementing recommendations]
```

---

## Integration

- **Input from:** All other Offer Factory skills (inventories, synthesis, autopsies, engine runs, deepened concepts, blueprints)
- **Output to:** Strategic planning, product development roadmap
- **Should be re-run:** Quarterly, or whenever a major new product is launched or deprecated
- **Pairs with:** Revenue data from Stripe/Whop/Trolley analytics skills for data-driven recommendations
