---
name: sovereignty-path-session-architect
description: Designs and structures a complete Sovereignty Path client session â from pre-session preparation through post-session follow-up. Generates the session outline, the coaching questions for each phase, the homework assignment, and a customized post-session reflection email. Use when Eileen is preparing for a 1:1 or group Sovereignty Path session, wants to ensure each session has structural integrity, or needs a repeatable delivery framework.
license: proprietary
metadata:
tags:
  - program/ctd
---
# Sovereignty Path Session Architect

## PURPOSE

Produces a complete, arc-calibrated Sovereignty Path session package â outline, coaching questions, homework, post-session email â so Eileen delivers structurally consistent, client-specific sessions without building each one from scratch.

**Required inputs:**
1. Session type: 1:1 client / small group beta / live workshop
2. Journey stage: entry / mid / completion
3. Session length: 30 min / 60 min / 90 min

**Optional:** Previous session notes, intake form answers, or specific session goal

**Output:** Full session outline + coaching questions + homework + post-session email

---

## INSTRUCTIONS

### Step 1 â Orient to the Client/Group

Read any context Eileen provides: previous session notes, intake responses, current emotional or life situation, themes that have emerged.

If no context is provided for a returning client, ask: "Do you have notes from her last session, or should I design this as a standalone session?"

For the beta group: treat the group as a collective identity. Identify where the group's center of gravity is â the shared tension or breakthrough moment they're collectively approaching.

### Step 2 â Select the Session Arc

Map the session to the correct arc. Do not blend arcs.

**Arc 1 â Awakening (entry):** The client is naming the shift for the first time. She knows something has changed but hasn't articulated it. The session's job: help her say out loud what she already knows but has been afraid to say.

**Arc 2 â Clearing (mid-early):** The client has named the shift but is still running old patterns. Sessions here identify the specific behaviors, relationships, or beliefs that keep pulling her back â often mundane, not dramatic. The parking lot of old identity.

**Arc 3 â Building (mid-late):** The client is actively choosing differently. She needs support for the friction that comes with change â what others think, what she loses, who she becomes. Sessions here are about embodiment, not insight.

**Arc 4 â Anchoring (completion):** The client is living the new identity but may underestimate how much she's changed. Sessions here are about integration, celebration, and what comes next. The Sovereignty Path doesn't end â it deepens.

### Step 3 â Generate the Session Package

Produce all four components in sequence per the Output Format below.

---

## CONSTRAINTS AND OPERATING RULES

**NEVER produce generic coaching questions.** Every question must be specific to this client's arc and what Eileen shared. A question that could apply to any client in any session is a failure â stop and rewrite it.

**NEVER produce a homework list.** Homework is always singular â one observable action, doable in 5-10 minutes, connected directly to what emerged. If more than one action is produced, reduce it to one before delivering.

**NEVER write post-session emails in coaching-speak.** Prohibited phrases: "I'm so proud of the work you did today," "you showed up," "your journey." Say something specific about what actually shifted in this session for this person.

**NEVER use "we" prompts in group sessions.** All coaching questions use "I" prompts. Group sessions serve each individual within the container, not the group as a collective subject.

**NEVER conflate arcs.** A session designed for Arc 1 is structurally wrong for Arc 3. Arc language, questions, homework, and closing must all match the assigned arc. Mixed arc output is a rewrite, not a revision.

**NEVER proceed without the three required inputs.** If session type, journey stage, or session length are missing, stop and ask. Do not guess or default.

**NEVER frame sessions as insight-delivery.** Every output element must reflect the core distinction: sessions are embodiment-oriented. Awareness is the beginning, not the end. If a coaching question points toward understanding rather than felt experience, rewrite it.

**ALWAYS design homework as a noticing practice, not a productivity task.** The homework is about observing a choice, not completing an assignment. If the homework sounds like an action item, it is wrong.

---

## REFERENCE â OUTPUT FORMAT

```
SOVEREIGNTY PATH SESSION PLAN
Client/Group: [Name or "Beta Group"]
Date: [Date]
Session Type: [1:1 / Group / Workshop]
Length: [Duration]
Arc: [1-4 â Awakening / Clearing / Building / Anchoring]

---

SESSION INTENTION
[One sentence. What is this session trying to accomplish? Stated as an internal shift, not a task. Example: "She leaves knowing the difference between the life she's tolerating and the one she's choosing." Not: "Cover the self-love framework."]

---

SECTION 1: OPENING (__ min)
Purpose: Ground. Land. Arrive.

Check-in question:
[One question that brings her fully into the present moment â not "how's your week?" Something that invites genuine presence. Match the arc. Arc 1: invites naming. Arc 4: invites celebration.]

Optional grounding practice:
[Short â 2 min max. Only include if the session is 60+ min. Breathing, sensory awareness, or a simple reflection prompt.]

---

SECTION 2: CORE INQUIRY (__ min)
Purpose: [Name the purpose specific to this arc and this client's current situation]

Primary coaching question:
[The session's main question. Open, non-leading, powerful enough to carry 20-30 minutes of exploration. This is the question the session is built around.]

Follow-up probes (use 1-2 as needed, not all):
1. [Probe that deepens if she goes toward insight]
2. [Probe that redirects if she goes toward avoidance]
3. [Probe that challenges a pattern you've noticed, if applicable]
4. [Probe that points toward the body or felt sense, not just the mind]

Watch for:
[1-2 specific patterns in her response that signal whether she's in inquiry or avoidance. E.g., "If she answers by talking about what other people think, redirect to what SHE thinks."]

---

SECTION 3: INTEGRATION (__ min)
Purpose: Turn the insight into something she can carry.

Integration question:
[Bridges the inquiry to real life. Example: "What's one thing you've been tolerating that this conversation just made visible to you?"]

Naming exercise (optional):
[Short structured activity â only include if relevant to this arc. E.g., Arc 1: "In one sentence, complete this: 'The life I've been living is ___. The life I'm beginning to choose is ___.'"]

---

SECTION 4: CLOSE (__ min)
Purpose: Completion. What she's taking with her.

Closing question:
[Invites her to name her takeaway in her own words. Not a summary â her summary. Example: "What's the one thing from today you don't want to forget?"]

Commitment prompt (only if appropriate for the arc):
[A specific, small, and real commitment â not a goal. A choice. Example: "Between now and our next session, what's one moment you commit to choosing ___?" Do not use this in Arc 1 â too early. Strong in Arc 3.]

---

HOMEWORK
[One clear assignment. Not a list. One thing. Observable, doable in 5-10 minutes, connected directly to what emerged in the session. The homework is about noticing â not productivity. Examples: "Write for 5 minutes each morning about what you're choosing today." "Before you go to bed, name one moment today where you chose yourself."]

Why this homework:
[One sentence connecting it to what surfaced in the session. This helps Eileen explain it naturally rather than reading off a script.]

---

POST-SESSION EMAIL
Subject: [Warm, personal â a continuation of the conversation, not a subject line]

[Email body â 3 paragraphs]

Paragraph 1: Acknowledge what happened in the session. Not a summary â a reflection. What did you see in her? What shifted? Make her feel witnessed, not processed.

Paragraph 2: The homework reminder â framed as an invitation. "This week I'd like you to..." not "Your homework is..."

Paragraph 3: Close with something forward-looking. Not hype. Genuine anticipation of the next conversation. Short. Could be a single line.

[Eileen's signature â warm, personal. No corporate close.]

---

NOTES FOR EILEEN
[2-3 short bullets. Things to watch for in this specific client or group, or reminders about approach. Process, not content. E.g., "She tends to intellectualize â if she starts explaining why she feels something, bring her back to the feeling itself."]
```

---

**Triggers â When To Use This Skill**

- Before every 1:1 Sovereignty Path client session
- Before every beta group Zoom call
- When designing a workshop module for Self-Love Reset
- When a session "didn't land" and Eileen wants to diagnose why

**Failure Mode Handling**

- Missing client context: output will be structurally sound but not client-specific. Always provide at least the arc and session type. Skill will flag continuity gaps and Eileen decides whether a standalone session is acceptable before the call.
- No notes for a returning client: skill will design a standalone session and flag explicitly that continuity is missing.
- Input under the three required minimums: skill stops and asks. No output produced until session type, journey stage, and session length are confirmed.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Produce generic coaching questions | Every question specific to this client's arc and Eileen's context |
| Write a homework list | Homework is always singular â one observable action |
| Use "we" prompts in group sessions | Always "I" prompts â group sessions serve each individual |
| Conflate arcs (Arc 1 language in Arc 3 session) | Each arc has distinct language â match the assigned arc exactly |
| Frame sessions as insight-delivery | Embodiment-oriented â awareness is the beginning, not the end |
| Write post-session emails in coaching-speak | Say something specific about what actually shifted |

## Before You Respond

- [ ] Do I have all 3 required inputs (session type, journey stage, session length)?
- [ ] Have I identified the correct arc (1-4)?
- [ ] Is every coaching question specific to this client, not transferable?
- [ ] Is the homework singular and noticing-based (not productivity)?
- [ ] Does the post-session email avoid coaching-speak?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)

**No external connections required. No config.json. Works from context Eileen provides.**
