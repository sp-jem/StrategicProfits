---
name: fq-conversion-optimizer
description: Analyzes a Feasibility Questionnaire (FQ) for clinical trials and identifies every factor that is reducing the probability of conversion â site profile mismatches, protocol complexity red flags, capacity gaps, investigator weaknesses â then recommends how to respond to maximize close rate. Use when Michelle is reviewing an FQ, deciding whether to pursue a study, or trying to understand why FQ conversion rate is low. Trigger phrases: "feasibility," "FQ," "should we take this study," "why aren't we converting feasibilities," "sponsor questionnaire," "site assessment," "protocol review."
license: proprietary
metadata:
tags:
  - program/ctd
---
# FQ Conversion Optimizer

## Purpose

Turns the feasibility questionnaire process from a time-drain into a revenue filter. Analyzes incoming FQs to identify which ones are worth pursuing, flags response weaknesses that kill conversions, and produces optimized answers that position Core Clinical Trials' network as the obvious choice.

## Minimum Requirements Before Starting

NEVER produce output until the following are confirmed:
- The FQ questions (or a description of what is being asked) are available
- Some indication of the sponsor, CRO, or therapeutic area is present

If no FQ content is provided, ask: "Paste the FQ questions â or if it's a sponsor-specific form, describe what they're asking about: patient population requirements, PI qualifications, site infrastructure, enrollment projections, or regulatory track record." Do NOT proceed without this input.

NEVER fabricate, estimate, or assume CCT capability data not explicitly provided in this session. If enrollment figures, PI credentials, or site counts are unknown: flag them with "Verification required â confirm with [Mailyn/Missy/Vincent] before submission." Do NOT insert estimated numbers.

ALWAYS run the Qualify/Pursue/Pass decision before any other work. Time spent on an unwinnable FQ is time taken from pipeline, operations, and exit preparation. NEVER skip Step 1.

## Core Workflow

### Step 1 â Qualify/Pursue/Pass Decision

Score the FQ against four criteria. PRODUCE this decision before any response drafting.

**1. Network Fit**
Does this study fall within CCT's 14+ therapeutic areas? Do patient population requirements match CCT site demographics? GLP-1, urgent care, and specialty practices are Michelle's priority expansion areas â flag these as high-priority.

Score: Strong Fit / Acceptable Fit / Poor Fit

**2. Investigator Match**
Does CCT have PIs with the credentials, experience, and track record this protocol requires? If this study requires a PI tier CCT cannot currently deliver, flag it â do not bury the gap in a confident-sounding response.

Score: Strong Match / Acceptable Match / Gap

**3. Enrollment Realism**
Can CCT's network realistically hit the enrollment targets given the protocol's patient eligibility criteria and timeline? Flag protocol complexity factors that make enrollment hard: narrow inclusion criteria, complex visit schedules, aggressive timelines.

Score: Realistic / Aggressive (possible) / Unrealistic

**4. Revenue Worthiness**
Is the study budget commensurate with the complexity and resource demands? Studies with low budgets and high site burden are NEVER worth pursuing even if fit is strong.

Score: Favorable / Acceptable / Unfavorable

REQUIRED output format:

| Criteria | Score |
|----------|-------|
| Network Fit | [Score] |
| Investigator Match | [Score] |
| Enrollment Realism | [Score] |
| Revenue Worthiness | [Score] |

**DECISION: QUALIFY / PURSUE WITH CONDITIONS / PASS**

If PASS: State the specific reason in one sentence. Log this as a dismissed FQ. STOP â do not produce Step 2 or Step 3 output for a PASS decision.
If PURSUE WITH CONDITIONS: State what condition MUST be met before submitting (e.g., "Confirm PI X can take this â call Mailyn"). Do NOT proceed to Step 3 until condition is resolved.

### Step 2 â Response Weakness Analysis

REQUIRED only when decision is Qualify or Pursue With Conditions.

For each FQ question where a weak or generic answer would hurt conversion:

---

**Question:** [Paste or paraphrase the FQ question]

**Common weak answer:** [What most site networks say â the generic response]

**Why it kills conversion:** [What the sponsor/CRO is actually evaluating here]

**CCT's winning angle:** [What CCT can say that no generic response can match â based on actual competitive advantages: largest alliance in North America, TrialPulse technology, single contract/budget/POC, 14+ therapeutic areas, 25+ years of pharma experience]

---

REQUIRED: Flag questions where CCT does NOT have a competitive answer. These are honest gaps â address them as "Pursue With Conditions" conditions, not with false claims.

### Step 3 â Optimized FQ Response

REQUIRED only when Step 1 decision is Qualify or conditions from Pursue With Conditions are resolved.

NEVER produce vague FQ responses. Every claim MUST be backed by a specific CCT capability. "We have experience in this therapeutic area" is prohibited output. "Our network covers [N] active sites in [therapeutic area] with investigators averaging [X] years of experience in [indication]" is the required standard.

**CCT positioning pillars â weave in naturally, NEVER force:**
- Largest alliance of clinical trial research sites in North America
- TrialPulse technology: single contract, single budget, single point of contact
- 14+ therapeutic areas â name the relevant ones for this study
- Multi-site network with rapid site identification and study startup
- 25+ year pharmaceutical industry track record (Michelle's personal expertise as DPM and former PRA Health Sciences, FastTrack Clinical Solutions)
- North American geographic coverage

**For enrollment projections:** Be specific and credible. Vague projections are prohibited. Required format: "Based on our current network across [relevant geographies], our initial site assessment suggests [X] patients can be enrolled within [Y] months at [Z] sites. This estimate assumes [specific inclusion criteria details from the protocol]." If actual site data is unavailable, leave the bracketed fields blank and flag: "Mailyn to populate before submission."

**For PI qualifications:** NEVER overpromise. Required format: "Our network includes investigators with board certification in [specialty] and [X] years of clinical research experience in [therapeutic area]." If credential data is unavailable, flag: "Missy to verify before submission."

**For timeline commitments:** Frame around CCT's startup advantage â single contract eliminates multi-site coordination lag. Quantify in days or weeks vs. typical multi-site contracts.

REQUIRED output format:

---

**[FQ QUESTION 1]**
[Optimized answer â complete, ready to submit]

**[FQ QUESTION 2]**
[Optimized answer]

[Continue for all questions]

---

### Step 4 â Debrief Mode (Post-Outcome Only)

ONLY run this step when Michelle explicitly states the study was not won and provides the loss outcome. NEVER run debrief mode during an active FQ process.

**Study:** [Description]
**Decision:** [Sponsor chose another network]

**Probable loss factors:**
1. [What CCT's response likely said vs. what the sponsor needed to hear]
2. [What the winning CRO/network likely offered that CCT could not match]
3. [What would need to change for CCT to win this type of study in the future]

**Pattern to track:** After 5+ debrief sessions, patterns will surface that reveal the primary conversion blocker. Log each debrief so the pattern is visible.

## Operating Rules

- ALWAYS run Step 1 first. NEVER skip the Qualify/Pursue/Pass decision to get to the response faster.
- NEVER produce vague FQ responses. Specificity wins feasibility reviews. Every claim MUST be backed by a specific capability.
- NEVER misrepresent CCT's capabilities. If CCT cannot meet a requirement, flag it in the Pursue With Conditions decision â do not bury it in a confident response that creates problems during study startup.
- NEVER fabricate enrollment projections, PI credentials, or site counts. If data is unavailable, flag the field for Mailyn or Missy to populate.
- Flag TrialPulse on EVERY FQ question about technology, data management, or site coordination. This is CCT's differentiator â NEVER omit it when relevant.
- Flag GLP-1, urgent care, and specialty practices as priority therapeutic areas on every relevant FQ. These are Michelle's current expansion priorities.
- NEVER run Debrief Mode on an active FQ. Debrief Mode is ONLY for post-outcome analysis of a completed, non-selected submission.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Skip the Qualify/Pursue/Pass decision | Step 1 always runs first â no exceptions |
| Produce vague FQ responses | Every claim backed by specific capability |
| Misrepresent CCT's capabilities | Flag gaps in Pursue With Conditions â don't bury them |
| Fabricate enrollment projections or credentials | Flag for Mailyn or Missy to populate |
| Omit TrialPulse when technology/data/coordination is asked | Flag it on every relevant FQ question |
| Run Debrief Mode during an active FQ | Debrief is post-outcome only |

## Before You Respond

- [ ] Have I run Step 1 (Qualify/Pursue/Pass) first?
- [ ] Is this a Pass? (If yes, stop all further output.)
- [ ] Am I populating actual FQ questions verbatim (not generic placeholders)?
- [ ] Is TrialPulse flagged on every relevant question?
- [ ] Are data gaps flagged for Mailyn/Missy instead of fabricated?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
