---
name: ghl-funnel-brief
description: Takes a voice note, rough idea, or short description of a funnel Steve wants to build and produces a complete GoHighLevel (GHL) build brief â page structure, copy angles, automation triggers, and offer architecture. Use this before touching GHL. It converts Steve's vision-level thinking into implementation-ready specs so Steve stays out of implementation and hands a complete brief to an operator or AI builder. Trigger phrases include "I want to build a funnel for," "funnel for [product]," "build me a GHL brief," or whenever Steve describes a new offer and wants it online.
license: proprietary
metadata:
tags:
  - program/ctd
---
# GHL Funnel Brief

Converts a rough funnel idea into a complete GoHighLevel build brief â page structure, copy direction, automation map, and handoff notes â ready to hand to an operator or builder without Steve's involvement.

---

## Purpose

Produce a single, complete GHL build brief that an operator can execute without talking to Steve. Output covers offer architecture, funnel map, page-by-page specs, GHL automation map, and handoff notes. Steve's involvement ends at reviewing the finished brief â not at building anything.

**Required inputs (all three must be present before output begins):**
1. The offer â what is being sold
2. The entry point â what a prospect sees first
3. The target buyer â who this funnel speaks to

If a voice note or rough description is provided, extract all three required elements from it before proceeding.

---

## Instructions

### Step 1 â Offer Architecture Summary

Clarify the full offer stack before building pages:

```
OFFER ARCHITECTURE
Core offer: [What they're buying]
Price: [Entry price point]
Upsell 1: [If applicable]
Upsell 2: [If applicable]
Guarantee: [If applicable]
Delivery method: [Access via GHL, Skool, live event, etc.]
```

### Step 2 â Funnel Map

Draw the full page sequence:

```
FUNNEL MAP
[Page 1 name] â [Page 2 name] â [Page 3 name] â [etc.]
Traffic source: [Organic / paid / email list / DMs]
Entry condition: [Cold traffic / warm list / hot referral]
```

### Step 3 â Page-by-Page Brief

For each page in the funnel, produce:

```
PAGE: [Page name]
Type: [Opt-in / VSL / Sales Page / OTO / Confirmation / Thank You]
Objective: [What this page accomplishes â specific, not "generate leads"]

ABOVE THE FOLD
- Headline: [Primary headline â the result, not the product]
- Subheadline: [Clarifies who this is for and the mechanism]
- Primary CTA: [Button copy + what it does]
- Visual direction: [What should be on screen â Steve on camera? Book mockup? VSL? Image?]

BODY DIRECTION (Sales Pages and VSLs only)
- Hook: [First 30 seconds / first screen â what grabs them]
- Problem: [What they're suffering from â specific to this buyer]
- Mechanism: [Why Steve's approach is different â named mechanism preferred]
- Proof: [What evidence appears here â results, testimonials, Steve's track record]
- Offer reveal: [How and when the offer is presented]
- CTA: [Final call to action â specific button copy]

AUTOMATION TRIGGERS ON THIS PAGE
- On opt-in: [What fires in GHL â tag added, sequence enrolled, notification sent]
- On purchase: [What fires â fulfillment sequence, Slack notification, onboarding trigger]
- On abandon: [Retargeting tag, abandon sequence, etc.]

COPY NOTES
[2-3 sentences on the tone and angle for this specific page â Steve's voice, not generic marketing]
```

### Step 4 â GHL Automation Map

List every automation needed for the funnel to run without human intervention:

```
GHL AUTOMATION MAP

Trigger: [What event fires this]
Action: [What GHL does]
Branch conditions: [If/then logic if applicable]

[List all automations in order of sequence]
```

### Step 5 â Handoff Notes

```
HANDOFF NOTES FOR OPERATOR
Priority order to build: [Which pages to build first]
Steve's copy that already exists: [Any existing copy to pull in]
Assets needed: [Headshots, book mockup, VSL recording, testimonial screenshots]
Test first: [The one element to A/B test before scaling traffic]
Steve's approval needed on: [What to confirm with Steve before going live]
```

**Steve's funnel philosophy (applied throughout):**
- One offer per page. No distractions. No nav. No options.
- The offer IS the mechanism. Funnels lead with the unique result, not product features.
- Short opt-ins, long VSLs, longer sales letters. Match page type to traffic temperature.
- GHL-native. All automations are buildable inside GHL unless Steve specifies otherwise.
- Test the headline first. Every funnel brief identifies the primary headline as the #1 variable to test.

---

## Operating Rules

**NEVER start the brief until all three required inputs are confirmed.** If a voice note is provided, extract the inputs from it â do not ask for what is already there. If all three cannot be extracted, state exactly which elements are missing and wait.

**NEVER write headlines that are product labels.** "Join Titans of Industry" is a disqualifying headline. Every headline must state a result: "Go from Doing Everything to Leading Everything â In 90 Days." Audit every headline in the output before delivering.

**NEVER include any element that requires Steve to be hands-on after the brief is delivered.** Steve's role ends at reviewing a finished page. Any build step that requires Steve's real-time involvement is a brief failure â redesign the step.

**NEVER assume GHL is the wrong platform.** Default to GHL for all automations and page builds. If a different platform is needed, flag it explicitly and adjust â do not silently swap tools.

**NEVER add automation steps that require tools outside GHL** unless Steve explicitly specifies external tools. All automations in the map must be natively buildable inside GHL.

**NEVER produce generic marketing copy.** Prohibited phrases: "synergy," "actionable insights," "leverage your ecosystem," "game-changing," or any equivalent. Every page brief must carry Steve's voice. Flag and remove any such phrase before delivering.

**ALWAYS note "pull existing copy from GHL first"** in the Handoff Notes when Steve mentions an existing funnel. Do not write new copy for pages that already have copy without flagging this first.

**Failure modes:**
- If Steve provides only an offer name with no details: extract what can be inferred from the known product list, then ask for the specific missing inputs before producing the brief.
- If the target buyer and entry point are mismatched (e.g., cold traffic entry with long-form VSL architecture): flag the mismatch explicitly and recommend the correction before producing pages.
- If an automation requires a tool Steve has not mentioned (e.g., Zapier, Stripe separately): flag it in the Handoff Notes rather than silently including it.

---

## Output Format

Deliver as a single document in section order: Offer Architecture, Funnel Map, Page-by-Page Brief, GHL Automation Map, Handoff Notes. Label every section clearly. The operator reading this must be able to build without talking to Steve.

---

## Reference

**Steve's products this applies to:**
- **Titans of Industry** â Application funnel, webinar funnel, direct outreach landing page
- **Offer Launch** (book) â Book funnel, 10K-copy launch funnel
- **School of Money** â Low-ticket front end, $297/month membership funnel
- **The Stage Book** â Workshop registration + book bundle funnel
- **Click AI** â Coming soon / waitlist funnel (coordinate with Steve's dad on positioning)
- **Keynote bookings** â Speaker inquiry funnel for event planners

**Platform default:** GHL (GoHighLevel)

**Related tools:**
- ai-steve (agent) â for drafting funnel copy in Steve's voice
- offer-launch-strategist (agent) â for book launch funnel architecture

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Use corporate language ("synergy," "actionable insights") | Steve's direct voice â flag and remove any corporate phrases |
| Add automation steps requiring tools outside GHL | Unless Steve specifies, everything is natively GHL |
| Write new copy for pages that already have copy | Flag existing copy and note "pull from GHL first" |
| Produce a brief from an offer name only | Extract what you can, ask for the missing inputs |
| Silently include external tools in automations | Flag external tool dependencies in Handoff Notes |
| Mismatch traffic temperature to architecture | Cold traffic + long-form VSL = flag the mismatch |

## Before You Respond

- [ ] Do I have the offer, target buyer, traffic temperature, and entry point?
- [ ] Am I using GHL natively unless told otherwise?
- [ ] Have I flagged any existing copy that should be pulled from GHL first?
- [ ] Is every page brief in Steve's voice (not corporate)?
- [ ] Can an operator build this without talking to Steve?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
