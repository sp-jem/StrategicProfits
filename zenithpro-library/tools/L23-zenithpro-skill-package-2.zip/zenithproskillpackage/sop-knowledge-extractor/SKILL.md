---
name: sop-knowledge-extractor
description: Extracts Cris Cawley's institutional publishing knowledge from conversations, decisions, and corrections and converts it into SOP entries, decision trees, and team-facing reference documents. Use when Cris answers a team question she's answered before, corrects a team mistake, or articulates a publishing standard â the goal is to turn her brain into written operating infrastructure so the same question never reaches her again.
license: proprietary
metadata:
tags:
  - program/ctd
---
# SOP Knowledge Extractor

Turns Cris Cawley's institutional publishing expertise into written SOP infrastructure. Every time she answers a question, makes a correction, or articulates a standard, that knowledge gets captured and formatted â so it lives in a document instead of only in her head.

## Why This Exists

Cris holds the deep publishing knowledge at Game Changer Publishing. She handles ~45 team members with no middle management layer. The result: she fields repetitive questions, corrects the same types of mistakes, and rebuilds context constantly. Her knowledge exists â it's just not externalized.

This skill does two things: (1) captures her knowledge in real time as she speaks it, and (2) reformats it into the SOP structure her team can actually use and follow.

## Keywords
SOP, standard operating procedure, institutional knowledge, publishing process, team documentation, decision tree, knowledge transfer, team training, process documentation, knowledge capture

## Quick Start

1. Paste in the raw content â a question she just answered, a correction she just made, a decision she just explained, or meeting notes from a team discussion
2. Specify the content type: `question-answer`, `correction`, `decision`, or `meeting-notes`
3. Claude extracts the embedded knowledge and produces a formatted SOP entry
4. Review and add to the vault under the appropriate SOP section

## Minimum Requirements Before Starting

Before extracting, verify:

- Raw content is provided (at least one exchange, correction, or explanation)
- Content type is specified (or Claude will classify it)
- The SOP section it belongs to (if known â Claude will suggest one if not)

## Core Workflow

### Step 1 â Classify the Knowledge Type

Read the raw content and identify which category the knowledge falls into:

**Question-Answer:** Cris answered a question a team member asked. The question reveals a gap in documentation. The answer is the missing SOP entry.

**Correction:** Cris corrected a mistake. The correction reveals a standard that was not written down. The correction is the rule.

**Decision:** Cris made a judgment call on a non-routine situation. The decision reveals criteria that should be documented so future situations route consistently.

**Meeting Notes:** A team meeting generated explanations, clarifications, or standards that should be captured before they evaporate.

### Step 2 â Extract the Core Standard

From the raw content, extract:

1. **The rule** â What is the publishing standard, requirement, or expectation being communicated? State it as a clear directive, not a description.
2. **The reason** â Why does this standard exist? What goes wrong when it isn't followed? (This is often implied â surface it explicitly.)
3. **The trigger** â When does this standard apply? What situation activates it?
4. **The exception** â Are there cases where the standard doesn't apply, or where judgment is required?
5. **The ownership** â Who is responsible for applying this standard? (PM role, account manager, production team, etc.)

### Step 3 â Produce the SOP Entry

Format the extracted knowledge in two versions:

**Version A: SOP Entry** (for the 19-section Google Drive / vault SOP system)

```
### [Title â actionable phrase, not a question]

**Applies to:** [Role(s) responsible]
**Trigger:** [When this applies]

**Standard:**
[The rule, stated as a directive. Plain language. What to do, not what to think about.]

**Why:**
[The reason this standard exists. 1-2 sentences. Grounded in GCP's publishing quality, client outcomes, or operational reliability.]

**Steps:**
1. [Step]
2. [Step]
3. [Step]
[Continue as needed]

**Exception handling:**
[If X, then Y. If judgment is needed, escalate to [role].]

**Common mistake:** [The specific error this SOP exists to prevent.]
```

**Version B: Quick Reference Card** (one paragraph, plain language, for team Slack or training onboarding)

```
[Title]
[2-4 sentences that a new team member could read in 30 seconds and apply immediately. No jargon. No assumed context. Includes the one thing that most commonly goes wrong.]
```

### Step 4 â Classify the SOP Section

GCP operates a 19-section SOP Google Drive. Assign the entry to the most relevant section from:

1. Client Onboarding
2. Manuscript Review and Editing
3. Cover Design and Approval
4. Interior Formatting and Layout
5. Printing and Fulfillment
6. ISBN and Copyright Registration
7. Distribution Setup
8. Client Communication Standards
9. Sales and New Client Pipeline
10. PM Responsibilities and Workflows
11. Vendor and Contractor Management
12. Quality Control Checkpoints
13. Revision and Reprint Protocols
14. Marketing and Launch Support
15. PUBLISH AI App Workflows
16. Finance and Invoicing
17. Team Onboarding and Training
18. Escalation and Exception Handling
19. Partnership and Referral Management

If the entry doesn't fit cleanly, suggest the closest section and flag for Cris's review.

### Step 5 â Flag for Knowledge Gap Audit

After producing the SOP entry, note:

- **Knowledge gap this closes:** [The question or mistake that revealed this gap]
- **Related gaps this entry suggests:** [What other questions this topic area probably generates â Cris may have answered these too]
- **Priority:** High (Cris answers this weekly) / Medium (monthly) / Low (edge case)

## Output Format

Produce the full output in this structure:

---

**SOP ENTRY EXTRACTED**
**Source type:** [Question-Answer / Correction / Decision / Meeting Notes]
**Date extracted:** [Date]
**Extracted from:** [Brief description of the source]

---

**VERSION A â SOP ENTRY**

[Full formatted SOP entry]

---

**VERSION B â QUICK REFERENCE**

[One-paragraph plain language version]

---

**CLASSIFICATION**
**SOP Section:** [Number and name]
**Suggested file location:** [Path in vault]

---

**KNOWLEDGE GAP AUDIT**
**Gap closed:** [What gap this fills]
**Related gaps to investigate:** [What else Cris probably gets asked in this area]
**Priority:** [High / Medium / Low]

---

## Operating Rules

**What this skill does:**
- Extracts the standard exactly as Cris stated it â her words, her logic, her exceptions
- Flags ambiguity and gaps for Cris's review rather than silently resolving them
- Produces two output versions: one for the SOP system, one for immediate team use
- Always surfaces what related questions this topic area is likely generating

**What this skill never does:**
- Never supplements Cris's stated standard with generic publishing industry best practices â GCP's standards may intentionally differ from industry norms
- Never assign ownership when the raw content does not specify responsibility â use "[Confirm with Cris]" always
- Never produce a Quick Reference Card that requires GCP insider knowledge to understand â if it assumes context, rewrite it
- Never mark an extraction complete if the ambiguity field is blank â every extraction either confirms clarity or flags a specific ambiguity
- Never invent a standard from implied context â extract only what was explicitly stated or can be directly inferred from Cris's correction or decision

**Constraint rules:**
- If the raw content is ambiguous or internally contradictory, extract the most conservative interpretation AND flag the specific contradiction for Cris's review â do not choose between contradictory statements silently
- If the raw content is very long (meeting notes spanning multiple topics), produce one SOP entry per distinct standard â do not combine separate standards into a single entry
- The SOP Section assignment must be one of the 19 named sections â "General" or "Miscellaneous" are not valid assignments; escalate to Cris if no section fits cleanly

## When To Use This Skill

- After any team all-hands where Cris explained something she's explained before
- When a team member sends a question Cris has answered in some form already
- When Cris catches and corrects a production mistake
- When Cris makes a vendor or client decision and wants the criteria documented
- At the end of any week where Cris felt like a bottleneck â run back through the questions she fielded and extract every SOP entry hiding in them

## Before You Respond

- [ ] Do I have raw content to extract from (not a request to generate)?
- [ ] Have I extracted only what Cris actually stated (not supplemented with industry best practice)?
- [ ] Is every ambiguity flagged for Cris's review?
- [ ] Does the SOP section map to one of the 19 named sections?
- [ ] Is the Quick Reference Card readable without insider knowledge?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Before You Respond, Version History (Gauntlet QA pass)
