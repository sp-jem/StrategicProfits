---
name: financial-aid-award-comparator
description: Takes raw financial aid award letters from multiple colleges and produces a standardized side-by-side comparison showing true net cost, aid breakdown by type, and which schools are actually more affordable after accounting for gift aid vs loans vs work-study. The most time-consuming part of April for Pearl â this compresses hours of manual analysis into minutes. Use when a family has received award letters and needs to understand what they actually mean.
license: proprietary
metadata:
tags:
  - program/ctd
  - client/pearl-lockwood
---
# Financial Aid Award Comparator

Standardizes award letters from multiple colleges â separates gift aid from loans and work-study, calculates true net cost per school, ranks schools by actual cost, and flags appeal leverage for Pearl's April consultations.

## Keywords
award letter, financial aid offer, net cost, COA, cost of attendance, EFC, SAI, gift aid, grants, scholarships, loans, work-study, merit aid, need-based aid, institutional grant, net price, appeal, leverage, financial aid comparison

## HARD CONSTRAINTS â Read Before Anything Else

- NEVER calculate without actual numbers Pearl provides. Do not estimate tuition, room and board, or any COA component from external sources without Pearl's explicit instruction AND a prominent flag.
- NEVER present a net cost figure without showing the full math (COA line by line, then subtraction of gift aid only).
- NEVER combine loans with gift aid in any "total aid" figure. Schools present $25,000 "total packages" that include $12,000 in loans â this framing misleads families and must be corrected, not replicated.
- NEVER subtract loans or work-study from net cost in the primary calculation. They are liabilities or contingent earnings, not free money.
- NEVER present Parent PLUS loans as aid. Flag them as a separate liability every single time they appear. They are never included in gift aid totals.
- NEVER present a merit scholarship without stating its renewability conditions. Unknown renewability must be flagged as "Unknown â verify with school before deciding."
- NEVER present work-study as guaranteed income. It is an offer of employment. The student must find and hold a qualifying job.
- NEVER present output as final without Pearl's review. Every output carries "For Pearl's Review â Not Final Until Approved."
- If any input number is ambiguous: ask Pearl before calculating. Wrong math with confidence is worse than no math.

## Quick Start

1. Paste or share the award letter content for each school (text, described line items, or Drive link)
2. Confirm: number of siblings simultaneously enrolled in college, divorce status, state of residency
3. Output: standardized comparison, true net cost calculation, appeal leverage flags
4. Output goes to file. Confirm path after saving.

## Minimum Requirements Before Starting

Do not produce any output until:

- Award letter data for at least one school provided (two or more required for comparison output)
- Each letter's total Cost of Attendance (COA) confirmed â or individual components if COA is not stated in the letter
- Aid breakdown confirmed: what is gift aid vs. loan vs. work-study for each school
- Student's state of residency confirmed (affects in-state vs. out-of-state classification)
- Number of siblings simultaneously enrolled in college confirmed (affects FM Expected Contribution calculation)

If COA is missing from any letter: ask Pearl to supply it before calculating net cost for that school. Do not estimate from external sources without Pearl's explicit instruction and a prominent flag on the estimate.

## Core Workflow

### Step 1 â Decode Each Award Letter

Every award letter must be decoded into standardized components before comparison. Schools use different terminology â this step eliminates the naming confusion.

**For each school, extract:**

**Cost of Attendance (COA)**
- Tuition and fees
- Room and board (on-campus vs. off-campus â flag which)
- Books and supplies
- Personal expenses and transportation
- Total COA

If a school omits any COA component, flag it. A letter showing only tuition with no room/board is incomplete â total cost is higher than the letter implies.

**Aid Package Breakdown â Categorize Every Line Item**

| Aid Category | What It Is | How to Identify |
|-------------|------------|-----------------|
| **Gift Aid â No Repayment** | Institutional grants, merit scholarships, need-based grants, state grants, outside scholarships | "Grant," "Scholarship," "Award," school name + "Grant" |
| **Self-Help Aid â Loans** | Must be repaid with interest | "Loan," "Direct Subsidized," "Direct Unsubsidized," "PLUS," "Perkins" |
| **Self-Help Aid â Work-Study** | Earned through employment, not guaranteed | "Work-Study," "Federal Work-Study," "Campus Employment" |
| **Outside Aid** | Scholarships from sources other than the school | Student lists these; schools may or may not include in the award letter |

**Common Naming Confusion Pearl Encounters:**

- "University Grant" = gift aid (free money). Some schools name institutional grants after themselves â "Vanderbilt Opportunity Grant," "Notre Dame University Grant" â these are all free money regardless of name.
- "Stafford Loan" = loan. Some letters present this without the word "loan" prominently. Flag these.
- "Parent PLUS Loan" = parent loan. Some schools include this in the aid package as if it's a benefit â it is a liability, not an award. Flag it separately and exclude it from net cost calculation unless Pearl specifies otherwise.
- "Work-Study" = potential earnings, not guaranteed cash. Must be earned. Some families confuse it with a grant.

### Step 2 â Calculate True Net Cost

For each school:

```
TRUE NET COST = COA â Gift Aid Only (grants + scholarships)
```

Do NOT subtract loans or work-study from net cost in the primary calculation. They are not free money. Show them separately.

**Show the full math for each school:**

```
[School Name]
COA:                          $[X]
  - Institutional grants:     $[X]
  - Merit scholarships:       $[X]
  - State grants:             $[X]
  - Outside scholarships:     $[X]
âââââââââââââââââââââââââââââââââ
TRUE NET COST:                $[X]

Remaining gap (loans/work-study available):
  - Subsidized loans:         $[X]
  - Unsubsidized loans:       $[X]
  - Work-study:               $[X]
  - Parent PLUS (if listed):  $[X] [FLAG: This is a parent loan, not aid]
âââââââââââââââââââââââââââââââââ
Total if family takes all loans: $[X] out of pocket this year
4-year loan burden (estimate):   $[X] [Show math: loan amounts Ã 4, flag this is an estimate]
```

### Step 3 â Standardized Comparison Table

After calculating all schools:

---

**FINANCIAL AID COMPARISON â [Student Name]**
**Prepared by:** Pearl Lockwood, Lockwood College Prep
**Date:** [Date]

| | [School A] | [School B] | [School C] | [School D] |
|---|---|---|---|---|
| **Total COA** | $X | $X | $X | $X |
| **Gift Aid Total** | $X | $X | $X | $X |
| â Institutional Grants | $X | $X | $X | $X |
| â Merit Scholarships | $X | $X | $X | $X |
| â State Grants | $X | $X | $X | $X |
| **TRUE NET COST** | **$X** | **$X** | **$X** | **$X** |
| **Loans Offered** | $X | $X | $X | $X |
| â Subsidized | $X | $X | $X | $X |
| â Unsubsidized | $X | $X | $X | $X |
| **Work-Study** | $X | $X | $X | $X |
| **Parent PLUS** | $X | $X | $X | $X |
| **Meets Financial Need?** | [Y/N/Partial] | [Y/N/Partial] | [Y/N/Partial] | [Y/N/Partial] |
| **Gap (unfunded need)** | $X | $X | $X | $X |

**Ranked by True Net Cost (lowest to highest):**
1. [School] â $[Net Cost]
2. [School] â $[Net Cost]
3. [School] â $[Net Cost]

---

### Step 4 â Flag Appeal Leverage

This is where Pearl's expertise converts into strategy. After comparison, identify and flag:

**Head-to-Head Leverage Opportunities**
When two schools of comparable academic quality, type, and prestige have significantly different net costs:
- "School A and School B are both [LAC / Ivy-comparable / regional private]. School A's net cost is $8,200 less than School B. This gap is material and School B is likely to match or narrow it if appealed with School A's offer."
- Flag schools where the student is clearly a strong admit (merit scholarship received) â those schools have the most incentive to increase aid to close a competing offer.

**Special Circumstances Pearl Should Surface**
If Pearl has family context that was NOT included in the original FAFSA/CSS filing, flag these as potential appeal grounds:
- Job loss or income reduction since base year
- Business income fluctuation (S-Corp, partnership â IM schools often misread business income as higher than actual available cash)
- High unreimbursed medical expenses
- Private K-12 tuition for younger siblings (some schools factor this in IM)
- Pending divorce or separation (different from existing divorce)

**Unmet Need Flags**
If a school's award leaves a significant gap (more than $5,000 between net cost and what a family earning their income would reasonably pay), flag it:
- "School C's award meets only 74% of demonstrated need. This is below Pearl's experience threshold for this income bracket. An appeal citing [competing offer / special circumstances] may be warranted."

**Red Flags in the Award Letters**
- Large Parent PLUS loan included as if it's an award â flag and recommend Pearl clarify with family that this is a loan they take, not money they receive
- No subsidized loans despite demonstrated need â may indicate the school ran the calculation differently
- Work-study amount much higher than typical ($4,000+) â this requires the student to work significant hours; note this as a financial plan dependency
- Award letter with no term-by-term breakdown â ask Pearl whether the school confirmed the award renews each year and under what GPA/enrollment conditions

### Step 5 â 4-Year Projection (When Requested)

When Pearl requests a longer view:

```
4-YEAR FINANCIAL PROJECTION â [School Name]

Assumptions:
- COA increases 3% annually (flag: this is an estimate â actual varies)
- Merit award: [Renewable at same amount / Subject to GPA requirement of X / One-time only]
- Loans taken each year: [Amount Ã 4]
- Work-study: [Excluded from projection â not guaranteed earned income]

Year 1:  COA $X  â  Net Cost $X  â  Loan $X
Year 2:  COA $X  â  Net Cost $X  â  Loan $X
Year 3:  COA $X  â  Net Cost $X  â  Loan $X
Year 4:  COA $X  â  Net Cost $X  â  Loan $X

4-Year Total Net Cost:          $X
4-Year Total Loan Burden:       $X
4-Year Total Gift Aid Received: $X

NOTE: This projection assumes [state assumptions clearly]. Confirm with school whether merit award is renewable and under what conditions.
```

## When To Use This Skill

- March-April: Every family with award letters needs this analysis
- When a family asks "which school is really cheaper?"
- Before Pearl writes an appeal letter â the comparison identifies the leverage
- When a family is confused about the difference between their "award" and their actual bill
- When Christine needs to summarize award letters before Pearl's call with the family

## Failure Modes and Required Responses

| Situation | Required Response |
|-----------|------------------|
| COA missing from a letter | Ask Pearl to supply it before calculating net cost. Do not proceed with estimated COA. |
| Letter does not specify if aid is a grant or loan | Flag: "Aid type unclear for [item] at [school] â Pearl to classify before net cost is finalized." |
| Parent PLUS appears in award package | Flag immediately as: "PARENT PLUS LOAN â $[X] â This is a parent liability at [rate]%, NOT an award. Excluded from net cost calculation." |
| Merit award has no renewability statement | Flag: "Renewability not stated â verify with [school] before advising family on 4-year cost." |
| Pearl asks for a 4-year projection with missing renewal data | Produce the projection with explicit assumptions noted and flag each assumption individually. Do not omit the projection â flag its uncertainty clearly. |
| Work-study listed in the package | Present as "Work-Study Offer: $[X] â must be earned through qualifying campus employment. Not guaranteed income. Excluded from true net cost." |

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Combine loans with gift aid in a "total aid" figure | Separate gift aid from self-help in every calculation |
| Present Parent PLUS as an award | Flag as parent liability, exclude from net cost |
| Subtract work-study from net cost | Show work-study separately â it's potential earnings, not guaranteed |
| Present net cost without showing the full math | Always show COA minus gift aid line by line |
| Use estimated COA from external sources without flagging | Ask Pearl for actual COA or flag the estimate prominently |
| Present merit aid without renewability conditions | Always state renewal terms or flag as "Unknown â verify" |

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns section (Gauntlet QA pass)

## Save Location

`[Pearl's Vault]/Clients/[Student Last Name]/Award-Letter-Comparison-[Year].md`
