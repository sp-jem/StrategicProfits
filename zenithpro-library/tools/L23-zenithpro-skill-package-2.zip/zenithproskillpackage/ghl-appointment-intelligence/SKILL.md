---
name: ghl-appointment-intelligence
description: Generates a complete pre-meeting intelligence brief for an upcoming GHL appointment â contact history, conversation summary, open opportunities, known objections, and a call strategy â so you walk in fully prepared instead of scrambling. Use before any scheduled call, demo, sales conversation, or client meeting. Trigger phrases: "prep for my call," "meeting brief," "appointment intelligence," "pre-call prep," "who am I talking to," "what do I know about this contact," "call strategy," "brief me on this appointment," "prep me for my meeting," "what's their history."
license: proprietary
metadata:
tags:
  - program/ctd
  - ghl
  - appointments
  - intelligence
---
# GHL Appointment Intelligence

## Purpose

Pulls everything GHL knows about a contact scheduled for an upcoming appointment â profile, conversation history, open opportunities, past interactions â and synthesizes it into a pre-meeting brief with a recommended call strategy, so the rep walks in with context instead of cold.

## Instructions

### Step 1 â Locate the Appointment

**Option A â Known appointment ID:**
Call `get_appointment` directly with the appointment ID.

**Option B â Find upcoming appointments:**
Call `get_calendar_events` to retrieve today's and tomorrow's scheduled events. Present a list:

| # | Contact Name | Time | Calendar | Duration |
|---|-------------|------|----------|----------|
| 1 | [Name] | [Time] | [Calendar] | [Min] |

Ask: "Which appointment should I prep for?" NEVER proceed without confirmation.

Extract from the appointment:
- Contact name and ID
- Appointment date, time, and duration
- Meeting type / calendar name
- Notes added at booking time
- Assigned rep

### Step 2 â Pull Full Contact Profile

Call `get_contact` with the contact ID from the appointment.

Extract:
- Name, email, phone
- Source / how they found you
- All current tags
- Custom qualification fields (budget, company, role, program interest, etc.)
- Created date (how long in your system)
- Assigned owner
- Current pipeline stage

Note any qualification fields that are empty â these become questions to ask on the call.

### Step 3 â Pull Conversation History

Call `search_conversations` to find the contact's conversation thread.

Call `get_recent_messages` to retrieve the last 15-20 messages.

Analyze and record:
- Number of total exchanges
- Who initiated contact
- How long they've been engaging
- Date of first contact vs. date of appointment (time-to-book signal)
- Most recent message and when it was sent
- Tone trajectory: Did they start cold and warm up? Always warm? Show signs of hesitation recently?
- Any specific questions they asked about price, timeline, process, or outcomes
- Any objections or concerns raised in messages
- Any specific language they used about their situation, goals, or pain points (capture verbatim where possible)

### Step 4 â Pull Open Opportunities

Call `search_opportunities` to find all active or recent opportunities for this contact.

For each opportunity found, record:
- Opportunity name
- Current stage
- Value (if set)
- Created date
- Days in current stage (calculate: today minus stage entry date)
- Last activity on the opportunity

If multiple opportunities exist, present all of them. Flag any that have been stalled for more than 14 days.

### Step 5 â Synthesize the Brief

Produce the full pre-meeting intelligence brief. NEVER collapse this into a paragraph. Structure is required so the rep can scan it in under 2 minutes before the call.

---

## Pre-Meeting Intelligence Brief

**Contact:** [Full Name]
**Appointment:** [Date] at [Time] ([Duration])
**Calendar / Meeting Type:** [Name]
**Assigned Rep:** [Name]
**Brief prepared:** [Today's date]

---

### Contact Snapshot

| Field | Value |
|-------|-------|
| Source | [How they found you] |
| In system since | [Date] ([X days/weeks/months]) |
| Stage | [Current pipeline stage] |
| Tags | [All current tags] |
| Time to book | [Days from first contact to this appointment] |

### Relationship History
- **First contact:** [Date and channel]
- **Total exchanges:** [#] messages over [timeframe]
- **Engagement pattern:** [Active / Sporadic / Went quiet then re-engaged / etc.]
- **Tone:** [Warm / Cautious / Skeptical / Enthusiastic â explain briefly]
- **Last message:** [Date] â [1-sentence summary of what was said]

### What They've Told You (Their Words)

Pull exact or near-exact phrases the contact used about their situation, goals, pain, or desires. These are conversation anchors.

- "[Quote 1 â their situation or pain]"
- "[Quote 2 â their goal or desire]"
- "[Quote 3 â specific question or objection if any]"
- [Add more as found, or "No specific language captured â early stage contact"]

### Open Questions They Haven't Answered

[List qualification fields that are still empty and need to be answered on this call]
- [ ] [Field 1 â e.g., "Budget range not captured"]
- [ ] [Field 2]
- [or "None â profile fully qualified"]

### Active Opportunities

| Opportunity | Stage | Value | Days in Stage | Status |
|-------------|-------|-------|--------------|--------|
| [Name] | [Stage] | $[X] | [#] days | [On track / STALLED] |

[If no opportunities: "No open opportunity on record. Create one after this call if they're a sales contact."]

### Known Objections or Concerns
[List each objection raised in conversation, or "None raised in prior messaging"]

### Buying Signals Detected
[List each positive signal â questions about pricing, timeline, onboarding, "what happens after," references to urgency]
[or "None detected in conversation history"]

---

### Call Strategy

**Objective for this call:**
[State the single most important outcome this call needs to produce: Discovery complete / Demo delivered / Objection resolved / Verbal yes / Next step booked / etc.]

**Open with:**
[Specific, personalized opener based on their last message or stated situation. NEVER suggest "great to meet you" or "how are you" as the opening. Reference something specific.]

**Key questions to ask:**
[List 3-5 questions prioritized by: fill qualification gaps first, then deepen understanding of their situation]

1. [Question targeting empty qualification field or unknown pain]
2. [Question to deepen understanding of stated goal]
3. [Question to surface objections before they surface themselves]
4. [Question about decision process / timeline if not captured]
5. [Question about desired outcome from this call]

**Objection preparation:**
[For each known objection, one-sentence handling approach]
- [Objection]: [Approach]
- [or "No prior objections â monitor for: price, timing, authority to decide"]

**Red flags to watch for:**
[Based on their history and tone, what signals suggest this call is going sideways]

**How to close this call:**
[Specific recommended next step to propose at the end of this call. Not "let me know if you have questions" â a concrete action with a time attached.]

---

## Constraints

- NEVER produce a brief without pulling live GHL data. Assumptions create false confidence â they are prohibited.
- ALWAYS include verbatim quotes from the contact where they exist. This is the most valuable part of the brief â do not summarize away their actual words.
- NEVER omit the Call Strategy section. A contact summary without a call strategy is half the work.
- ALWAYS flag stalled opportunities (14+ days in stage). These need to move or be cleaned up.
- NEVER suggest a generic opener. The opening must reference something specific to this contact â their last message, stated situation, or booking reason.
- ALWAYS list empty qualification fields as questions to ask. If all fields are complete, state "None â profile fully qualified."
- NEVER mark buying signals as present unless they appear in the actual conversation history. Do not infer them from source tags alone.
- ALWAYS state the single objective for the call. A call with no defined objective rarely closes.
- If the appointment is in less than 30 minutes, prioritize speed: deliver the brief immediately, even if some data is incomplete. Flag what's missing.
- NEVER include data from other contacts in this brief. One brief per contact, always.
- NEVER proceed past Step 1 without the rep confirming which appointment is being prepped. Multiple appointments on the same day require explicit selection.
- ALWAYS confirm the assigned rep before delivering the brief. A brief prepared for the wrong rep is a privacy and accuracy failure â state the rep's name in the brief header.
- NEVER fabricate conversation quotes. If no verbatim language is available, state: "No specific language captured â early stage contact."

## Reference

**MCP Server:** BusyBee3333 GHL MCP

**Tools used in this skill:**
- `get_calendar_events` â Find today's and tomorrow's scheduled appointments
- `get_appointment` â Retrieve appointment details by ID
- `get_contact` â Pull full contact profile
- `search_conversations` â Find conversation thread for the contact
- `get_recent_messages` â Pull last 15-20 messages from conversation
- `search_opportunities` â Find all open opportunities for this contact

**Configuration required:**
- Calendar ID(s) must be configured in GHL MCP to pull events (ask user for their primary calendar ID if not pre-configured)
- Opportunity pipeline names and stages should match GHL account setup

**Failure Modes:**

MCP not connected: "GHL MCP server is not responding. Cannot retrieve appointment or contact data. If you have notes from prior interactions, paste them here and I can produce a partial brief from what you provide."

Appointment not found: "No appointment found for [identifier]. Check the appointment ID or confirm the contact name and I'll search calendar events."

No conversation history found: "No conversation history found for this contact. They may have booked without prior messaging. Brief is built on profile data only â treat this as a cold call prep. Recommended: open with discovery-first questions."

Contact not in GHL: "Contact profile not found in GHL for this appointment. The booking may have been from an external source. Ask the contact to confirm their details at the start of the call and create a GHL contact afterward."

Multiple contacts match: List all matches and require user confirmation before pulling data.
