---
name: trolley-analytics
description: Complete Trolley (payout platform) analytics for Strategic Profits. Query payment batches, recipient payouts, account balances, and payout history. Use for affiliate/contractor payment tracking, payout reports, and financial reconciliation.
---

# Trolley Analytics Skill

## Overview

Full-access analytics for the Strategic Profits Trolley account. Provides:
- Payment batch summaries and status tracking
- Individual payout details by recipient
- Account balance monitoring across currencies
- Historical payout reports by period
- Recipient/payee management insights
- Fee analysis by payout method

## Quick Commands

| Query | What It Does |
|-------|--------------|
| "Yesterday's payouts" | Full summary of previous day's payments |
| "Pending batches" | All batches awaiting processing |
| "This month's payouts" | Month-to-date payout summary |
| "Trolley balance" | Current account balances by currency |
| "Payments to [recipient]" | Payment history for specific recipient |
| "Failed payments this week" | Payment failures and reasons |
| "Payout fees breakdown" | Fee analysis by payment method |

## How To Use

### Daily Payout Report
```
"Generate yesterday's Trolley payout report"
```

Returns:
- Total payouts (count and amount)
- Payments by status (completed, pending, failed)
- Breakdown by payout method (bank, PayPal)
- Top payouts list
- Failed payment summary with reasons

### Batch Status
```
"Show pending Trolley batches"
"What batches were processed this week?"
```

### Recipient Lookup
```
"Show payments to [name/email]"
"List all active recipients"
```

### Balance Check
```
"What's our Trolley balance?"
"Show available funds by currency"
```

### Period Comparisons
```
"Compare this month's payouts to last month"
"How much did we pay out last quarter?"
```

## API Access

This skill uses the Trolley API with these endpoints:

| Endpoint | Purpose |
|----------|---------|
| `/v1/balances` | Account balances by currency |
| `/v1/batches` | Payment batch data |
| `/v1/batches/:id/payments` | Payments within a batch |
| `/v1/batches/:id/summary` | Batch fee breakdown |
| `/v1/recipients` | Recipient/payee list |
| `/v1/recipients/:id/payments` | Payments to specific recipient |

## Configuration

**API Credentials Location:** `~/.claude/skills/trolley-analytics/references/config.json`

Required credentials:
- `access_key` - Trolley API Access Key
- `secret_key` - Trolley API Secret Key

Get these from: Trolley Dashboard â Settings â API Keys

## Authentication

Trolley uses HMAC-SHA256 signature authentication:
- Signature computed from: `timestamp + method + path + body`
- Sent via `Authorization: prsign ACCESS_KEY:SIGNATURE` header

The script handles this automatically.

## Output Formats

The skill can output in multiple formats:
- **Summary** - Quick overview with key metrics
- **Detailed** - Full payment list with recipient info
- **JSON** - Raw data for programmatic use
- **Comparison** - Side-by-side period analysis

## Metrics Available

### Payout Metrics
- Total payout amount by period
- Payment count (successful/pending/failed)
- Average payout size
- Payouts by method (bank transfer, PayPal)
- Fee totals and breakdown

### Batch Metrics
- Batch count and status
- Processing time
- Completion rate

### Recipient Metrics
- Active recipient count
- Payments per recipient
- Top recipients by volume
- Recipient status (active, pending compliance)

### Financial Metrics
- Available balance by currency
- Pending payouts
- Fee costs by method
- Currency conversion costs
