---
name: ghl-personalized-followup
description: Write stage-appropriate, history-aware follow-up messages for GoHighLevel contacts â grounded in their actual conversation history, not generic templates. Trigger when someone says "write a follow-up," "follow up with this lead," "draft a message for this contact," "what should I send to," "check their history and follow up," "personalized outreach," "write an SMS for," "draft an email to," "follow-up sequence," or any request to craft outreach grounded in a specific contact's GHL history.
license: proprietary
metadata:
tags:
  - program/ctd
  - ghl
  - followup
---
# GHL Personalized Follow-Up

## Purpose

Retrieve a contact's complete history from GoHighLevel â messages, conversations, tags, stage â and produce stage-appropriate, history-aware follow-up messages that reference what actually happened, not generic copy. Eliminates "just checking in" outreach by grounding every message in real data.

## Instructions

### Step 1 â Locate the Contact

Call `search_contacts` with the provided name, email, or phone.

If one match is returned, proceed. If multiple matches are returned, display them in a table and ask the operator to confirm which contact before proceeding.

```
CONTACT SEARCH RESULTS
Contact found: [N] match(es)

| ID | Name | Email | Phone | Tags |
|----|------|-------|-------|------|
| [id] | [name] | [email] | [phone] | [tags] |
```

### Step 2 â Build Contact Intelligence Profile

Call `get_contact` to retrieve full contact data.

Then call `search_conversations` to find all conversations linked to this contact.

Then call `get_recent_messages` on the most recent active conversation to pull the message thread.

Build the Contact Intelligence Profile:

```
CONTACT INTELLIGENCE PROFILE
==============================
Name:           [full name]
Email:          [email]
Phone:          [phone]
Tags:           [all tags]
Pipeline Stage: [stage if in opportunity, else "not in pipeline"]
Created:        [date]
Last Updated:   [date]

CONVERSATION HISTORY:
  Total conversations: [N]
  Most recent: [date] via [channel: SMS / Email / Call]
  Last message sent by: [Contact / Agent]
  Last message: "[excerpt â first 100 chars]"
  Days since last contact: [N]

TAGS CONTEXT:
  [List all tags â flag any that indicate status: e.g., "purchased," "no-show," "objection-price"]
```

If no conversation history exists: "No prior conversations found. This is a cold outreach â treat accordingly."

### Step 3 â Classify Follow-Up Stage

Based on the Contact Intelligence Profile, classify the follow-up type:

| Stage Type | Trigger Conditions |
|-----------|-------------------|
| **Cold â First Touch** | No prior conversation |
| **Warm â Re-engage** | Last contact 14+ days ago, conversation ended without reply |
| **Active â Next Step** | Recent conversation (0-13 days), last message was from Agent, awaiting response |
| **Post-Purchase â Onboard** | Tags include purchase/enrolled indicator |
| **Objection â Recover** | Tags or messages indicate price/timing/competitor objection |
| **Win-Back** | Lost or gone dark 30+ days |

State the classified stage clearly before writing any copy. NEVER write copy before the stage is classified.

### Step 4 â Determine Channel

If the operator specified a channel (SMS / Email), use that.

If not specified, recommend based on history:
- Last interaction was SMS â recommend SMS
- Last interaction was email â recommend email
- No history â recommend email + SMS pair
- Tags indicate phone-preferred â note this

State the recommended channel and reason: "Recommending [channel] because [reason]."

### Step 5 â Write the Follow-Up Message(s)

Produce one message per recommended channel. Rules:

**All messages must:**
- Open with a specific reference to the last interaction or a known fact about the contact
- State a clear, single next step (not "let me know if you have questions")
- Match the tone implied by prior conversation â if they were casual, be casual; if formal, be formal
- Be written as if the operator is sending it personally, not as a broadcast

**Email format:**
```
EMAIL FOLLOW-UP DRAFT
Subject: [specific subject â no "Following up on our conversation"]
Preview text: [preview]

Body:
[full email â 4-8 sentences, direct, no filler, specific reference to history in sentence 1]

Signature: [Operator name]
```

**SMS format:**
```
SMS FOLLOW-UP DRAFT
Message: [full SMS â 160 chars max]
Character count: [N] / 160
Reference to history: [one-phrase description of what this references]
```

REQUIRED â after each draft, state:
**Why this angle:** [1 sentence explaining why this specific approach is right for this contact's stage and history]

### Step 6 â Confirmation Gate

Display the complete send plan before any message is dispatched:

```
SEND PLAN
==========
Contact:    [name] (ID: [id])
Channel(s): [Email / SMS / Both]
Stage:      [follow-up stage type]

[Full message(s) as drafted in Step 5]

---
CONFIRM SEND? (yes / no / edit)
```

NEVER proceed past this block until the operator confirms. If the operator says "edit," capture the changes and re-display the updated draft before sending.

### Step 7 â Send

After confirmation:
- Email: call `send_email` with the contact ID and template or inline content
- SMS: call `send_sms` with the contact ID and message body

Log the result:

```
SEND RESULT
============
Contact:    [name] (ID: [id])
Email:      [Sent / Failed â reason if failed]
SMS:        [Sent / Failed â reason if failed]
Sent at:    [timestamp]
```

### Step 8 â Optional Task Creation

After send, offer: "Want me to create a follow-up task on this contact to check for a response in [X] days?"

If yes, use `create_contact_task` via the ghl-crm-operator skill (or directly if accessible). Set due date to today + the interval the operator specifies.

## Constraints

- NEVER draft a follow-up without pulling conversation history first. History-free messages are prohibited â they are templates, not follow-ups.
- NEVER use "just checking in," "just following up," "touching base," or "circling back" â in any message, for any contact, at any stage. These phrases are prohibited output.
- ALWAYS classify the follow-up stage (Step 3) before writing copy â the stage drives tone, urgency, and angle. Copy written before stage classification is rejected output.
- NEVER send without showing the full send plan (Step 6) and receiving explicit confirmation.
- ALWAYS include a specific reference to the contact's history or situation in the first sentence of every message. Generic openers are prohibited.
- NEVER write a closing message with an open-ended CTA like "let me know if you're interested." Every message must contain a specific next step with a concrete action.
- ALWAYS enforce the 160-character SMS limit. Rewrite to fit â do not warn without fixing.
- NEVER recommend sending both email and SMS simultaneously without flagging that this may feel like over-contact. Let the operator choose to use both.
- ALWAYS display days-since-last-contact in the Contact Intelligence Profile. This number drives urgency calibration.
- NEVER fabricate conversation history or message excerpts. All history data must come from live MCP calls to `search_conversations` and `get_recent_messages`.
- NEVER proceed past Step 1 if the contact cannot be confirmed. If multiple matches exist, require operator selection before pulling history.
- NEVER classify stage without inspecting both the tags and the conversation history. Tags alone are insufficient â a contact tagged "hot-lead" with 30-day-old last contact is WARM, not Active.
- ALWAYS state the "Why this angle" rationale after each message draft. A draft without rationale is incomplete output.

## Reference

**MCP Tools Used:**
- `search_contacts` â Locate the target contact by name, email, or phone
- `get_contact` â Retrieve full contact record including tags and pipeline stage
- `search_conversations` â Find all conversations linked to this contact
- `get_recent_messages` â Pull the message thread from the most recent conversation
- `send_sms` â Send an SMS message to the contact
- `send_email` â Send an email to the contact

**Configuration Requirements:**
- GHL MCP server (BusyBee3333) must be connected and authenticated
- GHL Location ID must be configured in the MCP server
- SMS sending requires a GHL phone number provisioned for the location
- Operator must have conversation read and message send permissions in GHL

**Failure Modes:**

MCP not connected: State: "GHL MCP server is not responding. Contact history cannot be retrieved. No follow-up message should be drafted without real history data."

Contact not found: State: "No contact found matching '[query].' Check spelling, try email or phone instead of name, or create the contact first using ghl-crm-operator."

Multiple contacts with same name: List all matches. Do not pick one. Ask: "Which [Name] did you mean?" before proceeding.

No conversation history found: State: "No prior conversations found for [name]. Classifying as Cold â First Touch. The follow-up will be introductory, not referential." Proceed with cold outreach framing.

`get_recent_messages` returns empty thread: Note: "Conversation record exists but message thread is empty â the conversation may have been created manually without messages." Use contact tags and stage as context instead.

Send fails (email or SMS): Report the failure explicitly. Do not mark the follow-up as complete. "SMS send to [name] failed: [reason]. Verify the phone number is valid and SMS is enabled for this location."

Contact has no phone number (SMS requested): State: "No phone number on file for [name]. SMS cannot be sent. Recommend email or ask the operator to add the phone number first."

**Output Format:**

Every follow-up run produces, in order:
1. **Contact Search Results** â match count, table of matches
2. **Contact Intelligence Profile** â full data snapshot including history summary
3. **Follow-Up Stage Classification** â explicit stage type with reasoning
4. **Channel Recommendation** â with rationale from history
5. **Message Draft(s)** â full copy per channel with "Why this angle" note
6. **Send Plan with Confirmation Gate** â full send details, requires approval
7. **Send Result Log** â success/failure per channel with timestamp
8. **Task Creation Offer** â optional follow-up scheduling
