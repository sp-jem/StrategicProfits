# Extraction Schema v1.0

## The 18 Extraction Categories

Every article is processed against ALL 18 categories in a single pass. Most articles will produce extractions in 3-8 categories. An empty category is normal â not everything applies everywhere.

---

### 1. Distinctions
**What:** Perceptual shifts â binary A/B framings that permanently change what you see.
**Format:** Use the Distinction Finder format (A side, B side, cost, gain, 6-filter qualification).
**Note:** Low yield from clippings (~0.24 per 1K lines). When they appear, they're valuable. Don't force it.

### 2. Proof Arsenal
**What:** Statistics, ROI numbers, case studies with specific measurable results.
**Format:** `[Claim it supports] â [Specific proof point] â [Source attribution within article]`
**Example:** "AI as operations, not experiment" â "Golf courses saw 25% revenue lift from dynamic pricing AI, 40% labor reallocation from autonomous mowers" â Golf Courses article, lines 34-41

### 3. Stories & Examples
**What:** Teaching-ready narratives with setup, tension, and resolution. Must be usable standalone.
**Format:** `[Setup] â [Tension/Wrong Move] â [Resolution/Reveal] â [What it illustrates]`
**Example:** "Hiring manager evaluates candidate â Passes because of missing product training â Another founder hires them with 'Special' mandate â They become VP in a few years" â Illustrates: coachable skills vs rare spikes

### 4. Quotable Lines
**What:** Sentences worth stealing for email subjects, slide headers, social posts, webinar openings.
**Format:** Exact quote with source. Note suggested use (subject line, slide header, etc.).
**Example:** "The question is not whether you can afford to deploy this. The question is whether you can afford to price manually while your competitors do not." â Use: webinar transition to offer

### 5. Market Language Map
**What:** Terms the market uses for things Rich teaches under different names.
**Format:** `[Market term] = [Rich's term] â [Where this mapping is useful]`
**Example:** "Context engineering" = Rich's "skill architecture" â Useful in FM webinar to bridge audience vocabulary

### 6. Wrong Advice / Contrast Ammo
**What:** Advice the market gives that Rich disagrees with or considers incomplete. The worse the advice, the more valuable.
**Format:** `[What they say] â [What's actually true] â [How Rich can use this]`
**Example:** "Learn these 7 AI skills for 2026" â Most are tool-level skills that won't matter in 6 months â FM email opener: "You've seen the listicles. Here's what they leave out..."

### 7. Curriculum Ingredients
**What:** Concepts, frameworks, or content that could become part of a lesson, exercise, or module in one of Rich's programs. Not the article itself â the teachable material within it.
**Format:** `[Concept] â [How it could be taught] â [Which program/module]`
**Example:** "6 components of context engineering" â Could become a FM hands-on workshop where teams map their own context stack â FM Day 4-5 (team sessions)

### 8. Student Resource Candidates
**What:** Articles that students should actually READ â not mined for parts, but handed to students as-is or lightly annotated.
**Format:** `[Article title] â [What student gets from reading it] â [Which program, which stage]`
**Tag with specific beginner track if applicable (see Category 18).**

### 9. Tool/Plugin/Setup Intelligence
**What:** Specific tools, plugins, configurations, settings, or technical recommendations mentioned.
**Format:** `[Tool/Plugin name] â [What it does] â [Relevance to which program's setup]`
**Example:** "Obsidian plugin: Dataview" â Enables dynamic queries across vault â FM student vault setup

### 10. Workflow Examples
**What:** Step-by-step processes someone describes for accomplishing something with AI or related tools.
**Format:** `[Task] â [Steps described] â [How this informs Rich's program design]`
**Example:** "Boris Cherny's Claude Code workflow: spec first, let Opus run, review output" â Informs FM demonstration design â show this workflow live

### 11. Mistakes & Anti-Patterns
**What:** What NOT to do, from real examples. Failed approaches, common pitfalls, cautionary tales.
**Format:** `[The mistake] â [Why it fails] â [What to do instead] â [Teaching use]`
**Example:** "Company rolled out AI to all departments simultaneously" â No density, no champions, adoption collapsed â Start with one team at 50%+ adoption â FM Day 2 teaching point

### 12. Trend Signals
**What:** The FACT that this article exists as a signal of where the conversation is heading. Not the content â the metadata.
**Format:** `[Trend] â [Evidence from this article] â [What it means for Rich's programs]`
**Example:** "Market shifting from 'prompt engineering' to 'context engineering'" â Third article this week using the term â FM positioning is ahead of this curve

### 13. Analogies & Metaphors
**What:** Useful ways of explaining complex concepts. Good analogies are rare and valuable for teaching.
**Format:** `[Complex concept] â [Analogy/metaphor] â [Where Rich could use this]`
**Example:** "AI adoption is like hiring â the question isn't 'can they do the job?' it's 'can they do the job HERE?'" â FM webinar, explaining why generic AI training fails

### 14. Objection Evidence
**What:** Specific evidence against specific objections Rich's programs face.
**Format:** `[Objection] â [Counter-evidence from this article] â [Which program]`
**Tag with the specific objection it counters.**
**Common objections:** "My industry is different" / "It's too early" / "It's too complicated" / "AI will replace my team" / "I tried AI and it didn't work" / "My team won't adopt it"

### 15. FAQ/Support Content
**What:** Articles that answer questions students will ask during or after programs.
**Format:** `[Question it answers] â [Summary of answer] â [Which program, which stage]`
**Example:** "How do MCP servers work?" â Article explains the architecture simply â FM pre-work FAQ

### 16. People to Watch
**What:** Authors writing smart things in Rich's space. Not for partnership â for awareness.
**Format:** `[Name] â [What they write about] â [Why Rich should know them]`

### 17. Rich's Learning Queue
**What:** Articles that would genuinely help Rich improve how he works with Claude and AI, based on the growth areas identified in "What Rich Needs to Learn About Claude."
**Filter:** Only flag articles that address Rich's ACTUAL growth areas (session management, specification discipline, building-as-product mindset, execution architecture). Do NOT flag generic "AI tips" content.
**Format:** `[Growth area it addresses] â [What the article offers] â [Recommended action: read in full / skim section X / extract key point]`
**Reference:** `~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/00 Projects/What-Rich-Needs-To-Learn-About-Claude.md`

### 18. Beginner Resources
**What:** Articles useful for onboarding students who are new to specific tools or concepts. Broken into four tracks:

| Track | Tag | What to flag |
|-------|-----|-------------|
| **Obsidian Onboarding** | `beginner:obsidian` | Setup guides, plugin recommendations, vault organization, workflow examples, beginner tutorials, tips and tricks |
| **Claude Code Onboarding** | `beginner:claude-code` | Getting started, first-session walkthroughs, CLAUDE.md templates, common commands, MCP basics, skill creation |
| **AI Fundamentals** | `beginner:ai-fundamentals` | What is an LLM, tokens, context windows, prompting basics â for team members starting from zero |
| **Tool Setup** | `beginner:tool-setup` | Node.js installation, terminal/command line basics, Git fundamentals, package managers â technical prerequisites |

**Format:** `[Track] â [Article title] â [What a beginner gets from it] â [Which program's students need this]`

**Program mapping:**
- FM students: All 4 tracks (teams may include non-technical members)
- Zenith Mind OS students: AI Fundamentals + Obsidian
- ZenithPro students: AI Fundamentals + Claude Code (for marketing automation)
- CTD students: Obsidian (for dot-connecting workflow)
- Consult clients: Claude Code + Tool Setup (for implementation sessions)

---

## Program Tags

Every extraction gets tagged with program relevance:

| Tag | Program |
|-----|---------|
| `FM` | Force Multiplier |
| `ZMOS` | Zenith Mind OS |
| `ZP` | ZenithPro |
| `CTD` | Connect the Dots to Riches |
| `1:1` | One-on-One AI Consults |
| `ALL` | All programs |

Multiple tags allowed. Most extractions will be tagged to 1-2 programs.

---

## Output Structure

Each processed article produces one extraction card:

```markdown
# Clipping Extraction: [Article Title]

**Source:** [filename in Clippings folder]
**Date processed:** [date]
**Date clipped:** [if determinable from file metadata]
**Word count:** [approximate]
**Primary classification:** [Why Rich likely clipped this â 1-2 sentences]
**Program relevance:** [FM / ZMOS / ZP / CTD / 1:1 / ALL]

---

## Extractions

### [Category Name] (only categories with actual extractions)

[Structured extraction per the format above]

---

*Categories with no extractions are omitted, not listed as empty.*
```
