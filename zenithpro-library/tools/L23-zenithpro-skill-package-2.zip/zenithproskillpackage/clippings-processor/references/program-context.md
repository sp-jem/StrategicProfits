# Program Context â What Each Program Needs from Clippings

## Force Multiplier (FM)
**What it is:** 10-day, half-day-per-day live training for entrepreneurs AND their teams. Teaches business owners to clone their expertise into AI systems that multiply their team's capability.
**Date:** March 24 - April 5, 2026
**Audience:** Entrepreneurs who already know AI is important but haven't operationalized it for their teams.
**Key themes:** Team multiplication (not solo productivity), expertise cloning, AI as operations (not experiment), the advantage window, architecture over tools.
**Four pillars:** The Major Shifts, 7 Characteristics of Disruption Winners, Strategic Builder Methodology, Management Training for Agent Operators.
**What FM needs from clippings:**
- AI deployment case studies with ROI numbers (proof arsenal)
- Team-level AI adoption stories (not individual productivity)
- Examples of the "advantage window" closing (urgency fuel)
- Wrong advice about AI adoption (contrast ammo)
- Beginner resources for ALL 4 tracks (teams include non-technical members)
- Curriculum ingredients for 10-day structure
- Management + AI intersection content

## Zenith Mind OS (ZMOS)
**What it is:** Individual AI mastery course. Teaches a single person to transform their personal productivity with AI.
**Audience:** Individuals who want to get better at AI personally.
**Key themes:** Personal AI mastery, workflow transformation, mindset shifts, individual capability.
**What ZMOS needs from clippings:**
- Individual AI workflow examples
- Before/after personal transformation stories
- AI fundamentals content for beginners
- Mindset/psychology content about adopting new tools
- Obsidian onboarding resources

## ZenithPro (ZP)
**What it is:** AI-powered marketing strategy program. Teaches how to use AI to leverage Rich's proven marketing and demand-creation strategies.
**Audience:** Marketers and business owners who want to apply AI specifically to marketing.
**Key themes:** AI + marketing, demand creation, advertising, content at scale, marketing automation.
**What ZP needs from clippings:**
- AI + marketing case studies
- Marketing automation examples
- Platform-specific AI capabilities (Google, Meta, YouTube)
- Content creation with AI workflows
- What marketers are getting wrong with AI

## Connect the Dots to Riches (CTD)
**What it is:** Business strategy program focused on pattern recognition â seeing connections others miss.
**Audience:** Business owners and strategists who want to think more strategically.
**Key themes:** Pattern recognition, cross-domain insight, strategic thinking, connecting disparate ideas.
**What CTD needs from clippings:**
- Cross-industry examples where an insight from one domain solved a problem in another
- "Hidden in plain sight" case studies
- Market blind spots and wrong assumptions
- Strategy frameworks and mental models
- Obsidian onboarding (for dot-connecting workflow)

## One-on-One AI Consults (1:1)
**What it is:** Private consulting sessions where Rich helps individuals implement AI in their specific business.
**Audience:** Business owners who want personalized, hands-on AI implementation help.
**Key themes:** Industry-specific implementation, quick wins, ROI justification, hands-on building.
**What 1:1 needs from clippings:**
- Industry-specific AI deployment examples (by vertical)
- Quick-win implementation templates
- ROI benchmarks by industry
- Objection-busting evidence (per industry)
- Claude Code onboarding resources
- Tool setup resources

## SOW / All Programs (ALL)
**What it is:** Steal Our Winners â monthly subscription with 500+ interviews and 71 issues.
**What ALL programs share:**
- Psychology/persuasion content
- Business fundamentals
- General proof points about AI transformation
- Quotable lines and stories that work in any context
