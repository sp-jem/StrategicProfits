# Clippings Processor

> **Purpose:** Process Rich's clipped articles into structured, program-tagged intelligence assets. Extract everything useful in a single pass so the article never needs to be re-read.

## Soul

Before first use, read `SOUL.md` in this skill folder. It defines who this processor IS â its values, perspective, biases, and relationship to Rich's work. The soul shapes HOW you read, not just WHAT you extract.

## Reference Documents

Before first use, read:
- `SOUL.md` â The processor's identity and values
- `references/extraction-schema.md` â All 18 extraction categories with formats and examples
- `references/program-context.md` â What each of Rich's programs needs from clippings

These files contain the complete extraction methodology. The instructions below are the operational workflow.

---

## Workflow

### Input

The user provides one of:
1. **A file path** â process that single article
2. **A folder path** â process all articles in the folder (batch mode)
3. **A number** â "process the last 20 clippings" (sorts by modification date)

**Default clippings location:** `~/Documents/Obsidian/Clippings/Clippings/`

### Step 1: Triage

For each article:
1. Read the complete article. Do not skim.
2. Assess size â skip files under 500 bytes (stubs, empty clips, video-only embeds).
3. Note the article's topic, author, publication, and approximate word count.

### Step 2: Classify

Determine WHY Rich likely clipped this article. This is the primary classification â it frames everything else.

Possible classifications (multiple allowed):
- **Idea resonance** â Contains a concept that connects to something Rich is thinking about
- **Proof/evidence** â Contains data, statistics, or case studies Rich can use
- **Market intelligence** â Shows what Rich's audience/market is reading and hearing
- **Contrast trigger** â Contains advice Rich disagrees with or wants to position against
- **Reference material** â Useful for building something (student guides, onboarding, FAQs)
- **Teaching example** â Contains a story or case study Rich could use in a program
- **Trend tracking** â Part of a pattern Rich is monitoring
- **Personal learning** â Helps Rich improve his own skills or workflow

### Step 3: Tag Programs

Assign program relevance tags:

| Tag | Program |
|-----|---------|
| `FM` | Force Multiplier |
| `ZMOS` | Zenith Mind OS |
| `ZP` | ZenithPro |
| `CTD` | Connect the Dots to Riches |
| `1:1` | One-on-One AI Consults |
| `ALL` | All programs |

Use `references/program-context.md` to make accurate assignments. Most articles will map to 1-3 programs, not all.

### Step 4: Extract

Run the article through all 18 categories from `references/extraction-schema.md`:

1. Distinctions
2. Proof Arsenal
3. Stories & Examples
4. Quotable Lines
5. Market Language Map
6. Wrong Advice / Contrast Ammo
7. Curriculum Ingredients
8. Student Resource Candidates
9. Tool/Plugin/Setup Intelligence
10. Workflow Examples
11. Mistakes & Anti-Patterns
12. Trend Signals
13. Analogies & Metaphors
14. Objection Evidence
15. FAQ/Support Content
16. People to Watch
17. Rich's Learning Queue
18. Beginner Resources (4 sub-tracks: Obsidian, Claude Code, AI Fundamentals, Tool Setup)

**Only include categories where something was actually extracted.** Omit empty categories entirely â don't list them as "N/A" or "None found."

**Every extraction must trace to specific text in the article.** Include line numbers or quote the relevant passage. Do not invent content the article doesn't contain.

### Step 5: Output

#### Single Article Mode

Write one extraction card per article:

```markdown
# Clipping Extraction: [Article Title]

**Source:** [filename]
**Author:** [if identifiable]
**Date processed:** [date]
**Word count:** [approximate]
**Classification:** [Why Rich clipped this]
**Programs:** [FM / ZMOS / ZP / CTD / 1:1 / ALL]

---

## Extractions

### [Category Name]

[Structured extraction per schema format]

---

### [Next Category]

...
```

**Output location:** Write to the project output folder specified by the user, or default to:
`~/Obsidian/Active-Knowledge/Distinctions/by-source/rich-clippings/extractions/`

#### Batch Mode

When processing multiple articles:

1. Write individual extraction cards for each article (one file per article, or all in one file â user preference)
2. Write a **batch summary index** that lists:
   - All articles processed with their classifications and program tags
   - Extraction counts by category across all articles
   - Top finds â the 5-10 most valuable extractions across the batch
   - Beginner resources inventory â all beginner-track finds grouped by track
   - Trend signals â patterns observed across multiple articles

**Batch summary location:** Same folder as extractions, named `batch-summary-[date].md`

---

## Quality Standards

### The Single-Pass Rule
The entire point of this skill is that Rich never needs to re-read a processed article. Extract aggressively. A marginal extraction that turns out unnecessary costs nothing. A missed extraction that Rich needed costs him a re-read.

### Extraction vs Invention
Extract what's IN the article. Do not generate insights the article doesn't contain. If an article has a great statistic but no story, extract the statistic â don't fabricate a story around it. Every extraction must cite its source passage.

### Program Accuracy
Don't tag everything as "ALL." Be specific about which programs benefit. An article about marketing AI is ZP, not FM. An article about team deployment is FM, not ZMOS. Cross-reference against `references/program-context.md`.

### Beginner Track Precision
When flagging beginner resources, be specific about the track (Obsidian / Claude Code / AI Fundamentals / Tool Setup) and the program whose students need it. "This is a good beginner article" is too vague. "This is an Obsidian vault organization guide useful for FM and CTD student onboarding" is right.

### The Learning Queue Filter
Category 17 (Rich's Learning Queue) is NOT "articles about AI tips." It's articles that address the SPECIFIC growth areas from Rich's learning document. Read `references/extraction-schema.md` category 17 for the filter criteria. Most articles will NOT qualify. That's correct.

---

## Batch Processing Tips

- Sort articles by size descending â larger articles tend to have more extractable content
- Skip files under 500 bytes without reading
- Skip files that are clearly video embeds or link collections (minimal text content)
- Process one article at a time with full attention, then move to the next
- If context window is getting large, write output to files incrementally rather than holding everything in memory

---

*Version: 1.0*
*Created: February 9, 2026*
