---
name: ghl-cockpit
description: Generate a live HTML command center (cockpit) from GoHighLevel data. Pulls contacts, pipeline, appointments, conversations, and campaigns via MCP, then writes a fully populated dark-mode HTML file and opens it in the browser. Trigger when someone says "ghl cockpit," "open cockpit," "business cockpit," "command center," "ghl dashboard," "show me my GHL," "cockpit report," or any request to see a visual command center of their GHL account.
license: proprietary
metadata:
tags:
  - program/ctd
  - ghl
  - cockpit
  - dashboard
---
# GHL Cockpit

## Purpose

Pull live data from every major area of a GoHighLevel account â contacts, pipeline, appointments, conversations, campaigns â and generate a self-contained dark-mode HTML cockpit file. The cockpit is NOT a read-only report; it is a command center that shows the full state of the business at a glance, highlights what needs attention, and surfaces prioritized actions.

The output is a single HTML file saved to the Desktop (or operator-specified path) and opened immediately in the default browser.

---

## Constraints

NEVER generate the cockpit with fabricated, assumed, or estimated data. Every figure in the HTML must come from a live MCP tool call.

NEVER hardcode pipeline names, stage names, campaign names, or calendar names. Always call discovery tools first.

NEVER skip a section because a tool returns empty data. Every section must render â with an explicit "No data found" state if empty.

NEVER save the HTML to `~/.claude/` or any system directory. Desktop is the default path.

NEVER ask for confirmation before running read-only tool calls. Proceed immediately.

NEVER omit the Action Center. If zero action items exist, render "All clear" explicitly â do not omit the section.

NEVER proceed to data collection if the template file is missing. Stop immediately and state the error.

NEVER proceed to HTML generation if all MCP calls have failed. A cockpit with zero live data must not be written.

ALWAYS open the file after saving. If `open` fails, print the full path so the operator can open it manually.

ALWAYS include the retrieval timestamp in `{{LAST_UPDATED}}` so the operator knows data freshness.

ALWAYS flag every failed tool call in the chat summary, stating which section is affected and what data is missing.

ALWAYS check template file existence before any data collection begins.

---

## Instructions

### Pre-Flight Check

Before any data collection, verify the template file exists:

`/Users/richardschefren/Obsidian/Strategic-Profits/00 Program Development/Connect The Dots To Riches/02 Cohort 2/GHL-Cockpit/cockpit-template.html`

If the file is not found, stop immediately. Do not proceed to MCP calls. Output the template missing error defined in the Failure Modes section.

### Step 1 â Announce and Collect Data

Announce to chat:

```
GHL Cockpit â Data Collection Starting
Location: [will be confirmed from API]
Pulling: contacts, pipeline, appointments, conversations, campaigns
Estimated time: ~60 seconds
```

Run all discovery calls in parallel:

**Contacts:**
- Call `search_contacts` with a broad query to get recent contacts
- Extract: total count, recent additions (last 7 days), top tags

**Pipeline:**
- Call `get_pipelines` to retrieve all pipeline definitions and stage names
- For each pipeline, call `search_opportunities` to get all open opportunities
- Extract per opportunity: name, contact, stage, value, created date, last updated date
- Calculate days since last update for each opportunity

**Appointments:**
- Call `get_calendar_events` for today (start = today 00:00, end = today 23:59)
- Call `get_calendar_events` for tomorrow
- Call `get_calendar_events` for the last 7 days (to identify no-shows)
- No-show definition: appointment in the past with no subsequent conversation activity from that contact

**Conversations:**
- Call `search_conversations` to get recent conversations
- Call `get_recent_messages` on the top conversations to get snippets
- Extract: contact name, channel (SMS/email/phone), snippet, timestamp, unread status

**Campaigns:**
- Call `get_campaigns` to get all automation campaigns with status
- Call `get_email_campaigns` to get email performance data (sent, opened, clicked)

### Step 2 â Process Data

**Pipeline Processing:**
- Group opportunities by stage
- For each stage: count deals, sum dollar values, calculate average days in stage
- Flag stalled: any opportunity last updated 14+ days ago
- Stall severity: 14-29 days = yellow, 30+ days = red
- Identify top 3 deals by value

**Revenue Calculation:**
- Sum all open opportunity values = total open pipeline
- Sum closed-won opportunities from current month if available; otherwise set `{{REVENUE_THIS_MONTH}}` to "â"
- Compare to last month if prior-month data is available; otherwise set `{{REVENUE_LAST_MONTH_DISPLAY}}` to "â" and `{{REVENUE_TREND_ARROW}}` to "â"

**Action Item Scoring:**
- Stalled deals (sorted by days stalled, worst first)
- Unanswered conversations older than 24 hours
- No-shows from last 7 days needing re-booking
- Appointments today with no prior conversation activity (cold contact)

Urgency levels:
- Critical: stalled 30+ days OR unanswered message 72+ hours
- High: stalled 14-29 days OR unanswered message 24-72 hours
- Medium: no-show within 7 days, needs re-booking
- Watch: moving normally but worth noting

**No-Show Detection Fallback:**
If `search_conversations` returned no data, no-show detection is not possible. Insert a "Conversation data unavailable" notice in the no-shows row rather than leaving it blank or fabricating a count.

### Step 3 â Populate the Template

Read the template from the path confirmed in the Pre-Flight Check. Replace every `{{PLACEHOLDER}}` with live data using the map below. A placeholder with no live data source receives a dash ("â") or the section's defined "no data" string â never a blank and never a fabricated value.

#### Header Placeholders

| Placeholder | Value |
|------------|-------|
| `{{BUSINESS_NAME}}` | Business name from GHL account, or "GHL Account" if unavailable |
| `{{LAST_UPDATED}}` | Current datetime in format: April 9, 2026 â 2:34 PM EDT |
| `{{TOTAL_CONTACTS}}` | Integer count of contacts from `search_contacts` |
| `{{ACTIVE_OPPORTUNITIES}}` | Count of open (non-closed) opportunities across all pipelines |
| `{{REVENUE_THIS_MONTH}}` | Sum of closed-won opportunities this month formatted as $X,XXX â or "â" if unavailable |
| `{{APPOINTMENTS_TODAY}}` | Count of today's calendar events |

#### Pipeline Placeholders

`{{PIPELINE_STAGES_HTML}}` â Full HTML block. For each pipeline:

```html
<div class="pipeline-block">
  <h3 class="pipeline-name">[Pipeline Name]</h3>
  <div class="pipeline-stages">
    <div class="stage-card [status-class]">
      <div class="stage-name">[Stage Name]</div>
      <div class="stage-count">[N] deals</div>
      <div class="stage-value">$[X,XXX]</div>
      <div class="stage-velocity">[N] avg days</div>
    </div>
  </div>
</div>
```

Status classes: `status-green` (avg days < 7), `status-yellow` (7-14 days), `status-red` (14+ days or any deal stalled 30+).

`{{STALLED_DEALS_HTML}}` â Table rows for stalled deals (14+ days):

```html
<tr class="[stall-class]">
  <td>[Opportunity Name]</td>
  <td>[Contact Name]</td>
  <td>[Stage]</td>
  <td>[N] days</td>
  <td>$[Value]</td>
  <td>[Owner]</td>
</tr>
```

Stall classes: `stall-yellow` (14-29 days), `stall-red` (30+ days).
If no stalled deals: `<tr><td colspan="6" class="no-data">No stalled deals â pipeline velocity is healthy.</td></tr>`

#### Revenue Placeholders

| Placeholder | Value |
|------------|-------|
| `{{REVENUE_THIS_MONTH_DISPLAY}}` | Formatted dollar value or "Not tracked in GHL" |
| `{{REVENUE_LAST_MONTH_DISPLAY}}` | Formatted dollar value or "â" |
| `{{REVENUE_TREND_ARROW}}` | `â` (up), `â` (down), or `â` (flat) |
| `{{REVENUE_TREND_CLASS}}` | `trend-up`, `trend-down`, or `trend-flat` |
| `{{OPEN_PIPELINE_VALUE}}` | Sum of all open opportunity values, formatted |

`{{TOP_DEALS_HTML}}` â Three rows for top 3 open deals by value:

```html
<tr>
  <td>[Deal Name]</td>
  <td>[Contact]</td>
  <td>[Stage]</td>
  <td>$[Value]</td>
</tr>
```

#### Appointments Placeholders

`{{TODAYS_APPOINTMENTS_HTML}}` â Rows for today's appointments:

```html
<tr>
  <td>[HH:MM AM/PM]</td>
  <td>[Contact Name]</td>
  <td>[Appointment Type]</td>
  <td><span class="badge [status]">[Status]</span></td>
</tr>
```

If no appointments today: `<tr><td colspan="4" class="no-data">No appointments scheduled for today.</td></tr>`

`{{NOSHOWS_HTML}}` â Rows for no-shows in last 7 days:

```html
<tr>
  <td>[Contact Name]</td>
  <td>[Date]</td>
  <td>[Appointment Type]</td>
  <td><a href="#" class="action-link" onclick="copyToClipboard('[Contact Phone/Email]')">Re-book</a></td>
</tr>
```

If no no-shows: `<tr><td colspan="4" class="no-data">No no-shows in the last 7 days.</td></tr>`
If conversation data unavailable: `<tr><td colspan="4" class="no-data">No-show detection unavailable â conversation data could not be retrieved.</td></tr>`

`{{TOMORROW_PREVIEW_HTML}}` â Count and list of tomorrow's appointments (names and times only).

#### Conversations Placeholders

| Placeholder | Value |
|------------|-------|
| `{{UNREAD_COUNT}}` | Integer count of unread/unanswered conversations |
| `{{OLDEST_UNANSWERED_AGE}}` | Human-readable age of oldest unanswered message, e.g. "3 days ago" â or "None" |

`{{RECENT_CONVERSATIONS_HTML}}` â 10 rows for the most recent conversations:

```html
<tr>
  <td>[Contact Name]</td>
  <td><span class="channel-badge [channel-class]">[SMS/Email/Phone]</span></td>
  <td class="snippet">[Message snippet, max 60 chars...]</td>
  <td class="time-ago">[X hours/days ago]</td>
  <td><span class="[read-class]">[Read/Unread]</span></td>
</tr>
```

Channel classes: `channel-sms`, `channel-email`, `channel-phone`.
Read classes: `status-read`, `status-unread`.

#### Campaign Placeholders

`{{CAMPAIGNS_HTML}}` â Rows for all active campaigns:

```html
<tr>
  <td>[Campaign Name]</td>
  <td><span class="badge badge-[status]">[Running/Paused/Draft]</span></td>
  <td>[Type: Email/SMS/Automation]</td>
  <td>[Last activity date or "â"]</td>
</tr>
```

`{{EMAIL_CAMPAIGN_PERF_HTML}}` â Last email campaign performance row:

```html
<tr>
  <td>[Campaign Name]</td>
  <td>[Sent count]</td>
  <td>[Open rate]%</td>
  <td>[Click rate]%</td>
  <td>[Reply count]</td>
</tr>
```

If no email campaigns: `<tr><td colspan="5" class="no-data">No email campaigns found.</td></tr>`

#### Action Center Placeholders

`{{ACTION_ITEMS_HTML}}` â Action item rows sorted by urgency:

```html
<tr class="priority-[critical|high|medium|watch]">
  <td><span class="priority-badge priority-[level]">[CRITICAL/HIGH/MEDIUM/WATCH]</span></td>
  <td>[Category: Stalled Deal / No-Show / Unanswered Message / Overdue Task]</td>
  <td>[Contact or Deal Name]</td>
  <td>[Suggested Action]</td>
  <td>[Age/Days]</td>
</tr>
```

If no action items: `<tr><td colspan="5" class="no-data all-clear">All clear â no items require attention right now.</td></tr>`

`{{TOTAL_ACTION_ITEMS}}` â Integer count of action items.

### Step 4 â Save the HTML File

Determine output path:
1. If the operator specified a path, use it
2. Otherwise: `~/Desktop/ghl-cockpit-[YYYY-MM-DD].html`

Write the fully populated HTML to the file. Confirm: `Cockpit saved to: [full path]`

### Step 5 â Open in Browser

Run: `open [output_path]`

Confirm: `Cockpit opened in default browser.`

### Step 6 â Print Summary to Chat

```
GHL COCKPIT GENERATED â [Business Name]
Generated: [timestamp]

Data pulled:
  Contacts:         [N] total
  Opportunities:    [N] open across [N] pipelines
  Appointments:     [N] today, [N] tomorrow
  Conversations:    [N] recent, [N] unread
  Campaigns:        [N] active

Action items:       [N] total
  Critical:         [N]
  High:             [N]
  Medium:           [N]

Failed calls:       [N] â [list affected sections, or "None"]
File: [path]
```

---

## Failure Modes

**Template file missing:**
```
ERROR: Cockpit template not found at:
/Users/richardschefren/Obsidian/Strategic-Profits/00 Program Development/Connect The Dots To Riches/02 Cohort 2/GHL-Cockpit/cockpit-template.html

Cannot generate cockpit without the template. Verify the file exists at that path.
```
Stop. Do not proceed to MCP calls.

**GHL MCP not connected (all calls fail):**
```
ERROR: GHL MCP server is not responding.
All tool calls (get_pipelines, search_contacts, get_calendar_events) failed.
Verify the BusyBee3333 MCP server is running and authenticated. Do not write a cockpit file.
```
Stop. Do not write an empty or placeholder cockpit.

**Partial tool failure (some calls succeed, some fail):**
Continue generating the cockpit with available data. For each failed section, insert:
```html
<div class="data-error">
  Data unavailable â [tool name] returned an error. Check GHL MCP connection.
</div>
```
List every failed call and affected section in the chat summary under "Failed calls."

**No-show detection unavailable (conversations API fails):**
Render the no-shows row with: "No-show detection unavailable â conversation data could not be retrieved." Do not omit the section and do not fabricate a no-show count.

**No opportunities found:**
Render the Pipeline section with: "No open opportunities found. Either the pipeline is empty or all deals are closed-won." Do not omit the section.

**No contacts returned:**
Render the Contacts metric as "0" and note "No contacts returned by search_contacts â verify GHL location ID is correct." Do not infer or estimate a contact count.

**File write failure:**
State the OS error and instruct: "Try running `/ghl-cockpit` again with an explicit output path, e.g., 'save cockpit to ~/Documents/cockpit.html'"

---

## Reference

### MCP Tools

| Tool | Purpose | Section |
|------|---------|---------|
| `search_contacts` | Total contact count, recent additions | Command Bar, Contacts |
| `get_pipelines` | Pipeline and stage definitions | Pipeline View |
| `search_opportunities` | All open deals with stage and value | Pipeline, Revenue, Action Center |
| `get_calendar_events` | Today's, tomorrow's, and past 7-day events | Appointments |
| `search_conversations` | Recent conversation list | Recent Activity |
| `get_recent_messages` | Message snippets for conversations | Recent Activity |
| `get_campaigns` | Campaign list and status | Campaign Status |
| `get_email_campaigns` | Email performance metrics | Campaign Status |

### Configuration Requirements

- GHL MCP server (BusyBee3333) must be connected and authenticated
- GHL Location ID must be configured in the MCP server
- Operator must have read access to contacts, opportunities, calendar, conversations, and campaigns
