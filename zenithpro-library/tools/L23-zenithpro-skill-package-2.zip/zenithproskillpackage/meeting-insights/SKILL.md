---
name: Meeting Insights
description: Analyzes sales call, consulting, and coaching session transcripts to surface behavioral patterns, communication habits, and missed opportunities. Identifies conflict avoidance, filler words, dominant talking patterns, failed closes, and active listening gaps. Use when the user says "analyze this call", "analyze my calls", "review this transcript", "check my communication patterns", "when did I avoid conflict", "analyze my speaking ratio", "find my filler words", "compare my meetings", "track my improvement", or "what's my coaching style".
version: 1.0.0
---

# Meeting Insights

Turns your call and session transcripts into actionable behavioral feedback — so you know exactly what to fix before the next call.

## Triggers

| Mode | Trigger Phrases |
|------|-----------------|
| **Single Call Analysis** | "analyze this call", "review this transcript", "debrief this call", "analyze this recording" |
| **Batch Pattern Analysis** | "analyze my calls", "analyze all meetings in this folder", "find my communication patterns", "look at my meetings from" |
| **Conflict Avoidance** | "when did I avoid conflict", "when did I hedge", "when did I avoid difficult conversations" |
| **Speaking Patterns** | "analyze my speaking ratio", "how much do I talk", "what's my filler word count", "find my filler words" |
| **Comparative Tracking** | "compare my calls", "compare these two folders", "how have I improved", "track my improvement" |
| **Coaching Style** | "what's my coaching style", "how do I facilitate", "how do I lead sessions" |

---

## What This Skill Analyzes

### 1. Conflict Avoidance Patterns
- Hedging language: "maybe", "kind of", "I think", "sort of", "potentially"
- Indirect requests instead of direct asks
- Subject changes when tension arises
- Non-committal agreement: "yeah, but...", "that's a good point, and..."
- Not addressing obvious problems or objections directly

### 2. Speaking Ratios
- Percentage of call time spent talking (target: <50% on discovery calls, <40% on coaching sessions)
- Interruption count — given and received
- Average speaking turn length
- Question-to-statement ratio

### 3. Filler Words
- Count of: "um", "uh", "like", "you know", "actually", "right?", "so..."
- Frequency per minute and per speaking turn
- Situational correlation — do fillers spike when uncertain or challenged?

### 4. Active Listening Indicators
- References to the other person's earlier points
- Paraphrasing or summarizing before responding
- Building on their language and framing
- Clarifying questions (not leading questions disguised as clarifying)

### 5. Sales-Specific Patterns
- Premature pitching before pain is established
- Missing Up-Front Contract or agenda-setting
- Close attempts — how many, when, how delivered
- Objection handling — met directly or sidestepped
- Missed buying signals
- Talk ratio inversion (seller talking more than buyer in discovery)

### 6. Coaching-Specific Patterns
- Directive vs. facilitative balance
- Questions that open thinking vs. questions that lead to your answer
- Space held for the client to sit with discomfort
- Action item clarity and ownership assignment
- Whether the client is doing the work or you're doing it for them

---

## Instructions

When Harry requests meeting analysis, execute these steps in order:

### Step 1: Discover Available Data

ALWAYS do this before asking any clarifying questions:
- Scan the folder or message for transcript files (.txt, .md, .vtt, .srt, .docx)
- Check whether files include speaker labels and timestamps
- Confirm the date range covered
- Identify Harry's name or label in the transcripts (he may be "H:", "Harry:", "Host:", etc.)

### Step 2: Clarify Analysis Goals (Only If Not Specified)

If Harry's message does not specify what to look for, ask ONE question:

> "What's the primary behavior you want to surface — conflict avoidance, speaking ratio, filler words, close patterns, or something else?"

NEVER ask multiple clarifying questions at once.

### Step 3: Analyze Patterns

**For each requested pattern, run the full analysis:**

**Conflict Avoidance:**
Look for hedging language, indirect phrasing, abrupt subject changes, agreement without commitment, and unaddressed problems. Timestamp every instance.

**Speaking Ratios:**
Calculate percentage of meeting time Harry spoke. Count interruptions. Measure average turn length. Track question vs. statement ratio. For sales calls, flag if Harry talked more than 50% during any discovery phase.

**Filler Words:**
Count every instance of "um", "uh", "like", "you know", "actually", "right?". Note per-minute frequency. Flag calls where filler density is 2x or more the baseline.

**Active Listening:**
Find moments where Harry references something the other person said earlier, paraphrases before responding, builds on their framing, or asks a genuine clarifying question. These are STRENGTHS — surface them alongside gaps.

**Sales-Specific:**
Evaluate: Did Harry set an agenda (UFC equivalent)? When did pitching start relative to pain establishment? How many close attempts? Were objections met head-on or redirected? What buying signals appeared and how were they handled?

**Coaching-Specific:**
Evaluate: How often did Harry answer his own questions? How much silence did he hold? Did action items end with client ownership or ambiguity? Was Harry doing more work in the session than the client?

### Step 4: Provide Specific Examples

For each pattern found, output this EXACT format:

```markdown
### [Pattern Name]

**Finding**: [One-sentence summary of the pattern]

**Frequency**: [X times across Y calls/sessions]

**Examples**:

1. **[Call Name or Date]** — [Timestamp if available]

   **What Happened**:
   > [Actual quote from transcript]

   **Why It Matters**:
   [Impact on the sale, coaching outcome, or relationship]

   **Better Approach**:
   [Specific alternative phrasing or behavior — verbatim, not theoretical]

[Repeat for 2-3 strongest examples per pattern]
```

NEVER include more than 3 examples per pattern. Lead with the strongest.

### Step 5: Synthesize Insights

After all patterns are analyzed, output this EXACT format:

```markdown
# Call Insights Summary

**Analysis Period**: [Date range]
**Calls/Sessions Analyzed**: [X]
**Total Duration**: [X hours, if calculable]

## Key Patterns Identified

### 1. [Primary Pattern — the one Harry most needs to fix]
- **Observed**: [What you saw — specific, not general]
- **Impact**: [What this is costing him — a lost deal, weakened coaching outcome, eroded trust]
- **Fix**: [Concrete, actionable — the specific behavior change, with example phrasing]

### 2. [Second Pattern]
[Same structure]

### 3. [Third Pattern]
[Same structure]

## Communication Strengths

1. [Strength 1 with specific example quote]
2. [Strength 2 with specific example quote]
3. [Strength 3 with specific example quote]

## Speaking Statistics

| Metric | Your Number | Target |
|--------|------------|--------|
| Avg talk ratio | [X%] | <50% (discovery) / <40% (coaching) |
| Questions per call | [X] | 8-12 (discovery) / 6-10 (coaching) |
| Filler words per min | [X] | <2 per min |
| Interruptions given | [X per call] | <3 per call |
| Close attempts | [X per call — sales only] | 2-3 per call |

## Priority Fixes (Do These First)

1. **[Behavior to change]** — [Specific phrasing or technique to use instead]
2. **[Behavior to change]** — [Specific phrasing or technique to use instead]
3. **[Behavior to change]** — [Specific phrasing or technique to use instead]
```

### Step 6: Offer Follow-Up

After delivering the summary, ALWAYS offer:
- "Track these same metrics next month and compare"
- "Deep dive into a specific call or pattern"
- "Run a comparative analysis against an earlier period"
- "Build a personal improvement plan from this data"

---

## Transcript Sources

### Getting Your Transcripts

**Granola** (recommended — free with Lenny's newsletter):
- Auto-transcribes all your calls
- Export to a folder as .txt or .md
- Point Claude Code at the folder

**Zoom:**
- Enable cloud recording with transcription in settings
- Download VTT or SRT after each call
- Store in a dedicated folder (e.g., `~/Calls/`)

**Fireflies.ai / Otter.ai:**
- Export transcripts in bulk from the dashboard
- Download as .txt
- Store locally (keep sensitive call data off shared drives)

**Google Meet:**
- Enable auto-transcription via Google Docs
- Download transcripts as .txt after each session

### File Naming Convention

ALWAYS use: `YYYY-MM-DD - [Call Type] - [Prospect or Client Name].txt`

Examples:
- `2026-02-20 - Discovery - Acme Corp.txt`
- `2026-02-22 - Coaching - Session 3 - Mike T.txt`
- `2026-02-24 - Consulting - Kickoff - Jane D.txt`

Consistent naming makes batch analysis and trend comparisons work without friction.

---

## Example Outputs

### Example 1: Conflict Avoidance Analysis

**Input**: "Analyze all calls in this folder and tell me every time I subtly avoided conflict."

**Output**:
```markdown
# Conflict Avoidance Patterns

Found 18 instances across 11 calls where you used indirect communication
or failed to address tension directly.

## Pattern: Hedging on Pricing Pushback

**Frequency**: 6 times across 5 calls

**Example 1: Discovery — Acme Corp** — 00:22:14

**What Happened**:
> "So, yeah, I mean, the investment is... it depends on a few things,
> honestly. We can definitely talk about that later if you want to
> kind of get a sense of what works for you."

**Why It Matters**:
The prospect asked directly about price. The hedge ("it depends", "kind of",
"if you want to") avoided the conversation entirely, which signals uncertainty
about your own value and delays the sale's real qualification moment.

**Better Approach**:
"The engagement runs $X. Before we get into whether that works, I want
to make sure the fit is there — can I ask what you're currently spending
on [problem area]?"
```

### Example 2: Coaching Style Analysis

**Input**: "How do I facilitate my coaching sessions? What's my style?"

**Output**: Analysis covering:
- Talk ratio across 8 sessions (Harry averaged 58% — target is below 40%)
- Pattern of answering his own questions before clients respond
- Strong labeling of emotions (genuine strength)
- Action items ending without clear client ownership in 4 of 8 sessions
- Specific examples of moments where more silence would have unlocked deeper client thinking

### Example 3: Improvement Tracking

**Input**: "Compare my calls from January vs. February to see if my discovery has improved."

**Output**: Comparative analysis showing:
- Talk ratio change: 64% → 51% (moving in right direction, not yet at target)
- Clarifying questions per call: 3 → 7 (significant improvement)
- Close attempts: 0.8 → 2.1 per call (much better)
- Remaining gap: still pitching before pain is fully established in 60% of calls
- Specific January vs. February side-by-side quote comparisons

---

## Common Analysis Requests

- "When do I avoid difficult pricing conversations?"
- "How much am I talking vs. listening?"
- "Do I pitch before the pain is real?"
- "When do I miss buying signals?"
- "How do I handle objections?"
- "Am I asking questions or making statements?"
- "Do I close enough times per call?"
- "What's my filler word pattern?"
- "How clear are my next steps at the end of each call?"
- "Have I gotten better at discovery this month?"

---

## Analysis Checklist (Run Before Every Output)

ALWAYS verify before delivering analysis:

- [ ] Harry's speaker label correctly identified in all transcripts
- [ ] Pattern examples include verbatim quotes, not paraphrases
- [ ] "Better Approach" language is specific and ready-to-use, not theoretical
- [ ] Speaking Statistics table is populated with actual numbers, not placeholders
- [ ] Strengths are surfaced alongside gaps — not just a list of problems
- [ ] Priority Fixes are ranked by impact, not by how often they appear
- [ ] Follow-up options offered at the end

---

## Edge Cases

**No speaker labels in transcript:** Infer from context (question patterns, meeting role). Flag the assumption: "Treating everything that appears to be leading the conversation as Harry — correct me if wrong."

**Single-turn transcript (no back-and-forth):** Analyze solo for delivery patterns — filler words, hedging language, clarity. Note: speaking ratio analysis not applicable.

**Highly sensitive client call:** NEVER quote client-identifying information in the summary output if Harry has flagged the call as confidential. Reference lines by timestamp only.

**Transcript with heavy crosstalk or errors:** Flag transcript quality issues. Analyze what's clean. Skip corrupted segments.

**Single call vs. folder:** For single calls, still surface patterns — even one example per pattern is actionable. For folders, prioritize patterns that appear across 3+ calls.

**No transcripts found in folder:** Say exactly: "No transcript files found. Supported formats: .txt, .md, .vtt, .srt, .docx. What format are your transcripts in?"

---
