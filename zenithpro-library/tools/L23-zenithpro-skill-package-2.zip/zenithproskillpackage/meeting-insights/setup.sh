#!/bin/bash
set -euo pipefail

# ============================================
#  Self-Installer for Claude Code Skills
#  Built by Harry Lockwood
# ============================================

# ---- SKILL CONFIG ----
SKILL_SLUG="meeting-insights"
DISPLAY_NAME="Meeting Insights"
VERSION="1.0.0"
AUTHOR="Harry Lockwood"

# Trigger rules for CLAUDE.md (leave empty array if no hard triggers needed)
# Each entry = one markdown table row: | trigger | action |
TRIGGER_RULES=(
)

# ---- END CONFIG (universal logic below) ----

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PLUGIN_DIR="$HOME/.claude/plugins/local/$SKILL_SLUG"
CLAUDE_MD="$HOME/.claude/CLAUDE.md"
MARKER="<!-- [skill-trigger:$SKILL_SLUG] -->"

usage() {
  echo "Usage: ./setup.sh [--uninstall]"
  echo ""
  echo "  (no args)     Install $DISPLAY_NAME as a Claude Code plugin"
  echo "  --uninstall   Remove the plugin and trigger rules"
}

# ---- UNINSTALL ----
if [[ "${1:-}" == "--uninstall" ]]; then
  echo -e "${YELLOW}Uninstalling $DISPLAY_NAME...${NC}"

  if [ -d "$PLUGIN_DIR" ]; then
    rm -rf "$PLUGIN_DIR"
    echo "  Removed plugin: $PLUGIN_DIR"
  else
    echo "  Plugin directory not found — already removed"
  fi

  if [ -f "$CLAUDE_MD" ] && grep -q "$MARKER" "$CLAUDE_MD"; then
    sed -i '' "/$MARKER/,/^$/d" "$CLAUDE_MD"
    echo "  Removed trigger rules from CLAUDE.md"
  fi

  echo ""
  echo -e "${GREEN}Done. Start a new Claude Code session to complete removal.${NC}"
  exit 0
fi

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
  usage
  exit 0
fi

# ---- INSTALL ----
echo ""
echo -e "${BOLD}$DISPLAY_NAME — Installer${NC}"
echo "────────────────────────────────────────"
echo ""

echo -e "  [1/4] Creating plugin directory..."
mkdir -p "$PLUGIN_DIR/skills/$SKILL_SLUG"

echo -e "  [2/4] Copying skill files..."
cp "$SCRIPT_DIR/SKILL.md" "$PLUGIN_DIR/skills/$SKILL_SLUG/"

for item in "$SCRIPT_DIR"/*/; do
  [ -d "$item" ] || continue
  dirname="$(basename "$item")"
  [[ "$dirname" == .* ]] && continue
  cp -r "$item" "$PLUGIN_DIR/skills/$SKILL_SLUG/"
done

echo -e "  [3/4] Generating plugin.json..."
cat > "$PLUGIN_DIR/plugin.json" << PJEOF
{
  "name": "$SKILL_SLUG",
  "version": "$VERSION",
  "description": "$DISPLAY_NAME — self-installed skill plugin",
  "author": {
    "name": "$AUTHOR"
  },
  "skills": [
    "./skills/$SKILL_SLUG/SKILL.md"
  ]
}
PJEOF

if [ ${#TRIGGER_RULES[@]} -gt 0 ]; then
  mkdir -p "$(dirname "$CLAUDE_MD")"

  if [ ! -f "$CLAUDE_MD" ]; then
    echo "# Claude Code Instructions" > "$CLAUDE_MD"
    echo "" >> "$CLAUDE_MD"
    echo -e "  ${YELLOW}Created $CLAUDE_MD${NC}"
  fi

  if grep -q "$MARKER" "$CLAUDE_MD" 2>/dev/null; then
    echo -e "  [4/4] Trigger rules already wired — ${YELLOW}skipping${NC}"
  else
    echo -e "  [4/4] Wiring trigger rules into CLAUDE.md..."
    {
      echo ""
      echo "$MARKER"
      echo "## Skill: $DISPLAY_NAME"
      echo "**Trigger phrase = fire the skill immediately.** Do not answer the question first — invoke the skill."
      echo ""
      echo "| Trigger | Action |"
      echo "|---------|--------|"
      for rule in "${TRIGGER_RULES[@]}"; do
        echo "$rule"
      done
      echo ""
    } >> "$CLAUDE_MD"
  fi
else
  echo -e "  [4/4] No hard triggers — ${YELLOW}skipping CLAUDE.md${NC}"
fi

echo ""
echo "────────────────────────────────────────"
echo -e "${GREEN}Installed $DISPLAY_NAME v$VERSION${NC}"
echo ""
echo "  Plugin:   $PLUGIN_DIR"
if [ ${#TRIGGER_RULES[@]} -gt 0 ]; then
  echo "  Triggers: $CLAUDE_MD"
fi
echo ""
echo -e "  ${BOLD}Start a new Claude Code session to activate.${NC}"
echo "  To uninstall: ./setup.sh --uninstall"
echo ""
