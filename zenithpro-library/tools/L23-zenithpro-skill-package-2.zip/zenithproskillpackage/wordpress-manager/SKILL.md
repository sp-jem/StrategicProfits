name: wordpress-manager
description: Manage your WordPress site through the AI Engine MCP integration. Create posts, pages, upload media, manage content - all through natural language. Use when you want to create blog posts, landing pages, sales letters, manage media, or make any content changes to your WordPress site.
version: 1.0.0
author: Rich Schefren
tags: [wordpress, cms, content, publishing, website, management]
---

# WordPress Manager

Manage your WordPress site directly through Claude Code using the AI Engine MCP integration. Create posts, pages, sales letters, landing pages, and manage media - all through natural conversation.

## CUSTOMIZE BEFORE USE

**Before using this skill, configure the following:**

1. **WordPress Site URL**
   - Replace all instances of `[YOUR_WORDPRESS_URL]` with your actual WordPress site URL
   - Example: `https://yourbusiness.com`

2. **AI Engine MCP Setup**
   - Install the AI Engine plugin (v3.2.0+) on your WordPress site
   - Go to AI Engine > Dev Tools > MCP Settings
   - Copy your No-Auth URL and replace `[YOUR_MCP_NO_AUTH_URL]`
   - Example format: `https://yourbusiness.com/wp-json/mcp/v1/mcp_XXXXXXXXXXXXX`

3. **Bridge Script (Optional)**
   - If using Claude Code with SSE bridge: `~/.mcp/mcp.js`
   - If hosting on Kinsta, configure your API key: `[YOUR_KINSTA_API_KEY]`

4. **Staging Environment (Optional)**
   - If you have a staging site, update: `[YOUR_STAGING_URL]`
   - If using Kinsta staging, update environment IDs

5. **Hosting Details (Optional)**
   - If using Kinsta, update your Company ID, Site ID, and Environment IDs
   - Otherwise, remove the Kinsta API Operations section

---

## How It Works

The AI Engine plugin on your WordPress site exposes an MCP (Model Context Protocol) endpoint that Claude Code connects to. This gives direct access to WordPress capabilities without needing browser automation.

**Connection Details:**
- Site: `[YOUR_WORDPRESS_URL]`
- No-Auth URL: `[YOUR_MCP_NO_AUTH_URL]`
- Plugin: AI Engine v3.2.0+ by Meow Apps
- Bridge Script: `~/.mcp/mcp.js` (required - Claude can't handle SSE directly)
- Status: **Configure and test connection**

**How the Bridge Works:**
Claude Code uses a stdio MCP server that runs the bridge script:
```
~/.mcp/mcp.js relay [YOUR_WORDPRESS_URL]
```
The bridge handles SSE streaming and JSON-RPC message forwarding between Claude and WordPress.

**Hosting (if applicable):**
- Provider: [YOUR_HOSTING_PROVIDER]
- Company/Account ID: [YOUR_ACCOUNT_ID]
- Site ID: [YOUR_SITE_ID]
- API Key: [YOUR_HOSTING_API_KEY]

**Staging Site (if applicable):**
- URL: `[YOUR_STAGING_URL]`
- Environment ID: [YOUR_STAGING_ENVIRONMENT_ID]
- Use for testing major changes before pushing to live

---

## Critical Workflow Rules

### 1. Use Staging for Major Changes
If you have a staging site, test major changes there first before pushing to live.

```
CORRECT: "I'll test this on staging first, then push to live after you approve"
WRONG: "I'll publish this major change directly to live"
```

### 2. Always Create Drafts First
For content changes, NEVER publish directly to live site without your review.

```
CORRECT: "I'll create this as a draft so you can review it first"
WRONG: "I'll publish this post now"
```

### 3. Confirm Before Destructive Actions
Always confirm before:
- Deleting any content
- Overwriting existing pages
- Making changes to published content

### 4. Use Descriptive Titles and Slugs
When creating content:
- Use SEO-friendly slugs
- Include relevant categories/tags
- Set proper meta descriptions

---

## Available Operations

### Posts

**Create a new post:**
```
Create a draft blog post titled "[Title]" with the following content:
[Content in markdown or HTML]

Categories: [category1, category2]
Tags: [tag1, tag2]
```

**List recent posts:**
```
List my recent WordPress posts
Show posts from the last 30 days
```

**Update existing post:**
```
Update the post titled "[Title]" to change [specific element]
```

**Delete post (use carefully):**
```
Delete the draft post titled "[Title]"
```

### Pages

**Create a landing page:**
```
Create a new landing page at /[slug] with:
- Headline: [headline]
- Subheadline: [subheadline]
- Body: [content]
- CTA: [call to action]
```

**Create a sales letter page:**
```
Create a sales letter page for [product/offer]:
[Include full sales letter copy]
```

**Update existing page:**
```
Update the page at /[slug] to change [element]
```

### Media

**Upload image:**
```
Upload this image to my WordPress media library: [path or URL]
```

**List media:**
```
Show my recent media uploads
List images in my media library
```

**Set featured image:**
```
Set the featured image for post "[Title]" to [image]
```

### Categories & Tags

**Manage categories:**
```
Create a new category called "[Name]"
List all categories
Add category "[Name]" to post "[Title]"
```

**Manage tags:**
```
Add tags [tag1, tag2] to post "[Title]"
List all tags
```

### Site Information

**Get site status:**
```
Show WordPress site information
What theme is active?
List installed plugins
```

### Hosting API Operations (if applicable)

**Refresh staging from live:**
```bash
curl -X POST "https://api.[YOUR_HOSTING_PROVIDER].com/v2/sites/environments/[YOUR_STAGING_ENVIRONMENT_ID]/clone" \
  -H "Authorization: Bearer [YOUR_HOSTING_API_KEY]" \
  -H "Content-Type: application/json" \
  -d '{"source_env_id": "[YOUR_LIVE_ENVIRONMENT_ID]"}'
```

**Clear cache:**
```bash
curl -X POST "https://api.[YOUR_HOSTING_PROVIDER].com/v2/sites/environments/[YOUR_LIVE_ENVIRONMENT_ID]/clear-cache" \
  -H "Authorization: Bearer [YOUR_HOSTING_API_KEY]"
```

**Get environment status:**
```bash
curl -s "https://api.[YOUR_HOSTING_PROVIDER].com/v2/sites/[YOUR_SITE_ID]/environments" \
  -H "Authorization: Bearer [YOUR_HOSTING_API_KEY]"
```

---

## Content Creation Patterns

### Blog Post Pattern

When creating a blog post, include:

1. **Title** - SEO-optimized, compelling
2. **Content** - Properly formatted HTML or markdown
3. **Excerpt** - 1-2 sentence summary
4. **Categories** - At least one relevant category
5. **Tags** - 3-5 relevant tags
6. **Featured Image** - If available
7. **Meta Description** - For SEO

Example request:
```
Create a draft blog post:

Title: The 3 Biggest Mistakes [Industry] Make in 2025
Slug: mistakes-2025
Category: Business Strategy
Tags: business, mistakes, strategy, 2025

Content:
[Full blog post content here]

Excerpt: Discover the three critical mistakes that are holding you back in 2025 and learn how to avoid them.
```

### Landing Page Pattern

When creating a landing page, structure as:

1. **Headline** - Primary benefit or hook
2. **Subheadline** - Supporting statement
3. **Problem Section** - Pain points
4. **Solution Section** - How you solve it
5. **Benefits** - Bullet points
6. **Social Proof** - Testimonials, stats
7. **CTA** - Clear call to action
8. **FAQ** - Address objections

### Sales Letter Pattern

For sales letters, use the classic structure:

1. **Pre-head** - Pattern interrupt
2. **Headline** - Big promise
3. **Lead** - Hook and story
4. **Body** - Problem, agitation, solution
5. **Bullets** - Fascinations
6. **Offer** - What they get
7. **Bonuses** - Extra value
8. **Guarantee** - Risk reversal
9. **Close** - Urgency and CTA
10. **P.S.** - Key point reinforcement

---

## Error Handling

### Connection Issues
If MCP connection fails:
1. Check if WordPress site is accessible at `[YOUR_WORDPRESS_URL]`
2. Verify AI Engine plugin is active
3. Check token hasn't expired
4. Restart Claude Code to refresh connection

### Permission Errors
If operation is denied:
1. Verify user role has required capabilities
2. Check if content is locked by another user
3. Some operations may require admin access

### Content Errors
If content creation fails:
1. Check for invalid HTML/characters
2. Verify slug isn't already taken
3. Ensure required fields are provided

---

## Safety Checklist

Before any operation, verify:

- [ ] Is this a draft or published content?
- [ ] Will this overwrite existing content?
- [ ] Has the user confirmed destructive actions?
- [ ] Is content appropriate for live site?
- [ ] Are all required fields populated?

---

## Integration with Other Skills

### With Copywriting Skills
Use copywriting skills to write copy, then publish:
```
Write a sales letter for [product] using [copywriting methodology], then create it as a draft page on WordPress
```

### With Design Skills
Create visual content, then upload:
```
Create a promotional image for [campaign], then upload to WordPress media library
```

### With Browser Automation
For tasks MCP can't handle, fall back to browser automation:
```
Use browser automation to check how the new page looks on mobile
```

---

## Quick Reference

| Task | Command Pattern |
|------|-----------------|
| New blog post | "Create a draft post titled X with content Y" |
| New page | "Create a page at /slug with content Y" |
| List posts | "Show my recent posts" |
| Upload image | "Upload this image to WordPress" |
| Update content | "Update the post titled X to change Y" |
| Delete draft | "Delete the draft titled X" |
| Add category | "Add category X to post Y" |
| Site info | "Show WordPress site information" |

---

## Troubleshooting

**"MCP connection refused"**
- Restart Claude Code to reload MCP servers
- Check site is accessible at `[YOUR_WORDPRESS_URL]`
- Verify AI Engine plugin is active in WordPress
- Test bridge: `cd ~/.mcp && node mcp.js start`

**"Unauthorized" errors**
- Token may have expired in AI Engine
- Regenerate No-Auth URL in AI Engine > Dev Tools > MCP Settings
- Update the URL: `cd ~/.mcp && node mcp.js remove [YOUR_WORDPRESS_URL] && node mcp.js add [YOUR_MCP_NO_AUTH_URL]`

**MCP not showing tools after restart**
- Check bridge is configured: `claude mcp list`
- Should show your WordPress site as connected
- If not connected, verify No-Auth URL is still valid in WordPress

**"Post creation failed"**
- Check for special characters in title/content
- Verify category exists
- Try with minimal content first

**"Media upload failed"**
- Check file size limits
- Verify file type is allowed
- Ensure file path is accessible

**Bridge script commands:**
```bash
~/.mcp/mcp.js list                          # Show registered sites
~/.mcp/mcp.js start                         # Test connection (verbose)
~/.mcp/mcp.js remove [YOUR_WORDPRESS_URL]   # Remove a site
~/.mcp/mcp.js add [YOUR_MCP_NO_AUTH_URL]    # Add new No-Auth URL
```

---

*WordPress Manager v1.0.0 | AI Engine MCP | Generic Business WordPress Management*