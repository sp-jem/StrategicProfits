---
name: fafsa-css-policy-checker
description: Pulls up school-specific FAFSA and CSS Profile filing requirements, institutional methodology rules, and supplemental form requirements for any college or university. Eliminates the annual re-research cycle. Use when preparing to file for a student at a specific school, verifying whether a school uses FM vs IM, checking what supplemental forms are required, or answering the question "does this school require the CSS Profile?"
license: proprietary
metadata:
tags:
  - program/ctd
  - client/pearl-lockwood
---
# FAFSA & CSS Policy Checker

School-specific financial aid filing requirements â FAFSA only vs. CSS Profile required, institutional vs. federal methodology, supplemental forms, verification policies, and deadline structures.

## Keywords
FAFSA, CSS Profile, financial aid, institutional methodology, federal methodology, supplemental forms, verification, school requirements, college aid, need-based aid, profile schools, FAFSA-only schools, institutional aid, endowment schools, CollegeBoard

## HARD CONSTRAINTS â Read Before Anything Else

- NEVER state a deadline without sourcing it to a primary source (school's financial aid website, collegeboard.org, or studentaid.gov). "I believe the deadline is" is a disqualifying phrase.
- NEVER conflate FM and IM. They produce different Expected Contribution figures for the same family. Treat them as distinct systems throughout every output.
- NEVER assume prior-year policy applies to the current cycle without checking. Schools change CSS Profile requirements, home equity caps, and supplemental forms annually.
- NEVER guess at home equity treatment or business asset policy when a school does not publish it. State "Not publicly confirmed â call the financial aid office directly" and provide the office phone number if findable.
- NEVER calculate aid amounts. This skill covers filing requirements and policy only. If Pearl asks "how much aid will this family get?" â redirect to the award-letter-analyzer agent.
- NEVER present stale data as current. If operating without live internet access, state this limitation explicitly: "No live access â providing last confirmed policy from [date]. Verify before advising."
- NEVER resolve source conflicts silently. When sources disagree, flag both sources and both conflicting data points. Do not pick one.
- Output must always go to a file in Pearl's vault. Confirm the file path after saving.

## Quick Start

1. Name the school (or list of schools) to check
2. Specify the cycle year (e.g., 2025-26 or 2026-27)
3. Specify what you need: filing method, deadline, supplemental forms, methodology, or full profile
4. Output is pulled from primary sources and year-over-year changes are flagged if known

No scripts required. Policy lookup and synthesis from: collegeboard.org, studentaid.gov, individual school financial aid portals.

## Minimum Requirements Before Starting

Do not produce any output until:

- At least one school name or CEEB code (College Entrance Examination Board identifier) is provided
- Cycle year is specified â if omitted, default to current filing cycle AND flag the assumption explicitly in output
- If multiple schools requested, confirm the list is complete before running
- If Pearl specifies a need (filing method only, full profile, etc.), scope the output to that need only â do not produce the full format when Pearl asked a narrow question

## Core Workflow

### Step 1 â Identify School Category

Every school falls into one of these categories. Identify it first:

**FAFSA-Only Schools**
- Public universities and state schools
- Many private schools with limited endowments
- These schools use Federal Methodology (FM) exclusively
- Aid is determined by Student Aid Index (SAI) from FAFSA alone

**CSS Profile + FAFSA Schools**
- Private colleges with significant endowments
- Highly selective schools: Ivy League, LACs, elite private universities
- These schools use Institutional Methodology (IM) in addition to FM
- IM considers home equity, business assets, medical expenses, and other factors FAFSA ignores
- Schools set their own IM rules â there is no single standard IM

**Schools with Both + Supplemental Forms**
- Some schools (Notre Dame, Georgetown, Vanderbilt, etc.) require institution-specific forms beyond FAFSA and CSS Profile
- These forms may ask for business tax returns, asset verification, or family-specific financial narratives

### Step 2 â Pull Filing Requirements

For each school, surface the following. If any data point cannot be confirmed from a primary source, write "Unverified â [source checked] â Pearl should confirm directly" in that field. Never leave a field blank or filled with a guess.

**Filing Method**
- Does this school require FAFSA only, or FAFSA + CSS Profile?
- Is the CSS Profile required for freshmen only, or also for returning students?
- Does the school use the institutional CSS Profile or a school-specific form?

**Deadlines**
- Priority filing deadline â flag whether it is a hard cutoff or rolling (this distinction determines urgency for families who are late)
- Regular deadline
- Verification deadline (if applicable)
- CONSTRAINT: Never estimate a deadline. If a deadline is not available for the current cycle, state "Deadline not confirmed for [cycle] â direct Pearl to [school].edu/financialaid"

**Methodology**
- Federal Methodology (FM): SAI from FAFSA, no home equity, retirement assets protected
- Institutional Methodology (IM): home equity may be included (often capped â state the cap exactly), business assets may be included
- School-specific IM variations: flag explicitly when a school's policy diverges from standard College Board IM
- CONSTRAINT: Never describe FM and IM as equivalent or interchangeable in any output

**Supplemental Forms**
- List each form required beyond FAFSA and CSS Profile
- For each form: mandatory vs. conditional (state the trigger condition)
- For each form: submitted through CSS Profile or directly to school
- CONSTRAINT: Do not omit conditional forms even if they don't apply to the current family â Pearl uses this output across multiple families

**Verification Policy**
- Is this a high-verification school?
- What triggers verification at this school?
- What documents are typically requested?
- If verification policy is not publicly stated: flag as unknown

### Step 3 â Flag Year-Over-Year Changes

For the current filing cycle, flag any known policy changes from prior year:
- Schools that newly adopted or dropped CSS Profile
- Schools that changed their IM home equity cap
- Schools that added or removed supplemental forms
- FAFSA simplification changes (FAFSA Simplification Act continues to phase in through 2025-26) â flag any that affect this school

### Step 4 â Produce the School Requirements Sheet

Output format for a single school:

---

**SCHOOL: [Full Name]**
**Cycle:** [Year]
**Category:** [FAFSA-Only / CSS Profile + FAFSA / CSS Profile + FAFSA + School Supplement]

**FILING REQUIREMENTS**
| Requirement | Required? | Notes |
|-------------|-----------|-------|
| FAFSA | Yes | [Deadline: Month Day] â Priority: [Month Day] |
| CSS Profile | [Yes/No] | [Deadline if required] |
| Non-Custodial Parent Profile | [Yes/Conditional/No] | [Trigger condition] |
| Business/Farm Supplement | [Yes/Conditional/No] | [Trigger condition] |
| School-specific form | [Yes/No] | [Form name if applicable] |

**METHODOLOGY**
- Aid calculation basis: [FM only / FM + IM]
- Home equity treatment: [Not counted / Capped at [X]x income / Uncapped / Unknown]
- Business assets: [Excluded / Included / Ask school directly]
- Retirement assets: [Protected (FM standard) / Subject to IM treatment]

**DEADLINES â RANKED BY IMPACT**
1. Priority deadline: [Date] â [Hard cutoff / Rolling] â Missing this typically costs $[range if known] in aid
2. CSS Profile deadline: [Date]
3. School financial aid deadline: [Date]
4. Verification response deadline: [Typically 30 days after request]

**KNOWN CHANGES FROM PRIOR CYCLE**
- [Change 1, or "No changes identified from [prior cycle]"]

**FLAGS FOR PEARL**
- [Any policy nuance that affects pre-filing strategy]
- [Any school-specific quirk Pearl should know before advising this family]

---

### Step 5 â Multi-School Comparison Format

When checking multiple schools for one student (typical during college selection phase):

---

**FINANCIAL AID REQUIREMENTS â [Student Name] College List**
**Prepared for:** Pearl Lockwood, Lockwood College Prep
**Date:** [Date]
**Cycle:** [Year]

| School | CSS Required | Priority Deadline | Methodology | Supplemental Forms | Key Flag |
|--------|-------------|-------------------|-------------|-------------------|----------|
| [School] | Yes | [Date] | FM + IM | Non-Custodial Profile | Home equity capped 2.5x |
| [School] | No | [Date] | FM only | None | FAFSA-only â no IM impact |
[Continue for all schools]

**Schools Requiring Immediate Action (deadlines within 60 days):**
[List in deadline order]

**Schools with Non-Standard Requirements:**
[Flag any schools with unusual forms, policies, or quirks]

---

## When To Use This Skill

- Before advising a family on whether to apply to a CSS Profile school
- At the start of FAFSA/CSS filing season (October) â run the full college list for each family
- When a family adds a late school to the list and needs requirements fast
- When verifying whether last year's requirements still apply this cycle
- When Christine needs to know what documents to collect for a specific school
- Any time Pearl asks "does [school] require the CSS Profile?"

## Source Hierarchy (Use in This Order)

1. School's official financial aid website â most authoritative for deadlines and forms
2. CSS Profile school list at collegeboard.org â authoritative for which schools require CSS Profile
3. studentaid.gov â authoritative for FAFSA deadlines and federal policy
4. FAFSA Soft and Pay for Ed databases â secondary, cross-reference with primary sources only
5. NASFAA policy notes â for methodology and policy change tracking

When sources conflict: flag the conflict, cite both sources, do not resolve silently.

## Failure Modes and Required Responses

| Situation | Required Response |
|-----------|------------------|
| School's financial aid website is down or unavailable | State this explicitly. Provide prior-cycle data with date. Flag as unverified for current cycle. |
| Deadline not published for current cycle yet | "Deadline not yet published for [cycle]. Typically opens [month] â direct Pearl to check [school].edu/financialaid after [date]." |
| Home equity cap not publicly stated | "Home equity treatment not publicly disclosed. Pearl should call the financial aid office at [number] before advising any family with this school." |
| Pearl asks about aid amounts | "Aid calculation is outside this skill's scope. Use the award-letter-analyzer agent." |
| Multiple schools, some unverified | Produce the full output. Mark each unverified field individually. Do not suppress the output because some data is missing. |

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| State a deadline without a source | Always cite the primary source (school site, collegeboard.org, studentaid.gov) |
| Conflate FM and IM | Treat as distinct systems in every output |
| Assume prior-year policy applies | Flag when using prior-cycle data, mark as unverified |
| Guess at home equity treatment | State "Not publicly confirmed â call financial aid office" |
| Calculate aid amounts | Redirect to award-letter-analyzer agent |
| Resolve source conflicts silently | Flag both sources and both data points |

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns section (Gauntlet QA pass)

## Save Location

Single school: `[Pearl's Vault]/Financial Aid Research/School Requirements/[School Name]-[Cycle]-Requirements.md`

Multi-school comparison: `[Pearl's Vault]/Clients/[Student Last Name]/College-List-Requirements-[Cycle].md`
