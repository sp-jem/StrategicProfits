---
name: exit-value-tracker
description: Evaluates every strategic decision, initiative, or investment against its impact on Game Changer Publishing's enterprise value for a 9-figure exit in 3 years. Scores decisions on the dimensions that acquirers care about: recurring revenue, operational independence from founders, documented systems, client retention, and scalable growth. Produces a go/no-go recommendation with the strategic rationale. Use before any major decision â hiring, technology, pricing change, new service line, partnership â to filter through the exit lens.
license: proprietary
metadata:
tags:
  - program/ctd
---
# Exit Value Tracker

Runs every major GCP decision through the 9-figure exit lens. Tells Cris whether a decision builds enterprise value, is neutral, or quietly erodes it â before she commits resources.

## Why This Exists

Cris has a 3-year exit timeline. She said it in the application: scale is the single biggest challenge. And the exit lens changes what decisions look like. A hire that looks expensive becomes a bargain if it reduces founder dependency. A new service line that looks like revenue becomes a risk if it's unscalable or un-documentable. A technology investment that looks optional becomes essential if it creates verifiable operational leverage.

This skill applies the acquirer's filter to GCP's daily decision-making, so three years of decisions compound toward a premium exit rather than away from it.

## Keywords
exit planning, enterprise value, M&A, acquisition readiness, 9-figure exit, founder dependency, EBITDA, scalable systems, operational independence, business valuation, GCP strategic filter

## Quick Start

1. Describe the decision, initiative, or investment under consideration
2. Specify the type: `hire`, `technology`, `pricing`, `service line`, `partnership`, `process change`, `capital investment`, or `other`
3. Claude runs the exit-value analysis and produces the recommendation
4. Use the output to inform the decision â or paste it to Cris's co-owner for alignment

## Minimum Requirements Before Starting

Before analyzing, verify:

- Clear description of the decision (what is being considered, approximate cost or resource commitment)
- Whether it's been partially decided or is fully open
- Timeline: when does this decision need to be made?

## The 9-Figure Exit Framework for GCP

An acquirer buying a publishing and fulfillment business at 9-figure valuation is buying these things (in order of weight):

**1. Recurring Revenue and Predictability**
How much revenue is contracted, recurring, or highly predictable? One-time project revenue is discounted heavily. Retainer clients, subscription services, licensing arrangements, and multi-book contracts are valued at a premium.

**2. Founder/Owner Independence**
How dependent is GCP's operation on Cris and her husband? An acquirer does not want to buy a job. Businesses where a specific person's knowledge, relationships, or judgment is required to operate are deeply discounted. Every move away from founder-dependence increases exit multiple.

**3. Documented Systems**
Can GCP's 19-section SOP system be handed to a new operator and produce consistent results? Documented, teachable systems command premium multiples. Undocumented expertise is a liability at exit.

**4. Client Retention and Satisfaction**
What does churn look like? Are clients returning for second and third books? Are they referring others? High NPS and retention signals a brand that can survive an ownership change.

**5. Scalable Growth Infrastructure**
Is GCP's growth dependent on Cris's personal relationships and referrals, or has it built lead generation infrastructure that an acquirer can continue operating and scaling? Founder-driven growth doesn't transfer.

**6. Team Depth and Independence**
With no middle management today, GCP is operationally thin. Acquirers buy businesses, not founders. Any improvement in team structure, documentation, and escalation protocols adds direct enterprise value.

**7. Vertical Integration Premium**
GCP owns publishing AND printing/fulfillment. This is a significant competitive moat and a strategic asset to the right acquirer. Initiatives that leverage or deepen this integration should score high.

**8. Proprietary Technology and IP**
The PUBLISH AI app is a proprietary asset. Any initiative that builds, protects, or extends proprietary IP â especially technology IP â commands an acquirer premium.

## Core Workflow

### Step 1 â Classify the Decision

Identify which exit-value dimension(s) this decision primarily affects. Most decisions touch multiple dimensions â identify the primary one and the secondary ones.

### Step 2 â Score the Decision Across Eight Dimensions

For each dimension, score the decision's impact:

- **+2:** Directly and materially builds this dimension of enterprise value
- **+1:** Modestly improves this dimension
- **0:** Neutral â neither builds nor erodes
- **-1:** Modest erosion or neutral distraction that consumes resources
- **-2:** Directly erodes this dimension â makes GCP harder to sell or lowers the multiple

**Dimensions:**
1. Recurring Revenue / Predictability
2. Founder Independence
3. Documented Systems
4. Client Retention / Satisfaction
5. Scalable Growth Infrastructure
6. Team Depth / Independence
7. Vertical Integration Premium
8. Proprietary Technology and IP

**Total range: -16 to +16**

### Step 3 â Payback and Risk Assessment

**Payback period:** How long until this decision generates measurable value? (In months)

**Capital at risk:** Cash, time, or opportunity cost if this goes wrong

**Reversibility:** Easy to undo / Hard to undo / Irreversible

**Acquirer signal:** Would an acquirer see this in due diligence and view it positively, neutrally, or negatively?

### Step 4 â Produce the Recommendation

**Score +8 to +16:** Strong yes. Prioritize and resource properly. Explain why this is exit-accretive.

**Score +2 to +7:** Yes, conditionally. Note what would maximize exit value from this decision.

**Score -1 to +1:** Neutral or unclear. Flag the opportunity cost and decide based on near-term operational need.

**Score -2 to -7:** Caution. This may make sense operationally but it's not building toward exit. Proceed only if operationally necessary, and plan how to reverse or upgrade later.

**Score -8 to -16:** No. This decision makes GCP harder to sell or lowers the multiple. Decline unless there is a compelling operational reason that overrides exit strategy.

## Output Format

---

**GCP EXIT VALUE ANALYSIS**
**Decision:** [Name of the decision being evaluated]
**Type:** [Hire / Technology / Pricing / Service Line / Partnership / Process Change / Capital / Other]
**Date:** [Date]

---

**EXIT VALUE SCORE**

| Dimension | Score | Rationale |
|-----------|-------|-----------|
| Recurring Revenue | [-2 to +2] | [Why] |
| Founder Independence | [-2 to +2] | [Why] |
| Documented Systems | [-2 to +2] | [Why] |
| Client Retention | [-2 to +2] | [Why] |
| Scalable Growth | [-2 to +2] | [Why] |
| Team Depth | [-2 to +2] | [Why] |
| Vertical Integration | [-2 to +2] | [Why] |
| Proprietary IP | [-2 to +2] | [Why] |
| **Total** | **[X/16]** | |

**RECOMMENDATION:** [STRONG YES / YES (CONDITIONAL) / NEUTRAL / CAUTION / NO]

---

**STRATEGIC ANALYSIS**

[3-5 sentences on why this decision lands where it does from an acquirer's perspective. Be specific about what an M&A buyer would see when they look at GCP's financials and operations in 3 years.]

**Payback period:** [X months]
**Capital at risk:** [Description]
**Reversibility:** [Easy / Hard / Irreversible]
**Acquirer signal:** [Positive / Neutral / Negative â and why]

---

**IF YES: How to maximize exit value from this decision**
[2-3 specific actions that would extract maximum enterprise value from proceeding]

**IF CAUTION/NO: What would make this exit-accretive**
[What would need to be different for this decision to score higher â alternative framing, timing, structure, or scope]

---

**CRIS'S EXIT DASHBOARD UPDATE**

Running cumulative notes (append after each analysis):

| Date | Decision | Score | Recommendation |
|------|----------|-------|----------------|
| [Date] | [This decision] | [X/16] | [Rec] |

---

## Operating Rules

**What this skill does:**
- Applies the buyer's lens, not the operator's lens â every analysis states what an acquirer would see in due diligence
- Surfaces Founder Independence impact prominently on every analysis, regardless of overall score â this dimension is GCP's highest-leverage exit lever
- Maintains a running cumulative dashboard of every decision analyzed so the pattern of decisions tells a strategic story over time
- Flags any decision whose payback period exceeds 36 months as effectively irrelevant to exit value

**What this skill never does:**
- Never output "NO" without providing an alternative decision structure that would achieve a better score â the answer to a bad decision is a better-structured decision
- Never let a high Proprietary IP or Vertical Integration score offset a critically low Founder Independence score â score each dimension independently; a -2 on Founder Independence must be called out explicitly even if the total is positive
- Never apply an operator's logic to the scoring â the question is always "what would an acquirer see, pay for, or be concerned about," not "what does Cris find operationally convenient"
- Never produce a "Neutral" recommendation without stating explicitly what near-term operational need would justify proceeding despite zero exit accretion
- Never skip the Cris's Exit Dashboard Update section â every analysis must be appended to the running log, not left for Cris to do manually

**Constraint rules:**
- If the decision description is vague (no cost, no timeline, no scope), do not score â output a list of the three minimum facts needed before analysis can proceed
- Reversibility must be classified as one of three options only: Easy / Hard / Irreversible â "somewhat reversible" or "depends" are not valid classifications
- Any decision scored -8 or below is a hard NO â do not frame it as "Caution" or suggest that operational necessity could override a catastrophic exit impact without Cris explicitly overriding in writing

## When To Use This Skill

- Before any hire that costs more than one month of profit
- Before signing any multi-year vendor or technology contract
- Before launching a new service line or product
- Before any pricing strategy change
- Before entering any partnership or distribution arrangement
- Quarterly: as a portfolio review of the previous quarter's major decisions
- At the start of annual planning to score the proposed initiatives against exit value

## Before You Respond

- [ ] Do I have cost, timeline, and scope for the decision?
- [ ] Have I classified reversibility as Easy / Hard / Irreversible?
- [ ] Did I score each dimension through the acquirer's lens, not the operator's?
- [ ] Is Founder Independence impact called out explicitly?
- [ ] Did I append to the Exit Dashboard?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Before You Respond, Version History (Gauntlet QA pass)
