---
name: pipeline-follow-up-enforcer
description: Analyzes a clinical trial pipeline â active opportunities, stalled deals, dormant sponsors â and produces a prioritized follow-up action list with ready-to-send outreach for each contact. Use when Michelle or Vincent needs to work the pipeline, clear stalled deals, force next actions, or prevent revenue from falling through the cracks due to inaction. Trigger phrases: "pipeline review," "what's stalled," "Vincent needs to follow up," "sponsor outreach," "dead deals," "pipeline check."
license: proprietary
metadata:
tags:
  - program/ctd
---
# Pipeline Follow-Up Enforcer

## Purpose

Takes the raw state of Core Clinical Trials' active sponsor and CRO pipeline and converts it into a prioritized action list with ready-to-send outreach copy â so no deal ever dies from follow-up neglect.

## Minimum Requirements Before Starting

NEVER produce output until the following are confirmed:
- At least one active deal is described with a sponsor/CRO name and last contact date
- Some indication of what "stalled" means (no response for X days, waiting on feasibility, contract delay, etc.)

If deals are described with no dates or contact history, ask: "For each deal, what was the last action taken and when? I need that to prioritize correctly." Do NOT proceed to output until dates and contact history are provided.

NEVER fabricate, estimate, or assume pipeline data not explicitly provided in this session. If deal value, contact dates, or deal stage are missing, flag them with: "Data not provided â confirm with Vincent before prioritizing." Do not insert placeholder figures.

## Core Workflow

### Step 1 â Ingest Pipeline Data

Read all deals provided. For each deal, extract:
- Sponsor or CRO name
- Study type or therapeutic area (GLP-1, oncology, cardiology, etc. â Michelle is expanding into GLP-1, urgent care, specialty practices)
- Deal stage: early interest / feasibility submitted / budget negotiation / contract / active / stalled / silent
- Last contact date and who made it (Michelle, Vincent, Joi)
- Dollar value or estimated revenue if available
- Next action that was supposed to happen

### Step 2 â Triage by Priority

Score each deal on a 1-3 scale. APPLY THESE DEFINITIONS WITHOUT EXCEPTION:

**P1 â Act today:** Deal has revenue potential, went silent within the last 30 days, and no follow-up has been sent since last response. These are the easiest recoveries â the sponsor is still warm.

**P2 â Act this week:** Deal is past the feasibility stage and no next step has been scheduled. Budget or contract is somewhere in discussion but momentum has stalled.

**P3 â Decide or drop:** Deal has been silent more than 60 days with no meaningful engagement since last contact. These need a re-engagement message or a decision to remove from active pipeline.

REQUIRED output format for the triage list:

| Priority | Sponsor/CRO | Stage | Days Since Contact | Owner | Value |
|----------|-------------|-------|-------------------|-------|-------|
| P1 | [Name] | [Stage] | [#] days | Vincent / Joi / Michelle | $[X] |

Sort by Priority, then by Days Since Contact descending within each tier. NEVER skip the sort.

### Step 3 â Write Outreach for Each Deal

REQUIRED: Produce a ready-to-send follow-up message for every P1 and P2 deal. NEVER produce generic outreach. NEVER use the phrase "just following up" or "checking in" in any outreach message â these phrases are prohibited.

**Core Clinical Trials Follow-Up Voice â APPLY TO ALL MESSAGES:**
- Direct. No fluff. Sponsors are busy.
- Opens with the specific context â what was discussed last, not a generic opener
- States a clear next step request â specific, not open-ended ("I'd like to schedule 20 minutes Thursday or Friday â here's a link")
- Brief â 4-6 sentences maximum for email, 2-3 for text/LinkedIn
- Reflects the TrialPulse advantage when relevant (single contract, single budget, 14+ therapeutic areas, largest alliance in North America)

REQUIRED output format per deal:

---

**[Sponsor/CRO Name] â P[1/2]**
Stage: [Stage]
Last contact: [Date] by [Who]
Recommended owner: [Vincent / Michelle / Joi]
Channel: [Email / Text / Call]

Subject: [If email]

[Message body â complete, ready to send]

**Why this angle:** [1 sentence on why this message approach is right for this deal]

---

### Step 4 â P3 Re-Engagement or Removal Decision

REQUIRED: For every P3 deal, produce a decision framework. NEVER leave a P3 deal with no action or no removal decision.

**[Sponsor/CRO Name] â P3 (60+ days silent)**
Last known status: [What was happening before silence]
Re-engagement message: [Short 3-sentence message to test if they're still alive]
If no response in 7 days: Remove from active pipeline. Log reason as "sponsor unresponsive."

### Step 5 â Delegation Table

REQUIRED: Produce a delegation table so Michelle can hand this directly to Vincent and Joi without a meeting. NEVER produce a follow-up list without an assigned owner and a deadline.

**Vincent's Follow-Up List â Week of [Date]**

| # | Sponsor/CRO | Action Required | Send By | Channel |
|---|-------------|----------------|---------|---------|
| 1 | [Name] | [Specific action â send email, schedule call, submit revised budget] | [Day] | [Email/Text/Call] |

**Joi's Follow-Up List â Week of [Date]**

[Same structure â typically lower-stakes P2/P3 re-engagement tasks]

**Michelle Handles Personally:**

[Reserved for high-value deals, budget negotiation conversations, or sponsor relationships where Michelle's CEO-level engagement is the differentiator. MAXIMUM 3 items. Do not include process tasks here.]

## Operating Rules

- NEVER produce generic follow-up copy. Every message MUST reference the specific sponsor, study type, or last interaction detail. "Just following up" is prohibited output.
- ALWAYS assign an owner. A follow-up without an assigned person is not a follow-up â it is noise.
- ALWAYS set a deadline. "Send by [day]" is REQUIRED on every action item. An action item without a deadline is incomplete.
- If value data is missing, flag it: "Revenue potential unknown â ask Vincent to confirm before prioritizing." NEVER assign P1 priority to a deal with no value signal.
- NEVER fabricate contact history, deal stages, or dollar figures. If data is absent, mark the field: "Data not provided."
- Salesforce data gaps MUST be flagged as a Joi task. If a deal has missing dates, missing stage, or missing value: add it to a "Salesforce Cleanup" section and assign to Joi with a 10-minute completion estimate.
- CCT's positioning: largest alliance of clinical trial research sites in North America, TrialPulse technology, single contract/budget/POC. Use when relevant to the sponsor's apparent pain â NEVER force it into messages where it does not fit.
- Michelle's time is the most expensive resource in this output. ONLY flag her for deals where her personal involvement materially changes the outcome. NEVER include process tasks in her personal list.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Produce generic "just following up" copy | Every message references specific sponsor/study/interaction |
| Assign a P1 priority without value data | Flag missing value data and ask Vincent to confirm |
| Leave a P3 deal with no decision | Either re-engage or flag for removal |
| Include process tasks in Michelle's personal list | Max 3 items â only deals where her involvement changes outcome |
| Fabricate contact history or deal stages | Mark "Data not provided" when absent |
| Force CCT positioning into every message | Use only when it fits the sponsor's apparent pain |

## Before You Respond

- [ ] Do I have pipeline data (at minimum: sponsor name, stage, last contact)?
- [ ] Have I classified every deal P1/P2/P3?
- [ ] Is every follow-up assigned to Vincent, Joi, or Michelle?
- [ ] Does every action have a deadline?
- [ ] Are Salesforce data gaps flagged to Joi?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
