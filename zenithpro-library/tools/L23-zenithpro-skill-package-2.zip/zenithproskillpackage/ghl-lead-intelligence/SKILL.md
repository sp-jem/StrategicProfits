---
name: ghl-lead-intelligence
description: Score and route new GHL contacts based on engagement signals and profile completeness. Use when you need to qualify a new lead, prioritize outreach, segment contacts by temperature, decide who follows up first, or route a contact to the right pipeline stage. Trigger phrases: "score this lead," "qualify this contact," "who should follow up," "hot or cold," "route this lead," "prioritize my leads," "lead scoring," "engagement signals," "which leads are worth calling."
license: proprietary
metadata:
tags:
  - program/ctd
  - ghl
  - leads
  - intelligence
---
# GHL Lead Intelligence

## Purpose

Pulls a contact's full profile and conversation history from GHL, applies an engagement-based scoring model, assigns a temperature rating and routing decision, and outputs a prioritized action card â so every new lead gets the right follow-up from the right person at the right time, without manual review.

## Instructions

### Step 1 â Locate the Contact

Call `search_contacts` with the name, email, or phone number provided by the user.

If multiple matches are returned, list them in this format and ask the user to confirm which one:

| # | Name | Email | Phone | Created |
|---|------|-------|-------|---------|
| 1 | [Name] | [Email] | [Phone] | [Date] |

NEVER proceed with scoring until the correct contact is confirmed.

### Step 2 â Pull Full Contact Profile

Call `get_contact` using the confirmed contact ID.

Extract and record the following fields:
- Full name, email, phone
- Source / Lead Source tag (if present)
- Tags currently applied
- Custom fields relevant to qualification (budget, timeline, company size, role â whatever is populated)
- Created date
- Assigned user (owner)
- Current pipeline stage (if any)
- Last activity date

Flag any required qualification fields that are EMPTY. Empty fields are data gaps â they will lower the profile completeness score.

### Step 3 â Pull Conversation History

Call `search_conversations` using the contact's email or phone to find their conversation thread.

Then call `get_recent_messages` on the conversation ID to retrieve the last 10-20 messages.

Record:
- Total number of inbound messages from the contact
- Total number of outbound messages sent to the contact
- Date of most recent inbound message
- Date of most recent outbound message
- Whether the contact has replied at all
- Most recent message content (summarize in 1-2 sentences)
- Any stated intent signals: asked a price question, mentioned a competitor, used urgency language, asked about next steps

### Step 4 â Score the Lead

Apply the following scoring model. NEVER skip categories. NEVER inflate scores.

#### A. Profile Completeness (max 25 points)
- Email present: +5
- Phone present: +5
- Source/channel known: +5
- At least one custom qualification field populated: +5
- Assigned to a specific owner: +5

#### B. Engagement Depth (max 35 points)
- Has replied at least once: +10
- Has sent 3+ inbound messages: +10
- Most recent inbound within 24 hours: +10 (within 72 hours: +5, beyond 72 hours: +0)
- Mentioned price, timeline, or next steps: +5

#### C. Intent Signals (max 25 points)
- Source is paid ad or referral (vs. organic cold): +10
- Tags include buyer-intent indicators (e.g., "hot lead," "requested demo," "applied"): +10
- Explicitly requested a call, demo, or proposal: +5

#### D. Recency Penalty (applied after totals)
- No inbound activity in past 7 days: -10
- No inbound activity in past 30 days: -20
- Never replied to any message: -15

**Final Score Calculation:**
Total raw score (A+B+C) minus recency penalty = Final Score (0-85 max)

**Temperature Assignments:**
- 65-85: HOT â Call within 2 hours
- 40-64: WARM â Follow up within 24 hours
- 20-39: COOL â Nurture sequence, follow up within 72 hours
- 0-19: COLD â Assign to long-term nurture or archive

### Step 5 â Apply Tags and Update Contact

Call `add_contact_tags` to apply the appropriate temperature tag:
- `lead-hot`, `lead-warm`, `lead-cool`, or `lead-cold`

If a previous temperature tag exists that conflicts, note it in the output. Do NOT remove old tags automatically â flag for manual review.

Call `update_contact` to:
- Set or confirm the assigned owner based on the routing decision below
- Update any custom field that captures lead score (if the account uses one)

### Step 6 â Routing Decision

Apply this routing logic WITHOUT exception:

| Temperature | Routing | Owner | Timeline |
|-------------|---------|-------|----------|
| HOT | Direct to closer or senior sales rep | Assigned rep or manager | 2 hours |
| WARM | Standard follow-up queue | Assigned rep | 24 hours |
| COOL | Automated nurture sequence + manual check-in | Assigned rep or automation | 72 hours |
| COLD | Long-term drip or archive decision | Manager review | 7 days |

If no owner is assigned in GHL, flag this: "No owner assigned â routing cannot be completed until an owner is set. Assign in GHL or specify here."

### Step 7 â Output: Lead Intelligence Card

Produce a structured card for the lead. NEVER produce a generic summary.

---

## Lead Intelligence Card

**Contact:** [Full Name]
**Email:** [Email] | **Phone:** [Phone]
**Source:** [Lead Source]
**Created:** [Date] | **Owner:** [Assigned Rep or "Unassigned"]

### Score Breakdown

| Category | Points Earned | Max |
|----------|--------------|-----|
| Profile Completeness | [X] | 25 |
| Engagement Depth | [X] | 35 |
| Intent Signals | [X] | 25 |
| Recency Penalty | -[X] | â |
| **Final Score** | **[X]** | **85** |

**Temperature: [HOT / WARM / COOL / COLD]**

### Engagement Summary
- Inbound messages: [#]
- Last inbound: [date/time]
- Last outbound: [date/time]
- Reply rate: [Replied / Never replied]
- Most recent message: [1-2 sentence summary]

### Intent Signals Detected
[List each signal found, or "None detected"]

### Data Gaps
[List every empty qualification field, or "None â profile complete"]

### Routing Decision
- **Assign to:** [Name or "Unassigned â action required"]
- **Follow-up by:** [Specific day/time]
- **Recommended channel:** [Call / SMS / Email]
- **Tags applied:** [list]

### Recommended First Message
[Write a specific, non-generic opening message or call script opener based on the contact's source, most recent message, and intent signals. NEVER use "just following up" or "checking in." Reference the specific context that brought them in.]

---

## Constraints

- NEVER score a contact without pulling live GHL data first. Static scoring from assumptions is prohibited.
- NEVER apply a HOT tag without at least one inbound engagement signal OR paid-ad/referral source combined with recency within 24 hours.
- ALWAYS list data gaps. A score without flagged gaps is incomplete output.
- NEVER assign routing without an owner name. "TBD" or "someone" is not a routing decision â flag as "Unassigned â action required" and halt routing.
- ALWAYS write a specific recommended first message. Generic outreach starters are prohibited output.
- NEVER remove existing tags. Only add temperature tags and flag conflicts.
- If `search_conversations` returns no conversation, the engagement score for inbound messages is 0. Do NOT assume engagement exists because a contact is in GHL.
- ALWAYS note the score breakdown by category â never show only the final number.
- If contact was created more than 30 days ago with zero inbound activity, flag for manager review before any further outreach. These contacts may need re-permission before contact.
- NEVER overwrite the owner field in `update_contact` without confirming the new owner with the user. Routing assignment and CRM owner update are separate decisions.
- NEVER proceed with scoring if the contact cannot be uniquely confirmed. Multiple matches require explicit user selection before any data is pulled.
- NEVER use "just following up," "checking in," or "touching base" in the Recommended First Message. Reference the specific context: source, last message, or stated goal.

## Reference

**MCP Server:** BusyBee3333 GHL MCP

**Tools used in this skill:**
- `search_contacts` â Find contact by name, email, or phone
- `get_contact` â Retrieve full contact profile and fields
- `search_conversations` â Find conversation thread for the contact
- `get_recent_messages` â Pull last 10-20 messages from conversation
- `add_contact_tags` â Apply temperature tag to contact
- `update_contact` â Set owner and update qualification fields

**Configuration required:**
- GHL Location ID must be set in MCP server config
- Temperature tags (`lead-hot`, `lead-warm`, `lead-cool`, `lead-cold`) must exist in the GHL account before this skill can apply them

**Failure Modes:**

MCP not connected: "GHL MCP server is not responding. Cannot pull live contact data. Verify the BusyBee3333 MCP server is running and your location ID is correctly configured."

Contact not found: "No match found for [identifier] in GHL. Check spelling, try alternate email/phone, or confirm the contact exists in this sub-account."

No conversation history: Score the contact on profile completeness and intent signals only. Apply the maximum recency penalty. Flag: "No conversation history found â engagement scores set to zero. Treat as first-contact lead."

Ambiguous identity (multiple matches): List all matches and require user confirmation before proceeding. Never guess which contact to score.

Empty profile (all fields blank): Score as COLD by default. Flag all empty fields. Recommend data enrichment before outreach.
