---
name: bottleneck-bypass-delegator
description: Identifies where Keith is the bottleneck across DWM, EMF Gone, and Level 5 â specifically creative decisions, copy feedback, Keynote reviews, and funnel fine-tuning â and produces delegation-ready task packages for Jeff Wyborny, Tony Kasza, Brandon Dauphinais, or Abigail Morgan. Converts Keith's "I need to do this" list into "here is what each person gets to run with." Use when Keith recognizes he's the thing holding something up.
license: proprietary
metadata:
tags:
  - program/ctd
---
# Bottleneck Bypass Delegator

## Purpose

Converts the tasks only Keith thinks he can do into structured handoffs that his team can actually execute â without a call with Keith to explain it.

## Keywords
delegation, bottleneck, team, Jeff Wyborny, Tony Kasza, Brandon Dauphinais, Abigail Morgan, DWM, EMF Gone, Level 5, handoff, task package, creative decisions, copy feedback, perfectionism, shipping

## Instructions

### Quick Start

1. Dump everything currently sitting on Keith's plate: the list of things he hasn't passed to anyone. Rough is fine.
2. Review the three-bucket sort: (a) must be Keith, (b) delegatable with a brief, (c) should already be delegated
3. Review the delegation packages for categories (b) and (c)
4. Send the packages â no follow-up calls required

### Minimum Requirements Before Starting

Do not generate delegation packages without:
- Keith's current list of open tasks (a brain dump is sufficient)
- Which companies are involved (DWM / EMF Gone / Level 5)
- Which team members are active and available

If Keith does not have a list ready, ask exactly this: "Give me a brain dump â what's sitting on your desk right now that you haven't moved on?"

Do not proceed by generating generic delegation structures. Without the actual task dump, there is nothing to delegate.

### Core Workflow

**Step 1 â Sort the Task Dump**
Read Keith's full list. Sort every item into three buckets:

**Bucket A â Must Be Keith:** Tasks that require Keith's expertise, relationships, or authority that genuinely cannot be transferred. (Example: a strategy call with a high-value DWM client, a keynote Keith is the face of.)

**Bucket B â Delegatable With a Brief:** Tasks Keith thinks he must do because no one has the context, but with a proper brief, a team member can handle them. This is the target bucket â most items land here.

**Bucket C â Should Already Be Delegated:** Tasks that are clearly within a team member's existing role and require no input from Keith. Flag these explicitly â they reveal where the systemic bottleneck pattern lives.

**Step 2 â Match to Team Members**
For each Bucket B and C task:
- Identify who on the team is the right owner (use the team reference below)
- Confirm this person has the capability for this type of task
- Note any dependency (e.g., Brandon needs the brief before he can launch; Tony needs the talking points before he can follow up)

Do not assign tasks to team members outside their role capability. Brandon handles ads execution, not coaching. Tony handles sales, not campaign setup.

**Step 3 â Write Delegation Packages**
For each delegatable task, write a package that includes all seven fields. Do not omit any field.

**Step 4 â Produce Keith's Shortened List**
After generating all delegation packages, produce a cleaned version of Keith's task list:
- Items delegated: show who owns them now
- Items that are genuinely Keith's: show only what remains

**Step 5 â Name the Pattern**
If the task dump reveals a systematic bottleneck, name it explicitly. Example: "Brandon is waiting for Keith on every ad decision because there's no standing authorization. The one-time fix is a standing authorization covering standard ad changes under $X." Single-item observations are tactical. Patterns reveal structural problems. Name the pattern.

## Reference

### Team Capabilities

**DWM Team**

Jeff Wyborny â Onboarding, coaching, sales. Can handle: client onboarding sequences, coaching call prep, sales follow-up, client communication drafts. Strong with people and process. Not primarily a technical ads person.

Tony Kasza â Sales and coaching. Can handle: sales call follow-ups, client objection handling, coaching materials review, testimonial collection.

Brandon Dauphinais â Support and ads execution. Can handle: Meta campaign setup and optimization, ad account troubleshooting, creative testing, campaign monitoring. Requires clear briefs from Keith â will not act well on ambiguous instructions.

**EMF Gone Team**

Dr. Lonnie Herman â Product and credibility. Can handle: scientific content review, product claims verification, content requiring medical authority. Do not delegate marketing strategy or ad copy approval to Dr. Herman without his input on claims.

Joakim Hansson â Operations (transitioning out). Currently handles operational continuity tasks only. Do not assign new strategic projects to Joakim.

Natalia Hansson â Finance and support. Can handle: payment processing, refunds, customer support tickets, invoicing.

**Level 5 Team**

Brian D. Ridgway â Creator and partner. Can handle: content creation for Level 5 material, coaching delivery, program development. Not primarily operational.

Abigail Morgan â CEO (acquiring partnership %). Can handle: strategic operations, partnerships, organizational decisions. Treat her as a CEO-level partner for delegation purposes. As she acquires more %, her scope expands.

## Output

```markdown
# DELEGATION PACKAGES
**Generated for:** Keith Krance
**Date:** [Date]
**Task dump reviewed:** [Number] items
**Delegated:** [Number] items
**Remains with Keith:** [Number] items

---

## BUCKET A â KEITH ONLY
These require Keith's presence, expertise, or relationship. They stay on his list.

| # | Task | Why Keith Only |
|---|------|---------------|
| 1 | [Task] | [Reason] |
| 2 | [Task] | [Reason] |

---

## BUCKET B â DELEGATABLE WITH BRIEF

### Package 1 â [Task Name]
**Assigned to:** [Team member name]
**Company:** [DWM / EMF Gone / Level 5]

**What to do:**
[Clear, specific instructions â written so this person can act without calling Keith]

**Definition of done:**
[What the finished result looks like]

**Keith does NOT need to review:**
[Explicit statement â "You do not need Keith's approval to send this. Just send it." Every package must include this field.]

**Keith must approve before:**
[Only list if truly necessary. "Nothing â just ship it." is a valid answer here.]

**Deadline:** [Date/time]

**If stuck:** [Specific escalation path â not "ask Keith." Example: "If the client escalates beyond X, bring it to Jeff." or "If Brandon can't get the ad account access, contact Natalia who has the login credentials."]

---

### Package [#] â [Task Name]
[Same structure]

---

## BUCKET C â SHOULD ALREADY BE DELEGATED
These are in Keith's task list when they should not be. Each one represents a systemic gap.

| # | Task | Who Should Own This | Why It's In Keith's List |
|---|------|--------------------|-----------------------|
| 1 | [Task] | [Name] | [Reason â missing process, unclear role ownership, no standing authorization, etc.] |

**Pattern:** [Name the theme if 2 or more Bucket C items share a root cause. Example: "3 of 4 Bucket C items involve Brandon not being empowered to act on ad decisions without Keith's approval. The fix is a standing authorization covering standard ad changes under $X."]

---

## KEITH'S REMAINING LIST
After delegation, Keith is responsible for:

1. [Task] â [Why Keith only / Est. time]
2. [Task] â [Why Keith only / Est. time]

**Total Keith time required:** ~[X hours]
```

## Constraints

- Never generate a delegation package for a task that genuinely requires Keith's expertise or relationship. Forcing delegation on the wrong items destroys trust.
- The "What Keith does NOT need to review" field is mandatory in every package. If this field is absent, the package defaults back to Keith reviewing everything â which is the problem this skill exists to fix.
- Never leave the "If stuck" field blank. Every delegated task must have a defined escalation path that does not default to "ask Keith."
- If Keith's task dump includes vague ideas or future considerations that are not actionable, move them to a parking lot section. Do not attempt to delegate what is not yet a defined task.
- Do not create false urgency. If a task has no real deadline, write "Flexible â complete within [week/two weeks]." Manufactured deadlines undermine the team's trust in delegation packages.
- The Bucket C pattern observation is required whenever 2 or more Bucket C items share a root cause. Naming the pattern once is how the bottleneck gets fixed systemically, not just for this task dump.

## When To Use This Skill

- When Keith has a pile of tasks he's been avoiding because they all "need him"
- Before any week where Keith has heavy external commitments (travel, events, speaking) and needs his team running without him
- When a launch has been delayed because Keith hasn't had time to review something
- When Keith recognizes he's the bottleneck and wants to act on it

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Generate a delegation package for a task that truly needs Keith | Forcing bad delegation destroys trust |
| Leave "What Keith does NOT need to review" blank | Mandatory field â absent = Keith reviews everything |
| Leave "If stuck" escalation path blank | Every task has an escalation that isn't "ask Keith" |
| Create false urgency with fake deadlines | "Flexible â complete within [window]" when no real deadline exists |
| Skip the Bucket C pattern observation | Name the root cause when 2+ items share one |
| Delegate vague future considerations | Move to a parking lot â not yet actionable |

## Before You Respond

- [ ] Have I classified every task into Bucket A (Keith only), B (delegable), or C (already should be)?
- [ ] Does every delegated task have a named owner?
- [ ] Does every package include "What Keith does NOT need to review"?
- [ ] Does every package have an "If stuck" escalation path?
- [ ] Did I name the pattern for Bucket C items sharing a root cause?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
