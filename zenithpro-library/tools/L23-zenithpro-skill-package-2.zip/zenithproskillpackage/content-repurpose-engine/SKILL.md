---
name: content-repurpose-engine
description: Takes one piece of Steve's content â a podcast episode transcript, YouTube video transcript, keynote recording, or raw voice note â and produces a complete multi-platform distribution package. Film once, appear everywhere. Use this immediately after any content recording. Trigger phrases include "repurpose this," "turn this into content," "distribute this episode," "make posts from this," or whenever Steve or Marley drops a transcript or recording.
license: proprietary
metadata:
tags:
  - program/ctd
---
# Content Repurpose Engine

One transcript in. Full content stack out â podcast description, email, Instagram, LinkedIn, Twitter/X thread, short-form clip recommendations, and DM opener. All from a single source recording.

---

## Purpose

Produce a complete 7-asset distribution package from a single source transcript. Every asset is finished copy ready to copy-paste into a platform scheduler â not a template, not a draft with placeholders. All seven assets must be delivered in a single output run.

**Required input:** Source transcript â minimum 300 words. Podcast episode, YouTube video, keynote, or voice note.

**Optional inputs:**
- Source type (podcast, YouTube, keynote, voice note) â default: podcast/spoken word
- Primary CTA â default priority: Titans ("DM Steve") > Offer Launch ("Grab the book") > School of Money ("Join here")
- Platforms to exclude â if specified, produce nothing for that platform and note the exclusion at the top of output

---

## Instructions

### Step 1 â Content Mining

Read the full transcript. Extract and produce internally before writing any asset:

```
SOURCE CONTENT BRIEF
Type: [Podcast / YouTube / Keynote / Voice Note]
Core argument: [The single most important thing Steve said â one sentence]
Best story: [The most compelling anecdote or example]
Best one-liners: [Top 5 quotable lines, verbatim from the transcript]
Key framework/concept mentioned: [Named frameworks, formulas, or processes Steve referenced]
Natural hooks: [Moments that create curiosity or would stop a scroll]
Primary CTA for this piece: [What action Steve wants the audience to take]
```

### Step 2 â Full Distribution Package

Produce all assets in the following order:

**A. EPISODE DESCRIPTION (Podcast / YouTube)**
150-200 words. Starts with the core argument. Written for the person who reads descriptions before hitting play. Include 3-5 bullet points of what they'll learn (specific, not vague). End with the CTA.

**B. EMAIL NEWSLETTER (Send to list)**
Subject line: 3 options, each under 50 characters
Preview text: One line that completes the story the subject starts

Body structure:
- Opening: The best hook from the episode, reframed as a direct address to the reader
- Middle: The core argument + the best story (condensed, not summarized â tell the story)
- Proof or payoff: The "so what" â what this means for the reader specifically
- CTA: Single clear action

Length: 350-450 words. Steve's voice. No "hope you're having a great week." No newsletter fluff.

**C. INSTAGRAM CAPTION (Feed post)**
Under 150 words. Lead with the best one-liner. Use line breaks aggressively. End with a question or CTA. Include 5 relevant hashtags at the bottom.

Reel hook (first 3 seconds of script): Write the first sentence Steve says on camera â provocative, incomplete without the next 30 seconds.

**D. LINKEDIN POST**
Hook line: One sentence that stops a scroll in a professional context.
Full post: 200-250 words. One strong argument, one story, one CTA. Develop the argument â not a list.

**E. TWITTER/X THREAD**
Thread starter tweet: Under 280 characters. Best one-liner or most provocative claim from the episode.
Tweets 2-6: Develop the core argument in 5 additional tweets, each under 280 characters.
Final tweet: CTA + episode link placeholder.

**F. SHORT-FORM CLIP RECOMMENDATIONS**
List 3 moments from the transcript that work as standalone short-form clips (YouTube Shorts, Instagram Reels, TikTok). For each:
- Timestamp reference (if available) or exact quote the lines
- Why this clip works standalone: what makes it complete without context
- Recommended caption: one sentence

Flag any clip that would work especially well on Marley's YouTube channel (200K subscribers).

**G. DM OPENER (for Marley or Steve to use manually)**
One sentence to start a conversation about this episode. Not a broadcast message â a genuine reach-out to someone specific. "Sent this to you specifically because..." framing.

---

## Operating Rules

**NEVER begin the distribution package until a transcript of at least 300 words is provided.** If the input is shorter, state: "This transcript is under 300 words. A full distribution package requires more source material. Provide more content or confirm this is the complete input." Do not produce partial packages.

**NEVER add ideas, arguments, or claims not in Steve's source transcript.** Every sentence in every asset must trace back to what he actually said. Invented content is a disqualifying failure.

**NEVER sanitize Steve's language.** If he said "you're bleeding out," keep it. Changing his actual words to softer alternatives is a prohibited edit. Preserve and amplify â do not homogenize.

**NEVER point to different offers in different assets from the same episode.** The CTA must be consistent across all seven assets unless Steve explicitly specifies a platform-specific split.

**NEVER use corporate or agency language.** Prohibited: "synergy," "actionable insights," "leverage your ecosystem," "game-changing," or any equivalent. Flag and remove before delivering.

**ALWAYS produce all seven assets in a single output.** A package missing any of the seven sections is incomplete. If a platform is excluded by Steve's instruction, note the exclusion at the top â the remaining six must still be delivered.

**ALWAYS clean grammar and coherence on rough voice notes** without changing Steve's arguments or adding content he did not say. Permitted: fix sentence fragments, remove filler words (um, like, you know), fix duplicate words. Prohibited: reorder arguments, merge two separate points, add transitions he did not imply, soften language. Clean presentation, original substance.

**If the transcript contains multiple competing arguments:** Identify the strongest one as the core argument. Use the others as supporting points in the email (Asset B) and LinkedIn (Asset D) only. Do not try to build 7 assets around competing ideas â pick one and commit.

**Failure modes:**
- If the transcript contains no clear core argument: extract the best candidate and flag it â "Core argument identified as [X]. If this is wrong, confirm the intended focus before I proceed."
- If the transcript is a raw voice note with no coherent structure: clean it for readability, then proceed â do not ask for a cleaner version unless the content is genuinely incoherent.
- If Steve specifies a platform to exclude mid-session after the package is started: produce the note of exclusion and deliver all remaining assets â do not restart from scratch.

---

## Output Format

Deliver the full package in section order (A through G), labeled by platform. Use horizontal rules between sections. The whole package must be ready to copy-paste into each platform's scheduler.

---

## Reference

**Steve's active content channels:**
- Sales Funnel Radio (podcast)
- Launch for Profit (podcast)
- YouTube
- Instagram
- LinkedIn
- Email list
- Twitter/X

**Marley Larsen's YouTube:** 200K subscribers. Cross-promotion opportunities between Steve's content and her channel are flagged in the short-form clip recommendations section (F).

**Current offer priority (default CTA order):**
1. Titans of Industry â DM Steve
2. Offer Launch (book) â grab the book
3. School of Money â join here

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Add ideas not in the transcript | Every sentence traces back to what Steve said |
| Sanitize Steve's language | Preserve his actual words â amplify, don't homogenize |
| Point to different CTAs across assets | One consistent CTA unless Steve specifies a split |
| Use agency language ("actionable insights") | Steve's voice is direct and provocateur |
| Produce a partial package | All 7 assets in one output or note the exclusion |
| Clean a voice note by reordering arguments | Fix fragments and filler only â substance stays intact |

## Before You Respond

- [ ] Do I have a transcript of at least 300 words?
- [ ] Have I identified the core argument (one sentence)?
- [ ] Do I know the CTA (default: Titans > Offer Launch > School of Money)?
- [ ] Am I producing all 7 assets (or noting which are excluded)?
- [ ] Is every sentence traceable to something Steve actually said?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History, grammar cleaning boundary, competing arguments protocol (Gauntlet QA pass)

**Related tools:**
- content-broadcast-monitor (perpetual agent) â tracks what's been distributed and what's missing
- ai-steve (agent) â for drafting content when Steve does not have time to record
