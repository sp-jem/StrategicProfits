---
name: stage-sales-accelerator
description: Builds every asset Marshall needs before, during, and after a stage sales presentation â talk structure, offer stack framing, close sequence, follow-up emails. Use when Marshall is preparing a stage talk, needs a close sequence written, is building a new offer to present from stage, or says anything like "I have a speaking event," "I need to close from stage," "build my presentation," or "write my follow-up sequence."
license: proprietary
vault_path: "[YOUR_VAULT]/Marshall Sylver/Stage Sales/"
metadata:
tags:
  - program/ctd
---
# Stage Sales Accelerator

Builds the complete pre-stage, on-stage, and post-stage asset stack for Marshall Sylver â the world's leading stage hypnotist and closer. Covers talk architecture, offer framing, close sequence, and the follow-up email sequence that converts the room that didn't buy in the moment.

## Constraints

**NEVER fabricate offer stack values, testimonials, client results, or event-specific facts.** Every number in the close script and follow-up emails must come from Marshall. Fabricated specifics destroy credibility on stage and create legal exposure. Mark every unverified item with [NEEDS REAL RESULT] and stop until Marshall provides it.

**NEVER write a generic close.** If the close script could apply to any speaker at any event, it is wrong. Rewrite until it is specific to Marshall's voice, this event's audience, and this offer's mechanism.

**NEVER deliver a close script that sounds like marketing copy read aloud.** Read every close line aloud before delivering. If it sounds written rather than spoken, rewrite it.

**NEVER invent urgency or scarcity that does not exist.** If there is no real deadline or limited availability, use a decision-forcing frame instead. False scarcity destroys trust permanently.

**NEVER write the follow-up sequence as a rehash of the stage close.** The audience that didn't buy from stage didn't buy for a reason. The emails address that reason â they do not repeat the same pitch in a new format.

**NEVER use hedging language in Marshall's voice.** The words "just," "maybe," "if you're interested," "might," and "could" are not in Marshall's vocabulary. Delete them from every draft.

## Keywords
stage close, speaking event, from-stage selling, offer stack, talk structure, close sequence, presentation script, stage hypnosis, follow-up sequence, back of room, event close, keynote, irresistible offer, stage presentation, conference sales

## Quick Start

1. Tell Marshall: "Run stage-sales-accelerator for [Event Name] on [Date]"
2. Provide: event audience (who are they?), primary offer being closed, price point, and any existing talk notes
3. If no notes exist, Claude interviews Marshall on the 5 key inputs below
4. Claude produces the full asset stack: talk outline, offer stack one-sheet, close script, and 5-email follow-up sequence
5. Marshall reviews, adjusts the price/offer details, and the assets are ready

No configuration required. Works from event briefing Marshall provides.

## 5 Key Inputs (Collected at Session Start)

Before producing any assets, gather these five inputs. If Marshall provides them upfront, skip to production. If not, ask for them directly:

1. **Event context:** Who is the audience? Industry, sophistication level, average income? How many people in the room? What did they pay to attend?
2. **Primary offer:** What is being closed? Program name, what it delivers, price point, bonuses?
3. **Talk slot:** How long is Marshall's time on stage? Is this a keynote, breakout, or workshop?
4. **Known room dynamics:** Is this a buyer's market (motivated), a skeptics market, or unknown? Has Marshall spoken to this audience before?
5. **Goal:** Revenue target for the event? Full close from stage, or stage close driving booked calls?

## Core Workflow

### Phase 1 â Talk Architecture

Design the talk structure using Marshall's stage-selling DNA: hypnotic rapport â belief installation â desire amplification â offer reveal â close. This is not a generic speaking structure â it is built around Marshall's specific ability to shift audience state through stage hypnosis and presence.

**Talk Structure Template:**

**OPEN (10% of time)**
- Pattern interrupt: something that immediately separates Marshall from every other speaker they've seen today
- Credibility without bragging: one specific result from one specific client
- Frame for the hour: "By the end of this, you will [outcome] â if you're willing to do one thing"

**RAPPORT AND STATE SHIFT (20% of time)**
- Marshall's signature move: audience participation or live demonstration that creates collective state change
- Mirror-and-lead into receptive state
- Establish the "Marshall frame": I have done this, and I can show you

**BELIEF INSTALLATION (30% of time)**
- Identify the #1 limiting belief in this specific audience
- Walk through the belief-reversal mechanism Marshall uses (name the specific framework or story that does this)
- Three proof moments: one logical, one emotional, one social
- Plant the seed for the offer: "The people who [do this thing] are the ones who [outcome]"

**DESIRE AMPLIFICATION (20% of time)**
- Future pace: walk them through what their life looks like in 12 months if this belief shift takes hold
- Cost of not acting: what has the old belief already cost them?
- The bridge: Marshall's offer is the fastest path from current state to future state

**OFFER REVEAL AND CLOSE (20% of time)**
- Offer stack reveal (see Phase 2)
- The close sequence (see Phase 3)
- Handle the room's top 3 objections in the close itself

### Phase 2 â Offer Stack One-Sheet

Produce a one-page offer stack framing document Marshall can use both as a visual aid and as the source document for the close script.

**Format:**

---
**OFFER STACK: [Program Name]**
**Prepared for:** [Event Name]
**Date:** [Date]

**What You're Getting:**

| Component | What It Is | Value |
|-----------|-----------|-------|
| [Core program] | [One-sentence description] | $[price] |
| [Bonus 1] | [One-sentence description] | $[value] |
| [Bonus 2] | [One-sentence description] | $[value] |
| [Bonus 3] | [One-sentence description] | $[value] |

**Total Real Value:** $[sum]
**You Invest Today:** $[actual price]
**You Save:** $[difference]

**What Makes This Different From Everything Else You've Seen Today:**
[One paragraph. Specific to this audience's likely sophistication and what they've already been offered.]

**The Guarantee:**
[State guarantee plainly. If there is no guarantee, say so and give the reason that makes that more compelling, not less.]

---

### Phase 3 â Close Script

A word-for-word close sequence that Marshall can use from stage. Written in Marshall's voice: direct, hypnotic, certainty-driven. Not soft. Not hesitant. Closes assume the sale.

**Close Sequence Structure:**

**THE PERMISSION FRAME**
"I'm going to make you an offer right now. Before I do â raise your hand if you've ever sat in a room like this, heard someone make you an offer, and thought 'that sounds interesting' but you didn't act, and six months later you were in the exact same situation? [pause] Right. I don't want that to happen to you today. So I'm going to make this very easy."

**THE OFFER REVEAL**
[Walk through the offer stack â name each component, state its standalone value, pause after each one. Do not rush. Let the stack build.]

**THE PRICE REVEAL**
"All of that â [brief recap of stack] â is [price]. Not [higher price]. Not [medium price]. [price]. Here's why I'm doing this..."
[Give a real reason: event special, Marshall's belief in this audience, specific outcome they can get by year-end, etc.]

**THE URGENCY FRAME** (if real scarcity exists, use it; if not, use a decision-forcing frame instead)
[Real scarcity: "I can only personally work with X people and here's why." Decision frame: "The only question is whether you're going to decide today or decide in three months after nothing has changed."]

**THE WALK TO THE TABLE**
"If you're ready, here's what you do right now: [specific action â go to the back, pull out your phone, approach my team]. My team is in the back and they're going to take care of you."

**SOCIAL PROOF ACCELERATOR**
After the first wave of people move: "Look at that. These are the people who are going to be telling a completely different story six months from now."

**THE LAST CALL**
"For anyone still thinking â here's what I know. You came here for a reason. You wouldn't be sitting in that seat if something in you wasn't ready. The question isn't whether you need this. You know you do. The question is whether you're going to let today be different."

### Phase 4 â Post-Event Follow-Up Sequence

Five emails for the list of attendees who did not buy from stage. Sent over 7 days.

**Email 1 (Day 1 â same day or next morning)**
Subject: You were in the room
[Reconnects to the energy of the event. References a specific moment from the talk. Opens the door without pressure. CTA: "If you're still thinking about [offer], here's what the next step looks like: [link or contact]"]

**Email 2 (Day 2)**
Subject: The one thing that changes everything
[Delivers a piece of content â a belief or insight from the talk â that they can use immediately. Positions Marshall as someone who gives value before the sale. Soft CTA.]

**Email 3 (Day 3)**
Subject: [Client name]'s result after 90 days
[One specific, detailed client success story. Result has to be specific and verifiable. CTA: "This is what's possible when you [key action]. [Link to offer page or booking page.]"]

**Email 4 (Day 5)**
Subject: I want to ask you something
[Direct, personal tone. Asks: "What's stopping you?" Offers to have a conversation. Not a hard close â this is the email that opens a real dialogue. CTA: "Reply to this email and tell me where you're stuck."]

**Email 5 (Day 7)**
Subject: Last chance to [specific outcome from event offer]
[Final offer. Reinstates the full value stack. States that this exact package and price is not available after today. Genuine close. Does not beg. CTA: [specific link or action, deadline stated clearly]]

---

**Email Body Formula (applied to all 5):**
- Opens with one sentence that earns the second
- Maximum 200 words per email
- Written in Marshall's voice: direct, hypnotic, certain, never apologetic
- Never uses "just" or "maybe" or "if you're interested"
- One CTA per email â not two

---

## Output Format

Deliver all four assets in one document. Label each section clearly:

```
# STAGE SALES PACKAGE â [Event Name]
## 1. Talk Architecture
## 2. Offer Stack One-Sheet
## 3. Close Script
## 4. Post-Event Follow-Up Sequence (Emails 1-5)
```

Save to: `[YOUR_VAULT]/Marshall Sylver/Stage Sales/[Event Name] - [Date].md`

Replace `[YOUR_VAULT]` with the path to your vault folder (e.g., `~/Documents/Obsidian/Active-Brain/00 Projects`).

## Operating Rules

- The close script is written to be delivered, not read. Read it aloud before delivering it to Marshall. If it sounds like a marketing email read out loud, rewrite it.
- Offer stack values must be provided by Marshall. Never invent numbers. If Marshall does not have them, ask: "What would someone pay to get just [component] on its own?" Do not proceed to write the close script until real values are provided.
- The follow-up sequence must not repeat the stage close verbatim. People who didn't buy from stage didn't do so for a reason â the emails address that reason, they do not rerun the pitch.
- All social proof and testimonials used in the close or emails must be real results Marshall has verified. Flag every placeholder with [NEEDS REAL RESULT] and list all flagged items in a summary at the end of the document so Marshall can fill them in a single pass.
- If Marshall has not provided event-specific context, the close script includes bracketed placeholders: [INSERT EVENT MOMENT], [INSERT SPECIFIC STAT], [INSERT AUDIENCE PAIN]. Never fabricate specifics.
- Do not use the phrase "if applicable" anywhere in the output. Either a component applies to this event or it does not â decide which and produce or omit it accordingly.

## When To Call This Skill

- Any time Marshall has a confirmed speaking slot â even if the event is months away, build the assets now
- When a strategic alliance partner invites Marshall to their event or list
- When Marshall is building a new program and needs to test the offer from stage before full launch
- When refining an existing close that isn't converting at target

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Write a close that could apply to any speaker | Every line is specific to Marshall, this audience, this offer |
| Deliver a close that sounds like marketing copy read aloud | Read every line aloud â if it sounds written, rewrite |
| Fabricate offer stack values or testimonials | Marshall provides every number â flag unknowns with [NEEDS REAL RESULT] |
| Invent urgency or scarcity | Use a decision-forcing frame if no real deadline exists |
| Repeat the stage close in follow-up emails | Emails address WHY they didn't buy â different angle |
| Use hedging language (just, maybe, might) | Delete from every draft â not Marshall's vocabulary |

## Before You Respond

- [ ] Do I have all 5 Key Inputs (event context, primary offer, talk slot, room dynamics, goal)?
- [ ] Are all offer stack values real numbers from Marshall (not invented)?
- [ ] Does the close script sound spoken, not written?
- [ ] Are all unverified items flagged with [NEEDS REAL RESULT]?
- [ ] Is every email under 200 words with one CTA?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)

## After Delivery

Ask Marshall:
1. "Does the close script sound like you? What would you say differently?"
2. "Is the offer stack complete? Any components missing or any values that need updating?"
3. "Do you have real client results we can drop into the follow-up emails to replace the placeholders?"
