# Substack Subscriptions - Master List

Use these URLs for archive fetching. Includes known redirects.

| Newsletter | Archive URL |
|------------|-------------|
| AI Supremacy | https://www.ai-supremacy.com/archive?sort=new |
| AI Maker | https://aimaker.substack.com/archive?sort=new |
| AI Tidbits | https://www.aitidbits.ai/archive?sort=new |
| AI 30 Day Challenge | https://ai30dc.substack.com/archive?sort=new |
| AI Adopters | https://aiadopters.club/archive?sort=new |
| AI Blew My Mind | https://aiblewmymind.substack.com/archive?sort=new |
| Alex McFarland | https://alexmcfarland.substack.com/archive?sort=new |
| Big Island Bot | https://bigislandbot.substack.com/archive?sort=new |
| Blockbuster | https://blockbuster.substack.com/archive?sort=new |
| Category Pirates | https://www.categorypirates.news/archive?sort=new |
| Department of Product | https://departmentofproduct.substack.com/archive?sort=new |
| Excellent Prompts | https://excellentprompts.substack.com/archive?sort=new |
| JT Novelo | https://jtnovelo2131.substack.com/archive?sort=new |
| Kieran Flanagan | https://www.kieranflanagan.io/archive?sort=new |
| Letters | https://letters.substack.com/archive?sort=new |
| Max Berry | https://maxberry.substack.com/archive?sort=new |
| Nate's Newsletter | https://natesnewsletter.substack.com/archive?sort=new |
| Raquel Hunter | https://raquelhunter.substack.com/archive?sort=new |
| Smart Prompts for AI | https://smartpromptsforai.substack.com/archive?sort=new |
| Tech Tiff | https://techtiff.substack.com/archive?sort=new |
| The AI Break | https://theaibreak.substack.com/archive?sort=new |
| The Creators AI | https://thecreatorsai.substack.com/archive?sort=new |
| Tyler Folkman | https://tylerfolkman.substack.com/archive?sort=new |
| Use AI to Write | https://useaitowrite.substack.com/archive?sort=new |

## Local Folder Mapping

| Newsletter | Folder Name |
|------------|-------------|
| AI Supremacy | ai-supremacy |
| AI Maker | aimaker |
| AI Tidbits | aitidbits |
| AI 30 Day Challenge | ai30dc |
| AI Adopters | aiadopters |
| AI Blew My Mind | aiblewmymind |
| Alex McFarland | alexmcfarland |
| Big Island Bot | bigislandbot |
| Blockbuster | blockbuster |
| Category Pirates | categorypirates |
| Department of Product | departmentofproduct |
| Excellent Prompts | excellentprompts |
| JT Novelo | jtnovelo2131 |
| Kieran Flanagan | kieranflanagan |
| Letters | letters |
| Max Berry | maxberry |
| Nate's Newsletter | natesnewsletter |
| Raquel Hunter | raquelhunter |
| Smart Prompts for AI | smartpromptsforai |
| Tech Tiff | techtiff |
| The AI Break | theaibreak |
| The Creators AI | thecreatorsai |
| Tyler Folkman | tylerfolkman |
| Use AI to Write | useaitowrite |

## Discontinued/Unavailable

- Acquisition Notes (acquisitionotes) - Publication discontinued
- NLP (nlp) - 404
- Max Berry (maxberry) - No posts

## Base Path

```
~/Documents/Obsidian/Archived-Projects/substack_newsletters/
```
