#!/usr/bin/env python3
"""
substack-fetch.py â Bulk Substack newsletter archive fetcher

Usage:
    python3 substack-fetch.py                 # Fetch new articles from all subscriptions
    python3 substack-fetch.py --check-only    # Just report what's new, don't download
    python3 substack-fetch.py --newsletter X  # Fetch only newsletter X (folder name)

Reads subscription list from ./subscriptions.md
Outputs JSON summary to stdout. Progress to stderr.
"""

import sys
import os
import json
import re
import time
import argparse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from urllib.parse import urljoin

try:
    import requests
except ImportError:
    sys.stderr.write("ERROR: 'requests' module required. Install: pip3 install requests\n")
    sys.exit(1)

try:
    from bs4 import BeautifulSoup
except ImportError:
    sys.stderr.write("ERROR: 'beautifulsoup4' module required. Install: pip3 install beautifulsoup4\n")
    sys.exit(1)

# --- Config ---

SCRIPT_DIR = Path(__file__).parent
SUBSCRIPTIONS_FILE = SCRIPT_DIR / "subscriptions.md"
BASE_OUTPUT = Path("~/Documents/Obsidian/Archived-Projects/substack_newsletters")
MAX_WORKERS = 6
REQUEST_TIMEOUT = 30
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
}


def load_subscriptions():
    """Parse subscriptions.md for newsletter URLs and folder mappings."""
    if not SUBSCRIPTIONS_FILE.exists():
        sys.stderr.write(f"ERROR: {SUBSCRIPTIONS_FILE} not found\n")
        sys.exit(1)

    text = SUBSCRIPTIONS_FILE.read_text()
    newsletters = []

    # Parse the URL table
    url_pattern = re.compile(r'\|\s*(.+?)\s*\|\s*(https?://\S+?/archive\?sort=new)\s*\|')
    for match in url_pattern.finditer(text):
        name = match.group(1).strip()
        url = match.group(2).strip()
        newsletters.append({"name": name, "archive_url": url})

    # Parse folder mapping table
    folder_map = {}
    folder_pattern = re.compile(r'\|\s*(.+?)\s*\|\s*(\S+?)\s*\|')
    in_folder_section = False
    for line in text.split('\n'):
        if 'Folder Name' in line:
            in_folder_section = True
            continue
        if in_folder_section and line.startswith('|'):
            m = folder_pattern.match(line)
            if m and '---' not in m.group(1):
                folder_map[m.group(1).strip()] = m.group(2).strip()

    # Merge folder names
    for nl in newsletters:
        nl["folder"] = folder_map.get(nl["name"], nl["name"].lower().replace(" ", ""))

    return newsletters


def get_existing_articles(folder_path):
    """Get set of existing article filenames in a folder."""
    if not folder_path.exists():
        return set()
    return {f.stem for f in folder_path.glob("*.md")}


def slugify(title):
    """Convert title to filename-safe slug."""
    slug = re.sub(r'[^\w\s-]', '', title.lower())
    slug = re.sub(r'[\s_]+', '-', slug)
    slug = re.sub(r'-+', '-', slug).strip('-')
    return slug[:80]  # Cap length


def fetch_archive_page(archive_url):
    """Fetch and parse a Substack archive page for article links."""
    try:
        resp = requests.get(archive_url, headers=HEADERS, timeout=REQUEST_TIMEOUT, allow_redirects=True)
        resp.raise_for_status()
    except Exception as e:
        return None, str(e)

    soup = BeautifulSoup(resp.text, 'html.parser')
    articles = []

    # Substack archive pages use various structures
    # Try finding article links
    for link in soup.find_all('a', href=True):
        href = link['href']
        # Substack article URLs contain /p/
        if '/p/' in href and href not in [a['url'] for a in articles]:
            title_el = link.find(['h2', 'h3', 'span', 'div'])
            title = title_el.get_text(strip=True) if title_el else ''
            if not title:
                title = link.get_text(strip=True)
            if title and len(title) > 3:
                full_url = href if href.startswith('http') else urljoin(archive_url, href)
                articles.append({"title": title, "url": full_url, "slug": slugify(title)})

    # Deduplicate by URL
    seen = set()
    unique = []
    for a in articles:
        if a['url'] not in seen:
            seen.add(a['url'])
            unique.append(a)

    return unique, None


def fetch_article_content(url):
    """Fetch a single article and extract content as markdown."""
    try:
        resp = requests.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT, allow_redirects=True)
        resp.raise_for_status()
    except Exception as e:
        return None, str(e)

    soup = BeautifulSoup(resp.text, 'html.parser')

    # Extract metadata
    title = ''
    title_el = soup.find('h1', class_=re.compile('post-title|title'))
    if title_el:
        title = title_el.get_text(strip=True)
    if not title:
        title_el = soup.find('h1')
        if title_el:
            title = title_el.get_text(strip=True)

    subtitle = ''
    sub_el = soup.find('h3', class_=re.compile('subtitle'))
    if sub_el:
        subtitle = sub_el.get_text(strip=True)

    date_str = ''
    date_el = soup.find('time')
    if date_el:
        date_str = date_el.get('datetime', date_el.get_text(strip=True))

    author = ''
    author_el = soup.find('a', class_=re.compile('author'))
    if author_el:
        author = author_el.get_text(strip=True)

    # Extract main content
    content_el = soup.find('div', class_=re.compile('body|post-content|available-content'))
    if not content_el:
        content_el = soup.find('article')

    content_text = ''
    if content_el:
        # Convert to simple markdown-ish text
        for br in content_el.find_all('br'):
            br.replace_with('\n')
        for p in content_el.find_all('p'):
            p.insert_after('\n\n')
        for h in content_el.find_all(['h1', 'h2', 'h3', 'h4']):
            level = int(h.name[1])
            h.insert_before('\n\n' + '#' * level + ' ')
            h.insert_after('\n\n')
        for li in content_el.find_all('li'):
            li.insert_before('- ')
            li.insert_after('\n')
        for blockquote in content_el.find_all('blockquote'):
            blockquote.insert_before('\n> ')
        for strong in content_el.find_all(['strong', 'b']):
            strong.insert_before('**')
            strong.insert_after('**')
        for em in content_el.find_all(['em', 'i']):
            em.insert_before('*')
            em.insert_after('*')

        content_text = content_el.get_text()
        # Clean up excessive whitespace
        content_text = re.sub(r'\n{3,}', '\n\n', content_text).strip()

    # Build markdown file
    md = f"""---
title: "{title.replace('"', "'")}"
author: "{author}"
date: "{date_str}"
source: "{url}"
---

# {title}

"""
    if subtitle:
        md += f"*{subtitle}*\n\n"
    md += content_text

    return md, None


def process_newsletter(newsletter, check_only=False):
    """Process a single newsletter: fetch archive, diff, download new."""
    name = newsletter['name']
    folder = newsletter['folder']
    archive_url = newsletter['archive_url']
    folder_path = BASE_OUTPUT / folder

    result = {
        "name": name,
        "folder": folder,
        "status": "ok",
        "existing": 0,
        "found": 0,
        "new": 0,
        "downloaded": 0,
        "errors": [],
    }

    # Fetch archive
    articles, err = fetch_archive_page(archive_url)
    if err:
        result["status"] = "error"
        result["errors"].append(f"Archive fetch failed: {err}")
        return result

    if articles is None:
        result["status"] = "error"
        result["errors"].append("No articles parsed from archive page")
        return result

    existing = get_existing_articles(folder_path)
    result["existing"] = len(existing)
    result["found"] = len(articles)

    # Find new articles (not already downloaded)
    new_articles = [a for a in articles if a['slug'] not in existing]
    result["new"] = len(new_articles)

    if check_only or not new_articles:
        return result

    # Download new articles
    folder_path.mkdir(parents=True, exist_ok=True)
    for article in new_articles:
        md_content, err = fetch_article_content(article['url'])
        if err:
            result["errors"].append(f"Failed to fetch {article['title']}: {err}")
            continue

        if md_content:
            filepath = folder_path / f"{article['slug']}.md"
            filepath.write_text(md_content, encoding='utf-8')
            result["downloaded"] += 1
            sys.stderr.write(f"  + {name}: {article['title'][:60]}\n")

        time.sleep(0.5)  # Polite delay

    return result


def main():
    parser = argparse.ArgumentParser(description="Fetch new Substack articles")
    parser.add_argument('--check-only', action='store_true', help="Report new articles without downloading")
    parser.add_argument('--newsletter', type=str, help="Process only this newsletter (folder name)")
    args = parser.parse_args()

    newsletters = load_subscriptions()
    sys.stderr.write(f"Loaded {len(newsletters)} subscriptions\n")

    if args.newsletter:
        newsletters = [n for n in newsletters if n['folder'] == args.newsletter]
        if not newsletters:
            sys.stderr.write(f"ERROR: Newsletter '{args.newsletter}' not found\n")
            sys.exit(1)

    results = []
    total_new = 0
    total_downloaded = 0

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(process_newsletter, nl, args.check_only): nl
            for nl in newsletters
        }

        for future in as_completed(futures):
            nl = futures[future]
            try:
                result = future.result()
                results.append(result)
                total_new += result['new']
                total_downloaded += result['downloaded']
                status = "ok" if result['status'] == 'ok' else "ERR"
                sys.stderr.write(
                    f"[{status}] {result['name']}: {result['found']} found, "
                    f"{result['new']} new, {result['downloaded']} downloaded\n"
                )
            except Exception as e:
                results.append({
                    "name": nl['name'], "folder": nl['folder'],
                    "status": "error", "errors": [str(e)],
                    "existing": 0, "found": 0, "new": 0, "downloaded": 0,
                })
                sys.stderr.write(f"[ERR] {nl['name']}: {e}\n")

    summary = {
        "timestamp": datetime.now().isoformat(),
        "newsletters_checked": len(results),
        "total_new_articles": total_new,
        "total_downloaded": total_downloaded,
        "check_only": args.check_only,
        "output_base": str(BASE_OUTPUT),
        "results": sorted(results, key=lambda r: r['name']),
    }

    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
