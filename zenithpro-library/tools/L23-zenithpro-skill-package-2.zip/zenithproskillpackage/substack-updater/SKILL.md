---
name: substack-updater
description: Bulk update all Substack newsletter archives in under 2 minutes. Parallel fetches, auto-diff, batch writes.
triggers:
  - /substack
  - /update-substacks
  - update my substacks
  - catch me up on substacks
  - download new substack articles
---

# Substack Bulk Updater

Updates all Substack newsletter subscriptions in parallel. Target: under 2 minutes for full sync.

## Usage

```
/substack
```

That's it. No parameters needed.

## What It Does

1. **Reads subscription list** from `substack_newsletters/Substack-Subscriptions.md`
2. **Parallel fetches all archives** - all 26+ newsletters at once via WebFetch
3. **Diffs against local** - checks existing files to find what's new
4. **Parallel fetches new articles** - grabs all new content simultaneously
5. **Batch writes all files** - saves everything in one pass
6. **Reports summary** - shows what was added

## Architecture

```
Phase 1: Archive Scan (10-15 seconds)
âââ WebFetch all /archive?sort=new URLs in parallel
âââ Extract article titles, dates, URLs from each
âââ Return structured list per newsletter

Phase 2: Local Diff (2-3 seconds)
âââ Bash: ls each newsletter folder, get latest date
âââ Compare against archive list
âââ Build list of new articles needed

Phase 3: Content Fetch (30-60 seconds)
âââ WebFetch all new article URLs in parallel
âââ Extract article text, author, date
âââ Return content for each

Phase 4: Batch Write (5-10 seconds)
âââ Write all markdown files
âââ Use consistent naming: YYYY-MM-DD_Newsletter-Name.md

Phase 5: Summary (instant)
âââ Report: X newsletters checked, Y new articles saved
```

## Key Principles

- **NEVER sequential** - Always parallel WebFetch calls
- **NEVER ask for approval** - This is a read-only operation on public content
- **NEVER verbose** - Terse progress, detailed summary at end
- **Batch everything** - Multiple tool calls in single messages

## Subscription List Location

```
~/Documents/Obsidian/Archived-Projects/substack_newsletters/Substack-Subscriptions.md
```

## Output Location

```
~/Documents/Obsidian/Archived-Projects/substack_newsletters/{newsletter-folder}/
```

## File Naming Convention

```
YYYY-MM-DD_{Newsletter-Name}.md
```

## Article Template

```markdown
# {Title}

**Source:** {URL}
**Author:** {Author}
**Date:** {Date}

---

{Content}

---

*Saved from {Newsletter Name} newsletter*
```

## Execution Instructions

When user triggers this skill:

### Step 1: Load subscriptions and check local state

```
PARALLEL:
- Read Substack-Subscriptions.md to get all URLs
- Bash: for each newsletter folder, get the most recent file date
```

### Step 2: Fetch all archives simultaneously

```
PARALLEL WebFetch (all at once, single message with multiple tool calls):
- {newsletter1}/archive?sort=new â "List article titles, dates, URLs"
- {newsletter2}/archive?sort=new â "List article titles, dates, URLs"
- ... (all 26+)
```

### Step 3: Calculate diff

Compare archive results against local latest dates. Build list of {url, newsletter, date, title} for all new articles.

### Step 4: Fetch all new article content

```
PARALLEL WebFetch (all new articles at once):
- article1_url â "Extract full article text, author, date"
- article2_url â "Extract full article text, author, date"
- ... (all new)
```

### Step 5: Write all files

```
PARALLEL Write (all files at once):
- Write article1.md
- Write article2.md
- ... (all new)
```

### Step 6: Report

```
## Substack Update Complete

**Time:** {seconds}
**Newsletters checked:** {count}
**New articles saved:** {count}

| Newsletter | New Articles |
|------------|-------------|
| AI Supremacy | 3 |
| Category Pirates | 2 |
| ... | ... |

**Unavailable:** {list any 404s or discontinued}
```

## Handling Redirects

Some Substacks redirect to custom domains. When WebFetch returns a redirect:
- Use the redirect URL immediately
- Update the subscription list with the new URL

Known redirects:
- categorypirates.substack.com â categorypirates.news
- aitidbits.substack.com â aitidbits.ai
- kieranflanagan.substack.com â kieranflanagan.io
- aiadopters.substack.com â aiadopters.club
- ai-supremacy.substack.com â ai-supremacy.com

## Error Handling

- **404:** Mark newsletter as unavailable, continue with others
- **Paywall:** Save whatever content is available, note paywall in file
- **Empty archive:** Skip, note in summary

## Performance Target

| Phase | Target Time |
|-------|-------------|
| Archive scan | 15 sec |
| Local diff | 3 sec |
| Content fetch | 60 sec |
| File writes | 10 sec |
| **Total** | **< 2 min** |
