---
name: ghl-content-engine
description: Produce marketing content â emails, SMS, and social posts â in the client's brand voice, formatted and ready to push directly into GoHighLevel. Trigger when someone says "write an email," "create email content," "draft an SMS," "write a social post," "create a template," "write content for GHL," "email copy," "SMS copy," "social media post," "write marketing content," "batch content," "content for a launch," or any request to produce marketing copy that will live in or send through GHL.
license: proprietary
metadata:
tags:
  - program/ctd
  - ghl
  - content
---
# GHL Content Engine

## Purpose

Produce marketing content â email sequences, standalone emails, SMS messages, and social posts â written in the operator's brand voice and formatted for immediate deployment in GoHighLevel. Every piece is deliverable-grade: no placeholders, no generic copy, no filler phrases. Content is reviewed before it is pushed into GHL.

## Instructions

### Step 1 â Content Brief Intake

Extract from the operator's request:

| Field | Required? | Default if Absent |
|-------|-----------|-------------------|
| Content goal | Yes | Must ask |
| Target audience | Yes | Must ask |
| Channel(s) | Yes | Must ask |
| Brand voice/tone | No | Professional, direct, conversational |
| Product or offer | No | Derive from goal |
| CTA / desired action | No | Derive from goal |
| Number of pieces | No | 1 per channel requested |
| Content angle/hook | No | Generate from goal |

If any Required field is missing, list them and ask once. Do not generate content until these are provided.

State the interpreted brief before writing:

```
CONTENT BRIEF
=============
Goal:       [goal]
Audience:   [audience]
Channels:   [Email / SMS / Social]
Voice:      [tone description]
CTA:        [specific action]
Pieces:     [N email(s), N SMS, N social post(s)]
```

Ask: "Does this brief look right? Confirm to proceed or correct any field."

### Step 2 â Establish Brand Voice

If the operator provides sample copy, analyze it for:
- Sentence length (short and punchy / long and detailed)
- Pronoun usage (first-person "I" / direct second-person "you" / collective "we")
- Formality level (casual / professional / authority)
- Signature phrases or patterns
- Emotional register (urgency / empathy / confidence / humor)

If no sample is provided, use the defaults: direct, second-person, professional-casual, confident.

State the voice parameters being applied:
```
VOICE PARAMETERS
================
Tone:       [descriptor]
Sentences:  [short / medium / varied]
Pronouns:   [I/you/we]
Register:   [casual/professional/authority]
Patterns:   [any noted patterns, or "Standard"]
```

### Step 3 â Generate Content

Produce all requested pieces. Apply these channel-specific rules:

**EMAIL:**
- Subject line: specific, benefit-forward, no "newsletter" or "update" openers
- Preview text: 40-90 characters, extends the subject without repeating it
- Body: opens with the reader's situation or desire, not the sender's news
- CTA: one clear action, stated once at the end (not repeated 3 times)
- Length: match to goal â promotional (300-500 words), nurture (150-250 words), announcement (100-200 words)
- No unsubscribe language (GHL adds this automatically to broadcast emails)

**SMS:**
- 160 characters max per segment â enforce this without exception
- Open with the hook, not the brand name
- One CTA, no ambiguity
- Include opt-out only if operator specifies compliance requirements
- No long URLs â ask for a short link if a link is needed
- Conversational â SMS reads as a text, not a billboard

**SOCIAL POST:**
- Platform-specific format if operator specifies (Facebook / Instagram / LinkedIn)
- Hook in the first line â the most important sentence, before any break
- Hashtags at the end if required (max 5 for Facebook/LinkedIn, up to 15 for Instagram)
- CTA in the final line
- Length: Facebook (150-300 words), Instagram (150-220 words), LinkedIn (200-400 words)

Display each piece in its own labeled block:

```
EMAIL [#]: [Name/Purpose]
==========================
Subject:      [subject line]
Preview:      [preview text]

Body:
---
[full email body]
---
Character count: [N] words
CTA:          [action stated]

---

SMS [#]: [Name/Purpose]
=========================
Message:      [full SMS]
Chars:        [N] / 160
CTA:          [action]

---

SOCIAL POST [#]: [Name/Purpose]
================================
Platform:     [Facebook / Instagram / LinkedIn / All]
Full post:
---
[full post text]
---
Hashtags:     [list, or "none"]
CTA:          [action]
```

### Step 4 â Sequence Framing (If Multiple Pieces)

If the operator requested a sequence (e.g., 3-email nurture, 5-day SMS drip), produce a sequence map:

```
SEQUENCE MAP: [Sequence Name]
==============================
Day 0 (Send day):  [Email 1 subject] â Goal: [open + click]
Day 2:             [SMS 1 message preview] â Goal: [reply / click]
Day 4:             [Email 2 subject] â Goal: [purchase / book]
Day 6:             [SMS 2 message preview] â Goal: [urgency push]
Day 8:             [Email 3 subject] â Goal: [final close]
```

Each piece in the sequence must build on the previous one â reference shared narrative thread in the Why Note below each piece.

### Step 5 â Pre-Push Review Gate

Display all content pieces together for review:

```
CONTENT REVIEW
==============
[All pieces from Step 3, in order]

---
Ready to push to GHL?
  [A] Create all email templates in GHL now
  [B] Send social post(s) to GHL social planner
  [C] Approve for manual copy-paste (no auto-push)
  [D] Edit first â [specify which piece]
```

Wait for operator selection. Do not auto-push anything.

### Step 6 â Push to GHL

**If option A selected (email templates):**
Call `create_email_template` for each approved email piece.
Log: `Email template created: [name] â Template ID: [id]`

**If option B selected (social posts):**
Call `create_social_post` for each approved social piece.
Confirm the social account to post from using `get_social_accounts` first if not already established.
Log: `Social post created: [platform] â Post ID: [id]`

**If option C selected:**
Provide a clean copy-paste block for each piece â no labels, no metadata, just the content.

**If sending directly:**
Call `send_email` or `send_sms` only if the operator specifies an audience contact or list. Follow confirmation protocol from ghl-personalized-followup before any sends.

### Step 7 â Delivery Report

```
CONTENT DELIVERY REPORT
========================
Email templates created:  [N] â IDs: [list]
Social posts created:     [N] â IDs: [list]
Direct sends:             [N sent / N failed]
Manual copy-paste:        [N pieces delivered in chat]

Status: Complete
```

## Constraints

- NEVER produce content without a clear content goal. If the goal is absent, ask once before proceeding.
- NEVER use placeholder text ([Your Name], [Insert Here], [CTA], etc.) in any output. All content is production-ready or it is not delivered.
- NEVER use "just checking in," "I hope this finds you well," "as per my last email," or any filler opener. These phrases are prohibited output.
- NEVER push to GHL (create templates, post social, send) without completing the Pre-Push Review Gate (Step 5) and receiving explicit operator selection.
- ALWAYS enforce the 160-character SMS limit. Rewrite to fit â a warning without a rewrite is not compliance.
- NEVER include multiple CTAs in a single email or SMS. One action per piece.
- ALWAYS state the voice parameters (Step 2) before generating content â the operator must be able to confirm voice before copy is written.
- NEVER batch-create social posts without first confirming the social accounts connected to GHL via `get_social_accounts`. Posting to the wrong account is irreversible in some cases.
- ALWAYS produce a sequence map (Step 4) when more than 2 pieces are requested â sequencing logic is not optional.
- NEVER produce content for a "general audience" without pushing back. An audience definition is required. "General audience" is not an audience.
- ALWAYS include the character count on every SMS in every review gate. If it exceeds 160, rewrite before confirmation â not flagged and left for the operator to fix.
- NEVER ask the operator to fix an over-limit SMS. Fix it internally, then present the compliant version.
- NEVER skip the Content Brief Confirmation (Step 1) â content produced without a confirmed brief cannot be verified against intent.

## Reference

**MCP Tools Used:**
- `create_email_template` â Save a written email as a reusable template in GHL
- `create_social_post` â Publish or schedule a social post via GHL's social planner
- `send_sms` â Send an SMS message directly to a contact
- `send_email` â Send an email directly to a contact (using template or inline)
- `get_social_accounts` â Retrieve connected social accounts for the GHL location

**Configuration Requirements:**
- GHL MCP server (BusyBee3333) must be connected and authenticated
- GHL Location ID must be configured in the MCP server
- Social posting requires social accounts connected in GHL settings
- SMS sending requires a GHL phone number provisioned for the location
- Operator must have email template and social post creation permissions in GHL

**Failure Modes:**

MCP not connected: State: "GHL MCP server is not responding. Content has been drafted but cannot be pushed to GHL. Deliver as manual copy-paste (Option C) until connection is restored."

`create_email_template` fails: State the error. Deliver the content as a copy-paste block so the operator can create the template manually. Do not lose the copy.

`create_social_post` fails: State the error and which platform. Offer the content as copy-paste for manual posting. Log which post ID was not created.

`get_social_accounts` returns empty list: State: "No social accounts are connected to this GHL location. Social posts cannot be auto-published. Connect accounts in GHL > Settings > Social Planner, then retry."

Content brief too vague (goal unclear): Do not attempt content. "The content goal is not specific enough to write effective copy. What should the reader do immediately after reading this piece?"

SMS over 160 characters after first draft: Do not present the over-limit draft. Rewrite internally until it fits, then present the compliant version.

Sequence requested with no send timing: Do not fabricate intervals. Ask: "What is the gap between each piece? (e.g., Day 0, Day 2, Day 5, Day 7)"

**Output Format:**

Every content engine run produces, in order:
1. **Content Brief Confirmation** â interpreted brief, operator confirms or corrects
2. **Voice Parameters** â stated before any copy is written
3. **Sequence Map** â if multiple pieces, the narrative arc and timing
4. **Content Blocks** â each piece in its labeled block with character counts and CTA callout
5. **Pre-Push Review Gate** â all pieces together, options A/B/C/D
6. **GHL Tool Call Log** â every MCP call made with result
7. **Delivery Report** â final tally of what was created, sent, or delivered as copy-paste
