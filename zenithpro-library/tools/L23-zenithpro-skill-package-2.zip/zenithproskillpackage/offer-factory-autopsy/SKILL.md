# Offer Factory: Offer Autopsy

---
name: offer-factory-autopsy
description: "Use when analyzing existing offers (Rich's or competitors') to understand their structural DNA before generating new ideas."
---

## Purpose

Before generating new offers, understand what structural patterns already exist in the current portfolio. The Autopsy reveals the DNA of any offer â what patterns it uses, what it's missing, and where structural changes would create the biggest transformation.

## Invocation

```
/offer-factory-autopsy [offer description or product name]
```

**Examples:**
```
/offer-factory-autopsy ZenithPro current offer structure
/offer-factory-autopsy [competitor URL or description]
/offer-factory-autopsy Analyze all of Rich's current offers
```

---

## The 30 Structural Patterns

These are the diagnostic lenses. Every offer is built from some combination of these patterns.

| # | Pattern | Core Mechanism | Classic Example |
|---|---------|---------------|-----------------|
| 1 | **Default Restructuring** | Change what happens if the buyer does nothing | Netflix (no late fees), negative option |
| 2 | **Barrier Elimination** | Remove the #1 obstacle to purchase | Ford ($850â$260), free shipping |
| 3 | **Temporal Distribution** | Spread the offer across time for psychological effect | PLF launch sequence, drip content |
| 4 | **Personalization at Scale** | Make mass offers feel individually tailored | Stitch Fix, quiz funnels, Levesque Ask Method |
| 5 | **Mechanism Differentiation** | Name and own the HOW behind the result | Todd Brown's Unique Mechanism, branded systems |
| 6 | **Value Chain Ownership** | Control more of the delivery chain than competitors | Ted Nicholas author-direct, Apple ecosystem |
| 7 | **Risk Reversal Innovation** | Go beyond money-back to better-than-risk-free | Abraham's guarantees, Casper 100-night trial |
| 8 | **Membership Gating** | Access requires ongoing commitment | Costco, Amazon Prime, SOW subscription |
| 9 | **Demo-as-Offer** | The demonstration IS the selling mechanism | Popeil live demos, free workshops that convert |
| 10 | **Challenge/Transformation** | Time-bound transformation experience IS the offer | Bill Phillips Body for Life, 30-day challenges |
| 11 | **Free Line Strategy** | Give away your best stuff free, sell implementation | Kern Results in Advance, Schefren Manifesto |
| 12 | **Toolkit Packaging** | Package knowledge as ready-to-use tools, not education | Kennedy toolkits, template packs, prompt libraries |
| 13 | **Ecosystem Bundling** | Multiple products that reinforce each other | Apple, Disney, Brunson Value Ladder |
| 14 | **Artificial Scarcity** | Engineer real or perceived limited availability | Disney Vault, Supreme drops, cohort limits |
| 15 | **Social Proof as Product** | Visible participation/success of others IS the product | Kickstarter funding bars, live leaderboards |
| 16 | **Education-as-Sales** | Teaching IS the selling (not separate from it) | Chet Holmes Dream 100, webinar teaching model |
| 17 | **Cause Integration** | Attach the offer to a mission larger than profit | TOMS, Patagonia, "movement" positioning |
| 18 | **Experience Wrapping** | Wrap a commodity in an experience that justifies premium | Starbucks, Disney parks, high-ticket retreats |
| 19 | **Subscription Conversion** | Convert one-time purchase to recurring revenue | Gillette razors, Dollar Shave Club, SaaS |
| 20 | **Pre-Order as Capital** | Sell before building, use revenue to fund creation | Tesla deposits, Kickstarter, founding member pricing |
| 21 | **Negative Option** | Buyer receives unless they actively cancel | Columbia House, free trial auto-renew |
| 22 | **Gift-with-Purchase** | Bonus that makes the purchase feel like a deal | Estee Lauder GWP, "but wait there's more" |
| 23 | **Curation as Product** | Selection and filtering IS the value | Birchbox, book clubs, SOW expert selection |
| 24 | **Application Gating** | Buyer must qualify to purchase | Schefren high-ticket, exclusive programs |
| 25 | **Price Deflation** | Aggressive price reduction as market expansion | Ford Model T, Walmart EDLP |
| 26 | **Value Ladder Ascension** | Designed path from low to high commitment | Brunson funnels, Robbins event ladder |
| 27 | **Platform + Consumable** | Sell the platform cheap, profit on ongoing supplies | Gillette, Nespresso, printers + ink |
| 28 | **Unbundling** | Break a bundle into individually purchasable pieces | iTunes singles, course modules sold separately |
| 29 | **Brand Extension** | Leverage trust from one product into adjacent categories | Branson Virgin, Disney merchandise, Rich's product line |
| 30 | **Certification/Licensing** | Let buyers teach/sell your methodology | Burchard HPX, franchise model, consultant licensing |

---

## Execution Process

### Step 1: Describe the Offer Structure

Before diagnosing, clearly describe:
- **What is being sold** (product/service/access)
- **Who it's sold to** (target buyer)
- **How it's sold** (funnel, sales mechanism)
- **What it costs** (price point, payment structure)
- **What the buyer gets** (deliverables, access, outcomes)
- **How it's delivered** (platform, timeline, format)

### Step 2: Pattern Scan

Go through ALL 30 patterns and score each:

| Score | Meaning |
|-------|---------|
| **STRONG** | This pattern is a primary structural element of the offer |
| **PRESENT** | This pattern exists but isn't a key driver |
| **WEAK** | Elements of this pattern exist but underutilized |
| **ABSENT** | This pattern is not present at all |
| **ANTI** | The offer actively works AGAINST this pattern |

### Step 3: Structural DNA Profile

Summarize:
- **Primary patterns** (STRONG) â the 3-5 patterns that define this offer
- **Supporting patterns** (PRESENT) â patterns that reinforce but don't define
- **Missed opportunities** (ABSENT patterns that would be natural fits)
- **Structural conflicts** (patterns working against each other)
- **Anti-patterns** (deliberate or accidental opposition to patterns that could help)

### Step 4: Transformation Opportunities

For each ABSENT or WEAK pattern, answer:
1. **What would this look like?** â Concrete description of the pattern applied to THIS offer
2. **What would change?** â How the offer would feel/work differently
3. **Effort to implement** â Low / Medium / High
4. **Impact estimate** â Low / Medium / High / Transformative
5. **Conflicts** â Would adding this pattern break anything already working?

### Step 5: Competitive Comparison (Optional)

If competitor offers are provided, map their pattern profiles alongside and identify:
- Patterns where Rich's offer is structurally stronger
- Patterns competitors use that Rich doesn't
- Structural white space â patterns NO ONE in the space is using

---

## Output

### File Location
```
Active-Brain/00 Projects/01 Behavioral Intelligence/Offer Factory/Autopsies/[Offer Name] - Autopsy - [Date].md
```

### Document Structure

```markdown
# Offer Autopsy: [Offer Name]
**Date:** [Date]
**Analyzed by:** Offer Factory Autopsy

## Offer Description
[Step 1 summary]

## Pattern Profile

### Primary Patterns (STRONG)
[List with explanation of how each manifests]

### Supporting Patterns (PRESENT)
[List with explanation]

### Underutilized (WEAK)
[List with what exists and what's missing]

### Absent
[List of patterns not present]

### Anti-Patterns
[Patterns the offer works against, and whether that's deliberate or accidental]

## Structural DNA Summary
[2-3 sentence summary: "This offer is fundamentally a [patterns] offer with [patterns] support. Its structural gaps are in [patterns]. The biggest transformation opportunity is [pattern]."]

## Transformation Opportunities (Ranked)

### 1. [Highest Impact Opportunity]
**Pattern:** [Name]
**What it looks like:** [Concrete description]
**Impact:** [Rating + why]
**Effort:** [Rating + why]
**Conflicts:** [Any]

[...repeat for top 5-10 opportunities...]

## Full Pattern Scan
[Complete 30-pattern table with scores]
```

---

## Integration

- **Before Engine runs:** Autopsy existing offers first so the Engine knows what patterns are already in play and can focus on what's NEW
- **After Engine runs:** Autopsy the generated ideas to verify they actually introduce new patterns (not just cosmetic variations of what exists)
- **Competitor analysis:** Autopsy competitor offers to find structural white space
