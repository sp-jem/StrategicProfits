---
name: billable-time-reconstructor
description: Reconstructs billable time entries from emails, call records, calendar events, and notes â formatted for direct entry into PCLaw (Milton) or Soluno/Actionstep (Grimsby). Use when Fay needs to docket a day she didn't track in real time, when she's reconstructing billable time from her inbox, or when she says anything like "what did I bill today," "I need to docket," "reconstruct my time," or "what was I doing on this file."
license: proprietary
tags:
  - program/ctd
  - client/fay-hassaan
---
# Billable Time Reconstructor

Reconstructs billable time from existing records â emails, calendar, call logs, notes â and formats docket entries ready for PCLaw (Milton) or Soluno/Actionstep (Grimsby).

---

## MINIMUM REQUIREMENTS BEFORE STARTING

Do not begin reconstruction until all three conditions are met:
- At least one source document is provided (email thread, calendar, note, or call log)
- A date or date range is specified
- Office is specified: Milton (PCLaw) or Grimsby (Soluno/Actionstep)

If source documents are missing, say exactly: "To reconstruct your billable time, paste any combination of emails, calendar entries, call logs, or meeting notes from the day or period. Even a quick summary of what you did on each file works. The more you give me, the more accurate the docket."

Do not prompt for office or date if already provided in the request.

---

## CORE WORKFLOW

### Step 1 â Ingest All Source Material

Read every piece of source material provided before extracting any time entries. Do not begin extracting mid-read. Sources include:
- Email threads (each email = a touchpoint on a file)
- Calendar entries (meeting = confirmed time block; use actual start/end if available)
- Call records from Dialpad or phone logs (call duration = billable unit)
- Meeting notes or dictated summaries
- Any text Fay writes describing what she did

### Step 2 â Identify File-Level Activity

For each piece of source material, extract:
- **File/Matter:** Client name and practice area (Real Estate, Estates, Corporate, Wills, Litigation â infer from context)
- **Date and time** of activity (or estimated time of day if not explicit)
- **Activity type:** Email correspondence | Phone call | Document review | Document drafting | Client meeting | Research | File management | Court/closing attendance
- **Duration:** Actual if explicit; estimated if not (see estimation rules)
- **Billable status:** Everything Fay does on a client file is presumptively billable unless it is clearly administrative (IT, HR, internal operations, payroll)

### Step 3 â Apply Time Estimation Rules

When duration is not explicit:

| Activity | Estimation Rule |
|----------|----------------|
| Short email (under 5 sentences sent or received) | 0.1 hr (6 min) |
| Substantive email (paragraph-level advice or instructions) | 0.2â0.3 hr |
| Email thread review (3+ back-and-forth) | 0.3â0.5 hr |
| Phone call (no duration provided) | 0.3 hr default â flag for Fay to confirm |
| Client meeting (calendar block) | Use actual block length |
| Document review (contract, agreement, title docs) | 0.5â1.0 hr depending on apparent complexity |
| Document drafting (Will, transfer, corporate resolution) | 1.0â2.0 hr â flag for Fay to confirm |
| Research (flagged in emails or notes) | Flag as estimate â ask Fay to confirm |

Rules:
- Always err conservative on estimates. Fay reviews before submitting.
- Every entry estimated at over 1.0 hr must be flagged for Fay's confirmation before submission. Under-billing is a cashflow problem; over-billing is a Law Society issue.
- If source material contains conflicting records for the same time period (e.g., calendar block overlaps with email timestamp), flag the conflict explicitly and present both options. Do not resolve the conflict by picking one.

### Step 4 â Produce the Docket Table

Format the output for immediate billing entry:

**[OFFICE] DOCKET â [Date or Date Range]**

| Matter / Client | Date | Activity Description | Time (hrs) | Billable | Notes |
|-----------------|------|----------------------|------------|---------|-------|
| [Client Name â File Type] | [Date] | [1-sentence description of activity] | [X.X] | Y | [FLAG if estimated] |
| ADMIN / NON-BILLABLE | [Date] | [What it was] | [X.X] | N | [Do not docket] |

**TOTAL BILLABLE THIS PERIOD:** [X.X hrs]
**FLAGGED FOR CONFIRMATION:** [List any entries where duration was estimated over 1.0 hr or activity type is ambiguous]

Rules:
- If an email involves multiple files, split the time proportionally and create a separate entry for each file.
- Rose Faddoul files: if source material includes emails or activity on Rose's files, list them separately. Do not mark as non-billable unless Fay explicitly confirms.
- Admin and operations (IT, HR, phone issues, payroll) are never billable to client files. Log them in the NON-BILLABLE section for Fay's internal awareness only.

### Step 5 â Surface the Billing Gap

After producing the docket table, calculate and report:

> "Based on this reconstruction, [X.X hrs] are billable from [date/period]. At your standard rates, this represents approximately $[X,XXX]â$[X,XXX] in revenue. This should be entered in [PCLaw / Soluno] before [end of day / end of week] to avoid aging."

If Fay has provided her rates, use them. Default to $400/hr if no rate information is available; note the assumption in the output.

---

## SYSTEM FORMAT REFERENCE

**Milton â PCLaw:**
Time entries require: Matter number | Date | Lawyer code | Hours | Description (under 250 characters)
Description format: `[Activity]: [Brief description of what was done]`
Example: `Email: Correspondence with client re: closing conditions â 183 Bronte St S`

**Grimsby â Soluno/Actionstep:**
Time entries require: Matter | Date | Timekeeper | Units (in tenths of an hour) | Description
Description format: Same as PCLaw
Conversion: 0.3 hrs = 3 units in Soluno

When Fay specifies the office, produce the table in the correct format for that system. If both offices are involved, produce two separate tables.

---

## GUARDRAILS

- Never bill for time Fay has not done. Reconstruction captures time already spent â never fabricates it.
- Every entry over 1.0 hr that was estimated (not timed) must be flagged for Fay's review before submission. No exceptions.
- Never submit to PCLaw or Soluno directly. This skill produces a table Fay reviews and enters.
- If source material is absent or insufficient to reconstruct a reasonable docket, say so explicitly rather than producing a sparse or speculative table.
- Conflicting time records are flagged, not resolved by the skill.

---

## OUTPUT SAVE LOCATION

`03 Law Files/[Grimsby or Milton]/Billing/[YYYY-MM-DD]-docket-reconstruction.md`

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Bill for time Fay hasn't done | Reconstruction only â never fabrication |
| Submit directly to PCLaw or Soluno | Produce table for Fay's review and entry |
| Resolve conflicting time records silently | Flag both and let Fay decide |
| Produce a sparse speculative table | Say source material is insufficient |
| Miss Law Society compliance | Every entry over 1hr that was estimated must be flagged |
| Mix Milton and Grimsby formats | Two separate tables if both offices involved |

## Before You Respond

- [ ] Do I know which office (Milton/PCLaw or Grimsby/Soluno)?
- [ ] Do I have source material (emails, calendar, call logs, notes)?
- [ ] Are all estimated entries over 1hr flagged for review?
- [ ] Am I using the correct format for the specified system?
- [ ] Is conflict resolution deferred to Fay, not silently decided?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
