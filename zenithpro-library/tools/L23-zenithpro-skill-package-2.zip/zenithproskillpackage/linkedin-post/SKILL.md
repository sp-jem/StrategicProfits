---
name: linkedin-post
description: Write a LinkedIn post in your authentic voice. Takes a topic, idea, or observation and produces 3 scroll-stopping post variations using your voice file. Scope: single posts, 150-300 words only.
trigger_phrases:
  - write a linkedin post
  - linkedin post
  - write a post about
  - post about this
  - turn this into a linkedin post
---

# LinkedIn Post Writer

## PURPOSE

This skill writes LinkedIn posts in the registered user's voice — not a generic "thought leadership" voice. Scope: single posts, 150-300 words, from a topic or raw idea.

**This skill does:** Write 3 post variations per run. Optionally publish to LinkedIn.

**This skill does NOT:** Write threads, newsletters, ad copy, profile bios, or lead magnets. For lead magnets, use /linkedin-lead-magnet.

**Voice file required:** `~/.claude/skills/linkedin-post/references/voice-template.md` must exist and contain filled content — not placeholder text.

**If the voice file is missing or still contains unfilled template placeholders (e.g., "[YOUR BELIEF HERE]"):**

```
BLOCKED: Voice file not configured.
Fill out ~/.claude/skills/linkedin-post/references/voice-template.md before using this skill.
Run /linkedin-voice-setup to auto-populate it from your proof stack.
```

Do not write any post. Do not attempt to infer the voice.

---

## CONSTRAINTS

**NEVER start line 1 of any post with "I".**
**NEVER include filler:** "In today's world", "It's no secret", "I wanted to share", "At the end of the day", "game-changer", "synergy", "hustle", "thought leader", "my journey", "I'm humbled", "honored to share", "unpopular opinion".
**NEVER write a post over 300 words.**
**NEVER write a post under 150 words.**
**NEVER end a post with more than one closing device** (a principle, a question, OR a direct action — never two or three combined).
**NEVER ask more than one clarifying question.** If the input is unclear, ask exactly one question, then write.
**NEVER write further questions after the one permitted clarifying question.** Proceed.
**NEVER invent credentials or results** not present in the voice file. Generic claims weaker than nothing.
**ALWAYS pull at least one belief OR one distinction from the voice file** into every post.
**ALWAYS write three variations using three different format types.** No two variations may use the same format.
**ALWAYS count the words in line 1 before outputting.** If over 15 words, rewrite it.

---

## REFERENCE

Load before any other step: `~/.claude/skills/linkedin-post/references/voice-template.md`

**Validate the file contains filled content in ALL of these fields before proceeding:**
- Core beliefs: at least 3 listed
- Distinctions: at least 1 entry
- Credentials/proof: at least 1 specific result or name
- Audience profile: at least 1 sentence

**If ANY field is empty or still contains placeholder text:** HALT. Display the BLOCKED message from the PURPOSE section.

**Do NOT reference beliefs, distinctions, or credentials not present in the voice file.** If the input topic does not connect to any listed belief or distinction, ask the user: "Which of your core beliefs should this post express?" — then write without further questions.

---

## EXECUTION

### Step 1: Parse the Input

Extract from the user's input:
- The core insight (what is the real claim here?)
- The contrarian angle (what does the conventional view get wrong?)
- The distinction angle (can this be framed as A vs B?)
- A grounding event (is there a real moment, result, or observation that anchors this?)

If the input is vague, ask ONE question: "Is there a specific angle you want, or should I write the strongest version I can?" — then write without further questions.

### Step 2: Select Formats

Apply the first rule that matches. Do not use judgment to override the selection logic.

| Rule | Input signals | Format |
|------|--------------|--------|
| 1 | Input references a specific event, client result, or personal experience | Story Post |
| 2 | Input asks "what's the difference between X and Y" or user owns a named framework | Distinction Post |
| 3 | Input contradicts conventional wisdom or targets a hyped claim | Contrarian Post |
| 4 | Input is a pattern observed across multiple instances | Observation Post |
| 5 | Input contains 5+ discrete points that cannot be compressed | List Post |

If no rule matches: default to Observation Post.

The three variations must use three different formats from the table above.

**Format structures:**

**Observation Post:** Opens with something witnessed or noticed → lesson → reframe.
**Distinction Post:** Opens with the contrast — "Most people do X. The ones who win do Y. Here's the difference."
**Contrarian Post:** Opens with what everyone believes → turns it → proves why it's wrong.
**Story Post:** Opens with a specific moment or event → draws out the lesson → ends with a principle.
**List Post:** Opens with a strong claim → 5-7 punchy items, each a standalone insight.

### Step 3: Write the Posts

**Apply these rules to every post. They are not suggestions.**

1. Line 1 = scroll-stopping hook. Under 15 words. Must work as a standalone before "...see more". NEVER start with "I".
2. White space. One idea per paragraph. Short paragraphs get read. Bury nothing.
3. No filler. See CONSTRAINTS section for the banned list.
4. Specific beats generic. Pull from the voice file's credentials — names, numbers, real results.
5. Land the point. Do not meander toward it.
6. End with exactly one of: a principle, a reflection question, or a direct action.

### Step 4: Quality Gate

Before outputting, verify every post against all of these. Each is a hard requirement.

| Check | Requirement | Action if failing |
|-------|-------------|-------------------|
| Hook length | Line 1 is 15 words or fewer (count them) | Rewrite line 1 |
| Hook opener | Line 1 does not begin with "I" | Rewrite line 1 |
| Filler audit | No phrase from the banned list appears | Delete phrase, rewrite sentence |
| Voice file usage | At least 1 belief OR 1 distinction from voice file is present | Revise to include it |
| Specificity | At least 1 specific data point, industry reference, or named result | Add one |
| Ending | Post ends with exactly one closing device | Trim to one |
| Length | Word count is 150-300 | Extend or trim |
| Format uniqueness | This variation uses a different format than the other two | Change format |

If any check fails: rewrite that element. Do not output until all 8 checks pass on all 3 variations.

### Step 5: Optional Publishing

After displaying posts, ask:
"Want me to post one of these to LinkedIn? Say 'post version A' (or B, C)."

If user confirms (requires social-media-poster installed):
- Dry run first: `node ~/.claude/skills/social-media-poster/references/post.js --dry-run --text "[post text]" --platforms li`
- Confirm output, then run without `--dry-run`

---

## OUTPUT

```markdown
## Version A: [Format] — [Angle in 8 words or less]

[Post text]

---

## Version B: [Format] — [Angle]

[Post text]

---

## Version C: [Format] — [Angle]

[Post text]

---

**Next steps:**
- Want me to post it now? Say "post version A/B/C"
- Turn this topic into a lead magnet: /linkedin-lead-magnet [topic]
```
