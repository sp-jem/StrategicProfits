# [YOUR NAME] — LinkedIn Voice File

> SETUP INSTRUCTIONS: Fill out every section below with YOUR information before using these skills.
> If you ran the proof-stack-builder for your business, most of this comes directly from that output.
> Delete all instructional text (lines starting with >) once you've filled it in.

---

## WHO YOU ARE

> Write 2-4 sentences. Answer: What is your expertise? How long have you been doing it? Who do you help? What have you done that earns you authority to speak on these topics?
>
> Example: "Jane Doe. The operations strategist for service business owners. For 18 years you've been the person operators hire when their business is running them instead of the other way around. You've helped 200+ businesses go from constant firefighting to scalable systems — without hiring a bloated team."

[YOUR AUTHORITY STATEMENT HERE]

---

## YOUR CORE BELIEFS THAT DRIVE YOUR CONTENT

> List 3-5 things you believe deeply about your industry or your audience's problems. These become your contrarian angles. The more specific and counter-conventional, the better.
>
> Format: "**Belief statement.** Explanation of why."

- **[Belief 1].** [Why you believe this.]
- **[Belief 2].** [Why you believe this.]
- **[Belief 3].** [Why you believe this.]
- **[Belief 4 — optional].** [Why you believe this.]
- **[Belief 5 — optional].** [Why you believe this.]

---

## VOICE RULES

> Keep or adapt these rules for your own writing style. Delete any that don't fit your voice.

**Direct.** No warm-up. First sentence does work. No "Great question!", no "In today's post...", no preamble.

**Contrarian by default.** Open with what everyone else believes that's wrong. Or with the thing nobody's saying that needs to be said.

**Evidence over assertion.** Don't claim — prove. Use specific numbers, specific names, specific results. General claims are weak. Specific examples land.

**Short sentences land harder.** Mix rhythm. Long sentence to set up the tension. Then one short one. That's the landing.

**No jargon.** Explain complex things simply. Clear > clever, always.

**Avoid:** "game-changer", "synergy", "hustle", "grind culture", "my journey", "I'm humbled", "honored to share", "unpopular opinion" (just have the opinion), "thought leader".

**[ADD YOUR OWN RULES]:** What words or phrases should never appear in your posts? What tone doesn't fit you?

---

## SIGNATURE PATTERNS

> These are reusable structures for your posts. Keep the ones that fit, add your own.

**The Distinction Pattern:**
"Most people call it [X]. I call it [Y]. The difference changes everything."

**The Paradox Pattern:**
"The more [A] you do, the less [B] you get. That's not a bug. It's the system working as designed."

**The Credential-Earned Contrarian:**
"I've spent [X years] watching [your audience] make this exact mistake. [Here's what I've seen.]"

**The Strategic Reframe:**
"You think you have a [surface problem]. You actually have a [root cause]. Here's how I know."

**The Anti-Hype:**
"Everyone's excited about [new shiny thing]. Here's what they're missing about why it won't work the way they think."

---

## YOUR DISTINCTIONS

> List the key distinctions, frameworks, or contrasts you teach. These are the ideas you return to again and again. They become your intellectual fingerprint on LinkedIn.
>
> Format: "[Concept A] vs [Concept B]" OR "[Your proprietary term or framework name]"

- [Distinction 1]
- [Distinction 2]
- [Distinction 3]
- [Distinction 4]
- [Distinction 5]
- [Add more as you develop them]

> TIP: If you ran the proof-stack-builder, your distinctions are in the "Core Frameworks" and "Intellectual Property" sections of that output.

---

## YOUR CREDENTIALS & PROOF

> List specific results, clients, experiences, and credentials. The skill will pull from these to make posts feel earned and real (not generic).
>
> Format: specific, with numbers when possible.

- [Years of experience in your field]
- [Number/type of clients or customers served]
- [Specific results you've produced]
- [Notable people you've worked with or who vouch for you]
- [Media, books, programs, or things you've built]
- [Any unique experiences that give you credibility]

---

## LINKEDIN FORMAT RULES

**Hook (line 1):** Must stop the scroll. A bold claim, a paradox, or a number. Under 15 words. No "I" to start.

**Body:** 3-7 short paragraphs. Each one moves the reader. No filler. No throat-clearing.

**White space:** One sentence = one paragraph when the sentence needs to land. Don't bury punches.

**Ending:** A question that invites reflection, a one-line principle, or a direct call to action (never all 3 at once).

**Length:** 150-300 words. LinkedIn's "see more" cutoff is ~3 lines. Make those 3 lines earn the click.

**No images needed** if the writing is strong. But if using images, screenshot of a real result > generic stock photo.

---

## YOUR AUDIENCE ON LINKEDIN

> Describe who you're writing for. Be specific about their situation, frustrations, and goals.

- **Who they are:** [Job title, type of business, industry, age range]
- **Where they are in their journey:** [Beginner? Experienced? Stuck? Growing?]
- **Their core frustration:** [What keeps them up at night in your domain]
- **What they want:** [Specific outcome they're chasing]
- **What they don't want:** [The thing that repels them — e.g., "another tactics dump"]
- **What makes them trust a source:** [Results? Credentials? Relatability? Framework quality?]

---

## YOUR CONTENT PILLARS

> List 3-5 topics you own. These are the areas where every post you write naturally connects to your expertise and your audience's needs.

1. **[Pillar 1]** — [1-line description of what you cover here]
2. **[Pillar 2]** — [1-line description]
3. **[Pillar 3]** — [1-line description]
4. **[Pillar 4 — optional]** — [1-line description]
5. **[Pillar 5 — optional]** — [1-line description]

---

## YOUR LEAD MAGNET CTA

> When posts offer a lead magnet, where should readers go? Fill in once, used everywhere.

- **Lead magnet destination:** [Notion page URL / website page / landing page]
- **CTA phrase:** [e.g., "Comment SYSTEM below and I'll send it to you" or "Link in comments"]
- **Your newsletter or community:** [Name + link, if you have one]
