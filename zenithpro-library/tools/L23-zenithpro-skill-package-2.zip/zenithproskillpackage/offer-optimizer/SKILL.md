# Active Offer Optimizer

---
name: offer-optimizer
description: "Use when you want to make a current, live offer convert better — not when creating new offers. Targets tactical and structural improvements to what's already selling."
---

## Purpose

The Offer Factory generates NEW ideas. This skill improves EXISTING ones. It takes an offer Rich is actively selling right now and systematically finds every way to make it more compelling, more urgent, easier to say yes to, and harder to say no to — without changing what the core product IS.

This is the difference between "What should I build next?" (Offer Factory) and "How do I sell more of what I'm already selling?" (this skill).

---

## Invocation

```
/offer-optimizer [offer name]
```

**Examples:**
```
/offer-optimizer Connect the Dots
/offer-optimizer ZenithPro Elite
/offer-optimizer Force Multiplier Intensive
/offer-optimizer "CTD $5K webinar offer"
```

---

## Input Requirements

**Required:**
- The offer to optimize (name or description)

**Strongly recommended:**
- Current price and pricing structure
- Current sales mechanism (webinar, VSL, sales call, email sequence)
- Current conversion rate (or directional: "converting well" / "underperforming")
- Current bonuses/guarantees/urgency mechanisms
- Known objections (from sales calls, support, refund reasons)
- Target buyer profile
- What the offer ascends to (backend) and what feeds into it (frontend)

**Will search for automatically:**
- Product registry (`~/.claude/skills/product-registry/`)
- Product component inventories (`Offer Factory/Product Components/`)
- Offer autopsies (`Offer Factory/Autopsies/`)

---

## The 10 Optimization Dimensions

The optimizer systematically generates improvements across 10 dimensions. For each dimension, it produces 3+ specific, implementable ideas using VS-CoT (k=3 candidates per slot, probability tagged).

### Dimension 1: Guarantee Innovation

Go beyond "60-day money-back." Generate novel guarantee structures:
- Conditional guarantees (tied to specific actions/outcomes)
- Aspirational guarantees (promise something bigger than a refund)
- Sealed-envelope guarantees (personalized, pre-committed)
- Partial/progressive guarantees (guarantee increases with engagement)
- Anti-guarantee (deliberately NO guarantee — and why that's more powerful)
- Double-your-money guarantees (with conditions)
- Guarantee stacking (multiple guarantees covering different risks)

**For each:** State the guarantee language, the risk to Rich (actual exposure), and the psychological mechanism (why this reduces buyer resistance).

### Dimension 2: Bonus Architecture

Bonuses that solve specific objections or accelerate results:
- Objection-killing bonuses (each major objection gets a bonus that eliminates it)
- Speed bonuses (help the buyer get results faster)
- FOMO bonuses (available only to action-takers, disappear after deadline)
- Unexpected bonuses (announced AFTER purchase to spike satisfaction)
- Anti-bonuses (remove something to increase perceived value — "no fluff" positioning)
- Community bonuses (access to a group, not just content)
- Tool bonuses (templates, scripts, frameworks — not more education)

**For each:** Name the bonus, describe it in one sentence, state which objection or desire it addresses, and estimate build effort.

### Dimension 3: Pricing Structure

Same price point, different structure:
- Payment plan variations (2-pay, 3-pay, deposit + balance)
- Performance pricing (pay less upfront, more when you get results)
- Founding member pricing (early adopter discount with deadline)
- Tiered access (same core, different access levels at different prices)
- Bundle pricing (combine with another product at a discount)
- Split-test pricing (specific prices to test)
- Anchor pricing (what to show BEFORE the price to make it feel like a deal)
- Price justification framing (cost per day, ROI framing, comparison anchors)

### Dimension 4: Urgency & Scarcity

Authentic urgency mechanisms (not fake countdown timers):
- Genuine capacity limits (and how to make them believable)
- Cohort-based enrollment (next cohort isn't for X months)
- Price increase schedule (announced in advance, actually executed)
- Bonus removal timeline (specific bonuses disappear at specific dates)
- Early-bird pricing (with clear deadline)
- Application windows (open/close dates)
- Results-based urgency (the cost of waiting — what the buyer loses per week of inaction)
- Social urgency (peer activity — "47 people enrolled this week")

### Dimension 5: Objection Pre-handling

Structural changes to the offer that make objections irrelevant:
- For each known objection, design an offer element that eliminates it BEFORE it forms
- For unknown objections, use the "What would stop a smart person from buying this?" framework
- FAQ-as-offer-design: turn the most common questions into offer features
- Anti-objection bonuses (see Dimension 2)
- Objection acknowledgment in positioning ("This is NOT for people who...")

### Dimension 6: Positioning & Framing

How the offer is DESCRIBED, not what it IS:
- Category reframing (is this "a course" or "a system"? "coaching" or "strategic consulting"?)
- Outcome framing (lead with RESULT, not process)
- Contrast positioning (vs. alternatives — without attacking)
- Identity positioning (who the buyer BECOMES, not what they GET)
- Status positioning (what buying signals about the buyer)
- Origin story framing (WHY this offer exists — mission, discovery, frustration)
- Naming optimization (does the offer name create curiosity, clarity, or desire?)

### Dimension 7: Delivery Mechanism

Same content/value, better packaging:
- Format swaps (live → recorded, group → 1:1, course → workshop → sprint)
- Pacing changes (self-paced → structured, 12 weeks → 4 weeks intensive)
- Access model changes (lifetime → annual, limited → unlimited)
- Fulfillment innovation (AI-assisted delivery, personalized paths, adaptive content)
- Physical components (printed workbooks, boxes, cards — for digital products)
- Hybrid models (mix of live + recorded + tool + community)

### Dimension 8: Social Proof Optimization

Better use of existing proof:
- Testimonial strategy (which testimonials, where, in what format)
- Case study creation (turn best results into detailed case studies)
- Results documentation (screenshot archives, before/after, metrics)
- Celebrity/authority endorsement (who credible has said something positive?)
- Peer proof (how many people like the buyer have bought this?)
- Process proof (show the methodology working in real-time)
- Anti-proof (acknowledge failures honestly — paradoxically builds more trust)

### Dimension 9: Ascension Integration

How this offer connects to the next offer:
- Built-in upsell triggers (natural moments where the buyer wants MORE)
- Graduation pathways (complete this → qualify for that)
- Cross-sell hooks (during delivery, expose buyer to adjacent products)
- Referral mechanics (turn buyers into promoters)
- Downsell recovery (what to offer people who say no to the main offer)
- Retention mechanics (for recurring offers — reduce churn)

### Dimension 10: Launch & Sales Mechanism

How the offer is SOLD:
- Webinar structure optimization (for webinar-sold offers)
- VSL structure optimization (for VSL-sold offers)
- Email sequence optimization (for email-sold offers)
- Sales call optimization (for call-sold offers)
- Landing page structure
- Application process design (for high-ticket)
- Multi-touch sequence design (the full journey from awareness to purchase)

---

## Execution Process

### Step 1: Offer Audit

Before generating improvements, understand what exists:
- Load all available information about the offer (product registry, component inventories, autopsies)
- Document the current state of all 10 dimensions
- Identify which dimensions are strongest (leave alone) and weakest (most opportunity)

### Step 2: Generate Improvements (VS-CoT)

For each of the 10 dimensions:
1. Reason about the problem space for THIS specific offer
2. Generate k=3 candidates per improvement slot
3. Tag probabilities — prioritize non-obvious improvements
4. Select the best candidate AND show alternates

Minimum: 3 improvements per dimension = 30+ total improvements

### Step 3: Prioritize

Rank ALL improvements by:

| Factor | Weight |
|--------|--------|
| Conversion impact (expected) | 35% |
| Implementation effort (inverted) | 25% |
| Speed to deploy | 20% |
| Risk (inverted) | 10% |
| Novelty | 10% |

### Step 4: Action Plan

Produce three lists:
1. **Do This Week** — 5 improvements that can be implemented in days with high impact
2. **Do This Month** — 10 improvements that need some preparation
3. **Do This Quarter** — Remaining improvements that require significant effort

---

## Output

### File Location
```
Active-Brain/00 Projects/01 Behavioral Intelligence/Offer Optimizer/[Offer Name] - Optimized - [Date].md
```

Create the output folder if it doesn't exist.

### Document Structure

```markdown
# Offer Optimization: [Offer Name]
**Date:** [Date]
**Current Price:** [Price]
**Current Sales Mechanism:** [Webinar/VSL/Call/etc.]
**Current Conversion Rate:** [If known]
**Backend:** [What this ascends to]
**Frontend:** [What feeds into this]

## Current State Audit
[10-dimension snapshot of where the offer is now]

## Do This Week (Top 5)

### 1. [Improvement Name]
**Dimension:** [Which of the 10]
**What to change:** [Specific, actionable instruction]
**Why it works:** [Mechanism — not just "it'll convert better"]
**Expected impact:** [Directional: minor lift / moderate lift / significant lift]
**Implementation:** [Exact steps to deploy this]

[...repeat for all 5...]

## Do This Month (Next 10)
[Same format, slightly less detail]

## Do This Quarter (Remaining)
[Same format, brief]

## Full Improvement Catalog by Dimension

### Guarantee Innovation
[All improvements in this dimension with details]

### Bonus Architecture
[...]

[...all 10 dimensions...]

## Combined Impact Estimate
- If all "This Week" improvements are deployed: [expected lift]
- If all "This Month" improvements are added: [expected lift]
- If all improvements are deployed: [expected lift]
- Risk assessment: [what could go wrong]
```

---

## Quality Standards

**A good optimization run makes Rich say "I can use this TODAY."**

Signs it's working:
- At least 5 improvements Rich can implement before next week
- Improvements are SPECIFIC to this offer, not generic advice
- Each improvement has a clear mechanism (not just "add more bonuses")
- The combined effect is clearly greater than any single change
- The improvements respect Rich's brand and positioning

Signs it's phoning it in:
- Generic advice that could apply to any offer ("add testimonials")
- Improvements that require rebuilding the offer from scratch
- All improvements in the same dimension
- No specificity about implementation
- Improvements that conflict with each other
