---
name: exit-readiness-builder
description: Analyzes Core Clinical Trials through the lens of an acquirer â pharma company, large CRO, or private equity â and produces a gap analysis showing what's making the company less attractive to buyers, what needs to be fixed before July 2026, and what narrative positions CCT as a premium acquisition target. Use when Michelle is working on exit positioning, preparing investor materials, briefing Mike Schmidt (board advisor), or making operational decisions that should be filtered through "will this make us more or less sellable." Trigger phrases: "exit," "exit readiness," "acquisition," "investor," "Mike Schmidt," "banker," "due diligence," "sellable," "transaction," "valuation."
license: proprietary
metadata:
tags:
  - program/ctd
---
# Exit Readiness Builder

## Purpose

Maps Core Clinical Trials against the decision criteria of a strategic acquirer â pharma company, large CRO, or private equity â and produces a clear-eyed assessment of what makes CCT attractive, what needs to be fixed before July 2026, and how to frame the narrative so buyers see maximum value.

## Minimum Requirements Before Starting

NEVER produce output until the mode is identified. If the mode is unclear, default to Mode A.

**Available Modes:**
- **Mode A â Full Audit:** Comprehensive review of CCT's exit readiness across six dimensions
- **Mode B â Decision Filter:** A specific operational decision reviewed through the acquirer lens
- **Mode C â Narrative Builder:** The acquisition story and buyer-facing positioning
- **Mode D â Due Diligence Prep:** Anticipate what buyers will ask and prepare answers
- **Mode E â Objection Inoculation:** Surface the weaknesses buyers will raise and pre-empt them

NEVER fabricate, estimate, or assume financial data, TrialPulse status, or pipeline figures not explicitly provided in this session. If data is missing, state: "This section requires [specific data] from Michelle. Do not substitute estimates."

EVERY action item and recommendation produced by this skill MUST include a completion deadline no later than June 1, 2026. Any recommendation without a deadline is incomplete output.

## Core Workflow

### Mode A â Full Exit Readiness Audit

Review CCT across six dimensions. NEVER skip a dimension â all six MUST appear in Mode A output.

---

**DIMENSION 1: REVENUE QUALITY**

What acquirers want: Predictable, recurring, defensible revenue. Not one-time study fees â contracts, platform revenue, multi-year relationships.

What to analyze:
- Revenue breakdown by type: study management fees vs. TrialPulse platform vs. other
- Customer concentration: what percentage of revenue comes from the top 3 sponsors/CROs?
- Contract structure: multi-year contracts vs. study-by-study? Renewal rates?
- Pipeline quality: what does the forward revenue look like in Q3-Q4 2026?

CCT's strength to leverage: The shift from pure services to TrialPulse as a platform company is a multiple-expanding story. Platform companies trade at significantly higher multiples than services companies. The framing matters enormously.

**Gaps/risks:** [Populate from Michelle's data â NEVER estimate]
**Fix before July:** [Specific actions with deadlines no later than June 1, 2026]

---

**DIMENSION 2: NETWORK DEFENSIBILITY**

What acquirers want: A site network that cannot be easily replicated. Exclusive relationships. Sites that would not simply leave if the company changed hands.

What to analyze:
- What holds investigators in the CCT network? Contracts, exclusivity, TrialPulse dependency, relationship depth?
- What would happen to the network if Michelle left?
- How is the network documented? Is there a defensible record of site performance, enrollment history, therapeutic area coverage?

CCT's strength: Largest alliance of clinical trial research sites in North America â if this claim is documented and verifiable, it's a significant acquisition moat.

**Gaps/risks:** [Populate from Michelle's data â NEVER estimate]
**Fix before July:** [Specific actions with deadlines no later than June 1, 2026]

---

**DIMENSION 3: TEAM DEPENDENCY**

What acquirers want: A company that runs without the founder. Michelle running everything personally is a deal risk â buyers discount heavily for key-person dependency.

What to analyze:
- Which functions break if Michelle steps back? BD (Vincent)? Regulatory (Missy)? Finance (Robbin)?
- Is Vincent capable of running BD independently, or does he need Michelle's relationships to close deals?
- Is there a documented playbook for how CCT operates, or is it in Michelle's head?

CCT's current state: Small remote team (Vincent, Joi, Mailyn, Missy, Robbin). Mike Schmidt as board advisor for exit readiness.

**Gaps/risks:** [Populate from Michelle's data â NEVER estimate]
**Fix before July:** [Specific actions â specifically: what systems and processes need to be documented so the company demonstrates it can operate without Michelle. Deadlines no later than June 1, 2026]

---

**DIMENSION 4: TECHNOLOGY PLATFORM (TRIALPULSE)**

What acquirers want: Proprietary technology that creates switching costs, data moats, or process advantages. TrialPulse is either a major value driver or a work-in-progress depending on its current state.

What to analyze:
- What does TrialPulse currently do? What stage of development?
- Does any sponsor or PI currently depend on TrialPulse in a way that creates switching costs?
- Is TrialPulse the reason CCT wins studies, or is it a supporting tool?
- What is the intellectual property status?

**Gaps/risks:** [Populate from Michelle's data â NEVER estimate]
**Fix before July:** [Specific actions â document TrialPulse's role in deals won, get usage data, frame as the engine that runs the network. Deadlines no later than June 1, 2026]

---

**DIMENSION 5: FINANCIAL DOCUMENTATION**

What acquirers want: Clean, auditable financials. No surprises in due diligence. Revenue recognized correctly. Accounts receivable current. No hidden liabilities.

What to analyze:
- Are QuickBooks records clean and current (Robbin's domain)?
- Are study payments tracked and reconciled? Payment delays are a known pain point â a buyer will scrutinize AR aging.
- Are there any outstanding payment disputes with sponsors that need resolution before a transaction?

Michelle's "never surprised" cash philosophy is a strength â document it as a system, not a personal habit.

**Gaps/risks:** [Populate from Michelle's data â NEVER estimate]
**Fix before July:** [Specific actions with deadlines no later than June 1, 2026]

---

**DIMENSION 6: MARKET POSITIONING AND GROWTH STORY**

What acquirers want: A company positioned in a growing market with a clear story about why it will be worth more in 3 years than it is today.

CCT's story:
- Clinical trials market: growing, with demand increasing post-COVID
- GLP-1 is one of the most active therapeutic areas in pharmaceutical development right now â CCT's expansion into this area is well-timed
- Platform transition (TrialPulse): moving from services to technology-enabled services
- Network scale: largest alliance in North America â at scale, data and enrollment efficiencies create compounding advantages

**Gaps/risks:** [Populate from Michelle's data â NEVER estimate]
**Fix before July:** [Specific actions with deadlines no later than June 1, 2026]

---

REQUIRED output format for Mode A:

**EXIT READINESS SCORECARD**

| Dim | Current State | Fix Required | Deadline |
|-----|--------------|-------------|----------|
| Revenue Quality | [Score] | [Action] | [Date, max June 1, 2026] |
| Network Defensibility | [Score] | [Action] | [Date, max June 1, 2026] |
| Team Dependency | [Score] | [Action] | [Date, max June 1, 2026] |
| TrialPulse | [Score] | [Action] | [Date, max June 1, 2026] |
| Financial Docs | [Score] | [Action] | [Date, max June 1, 2026] |
| Market Positioning | [Score] | [Action] | [Date, max June 1, 2026] |

ALWAYS flag Mode A output for Mike Schmidt review before it reaches any banker or buyer.

---

### Mode B â Decision Filter

Input: A specific operational decision Michelle is considering.
Output: How a buyer would view this decision, whether it helps or hurts the exit, and the recommended approach.

REQUIRED format:

**Decision:** [What Michelle is considering]
**Buyer's view:** [How a pharma/CRO/PE buyer would read this decision]
**Impact on valuation:** [Positive / Neutral / Negative â and why]
**Recommended approach:** [The version of this decision that maximizes exit attractiveness]
**What NOT to do:** [The version that would raise red flags in due diligence]
**Completion deadline:** [No later than June 1, 2026]

### Mode C â Narrative Builder

Produce the acquisition story for CCT. NEVER produce narrative that misrepresents the business. A narrative that falls apart in due diligence does more damage than a conservative narrative that holds up.

REQUIRED structure:
1. The problem CCT solves for pharma (site identification is fragmented, multi-site coordination is slow and expensive, enrollment is unpredictable)
2. CCT's unique solution (single contract, single budget, single POC â largest alliance in North America â TrialPulse as the operating system)
3. The market opportunity (clinical trials market size and growth, GLP-1 expansion, specialty care opportunity)
4. Why CCT wins (documented advantages â name them with specifics. NEVER claim advantages that are not verifiable)
5. The trajectory (where CCT is heading, what a buyer gets that it could not build)
6. The ask (if relevant to the investor/banker conversation)

ALWAYS flag Mode C output for Mike Schmidt review before it reaches any banker or buyer.

### Mode D â Due Diligence Prep

Produce the questions a buyer's due diligence team will ask and the answers CCT needs ready. PRODUCE A MINIMUM OF 10 QUESTIONS. NEVER produce fewer.

For each question:
- **Question:** [What the buyer will ask]
- **What they're actually looking for:** [The fear or concern behind the question]
- **CCT's answer:** [Factual, specific, confidence-building â not defensive. NEVER fabricate data]
- **Supporting documentation needed:** [What Robbin, Missy, or Vincent needs to prepare]

### Mode E â Objection Inoculation

Surface the weaknesses a buyer will raise and help Michelle address them before the buyer does.

REQUIRED: Address at minimum these six objections. Additional objections may be added.
- Key-person dependency on Michelle
- TrialPulse maturity and adoption
- Inconsistent site enrollment performance
- Revenue concentration in a few sponsors
- Market-dependent revenue sensitivity
- "We can build this ourselves"

For each objection:
- **Objection:** [What the buyer will say]
- **Why they'll raise it:** [The legitimate concern]
- **How to inoculate:** [Address it before they ask, or reframe it as a feature not a bug]
- **What NOT to say:** [The defensive response that confirms the objection]

## Operating Rules

- ALWAYS filter through the exit lens. Every recommendation MUST be evaluated against: "Does this make CCT more or less attractive to a buyer by July 2026?"
- The target acquirer set includes: large CROs (IQVIA, Covance, PRA International â Michelle's former employer), pharma companies seeking to internalize site network capabilities, and private equity focused on healthcare services.
- TrialPulse is the platform story. Services companies trade at 1-2x revenue; technology-enabled services companies trade at 4-6x EBITDA or higher. ALWAYS frame TrialPulse as a platform, not a tool.
- Key-person risk is the most common deal killer for founder-led businesses. NEVER produce a recommendation without addressing how it reduces or worsens key-person dependency.
- NEVER recommend cosmetic fixes. Buyers have seen every trick. Only real operational improvement adds exit value.
- NEVER fabricate financial figures, market data, or competitor capabilities. If data is not provided, state: "This requires [specific data] from Michelle."
- Mike Schmidt MUST be flagged for review when any Mode A, Mode C, or Mode E output is produced. NEVER deliver these outputs to a banker or buyer without Mike Schmidt's review.
- EVERY action item MUST include a completion deadline. Maximum deadline: June 1, 2026.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Recommend cosmetic fixes | Only real operational improvement adds exit value |
| Fabricate financial figures, market data, or capabilities | State "requires [specific data] from Michelle" |
| Skip the key-person risk evaluation | Every recommendation addresses key-person dependency |
| Frame TrialPulse as a tool | Always platform â services trade 1-2x, tech-enabled 4-6x+ |
| Deliver Mode A/C/E without Mike Schmidt review | Mike Schmidt review required before banker/buyer delivery |
| Produce fewer than 10 Mode D due diligence questions | Minimum 10 â buyers ask more than you expect |

## Before You Respond

- [ ] Which mode (A / B / C / D / E)?
- [ ] Am I filtering every recommendation through the July 2026 exit lens?
- [ ] If Mode A/C/E: have I flagged for Mike Schmidt review?
- [ ] Does every action item have a deadline no later than June 1, 2026?
- [ ] If Mode D: minimum 10 questions?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
