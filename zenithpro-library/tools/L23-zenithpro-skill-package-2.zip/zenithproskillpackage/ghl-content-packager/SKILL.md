---
name: ghl-content-packager
description: Takes finished Level 5 Mentoring campaign assets (landing pages, email sequences, ad copy) and reformats them for direct import or manual entry into GoHighLevel (GHL). Produces GHL-ready email bodies, funnel page copy blocks, automation sequence structure, and a step-by-step implementation guide. Use when Abigail says "format this for GHL," "I need to put this into GoHighLevel," "help me build this in GHL," or "get this campaign ready to go live."
license: proprietary
metadata:
tags:
  - program/ctd
---
# GHL Content Packager

Bridges the gap between written campaign assets and live GoHighLevel implementation. Takes any Level 5 Mentoring campaign and produces GHL-structured copy, page blocks, email automation specs, and an implementation guide Abigail or a VA can follow without guessing.

## Keywords
GoHighLevel, GHL, funnel, automation, email campaign, landing page, implementation, deploy, CRM, email sequence, form, pipeline

## Quick Start

1. Paste or point me to the finished campaign assets (landing page copy, email sequence, ad copy)
2. Tell me what you're building in GHL: registration funnel? Email nurture sequence? Thank-you page? Sales page?
3. I produce the GHL-ready package
4. You or your VA implements directly in GHL

No API connection required in this version. This skill produces structured copy and step-by-step guidance â a VA or Abigail builds it manually in GHL.

---

## GHL Implementation Map

This skill handles four common GHL build types for Level 5 Mentoring:

| Build Type | What You Provide | What I Produce |
|-----------|-----------------|----------------|
| Registration Funnel | Landing page copy | Opt-in page blocks, thank-you page, form field specs |
| Email Automation Sequence | Email sequence (5â7 emails) | GHL email automation spec: triggers, delays, subject lines, body formatting |
| Sales Page | Full sales copy | Hero section, body sections, CTA sections, price block |
| Ad â Funnel Pipeline | Ad copy + landing page | Ad creative specs + matching landing page for message continuity |

---

## Core Workflow

### Step 1 â Asset Inventory

Before producing the GHL package, confirm what assets exist:

```
ASSET CHECK:
[ ] Landing page / opt-in page copy (headline, body, CTA)
[ ] Thank-you page copy
[ ] Email sequence (how many emails? Subject lines + body complete?)
[ ] Ad copy
[ ] Sales page (if separate from opt-in)
[ ] Webinar replay page (if applicable)

Missing assets: [list â these need to be written first using spellbreak-campaign-engine]
```

Proceed with what exists. Flag missing assets and offer to produce them via spellbreak-campaign-engine before packaging.

### Step 2 â Funnel Page Blocks

For each page in the funnel, reformat the copy into GHL's visual section structure:

---

**OPT-IN PAGE STRUCTURE (GHL Section Format)**

```
SECTION 1: Hero
  - Headline: [exact text]
  - Sub-headline: [exact text]
  - Background: [color or image description]
  - CTA Button: [button text] â [action: submit form / go to next page]

SECTION 2: Body (repeat for each content block)
  - Section purpose: [what this section does]
  - Copy block: [exact text]
  - Layout: [text only / text + image / text + video embed]

SECTION 3: Form
  - Form fields: First Name, Email [+ any others specified]
  - Button text: [exact CTA]
  - Privacy note: [text below form if applicable]

SECTION 4: Footer
  - Copy: [legal / privacy / contact]
```

---

**THANK-YOU PAGE STRUCTURE**

```
SECTION 1: Confirmation
  - Headline: [confirmation message]
  - Sub-headline: [what to expect / next step]

SECTION 2: What's Next
  - Instructions: [check email / add to calendar / join Facebook group]
  - Calendar link block: [if masterclass â provide calendar event details]

SECTION 3: Pre-Frame (optional)
  - Copy: [short content that primes them for the masterclass]
```

---

### Step 3 â Email Automation Spec

For each email in the sequence, produce a GHL automation card:

```
EMAIL [#]: [Email Name]
Trigger: [Registration / Time delay from previous / Tag applied]
Delay: [Immediately / X hours / X days after trigger]
From Name: [Abigail Morgan | Level 5 Mentoring]
From Email: [abigail@level5mentoring.com â confirm with Abigail]
Subject Line: [exact text]
Preview Text: [exact text â 40â90 characters]
Body: [full formatted email body]
  â Paragraph breaks: use double line break
  â Bold: use for key phrases
  â Links: [describe link text and destination]
CTA Link Text: [exact text]
CTA Link Destination: [URL or GHL page]
Tags to apply on send: [if any]
Tags to apply on click: [if any â for pipeline tracking]
```

Produce one card per email. Stack them in sequence order.

**Automation workflow diagram (text format):**

```
TRIGGER: Registration on [Opt-In Page Name]
  â
Tag Applied: [Campaign Name]-Registered
  â Immediately
Email 1: [Name] sent
  â 24 hours
Email 2: [Name] sent
  â 24 hours
Email 3: [Name] sent
  ...continue through sequence...
  â
[At masterclass date/time]
Email 4: Day-of reminder sent
  â 24 hours after masterclass
Email 5: Replay sent
  â 2 days
Email 6: Bridge / offer sent
  â 2 days
Email 7: Last chance sent
  â
Tag Applied: [Campaign Name]-Sequence-Complete
```

### Step 4 â Implementation Guide

Produce a step-by-step guide for Abigail or a VA to build this in GHL:

```
IMPLEMENTATION GUIDE: [Campaign Name]
Estimated build time: [X hours for VA with GHL experience]

STEP 1: Create the Funnel
  1. In GHL, go to Funnels > Create New Funnel
  2. Name it: [Campaign Name] â [Date]
  3. Add pages in this order: [list]
  4. [Specific instructions per page]

STEP 2: Build the Opt-In Page
  1. Click on [Page Name]
  2. Add Section 1 (Hero): [instructions]
  3. [Continue step by step]

STEP 3: Set Up the Email Automation
  1. Go to Automation > Create Workflow
  2. Name it: [Campaign Name] Email Sequence
  3. Set trigger: [exact trigger setting in GHL]
  4. Add Email 1: [Subject line] â paste body from this document
  5. Set delay: Immediately
  6. Add Email 2: [Subject line] â paste body
  7. Set delay: 1 day
  [Continue for all emails]

STEP 4: Connect Form to Automation
  1. In the opt-in page form settings, set trigger: [Workflow name]
  2. Test with a test email address
  3. Confirm Email 1 arrives within 5 minutes

STEP 5: QA Checklist Before Going Live
  [ ] All pages load correctly
  [ ] Form submits and triggers Email 1
  [ ] All emails arrive with correct subject lines
  [ ] All links in emails go to correct destinations
  [ ] Thank-you page appears after form submission
  [ ] Mobile view checked on opt-in page
```

---

## GHL-Specific Formatting Rules

When formatting email body copy for GHL:
- Use plain text formatting (GHL email editor handles its own styling)
- Indicate bold with **text** markers so the implementer knows what to bold
- Hyperlinks: write as `[Link Text](URL)` â implementer selects text and adds link in GHL
- Avoid em-dashes in email bodies (some email clients render them incorrectly â use double hyphen -- as a safe substitute)
- Keep paragraphs short (2â3 lines) â GHL email editor does not always preserve line breaks faithfully on all clients

---

## Constraints

- NEVER include placeholder text in the final package. If a copy asset is missing, stop, list exactly what is missing, and note that it must be written (via spellbreak-campaign-engine) before packaging continues.
- NEVER use em-dashes in email body copy. Use double hyphen (--) as substitute for cross-client rendering safety.
- NEVER produce a GHL package without completing the Asset Inventory (Step 1) first. Packaging incomplete assets produces a broken funnel.
- NEVER write implementation instructions that assume the VA understands the Spellbreaking method. Instructions are for a GHL-competent VA with zero method knowledge.
- ALWAYS label hyperlinks as `[Link Text](URL)` â the implementer selects the text and adds the link in GHL.
- ALWAYS keep email paragraph copy to 2-3 lines. GHL email editor does not reliably preserve line breaks across all clients.
- ALWAYS include the QA checklist (Step 5 of Implementation Guide) in every package. Non-negotiable before go-live.
- This skill produces documentation for manual GHL implementation only. Direct API integration is a future build â flag this to Abigail when she is ready to scope it.
- If Abigail has no VA and will implement herself: note estimated time in the implementation guide header.

## Output Block

Every run produces one complete, self-contained GHL package document:

1. Asset inventory confirmation (what exists / what's missing)
2. Funnel page blocks in GHL section format (Hero / Body / Form / Footer / Thank-You)
3. Email automation spec: one card per email, stacked in sequence order
4. Automation workflow diagram in text format
5. Implementation guide: step-by-step, VA-executable, with estimated build time
6. QA checklist before go-live

Save to: `AI-Training/02 Campaigns/[Campaign Name]/GHL-Package.md`

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Include placeholder text in the final package | Stop and list what's missing |
| Use em-dashes in email body copy | Double hyphen (--) for cross-client rendering safety |
| Skip the Asset Inventory (Step 1) | Packaging incomplete assets breaks the funnel |
| Assume the VA understands Spellbreaking method | Instructions are GHL-competent, method-agnostic |
| Deliver the package without a QA checklist | Non-negotiable before go-live |
| Suggest direct API integration as current capability | Flag as future build |

## Before You Respond

- [ ] Have I completed the Asset Inventory first?
- [ ] Are all copy assets present (not placeholder text)?
- [ ] Are hyperlinks formatted as [Link Text](URL)?
- [ ] Is every email paragraph 2-3 lines max?
- [ ] Does the package include the QA checklist?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
