# Setup Required — Fireflies Meeting Downloader

Downloads meeting transcripts from Fireflies AI to Obsidian.

## To configure:

1. Get your Fireflies API key: app.fireflies.ai → Integrations → API Key
2. Open `references/bulk-download.js`
3. Replace `YOUR_FIREFLIES_API_KEY` with your key
4. Update the output path to your Obsidian vault
