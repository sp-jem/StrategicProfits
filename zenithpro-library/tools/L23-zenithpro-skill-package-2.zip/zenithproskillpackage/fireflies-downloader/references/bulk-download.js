/**
 * Fireflies AI Bulk Downloader
 *
 * Downloads all meeting transcripts from Fireflies AI via GraphQL API
 * Saves as Obsidian-compatible markdown files with YAML frontmatter tags
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

// ─── Attendee-based routing ────────────────────────────────────────────────

const HARRY_EMAILS = [
  'harry.lockwood67@gmail.com',
  'harry@strategicprofits.com',
  'harry@lockwoodcollegeprep.com',
];

function routeByAttendee(transcript) {
  const attendeeEmails = (transcript.meeting_attendees || [])
    .map(a => (a.email || '').toLowerCase())
    .filter(Boolean);

  const allEmails = new Set([
    ...attendeeEmails,
    (transcript.host_email || '').toLowerCase(),
    (transcript.organizer_email || '').toLowerCase(),
  ]);

  const hasLCP      = allEmails.has('harry@lockwoodcollegeprep.com');
  const hasSP       = allEmails.has('harry@strategicprofits.com');
  const hasPersonal = allEmails.has('harry.lockwood67@gmail.com');

  if (!hasLCP && !hasSP && !hasPersonal) {
    console.log('   -> SKIP (Harry not in attendees)');
    return 'SKIP';
  }
  if (hasLCP && !hasSP && !hasPersonal) {
    console.log('   -> LCP (attendee match)');
    return OUTPUT_DIR_LCP;
  }
  if ((hasSP || hasPersonal) && !hasLCP) {
    console.log('   -> SP (attendee match)');
    return OUTPUT_DIR_SP;
  }
  // Both LCP and SP/personal present — fall through to keyword routing
  return null;
}

// Configuration
const API_KEY = 'fd67b8c2-990a-4075-ac1d-65d494e4739d';
const OUTPUT_DIR_SP  = '/Users/harryiii/HQ/Zoom Meetings/Strategic Profits';
const OUTPUT_DIR_LCP = '/Users/harryiii/HQ/Zoom Meetings/Lockwood College Prep';
const API_ENDPOINT = 'https://api.fireflies.ai/graphql';

// LCP routing — if any of these appear anywhere in the transcript, route to LCP
const LCP_KEYWORDS = [
  /\bandy\b/i,
  /\bmy dad\b/i,
  /\bkajabi\b/i,
  /\bcollege\b/i,
  /\bsat\b/i,
  /\bact\b/i,
  /\btutoring\b/i,
  /\btutor\b/i,
  /\badmission/i,
  /\bapplication\b/i,
  /\bfinancial\s*aid\b/i,
  /\bscholarship\b/i,
  /\blockwood\s*college\b/i,
  /\btest\s*prep\b/i,
  /\bgpa\b/i,
  /\bhigh\s*school\b/i,
];

function routeToFolder(transcript) {
  const searchText = [
    transcript.title || '',
    transcript.summary?.overview || '',
    transcript.summary?.short_summary || '',
    (transcript.sentences || []).map(s => s.text || '').join(' ')
  ].join(' ');

  for (const kw of LCP_KEYWORDS) {
    if (kw.test(searchText)) {
      console.log(`   -> LCP (matched: ${kw})`);
      return OUTPUT_DIR_LCP;
    }
  }
  return OUTPUT_DIR_SP;
}

// Date range - can be overridden via environment variables
// MEETING_FROM_DATE and MEETING_TO_DATE for automated daily collection
const FROM_DATE = process.env.MEETING_FROM_DATE || '2026-01-01T00:00:00.000Z';
const TO_DATE = process.env.MEETING_TO_DATE || new Date().toISOString();

// Known team members for participant tagging
const KNOWN_PEOPLE = {
  'rich': 'Rich Schefren',
  'richard': 'Rich Schefren',
  'richard schefren': 'Rich Schefren',
  'nicole': 'Nicole M',
  'ashley': 'Ashley Shaw',
  'ashley shaw': 'Ashley Shaw',
  'michelle': 'Michelle Mattison',
  'tom': 'Tom Hammaker',
  'ben': 'Ben Thole',
  'jessica': 'Jessica Middlebrook',
  'joseph': 'Joseph Conrad',
  'katrine': 'Katrine',
  'irish': 'Irish Arenal',
  'jem': 'Jem Erroba'
};

// Meeting type detection patterns
const MEETING_TYPES = [
  { pattern: /zenithpro/i, type: 'ZenithPro Session' },
  { pattern: /zenith\s*mind/i, type: 'ZenithMind Session' },
  { pattern: /copy\s*clinic/i, type: 'Copy Clinic' },
  { pattern: /office\s*hours/i, type: 'Office Hours' },
  { pattern: /1[:\-]1|one.on.one|1on1/i, type: '1:1 Meeting' },
  { pattern: /strategic\s*partner/i, type: 'Strategic Partner Call' },
  { pattern: /sow|steal\s*our\s*winners/i, type: 'SOW Session' },
  { pattern: /team\s*meeting|team\s*call/i, type: 'Team Meeting' },
  { pattern: /copywriter/i, type: 'Copywriter Call' },
  { pattern: /client/i, type: 'Client Call' },
  { pattern: /interview/i, type: 'Interview' },
  { pattern: /webinar/i, type: 'Webinar' },
  { pattern: /workshop/i, type: 'Workshop' }
];

function makeGraphQLRequest(query, variables = {}) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify({ query, variables });

    const options = {
      hostname: 'api.fireflies.ai',
      path: '/graphql',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`,
        'Content-Length': Buffer.byteLength(postData)
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error(`Parse error: ${data.substring(0, 200)}`));
        }
      });
    });

    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

async function fetchTranscriptList(skip = 0) {
  const query = `
    query Transcripts($fromDate: DateTime, $toDate: DateTime, $limit: Int, $skip: Int) {
      transcripts(fromDate: $fromDate, toDate: $toDate, limit: $limit, skip: $skip) {
        id
        title
        date
        host_email
        organizer_email
        duration
      }
    }
  `;

  return makeGraphQLRequest(query, {
    fromDate: FROM_DATE,
    toDate: TO_DATE,
    limit: 50,
    skip: skip
  });
}

async function fetchFullTranscript(transcriptId) {
  const query = `
    query Transcript($transcriptId: String!) {
      transcript(id: $transcriptId) {
        id
        title
        date
        dateString
        host_email
        organizer_email
        duration
        transcript_url

        sentences {
          speaker_name
          text
          start_time
          end_time
        }

        summary {
          keywords
          action_items
          overview
          short_summary
          topics_discussed
        }

        speakers {
          id
          name
        }

        meeting_attendees {
          displayName
          email
          name
        }
      }
    }
  `;

  return makeGraphQLRequest(query, { transcriptId });
}

function formatDuration(seconds) {
  if (!seconds) return 'Unknown';
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}m ${secs}s`;
}

function detectMeetingType(title, summary) {
  const text = `${title || ''} ${summary || ''}`.toLowerCase();

  for (const mt of MEETING_TYPES) {
    if (mt.pattern.test(text)) {
      return mt.type;
    }
  }
  return 'Meeting';
}

function extractParticipants(transcript) {
  const participants = new Set();

  // From meeting attendees
  if (transcript.meeting_attendees) {
    transcript.meeting_attendees.forEach(a => {
      const name = a.displayName || a.name || '';
      if (name) {
        const normalized = name.toLowerCase().trim();
        if (KNOWN_PEOPLE[normalized]) {
          participants.add(KNOWN_PEOPLE[normalized]);
        } else if (name.length > 1) {
          participants.add(name.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' '));
        }
      }
    });
  }

  // From speakers
  if (transcript.speakers) {
    transcript.speakers.forEach(s => {
      const name = s.name || '';
      if (name) {
        const normalized = name.toLowerCase().trim();
        if (KNOWN_PEOPLE[normalized]) {
          participants.add(KNOWN_PEOPLE[normalized]);
        } else if (name.length > 1 && name !== 'Unknown') {
          participants.add(name.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' '));
        }
      }
    });
  }

  // From title (common patterns like "Nicole & Rich")
  const title = transcript.title || '';
  Object.keys(KNOWN_PEOPLE).forEach(key => {
    if (title.toLowerCase().includes(key)) {
      participants.add(KNOWN_PEOPLE[key]);
    }
  });

  return Array.from(participants).slice(0, 10);
}

function extractTopics(transcript) {
  const topics = new Set();

  // From summary topics
  if (transcript.summary?.topics_discussed) {
    transcript.summary.topics_discussed.forEach(t => {
      if (t && t.length > 2 && t.length < 50) {
        topics.add(t);
      }
    });
  }

  // From keywords (select meaningful ones)
  if (transcript.summary?.keywords) {
    transcript.summary.keywords.slice(0, 5).forEach(k => {
      if (k && k.length > 2 && k.length < 30) {
        topics.add(k);
      }
    });
  }

  return Array.from(topics).slice(0, 8);
}

function buildYAMLFrontmatter(transcript) {
  const t = transcript;
  const dateStr = t.dateString || t.date || new Date().toISOString();
  const participants = extractParticipants(t);
  const topics = extractTopics(t);
  const meetingType = detectMeetingType(t.title, t.summary?.overview);

  let yaml = '---\n';
  yaml += `date: ${dateStr.split('T')[0]}\n`;
  yaml += `source: Fireflies AI\n`;
  yaml += `type: "${meetingType}"\n`;

  if (participants.length > 0) {
    yaml += `participants:\n`;
    participants.forEach(p => {
      yaml += `  - "${p}"\n`;
    });
  }

  if (topics.length > 0) {
    yaml += `topics:\n`;
    topics.forEach(topic => {
      yaml += `  - "${topic.replace(/"/g, '\\"')}"\n`;
    });
  }

  if (t.duration) {
    yaml += `duration: ${formatDuration(t.duration)}\n`;
  }

  if (t.transcript_url) {
    yaml += `url: "${t.transcript_url}"\n`;
  }

  yaml += '---\n\n';
  return yaml;
}

function buildMarkdown(transcript) {
  const t = transcript;

  // Start with YAML frontmatter
  let md = buildYAMLFrontmatter(t);

  md += `# ${t.title || 'Untitled Meeting'}\n\n`;

  // Metadata block
  md += `> **Date:** ${t.dateString || t.date || 'Unknown'}\n`;
  md += `> **Source:** Fireflies AI\n`;
  md += `> **Duration:** ${formatDuration(t.duration)}\n`;

  if (t.host_email) {
    md += `> **Host:** ${t.host_email}\n`;
  }

  // Participants
  if (t.meeting_attendees && t.meeting_attendees.length > 0) {
    const names = t.meeting_attendees
      .map(a => a.displayName || a.name || a.email || 'Unknown')
      .filter(n => n && n !== 'Unknown')
      .slice(0, 20)
      .join(', ');
    if (names) {
      md += `> **Participants:** ${names}\n`;
    }
  } else if (t.speakers && t.speakers.length > 0) {
    const names = t.speakers
      .map(s => s.name)
      .filter(n => n)
      .join(', ');
    if (names) {
      md += `> **Speakers:** ${names}\n`;
    }
  }

  if (t.transcript_url) {
    md += `> **Report:** [View in Fireflies](${t.transcript_url})\n`;
  }

  md += `\n---\n\n`;

  // Summary
  if (t.summary) {
    if (t.summary.overview) {
      md += `## Summary\n\n${t.summary.overview}\n\n`;
    } else if (t.summary.short_summary) {
      md += `## Summary\n\n${t.summary.short_summary}\n\n`;
    }

    // Action Items
    if (t.summary.action_items && Array.isArray(t.summary.action_items) && t.summary.action_items.length > 0) {
      md += `## Action Items\n\n`;
      t.summary.action_items.forEach(item => {
        md += `- [ ] ${item}\n`;
      });
      md += '\n';
    }

    // Topics
    if (t.summary.topics_discussed && Array.isArray(t.summary.topics_discussed) && t.summary.topics_discussed.length > 0) {
      md += `## Topics Discussed\n\n`;
      t.summary.topics_discussed.forEach(topic => {
        md += `- ${topic}\n`;
      });
      md += '\n';
    }

    // Keywords
    if (t.summary.keywords && Array.isArray(t.summary.keywords) && t.summary.keywords.length > 0) {
      md += `## Keywords\n\n${t.summary.keywords.join(', ')}\n\n`;
    }
  }

  // Transcript
  if (t.sentences && t.sentences.length > 0) {
    md += `## Transcript\n\n`;

    let currentSpeaker = null;
    let currentText = [];

    t.sentences.forEach(sentence => {
      const speaker = sentence.speaker_name || 'Unknown';
      const text = sentence.text || '';

      if (speaker !== currentSpeaker) {
        // Flush previous speaker's text
        if (currentSpeaker && currentText.length > 0) {
          md += `**${currentSpeaker}:** ${currentText.join(' ')}\n\n`;
        }
        currentSpeaker = speaker;
        currentText = [text];
      } else {
        currentText.push(text);
      }
    });

    // Flush final speaker
    if (currentSpeaker && currentText.length > 0) {
      md += `**${currentSpeaker}:** ${currentText.join(' ')}\n\n`;
    }
  }

  md += `---\n*Downloaded from Fireflies AI: ${new Date().toISOString()}*\n`;

  return md;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

(async () => {
  console.log('\n========================================');
  console.log('  Fireflies AI Bulk Downloader');
  console.log('  (with auto-tagging)');
  console.log('========================================\n');

  // Ensure output directories exist
  [OUTPUT_DIR_SP, OUTPUT_DIR_LCP].forEach(d => {
    if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
  });

  // Phase 1: Fetch all transcript IDs
  console.log('Phase 1: Fetching transcript list...\n');

  const allTranscripts = [];
  let skip = 0;
  let hasMore = true;

  while (hasMore) {
    try {
      const response = await fetchTranscriptList(skip);

      if (response.errors) {
        console.log('API Error:', response.errors[0]?.message || JSON.stringify(response.errors));
        break;
      }

      const transcripts = response.data?.transcripts || [];

      if (transcripts.length === 0) {
        hasMore = false;
      } else {
        allTranscripts.push(...transcripts);
        console.log(`  Fetched ${transcripts.length} transcripts (total: ${allTranscripts.length})`);
        skip += transcripts.length;
        await sleep(300); // Rate limiting
      }

      // Safety limit
      if (skip > 2000) {
        console.log('  Reached safety limit (2000 transcripts)');
        break;
      }

    } catch (e) {
      console.log(`  Error fetching list: ${e.message}`);
      break;
    }
  }

  console.log(`\nFound ${allTranscripts.length} transcripts\n`);

  if (allTranscripts.length === 0) {
    console.log('No transcripts found. Check API key and date range.');
    return;
  }

  // Show sample
  console.log('Sample transcripts:');
  allTranscripts.slice(0, 10).forEach((t, i) => {
    const date = t.date ? new Date(t.date).toISOString().split('T')[0] : 'no date';
    console.log(`  ${i + 1}. ${(t.title || 'Untitled').substring(0, 50)} (${date})`);
  });
  console.log('');

  // Phase 2: Download each transcript
  console.log('Phase 2: Downloading full transcripts with auto-tagging...\n');

  let downloaded = 0, skipped = 0, errors = 0;

  for (let i = 0; i < allTranscripts.length; i++) {
    const t = allTranscripts[i];
    const progress = `[${i + 1}/${allTranscripts.length}]`;
    const title = t.title || 'Untitled';

    console.log(`${progress} ${title.substring(0, 55)}`);

    try {
      // Generate filename
      let dateStr = new Date().toISOString().split('T')[0];
      if (t.date) {
        try {
          const d = new Date(t.date);
          if (!isNaN(d.getTime())) dateStr = d.toISOString().split('T')[0];
        } catch (e) {}
      }

      const safeTitle = title
        .replace(/[\/\\:*?"<>|]/g, '-')
        .replace(/\s+/g, ' ')
        .substring(0, 50)
        .trim();

      const filename = `${dateStr} ${safeTitle}.md`;
      // Route to LCP or SP based on content (checked after full transcript fetch below)
      // Temporarily use SP; will re-route after fetching full transcript
      const filename_only = filename;
      let filepath = path.join(OUTPUT_DIR_SP, filename_only);

      // Skip if exists in either folder
      if (fs.existsSync(filepath) || fs.existsSync(path.join(OUTPUT_DIR_LCP, filename_only))) {
        console.log('   -> exists');
        skipped++;
        continue;
      }

      // Fetch full transcript
      const response = await fetchFullTranscript(t.id);

      if (response.errors) {
        console.log(`   -> API error: ${response.errors[0]?.message || 'Unknown'}`);
        errors++;
        continue;
      }

      const fullTranscript = response.data?.transcript;

      if (!fullTranscript) {

        console.log('   -> no data');
        errors++;
        continue;
      }

      // Route: attendee email first, keywords as fallback
      let outputDir = routeByAttendee(fullTranscript);
      if (outputDir === 'SKIP') { skipped++; continue; }
      if (!outputDir) outputDir = routeToFolder(fullTranscript);
      filepath = path.join(outputDir, filename_only);

      // Build and save markdown with tags
      const md = buildMarkdown(fullTranscript);
      fs.writeFileSync(filepath, md);
      console.log(`   -> saved (${outputDir.includes('Lockwood') ? 'LCP' : 'SP'})`);
      downloaded++;

      // Rate limiting - increased to avoid 429 errors
      await sleep(500);

    } catch (e) {
      console.log(`   -> error: ${e.message.substring(0, 50)}`);
      errors++;
    }
  }

  console.log('\n========================================');
  console.log('  Complete!');
  console.log(`  Downloaded: ${downloaded}`);
  console.log(`  Skipped (exists): ${skipped}`);
  console.log(`  Errors: ${errors}`);
  console.log(`  Saved to: SP → ${OUTPUT_DIR_SP} | LCP → ${OUTPUT_DIR_LCP}`);
  console.log('========================================\n');
})();
