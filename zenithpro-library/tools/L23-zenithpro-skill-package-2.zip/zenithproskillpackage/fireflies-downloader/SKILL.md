---
name: fireflies-downloader
description: Downloads meeting transcripts from Fireflies AI (SP team account) to ~/HQ/Zoom Meetings/. Auto-routes to Strategic Profits or Lockwood College Prep based on Google Calendar cross-reference. LaunchAgent runs nightly at 11pm.
---

# Fireflies AI Downloader

Downloads meeting transcripts, summaries, and action items from the SP Fireflies team account into `~/HQ/Zoom Meetings/`.

## Output Locations

```
~/HQ/Zoom Meetings/
  Strategic Profits/     â SP meetings (default)
  Lockwood College Prep/ â LCP meetings
  fireflies-sync.log     â nightly run log
  fireflies-sync-err.log â error log
```

## Routing Logic

1. **Calendar check (primary):** Cross-references meeting date against Harry's LCP and SP Google Calendars (Â±30 min window).
   - LCP calendar only â LCP folder
   - SP calendar only â SP folder
   - BOTH â falls through to keyword matching â defaults SP
   - NEITHER â **SKIP** (someone else's team meeting â Rich, Nicole, etc.)

2. **Keyword fallback:** If both calendars match, scans title/transcript for LCP keywords (college, SAT, ACT, tutoring, admissions, financial aid, scholarship, etc.). Defaults to SP.

3. **Deduplication:** Skips files that already exist in either output folder.

## LaunchAgent (Nightly 11pm)

```
~/Library/LaunchAgents/com.harry.fireflies-sync.plist
```

Check status:
```bash
launchctl list | grep fireflies-sync
```

Run manually:
```bash
node ~/.claude/skills/fireflies-downloader/references/bulk-download.js
```

## Date Range Override

```bash
MEETING_FROM_DATE='2026-01-01T00:00:00.000Z' \
MEETING_TO_DATE='2026-03-09T23:59:59.000Z' \
  node ~/.claude/skills/fireflies-downloader/references/bulk-download.js
```

## Ad-Hoc Calls (Fireflies Won't Auto-Join)

Fireflies auto-join only fires when there's a Zoom/Meet link in a Google Calendar invite. For unscheduled calls (Slack DM link, etc.):

**Option A â Invite the bot mid-call:** Add `ai@fireflies.ai` as a Zoom participant. It'll join and record regardless of calendar.

**Option B â Manual upload:** Record the call locally, then upload at `app.fireflies.ai` â Upload.

## Technical Details

- **API:** GraphQL at `https://api.fireflies.ai/graphql`
- **Auth:** Bearer token (API key hardcoded in bulk-download.js)
- **Account:** SP team account (downloads ALL team meetings â filtered by calendar cross-ref)
- **Pagination:** 50 per request, 500ms delay between requests
- **Calendar auth:** Google OAuth tokens in `~/.google-mcp-accounts/` (auto-refreshed by script)
- **Calendar window:** Â±30 min around meeting start time

## Requirements

- Node.js 18+
- Google OAuth tokens for `harry_at_lockwoodcollegeprep_com.json` and `harry_at_strategicprofits_com.json` in `~/.google-mcp-accounts/`
