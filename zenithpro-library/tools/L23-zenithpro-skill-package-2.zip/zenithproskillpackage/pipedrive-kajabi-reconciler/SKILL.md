---
name: pipedrive-kajabi-reconciler
description: Eliminates the duplicate data entry problem across Lockwood College Prep's Kajabi, PipeDrive, and Google Sheets stack. Takes a data export or paste from any of the three platforms and produces a master reconciliation showing what's in sync, what's missing, and what Christine needs to do to fix it â plus a Zapier workflow design that prevents the problem from recurring. Invoke when Andy suspects records are out of sync, when onboarding a new client into all three platforms, or when building the zero-duplication data infrastructure.
license: proprietary
metadata:
tags:
  - program/ctd
  - client/andy-lockwood
---
# PipeDrive-Kajabi Reconciler

Identifies every discrepancy between Lockwood College Prep's Kajabi, PipeDrive, and Google Sheets records â and produces both the one-time fix and the permanent automation to prevent it from happening again.

## Context

Andy's current data problem: a new client or lead enters at one or more of these points â Kajabi (workshop registration, email list), PipeDrive (sales pipeline), Google Sheets (manual tracking, contractor assignments). When someone becomes a client, data should flow to all three. When someone attends a workshop but does not buy, they should stay in PipeDrive as a nurture lead. When a contractor is assigned, that should be reflected in Sheets and PipeDrive.

Currently none of this is automated. Christine and Andy do it manually, data gets out of sync, leads fall through cracks, and duplicate entry consumes hours per week.

This skill does two things: reconciles what is broken now, and designs the Zapier automation that makes it self-maintaining going forward.

**Keywords:** data reconciliation, duplicate entry, PipeDrive, Kajabi, Google Sheets, Zapier, CRM sync, lead tracking, client onboarding, Christine, automation design, data hygiene, Lockwood College Prep

## Quick Start

1. Tell me which platform(s) you are starting from â paste a list of names/emails from PipeDrive, Kajabi, or Sheets (or all three)
2. Tell me what the records SHOULD look like when in sync (e.g., "every Kajabi buyer should be in PipeDrive as 'Client - Active'")
3. I run the reconciliation and produce the fix + automation design
4. Christine implements the one-time fix; Zapier handles it automatically going forward

You do not need a data export â even a rough list pasted into chat is enough to start the diagnosis.

## GUARDRAILS

- NEVER recommend deleting records to resolve discrepancies. Always add what is missing, never remove what is there.
- NEVER silently guess when a record appears in a conflicting state across platforms. Flag it explicitly for Andy's review: "This person appears to be in both Active Client and Completed â which is correct?"
- NEVER design Zap field mapping without knowing the target platform's column structure. If Andy's Google Sheets column headers are unknown, ask for them before producing the Zap design. Ask specifically: "Paste your Sheets column headers for the client roster tab."
- NEVER assume TextLine has a native Zapier integration. If TextLine integration is required, flag this and provide the workaround (TextLine API + Zapier Webhooks) alongside the standard Zap design.
- DO NOT produce a reconciliation table without a summary row showing total records checked, records in sync, records with gaps, and most common gap.
- Always calculate the time-savings case: "This automation eliminates approximately X hours of manual entry per month for Christine." Do not skip this calculation.
- Zap designs must be written so Christine can implement them without a call with Andy. Field mapping must be explicit.

## Core Workflow

### Step 1 â Define the Master Record Map

Before reconciling, establish what the "correct" state looks like for each record type:

**Prospect (attended workshop, did not buy)**
- Kajabi: tagged as [workshop name] + NOT tagged as client
- PipeDrive: in "Nurture" stage with last-contact date updated
- Sheets: should NOT be in client tracking sheet; should be in lead tracking sheet
- TextLine: opted in for follow-up sequence

**New Client (signed agreement, deposit paid)**
- Kajabi: tagged as "Active Client" + year (e.g., "Client 2026")
- PipeDrive: moved to "Active Clients" pipeline, deal closed-won
- Sheets: added to client roster with student name, grade, package, assigned contractor, start date
- TextLine: added to client broadcast list

**Active Client (in service)**
- All three platforms in sync on package type and contractor assignment
- PipeDrive: deal stage reflects current phase (Onboarding / In Progress / Essay Season / Applications Submitted)
- Sheets: contractor column populated, milestone dates filled in
- Kajabi: tagged with current service phase for any phase-specific email automation

**Completed Client (admitted, done)**
- PipeDrive: closed with outcome noted (where admitted)
- Sheets: completion date, schools admitted to (this is the testimonial data pipeline)
- Kajabi: tagged for alumni sequence

### Step 2 â Reconciliation Analysis

Take the data provided and run through each record:

| Name | Kajabi Status | PipeDrive Status | Sheets Status | Gap | Priority Fix |
|------|--------------|-----------------|--------------|-----|-------------|
| [Name] | [tag/status] | [stage] | [row status] | [what is missing or wrong] | [action] |

Summarize at the bottom:
- Total records checked: [N]
- Records fully in sync: [N]
- Records with gaps: [N]
- Most common gap: [e.g., "PipeDrive not updated after client signs"]
- Estimated time to fix manually: [N hours] vs. with Zapier automation: [N minutes, recurring]

### Step 3 â Zapier Workflow Design

Design the exact Zapier automation to prevent recurrence. Produce each Zap as a recipe in this format:

---

**ZAP 1 â Workshop Registration to PipeDrive**
Trigger: Kajabi â New Event Registration
Filter: Event name contains "Workshop" or "Presentation"
Action: PipeDrive â Create Person (if not exists) + Create Deal in "Workshop Lead" stage
Field mapping:
- PipeDrive Person Name = Kajabi registrant name
- PipeDrive Email = Kajabi registrant email
- PipeDrive Phone = Kajabi registrant phone (if captured)
- PipeDrive Deal Title = "[Name] - [Workshop Date]"
- PipeDrive Deal Stage = "Workshop Lead"
- PipeDrive Source = "Kajabi Workshop"

Result: Every workshop registrant is automatically in PipeDrive within minutes of signing up. Christine never enters these manually.

---

**ZAP 2 â New Client to All Platforms**
Trigger: PipeDrive â Deal Stage Changed to "Active Client"
Actions (in sequence):
1. Kajabi â Add Tag "Active Client" + current year to the contact
2. Google Sheets â Add Row to Client Roster sheet with: Name, Email, Phone, Package (from PipeDrive deal value/title), Start Date (today), Contractor (blank â Christine fills in), Grade (from PipeDrive custom field)
3. TextLine â Add contact to "Active Clients" broadcast group (via TextLine API or Zapier TextLine integration if available; if not, flag for Christine to add manually and note the workaround path)

Result: When Andy closes a deal in PipeDrive, the client appears in Kajabi and Sheets automatically. Christine only fills in the contractor assignment.

---

**ZAP 3 â Deal Stage Updates to Sheets**
Trigger: PipeDrive â Deal Stage Changed (for any Active Client deal)
Action: Google Sheets â Update Row matching deal ID or email
Field: Update "Current Phase" column with new PipeDrive stage name

Result: The Sheets client roster always reflects the current phase without Christine manually updating it.

---

**ZAP 4 â Completed Client to Alumni Tag**
Trigger: PipeDrive â Deal Stage Changed to "Completed" or "Closed Won - Admitted"
Actions:
1. Kajabi â Add Tag "Alumni [Year]", Remove Tag "Active Client"
2. Google Sheets â Update Completion Date and Schools Admitted To columns (from PipeDrive notes field)

Result: Completed clients automatically enter the alumni nurture sequence in Kajabi and the Sheets record is updated.

---

**ZAP 5 â Sheets Contractor Assignment Notification**
Trigger: Google Sheets â Row Updated (contractor column changed from blank to a name)
Action: Email or Slack notification to Andy â "[Student Name] assigned to [Contractor Name] in Sheets. PipeDrive: [link to deal]"

Result: Andy sees every contractor assignment without checking Sheets manually.

---

### Step 4 â One-Time Remediation Plan

For the records that are currently out of sync, produce a prioritized fix list:

**Priority 1 â Active clients missing from Sheets (revenue risk)**
[List each one + what to add]

**Priority 2 â Workshop leads not in PipeDrive (lead leakage)**
[List each one + suggested PipeDrive stage]

**Priority 3 â Completed clients not tagged in Kajabi (alumni sequence not triggering)**
[List each one + what tag to add]

**Estimated fix time:** [Christine should be able to complete this in X hours]

### Step 5 â Maintenance Protocol

After automation is live:

**Monthly audit (Christine, 20 min):**
- Pull PipeDrive "Active Clients" list
- Cross-check against Sheets client roster
- Flag any mismatches for Andy's review

**Quarterly audit (Andy, 30 min):**
- Confirm all Zaps are still running (check Zapier task history for errors)
- Confirm Kajabi tags are accurate (no "Active Client" tags on completed clients)
- Review Sheets for any manually-entered rows that did not come through Zapier (signals a gap in the automation)

## Output Format

Produce in four sections, in this order:
1. **MASTER RECORD MAP** â what each record type should look like across all three platforms
2. **RECONCILIATION TABLE** â current state of all provided records with gaps identified, plus summary row
3. **ZAP DESIGNS** â each Zap written as a recipe Christine can implement, with explicit field mapping
4. **REMEDIATION PLAN** â prioritized list of one-time fixes with estimated time to complete

## Operating Rules

- Never recommend deleting records to resolve discrepancies â always add what is missing.
- If TextLine does not have a native Zapier integration: flag this explicitly and provide the workaround (TextLine API + Zapier Webhooks).
- Zap designs are written so Christine can implement them. Field mapping must be explicit â no assumptions about what field names exist on either side.
- If Andy's Google Sheets structure is unknown: ask for column headers before designing Zap field mapping.
- Flag any data requiring Andy's judgment explicitly. Do not silently guess.
- Always calculate the time-savings case for the automation.

## When to Use This Skill

- Monthly data hygiene audit (run with Christine)
- Whenever Andy suspects a lead fell through the cracks
- Before any Boca Raton expansion â set up the automation stack correctly from day one
- When onboarding a new cohort of clients â reconcile before sending any automated communications
- When rebuilding or migrating any platform in the stack

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Recommend deleting records to resolve discrepancies | Always add what is missing |
| Design Zaps with assumed field names | Ask Christine for actual column headers first |
| Silently guess at data requiring Andy's judgment | Flag every judgment call explicitly |
| Use TextLine's non-existent Zapier integration | Flag the workaround (TextLine API + Webhooks) |
| Produce output without a time-savings case | Always calculate the automation payback |
| Ignore Kajabi tag accuracy on alumni | Trigger alumni sequences through correct tags |

## Before You Respond

- [ ] Do I have data from at least one of the three platforms?
- [ ] Do I know the Google Sheets column structure?
- [ ] Am I flagging judgment calls for Andy?
- [ ] Is the TextLine workaround noted if automation is needed?
- [ ] Have I calculated the time-savings?

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Anti-Patterns, Before You Respond, Version History (Gauntlet QA pass)
