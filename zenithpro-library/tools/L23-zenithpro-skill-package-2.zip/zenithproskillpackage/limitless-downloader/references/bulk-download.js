/**
 * Limitless AI Bulk Downloader
 *
 * Downloads all lifelogs from Limitless AI via REST API
 * Saves as Obsidian-compatible markdown files with YAML frontmatter tags
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

// Configuration
const API_KEY = 'YOUR_LIMITLESS_API_KEY';
const OUTPUT_DIR = '~/Documents/Obsidian/Archive-Brain/Limitless';
const API_BASE = 'api.limitless.ai';
const TIMEZONE = 'America/New_York';

// Convert a Date or ISO string to YYYY-MM-DD in Eastern time
function toLocalDate(input) {
  const d = input instanceof Date ? input : new Date(input);
  return d.toLocaleDateString('en-CA', { timeZone: TIMEZONE }); // en-CA gives YYYY-MM-DD
}

// Convert a Date or ISO string to YYYY-MM-DD HH:MM:SS in Eastern time
function toLocalDateTime(input) {
  const d = input instanceof Date ? input : new Date(input);
  const date = d.toLocaleDateString('en-CA', { timeZone: TIMEZONE });
  const time = d.toLocaleTimeString('en-GB', { timeZone: TIMEZONE, hour12: false });
  return `${date} ${time}`;
}

// Date range - can be overridden via environment variables
// MEETING_FROM_DATE and MEETING_TO_DATE for automated daily collection
const FROM_DATE = process.env.MEETING_FROM_DATE || '2026-01-01';
const TO_DATE = process.env.MEETING_TO_DATE || toLocalDate(new Date());

// Known team members for participant tagging
const KNOWN_PEOPLE = {
  'rich': 'Rich Schefren',
  'richard': 'Rich Schefren',
  'richard schefren': 'Rich Schefren',
  'nicole': 'Nicole M',
  'ashley': 'Ashley Shaw',
  'ashley shaw': 'Ashley Shaw',
  'michelle': 'Michelle Mattison',
  'tom': 'Tom Hammaker',
  'ben': 'Ben Thole',
  'jessica': 'Jessica Middlebrook',
  'joseph': 'Joseph Conrad',
  'katrine': 'Katrine',
  'irish': 'Irish Arenal',
  'jem': 'Jem Erroba'
};

// Recording type detection patterns
const RECORDING_TYPES = [
  { pattern: /zenithpro/i, type: 'ZenithPro Session' },
  { pattern: /zenith\s*mind/i, type: 'ZenithMind Session' },
  { pattern: /meeting|call|session/i, type: 'Meeting' },
  { pattern: /discussion|conversation/i, type: 'Discussion' },
  { pattern: /interview/i, type: 'Interview' },
  { pattern: /brainstorm/i, type: 'Brainstorm' },
  { pattern: /planning/i, type: 'Planning Session' },
  { pattern: /strategy/i, type: 'Strategy Session' },
  { pattern: /review/i, type: 'Review' },
  { pattern: /training|workshop/i, type: 'Training' }
];

function makeRequest(endpoint, params = {}) {
  return new Promise((resolve, reject) => {
    const queryString = new URLSearchParams(params).toString();
    const pathWithQuery = queryString ? `${endpoint}?${queryString}` : endpoint;

    const options = {
      hostname: API_BASE,
      path: pathWithQuery,
      method: 'GET',
      headers: {
        'X-API-Key': API_KEY,
        'Accept': 'application/json'
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          if (res.statusCode === 429) {
            reject(new Error('Rate limited - waiting...'));
            return;
          }
          if (res.statusCode !== 200) {
            reject(new Error(`HTTP ${res.statusCode}: ${data.substring(0, 200)}`));
            return;
          }
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error(`Parse error: ${data.substring(0, 200)}`));
        }
      });
    });

    req.on('error', reject);
    req.end();
  });
}

function formatDuration(seconds) {
  if (!seconds) return 'Unknown';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  if (mins > 60) {
    const hours = Math.floor(mins / 60);
    const remainMins = mins % 60;
    return `${hours}h ${remainMins}m`;
  }
  return `${mins}m ${secs}s`;
}

function detectRecordingType(title, content) {
  const text = `${title || ''} ${content || ''}`.toLowerCase();

  for (const rt of RECORDING_TYPES) {
    if (rt.pattern.test(text)) {
      return rt.type;
    }
  }
  return 'Recording';
}

function extractParticipants(lifelog) {
  const participants = new Set();

  // From title
  const title = lifelog.title || '';
  Object.keys(KNOWN_PEOPLE).forEach(key => {
    if (title.toLowerCase().includes(key)) {
      participants.add(KNOWN_PEOPLE[key]);
    }
  });

  // From content/transcript
  const content = lifelog.markdown || '';
  Object.keys(KNOWN_PEOPLE).forEach(key => {
    // Look for speaker patterns like "**Richard:**" or "Richard Schefren:"
    const speakerPattern = new RegExp(`\\*\\*${key}[^*]*\\*\\*:|${key}[^:]*:`, 'i');
    if (speakerPattern.test(content)) {
      participants.add(KNOWN_PEOPLE[key]);
    }
  });

  // From speakers array if present
  if (lifelog.speakers) {
    lifelog.speakers.forEach(s => {
      const name = s.name || s.speakerName || '';
      if (name) {
        const normalized = name.toLowerCase().trim();
        if (KNOWN_PEOPLE[normalized]) {
          participants.add(KNOWN_PEOPLE[normalized]);
        } else if (name.length > 1 && name !== 'Unknown') {
          participants.add(name.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' '));
        }
      }
    });
  }

  return Array.from(participants).slice(0, 10);
}

function extractTopicsFromContent(content) {
  const topics = new Set();

  if (!content) return [];

  // Look for headings (## or ###)
  const headingMatches = content.match(/^#{2,3}\s+(.+)$/gm);
  if (headingMatches) {
    headingMatches.forEach(h => {
      const topic = h.replace(/^#+\s*/, '').trim();
      if (topic.length > 3 && topic.length < 60 && !topic.toLowerCase().includes('transcript')) {
        topics.add(topic);
      }
    });
  }

  // Look for bullet points that might be topics
  const bulletMatches = content.match(/^[-*]\s+(.{10,50})$/gm);
  if (bulletMatches) {
    bulletMatches.slice(0, 5).forEach(b => {
      const topic = b.replace(/^[-*]\s*/, '').trim();
      if (topic.length > 5 && topic.length < 50) {
        topics.add(topic);
      }
    });
  }

  return Array.from(topics).slice(0, 6);
}

function buildYAMLFrontmatter(lifelog) {
  const startTime = lifelog.startTime || lifelog.start_time;
  const endTime = lifelog.endTime || lifelog.end_time;

  let dateStr = toLocalDate(new Date());
  if (startTime) {
    try {
      dateStr = toLocalDate(startTime);
    } catch (e) {}
  }

  const participants = extractParticipants(lifelog);
  const topics = extractTopicsFromContent(lifelog.markdown || lifelog.summary || '');
  const recordingType = detectRecordingType(lifelog.title, lifelog.markdown);

  let duration = null;
  if (startTime && endTime) {
    duration = (new Date(endTime) - new Date(startTime)) / 1000;
  }

  let yaml = '---\n';
  yaml += `date: ${dateStr}\n`;
  yaml += `source: Limitless AI\n`;
  yaml += `type: "${recordingType}"\n`;

  if (participants.length > 0) {
    yaml += `participants:\n`;
    participants.forEach(p => {
      yaml += `  - "${p}"\n`;
    });
  }

  if (topics.length > 0) {
    yaml += `topics:\n`;
    topics.forEach(topic => {
      yaml += `  - "${topic.replace(/"/g, '\\"')}"\n`;
    });
  }

  if (duration) {
    yaml += `duration: ${formatDuration(duration)}\n`;
  }

  if (lifelog.id) {
    yaml += `id: "${lifelog.id}"\n`;
  }

  yaml += '---\n\n';
  return yaml;
}

function buildMarkdown(lifelog) {
  const l = lifelog;

  // Start with YAML frontmatter
  let md = buildYAMLFrontmatter(l);

  md += `# ${l.title || 'Untitled Lifelog'}\n\n`;

  // Metadata
  const startTime = l.startTime || l.start_time;
  const endTime = l.endTime || l.end_time;

  let dateStr = 'Unknown';
  if (startTime) {
    try {
      dateStr = toLocalDateTime(startTime);
    } catch (e) {}
  }

  md += `> **Date:** ${dateStr}\n`;
  md += `> **Source:** Limitless AI\n`;

  if (startTime && endTime) {
    const duration = (new Date(endTime) - new Date(startTime)) / 1000;
    md += `> **Duration:** ${formatDuration(duration)}\n`;
  }

  if (l.id) {
    md += `> **ID:** ${l.id}\n`;
  }

  md += `\n---\n\n`;

  // Summary/Contents
  if (l.summary) {
    md += `## Summary\n\n${l.summary}\n\n`;
  }

  // Markdown content (primary content field)
  if (l.markdown) {
    md += `## Content\n\n${l.markdown}\n\n`;
  } else if (l.contents && Array.isArray(l.contents)) {
    md += `## Content\n\n`;
    l.contents.forEach(content => {
      if (content.type === 'heading1') {
        md += `# ${content.content || ''}\n\n`;
      } else if (content.type === 'heading2') {
        md += `## ${content.content || ''}\n\n`;
      } else if (content.type === 'heading3') {
        md += `### ${content.content || ''}\n\n`;
      } else if (content.type === 'blockquote') {
        md += `> ${content.content || ''}\n\n`;
      } else if (content.type === 'bullet') {
        md += `- ${content.content || ''}\n`;
      } else if (content.speakerName || content.speaker_name) {
        const speaker = content.speakerName || content.speaker_name || 'Speaker';
        const text = content.content || content.text || '';
        md += `**${speaker}:** ${text}\n\n`;
      } else if (content.content) {
        md += `${content.content}\n\n`;
      }
    });
  }

  // Action items
  if (l.actionItems && l.actionItems.length > 0) {
    md += `## Action Items\n\n`;
    l.actionItems.forEach(item => {
      md += `- [ ] ${item.text || item.content || item}\n`;
    });
    md += '\n';
  }

  // Transcript
  if (l.transcript && Array.isArray(l.transcript)) {
    md += `## Transcript\n\n`;
    l.transcript.forEach(line => {
      const speaker = line.speakerName || line.speaker_name || line.speaker || '';
      const text = line.text || line.content || '';
      if (speaker) {
        md += `**${speaker}:** ${text}\n\n`;
      } else if (text) {
        md += `${text}\n\n`;
      }
    });
  }

  md += `---\n*Downloaded from Limitless AI: ${new Date().toISOString()}*\n`;

  return md;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

(async () => {
  console.log('\n========================================');
  console.log('  Limitless AI Bulk Downloader');
  console.log('  (with auto-tagging)');
  console.log('========================================\n');

  // Ensure output directory exists
  if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  }

  // Phase 1: Fetch lifelogs for date range
  console.log(`Phase 1: Fetching lifelogs from ${FROM_DATE} to ${TO_DATE}...\n`);

  const allLifelogs = [];
  let cursor = null;
  let pageNum = 1;

  while (true) {
    try {
      const params = {
        date: FROM_DATE,
        timezone: 'America/New_York',
        limit: 50,
        direction: 'asc',
        include_markdown: true,
        include_headings: true
      };

      if (cursor) {
        params.cursor = cursor;
      }

      const response = await makeRequest('/v1/lifelogs', params);

      if (response.data && response.data.lifelogs && response.data.lifelogs.length > 0) {
        // Filter by date range
        const filtered = response.data.lifelogs.filter(l => {
          const startTime = l.startTime || l.start_time;
          if (!startTime) return true;
          const date = startTime.split('T')[0];
          return date >= FROM_DATE && date <= TO_DATE;
        });

        allLifelogs.push(...filtered);
        console.log(`  Page ${pageNum}: Found ${response.data.lifelogs.length} lifelogs, ${filtered.length} in range (total: ${allLifelogs.length})`);

        // Check for more pages
        if (response.meta && response.meta.lifelogs && response.meta.lifelogs.nextCursor) {
          cursor = response.meta.lifelogs.nextCursor;
        } else {
          break;
        }
      } else {
        break;
      }

      pageNum++;
      await sleep(350); // Rate limiting (180 req/min = ~333ms between requests)

      // Safety limit
      if (pageNum > 100) {
        console.log('  Reached page limit (100)');
        break;
      }

    } catch (e) {
      if (e.message.includes('Rate limited')) {
        console.log('  Rate limited, waiting 10 seconds...');
        await sleep(10000);
        continue;
      }
      console.log(`  Error on page ${pageNum}: ${e.message}`);
      break;
    }
  }

  // Also try fetching by iterating through each date in range
  console.log('\n  Checking each date in range...');
  const startDate = new Date(FROM_DATE);
  const endDate = new Date(TO_DATE);

  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
    const dateStr = d.toISOString().split('T')[0];

    try {
      const params = {
        date: dateStr,
        timezone: 'America/New_York',
        limit: 50,
        include_markdown: true,
        include_headings: true
      };

      const response = await makeRequest('/v1/lifelogs', params);

      if (response.data && response.data.lifelogs && response.data.lifelogs.length > 0) {
        // Add any new lifelogs not already in our list
        const existingIds = new Set(allLifelogs.map(l => l.id));
        const newLogs = response.data.lifelogs.filter(l => !existingIds.has(l.id));

        if (newLogs.length > 0) {
          allLifelogs.push(...newLogs);
          console.log(`  ${dateStr}: Found ${newLogs.length} new lifelogs (total: ${allLifelogs.length})`);
        }
      }

      await sleep(350);

    } catch (e) {
      if (e.message.includes('Rate limited')) {
        console.log('  Rate limited, waiting 10 seconds...');
        await sleep(10000);
        d.setDate(d.getDate() - 1); // Retry this date
        continue;
      }
      // Skip errors for individual dates
    }
  }

  console.log(`\nFound ${allLifelogs.length} total lifelogs for 2026\n`);

  if (allLifelogs.length === 0) {
    console.log('No lifelogs found. Check API key and date range.');
    console.log('Note: Limitless API only returns data recorded via the Pendant.');
    return;
  }

  // Show sample
  console.log('Sample lifelogs:');
  allLifelogs.slice(0, 10).forEach((l, i) => {
    const startTime = l.startTime || l.start_time;
    const date = startTime ? startTime.split('T')[0] : 'no date';
    console.log(`  ${i + 1}. ${(l.title || 'Untitled').substring(0, 50)} (${date})`);
  });
  console.log('');

  // Phase 2: Save each lifelog
  console.log('Phase 2: Saving lifelogs with auto-tagging...\n');

  let downloaded = 0, skipped = 0, errors = 0;

  for (let i = 0; i < allLifelogs.length; i++) {
    const l = allLifelogs[i];
    const progress = `[${i + 1}/${allLifelogs.length}]`;
    const title = l.title || 'Untitled';

    console.log(`${progress} ${title.substring(0, 55)}`);

    try {
      // Generate filename
      const startTime = l.startTime || l.start_time;
      let dateStr = toLocalDate(new Date());
      if (startTime) {
        try {
          const d = new Date(startTime);
          if (!isNaN(d.getTime())) dateStr = toLocalDate(d);
        } catch (e) {}
      }

      const safeTitle = title
        .replace(/[\/\\:*?"<>|]/g, '-')
        .replace(/\s+/g, ' ')
        .substring(0, 50)
        .trim();

      const filename = `${dateStr} ${safeTitle} (Limitless).md`;
      const filepath = path.join(OUTPUT_DIR, filename);

      // Skip if exists
      if (fs.existsSync(filepath)) {
        console.log('   -> exists');
        skipped++;
        continue;
      }

      // Build and save markdown with tags
      const md = buildMarkdown(l);
      fs.writeFileSync(filepath, md);
      console.log('   -> saved');
      downloaded++;

    } catch (e) {
      console.log(`   -> error: ${e.message.substring(0, 50)}`);
      errors++;
    }
  }

  console.log('\n========================================');
  console.log('  Complete!');
  console.log(`  Downloaded: ${downloaded}`);
  console.log(`  Skipped (exists): ${skipped}`);
  console.log(`  Errors: ${errors}`);
  console.log(`  Saved to: ${OUTPUT_DIR}`);
  console.log('========================================\n');
})();
