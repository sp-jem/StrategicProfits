#!/bin/bash
# Limitless continuous sync â checks last 2 days every 30 minutes
# Runs the bulk downloader with a narrow date window so it's fast

export MEETING_FROM_DATE=$(date -v-1d +%Y-%m-%d)
export MEETING_TO_DATE=$(date +%Y-%m-%d)

/usr/local/bin/node ~/.claude/skills/limitless-downloader/references/bulk-download.js
