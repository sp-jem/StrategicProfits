---
name: limitless-downloader
description: Downloads meeting transcripts from Limitless AI (Pendant) to Obsidian via REST API. Bulk download all historical lifelogs with full transcripts, summaries, and action items. Part of the Second Brain automated meeting collection system.
---

# Limitless AI Downloader

Downloads meeting transcripts, lifelogs, and summaries from Limitless AI (Pendant) into your Obsidian vault.

## Features

- **Bulk Download**: Fetch all historical lifelogs via Limitless REST API
- **Daily Automation**: Integrates with SecondBrainMeetings.app for daily collection
- **Full Transcripts**: Speaker-attributed conversation text
- **AI Summaries**: Overview, action items, and structured content
- **Smart Deduplication**: Skips already-downloaded files

## Automated Daily Collection

This skill is automatically run daily at 6:30 AM by `SecondBrainMeetings.app` to pull yesterday's pendant recordings. The recordings are then included in the 7 AM daily digest.

**Related Components:**
- `SecondBrainMeetings.app` - Orchestrates all meeting downloaders
- `SecondBrainDigest.app` - Includes meetings in daily digest
- `SecondBrainEvaluator.app` - Validates meeting downloads

## Usage

### Bulk Download Historical Lifelogs

```bash
node ~/.claude/skills/limitless-downloader/references/bulk-download.js
```

### Download Specific Date Range (Automated)

The script accepts environment variables for date filtering:

```bash
MEETING_FROM_DATE='2026-01-17' MEETING_TO_DATE='2026-01-17' \
  node ~/.claude/skills/limitless-downloader/references/bulk-download.js
```

**Note:** Limitless uses `YYYY-MM-DD` format (not ISO timestamps like Fireflies/Read AI).

### Configuration

Edit `references/bulk-download.js` to change defaults:

```javascript
const API_KEY = 'your-api-key-here';
const OUTPUT_DIR = '/path/to/your/meetings/folder';
// Date range can be overridden via MEETING_FROM_DATE and MEETING_TO_DATE env vars
const FROM_DATE = process.env.MEETING_FROM_DATE || '2026-01-01';
const TO_DATE = process.env.MEETING_TO_DATE || new Date().toISOString().split('T')[0];
```

## Output Location

Default save location:
```
~/Documents/Obsidian/YOUR-OBSIDIAN-VAULT/01 Strategic Profits/2026 Meetings/Pendant Recordings/
```

**Filename format:** `YYYY-MM-DD Meeting Title (Limitless).md`

**Note:** Limitless pendant recordings go into `Pendant Recordings/` subfolder. Scheduled meetings from Fireflies and Read AI go into `Scheduled Meetings/`.

## Output Format

Each lifelog is saved as Obsidian-compatible markdown:

```markdown
# Meeting Title

> **Date:** 2026-01-15 14:30:00
> **Source:** Limitless AI
> **Duration:** 45m 30s
> **ID:** abc123

---

## Summary
[AI-generated meeting summary]

## Content
[Structured content with headings, bullets, quotes]

## Action Items
- [ ] Action item 1
- [ ] Action item 2

## Transcript
**Speaker 1:** What they said...

**Speaker 2:** Response...

---
*Downloaded from Limitless AI: 2026-01-18T15:45:00.000Z*
```

## API Details

- **Endpoint**: `https://api.limitless.ai/v1/lifelogs`
- **Auth**: API key via `X-API-Key` header
- **Rate Limit**: 180 requests/minute
- **Pagination**: Uses cursor-based pagination

## Getting Your API Key

1. Go to https://app.limitless.ai
2. Click "Create API Key" in the top right corner
3. Copy the key (format: `sk-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`)

## Requirements

- Node.js 18+
- Limitless AI account with Pendant
- API key from Limitless dashboard

## Notes

- The Limitless API only returns data recorded via the Pendant
- Large requests may timeout; the script handles pagination automatically
- Rate limiting is built-in (350ms between requests)
