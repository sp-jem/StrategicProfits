# Setup Required â Limitless AI Downloader

Downloads recordings from your Limitless AI Pendant to Obsidian.

## To configure:

1. Get your Limitless API key: limitless.ai â Settings â API
2. Open `references/bulk-download.js`
3. Replace `YOUR_LIMITLESS_API_KEY` with your key
4. Update the output path to your Obsidian vault

## Requirements:
- Node.js installed
- Limitless AI Pendant device
