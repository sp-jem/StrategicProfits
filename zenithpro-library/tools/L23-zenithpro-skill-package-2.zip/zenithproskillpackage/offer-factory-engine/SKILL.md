# Offer Factory: Offer Engine

---
name: offer-factory-engine
description: "Use when you want a flood of creative offer ideas from Rich's existing product components. Supports multiple generation modes."
---

## Purpose

This is the creative engine. It takes what you HAVE (product components, existing offers) and shows you what you COULD have by systematically combining structural patterns, creative lenses, and cross-industry thinking. The goal is volume and novelty â generating ideas you would never arrive at by thinking about your products the way you normally do.

---

## CRITICAL: Anti-Mode-Collapse Protocol (Verbalized Sampling)

**Based on:** Zhang et al. (2025), "Verbalized Sampling: How to Mitigate Mode Collapse and Unlock LLM Diversity" â https://arxiv.org/html/2510.01171v3

After RLHF alignment, LLMs lose 30-50% of their generative diversity. They converge on the single highest-probability (safest, most conventional) response. This is called **mode collapse** â and it is the OPPOSITE of what the Offer Factory needs. The Engine uses **Verbalized Sampling (VS)** to recover suppressed diversity.

### The VS-CoT Technique

For EVERY generation step in EVERY mode, use the **VS-CoT (Chain of Thought) variant:**

**Step A â Reason about the problem space first.** Before generating any candidates, think step-by-step about what dimensions of the problem exist, what categories of solution are possible, and what conceptual territories are available. This prevents the model from collapsing to the first idea that comes to mind.

**Step B â Generate k=5 candidates with explicit probability tags.** For each pattern application, each constraint response, each creator lens â generate 5 distinct options. For each, state the probability that a typical AI would generate this idea:

```
<candidate>
<text>[Offer concept description]</text>
<probability>0.XX</probability>
</candidate>
```

**Step C â Apply the diversity filter.**
- Flag any candidate with probability > 0.60 as **OBVIOUS** â include it for completeness but do not let it dominate
- REQUIRE at least 2 candidates with probability < 0.20 â these are the **non-obvious ideas** the system exists to surface
- If all 5 candidates are above 0.30, the generation has collapsed â **regenerate from a different conceptual starting point**

### Mandatory Rules (Every Mode, Every Step)

1. **VS-CoT is non-negotiable.** Never generate a single idea per slot. Always 5 candidates with probability tags. Always reason about the space first.

2. **Prioritize low-probability candidates.** The ideas that feel weird, impractical, or counterintuitive are the ones this system exists to surface. Score them HIGHER on novelty, not lower. A candidate at p=0.05 that is feasible is worth more than a candidate at p=0.70 that is obvious.

3. **The "Would Anyone Else Think of This?" Test.** Before finalizing any idea, ask: "If 10 other AI systems were given this same prompt, would more than 2 of them generate this same idea?" If yes, it's too obvious â push further.

4. **Forced diversity across batches.** In any batch of 10+ ideas, at least 30% must come from a different conceptual space than the majority. If 7 out of 10 ideas involve "add a lower price tier," the engine has collapsed â regenerate until diversity is restored.

5. **Second-order pass (mandatory).** After the first generation pass, run a second pass: "What ideas did I NOT generate because they seemed too weird, impractical, or risky?" Generate those explicitly. This recovers ideas suppressed by alignment training.

6. **Temperature is not a substitute.** VS gains are orthogonal to temperature settings â VS at temperature 0.7 outperforms plain generation at temperature 1.5 on diversity metrics. Do not rely on temperature alone for creativity.

7. **Full candidate visibility.** The output document must include ALL k=5 candidates for every generation slot â not just the winner. Organize as: selected candidate (highlighted) + 4 alternates (collapsed under "Other candidates considered"). This lets Rich browse the full creative space and potentially select a candidate the system ranked lower. The Engine's job is to GENERATE â Rich's job is to SELECT.

### Diversity Tuning Parameter

The probability threshold controls the diversity level of the final output:
- **High diversity (threshold < 0.10):** Select only candidates the model rates as very unlikely. Use for maximum novelty â Inversion Mode, Constraint Mode.
- **Medium diversity (threshold < 0.20):** Balanced selection. Use for most modes â Pattern Sweep, Cross-Pollination, Creator Lens.
- **Targeted diversity (threshold < 0.30):** Closer to conventional but still filtered. Use for Component Remix where feasibility matters more.

### Why This Matters

Without VS, the Offer Factory produces 30 variations of the 3-4 most obvious ideas. The model's alignment training actively suppresses the weird, novel, counterintuitive ideas that are the entire point of a creative engine. VS recovers 66.8% of the diversity lost during alignment â turning "30 variations of obvious" into "30 ideas spanning 15 different conceptual territories."

The entire value proposition is in the non-obvious 20% â the ideas that make Rich say "I never would have thought of that."

## Invocation

```
/offer-factory-engine [mode] [product(s)] [optional constraints]
```

**Examples:**
```
/offer-factory-engine pattern-sweep ZenithPro
/offer-factory-engine cross-pollinate SOW with retail patterns
/offer-factory-engine remix ZenithPro + SOW + Force Multiplier
/offer-factory-engine creator-lens "What would Popeil do with Connect the Dots?"
/offer-factory-engine constraint "Design an offer that costs $0 to fulfill"
/offer-factory-engine inversion ZenithPro
/offer-factory-engine full-run all products
```

---

## Input Requirements

**Required:**
- At least one product name OR "all products"
- A mode selection (or "full-run" for all modes)

**Strongly recommended:**
- Product Component Inventories (`Offer Factory/Product Components/`)
- Cross-Product Synthesis (`Offer Factory/Cross-Product Map/`)
- Existing Offer Autopsies (`Offer Factory/Autopsies/`)

**If component inventories don't exist yet:** The Engine will work from whatever product knowledge is available (product registry, vault search, general knowledge), but output will be less specific. Flag this and recommend running the Decomposer first.

---

## Context Parameters (Optional)

These parameters shape what the Engine generates. When provided, every mode factors them into concept generation.

| Parameter | Description | Example |
|-----------|-------------|---------|
| `currently_selling` | What product/offer Rich is actively selling right now | `"Connect the Dots"` |
| `priority` | What to optimize for | `new-products` (default), `support-active-sales`, or `portfolio-gaps` |
| `sales_context` | Brief description of current sales situation | `"CTD selling via webinar, $5K, backend is Maximum Profit at $50K/yr"` |

**How context parameters affect generation:**

- **`currently_selling`** â When set, the Engine weights concepts that support, enhance, or complement the active sales effort. This doesn't replace normal generation â it adds a bias toward ideas that make the current offer ecosystem stronger.
- **`priority: support-active-sales`** â Shifts all modes toward generating concepts that feed into, amplify, or extend what's currently being sold. Pattern Sweep looks for patterns that strengthen the active offer. Cross-Pollination imports patterns that enhance the sales motion. Creator Lens asks "how would [Creator] make this current offer sell better?"
- **`priority: portfolio-gaps`** â Shifts all modes toward identifying structural holes in the product lineup (missing price points, unserved segments, missing delivery formats, etc.).
- **`priority: new-products`** â Default behavior. Maximum novelty, no bias toward existing offers.

**Mode-level rule:** If `currently_selling` is set, generate at least 5 concepts per mode specifically designed to support/enhance/complement that active offer. These go into the "Support Active Sales" category in the output.

---

## The 6 Modes

### Mode 1: Pattern Sweep

Run ONE product through ALL 30 structural patterns AND all 20 tactical patterns. For structural patterns, generate new offer concepts. For tactical patterns, generate concepts that modify/improve existing offers, not just create new ones.

**Process:**
1. Load the product's component inventory
2. Load its Offer Autopsy (if exists) to know which patterns are already in play
3. For each of the 30 structural patterns:
   - Skip patterns already rated STRONG in the Autopsy
   - Generate a specific, concrete offer concept that applies this pattern to this product
   - Rate: Novelty (1-5), Feasibility (1-5), Revenue Potential (1-5)
4. For each of the 20 tactical patterns:
   - Generate a specific concept that applies this tactical modification to the product's current or proposed offer
   - Rate: Novelty (1-5), Feasibility (1-5), Revenue Potential (1-5)
5. If `currently_selling` is set, generate at least 5 concepts specifically designed to support/enhance/complement that active offer
6. Rank all 50 concepts by combined score
7. Highlight the top 5 with expanded descriptions

**Output:** 50 concepts ranked, top 5 expanded.

### Mode 2: Cross-Pollination

Take patterns dominant in OTHER industries and apply them to Rich's products.

**Process:**
1. Identify the industry/category Rich's product lives in (info-marketing, coaching, online education)
2. From the 30 patterns, identify which are COMMON in that industry vs. RARE
3. From the 55 creators, identify which are from OUTSIDE that industry
4. For each rare pattern, generate an offer concept that imports it:
   - "What does membership gating (Costco) look like for SOW?"
   - "What does demo-as-offer (Popeil) look like for ZenithPro?"
   - "What does subscription curation (Birchbox) look like for Maximum Profit?"
5. Score each for novelty and feasibility
6. Highlight concepts where the cross-industry pattern creates genuine competitive advantage (not just novelty for its own sake)
7. If `currently_selling` is set, generate at least 5 concepts specifically designed to support/enhance/complement that active offer

**Output:** 15-20 cross-pollinated concepts, ranked by competitive advantage potential.

### Mode 3: Component Remix

Pull specific components from DIFFERENT products and combine them into something new.

**Process:**
1. Load ALL product component inventories
2. Load Cross-Product Synthesis (especially the Natural Pairings and Amplification Pairs)
3. Generate combinations:
   - **2-product combos:** Take 1 high-value component from Product A + 1 from Product B â new offer
   - **3-product combos:** Take components from 3 different products â new offer
   - **Orphan rescue:** Take underleveraged components from multiple products â new offer built from pieces nobody is using fully
4. For each combination:
   - Name it
   - Describe it (what the buyer gets)
   - Identify the target buyer (who wants THIS specific combination)
   - Rate: standalone value, novelty, overlap with existing offers
5. Rank by value creation (does the combination create something greater than the sum of parts?)
6. If `currently_selling` is set, generate at least 5 concepts specifically designed to support/enhance/complement that active offer

**Output:** 20-30 remix concepts, grouped by combination type.

### Mode 4: Creator Lens

Think LIKE a specific creator about Rich's products.

**Process:**
1. Select creator(s) â either specified by user or auto-selected for maximum contrast with current approach
2. Load that creator's profile from the Master List (`06 - Greatest Offer Creators of All Time - Master List.md`)
3. For each creator, answer:
   - "If [Creator] were rebuilding this product from scratch, what would the offer look like?"
   - "What would [Creator] add that Rich hasn't?"
   - "What would [Creator] remove that Rich considers essential?"
   - "What would [Creator] price it at and why?"
   - "What delivery mechanism would [Creator] use?"
4. Generate 3-5 specific offer concepts per creator
5. Flag concepts that are genuinely different from anything in the current portfolio
6. If `currently_selling` is set, generate at least 5 concepts specifically designed to support/enhance/complement that active offer

**Recommended Creator Contrasts:**
| Creator | Why They'd See It Differently |
|---------|------------------------------|
| **Popeil** | Would make it demo-driven, simplify to one repeatable action |
| **Disney** | Would build an ecosystem where each piece sells the next |
| **Bezos** | Would design for maximum lock-in and recurring behavior |
| **Ford** | Would ask "how do we make this 10x cheaper and serve 100x more people?" |
| **Robbins** | Would make the experience itself the transformation |
| **Hormozi** | Would restructure the value equation â more outcome, less effort |
| **Kennedy** | Would package it as tools, not education |
| **Brunson** | Would build a value ladder with a $7 entry point |
| **Kern** | Would give away the best parts free and sell implementation |
| **Walker** | Would launch it as a sequence that builds anticipation |
| **Yunus** | Would ask "how do we serve the people who can't afford this at all?" |
| **Lauder** | Would add gift-with-purchase and loyalty mechanics |
| **Costco** | Would strip margins and make money on membership, not products |
| **Sackheim** | Would restructure defaults â what happens if you do nothing? |
| **Levesque** | Would hyper-personalize â different offer for every buyer segment |
| **Abraham** | Would find hidden assets and monetize what's being given away free |
| **Nicholas** | Would own the full value chain from education to implementation to tools |
| **Scherman** | Would use negative option â you're in unless you opt out |
| **Phillips** | Would make it a challenge with a deadline and public accountability |
| **Belcher** | Would package it as a toolkit with physical components |
| **Holmes** | Would sell it through education-as-sales â teach, then offer the shortcut |
| **Branson** | Would extend the brand into adjacent categories |
| **Burchard** | Would add certification â buyers become licensed practitioners |
| **Tesla/Kickstarter** | Would pre-sell before building â validate with capital, not surveys |

**Output:** 3-5 concepts per creator lens, with the creator's logic explained.

### Mode 5: Constraint Mode

Impose artificial constraints that force genuinely novel thinking.

**Pre-Built Constraints:**
1. "Design an offer that costs $0 to fulfill"
2. "Design an offer with no sales page"
3. "Design an offer that gets MORE valuable the more people buy it"
4. "Design an offer the buyer can resell"
5. "Design an offer that takes less than 5 minutes to deliver"
6. "Design an offer where the buyer does the work and you provide the structure"
7. "Design an offer that requires no new content creation"
8. "Design an offer where the price goes UP, not down, over time"
9. "Design an offer that can only be bought by referral"
10. "Design an offer that solves the problem BEFORE the buyer pays"
11. "Design an offer at $50,000+"
12. "Design an offer a competitor could never copy"
13. "Design an offer that takes 12 months to deliver but creates value in 24 hours"
14. "Design an offer where AI does 90% of the fulfillment"
15. "Design an offer that turns a customer into a partner"

**Process:**
1. Select constraint (user-specified or random)
2. Load relevant product components
3. Force-generate 5 concepts that genuinely satisfy the constraint (not loopholes)
4. For each, explain HOW it satisfies the constraint and WHY the constraint led to something you wouldn't otherwise create
5. Rate: novelty, feasibility, revenue potential, constraint satisfaction
6. If `currently_selling` is set, generate at least 5 concepts specifically designed to support/enhance/complement that active offer

**Output:** 5 constrained concepts per constraint, with constraint logic explained.

### Mode 6: Inversion Mode

Flip assumptions. What's the opposite of what you're doing?

**Process:**
1. Load current offer structure for the product
2. List every assumption baked into the current offer:
   - Price assumption (e.g., "high-ticket")
   - Delivery assumption (e.g., "live calls + recorded lessons")
   - Audience assumption (e.g., "established entrepreneurs")
   - Timeline assumption (e.g., "multi-month program")
   - Access assumption (e.g., "Rich teaches it")
   - Packaging assumption (e.g., "comprehensive program")
3. For each assumption, INVERT it:
   - High-ticket â $27
   - Live calls â fully automated
   - Established â beginners
   - Multi-month â 1 day
   - Rich teaches â community teaches each other
   - Comprehensive â one single thing
4. For each inversion, generate a concrete offer concept
5. Score: Which inversions create genuinely interesting offers vs. which just create worse versions?
6. If `currently_selling` is set, generate at least 5 concepts specifically designed to support/enhance/complement that active offer

**Output:** One concept per assumption inversion, scored for viability.

---

## Full-Run Mode

When invoked with `full-run`, the Engine runs ALL 6 modes against the specified product(s) and produces a consolidated output:

1. Pattern Sweep (50 concepts â 30 structural + 20 tactical)
2. Cross-Pollination (15-20 concepts)
3. Component Remix (20-30 concepts)
4. Creator Lens â auto-select 15 highest-contrast creators (45-75 concepts)
5. Constraint Mode â run 5 random constraints (25 concepts)
6. Inversion Mode (8-12 concepts)

**Total: 140-200+ concepts per full run**

Then consolidate:
- Remove duplicates and near-duplicates
- Cluster similar concepts into categories (see Document Structure below)
- Keep ALL concepts organized by use-case category â not just a top 20
- A "Top 10 Overall" section exists for quick scanning, but the full catalog is browsable
- Flag any that appeared independently in multiple modes (convergence signal)

---

## Output

### File Location
```
Active-Brain/00 Projects/01 Behavioral Intelligence/Offer Factory/Engine Runs/[Product] - [Mode] - [Date].md
```

### Document Structure

```markdown
# Offer Engine Run: [Product] â [Mode]
**Date:** [Date]
**Mode:** [Mode name]
**Products:** [Which products were input]
**Component Data:** [Available/Partial/None â flag if Decomposer hasn't run]

## Run Summary
- Total concepts generated: [count]
- Top-rated concepts: [count above threshold]
- Novelty standouts: [count]
- Feasibility standouts: [count]
- Convergence signals: [concepts that appeared in multiple modes]

## Quick Scan: Top 10 Overall
[Ranked list with scores â the 10 highest-combined-score concepts across all modes and categories]

### 1. [Concept Name]
**Pattern(s):** [Which structural/tactical patterns]
**Source Mode:** [Which mode generated this]
**Category:** [Which catalog category below]
**Products/Components Used:** [Specific components from specific products]
**Description:** [2-3 sentences â what the buyer gets, how it works]
**Target Buyer:** [Who specifically wants this]
**Why It's Novel:** [What makes this different from anything in the current portfolio]
**Scores:** Novelty [/5] | Feasibility [/5] | Revenue [/5] | Combined [/15]

[...repeat for all 10...]

## Full Catalog by Category

### Support Active Sales
[Concepts that help sell what Rich is currently selling â only populated if `currently_selling` is set]
[Ranked list with full concept details and scores]

### Quick Wins (Buildable This Week)
[Concepts requiring minimal new assets â high feasibility, low complexity]
[Ranked list with full concept details and scores]

### New Standalone Products
[Full new offer concepts â things that don't exist yet]
[Ranked list with full concept details and scores]

### Portfolio Extensions
[Add-ons, upsells, upgrades to existing products]
[Ranked list with full concept details and scores]

### Strategic Bets
[High novelty, higher risk, potentially transformative â the "I never would have thought of that" ideas]
[Ranked list with full concept details and scores]

## All Concepts by Mode

### Pattern Sweep
[Full list with scores â structural and tactical]

### Cross-Pollination
[Full list with scores]

[...etc...]

## Convergence Report
[Concepts that appeared in 2+ modes, indicating strong structural logic]

## Recommended Next Steps
- Send top 3-5 to Offer Deepener for development
- Flag concepts needing additional product data
- Note any concepts that require Rich's input
```

---

## Scoring Rubric

| Dimension | 1 | 3 | 5 |
|-----------|---|---|---|
| **Novelty** | Exists in market already | Variation on known concept | Never seen this before |
| **Feasibility** | Would require major new infrastructure | Needs some new assets | Could build with existing components |
| **Revenue** | <$10K potential | $10K-$100K potential | $100K+ potential |

**Combined score thresholds:**
- 12-15: Send to Deepener immediately
- 9-11: Worth exploring further
- 6-8: Interesting but not urgent
- 3-5: File for reference

---

## Tactical Patterns (20)
*Smaller-scale patterns that modify HOW an offer is presented, priced, or delivered â not WHAT the offer is.*

| # | Pattern | Description |
|---|---------|-------------|
| T1 | Guarantee Innovation | Novel risk reversal beyond money-back (conditional, aspirational, sealed-envelope, etc.) |
| T2 | Bonus Architecture | Strategic bonus design (bonuses that solve objections, speed results, or create FOMO) |
| T3 | Urgency Engineering | Authentic scarcity/urgency mechanisms (not fake countdown timers) |
| T4 | Price Anchoring | Strategic price presentation (comparison anchors, payment framing, investment vs. cost) |
| T5 | Social Proof Stacking | Proof structures beyond testimonials (case studies, live results, peer density) |
| T6 | Naming/Branding | Offer naming that creates category (branded method, proprietary system name) |
| T7 | Delivery Mechanism Swap | Same content, different delivery (book->workshop, course->tool, coaching->AI) |
| T8 | Onboarding Design | First-experience design that locks in commitment (quick win, identity shift) |
| T9 | Ascension Trigger | Built-in mechanism that moves buyer to next offer (milestone, graduation, results-based) |
| T10 | Community Architecture | Community as product feature (peer accountability, shared identity, network effects) |
| T11 | Content Gating Strategy | What's free, what's paid, what's premium â and why the line is where it is |
| T12 | Launch Sequence Design | How the offer enters the world (PLF, challenge, application, waiting list, etc.) |
| T13 | Payment Structure Innovation | Beyond one-time/subscription (performance-based, equity, revenue share, deposit+balance) |
| T14 | Objection Pre-handling | Offer structure that eliminates objections before they form |
| T15 | Identity Alignment | Offer positioning that aligns with buyer's desired identity, not just their problem |
| T16 | Exclusivity Framing | Legitimate exclusivity (application, prerequisites, capacity limits with real constraints) |
| T17 | Results Timeline | Promise structure around WHEN results happen (24 hours, 7 days, 90 days) |
| T18 | Transformation Staging | Breaking one big transformation into visible stages the buyer can track |
| T19 | Competitor Contrast | Offer structure that makes alternatives look obviously worse without attacking them |
| T20 | Exit Strategy | Built-in graduation/completion that makes the end feel like success, not abandonment |

---

## Quality Standards

**A good Engine run makes Rich say "I never would have thought of that."**

Signs the Engine is working well:
- Ideas that feel obvious in hindsight but weren't before
- Cross-industry patterns that create genuine differentiation
- Component remixes that create value exceeding the sum
- At least 3-5 concepts per run that provoke real excitement

Signs the Engine is phoning it in:
- Cosmetic variations of existing offers ("What if ZenithPro but cheaper")
- Generic ideas that could apply to any business ("Create a referral program")
- Pattern applications that don't use specific product knowledge
- All ideas clustered in the same conceptual space
- More than 50% of ideas are things a competent marketer would suggest without this system
- The "probability that a typical AI would generate this" score is above 40% for the majority of outputs
