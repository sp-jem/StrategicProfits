---
name: workshop-show-rate-maximizer
description: Designs and executes a complete workshop show-rate optimization system for Lockwood College Prep's Wednesday evening presentations. Takes a registrant list and produces a multi-touchpoint sequence (email, TextLine SMS, voicemail script) engineered to lift attendance from 30% toward 70%+. Uses psychology of commitment, anticipation, and identity â not generic reminders. Invoke when Andy wants to maximize attendance for an upcoming live presentation, audit why a past workshop underperformed, or rebuild his entire pre-workshop communication sequence.
license: proprietary
metadata:
tags:
  - program/ctd
  - client/andy-lockwood
---
# Workshop Show-Rate Maximizer

Diagnoses why Lockwood College Prep workshops convert registrants to attendees at only 30% and produces a complete, ready-to-deploy communication sequence that lifts that number to 70%+.

## Context

Andy runs approximately 3 live presentations per month, Wednesday evenings at 6:30pm. Christine is Andy's ops coordinator â she deploys the communication sequence in Kajabi and TextLine per the instructions this skill produces. Current conversion: 50 register, 15 show. That's a 70% no-show rate on warm, self-selected leads â people who already raised their hand about college admissions help. The problem is not the audience. The problem is the pre-event communication sequence is not doing its job.

The fix is not more reminders. It is a psychologically engineered sequence that progressively increases commitment, builds anticipation for specific content, and makes showing up feel like an identity-consistent act for an affluent Long Island or Boca Raton parent who cares about their kid's college future.

**Keywords:** workshop attendance, show rate, webinar no-shows, pre-event sequence, SMS sequence, email sequence, TextLine, commitment device, anticipation engine, college admissions presentation, Lockwood College Prep

## Minimum Requirements Before Starting

- Workshop date and time (default: Wednesday 6:30pm unless told otherwise). **HARD STOP if date is in the past** â this skill is for upcoming workshops only. If the date has already passed, redirect Andy to a post-event analysis instead of producing a pre-event sequence.
- **HARD STOP if the date doesn't match the stated day** (e.g., user says "Wednesday's workshop" but provides a Saturday date). Surface the conflict and ask which is correct before proceeding.
- Workshop topic or title â **HARD STOP if absent**. "Wednesday's workshop" is not a topic. Without a topic, every message becomes generic â the exact anti-pattern this skill exists to prevent.
- Workshop format: in-person, virtual (Zoom), or **hybrid** (both physical + virtual attendance). Hybrid requires Message 5 to include BOTH a physical address AND a Zoom link, clearly labeled.
- Workshop duration: single evening (default) or multi-day event. **If multi-day**: this skill doesn't apply â multi-day events need a different sequence. Redirect Andy to build a custom sequence.
- Number of registrants (even an estimate is fine). Zero registrants = no sequence needed â flag this to Andy rather than producing a sequence for an empty audience.
- Confirmation that TextLine is available for SMS outreach

**If no prior sequence is provided:** skip the diagnosis section and go directly to Phase 2.

**If TextLine is not available:** flag this immediately and produce an email-only fallback sequence. Do not produce SMS messages that cannot be deployed.

**If workshop date is less than 72 hours away:** flag the timing gap and produce an abbreviated sequence starting from the highest-leverage messages (Message 4 and 5 only). State explicitly what was skipped and why.

## GUARDRAILS

- NEVER produce a sequence that could apply to any workshop topic without modification. Every sequence is customized to the specific workshop title and content.
- NEVER deliver SMS drafts without counting characters. Every SMS must be confirmed under 160 characters before delivery.
- NEVER recommend removing touchpoints to simplify. The 5-touchpoint multi-channel approach is the system. Removing touchpoints removes results.
- NEVER use corporate or promotional language in Andy's voice. Andy sounds like a trusted advisor texting a parent directly.
- NEVER produce generic college admissions copy ("discover the secrets," "unlock your potential"). Every message references something specific to this workshop's content.
- DO NOT produce Message 6 (no-show recovery) as a batch blast. It is triggered only for confirmed non-attendees after the event starts.
- PROHIBITED output: templates with unfilled [PLACEHOLDER] fields. Fill in what is known (Andy, Lockwood College Prep, college admissions) and flag only what changes per workshop (topic, date, join link).

## Core Workflow

### Phase 1 â Diagnosis (only if prior sequence provided)

Analyze the existing sequence against these five failure modes:

**Failure Mode 1: Reminder-Only Messaging**
Did every message say some version of "don't forget your workshop is Wednesday"? If yes: this sequence has zero psychological lift. It reminds people of an obligation rather than building desire to attend.

**Failure Mode 2: No Commitment Escalation**
Did the sequence ask registrants to do anything that deepens their commitment? (Reply with their kid's name, answer a question, say "I'll be there") If not: the registrant never moved from passive enrollment to active participation. Passive enrollment cancels easily.

**Failure Mode 3: No Anticipation Content**
Did any message tease specific things they would learn? ("On Wednesday I'm going to show you the single question that tells us whether a student has a realistic shot at their top 3 schools") If not: there is nothing to look forward to. The workshop competes with everything else happening that night and loses.

**Failure Mode 4: Wrong Timing**
Were messages clustered in the last 24 hours? Or sent too early and too infrequently? Optimal window: first contact within 15 minutes of registration, then Day-3-before, Day-1-before, Day-of morning, 90 minutes before.

**Failure Mode 5: Single Channel**
Was the sequence email-only? For a 6:30pm event with a busy parent audience, email alone is insufficient. TextLine SMS has 98% open rates and changes behavior.

Score each failure mode: Present / Absent. Conclude with: "Your sequence had [X] of 5 failure modes. The highest-impact fix is [Y]."

### Phase 2 â Build the Optimized Sequence

Produce the complete sequence. Every message is written out in full â no templates, no placeholders. Andy (or Christine) must be able to copy each message directly into TextLine or the email platform.

---

**MESSAGE 1 â Instant Confirmation**
*Timing: within 15 minutes of registration*
*Channel: Email*
*Length: 150 words maximum*

Subject: You're in â here's what Wednesday is about

Three jobs: confirm they are registered, make them feel smart for signing up, tease ONE specific thing they will learn that they did not know they would be getting. Sign from Andy personally. No corporate language.

---

**MESSAGE 2 â Commitment Question**
*Timing: 3 days before workshop*
*Channel: TextLine SMS*
*Length: 160 characters maximum â count before finalizing*

Ask one question that requires a reply. Example pattern: "Hey, it's Andy from Lockwood â quick question before Wednesday: what's your biggest worry about [kid's situation] right now? Reply and I'll make sure we cover it."

This is a commitment device. When they reply, they have invested. They show up to see if their question was answered.

**Christine note:** Save replies and have Andy reference them in the opening minutes of the workshop. Even a general acknowledgment ("a lot of you asked about essay strategy â that's exactly what we're hitting tonight") dramatically increases the sense that this was personal.

---

**MESSAGE 3 â Anticipation Spike**
*Timing: 1 day before workshop*
*Channel: Email*
*Length: 200 words maximum*

Subject: Fill with the specific workshop topic â e.g., "What most families get completely wrong about financial aid timing." The subject must contain the actual topic of this specific workshop, not the bracket placeholder.

Lead with a counterintuitive truth about college admissions that most Long Island parents believe incorrectly. Do not give the answer â give the premise and say "I'm walking through this in detail tomorrow night." The registrant now has a specific thing they want to know, and the only place to get it is Wednesday's workshop.

---

**MESSAGE 4 â Same-Day Morning**
*Timing: day of workshop, 8:00 AM*
*Channel: TextLine SMS*
*Length: 160 characters maximum â count before finalizing*

Short, direct, personal. Include the phrase "I saved you a seat" â this triggers reciprocity and identity. They do not want to waste the seat Andy saved.

---

**MESSAGE 5 â 90-Minute Warning**
*Timing: 5:00 PM on workshop day (90 minutes before 6:30 start)*
*Channel: TextLine SMS*
*Length: 160 characters maximum â count before finalizing*

One final nudge. Include the direct join link. Permission to come even if staying briefly ("If you can only stay 20 minutes, still come").

---

**MESSAGE 6 â No-Show Recovery**
*Timing: 15 minutes after workshop starts*
*Channel: Email*
*Audience: Non-attendees only â do not send to anyone who joined*
*Length: 100 words maximum*

Subject: Missed you tonight â here's what we covered

Brief summary of 3 things covered. Offer to jump on a 15-minute call this week. Converts the no-show into a sales conversation rather than a dead lead.

---

### Phase 3 â Psychological Mechanics Summary

After the sequence, produce a one-page summary Andy can share with Christine so she understands WHY each message works:

- **Why Message 1 works:** tease + confirmation = anticipation installed from minute one
- **Why Message 2 works:** commitment device â replied = invested = more likely to show
- **Why Message 3 works:** open loop in the brain that only the workshop closes
- **Why Message 4 works:** reciprocity trigger + social contract around the "saved seat"
- **Why Message 5 works:** specificity and permission to come even if staying briefly
- **Why Message 6 works:** no-show is not a dead lead â it is a warm prospect who needed more time

### Phase 4 â Platform Setup Instructions

Produce setup guidance only if Andy requests it:

**TextLine:** How to tag registrants by upcoming workshop date, how to schedule broadcasts, how to filter by "did not check in" after the event starts.

**Kajabi:** Where to configure the automated email triggers by event registration, how to set the time delays, how to A/B test subject lines for Messages 2 and 3.

**Zapier connector:** If registration is in Kajabi and outreach is via TextLine, a Zapier Zap routes registrant phone numbers from Kajabi to TextLine automatically (so Christine doesn't paste them manually). For the complete Zap recipe including field mapping, trigger conditions, and error handling, invoke the `pipedrive-kajabi-reconciler` skill separately â it contains the full ZAP 1 design. This skill stops at the requirement ("route phone numbers to TextLine") and hands off the implementation detail.

## Output Format

Deliver the output in three sections, in this order:

1. **DIAGNOSIS** (only if prior sequence provided) â failure modes identified, ranked by impact, with a score out of 5
2. **OPTIMIZED SEQUENCE** â all applicable messages written in full, each labeled with: message number, channel, timing, character/word count confirmation
3. **SETUP GUIDE** â platform-specific deployment instructions for Christine, only if requested

## Operating Rules

- Every message is written out in full. Never deliver a template with [NAME] placeholders â fill in what is known and flag only what changes per workshop (topic, date, join link).
- SMS messages must be under 160 characters. State the character count next to each SMS before delivery.
- Voice of all messages is Andy: direct, no-nonsense, genuinely invested in the family's outcome. Not corporate. Not promotional. Reads like a text from a trusted advisor.
- If Andy provides the current show rate and the sequence produced lifts it, calculate the revenue impact: "If this takes you from 15 to 30 attendees per workshop, and your close rate holds at X%, that's Y additional clients per month at your current offer price." **Sanity-check close rate inputs**: if Andy provides a close rate below 5% or above 50%, flag it as implausible before calculating â "Most LCP workshops close in the 15-35% range. Your number is outside that band. Is that accurate or a typo?" Do not silently produce revenue math on impossible rates.
- If the workshop date is unknown, do not produce a sequence. Ask for the date first.
- If it is a Boca Raton workshop: adjust cultural references. Florida affluent families have different social comparison dynamics than Long Island families. Specific adjustments: (1) Reference University of Florida, Miami, Tulane, Emory, and top-tier private Florida schools instead of Ivy League / Long Island elites. (2) Tone down Northeast academic competitiveness framing â Florida affluent parents are more outcome-focused (career placement, ROI) and less status-focused (prestige-chasing). (3) Replace "dinner party conversation" social references with "country club" or "community" framing. (4) Avoid Northeast weather/lifestyle references. (5) Timeline urgency still applies but frame around Florida public school calendar (which runs slightly different from NY).

## Edge Cases

1. **Workshop is less than 72 hours away** â Skip Messages 1-3. Produce only Message 4 (same-day morning) and Message 5 (90-minute warning). State what was skipped and why.
2. **Registrant list has no phone numbers** â TextLine cannot run. Produce email-only fallback for Messages 2, 4, and 5. Flag the show-rate risk of email-only delivery.
3. **Andy's close rate is unknown** â Do not produce the revenue impact calculation. State: "Provide your close rate and offer price to unlock the revenue projection."
4. **Repeat attendees on the registrant list** â Adjust Message 2 (commitment question) to reference their prior attendance: "You came to the last one â this one goes deeper on [topic]." Do not treat repeat attendees as new.
5. **Virtual workshop (Zoom) instead of in-person** â Replace "I saved you a seat" language with "I saved your spot." Adjust Message 5 to include the Zoom link directly. Remove any in-person logistics.
6. **Same-day request (workshop is tonight, morning has passed)** â Produce only Message 5 (90-minute warning) with the join link. State: "Only Message 5 is viable at this point. For future workshops, engage this skill at least 72 hours before the event."
7. **Hybrid workshop (physical + virtual attendance)** â Message 5 must include both the physical address AND the Zoom link, clearly labeled: "In person: [address] | Can't make it in person? Join on Zoom: [link]." Message 4 mentions both options with equal weight.
8. **Multi-day event (retreat, weekend intensive)** â This skill does not apply. Redirect Andy: "This is a multi-day event. The 5-message sequence is calibrated for a single-evening workshop. Use a custom sequence for multi-day events, or have me build one."
9. **Workshop date has already passed** â Stop. Do not produce a pre-event sequence. Suggest running post-event analysis instead: "This workshop was [X] days ago. For a post-event analysis and no-show recovery, use Message 6 in isolation."
10. **Date conflicts with stated day** (e.g., "Wednesday's workshop" with a Saturday date) â Surface the conflict and ask which is correct. Do not pick one and proceed.

## Anti-Patterns

| Don't | Do Instead |
|-------|------------|
| Send generic "reminder" messages | Every message builds anticipation or deepens commitment |
| Cluster all messages in the last 24 hours | Spread across 5 touchpoints from registration to 90 min before |
| Use the same channel for every message | Alternate email and TextLine SMS |
| Write messages that could apply to any workshop | Every message references this workshop's specific topic |
| Send Message 6 (no-show recovery) to attendees | Filter non-attendees only â sending to attendees is a trust violation |

## Before You Respond

*(Pre-flight gate: Minimum Requirements section above defines the hard prerequisites. This checklist is the per-output verification that runs once data is in hand.)*

- [ ] Minimum Requirements satisfied per the section above?
- [ ] Is every SMS under 160 characters with the count stated?
- [ ] Is every message specific to THIS workshop's topic (not reused from prior week)?
- [ ] If Boca Raton workshop: have I adjusted cultural references?
- [ ] Has Christine been told what to deploy in TextLine vs. Kajabi?

## When to Use This Skill

- Before every Wednesday workshop to generate the fresh sequence
- When Andy wants to audit why a past workshop had low attendance
- When building out the Boca Raton expansion â new market needs its own sequence calibrated to Florida parents
- When training Christine to own the workshop communication workflow end-to-end

## Save Location

Save the generated sequence to Andy's Obsidian vault at the root configured on first run. Path: `[Andy's Vault Root]/CTD/Workshop Sequences/[YYYY-MM-DD]-sequence.md`. Christine confirms the vault root path before the first save.

## Version History

- **v1.0.0** â Initial build for CTD Cohort 2 (April 2026)
- **v1.1.0** â Added Edge Cases, Anti-Patterns, Before You Respond sections (Gauntlet QA pass)
- **v1.2.0** â Full Gauntlet Phase 6C cold reads (Phoenix + Novice + Saboteur). Phoenix: defined Christine, anchored save path, consolidated duplicate pre-flight gates. Novice: fixed Message 3 bracket-placeholder contradiction, expanded Boca Raton adjustment with 5 specific changes, explained pipedrive-kajabi-reconciler handoff. Saboteur: hard stops for past date, day/date conflict, missing topic, multi-day event; added hybrid format edge case; added 0%/100% close rate sanity checks.
