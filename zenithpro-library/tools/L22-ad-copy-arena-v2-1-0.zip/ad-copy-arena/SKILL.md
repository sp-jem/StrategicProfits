---
name: ad-copy-arena
description: "Competitive ad copy engine. Runs 5 expert frameworks — meta-ad-copy (Ben Heath + Dara Denney + Nick Theriot), sa-ad-copy (SA UPSYD + 3-Act), clayton-headlines (Clayton Makepeace fascination headlines), carlton-hooks (John Carlton pattern-interrupt hooks), and dara-denney-founder-ad-formula (Dara Denney founder UGC scripts) — against the same brief, then scores all hooks and ads head-to-head to declare winners. Use when writing Facebook/Meta ad copy for any campaign. Triggers: /ad-copy-arena, 'write ad copy', 'create ads', 'ad copy for [campaign]', 'Facebook ads for [offer]'."
version: 2.1.0
author: Ashley Shaw / Strategic Profits
programs: [Ad Prediction Machine, ZenithPro]
trigger: /ad-copy-arena
dependencies:
  # Arena competitors (Phases 1-5)
  - meta-ad-copy
  - sa-ad-copy
  - clayton-headlines
  - carlton-hooks
  - dara-denney-founder-ad-formula
  # Critic chain (Phase 7C)
  - copy-review-agent
  - truth-critic
  - nick-shackelford-thumbstop-audit
  # Creative direction chain (Phase 7B)
  - meta-ad-graphic-strategist
  - ad-image-creator
  # Post-production audit (Phase 7B — only when images exist)
  - visual-conversion-critic
---

# Ad Copy Arena

Competitive ad copy engine. Five expert frameworks draft independently against the same brief, then a judge layer scores every hook and ad head-to-head and declares winners.

---

## NON-NEGOTIABLE RULES

| Rule | Why |
|------|-----|
| All 5 skills run on the SAME brief | Different briefs = unfair competition. The brief is locked before any skill runs. |
| No skill sees another's output | Independence prevents contamination. Run them as separate passes. |
| The judge layer scores AFTER all 5 skills complete | No mid-round scoring. All entries must be final before judging begins. |
| Never fabricate proof points | Both skills must use only verified data from the brief. Placeholders for anything unverified. |
| Remove all internal scoring notation from final output | Golden Hook scores, validation gates, framework attribution — keep in working drafts, strip from production copy. |
| Replace "Keith" with "SA" in all output | SA's framework references use "SA" only — never the person's name. |
| All outputs saved to files | Chat-only delivery = lost work. Every phase produces a file. |

---

## ARENA STRUCTURE

```
[Brief Locked]
       |
       +---> Pass 1: meta-ad-copy (Ben Heath + Dara Denney + Nick Theriot)
       |         -> 10+ hooks + 3 full ad variations
       |
       +---> Pass 2: sa-ad-copy (SA UPSYD + 4 Buyer Personas + 3-Act)
       |         -> 5+ hooks + 2 full ad scripts
       |
       +---> Pass 3: clayton-headlines (Clayton Makepeace fascination headlines)
       |         -> 10+ headline/hook variants + 1 full primary text ad
       |
       +---> Pass 4: carlton-hooks (John Carlton pattern-interrupt hooks)
       |         -> 10+ hooks + 2 full ads with Incongruous Juxtaposition lead
       |
       +---> Pass 5: dara-denney-founder-ad-formula (Dara Denney founder UGC)
       |         -> 5+ hooks + 2 founder-led video ad scripts
       |
       v
[Judge Layer]
       |
       +---> Hook Battle: Score all hooks head-to-head (~40+ hooks)
       +---> Ad Battle: Score all full ads/scripts head-to-head (~11 ads)
       +---> Winner Declaration + Runner-Up + "Dark Horse" pick
       |
       v
[Production Package]
       -> Top 5 hooks (ranked)
       -> Top 3 full ads (ranked)
       -> Testing plan (what to run first, second, third)
```

All 5 passes run independently — no pass sees another's output.

**Phase sequence:** 0 (Brief) → 1-5 (Expert Passes) → 6 (Judge) → 7A (Winner Declaration) → 7B (Creative Direction) → 7C (Critic Audit) → 8 (Revision Rounds) → 9 (Final Package). 7B and 7C run in parallel — neither depends on the other. Both must complete before Phase 8.

---

## PHASE 0: BRIEF COLLECTION (Mandatory — runs before either skill)

Collect and lock the following. Neither skill runs until the brief is confirmed.

### Required Fields
1. **Product / Offer** — what is being advertised (name, price, what's included)
2. **Target audience** — who the ideal customer is, with specificity
3. **Awareness stage** — cold / warm / hot (Level 1-5 if known)
4. **Primary goal** — registrations / leads / sales / clicks
5. **Positioning context** — hook direction, enemy, distinction, competitive angle
6. **Verified proof points** — testimonials, numbers, results that CAN be used (list them explicitly)
7. **What CANNOT be claimed** — any numbers, results, or stories that are unverified

### Optional but High-Value
- Previous campaign data (what worked, what didn't)
- Existing hooks or copy to beat
- Visual direction or format constraints
- Platform (Meta, YouTube, etc.) — defaults to Meta

### Brief Coherence Check (MANDATORY before lock)

Before presenting the brief for confirmation, check for:
- **Awareness contradiction:** Does the traffic temperature (cold/warm/hot) match the proof language? Cold traffic + insider jargon = coherence failure. Flag it.
- **Proof scope:** Only Field #6 (Verified Proof Points) counts as verified source material for factual claims. Positioning context (Field #5) is NOT a verified source — it's direction, not data.
- **Required fields:** If any required field (1-7) is missing, HALT. Do not proceed on user pressure. State: "Field [X] is required. The arena cannot produce reliable output without it."

### Brief Lock
Present the complete brief back to the user including any coherence flags. Do not proceed until they confirm with "confirmed" or provide corrections.

> **Brief locked. Running all 5 frameworks now.**

---

## PHASE 1: PASS 1 — meta-ad-copy

Invoke the meta-ad-copy skill with the locked brief. Follow its full execution protocol:
1. Verify brief
2. Determine market sophistication stage
3. Select frameworks based on stage
4. Generate hooks (10+ minimum) and primary text (3 full ad variations)
5. Self-validate

Save output to: `[project-folder]/arena-pass-1-meta.md`

**Strip from output before saving:**
- Golden Hook Formula scoring lines
- Self-validation gate checklist (keep internally, don't include in file)
- Framework attribution paragraphs (keep expert names in hook type labels only)

---

## PHASE 2: PASS 2 — sa-ad-copy

Invoke the sa-ad-copy skill with the SAME locked brief. Follow its full execution protocol:
1. UPSYD analysis
2. 4 Buyer Persona mapping
3. Hook generation (5+ minimum) using SA's hook research process
4. Full ad scripts (2 minimum) using 3-Act block structure
5. Self-validate

Save output to: `[project-folder]/arena-pass-2-sa.md`

**Strip from output before saving:**
- Internal scoring notation
- Self-validation gate checklist
- Any reference to "Keith" — replace with "SA"

---

## PHASE 3: PASS 3 — clayton-headlines (Clayton Makepeace)

Invoke the clayton-headlines skill with the SAME locked brief. Clayton's natural format is long-form sales copy — **constrain him to Meta ad format.**

**Instructions to Clayton:**
> "You are writing Meta/Facebook ad copy, NOT a sales letter. Apply your fascination headline frameworks, emotional trigger systems, and curiosity-gap mastery to produce SHORT-FORM ad copy that fits a Facebook feed. Every output must be under 300 words for primary text. Think of this as writing the most irresistible 3 lines anyone has ever scrolled past."

**What to produce:**
1. 10+ headline/hook variants using Clayton's fascination frameworks (curiosity-driven, emotion-loaded, benefit-specific)
2. 1 full Meta primary text ad (hook + body + CTA, under 300 words)
3. 3 headline options for the ad

Save output to: `[project-folder]/arena-pass-3-clayton.md`

**Strip from output before saving:**
- Internal scoring notation
- Framework attribution paragraphs (keep expert name in labels only)

---

## PHASE 4: PASS 4 — carlton-hooks (John Carlton)

Invoke the carlton-hooks skill with the SAME locked brief. Carlton's natural format is sales letters — **constrain him to Meta ad format.**

**Instructions to Carlton:**
> "You are writing Meta/Facebook ad copy, NOT a sales letter. Apply your Incongruous Juxtaposition, A-Brain triggers, pattern-interrupt hooks, and Simple Writing System to produce SHORT-FORM ad copy. Every output must be under 300 words for primary text. Write like you're talking to someone at a bar who's about to scroll away — you have 3 seconds."

**What to produce:**
1. 10+ hooks using Carlton's pattern-interrupt and Incongruous Juxtaposition frameworks
2. 1 full Meta primary text ad with an Incongruous Juxtaposition lead (hook + body + CTA, under 300 words)
3. 3 headline options for the ad

Save output to: `[project-folder]/arena-pass-4-carlton.md`

**Strip from output before saving:**
- Internal scoring notation
- Framework attribution paragraphs (keep expert name in labels only)

---

## PHASE 5: PASS 5 — dara-denney-founder-ad-formula (Dara Denney)

Invoke the dara-denney-founder-ad-formula skill with the SAME locked brief. Dara's framework is purpose-built for founder-led UGC video ads.

**Instructions to Dara:**
> "Write founder-led video ad scripts for Meta/Facebook. The founder is Rich Schefren — casual, credible, not guru-polished. These scripts should look and feel like organic content that happens to be an ad. Apply your split-tested founder ad formula, name + title text overlay rule, and native-content style direction."

**What to produce:**
1. 5+ hooks optimized for founder-to-camera format
2. 2 full founder-led video ad scripts (casual talking head, organic feel, under 90 seconds each)
3. Visual direction notes for each script (setting, wardrobe, production style)

Save output to: `[project-folder]/arena-pass-5-dara.md`

**Strip from output before saving:**
- Internal scoring notation
- Framework attribution paragraphs (keep expert name in labels only)

---

## PHASE 6: JUDGE LAYER

Read all five pass files. Score every entry. The judge evaluates on these 6 dimensions:

### Hook Scoring (each hook scored 1-10 on each dimension)

| Dimension | What It Measures |
|-----------|-----------------|
| **Scroll-Stop Power** | Would this actually stop a thumb mid-scroll? Does it interrupt the pattern? |
| **Curiosity Gap** | Does it open a loop the viewer MUST close? How strong is the unanswered question? |
| **Audience Specificity** | Does the right person instantly know "this is for me"? Does the wrong person scroll past? |
| **Mechanism Tease** | Does it hint at something different without giving it away? |
| **Emotional Charge** | Does it trigger a feeling — frustration, recognition, hope, fear of missing out? |
| **Platform Native** | Would this feel natural in a Meta feed? Or does it scream "ad"? |

**Total possible per hook: 60 points**

### Full Ad Scoring (each ad scored 1-10 on each dimension)

| Dimension | What It Measures |
|-----------|-----------------|
| **Hook Strength** | Same criteria as hook scoring above |
| **Education / Mechanism Clarity** | Does the body clearly explain WHY this is different? Would a cold reader understand? |
| **Proof Integration** | Are testimonials and numbers woven naturally, or bolted on? |
| **Persona Coverage** | Does this ad speak to at least 2 of the 4 buyer personas? |
| **CTA Strength** | Is the next step clear, specific, and low-friction? |
| **Voice / Authenticity** | Does this sound like a real person or a copywriter? Would it survive in a feed? |

**Total possible per ad: 60 points**

### Scoring Rules
- Score independently — do not curve scores based on what the other skill produced
- Ties are broken by Scroll-Stop Power (hooks) or Hook Strength (ads) — the first impression wins
- If a hook or ad contains a fabricated proof point, it is automatically disqualified regardless of score
- Note which buyer persona(s) each entry serves best
- **Cut threshold: 48/60 minimum.** Any hook or ad scoring below 48 is CUT — it does not appear in the production package. Only 48+ entries survive to the winners declaration. If fewer than 5 hooks or 3 ads clear the threshold, report how many survived and note the gap.

---

## PHASE 7A: WINNER DECLARATION + PRODUCTION PACKAGE

### Declare Winners

**Hook Battle Results:**
1. **Champion Hook** — highest total score
2. **Runner-Up Hook** — second highest
3. **Dark Horse Hook** — the one that scores lower overall but has the highest single-dimension score (often the most creative or polarizing option worth testing)
4. **Hooks 4-5** — next two by score
5. For each: state which skill produced it, which persona it serves, and a one-line rationale

**Ad Battle Results:**
1. **Champion Ad** — highest total score
2. **Runner-Up Ad** — second highest
3. **Dark Horse Ad** — highest single-dimension score
4. For each: state which skill produced it, which personas it covers, and a one-line rationale

### Production Package

Compile the final deliverable:

```markdown
# Ad Copy Arena — [Campaign Name] — Production Package

## Campaign: [name]
## Date: [date]
## Arena Result: [X] hooks scored, [Y] ads scored

---

## TOP 5 HOOKS (Ranked)

### #1: [Hook text]
- Score: [X]/60
- Source: [meta-ad-copy / sa-ad-copy]
- Best for: [persona(s)]
- Visual direction: [recommendation]

[repeat for #2-5]

---

## TOP 3 ADS (Ranked)

### #1: [Ad name]
- Score: [X]/60
- Source: [meta-ad-copy / sa-ad-copy]
- Personas covered: [list]
- Format: [talking head / screen share / text-on-screen / etc.]

[Full ad copy here — production-ready, no internal notation]

[repeat for #2-3]

---

## TESTING PLAN

### Week 1: Launch
- Run hooks #1, #2, and #5 (Dark Horse) as separate ad sets
- Pair each with Champion Ad body copy
- Budget: [defer to media buyer — do not recommend spend]

### Week 2: Iterate
- Kill lowest performer
- Test Runner-Up Ad body copy with winning hook
- Test Dark Horse Ad if budget allows

### What to Watch
- Hook-through rate (3-second video views / impressions)
- CTR to registration page
- Cost per registration
- If Dark Horse outperforms Champion — the market is more [saturated/emotional/frustrated] than assessed. Shift future creative toward that direction.
```

Save production package to: `[project-folder]/ad-copy-arena-winners.md`

---

## PHASE 7B: CREATIVE DIRECTION LAYER (Runs after judge, before revision)

After the judge declares winners, produce creative direction for every surviving entry. This bridges the gap between copy and production.

### For Every Winning Hook:
1. **Image ad version** — rewrite the hook as text-on-image copy (max 8 words on the image, the rest goes in primary text)
2. **Visual direction** — what the image should show (screen-share, founder photo, before/after, contrast split, testimonial card, etc.)
3. **Text overlay spec** — exact words on the image, font size hierarchy, color contrast notes
4. **Format recommendation** — static image / carousel / video / Reel

### For Every Winning Ad:
1. **Static image companion** — a standalone image ad version of the same angle (for people who don't watch video)
2. **Thumbnail/first-frame direction** — what the viewer sees before they click play (this IS the scroll-stop for video)
3. **Headline options** — 3 headlines for the ad (these show below the image in Meta's format)
4. **Description line** — the single line that shows under the headline

### Image Ad Copy Rules:
- Text on image: MAX 8 words. Less is more. The image does the stopping, the primary text does the selling.
- Never put the full hook on the image — put the MOST provocative fragment, then complete it in primary text
- Always include Rich's name + title on founder content images (Dara's split-tested rule)
- Contrast matters — light text on dark, or dark text on light. No mid-tones.
- Feed-native first — should look like a post, not an ad

### Expert Chain for Visual Creative

The creative direction layer runs through 3 expert skills in sequence:

**Step 1: meta-ad-graphic-strategist** — generates image concepts
- Applies Dara Denney + Shackelford visual frameworks
- Produces scroll-stop mechanics, feed contrast strategy, native-first design direction
- Outputs: image concept briefs for each winning hook and ad

**Step 2: ad-image-creator** — specs for production
- Takes the image concepts and produces production-ready specs
- Format, dimensions, text overlay placement, color palette, typography
- Outputs: production briefs ready to hand to a designer or AI image tool

**Step 3: nick-shackelford-thumbstop-audit** — validates scroll-stop
- Audits every image concept against Shackelford's scroll-stop criteria
- PASS/FAIL gate — if an image concept fails, it goes back to Step 1 for revision
- Only images that PASS the thumbstop audit make the final creative direction package

**Optional Step 4: visual-conversion-critic** — audits finished creative
- Run AFTER images are actually produced (not at the concept stage)
- Checks colors, typography, layout, buttons, contrast, feed readability
- Returns APPROVED / FIX FIRST / NEEDS LIVE DATA verdict

Save creative direction to: `[project-folder]/ad-copy-arena-creative-direction.md`

---

## PHASE 7C: CRITIC AUDIT (Mandatory — runs before revision, blocks delivery)

Every arena output must pass external critic review before it can be declared production-ready. The arena's internal judge scores are necessary but not sufficient — critics catch what judges miss.

### Critic Chain (run in parallel)

**1. nick-shackelford-thumbstop-audit** — on ALL surviving hooks (48+ from judge)
- PASS/FAIL on scroll-stop probability
- Specific fix recommendations for any FAIL
- Hooks that fail thumbstop are demoted regardless of judge score

**2. copy-review-agent** — on ALL surviving ads (48+ from judge)
- Multi-framework review (persuasion, structure, voice, proof integration)
- Grade: A+ / A / B / C / F
- Ads below A grade go back for revision with specific fix notes

**3. truth-critic** — on the FULL production package
- Source verification: every claim, number, testimonial, and proof point cross-referenced against the brief
- Fabrication check: flag anything not traceable to verified source material
- PASS/FAIL — a single fabrication fails the entire package

**4. Voice DNA check** (if Voice DNA file exists for the founder/brand)
- Cross-reference winning ads against the Voice DNA file
- Flag any lines that don't sound like the founder
- Provide rewrite suggestions that match documented speech patterns

**5. visual-conversion-critic** — on creative direction (ONLY when actual images exist)
- Skip this at the concept stage — run it AFTER images are produced
- Returns APPROVED / FIX FIRST / NEEDS LIVE DATA

### Audit Rules

| Rule | Why |
|------|-----|
| Critics run AFTER the judge layer, BEFORE revision rounds | Revisions should fix critic findings, not just chase higher scores |
| truth-critic failure blocks the entire package | A single fabricated proof point makes everything untrustworthy |
| Hooks that fail thumbstop audit are CUT even if they scored 48+ | The judge scores persuasion potential; thumbstop scores real-world scroll behavior. Thumbstop wins. |
| Ads below A grade get specific fix notes and enter revision | Don't revise blindly — revise against critic findings |
| visual-conversion-critic only runs when actual produced images exist | At the concept/spec stage, there's nothing visual to audit yet |

Save audit results to: `[project-folder]/ad-copy-arena-audit.md`

---

## PHASE 8: REVISION ROUNDS (Iterate Until Best of the Best)

After the judge declares winners, run revision rounds to push scores higher. This is how good becomes great.

### How Revision Works

**Cross-competitor context mechanism:** Before each expert revises, compile all winning entries into a single context file: `[project-folder]/arena-revision-context.md`. This file contains the full text of every winning hook and ad, labeled by source expert. Each expert receives this file as input alongside the original brief.

1. Take the Top 5 hooks and Top 3 ads from the judge layer
2. Compile all winners into `arena-revision-context.md` with source labels
3. Each expert receives: the original locked brief + the revision context file
4. Each expert writes **revised versions** — they can:
   - Improve their own winning entries based on what they learned from seeing others
   - Write NEW entries inspired by another expert's approach but filtered through their own framework
   - Combine elements (e.g., Carlton's hook opening + SA's body structure)
4. Re-judge all revised entries against the originals using the same 6-dimension scoring
5. Only entries scoring **48/60 or higher** survive
6. **Repeat until no revision round produces a higher score than the previous round's champion**

### Revision Round Rules

| Rule | Why |
|------|-----|
| Experts CAN see each other's work during revision (unlike drafting) | Cross-pollination is the point — revision is about improving, not independent creation |
| Original winners stay in the competition | A revision must BEAT the original to replace it — originals aren't automatically retired |
| Maximum 3 revision rounds | Diminishing returns after 3. If Round 3 doesn't beat Round 2's champion, stop. |
| Each expert produces max 2 revised hooks + 1 revised ad per round | Prevents explosion. Quality over quantity in revision. |
| The final champion must score higher than the Round 1 champion | If revision doesn't improve scores, the original wins. Revision is not mandatory — it earns its place. |
| **Truth-critic MUST re-run after every revision round** | Revision introduces new content that may drift from source. Every revised entry gets truth-checked before it can enter the winners pool. A revised entry that fails truth-critic is DISQUALIFIED regardless of score. |
| **All 5 experts must compete — no single-expert bypass** | The arena's value is competition. If a user requests "only use Clayton," respond: "The arena requires all 5 experts to compete. To run a single expert, use that skill directly (e.g., `/clayton-headlines`)." |

### Truth-Critic Failure Recovery

If the truth-critic finds a FABRICATED claim in any entry:

1. **Disqualify that specific entry** — remove it from the winners pool
2. **Promote the next-highest-scoring entry** that passed truth-check
3. **Flag the disqualified entry** with the specific fabrication and source conflict
4. **Re-run the judge** on remaining entries to confirm new rankings
5. **If fewer than 3 ads or 5 hooks survive after disqualification:** Report the gap and note which expert(s) failed. Do NOT fill gaps with sub-48 entries.

### Revision Output

Save each round to: `[project-folder]/arena-revision-round-[N].md`

After the final round, update the production package with the ultimate winners.

Save final to: `[project-folder]/ad-copy-arena-final-winners.md`

---

## OUTPUT LOCATIONS

All files saved to the offer/campaign folder in the Obsidian Vault:

| File | Contents |
|------|----------|
| `arena-pass-1-meta.md` | meta-ad-copy full output (Heath + Denney + Theriot) — 10+ hooks + 3 ads |
| `arena-pass-2-sa.md` | sa-ad-copy full output (SA UPSYD + 3-Act) — 5+ hooks + 2 video scripts |
| `arena-pass-3-clayton.md` | Clayton Makepeace fascination headlines + 2 ads |
| `arena-pass-4-carlton.md` | John Carlton pattern-interrupt hooks + 2 ads |
| `arena-pass-5-dara.md` | Dara Denney founder-led UGC video scripts — 5+ hooks + 2 scripts |
| `ad-copy-arena-winners.md` | Judge scores + ranked winners + testing plan |
| `ad-copy-arena-creative-direction.md` | Expert-chain visual direction for all winners (Phase 7B) |
| `ad-copy-arena-audit.md` | Critic audit results — thumbstop, copy review, truth critic (Phase 7C) |
| `arena-revision-round-[N].md` | Revision round results (Phase 8) — one file per round |
| `ad-copy-arena-final-winners.md` | Final production package after all revisions + audits complete |

---

## SCOPE BOUNDARIES

**This skill IS:** A competitive ad copy generation and judging system for Meta/Facebook ads.

**This skill IS NOT:**
- A media buyer — does not recommend budgets, audiences, or campaign structure
- A visual creative director — provides hook direction but does not produce images or video
- A landing page writer — route to `/landing-page-copy` for that
- A general copywriter — only produces Meta ad copy (hooks, primary text, scripts)

**If asked for:**
- Landing page copy → "Use `/landing-page-copy` for that"
- Ad images → "Use `/ad-image-creator` for that"
- Campaign setup → "Use `/ad-campaign-architect` for that"
- YouTube ads → "Use `/youtube-ad-script-builder` for that"
