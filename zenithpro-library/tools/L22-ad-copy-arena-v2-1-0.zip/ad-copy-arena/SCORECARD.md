# Ad Copy Arena — Skill Scorecard
**Skill:** ad-copy-arena
**Latest Version Graded:** v2.1.0
**Latest Score:** 4.17 / 5.0
**Latest Run:** Run 2 — 2026-04-08
**Status:** PASS
**Grader:** skill-grader (claude-sonnet-4-6)
**Calibration:** No calibration examples found; using general standards (low confidence)

---

## Run History

| Run | Version | Date | Score | Delta | Status |
|-----|---------|------|-------|-------|--------|
| 1 | v2.0.0 | 2026-04-08 | 4.01 / 5.0 | — | PASS — 3 must-fix items |
| 2 | v2.1.0 | 2026-04-08 | 4.17 / 5.0 | +0.16 | PASS — 2 remaining items |

---

# RUN 1 — v2.0.0 (2026-04-08)

## Pass/Fail Gates

| Gate | Result | Evidence |
|------|--------|----------|
| Factual accuracy | PASS | No fabricated frameworks or toolnames; all five expert systems (Ben Heath, Dara Denney, Nick Theriot, SA/UPSYD, Clayton Makepeace, John Carlton) are legitimate frameworks correctly attributed. No invented proof points or false statistics. |
| Policy compliance | PASS | No-fabrication rule is explicitly stated and enforced via truth-critic gate. Placeholder protocol for unverified claims is mandated. |
| Format compliance | PASS | Skill follows standard SKILL.md structure with YAML frontmatter, phased execution blocks, output file references, rules tables, and scope boundaries. |
| Brand safety | PASS | "Replace Keith with SA" rule correctly protects identity. Voice DNA check is a mandatory critic gate for founder content. Rich Schefren persona is specified appropriately (casual, credible, not guru-polished). |

All gates pass. Eligible for dimensional scoring.

---

## Dimensional Scores

| Dimension | Score | Weight | Weighted |
|-----------|-------|--------|----------|
| Structural quality | 3.8 | 0.25 | 0.95 |
| Output quality | 4.5 | 0.20 | 0.90 |
| Integration quality | 3.5 | 0.20 | 0.70 |
| Student-readiness | 3.6 | 0.15 | 0.54 |
| Conversion effectiveness | 4.6 | 0.20 | 0.92 |

**Weighted Score: 4.01 / 5.0**

---

## Dimension Justifications

### Structural Quality — 3.8/5.0
**Strengths:** Clear non-negotiable rules table at the top. Arena structure diagram is unambiguous. Judge scoring rubrics define all 6 dimensions with point totals. Hard cut threshold (48/60) is explicit. Output locations table exists. Scope boundaries section is clean and actionable.

**Defects:**
- Phase numbering is broken. "Phase 4" appears twice — once as the carlton-hooks pass in the arena diagram, and again as "PHASE 4: WINNER DECLARATION + PRODUCTION PACKAGE" in the written phases. Phase 5 is Dara Denney, Phase 6 is the Judge Layer, then Phase 7B and 7C appear before Phase 8 (Revision). The 7B/7C alphabetic suffix is unexplained and the ordering between 7B and 7C is never stated.
- The output locations table is incomplete. It lists 6 files but is missing: `ad-copy-arena-audit.md`, `ad-copy-arena-creative-direction.md`, `arena-revision-round-[N].md`, and `ad-copy-arena-final-winners.md` — all of which are explicitly referenced in their respective phases.
- The arena diagram comment at the bottom reads "All 4 passes run independently" when there are 5 passes.

### Output Quality — 4.5/5.0
**Strengths:** Five independent expert frameworks running against the same locked brief is a genuinely differentiated approach. The judge layer produces ranked tiers (Champion / Runner-Up / Dark Horse) with rationale, not just a list. The revision protocol with a convergence stop rule prevents infinite iteration. The production package template is complete — hooks ranked, ads ranked, testing plan, no internal notation. Dara founder-ad instructions are appropriately persona-specific for Rich Schefren. The creative direction layer correctly bridges from copy to visual production.

**Defects:**
- Production package template references `[project-folder]` but never defines where the project folder is or how to name it. A runner must infer.
- The testing plan correctly defers budget to the media buyer but provides no test structure guidance (number of ad sets to run simultaneously, minimum audience size for valid data). A student without a media buyer would be stuck.

### Integration Quality — 3.5/5.0
**Strengths:** YAML dependency block names five skills. Each phase explicitly invokes the correct skill by name. The creative direction chain (meta-ad-graphic-strategist → ad-image-creator → nick-shackelford-thumbstop-audit) is sequenced with a proper PASS/FAIL gate back to Step 1. visual-conversion-critic is correctly scoped to post-production images only.

**Defects:**
- YAML dependency block lists 5 skills: `meta-ad-copy`, `sa-ad-copy`, `clayton-headlines`, `carlton-hooks`, `dara-denney-founder-ad-formula`. But `copy-review-agent`, `truth-critic`, `ad-image-creator`, `meta-ad-graphic-strategist`, `nick-shackelford-thumbstop-audit`, and `visual-conversion-critic` are all invoked in Phases 7B and 7C with no YAML dependency declaration. A runner cannot verify these skills exist before the workflow reaches those phases.
- `dara-denney-founder-ad-formula` appears in the YAML dependencies but is not included in the bulleted dependency list at the top of the YAML block (the list shows only 4). Minor inconsistency but creates confusion about what's actually required.
- The revision phase (Phase 8) instructs skills to "see each other's output" but provides no mechanism — no file path instruction, no explicit re-invocation protocol. How a skill is called with cross-competitor context is left undefined.

### Student-Readiness — 3.6/5.0
**Strengths:** Brief lock protocol is explicit with 7 required fields and a user confirmation gate before any skill runs. Non-negotiable rules table is digestible. Scope boundary redirects are specific and actionable. Judge scoring rubrics remove ambiguity from what "good" means.

**Defects:**
- The broken phase numbering (Phase 4 appearing twice, 7B/7C with no explanation, "All 4 passes" when there are 5) would confuse a first-time runner.
- Phase 7B and 7C are both described as running "after the judge, before revision" but their relative order is never stated. A student must guess.
- The revision phase is the most underspecified section. "Show ALL winning entries to each of the 5 experts" — but how? The skills are invoked via their own prompts. The mechanism for feeding competitor copy into another skill's context is completely unaddressed.
- No example of what a completed arena output looks like. For a ZenithPro student, a reference example would significantly reduce first-run failure rate.

### Conversion Effectiveness — 4.6/5.0
**Strengths:** The 6-dimension judge scoring criteria map exactly to what determines Meta ad performance in cold traffic: Scroll-Stop Power, Curiosity Gap, Audience Specificity, Mechanism Tease, Emotional Charge, Platform Native. The 48/60 cut threshold eliminates average work. The Dark Horse concept is sophisticated and directly addresses the limitation of pure scoring (creative that polarizes often converts better than creative that averages high). Testing plan signals (hook-through rate, CTR, cost per reg) are the right metrics. The SA UPSYD + 4 Buyer Personas pass ensures persona coverage is built into the judging criteria. Clayton's constraint to under-300-word Meta format prevents long-form drift that wouldn't survive a feed. Carlton's 3-second bar is correctly framed.

**Defects:**
- The testing plan is too thin on Week 2+ structure. "Kill lowest performer" is directionally correct but insufficient for a student without a media buyer. A brief decision tree (if CPC is X, then Y; if hook-through rate below Z%, then W) would significantly raise conversion effectiveness of the output.
- No explicit awareness stage → framework emphasis mapping. The spec collects awareness level in the brief but never uses it to weight which of the 5 passes should be prioritized in the judge layer. A Level 1 cold audience and a Level 5 hot audience should not weight the same frameworks equally.

---

## Top 3 Improvements (Run 1)

### 1. Fix phase numbering and add explicit ordering for 7B/7C
**Issue:** Phase 4 appears twice. Phases 7B and 7C have no stated order relative to each other. The arena diagram says "4 passes" when there are 5. This structural confusion will cause first-run failures.
**Suggestion:** Renumber all phases sequentially: 0 (Brief), 1-5 (Passes), 6 (Judge), 7 (Creative Direction), 8 (Critic Audit), 9 (Revision). Add a one-line statement between 7 and 8 clarifying that creative direction runs first, critic audit runs second, both happen before revision. Fix the arena diagram line count.

### 2. Complete the YAML dependency block
**Issue:** `copy-review-agent`, `truth-critic`, `ad-image-creator`, `meta-ad-graphic-strategist`, `nick-shackelford-thumbstop-audit`, and `visual-conversion-critic` are invoked in Phases 7B and 7C but are not declared as dependencies. A runner cannot verify they exist before the workflow reaches those phases.
**Suggestion:** Add all invoked skills to the YAML dependencies block. If some are optional (visual-conversion-critic), mark them `optional: true`. Update the output locations table to include all files produced by the full workflow.

### 3. Specify the revision re-invocation mechanism
**Issue:** Phase 8 instructs experts to "see each other's output" during revision rounds but provides no mechanism for how a skill is invoked with cross-competitor context. This is the most underspecified phase and the most likely to fail silently.
**Suggestion:** Add an explicit instruction block: "To run revision, pass the following to each skill at invocation: [original brief] + [list of winning hook and ad texts from all 5 passes]. Instruct the skill to use these as creative benchmarks, not source material." Specify the exact file to reference (`ad-copy-arena-winners.md`) and that skills may cross-pollinate style but must not copy text verbatim.

---

## Certification (Run 1)

| | |
|---|---|
| **Weighted score** | 4.01 / 5.0 |
| **Minimum threshold** | 4.0 / 5.0 |
| **Individual dimension minimum** | 3.0 / 5.0 |
| **Lowest individual dimension** | Integration quality: 3.5 |
| **Status** | PASS — minimum threshold met, no dimension below 3.0 |

**Certified with must-fix items.** The skill passes minimum threshold and is safe to deploy. The three improvements above are recommended before next major version. The integration gap (missing YAML dependencies) is the highest-priority fix as it is the most likely cause of silent failures in production.

---

*Run 1 scorecard generated by skill-grader. Calibration confidence: low (no prior calibration examples found).*

---

---

# RUN 2 — v2.1.0 (2026-04-08)

## Fix Assessment

Three must-fix items from Run 1 were addressed in v2.1.0. Each assessed below.

| Must-Fix Item | Fix Applied | Assessment |
|---------------|-------------|------------|
| Phase numbering broken | Phase sequence map added (line 82); "All 4 passes" corrected to "All 5 passes" (line 80) | PARTIAL — sequence map is correct and 7B/7C parallel ordering now resolved. However, the written phase header "PHASE 4: WINNER DECLARATION + PRODUCTION PACKAGE" (line 247) was not updated and now directly contradicts the declared 7A label in the sequence map. A runner following the written headers will encounter Phase 4 twice. |
| YAML dependencies incomplete | All 11 dependencies now declared with role-based comments grouping them by function (arena competitors, critic chain, creative direction, post-production) | COMPLETE — every skill invoked in the workflow is now declared. visual-conversion-critic appropriately scoped via inline comment. |
| Revision phase underspecified | arena-revision-context.md mechanism introduced: explicit file path, contents description, and invocation instructions for each expert | COMPLETE — the mechanism is concrete and actionable. Expert cross-pollination rules are clear. |

**Fix score: 2 of 3 complete. 1 partial (phase header conflict persists).**

---

## Pass/Fail Gates

| Gate | Result | Evidence |
|------|--------|----------|
| Factual accuracy | PASS | All expert systems remain correctly attributed. No fabricated frameworks introduced. No invented proof points. |
| Policy compliance | PASS | No-fabrication rule reinforced. truth-critic gate intact. Placeholder protocol unchanged. |
| Format compliance | PASS | SKILL.md structure intact. YAML complete. Phase blocks present. Output locations table complete (all 10 files now listed). |
| Brand safety | PASS | "Replace Keith with SA" rule present. Voice DNA check mandatory. Rich Schefren persona correctly specified. |

All gates pass. Eligible for dimensional scoring.

---

## Dimensional Scores

| Dimension | Run 1 Score | Run 2 Score | Delta | Weight | Weighted (Run 2) |
|-----------|-------------|-------------|-------|--------|------------------|
| Structural quality | 3.8 | 4.0 | +0.2 | 0.25 | 1.00 |
| Output quality | 4.5 | 4.5 | flat | 0.20 | 0.90 |
| Integration quality | 3.5 | 3.9 | +0.4 | 0.20 | 0.78 |
| Student-readiness | 3.6 | 3.8 | +0.2 | 0.15 | 0.57 |
| Conversion effectiveness | 4.6 | 4.6 | flat | 0.20 | 0.92 |

**Run 1 Weighted Score: 4.01 / 5.0**
**Run 2 Weighted Score: 4.17 / 5.0**
**Delta: +0.16**

---

## Dimension Justifications (Run 2)

### Structural Quality — 4.0/5.0 (was 3.8, +0.2)
**What improved:** The phase sequence map on line 82 is new and unambiguous: 0 → 1-5 → 6 → 7A → 7B → 7C → 8 → 9. The "All 4 passes" error in the arena diagram is corrected to "All 5 passes." The 7B/7C parallel ordering is now explicitly stated ("neither depends on the other; both must complete before Phase 8"). The output locations table now includes all 10 files — the 4 missing files from Run 1 are present.

**Remaining defect:** The written phase header "PHASE 4: WINNER DECLARATION + PRODUCTION PACKAGE" on line 247 was not updated to match the declared 7A label in the sequence map. A runner following the headers will encounter "PHASE 4" twice (once for Carlton hooks, once for Winner Declaration), which directly contradicts the phase sequence on line 82. The sequence map and the headers are now in conflict, which is worse than having no sequence map at all — a runner cannot know which to trust.

### Output Quality — 4.5/5.0 (flat)
**What improved:** Nothing targeted this dimension.

**Remaining defects (unchanged from Run 1):**
- Production package template uses `[project-folder]` without defining where that folder lives or how to name it.
- Testing plan Week 2+ structure is too thin — "kill lowest performer" is correct direction but insufficient for an operator without a media buyer.

### Integration Quality — 3.9/5.0 (was 3.5, +0.4)
**What improved:** The YAML dependency block now declares all 11 skills with role-based comments. `copy-review-agent`, `truth-critic`, `nick-shackelford-thumbstop-audit`, `meta-ad-graphic-strategist`, `ad-image-creator`, and `visual-conversion-critic` — all previously absent — are now declared. A runner can verify every dependency exists before beginning. The output locations table is now complete. This was the highest-priority fix from Run 1 and it was fully addressed.

**Remaining minor gap:** `visual-conversion-critic` is not marked `optional: true` in the YAML despite the skill body correctly scoping it to post-production images only. This creates a minor ambiguity — is it a required dependency or a conditional one? The inline comment partially addresses this but an explicit optional flag would be cleaner. Not a blocking issue.

### Student-Readiness — 3.8/5.0 (was 3.6, +0.2)
**What improved:** The revision mechanism (arena-revision-context.md) is now fully specified. A first-time runner knows exactly what file to create, what it contains, and how each expert receives it. This was the most failure-prone phase in v2.0.0 and it is now actionable. The 7B/7C parallel ordering question is also resolved.

**Remaining defects:**
- The written phase headers remain in conflict with the phase sequence map (see Structural Quality). A student reading top-to-bottom hits "PHASE 4" twice with different content. This is the most likely source of first-run confusion.
- No example output exists. A ZenithPro student encountering this skill for the first time has no reference for what a completed arena looks like.
- Awareness stage collected in the brief (Phase 0) is never used to weight framework emphasis in the judge layer. A student who provides "Level 1 cold audience" gets no instruction on how that changes which expert passes to weight more heavily.

### Conversion Effectiveness — 4.6/5.0 (flat)
**What improved:** Nothing targeted this dimension.

**Remaining defects (unchanged from Run 1):**
- Week 2+ testing structure is underdeveloped — no decision criteria for when to kill vs. iterate.
- Awareness stage → framework weighting gap: the brief collects sophistication level but the judge layer treats all 5 passes equally regardless. Cold audiences benefit from Clayton/Carlton hooks (curiosity/pattern-interrupt); warm audiences benefit from SA UPSYD (problem-aware solution framing). This distinction is never applied.

---

## Top 3 Improvements (Run 2)

### 1. Renumber the written phase headers to match the declared sequence map
**Issue:** The phase sequence map on line 82 declares the winner declaration step as Phase 7A. The written section header on line 247 says "PHASE 4: WINNER DECLARATION." These directly conflict. A runner cannot know which is authoritative. This is a worse state than Run 1 — the map exists but disagrees with the document structure it describes.
**Suggestion:** Update the written section header from "PHASE 4: WINNER DECLARATION + PRODUCTION PACKAGE" to "PHASE 7A: WINNER DECLARATION + PRODUCTION PACKAGE" so it matches the sequence map exactly. This is a single line change and closes the last structural issue from Run 1's must-fix list.

### 2. Add awareness stage → framework weighting guidance to the judge layer
**Issue:** The brief collects audience awareness stage (Phase 0 field 3) but the judge layer scores all 5 passes with identical weight regardless of awareness level. Cold audiences respond differently than warm audiences, and the expert frameworks are not interchangeable in that context.
**Suggestion:** Add a weighting note to Phase 6 (Judge Layer): "Awareness stage weighting — if brief indicates Level 1-2 (cold), weight Scroll-Stop Power and Curiosity Gap dimensions 1.5x when scoring Clayton and Carlton hooks. If Level 3-4 (problem-aware), weight Mechanism Tease and Education/Mechanism Clarity 1.5x for SA UPSYD and Dara founder scripts. If Level 5 (solution-aware/hot), weight Proof Integration and CTA Strength 1.5x." This makes the awareness stage input actionable rather than decorative.

### 3. Define project-folder naming convention and add a reference example
**Issue:** `[project-folder]` is referenced throughout the output file paths without definition. Students must guess where to save files. Additionally, no example output exists — a first-time runner has no reference for what the arena should produce.
**Suggestion:** Add a Phase 0 instruction: "Before running the arena, create a folder in your Obsidian Vault at: `03 Client Work/[Client]/Ad Copy/[Campaign Name] — Arena — [YYYY-MM-DD]/`. All output files save here. Use this path wherever `[project-folder]` appears." For the example: save one completed production package as a reference file at `.claude/skills/ad-copy-arena/examples/keep/example-001.md`. This also enables future calibration runs.

---

## Comparison: Run 1 vs. Run 2

| Dimension | Run 1 | Run 2 | Direction |
|-----------|-------|-------|-----------|
| Structural quality | 3.8 | 4.0 | improved |
| Output quality | 4.5 | 4.5 | flat |
| Integration quality | 3.5 | 3.9 | improved |
| Student-readiness | 3.6 | 3.8 | improved |
| Conversion effectiveness | 4.6 | 4.6 | flat |
| **Weighted total** | **4.01** | **4.17** | **improved** |

**Improved:** Structural quality, integration quality, student-readiness
**Flat:** Output quality, conversion effectiveness
**Regressed:** None

---

## Certification (Run 2)

| | |
|---|---|
| **Weighted score** | 4.17 / 5.0 |
| **Minimum threshold** | 4.0 / 5.0 |
| **Individual dimension minimum** | 3.0 / 5.0 |
| **Lowest individual dimension** | Integration quality: 3.9 |
| **Status** | PASS — all dimensions above 3.0, weighted score above 4.0 |

**Certified.** All three Run 1 must-fix items were addressed (2 complete, 1 partial). The remaining phase header conflict (PHASE 4 label on winner declaration section) is the single highest-priority fix before the next version release. The skill is production-ready at current state — the conflict is navigable by a careful reader, and the phase sequence map provides the correct reference. Improvements 2 and 3 above are the next highest-value items for a v2.2.0 release.

---

*Run 2 scorecard generated by skill-grader. Calibration confidence: low (no prior calibration examples found).*
