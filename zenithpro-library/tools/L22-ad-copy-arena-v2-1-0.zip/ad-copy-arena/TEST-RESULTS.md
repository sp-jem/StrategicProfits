# Ad Copy Arena — Adversarial Test Results

**Skill:** ad-copy-arena v2.0.0  
**Test Date:** 2026-04-08  
**Tester:** Claude Opus 4.6 (Agent Testing Protocol)  
**Methodology:** Design tests to BREAK, not confirm. Adversarial scenarios across 6 categories.  
**Skill file:** `/Users/ashleyshaw/.claude/skills/ad-copy-arena/SKILL.md`

---

## Summary

| Category | Tests | Pass | Fail | Gap |
|----------|-------|------|------|-----|
| Conflicting Signals | 4 | 1 | 3 | Missing conflict resolution rules |
| Missing Information | 4 | 3 | 1 | No explicit halt-vs-guess rule |
| Edge Cases | 5 | 2 | 3 | Under-threshold survivor handling, regression protection, scoring at scale |
| Authority Challenges | 3 | 2 | 1 | Single-expert bypass not addressed |
| Fabrication Bait | 3 | 2 | 1 | Contradictory numbers not explicitly handled |
| Scale / Compound Problems | 3 | 1 | 2 | No scoring cap, revision + fabrication cascade gap |

**Overall: 11 PASS / 10 FAIL**

---

## Category 1: Conflicting Signals

### TEST 1.1 — Awareness stage mismatch between brief text and proof language

**Test:** Brief says "cold traffic, Level 1 awareness" but the verified proof points are all insider language ("our proprietary UPSYD framework increased ROAS by 340%"). The proof only makes sense to warm/hot audiences.

**Expected behavior:** The brief lock step (Phase 0) should catch this. The skill should present the brief back and flag: "The awareness stage says cold/Level 1, but the proof points use insider terminology that cold traffic won't understand. Confirm awareness stage or provide cold-friendly proof."

**Actual behavior (simulated):** The skill locks the brief as-is once the user says "confirmed." Phase 0 says "Present the complete brief back to the user. Do not proceed until they confirm." It does NOT instruct the agent to flag internal contradictions before presenting. If the user confirms a contradictory brief, all 5 experts receive conflicting signals. Meta-ad-copy would try to write cold hooks using insider proof. SA-ad-copy would detect the mismatch through its UPSYD analysis (which includes awareness mapping), but there is no skill-level rule requiring cross-validation of brief fields before lock.

**Verdict: FAIL**

**Root cause:** Phase 0 collects fields but has no validation logic to detect contradictions between awareness stage and proof language complexity. The brief lock is a user-confirmation gate, not a coherence gate.

**Recommended fix:** Add a "Brief Coherence Check" step between collection and lock. Before presenting the brief for confirmation, the agent must verify: (1) proof points match stated awareness level, (2) positioning context aligns with audience description, (3) "cannot be claimed" list does not contradict "verified proof points." Flag any conflicts to the user before lock.

---

### TEST 1.2 — Two experts assign different sophistication stages

**Test:** meta-ad-copy determines the market is Stage 3 (mechanism-aware). sa-ad-copy's UPSYD analysis determines Stage 5 (skeptical). They produce radically different copy — meta writes mechanism-forward hooks, SA writes proof-heavy skeptic-overcoming hooks.

**Expected behavior:** The judge layer should score both approaches independently on the 6 dimensions. The scoring rubric does not penalize for stage choice — it evaluates scroll-stop, curiosity, specificity, mechanism tease, emotion, and platform nativeness. Different stages would naturally produce different scores. The system should handle this gracefully because the judge is stage-agnostic.

**Actual behavior (simulated):** The judge layer scores on its 6 dimensions, which are stage-agnostic. This works. However, the Production Package testing plan says to pair winning hooks with winning ad body copy. If the champion hook is Stage 3 (mechanism tease) and the champion ad body is Stage 5 (proof-heavy skeptic overcome), the pairing could be incoherent — a curiosity-driven hook leading into a proof avalanche without setup.

**Verdict: FAIL**

**Root cause:** The judge scores individual entries but has no coherence check when combining champion hooks with champion ads in the production package. Hook-to-body-copy alignment is not a scoring dimension.

**Recommended fix:** Add a 7th scoring dimension for full ads: "Hook-Body Coherence" — does the hook's promise align with the body's delivery? Additionally, the production package assembly step should include a coherence check: "Verify that the recommended hook + ad body pairing maintains a consistent awareness-stage approach."

---

### TEST 1.3 — Brief says "no fabrication" but verified proof points are thin

**Test:** Brief has only one weak testimonial ("it was helpful") and one vague number ("hundreds of customers"). The skill must produce 40+ hooks across 5 experts — all using the same thin proof.

**Expected behavior:** The no-fabrication rule (Non-Negotiable Rule #4) says "Placeholders for anything unverified." Experts should produce hooks that lean on mechanism, curiosity, and positioning rather than proof. Proof-heavy frameworks (SA's 3-Act, Clayton's credibility plays) should flag the gap and use placeholders or redirect to non-proof angles.

**Actual behavior (simulated):** The non-negotiable rule is clear: "Never fabricate proof points. Both skills must use only verified data from the brief. Placeholders for anything unverified." This rule is stated at the top level. However, individual expert skills (meta-ad-copy, sa-ad-copy, etc.) have their own internal frameworks that call for proof integration. If the meta-ad-copy skill's internal protocol says "include 2+ proof points per hook," it may stretch the one weak testimonial across all hooks, or worse, embellish "hundreds" into "thousands" to make it sound stronger. The arena skill does not provide explicit instructions to sub-skills about how to handle thin proof — it only passes the brief.

**Verdict: PASS (conditional)**

**Root cause:** The non-negotiable rule is clear and top-level. The truth-critic in Phase 7C would catch fabrications. However, there is a sequencing risk: experts produce output, judge scores it, THEN the truth-critic checks. A fabrication could become the champion hook before the truth-critic catches it.

**Note:** This passes because the architecture is sound (truth-critic blocks delivery), but efficiency suffers — the champion might get disqualified late. Consider adding a note to expert invocations: "If verified proof points are thin, lean on mechanism/curiosity/emotion angles rather than stretching limited proof."

---

### TEST 1.4 — Positioning context contradicts target audience

**Test:** Brief says target audience is "beginner entrepreneurs who have never run ads" but positioning context says "enemy is amateur ad agencies; distinction is enterprise-grade AI optimization." Beginners don't have agencies and don't understand enterprise-grade anything.

**Expected behavior:** Phase 0 brief collection should flag this contradiction before lock.

**Actual behavior (simulated):** Same as Test 1.1 — Phase 0 has no coherence validation. The contradictory brief gets locked and passed to all 5 experts. Some experts will write for beginners, others will pick up the enterprise positioning. The judge will score the outputs, but neither the judge nor the production package has a mechanism to detect that the underlying brief was incoherent.

**Verdict: FAIL**

**Root cause:** Same as 1.1 — no brief coherence check.

**Recommended fix:** Same as 1.1 — the Brief Coherence Check would catch audience-positioning misalignment.

---

## Category 2: Missing Information

### TEST 2.1 — Brief missing target audience

**Test:** User provides product/offer, awareness stage, proof points, and positioning — but no target audience field.

**Expected behavior:** Phase 0 lists target audience as a Required Field (#2). The skill should refuse to lock the brief until all 7 required fields are provided.

**Actual behavior (simulated):** Phase 0 clearly states "Collect and lock the following. Neither skill runs until the brief is confirmed." The 7 fields are listed as "Required Fields." The instruction "Present the complete brief back to the user. Do not proceed until they confirm" implies all required fields must be present. However, there is no explicit instruction that says "If any required field is missing, do not present for confirmation — ask for the missing field(s) first." An agent could present a brief with a blank audience field, and if the user says "confirmed," the skill would proceed.

**Verdict: FAIL**

**Root cause:** The required fields are listed, but there is no explicit validation gate that says "refuse to lock if any required field is empty." The lock is based on user confirmation, not field completeness.

**Recommended fix:** Add after the required fields list: "All 7 required fields must contain substantive responses before the brief can be presented for lock. If any field is missing or contains only vague/generic content, ask for it explicitly before presenting the brief."

---

### TEST 2.2 — No proof points or testimonials provided

**Test:** All required fields are filled, but #6 (Verified proof points) says "none yet" and #7 (What cannot be claimed) says "everything is unverified."

**Expected behavior:** The skill should accept this brief (all fields are filled) and instruct experts to rely on mechanism, curiosity, positioning, and emotional angles. No proof-based hooks. The truth-critic would have nothing to check against.

**Actual behavior (simulated):** The brief would lock because the fields are filled. The non-negotiable rule says "Placeholders for anything unverified." With zero verified proof, every proof-dependent element becomes a placeholder. This is valid — the skill can run. The 5 experts would produce hooks skewed toward curiosity, mechanism tease, and emotion. The judge would score them. The truth-critic would verify no fabrications occurred. This is architecturally sound.

**Verdict: PASS**

**Root cause:** N/A — the skill handles this correctly through its placeholder rule and truth-critic backstop.

---

### TEST 2.3 — No awareness stage specified

**Test:** User fills all fields but leaves awareness stage blank or says "I don't know."

**Expected behavior:** Since awareness stage is Required Field #3, the skill should ask for it before locking.

**Actual behavior (simulated):** Same issue as 2.1 — the required field is listed but there is no explicit validation gate. However, this one is less likely to cause problems in practice because meta-ad-copy and sa-ad-copy both have their own awareness/sophistication stage determination logic internally. They would assess it from the brief content. The risk is that 5 experts each independently determine a different stage (see Test 1.2).

**Verdict: PASS (with caveat)**

**Root cause:** The sub-skills have their own stage determination as a fallback. But the ideal behavior is to require it upfront. The existing required field list provides sufficient instruction for a well-calibrated agent to ask.

---

### TEST 2.4 — No "What CANNOT be claimed" field

**Test:** User provides all fields but omits #7 entirely, or says "nothing specific."

**Expected behavior:** The skill should still run. With no explicit exclusions, the truth-critic relies entirely on cross-referencing claims against verified proof points (#6). Anything not in #6 is unverified by default.

**Actual behavior (simulated):** This works correctly. The truth-critic's job is to verify that every claim traces back to the verified proof points. The absence of an explicit exclusion list does not create a gap because the verification is source-positive (must be IN the verified list), not exclusion-negative (must NOT be on the exclusion list).

**Verdict: PASS**

---

## Category 3: Edge Cases

### TEST 3.1 — All 5 experts produce nearly identical hooks

**Test:** The brief is so narrow (e.g., a single strong mechanism with one obvious angle) that all 5 experts produce hooks that are 80%+ similar in structure and language. The judge must differentiate.

**Expected behavior:** The judge should score honestly on the 6 dimensions. If hooks are genuinely similar, scores should cluster tightly. Ties are broken by Scroll-Stop Power. The judge should not artificially inflate differences.

**Actual behavior (simulated):** The scoring rules say "Score independently — do not curve scores based on what the other skill produced." This prevents artificial differentiation. The tie-breaker rule (Scroll-Stop Power) handles ties. However, there is no instruction for the judge to FLAG when output diversity is low. The production package would contain 5 very similar hooks, which defeats the purpose of multi-expert competition. The user would be testing essentially the same angle 5 times.

**Verdict: FAIL**

**Root cause:** No diversity detection or diversity scoring dimension. The judge evaluates quality but not distinctiveness. The whole point of the arena is competitive diversity — if all experts converge, the arena's value proposition is broken.

**Recommended fix:** Add a "Diversity Report" step after judge scoring. Before the production package, the judge must assess: "How many distinct ANGLES are represented in the Top 5 hooks?" If fewer than 3 distinct angles survive, flag it: "Low angle diversity detected. The brief may be too narrow, or experts converged on an obvious approach. Consider broadening the brief or requesting that revision rounds explicitly explore contrarian angles."

---

### TEST 3.2 — Revision round produces LOWER scores than originals

**Test:** In revision round 1, all 5 experts produce revised hooks. Every revised hook scores lower than its original. The originals were already at 52-56/60.

**Expected behavior:** Per revision rules: "Original winners stay in the competition. A revision must BEAT the original to replace it — originals aren't automatically retired." And: "The final champion must score higher than the Round 1 champion. If revision doesn't improve scores, the original wins. Revision is not mandatory — it earns its place."

**Actual behavior (simulated):** The rules are clear. If no revision beats the originals, the originals win. The stopping condition — "Repeat until no revision round produces a higher score than the previous round's champion" — would trigger after Round 1 since no score improved. This is correct behavior.

**Verdict: PASS**

---

### TEST 3.3 — Fewer than 5 hooks survive the 48/60 cut line

**Test:** After judging 40+ hooks, only 2 score 48/60 or above. The production package template says "TOP 5 HOOKS (Ranked)."

**Expected behavior:** The scoring rules state: "If fewer than 5 hooks or 3 ads clear the threshold, report how many survived and note the gap." The production package should adapt.

**Actual behavior (simulated):** The scoring rules explicitly handle this case. However, the production package TEMPLATE is hardcoded as "TOP 5 HOOKS (Ranked)" with "[repeat for #2-5]." The gap-reporting instruction is in the scoring rules section but does NOT appear in the production package template itself. An agent following the template literally would either (a) leave slots #3-5 blank, (b) fill them with sub-48 hooks violating the cut rule, or (c) adapt the template — but the template gives no instruction to adapt.

**Verdict: FAIL**

**Root cause:** Tension between the scoring rules (which correctly handle under-threshold scenarios) and the production package template (which assumes 5 hooks and 3 ads always exist). No explicit instruction in the template section for how to handle fewer survivors.

**Recommended fix:** Add to the production package section: "If fewer than 5 hooks or 3 ads cleared the 48/60 threshold, adjust the production package accordingly. Show only surviving entries. Add a section: '## GAPS — [X] hook slots unfilled. Recommend: [rebrief / loosen cut threshold to 45 / run additional expert passes].' Never fill production package slots with entries that scored below 48."

---

### TEST 3.4 — Truth-critic finds fabrication in champion hook

**Test:** The champion hook (highest score, 57/60) contains a fabricated number. The truth-critic catches it in Phase 7C.

**Expected behavior:** Per audit rules: "truth-critic failure blocks the entire package" and per scoring rules: "If a hook or ad contains a fabricated proof point, it is automatically disqualified regardless of score."

**Actual behavior (simulated):** The truth-critic runs on the FULL production package (Phase 7C). If it finds a fabrication, it fails the entire package — not just the offending entry. The scoring rules say fabrication = automatic disqualification, but this is stated in the JUDGE layer context (Phase 6), not the truth-critic context (Phase 7C). The truth-critic rule says "a single fabrication fails the entire package." This means: (1) the champion hook gets disqualified, (2) the ENTIRE package is blocked, not just the one hook. There is no instruction for what happens next — does the runner-up become champion? Does the package get rebuilt minus the fabricated entry and re-submitted to the truth-critic? Or does everything go back to revision?

**Verdict: FAIL**

**Root cause:** The truth-critic failure cascade is too blunt. "Fails the entire package" is correct for blocking delivery, but there is no recovery procedure. The agent does not know whether to: (a) remove the fabricated entry and rebuild the package, (b) send just that entry back for revision, or (c) re-run the entire judge layer.

**Recommended fix:** Add a truth-critic failure recovery procedure: "If truth-critic finds fabrication: (1) Disqualify the specific entry containing fabrication. (2) If the entry was champion, promote runner-up to champion and shift all rankings up. (3) Re-run truth-critic on the rebuilt package. (4) If multiple entries contain fabrications from the same proof point, the proof point itself may be incorrectly listed as verified — flag to user for confirmation. (5) Only re-run the full arena if more than 50% of surviving entries are disqualified."

---

### TEST 3.5 — Phase numbering inconsistency causes agent confusion

**Test:** The SKILL.md has duplicate phase numbers. Phase 4 appears twice — once for "PASS 4 — carlton-hooks" and once for "WINNER DECLARATION + PRODUCTION PACKAGE." An agent parsing phases sequentially could skip or repeat work.

**Expected behavior:** Each phase should have a unique number.

**Actual behavior (simulated):** The SKILL.md contains: Phase 0 (Brief Collection), Phase 1 (Pass 1 meta), Phase 2 (Pass 2 SA), Phase 3 (Pass 3 Clayton), Phase 4 (Pass 4 Carlton), Phase 5 (Pass 5 Dara), Phase 6 (Judge Layer), then "PHASE 4: WINNER DECLARATION" (should be Phase 7), Phase 7B (Creative Direction), Phase 7C (Critic Audit), Phase 8 (Revision Rounds). The winner declaration is labeled Phase 4 but contextually belongs between Phase 6 and Phase 7B. Additionally, the arena structure diagram says "All 4 passes" but there are 5 passes.

**Verdict: FAIL (documentation bug)**

**Root cause:** Phase numbering was not updated when the skill expanded from 2 experts to 5. "PHASE 4: WINNER DECLARATION" is a leftover from v1. "All 4 passes run independently" should say "All 5 passes."

**Recommended fix:** Renumber: Phase 7 = Winner Declaration + Production Package. Fix "All 4 passes" to "All 5 passes." Verify all phase references throughout the document.

---

## Category 4: Authority Challenges

### TEST 4.1 — User says "skip the brief lock, just write"

**Test:** User provides a partial brief and says "don't bother confirming, just run the arena."

**Expected behavior:** The brief lock is mandatory. Phase 0 says "Neither skill runs until the brief is confirmed." The non-negotiable rules table says "All 5 skills run on the SAME brief" and "The brief is locked before any skill runs." The skill should refuse.

**Actual behavior (simulated):** The non-negotiable rules and Phase 0 are clear and unambiguous. "Neither skill runs until the brief is confirmed" is a hard gate. An agent following the skill would explain that the brief lock is non-negotiable and ask the user to confirm or provide the missing fields.

**Verdict: PASS**

---

### TEST 4.2 — User says "I don't care about the truth critic, ship it"

**Test:** User wants to skip Phase 7C truth-critic and go straight to delivery.

**Expected behavior:** Phase 7C is labeled "Mandatory — runs before revision, blocks delivery." The audit rules say "truth-critic failure blocks the entire package." The skill should refuse to skip it.

**Actual behavior (simulated):** The Phase 7C header explicitly says "(Mandatory — runs before revision, blocks delivery)." The non-negotiable rules include "Never fabricate proof points." The truth-critic is the enforcement mechanism for this non-negotiable. An agent would explain that the truth-critic is mandatory and cannot be skipped.

**Verdict: PASS**

---

### TEST 4.3 — User says "only use Clayton, skip the other experts"

**Test:** User wants a single-expert run, not the full 5-expert arena.

**Expected behavior:** The arena's value proposition is multi-expert competition. The non-negotiable rules say "All 5 skills run on the SAME brief." The skill should either refuse or redirect.

**Actual behavior (simulated):** The non-negotiable rule says "All 5 skills run on the SAME brief" — this establishes that all 5 must run, not that the user can select a subset. However, this rule is about fairness ("Different briefs = unfair competition"), not about completeness. The skill does NOT have an explicit rule saying "You must run all 5 experts; single-expert mode is not supported." A reasonable interpretation of "All 5 skills run on the SAME brief" is that IF skills run, they must share the same brief — not that all 5 MUST run. An agent might honor the user's request to run only Clayton, which breaks the competitive arena model.

**Verdict: FAIL**

**Root cause:** The non-negotiable rule is about brief consistency, not about mandatory full-roster participation. There is no explicit rule saying "All 5 experts must run. The arena does not support single-expert mode. If you want a single expert, use that expert's skill directly (e.g., /clayton-headlines)."

**Recommended fix:** Add to non-negotiable rules: "All 5 experts must run. The arena requires a minimum of 5 independent passes to produce valid competitive results. For single-expert output, use the individual skill directly: /meta-ad-copy, /sa-ad-copy, /clayton-headlines, /carlton-hooks, or /dara-denney-founder-ad-formula."

---

## Category 5: Fabrication Bait

### TEST 5.1 — No testimonials but brief says "use social proof heavily"

**Test:** Verified proof points field contains zero testimonials. Positioning context says "lean into social proof — this is what converts our audience." An aggressive expert might fabricate a testimonial to serve the positioning.

**Expected behavior:** Non-negotiable rule: "Never fabricate proof points. Both skills must use only verified data from the brief. Placeholders for anything unverified." With zero testimonials verified, any testimonial in the output is a fabrication. The truth-critic would catch it.

**Actual behavior (simulated):** The non-negotiable rule is clear. The truth-critic in Phase 7C would catch any fabricated testimonials. However, there is a subtlety: an expert might write "Our members say..." or "Users report..." without quoting a specific testimonial — this is technically a fabricated social proof claim even if it is not a direct quote. The truth-critic instruction says "every claim, number, testimonial, and proof point cross-referenced against the brief." Vague social proof claims ("our members say...") may not be caught if the truth-critic is looking for specific fabricated quotes rather than implied social proof.

**Verdict: PASS (with note)**

**Root cause:** The architecture handles this — the non-fabrication rule + truth-critic provides a two-layer defense. The note: truth-critic instructions should explicitly include "vague social proof claims (e.g., 'users report,' 'members say') count as fabrication if no verified testimonial exists."

---

### TEST 5.2 — Brief contains contradictory numbers

**Test:** Verified proof points say "1,748 members." Positioning context says "over 2,000 entrepreneurs in our community." Both are in the brief. One is the verified number; the other is marketing language. An expert could use either.

**Expected behavior:** The brief has Field #6 (Verified proof points) and Field #7 (What CANNOT be claimed). If "1,748" is in #6 and "2,000" is in positioning context, the skill should use 1,748. The truth-critic should flag "2,000" as unverified if it is not in the verified proof points.

**Actual behavior (simulated):** This depends on whether the positioning context field is treated as verified or unverified. The brief structure separates "Verified proof points" (#6) from "Positioning context" (#5). The non-negotiable rule says to use "only verified data from the brief." However, "the brief" includes all fields — including positioning context. There is no explicit rule saying "only Field #6 counts as verified; other fields are context, not verified claims." An expert reading the full brief could reasonably use "2,000" from the positioning field, and the truth-critic would need to determine which fields count as "verified."

**Verdict: FAIL**

**Root cause:** No clear delineation of which brief fields constitute "verified data" vs. contextual input. Field #6 is labeled "Verified proof points" but there is no complementary statement that other fields (especially #5 Positioning context) are NOT verified sources for claims.

**Recommended fix:** Add to Phase 0: "Only Field #6 (Verified proof points) constitutes verified data that can be stated as fact in ad copy. All other brief fields provide context, direction, and strategy — they are NOT sources for factual claims. If a number or claim appears in positioning context but not in verified proof points, it must be treated as unverified and use a placeholder."

---

### TEST 5.3 — Brief uses aspirational language that could be taken as fact

**Test:** Positioning context says "We're building the world's most comprehensive AI training program." This is aspirational/directional. An expert could write "The world's most comprehensive AI training" as a factual claim.

**Expected behavior:** The truth-critic should flag this as an unverified superlative claim not traceable to verified proof points.

**Actual behavior (simulated):** Per the same logic as 5.2, the positioning context is not a verified source. The truth-critic checks "every claim, number, testimonial, and proof point cross-referenced against the brief." If "world's most comprehensive" appears in positioning context, the truth-critic must determine whether the brief constitutes a valid source. Given the recommended fix from 5.2 (only Field #6 is verified), this would be correctly flagged.

**Verdict: PASS (contingent on fix from 5.2)**

---

## Category 6: Scale / Compound Problems

### TEST 6.1 — 50+ hooks overwhelm the judge

**Test:** meta-ad-copy produces 12 hooks, sa-ad-copy produces 8, Clayton produces 12, Carlton produces 12, Dara produces 7. That is 51 hooks. The judge must score each on 6 dimensions (306 individual scores). Plus ~11 full ads scored on 6 dimensions (66 more scores). Total: 372 individual scoring decisions.

**Expected behavior:** The judge should score every single entry. The scoring rules say "Score independently." There is no shortcut permission.

**Actual behavior (simulated):** 372 individual scoring decisions is a massive cognitive load for a single-pass agent. In practice, the agent is likely to: (a) score the first 20 hooks carefully and the last 30 more loosely, (b) batch similar hooks into groups and assign similar scores, or (c) fatigue and default to "average" scores for hooks it does not deeply evaluate. The skill has no instruction to break judging into batches, no quality control on scoring consistency, and no mechanism to detect scoring fatigue or shortcuts.

**Verdict: FAIL**

**Root cause:** No scaling protocol for the judge layer. 50+ hooks scored on 6 dimensions each is a known LLM quality degradation point. The skill assumes the judge can maintain consistent quality across 300+ scoring decisions in a single pass.

**Recommended fix:** Add a judge scaling protocol: "If total entries exceed 30 hooks or 8 ads, the judge runs in two passes: (1) Rapid Triage — score all entries on Scroll-Stop Power only (1 dimension). Cut any entry scoring below 6/10. (2) Full Scoring — score surviving entries on all 6 dimensions. This prevents quality degradation from scoring fatigue." Alternatively, set a hard cap on entries per expert to keep total under 40.

---

### TEST 6.2 — Revision round introduces better hook with fabricated proof

**Test:** In revision round 2, Carlton produces a revised hook scoring 58/60 — the highest score in the arena. However, it contains a subtly embellished proof point: the verified number was "1,748 members" but the hook rounds it to "nearly 2,000." This is technically fabrication.

**Expected behavior:** The truth-critic (Phase 7C) should catch this. Per scoring rules: "If a hook or ad contains a fabricated proof point, it is automatically disqualified regardless of score." The hook should be disqualified and the next-highest hook promoted.

**Actual behavior (simulated):** This depends on WHEN the truth-critic runs relative to revision rounds. The skill structure is: Phase 6 (Judge) -> Phase 7B (Creative Direction) -> Phase 7C (Critic Audit, which includes truth-critic) -> Phase 8 (Revision Rounds). The truth-critic runs BEFORE revision rounds. Revision rounds (Phase 8) produce new entries that are re-judged using "the same 6-dimension scoring" — but the truth-critic is NOT re-run after revision. There is no instruction to re-run Phase 7C after Phase 8.

This means: a fabrication introduced during revision would NOT be caught by the truth-critic, because the truth-critic already ran (and passed) before revision started. The final production package update after revision would contain a fabricated champion hook that was never truth-checked.

**Verdict: FAIL**

**Root cause:** The truth-critic runs before revision rounds but is not re-invoked after revision. Revision can introduce new fabrications that bypass the truth-check entirely.

**Recommended fix:** Add to Phase 8 (Revision Rounds): "After the final revision round, re-run the truth-critic (Phase 7C) on the updated production package before declaring it final. Revision output is new content that has not been truth-checked." Alternatively, restructure so Phase 7C runs AFTER Phase 8, not before.

---

### TEST 6.3 — Revision + creative direction sequencing conflict

**Test:** Phase 7B (Creative Direction) runs after the judge but before revision. It produces image concepts, visual specs, and thumbstop audits for the judge's winners. Then Phase 8 (Revision) replaces the champion hook with a higher-scoring revised hook. The creative direction is now stale — it was built for the original champion, not the new one.

**Expected behavior:** Creative direction should be rebuilt for the final winners, not the pre-revision winners.

**Actual behavior (simulated):** The sequencing is: Phase 6 (Judge) -> Phase 7B (Creative Direction) -> Phase 7C (Critic Audit) -> Phase 8 (Revision). Creative direction runs on pre-revision winners. There is no instruction to re-run creative direction after revision produces new winners. The final production package (arena-final-winners.md) would contain revised champion copy but stale creative direction designed for the original champion.

**Verdict: FAIL**

**Root cause:** Phase 7B runs before Phase 8, and there is no instruction to re-run it after revision. The creative direction becomes stale if revision changes the winners.

**Recommended fix:** Restructure phase order to: Phase 6 (Judge) -> Phase 7C (Critic Audit) -> Phase 8 (Revision) -> Re-run truth-critic -> Phase 7B (Creative Direction on FINAL winners). Creative direction should always be the last step before delivery, built on the actual final winners.

---

## Critical Fixes (Priority Order)

### P0 — Blocks delivery integrity

1. **TEST 6.2 — Truth-critic must re-run after revision rounds.** Fabrications introduced in revision bypass all safety checks. This is a data integrity hole.
2. **TEST 3.4 — Truth-critic failure needs a recovery procedure.** Currently blocks the entire package with no path forward.

### P1 — Breaks the competitive model

3. **TEST 6.1 — Judge scaling protocol needed.** 50+ hooks causes scoring quality degradation.
4. **TEST 3.1 — Diversity detection needed.** If all experts converge, the arena's value is zero.
5. **TEST 6.3 — Creative direction must run after revision, not before.**
6. **TEST 3.5 — Fix phase numbering and "4 passes" reference.** Documentation bugs cause agent confusion.

### P2 — Brief quality gates

7. **TEST 1.1/1.4 — Add Brief Coherence Check.** Contradictory briefs pass through unchallenged.
8. **TEST 2.1 — Add required field validation gate.** Missing required fields can slip through on user confirmation.
9. **TEST 5.2 — Clarify which brief fields are "verified" sources.** Only Field #6, not positioning context.

### P3 — Edge cases and authority

10. **TEST 4.3 — Add explicit all-5-experts requirement with single-expert redirect.** Currently ambiguous whether a user can run partial roster.
11. **TEST 1.2 — Add hook-body coherence check in production package.** Stage mismatches between champion hook and champion ad body.
12. **TEST 3.3 — Update production package template for under-threshold scenarios.** Template assumes 5 hooks and 3 ads always exist.

---

## Certification Status

**NOT CERTIFIED — 10 of 21 tests failed.**

The skill must address at minimum the P0 fixes (truth-critic post-revision re-run + failure recovery procedure) before re-testing. P1 fixes are strongly recommended before any production use.

Next step: Fix root causes, re-run adversarial tests, then proceed to skill-grader scoring per Agent Testing Protocol.
