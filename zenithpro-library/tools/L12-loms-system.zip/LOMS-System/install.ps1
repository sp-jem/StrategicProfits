# LOMS System Installer for Windows
# Installs all 5 LOMS skills for automated content harvesting

$ErrorActionPreference = "Stop"

$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path
$SKILLS_DIR = "$env:USERPROFILE\.claude\skills"
$DEFAULT_LIBRARY = "$env:USERPROFILE\Documents\LOMS-Library"

Write-Host ""
Write-Host "==================================" -ForegroundColor Cyan
Write-Host "LOMS System Installer" -ForegroundColor Cyan
Write-Host "==================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Installing 5 skills:"
Write-Host "  - loms-run (orchestrator)"
Write-Host "  - loms-capture"
Write-Host "  - loms-analyze"
Write-Host "  - loms-package"
Write-Host "  - loms-curate"
Write-Host ""

# Check if any LOMS skills already exist
$existing = @()
$skills = @("loms-run", "loms-capture", "loms-analyze", "loms-package", "loms-curate")
foreach ($skill in $skills) {
    if (Test-Path "$SKILLS_DIR\$skill") {
        $existing += $skill
    }
}

if ($existing.Count -gt 0) {
    Write-Host "Warning: These skills already exist: $($existing -join ', ')" -ForegroundColor Yellow
    $response = Read-Host "Overwrite? (y/N)"
    if ($response -ne "y" -and $response -ne "Y") {
        Write-Host "Installation cancelled"
        exit 0
    }
}

# Create skills directory if needed
if (!(Test-Path $SKILLS_DIR)) {
    New-Item -ItemType Directory -Force -Path $SKILLS_DIR | Out-Null
}

# Install each skill
foreach ($skill in $skills) {
    Write-Host "Installing $skill..."

    # Remove existing if present
    if (Test-Path "$SKILLS_DIR\$skill") {
        Remove-Item -Recurse -Force "$SKILLS_DIR\$skill"
    }

    # Create skill directory and copy
    New-Item -ItemType Directory -Force -Path "$SKILLS_DIR\$skill" | Out-Null
    Copy-Item "$SCRIPT_DIR\skills\$skill\SKILL.md" "$SKILLS_DIR\$skill\"

    Write-Host "  Installed $skill" -ForegroundColor Green
}

# Install or update config file
$CONFIG_FILE = "$SKILLS_DIR\loms-config.json"
if (Test-Path $CONFIG_FILE) {
    Write-Host ""
    Write-Host "Config file already exists at $CONFIG_FILE"
    Write-Host "Keeping existing configuration."
    # Read existing library_base
    $config = Get-Content $CONFIG_FILE | ConvertFrom-Json
    $LIBRARY_BASE = $config.library_base -replace "~", $env:USERPROFILE
} else {
    Write-Host ""
    Write-Host "Creating config file..."
    Copy-Item "$SCRIPT_DIR\skills\loms-config.json" $CONFIG_FILE
    $LIBRARY_BASE = $DEFAULT_LIBRARY
    Write-Host "  Config saved to $CONFIG_FILE" -ForegroundColor Green
}

# Expand ~ in LIBRARY_BASE if present
$LIBRARY_BASE = $LIBRARY_BASE -replace "~", $env:USERPROFILE

# Create library directory structure
Write-Host ""
Write-Host "Creating library directory structure..."
Write-Host "  Location: $LIBRARY_BASE"
New-Item -ItemType Directory -Force -Path "$LIBRARY_BASE\library\daily" | Out-Null
New-Item -ItemType Directory -Force -Path "$LIBRARY_BASE\library\processed" | Out-Null
New-Item -ItemType Directory -Force -Path "$LIBRARY_BASE\library\packages\skills" | Out-Null
New-Item -ItemType Directory -Force -Path "$LIBRARY_BASE\library\packages\documentation" | Out-Null
New-Item -ItemType Directory -Force -Path "$LIBRARY_BASE\library\packages\patterns" | Out-Null
New-Item -ItemType Directory -Force -Path "$LIBRARY_BASE\library\harvest" | Out-Null

Write-Host ""
Write-Host "==================================" -ForegroundColor Green
Write-Host "Installation Complete!" -ForegroundColor Green
Write-Host "==================================" -ForegroundColor Green
Write-Host ""
Write-Host "Skills installed to: $SKILLS_DIR"
Write-Host "  - loms-run"
Write-Host "  - loms-capture"
Write-Host "  - loms-analyze"
Write-Host "  - loms-package"
Write-Host "  - loms-curate"
Write-Host ""
Write-Host "Config file: $CONFIG_FILE"
Write-Host ""
Write-Host "Library created at:"
Write-Host "  $LIBRARY_BASE"
Write-Host ""
Write-Host "To change the library location, edit:" -ForegroundColor Yellow
Write-Host "  $CONFIG_FILE"
Write-Host ""
Write-Host "USAGE:" -ForegroundColor Yellow
Write-Host ""
Write-Host "At the end of your work day, run:"
Write-Host "  /loms"
Write-Host ""
Write-Host "Or tell Claude:"
Write-Host '  "Run the LOMS pipeline"'
Write-Host ""
Write-Host "==================================" -ForegroundColor Cyan
