#!/bin/bash
# LOMS System Installer for Mac/Linux
# Installs all 5 LOMS skills for automated content harvesting

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILLS_DIR="$HOME/.claude/skills"
DEFAULT_LIBRARY="$HOME/Documents/LOMS-Library"

echo ""
echo "=================================="
echo "LOMS System Installer"
echo "=================================="
echo ""
echo "Installing 5 skills:"
echo "  - loms-run (orchestrator)"
echo "  - loms-capture"
echo "  - loms-analyze"
echo "  - loms-package"
echo "  - loms-curate"
echo ""

# Check if any LOMS skills already exist
EXISTING=""
for skill in loms-run loms-capture loms-analyze loms-package loms-curate; do
    if [ -d "$SKILLS_DIR/$skill" ]; then
        EXISTING="$EXISTING $skill"
    fi
done

if [ -n "$EXISTING" ]; then
    echo "Warning: These skills already exist:$EXISTING"
    read -p "Overwrite? (y/N) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Installation cancelled"
        exit 1
    fi
fi

# Create skills directory if needed
mkdir -p "$SKILLS_DIR"

# Install each skill
for skill in loms-run loms-capture loms-analyze loms-package loms-curate; do
    echo "Installing $skill..."

    # Remove existing if present
    rm -rf "$SKILLS_DIR/$skill"

    # Create skill directory and copy
    mkdir -p "$SKILLS_DIR/$skill"
    cp "$SCRIPT_DIR/skills/$skill/SKILL.md" "$SKILLS_DIR/$skill/"

    echo "  Installed $skill"
done

# Install or update config file
CONFIG_FILE="$SKILLS_DIR/loms-config.json"
if [ -f "$CONFIG_FILE" ]; then
    echo ""
    echo "Config file already exists at $CONFIG_FILE"
    echo "Keeping existing configuration."
    # Read existing library_base
    LIBRARY_BASE=$(grep -o '"library_base"[[:space:]]*:[[:space:]]*"[^"]*"' "$CONFIG_FILE" | sed 's/.*: *"//' | sed 's/"//' | sed "s|~|$HOME|")
else
    echo ""
    echo "Creating config file..."
    cp "$SCRIPT_DIR/skills/loms-config.json" "$CONFIG_FILE"
    LIBRARY_BASE="$DEFAULT_LIBRARY"
    echo "  Config saved to $CONFIG_FILE"
fi

# Expand ~ in LIBRARY_BASE if present
LIBRARY_BASE="${LIBRARY_BASE/#\~/$HOME}"

# Create library directory structure
echo ""
echo "Creating library directory structure..."
echo "  Location: $LIBRARY_BASE"
mkdir -p "$LIBRARY_BASE/library/daily"
mkdir -p "$LIBRARY_BASE/library/processed"
mkdir -p "$LIBRARY_BASE/library/packages/skills"
mkdir -p "$LIBRARY_BASE/library/packages/documentation"
mkdir -p "$LIBRARY_BASE/library/packages/patterns"
mkdir -p "$LIBRARY_BASE/library/harvest"

echo ""
echo "=================================="
echo "Installation Complete!"
echo "=================================="
echo ""
echo "Skills installed to: $SKILLS_DIR"
echo "  - loms-run"
echo "  - loms-capture"
echo "  - loms-analyze"
echo "  - loms-package"
echo "  - loms-curate"
echo ""
echo "Config file: $CONFIG_FILE"
echo ""
echo "Library created at:"
echo "  $LIBRARY_BASE"
echo ""
echo "To change the library location, edit:"
echo "  $CONFIG_FILE"
echo ""
echo "USAGE:"
echo ""
echo "At the end of your work day, run:"
echo '  /loms'
echo ""
echo "Or tell Claude:"
echo '  "Run the LOMS pipeline"'
echo ""
echo "=================================="
