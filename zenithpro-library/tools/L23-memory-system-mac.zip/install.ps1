#
# Memory System — Windows Installer
# Installs the setup-memory-system skill and its Python files.
#

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "Memory System — Installer" -ForegroundColor White -BackgroundColor DarkBlue
Write-Host "================================"
Write-Host ""

$SkillsDir = "$env:USERPROFILE\.claude\skills"

# Check Claude Code skills directory exists
if (-not (Test-Path $SkillsDir)) {
    Write-Host "  ⚠ Skills directory not found at $SkillsDir" -ForegroundColor Yellow
    Write-Host "  Creating it now..."
    New-Item -ItemType Directory -Path $SkillsDir -Force | Out-Null
}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Installed = 0
$Skipped = 0

# Ensure credentials directory exists
$CredsDir = "$env:USERPROFILE\.claude\credentials"
New-Item -ItemType Directory -Path $CredsDir -Force | Out-Null
Write-Host "  ✓ Credentials directory ready at $CredsDir" -ForegroundColor Green

# Install the setup skill
$Skill = "setup-memory-system"
$SkillSource = Join-Path $ScriptDir $Skill
$SkillDest = Join-Path $SkillsDir $Skill

if (Test-Path $SkillSource) {
    if (Test-Path $SkillDest) {
        Write-Host "  ⚠ $Skill already exists — replacing" -ForegroundColor Yellow
        Remove-Item -Recurse -Force $SkillDest
    }
    Copy-Item -Recurse $SkillSource $SkillDest
    Write-Host "  ✓ Installed $Skill skill" -ForegroundColor Green
    $Installed++
} else {
    Write-Host "  ✗ $Skill not found in installer directory" -ForegroundColor Red
    $Skipped++
}

# Copy Python files to the skill's references directory
if (Test-Path $SkillDest) {
    $RefDir = Join-Path $SkillDest "references"
    New-Item -ItemType Directory -Path $RefDir -Force | Out-Null

    $PyFiles = @("memory-agent-fm.py", "brain_memory_bridge_fm.py", "brain_briefing.py", "verify-memory-system.py")
    foreach ($PyFile in $PyFiles) {
        $Source = Join-Path $ScriptDir $PyFile
        if (Test-Path $Source) {
            Copy-Item $Source (Join-Path $RefDir $PyFile)
            Write-Host "  ✓ Copied $PyFile" -ForegroundColor Green
            $Installed++
        } else {
            Write-Host "  ✗ $PyFile not found in installer directory" -ForegroundColor Red
            $Skipped++
        }
    }
} else {
    Write-Host "  ✗ Skipping Python file copy — skill directory was not installed" -ForegroundColor Red
    $Skipped += 4
}

Write-Host ""
Write-Host "================================"
Write-Host "Installation complete!" -ForegroundColor Green
Write-Host ""
Write-Host "  Installed: $Installed items"
if ($Skipped -gt 0) { Write-Host "  Skipped:   $Skipped items (check errors above)" -ForegroundColor Yellow }
Write-Host ""
Write-Host "  Next step:"
Write-Host "    Open Claude Code and tell it: 'Run setup-memory-system'"
Write-Host ""
Write-Host "  The setup skill will:"
Write-Host "    1. Verify your Day 6 infrastructure is ready"
Write-Host "    2. Install the memory agent, bridge, and briefing generator"
Write-Host "    3. Provide instructions for running the daemon"
Write-Host "    4. Run verification"
Write-Host ""
Write-Host "  Prerequisites (from Day 6):"
Write-Host "    - setup-brain completed"
Write-Host "    - Anthropic API key in ~/.claude/credentials/anthropic-linker.env"
Write-Host "    - Python 3 with anthropic package"
Write-Host ""
