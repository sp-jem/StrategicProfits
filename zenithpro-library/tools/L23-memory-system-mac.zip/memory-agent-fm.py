#!/usr/bin/env python3
"""
Memory Agent for Force Multiplier
Watches Claude Code sessions, extracts structured memories using Haiku,
consolidates them, and stores them in memory-store.json.

Runs as a launchd daemon. Never writes to brain-state.json.
Owns memory-store.json exclusively.
"""

import copy
import hashlib
import json
import os
import queue
import re
import shutil
import signal
import sys
import threading
import time
from datetime import datetime, date, timezone

# Add parent dir for config/brain_config imports
_this_dir = os.path.dirname(os.path.abspath(__file__))
if _this_dir not in sys.path:
    sys.path.insert(0, _this_dir)
_brain_dir = os.path.join(_this_dir, "brain")
if _brain_dir not in sys.path:
    sys.path.insert(0, _brain_dir)

try:
    import config
    import brain_config
except ImportError as e:
    print(f"\nERROR: Required module not found: {e}")
    print("The memory agent requires config.py and brain_config.py from the Day 6 setup.")
    print("Please complete /setup-brain before running memory-agent-fm.py.\n")
    sys.exit(1)

log = config.setup_logging("memory-agent")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
MEMORY_STORE_PATH = os.path.join(brain_config.DATA_DIR, "memory-store.json")

# Claude Code session JSONL directories to scan — auto-detected
def _auto_detect_session_dirs():
    """Auto-detect all Claude Code project directories."""
    base = os.path.expanduser("~/.claude/projects/")
    dirs = []
    if os.path.isdir(base):
        for entry in os.listdir(base):
            full = os.path.join(base, entry)
            if os.path.isdir(full):
                dirs.append(full)
    if not dirs:
        dirs = [base]  # Fallback: watch the base dir itself
    return dirs

SESSION_DIRS = _auto_detect_session_dirs()

# Extraction model — cheap and fast
EXTRACTION_MODEL = "claude-haiku-4-5-20251001"
EXTRACTION_MAX_TOKENS = 2048

# Thread intervals
WATCH_INTERVAL = 10        # seconds
CONSOLIDATION_INTERVAL = 900  # 15 minutes
HEALTH_INTERVAL = 300      # 5 minutes
DECAY_HOUR = 3             # 3 AM

# Jaccard similarity thresholds for two-pass consolidation
JACCARD_AUTO_MERGE = 0.8    # Auto-merge at this threshold and above
JACCARD_FLAG_REVIEW = 0.6   # Flag for review at this threshold (up to AUTO_MERGE)
REVIEW_QUEUE_MAX = 100      # Max pending review items

# Max chars per extraction batch
MAX_EXTRACTION_CHARS = 20000


# ---------------------------------------------------------------------------
# MemoryStore — Thread-safe wrapper around memory-store.json
# ---------------------------------------------------------------------------
class MemoryStore:
    """Thread-safe memory store backed by memory-store.json."""

    def __init__(self, path=MEMORY_STORE_PATH):
        self._path = path
        self._lock = threading.RLock()
        self._data = None
        self._day_counter = 0
        self._current_day = ""
        self.load()

    def load(self):
        """Load memory store from disk. Falls back to .bak, then default schema."""
        with self._lock:
            self._data = self._try_load(self._path)
            if self._data is None:
                bak = self._path + ".bak"
                self._data = self._try_load(bak)
                if self._data is not None:
                    log.warning("Loaded memory store from backup: %s", bak)
            if self._data is None:
                log.info("Creating fresh memory store at %s", self._path)
                self._data = self._default_schema()
                self.save()
            # Initialize day counter from existing memories
            today = datetime.now().strftime("%Y%m%d")
            self._current_day = today
            existing_today = [m for m in self._data.get("memories", [])
                              if m.get("id", "").startswith(f"mem_{today}_")]
            self._day_counter = len(existing_today)

    def _try_load(self, path):
        """Try to load JSON from path. Returns dict or None."""
        if not os.path.exists(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and "memories" in data:
                return data
            return None
        except (json.JSONDecodeError, IOError, OSError) as e:
            log.warning("Failed to load %s: %s", path, e)
            return None

    def _default_schema(self):
        """Return empty memory store schema."""
        now = datetime.now().isoformat()
        return {
            "schema_version": "1.0",
            "created": now,
            "last_updated": now,
            "memories": [],
            "indexes": {
                "by_type": {"decision": [], "preference": [], "relationship": [],
                            "commitment": [], "context": [], "correction": []},
                "by_source": {"claude_code": [], "brain_state": [],
                              "screenpipe": [], "meeting": [], "slack": []},
                "by_tag": {},
            },
            "watermarks": {
                "brain_state_mtime": 0.0,
                "brain_state_hash": "",
                "sessions_processed": {},
                "last_consolidation": "",
                "last_decay": "",
            },
            "agent_status": {
                "last_heartbeat": "",
                "uptime_seconds": 0,
                "threads": {},
                "stats": {
                    "total_extractions": 0,
                    "total_consolidations": 0,
                    "api_calls_today": 0,
                    "api_cost_estimate_today": 0.0,
                },
            },
            "corrections_log": [],
            "consolidation_log": [],
            "consolidation_review_queue": [],
        }

    def save(self):
        """Save memory store to disk atomically. Creates .bak first."""
        with self._lock:
            self._data["last_updated"] = datetime.now().isoformat()
            content = json.dumps(self._data, indent=2, default=str)
            # Create backup before overwriting
            if os.path.exists(self._path):
                try:
                    bak = self._path + ".bak"
                    with open(self._path, "r", encoding="utf-8") as f:
                        bak_content = f.read()
                    config.atomic_write(bak, bak_content)
                except Exception as e:
                    log.warning("Failed to create backup: %s", e)
            config.atomic_write(self._path, content)

    def _content_hash(self, text):
        """SHA-256 hash of normalized text for dedup."""
        normalized = re.sub(r'\s+', ' ', text.strip().lower())
        return hashlib.sha256(normalized.encode('utf-8')).hexdigest()

    def _next_id(self):
        """Generate next memory ID: mem_YYYYMMDD_NNN."""
        today = datetime.now().strftime("%Y%m%d")
        if today != self._current_day:
            self._current_day = today
            self._day_counter = 0
        self._day_counter += 1
        return f"mem_{today}_{self._day_counter:03d}"

    def add_memory(self, unit):
        """Add a memory unit. Deduplicates via content hash. Returns ID or None if duplicate."""
        with self._lock:
            content = unit.get("content", "")
            if not content:
                return None
            c_hash = self._content_hash(content)
            # Check for exact duplicate
            for existing in self._data["memories"]:
                if existing.get("_content_hash") == c_hash:
                    log.debug("Duplicate memory skipped: %s", content[:60])
                    return None
            mem_id = self._next_id()
            now = datetime.now().isoformat()
            memory = {
                "id": mem_id,
                "type": unit.get("type", "context"),
                "content": content,
                "reasoning": unit.get("reasoning", ""),
                "source": unit.get("source", "unknown"),
                "source_detail": unit.get("source_detail", ""),
                "created": now,
                "last_accessed": now,
                "access_count": 0,
                "confidence": unit.get("confidence", 0.7),
                "tags": unit.get("tags", []),
                "related_memories": unit.get("related_memories", []),
                "status": "active",
                "decay_score": 1.0,
                "_content_hash": c_hash,
            }
            self._data["memories"].append(memory)
            # Update indexes
            mem_type = memory["type"]
            if mem_type in self._data["indexes"]["by_type"]:
                self._data["indexes"]["by_type"][mem_type].append(mem_id)
            source_key = memory["source"].split("_")[0] if "_" in memory["source"] else memory["source"]
            if source_key in self._data["indexes"]["by_source"]:
                self._data["indexes"]["by_source"][source_key].append(mem_id)
            for tag in memory["tags"]:
                tag_lower = tag.lower()
                if tag_lower not in self._data["indexes"]["by_tag"]:
                    self._data["indexes"]["by_tag"][tag_lower] = []
                self._data["indexes"]["by_tag"][tag_lower].append(mem_id)
            log.info("Added memory %s: [%s] %s", mem_id, mem_type, content[:80])
            return mem_id

    def search(self, query, type_filter=None, source_filter=None, status_filter="active", limit=20):
        """Keyword search on content + tags. Returns list of matching memories."""
        with self._lock:
            query_lower = query.lower()
            query_words = set(query_lower.split())
            results = []
            for m in self._data["memories"]:
                if status_filter and m.get("status") != status_filter:
                    continue
                if type_filter and m.get("type") != type_filter:
                    continue
                if source_filter and not m.get("source", "").startswith(source_filter):
                    continue
                # Score: word overlap in content + tags
                content_lower = m.get("content", "").lower()
                tags_lower = " ".join(m.get("tags", [])).lower()
                searchable = content_lower + " " + tags_lower
                matches = sum(1 for w in query_words if w in searchable)
                if matches > 0:
                    results.append((matches, m))
            results.sort(key=lambda x: -x[0])
            return [m for _, m in results[:limit]]

    def relevant(self, query, limit=10):
        """Score active memories by relevance. Returns top N with scores."""
        with self._lock:
            query_lower = query.lower()
            query_words = set(query_lower.split())
            scored = []
            for m in self._data["memories"]:
                if m.get("status") != "active":
                    continue
                content_lower = m.get("content", "").lower()
                tags_lower = " ".join(m.get("tags", [])).lower()
                searchable = content_lower + " " + tags_lower
                all_words = set(searchable.split())
                if not all_words or not query_words:
                    continue
                # Word overlap
                overlap = len(query_words & all_words)
                if overlap == 0:
                    continue
                overlap_score = overlap / len(query_words)
                # Decay
                decay = m.get("decay_score", 1.0)
                # Access boost
                access_boost = 1 + 0.05 * m.get("access_count", 0)
                # Recency (days since creation, max penalty ~0.5 over 30 days)
                try:
                    created = datetime.fromisoformat(m["created"])
                    days_old = (datetime.now() - created).days
                except (ValueError, KeyError):
                    days_old = 30
                recency = max(0.5, 1.0 - (days_old * 0.017))  # ~0.5 at 30 days
                score = overlap_score * decay * access_boost * recency
                scored.append((score, m))
            scored.sort(key=lambda x: -x[0])
            # Update last_accessed for returned items
            top = scored[:limit]
            for _, m in top:
                m["last_accessed"] = datetime.now().isoformat()
                m["access_count"] = m.get("access_count", 0) + 1
            return [{"score": round(s, 4), "memory": m} for s, m in top]

    def mark_accessed(self, mem_id):
        """Bump access_count and update last_accessed for a memory."""
        with self._lock:
            for m in self._data["memories"]:
                if m["id"] == mem_id:
                    m["access_count"] = m.get("access_count", 0) + 1
                    m["last_accessed"] = datetime.now().isoformat()
                    return True
            return False

    def run_consolidation(self):
        """Deduplicate and merge related memories."""
        with self._lock:
            memories = self._data["memories"]
            active = [m for m in memories if m.get("status") == "active"]
            merged_count = 0
            # Build hash lookup
            hash_groups = {}
            for m in active:
                h = m.get("_content_hash", "")
                if h:
                    hash_groups.setdefault(h, []).append(m)
            # Exact dedup: keep first, mark rest as superseded
            for h, group in hash_groups.items():
                if len(group) > 1:
                    primary = group[0]
                    for dup in group[1:]:
                        dup["status"] = "superseded"
                        dup["superseded_by"] = primary["id"]
                        if dup["id"] not in primary.get("related_memories", []):
                            primary.setdefault("related_memories", []).append(dup["id"])
                        merged_count += 1
            # Two-pass near-duplicate detection by Jaccard similarity
            active_remaining = [m for m in active if m.get("status") == "active"]
            # Build set of already-flagged pairs to avoid duplicates in review queue
            review_queue = self._data.setdefault("consolidation_review_queue", [])
            existing_pairs = {tuple(sorted(item["pair"])) for item in review_queue if item.get("status") == "pending"}

            for i in range(len(active_remaining)):
                for j in range(i + 1, len(active_remaining)):
                    a = active_remaining[i]
                    b = active_remaining[j]
                    if a.get("status") != "active" or b.get("status") != "active":
                        continue
                    words_a = set(a.get("content", "").lower().split())
                    words_b = set(b.get("content", "").lower().split())
                    if not words_a or not words_b:
                        continue
                    intersection = len(words_a & words_b)
                    union = len(words_a | words_b)
                    jaccard = intersection / union if union > 0 else 0

                    if jaccard >= JACCARD_AUTO_MERGE:
                        # Pass 1: Auto-merge at high similarity
                        if a.get("confidence", 0) >= b.get("confidence", 0):
                            primary, secondary = a, b
                        else:
                            primary, secondary = b, a
                        secondary["status"] = "superseded"
                        secondary["superseded_by"] = primary["id"]
                        primary.setdefault("related_memories", []).append(secondary["id"])
                        merged_count += 1
                    elif jaccard >= JACCARD_FLAG_REVIEW:
                        # Pass 2: Flag for review (don't auto-merge)
                        pair_key = tuple(sorted([a["id"], b["id"]]))
                        if pair_key not in existing_pairs:
                            review_queue.append({
                                "pair": list(pair_key),
                                "jaccard": round(jaccard, 4),
                                "flagged_at": datetime.now().isoformat(),
                                "status": "pending",
                                "content_a": a.get("content", "")[:80],
                                "content_b": b.get("content", "")[:80],
                            })
                            existing_pairs.add(pair_key)

            # Cap review queue at REVIEW_QUEUE_MAX pending items
            pending = [item for item in review_queue if item.get("status") == "pending"]
            if len(pending) > REVIEW_QUEUE_MAX:
                # Sort by flagged_at, remove oldest
                pending.sort(key=lambda x: x.get("flagged_at", ""))
                to_remove = len(pending) - REVIEW_QUEUE_MAX
                for item in pending[:to_remove]:
                    item["status"] = "dropped"
            if merged_count > 0:
                log.info("Consolidation: merged %d duplicates", merged_count)
                self._data["consolidation_log"].append({
                    "timestamp": datetime.now().isoformat(),
                    "merged_count": merged_count,
                })
                # Keep consolidation log trimmed
                self._data["consolidation_log"] = self._data["consolidation_log"][-50:]
            self._data["watermarks"]["last_consolidation"] = datetime.now().isoformat()
            return merged_count

    def run_decay(self):
        """Apply decay scoring to all active memories."""
        with self._lock:
            now = datetime.now()
            decayed = 0
            dormant = 0
            for m in self._data["memories"]:
                if m.get("status") != "active":
                    continue
                # Skip permanent memories
                tags = m.get("tags", [])
                if "core_belief" in tags or "permanent" in tags:
                    continue
                # Calculate days since last access
                try:
                    last = datetime.fromisoformat(m.get("last_accessed", m.get("created", "")))
                    days_since = (now - last).days
                except (ValueError, KeyError):
                    days_since = 30
                # Decay formula: base * 0.95^days * (1 + 0.1 * access_count)
                base = 1.0
                access_count = m.get("access_count", 0)
                decay_score = base * (0.95 ** days_since) * (1 + 0.1 * access_count)
                decay_score = min(1.0, max(0.0, decay_score))
                if decay_score != m.get("decay_score", 1.0):
                    m["decay_score"] = round(decay_score, 4)
                    decayed += 1
                # Mark dormant if very low
                if decay_score < 0.1:
                    m["status"] = "dormant"
                    dormant += 1
            self._data["watermarks"]["last_decay"] = now.isoformat()
            if decayed > 0 or dormant > 0:
                log.info("Decay: updated %d scores, %d marked dormant", decayed, dormant)
            return decayed, dormant

    def get_watermarks(self):
        """Return current watermarks dict."""
        with self._lock:
            return copy.deepcopy(self._data.get("watermarks", {}))

    def set_watermark(self, key, value):
        """Update a single watermark value."""
        with self._lock:
            self._data.setdefault("watermarks", {})[key] = value

    def update_session_watermark(self, filepath, offset):
        """Update the session file watermark."""
        with self._lock:
            self._data.setdefault("watermarks", {}).setdefault("sessions_processed", {})[filepath] = offset

    def update_agent_status(self, status_dict):
        """Update agent_status section."""
        with self._lock:
            self._data["agent_status"].update(status_dict)

    def increment_stat(self, key, amount=1):
        """Increment a stat counter."""
        with self._lock:
            stats = self._data["agent_status"]["stats"]
            stats[key] = stats.get(key, 0) + amount

    def get_stats(self):
        """Return store statistics."""
        with self._lock:
            memories = self._data["memories"]
            total = len(memories)
            active = sum(1 for m in memories if m.get("status") == "active")
            dormant = sum(1 for m in memories if m.get("status") == "dormant")
            superseded = sum(1 for m in memories if m.get("status") == "superseded")
            by_type = {}
            for m in memories:
                if m.get("status") == "active":
                    t = m.get("type", "unknown")
                    by_type[t] = by_type.get(t, 0) + 1
            return {
                "total": total,
                "active": active,
                "dormant": dormant,
                "superseded": superseded,
                "by_type": by_type,
                "agent_status": copy.deepcopy(self._data.get("agent_status", {})),
            }

    def get_memory_by_id(self, mem_id):
        """Return a memory by ID or None."""
        with self._lock:
            for m in self._data["memories"]:
                if m["id"] == mem_id:
                    return copy.deepcopy(m)
            return None

    def update_memory(self, mem_id, updates):
        """Update fields on a memory. Returns True if found."""
        with self._lock:
            for m in self._data["memories"]:
                if m["id"] == mem_id:
                    m.update(updates)
                    return True
            return False

    def get_existing_source_details(self):
        """Return set of source_detail values for dedup against brain-state."""
        with self._lock:
            return {m.get("source_detail", "") for m in self._data["memories"]
                    if m.get("source") == "brain_state" and m.get("status") == "active"}


# ---------------------------------------------------------------------------
# BrainStateWatcher — Polls brain-state.json for changes
# ---------------------------------------------------------------------------
class BrainStateWatcher:
    """Watch brain-state.json for new decisions, commitments, people model changes."""

    def __init__(self, store):
        self._store = store

    def check(self):
        """Check brain-state.json for changes. Returns list of extraction jobs."""
        jobs = []
        watermarks = self._store.get_watermarks()
        try:
            mtime = os.path.getmtime(brain_config.BRAIN_STATE_FILE)
        except OSError:
            return jobs

        if mtime <= watermarks.get("brain_state_mtime", 0):
            return jobs

        # Load state via brain_config (read-only)
        try:
            state = brain_config.load_state()
        except Exception as e:
            log.error("Failed to load brain state: %s", e)
            return jobs

        # Compute content hash over relevant sections
        relevant = {
            "decisions": state.get("decisions", []),
            "commitments": state.get("commitments", []),
            "people_model": state.get("people_model", {}),
            "patterns": state.get("patterns", {}),
        }
        content_str = json.dumps(relevant, sort_keys=True, default=str)
        content_hash = hashlib.sha256(content_str.encode()).hexdigest()

        if content_hash == watermarks.get("brain_state_hash", ""):
            # mtime changed but content didn't (cosmetic edit)
            self._store.set_watermark("brain_state_mtime", mtime)
            return jobs

        existing_details = self._store.get_existing_source_details()

        # Extract new decisions
        for d in state.get("decisions", []):
            d_id = d.get("id", "")
            desc = d.get("description", d.get("text", ""))
            detail_key = f"brain_state:decision:{d_id}"
            if detail_key in existing_details or not desc:
                continue
            jobs.append({
                "source": "brain_state",
                "source_detail": detail_key,
                "text": f"DECISION: {desc}. Date: {d.get('decided_date', d.get('date', 'unknown'))}. Status: {d.get('execution_status', 'unknown')}.",
                "hint_type": "decision",
            })

        # Extract new commitments
        for c in state.get("commitments", []):
            c_id = c.get("id", "")
            desc = c.get("description", "")
            detail_key = f"brain_state:commitment:{c_id}"
            if detail_key in existing_details or not desc:
                continue
            person = c.get("person", "the owner")
            status = c.get("status", "open")
            if status in brain_config.TERMINAL_STATUSES:
                continue
            jobs.append({
                "source": "brain_state",
                "source_detail": detail_key,
                "text": f"COMMITMENT: {desc}. Person: {person}. Status: {status}. Age: {c.get('age_days', 0)} days.",
                "hint_type": "commitment",
            })

        # Extract people model changes (significant relationships)
        for name, pdata in state.get("people_model", {}).items():
            detail_key = f"brain_state:person:{name}"
            if detail_key in existing_details:
                continue
            role = pdata.get("role", "unknown")
            rate = pdata.get("commitment_follow_through_rate", 0)
            interactions = sum(pdata.get("communication_style", {}).get("channel_distribution", {}).values())
            if interactions < 3:
                continue  # Not significant enough
            jobs.append({
                "source": "brain_state",
                "source_detail": detail_key,
                "text": f"RELATIONSHIP: {name} ({role}). Follow-through rate: {rate:.0%}. Total interactions: {interactions}.",
                "hint_type": "relationship",
            })

        self._store.set_watermark("brain_state_mtime", mtime)
        self._store.set_watermark("brain_state_hash", content_hash)

        if jobs:
            log.info("BrainStateWatcher: %d new items to extract", len(jobs))
        return jobs


# ---------------------------------------------------------------------------
# SessionWatcher — Scans Claude Code JSONL directories
# ---------------------------------------------------------------------------
class SessionWatcher:
    """Watch Claude Code session JSONL files for new conversation content."""

    def __init__(self, store):
        self._store = store

    def check(self):
        """Scan session directories for new content. Returns extraction jobs."""
        jobs = []
        watermarks = self._store.get_watermarks()
        session_marks = watermarks.get("sessions_processed", {})

        for scan_dir in SESSION_DIRS:
            if not os.path.isdir(scan_dir):
                continue
            try:
                entries = os.listdir(scan_dir)
            except OSError:
                continue

            for entry in entries:
                if not entry.endswith(".jsonl"):
                    continue
                filepath = os.path.join(scan_dir, entry)
                try:
                    mtime = os.path.getmtime(filepath)
                except OSError:
                    continue

                # Check if file is new or modified
                last_offset = session_marks.get(filepath, 0)
                try:
                    file_size = os.path.getsize(filepath)
                except OSError:
                    continue

                if file_size <= last_offset:
                    continue

                # Read new content from last offset
                try:
                    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
                        f.seek(last_offset)
                        new_content = f.read()
                        new_offset = f.tell()
                except (IOError, OSError) as e:
                    log.warning("Failed to read session file %s: %s", filepath, e)
                    continue

                if not new_content.strip():
                    self._store.update_session_watermark(filepath, new_offset)
                    continue

                # Parse JSONL lines and extract user/assistant messages
                messages = []
                for line in new_content.strip().split("\n"):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry_data = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    msg_type = entry_data.get("type", "")
                    if msg_type in ("user", "human"):
                        content = entry_data.get("message", {}).get("content", "")
                        if isinstance(content, str) and content.strip():
                            messages.append(f"USER: {content.strip()}")
                        elif isinstance(content, list):
                            # Handle structured content (text blocks)
                            for block in content:
                                if isinstance(block, dict) and block.get("type") == "text":
                                    messages.append(f"USER: {block.get('text', '').strip()}")
                    elif msg_type in ("assistant", "ai"):
                        content = entry_data.get("message", {}).get("content", "")
                        if isinstance(content, str) and content.strip():
                            messages.append(f"ASSISTANT: {content.strip()[:500]}")
                        elif isinstance(content, list):
                            for block in content:
                                if isinstance(block, dict) and block.get("type") == "text":
                                    text = block.get("text", "").strip()[:500]
                                    if text:
                                        messages.append(f"ASSISTANT: {text}")

                if messages:
                    # Concatenate into blocks, capped at MAX_EXTRACTION_CHARS
                    block = "\n\n".join(messages)
                    if len(block) > MAX_EXTRACTION_CHARS:
                        block = block[:MAX_EXTRACTION_CHARS]
                    session_name = os.path.basename(filepath).replace(".jsonl", "")
                    jobs.append({
                        "source": "claude_code",
                        "source_detail": f"session:{session_name}",
                        "text": block,
                        "hint_type": None,  # Let extractor decide
                    })

                self._store.update_session_watermark(filepath, new_offset)

        if jobs:
            log.info("SessionWatcher: %d session files with new content", len(jobs))
        return jobs


# ---------------------------------------------------------------------------
# MemoryExtractor — Haiku API calls for structured extraction
# ---------------------------------------------------------------------------
class MemoryExtractor:
    """Extract structured memories from raw text using Claude Haiku."""

    EXTRACTION_PROMPT = """You are a business owner's chief of staff. Your job is to read conversations and extract ONLY the things the owner would be frustrated to lose if they came back in two weeks and the system had forgotten them.

You are NOT a stenographer. Most conversations contain ZERO extractable memories. A busy day might produce 5-15. If you're extracting more than that, your bar is too low.

THE TEST: "Would the business owner be pissed if this was lost six months from now?" If the answer is no, DO NOT extract it.

Memory types:
- DECISION: The owner made a real choice with consequences ("decided to use Paperclip instead of building our own", "chose to kill the LinkedIn strategy")
- PREFERENCE: A durable preference that should persist across sessions ("prefers bundled PRs for refactors", "wants terse responses with no summaries")
- COMMITMENT: Something the owner PERSONALLY committed to doing for a SPECIFIC person ("told the client I'd have the deck by Friday"). NOT system tasks, NOT AI assistant commitments, NOT vague intentions
- CONTEXT: The WHY behind a decision or the SOURCE of something adapted — reasoning that would be expensive to re-derive ("pulled PI skill from danielmiessler/PAI repo because it parallels our OSINT needs")
- CORRECTION: The owner explicitly said the system was wrong about something ("that's not what I decided", "stop recommending that to me")
- REFERENCE: An external source worth remembering — a GitHub repo, a person's system, a tool discovered, a URL ("danielmiessler/PAI has 5 more skills to evaluate: Council, RedTeam, WorldThreatModel, FirstPrinciples, IterativeDepth")

Return a JSON array. Each object must have:
- "type": one of the above (lowercase)
- "content": standalone sentence, max 200 chars. Include names, URLs, specifics. Not "user found a repo" but "Found danielmiessler/PAI on GitHub — adapted Private Investigator and Extract Wisdom skills"
- "reasoning": why this matters to the owner specifically, max 200 chars
- "confidence": 0.8-1.0 ONLY. If you're not at least 0.8 confident this matters, don't include it
- "tags": 2-5 lowercase keyword tags

NEVER extract:
- Technical implementation details (file paths, function names, frameworks used, routing patterns, build configs)
- The AI assistant's own plans or commitments ("I will save this", "I should check X")
- Current state observations ("dashboard shows 25 items", "scorekeeper at level 1")
- Things that are obvious from reading the code or git history
- Conversation mechanics ("user asked about X", "user prefers minimal interruptions")
- Progress updates ("Phase 3 complete", "build succeeded", "memory agent restarted")
- Anything you'd classify as "the system is working correctly"
- Preferences about how the AI assistant should behave (those belong in CLAUDE.md, not memory)

ALWAYS extract:
- Where things came from (repos, people, systems explored or adapted)
- What the owner said they'd come back to later
- Decisions that reverse or contradict previous decisions
- Commitments the owner made to real humans
- The reasoning behind non-obvious decisions (the WHY that would be lost)

Return ONLY the JSON array. If nothing worth extracting, return []. Returning [] is the CORRECT answer for most conversation chunks.
"""

    def __init__(self, store):
        self._store = store
        self._client = None

    def _get_client(self):
        """Lazy-load Anthropic client."""
        if self._client is None:
            import anthropic
            api_key = brain_config.get_anthropic_key()
            self._client = anthropic.Anthropic(api_key=api_key)
        return self._client

    def extract(self, job):
        """Extract memories from a single job. Returns list of memory units."""
        text = job.get("text", "")
        if not text or len(text) < 50:
            return []

        hint = job.get("hint_type")
        if hint:
            # For brain-state items, we already know the type — skip API call
            content = text
            # Clean up prefixes
            for prefix in ("DECISION: ", "COMMITMENT: ", "RELATIONSHIP: "):
                if content.startswith(prefix):
                    content = content[len(prefix):]
            return [{
                "type": hint,
                "content": content[:150],
                "reasoning": f"Extracted from {job.get('source', 'unknown')}",
                "confidence": 0.8,
                "tags": self._auto_tags(content),
                "source": job.get("source", "unknown"),
                "source_detail": job.get("source_detail", ""),
            }]

        # API extraction for session content
        try:
            client = self._get_client()
            prompt = f"{self.EXTRACTION_PROMPT}\n\n--- TEXT TO ANALYZE ---\n{text}"

            response = client.messages.create(
                model=EXTRACTION_MODEL,
                max_tokens=EXTRACTION_MAX_TOKENS,
                messages=[{"role": "user", "content": prompt}],
            )

            response_text = response.content[0].text if response.content else "[]"

            # Parse JSON from response
            # Handle markdown code fences
            if "```" in response_text:
                match = re.search(r'```(?:json)?\s*\n?(.*?)\n?```', response_text, re.DOTALL)
                if match:
                    response_text = match.group(1)

            memories = json.loads(response_text.strip())
            if not isinstance(memories, list):
                memories = []

            self._store.increment_stat("api_calls_today")
            # Rough cost estimate: ~5K input tokens + ~1K output at Haiku pricing
            self._store.increment_stat("api_cost_estimate_today", 0.002)

            results = []
            for mem in memories:
                if not isinstance(mem, dict):
                    continue
                confidence = mem.get("confidence", 0.5)
                if confidence < 0.8:
                    continue
                results.append({
                    "type": mem.get("type", "context").lower(),
                    "content": str(mem.get("content", ""))[:200],
                    "reasoning": str(mem.get("reasoning", ""))[:200],
                    "confidence": confidence,
                    "tags": mem.get("tags", [])[:5],
                    "source": job.get("source", "unknown"),
                    "source_detail": job.get("source_detail", ""),
                })

            self._store.increment_stat("total_extractions", len(results))
            return results

        except json.JSONDecodeError as e:
            log.warning("Failed to parse extraction response: %s", e)
            return []
        except Exception as e:
            log.error("Extraction API error: %s", e)
            return []

    def _auto_tags(self, text):
        """Generate basic tags from content text. Loads custom keywords from companion-config.json."""
        text_lower = text.lower()
        tags = []
        # Try to load custom keywords from companion-config.json
        keywords = {}
        config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "companion-config.json")
        if os.path.exists(config_path):
            try:
                with open(config_path, "r") as f:
                    cc = json.load(f)
                # Use products and team names as tag keywords
                for product in cc.get("products", []):
                    keywords[product.lower()] = product.lower().replace(" ", "-")
                for person in cc.get("team", []):
                    keywords[person.lower()] = person.lower()
            except (json.JSONDecodeError, IOError):
                pass
        # Always include generic business keywords
        generic = {
            "pricing": "pricing", "webinar": "webinar", "dashboard": "dashboard",
            "brain": "brain", "slack": "slack", "email": "email",
            "launch": "launch", "revenue": "revenue", "client": "client",
            "employee": "employee", "hire": "hire", "fire": "fire",
        }
        keywords.update(generic)
        for keyword, tag in keywords.items():
            if keyword in text_lower and tag not in tags:
                tags.append(tag)
        return tags[:5]


# ---------------------------------------------------------------------------
# MemoryAgent — Main orchestrator with 5 daemon threads
# ---------------------------------------------------------------------------
class MemoryAgent:
    """Main memory agent orchestrator. Runs 5 daemon threads."""

    def __init__(self):
        self._store = MemoryStore()
        self._brain_watcher = BrainStateWatcher(self._store)
        self._session_watcher = SessionWatcher(self._store)
        self._extractor = MemoryExtractor(self._store)
        self._queue = queue.Queue()
        self._shutdown = threading.Event()
        self._start_time = time.time()
        self._thread_status = {}
        self._thread_status_lock = threading.Lock()
        self._last_cost_reset_date = ""  # Empty = reset on first health loop iteration
        self._last_snapshot_date = ""

    def start(self):
        """Start all daemon threads and run until shutdown."""
        log.info("Memory Agent starting...")

        # Register signal handlers
        signal.signal(signal.SIGTERM, self._handle_signal)
        signal.signal(signal.SIGINT, self._handle_signal)

        threads = [
            ("watch", self._watch_loop),
            ("extract", self._extract_loop),
            ("consolidate", self._consolidate_loop),
            ("decay", self._decay_loop),
            ("health", self._health_loop),
        ]

        for name, target in threads:
            t = threading.Thread(target=self._safe_thread, args=(name, target), daemon=True)
            t.start()
            log.info("Started thread: %s", name)

        # Main thread waits for shutdown
        log.info("Memory Agent running. PID=%d", os.getpid())
        try:
            while not self._shutdown.is_set():
                self._shutdown.wait(timeout=1.0)
        except KeyboardInterrupt:
            pass
        finally:
            self._shutdown_cleanup()

    def _handle_signal(self, signum, frame):
        """Handle SIGTERM/SIGINT gracefully."""
        log.info("Received signal %d, shutting down...", signum)
        self._shutdown.set()

    def _shutdown_cleanup(self):
        """Final cleanup on shutdown."""
        log.info("Saving memory store before exit...")
        try:
            self._store.save()
            log.info("Memory store saved. Shutdown complete.")
        except Exception as e:
            log.error("Failed to save on shutdown: %s", e)

    def _safe_thread(self, name, target):
        """Wrapper that catches exceptions in threads without crashing the daemon."""
        try:
            target()
        except Exception as e:
            log.error("Thread '%s' crashed: %s", name, e, exc_info=True)
            with self._thread_status_lock:
                self._thread_status[name] = {
                    "status": "crashed",
                    "error": str(e),
                    "crashed_at": datetime.now().isoformat(),
                }

    def _update_thread_status(self, name, status="running"):
        """Update a thread's status."""
        with self._thread_status_lock:
            self._thread_status[name] = {
                "status": status,
                "last_run": datetime.now().isoformat(),
            }

    # -- Thread: Watch Loop ---------------------------------------------------
    def _watch_loop(self):
        """Watch for new data from all sources. Runs every WATCH_INTERVAL seconds."""
        # On first run, give a small delay for startup
        time.sleep(2)
        while not self._shutdown.is_set():
            self._update_thread_status("watch")
            try:
                # Brain-state watcher DISABLED — brain already has this data.
                # Duplicating it into memory-store was pure noise (290 redundant items).
                # brain_jobs = self._brain_watcher.check()
                # for job in brain_jobs:
                #     self._queue.put(job)

                # Check session logs
                session_jobs = self._session_watcher.check()
                for job in session_jobs:
                    self._queue.put(job)

            except Exception as e:
                log.error("Watch loop error: %s", e)

            self._shutdown.wait(timeout=WATCH_INTERVAL)

    # -- Thread: Extract Loop -------------------------------------------------
    def _extract_loop(self):
        """Process extraction queue. Blocks on queue, processes jobs one at a time."""
        batch_count = 0
        while not self._shutdown.is_set():
            self._update_thread_status("extract")
            try:
                job = self._queue.get(timeout=5.0)
            except queue.Empty:
                continue

            try:
                memories = self._extractor.extract(job)
                added = 0
                for mem in memories:
                    mem_id = self._store.add_memory(mem)
                    if mem_id:
                        added += 1
                if added > 0:
                    batch_count += added
                    # Save after every batch to persist
                    if batch_count >= 5 or self._queue.empty():
                        self._store.save()
                        batch_count = 0
            except Exception as e:
                log.error("Extract loop error: %s", e)

    # -- Thread: Consolidation Loop -------------------------------------------
    def _consolidate_loop(self):
        """Run consolidation every CONSOLIDATION_INTERVAL seconds."""
        # Wait a bit before first consolidation
        self._shutdown.wait(timeout=60)
        while not self._shutdown.is_set():
            self._update_thread_status("consolidate")
            try:
                merged = self._store.run_consolidation()
                if merged > 0:
                    self._store.save()
            except Exception as e:
                log.error("Consolidation error: %s", e)

            self._shutdown.wait(timeout=CONSOLIDATION_INTERVAL)

    # -- Thread: Decay Loop ---------------------------------------------------
    def _decay_loop(self):
        """Run decay daily at DECAY_HOUR AM."""
        while not self._shutdown.is_set():
            self._update_thread_status("decay")
            now = datetime.now()
            # Calculate seconds until next DECAY_HOUR
            from datetime import timedelta
            target = now.replace(hour=DECAY_HOUR, minute=0, second=0, microsecond=0)
            if now >= target:
                target = target + timedelta(days=1)
            wait_seconds = (target - now).total_seconds()
            # But don't wait more than 1 hour at a time (so we can check shutdown)
            wait_seconds = min(wait_seconds, 3600)

            self._shutdown.wait(timeout=wait_seconds)
            if self._shutdown.is_set():
                break

            # Check if it's actually decay time
            if datetime.now().hour == DECAY_HOUR:
                try:
                    decayed, dormant = self._store.run_decay()
                    if decayed > 0 or dormant > 0:
                        self._store.save()
                except Exception as e:
                    log.error("Decay error: %s", e)

    # -- Thread: Health Loop --------------------------------------------------
    def _health_loop(self):
        """Report health status every HEALTH_INTERVAL seconds. Also handles daily cost reset and snapshots."""
        while not self._shutdown.is_set():
            try:
                uptime = int(time.time() - self._start_time)
                with self._thread_status_lock:
                    threads_snapshot = dict(self._thread_status)
                self._store.update_agent_status({
                    "last_heartbeat": datetime.now().isoformat(),
                    "uptime_seconds": uptime,
                    "threads": threads_snapshot,
                })

                # R4: Reset daily API cost counters on date change
                today_str = date.today().isoformat()
                if today_str != self._last_cost_reset_date:
                    with self._store._lock:
                        stats = self._store._data["agent_status"]["stats"]
                        stats["api_calls_today"] = 0
                        stats["api_cost_estimate_today"] = 0.0
                    self._last_cost_reset_date = today_str
                    log.info("Daily API cost counters reset for %s", today_str)

                    # R5: Daily memory-store snapshot
                    self._create_daily_snapshot(today_str)

                self._store.save()
            except Exception as e:
                log.error("Health loop error: %s", e)

            self._shutdown.wait(timeout=HEALTH_INTERVAL)

    def _create_daily_snapshot(self, date_str):
        """Create a daily snapshot of memory-store.json. 30-day retention."""
        try:
            history_dir = os.path.join(brain_config.DATA_DIR, "memory-store-history")
            os.makedirs(history_dir, exist_ok=True)
            snapshot_name = f"memory-store-{date_str}.json"
            snapshot_path = os.path.join(history_dir, snapshot_name)
            if os.path.exists(snapshot_path):
                return  # Already snapshotted today
            source = os.path.join(brain_config.DATA_DIR, "memory-store.json")
            if os.path.exists(source):
                shutil.copy2(source, snapshot_path)
                log.info("Daily snapshot created: %s", snapshot_name)
            # Cleanup: remove files older than 30 days
            cutoff = date.today().toordinal() - 30
            for fname in os.listdir(history_dir):
                if not fname.startswith("memory-store-") or not fname.endswith(".json"):
                    continue
                try:
                    fdate_str = fname.replace("memory-store-", "").replace(".json", "")
                    fdate = date.fromisoformat(fdate_str)
                    if fdate.toordinal() < cutoff:
                        os.remove(os.path.join(history_dir, fname))
                        log.info("Removed old snapshot: %s", fname)
                except (ValueError, OSError):
                    continue
        except Exception as e:
            log.error("Failed to create daily snapshot: %s", e)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    agent = MemoryAgent()
    agent.start()
