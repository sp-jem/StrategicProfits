---
name: setup-memory-system
description: Sets up the Memory System — a persistent intelligence layer that watches your Claude Code sessions, extracts decisions/commitments/preferences, and produces daily intelligence briefings. Requires setup-brain (Day 6) to be completed first.
version: 1.0.0
tags: [setup, infrastructure, memory, intelligence-engine]
type: discipline
---

# setup-memory-system

Sets up the persistent Memory System for your intelligence engine. This installs a background daemon that watches your Claude Code conversations and automatically extracts important information — decisions you've made, commitments you've given, preferences you've stated, corrections you've applied. Over time, it builds a living memory of your business that compounds with every session.

## PURPOSE

**Problem:** Every Claude Code session starts cold. Decisions made last week are forgotten. Commitments vanish when the session ends. The brain infrastructure from Day 6 has the structure but no data flowing into it.

**Audience:** Force Multiplier participants who have completed setup-brain (Day 6).

**Success criteria:** Memory agent daemon is running, verification script passes all checks, and within 24 hours of normal Claude Code use, your system begins accumulating real business intelligence.

**Non-goals:** This skill does NOT configure data sources like Screenpipe, Slack, or email collectors. It focuses solely on the memory extraction layer that watches Claude Code sessions.

---

## INVARIANTS (non-negotiable rules)

1. **NEVER overwrite existing files.** Every file copy step MUST check for existence first. If the file exists, skip it (unless it's a Python file being upgraded — in that case, back up first).
2. **NEVER store credentials in any file other than `~/.claude/credentials/`.** The memory agent reads credentials from there via brain_config.py.
3. **MUST have setup-brain completed BEFORE this skill.** If brain_config.py or config.py doesn't exist, STOP immediately.
4. **MUST verify end-to-end after installation.** The verification step is NOT optional.
5. **This skill MUST be idempotent.** Running it twice produces the same result as running it once.

---

## PRE-FLIGHT

Before executing any step, announce the plan:

> I will now set up the Memory System. This involves:
> 1. Verifying Day 6 prerequisites (brain infrastructure, API key, Python)
> 2. Installing 3 Python files (memory agent, bridge, briefing generator)
> 3. Creating a LaunchAgent to run the memory agent as a background daemon
> 4. Starting the daemon
> 5. Running end-to-end verification
> 6. Adding BRIEFING.md to your session startup (if not already configured)
>
> All file operations are non-destructive — existing data is never overwritten.

---

## STEP 1: Verify Prerequisites

Check that Day 6 setup-brain was completed. If ANY check fails, STOP and direct to the prerequisite.

```bash
# Check brain infrastructure
for f in \
  ~/.claude/skills/intelligence-engine/config.py \
  ~/.claude/skills/intelligence-engine/brain/brain_config.py \
  ~/.claude/skills/intelligence-engine/brain/brain_state.py \
  ~/.claude/credentials/anthropic-linker.env
do
  if [ ! -f "$f" ]; then
    echo "MISSING: $f"
    echo "Please complete /setup-brain first, then re-run this skill."
    exit 1
  fi
done
echo "All prerequisites found."
```

Verify Python 3 and the anthropic package:

```bash
python3 --version || { echo "Python 3 is required. Install from python.org"; exit 1; }
python3 -c "import anthropic" 2>/dev/null || {
  echo "Installing anthropic package..."
  pip3 install anthropic
}
```

Verify brain-state.json exists (auto-detect vault path):

```python
import os, sys
sys.path.insert(0, os.path.expanduser("~/.claude/skills/intelligence-engine"))
sys.path.insert(0, os.path.expanduser("~/.claude/skills/intelligence-engine/brain"))
import brain_config
assert os.path.exists(brain_config.BRAIN_STATE_FILE), f"brain-state.json not found at {brain_config.BRAIN_STATE_FILE}"
print(f"Vault detected: {brain_config.DATA_DIR}")
```

---

## STEP 2: Install Python Files

Copy the three memory system Python files to their correct locations. The memory agent goes in the intelligence-engine root (alongside config.py). The bridge and briefing generator go in the brain/ subdirectory (alongside brain_config.py).

**File locations:**
| Source (in this skill's references/) | Destination |
|--------------------------------------|-------------|
| `references/memory-agent-fm.py` | `~/.claude/skills/intelligence-engine/memory-agent-fm.py` |
| `references/brain_memory_bridge_fm.py` | `~/.claude/skills/intelligence-engine/brain/brain_memory_bridge_fm.py` |
| `references/brain_briefing.py` | `~/.claude/skills/intelligence-engine/brain/brain_briefing.py` |
| `references/verify-memory-system.py` | `~/.claude/skills/intelligence-engine/verify-memory-system.py` |

For each file:
1. Check if destination exists
2. If it exists, create a .bak backup before overwriting (this is an upgrade, not first install)
3. Copy the file
4. Make it executable: `chmod +x <destination>`

```bash
IE_DIR="$HOME/.claude/skills/intelligence-engine"
BRAIN_DIR="$IE_DIR/brain"
REF_DIR="$HOME/.claude/skills/setup-memory-system/references"

# Helper: backup existing file before overwriting
backup_and_copy() {
  local src="$1" dest="$2"
  if [ -f "$dest" ]; then
    cp "$dest" "${dest}.bak"
    echo "  Backed up existing $(basename "$dest") → $(basename "$dest").bak"
  fi
  cp "$src" "$dest"
  chmod +x "$dest"
  echo "  Installed $(basename "$dest")"
}

# memory-agent-fm.py → intelligence-engine root
backup_and_copy "$REF_DIR/memory-agent-fm.py" "$IE_DIR/memory-agent-fm.py"

# brain_memory_bridge_fm.py → brain/
backup_and_copy "$REF_DIR/brain_memory_bridge_fm.py" "$BRAIN_DIR/brain_memory_bridge_fm.py"

# brain_briefing.py → brain/
backup_and_copy "$REF_DIR/brain_briefing.py" "$BRAIN_DIR/brain_briefing.py"

# verify script → intelligence-engine root
backup_and_copy "$REF_DIR/verify-memory-system.py" "$IE_DIR/verify-memory-system.py"
```

---

## STEP 3: Create LaunchAgent (Mac only)

Auto-detect Python 3 path and create the launchd plist. This MUST be a single bash block so variables are available throughout.

IMPORTANT: launchd does NOT expand `~` or `$HOME`. All paths in the plist must be fully expanded (e.g., `/Users/username/...`).

```bash
PYTHON_PATH=$(which python3)
IE_DIR="$HOME/.claude/skills/intelligence-engine"
AGENT_SCRIPT="$IE_DIR/memory-agent-fm.py"
PLIST_PATH="$HOME/Library/LaunchAgents/com.intelligence-engine.memory-agent.plist"
LOG_DIR="$HOME/.claude/logs"

mkdir -p "$LOG_DIR"
mkdir -p "$HOME/Library/LaunchAgents"

# Write the plist file with expanded paths
cat > "$PLIST_PATH" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.intelligence-engine.memory-agent</string>
    <key>ProgramArguments</key>
    <array>
        <string>${PYTHON_PATH}</string>
        <string>${AGENT_SCRIPT}</string>
    </array>
    <key>WorkingDirectory</key>
    <string>${IE_DIR}</string>
    <key>KeepAlive</key>
    <true/>
    <key>RunAtLoad</key>
    <true/>
    <key>StandardOutPath</key>
    <string>${LOG_DIR}/memory-agent-stdout.log</string>
    <key>StandardErrorPath</key>
    <string>${LOG_DIR}/memory-agent-stderr.log</string>
</dict>
</plist>
EOF

echo "LaunchAgent plist written to: $PLIST_PATH"
```

**For Windows users:** Skip this step. Instead, provide these instructions:
> To run the memory agent on Windows:
> 1. Open a terminal and run: `python3 %USERPROFILE%\.claude\skills\intelligence-engine\memory-agent-fm.py`
> 2. To run at startup, create a Windows Task Scheduler entry:
>    - Program: the path to python3.exe (e.g., `C:\Users\You\AppData\Local\Programs\Python\Python312\python.exe`)
>    - Arguments: `%USERPROFILE%\.claude\skills\intelligence-engine\memory-agent-fm.py`
>    - Trigger: At log on
> 3. Or simply run it manually when you want the daemon active

---

## STEP 4: Start the Daemon

IMPORTANT: `$PLIST_PATH` must be redeclared here because each bash block runs in a separate shell.

```bash
PLIST_PATH="$HOME/Library/LaunchAgents/com.intelligence-engine.memory-agent.plist"

# Unload if already loaded (idempotent)
launchctl bootout gui/$(id -u) "$PLIST_PATH" 2>/dev/null || true

# Load the new plist
launchctl bootstrap gui/$(id -u) "$PLIST_PATH"

# Wait 3 seconds for daemon to start
sleep 3

# Verify it's running
if launchctl list | grep -q "com.intelligence-engine.memory-agent"; then
    echo "Memory Agent daemon is running."
else
    echo "WARNING: Daemon may not have started. Check logs at ~/.claude/logs/memory-agent-stderr.log"
fi
```

---

## STEP 5: Run Verification

```bash
python3 ~/.claude/skills/intelligence-engine/verify-memory-system.py
```

All checks should pass (warnings about empty data are normal for fresh install).

---

## STEP 6: Configure Session Startup

Add a BRIEFING.md read instruction to the user's `~/.claude/CLAUDE.md` so every future Claude Code session starts with their intelligence briefing.

First, determine the actual vault path by running:

```python
import os, sys
sys.path.insert(0, os.path.expanduser("~/.claude/skills/intelligence-engine"))
sys.path.insert(0, os.path.expanduser("~/.claude/skills/intelligence-engine/brain"))
import config
briefing_path = os.path.join(config.MEMORY_DIR, "BRIEFING.md")
print(briefing_path)
```

Then add this block to `~/.claude/CLAUDE.md` (replacing `BRIEFING_PATH` with the actual path printed above):

    ## Intelligence Briefing

    At session start, read this file if it exists:
    `BRIEFING_PATH`
    This contains your accumulated business intelligence — commitments, decisions,
    priorities, and recent memories. Use it to inform your work in this session.

Rules:
1. If `~/.claude/CLAUDE.md` does not exist, CREATE it with this block
2. If it exists but already contains "BRIEFING.md" or "Intelligence Briefing", SKIP (already configured)
3. If it exists without the block, APPEND the block to the end
4. Always use the ACTUAL expanded path (e.g., `/Users/alice/Obsidian/MyVault/memory/BRIEFING.md`), never a literal placeholder

---

## STEP 7: Run Bridge and Generate First Briefing

Now that the daemon is running, run the bridge and briefing generator once to populate initial state:

```bash
# Run the bridge (connects memory-store to brain-state)
cd ~/.claude/skills/intelligence-engine
python3 brain/brain_memory_bridge_fm.py

# Generate the first briefing
python3 brain/brain_briefing.py
```

Report the results to the user:
- How many memories were bridged (if any)
- Where BRIEFING.md was written
- What the user should expect going forward

---

## POST-INSTALLATION

Tell the user:

> Your Memory System is now active. Here's what happens next:
>
> **Immediately:** The memory agent daemon is watching your Claude Code sessions. Every conversation you have will be scanned for important information.
>
> **Within 24 hours:** As you use Claude Code normally, memory-store.json will begin filling with extracted decisions, commitments, preferences, and context.
>
> **To sync memories to brain-state:** Run `python3 ~/.claude/skills/intelligence-engine/brain/brain_memory_bridge_fm.py`
>
> **To generate a fresh briefing:** Run `python3 ~/.claude/skills/intelligence-engine/brain/brain_briefing.py`
>
> **To check system health:** Run `python3 ~/.claude/skills/intelligence-engine/verify-memory-system.py`
>
> **Logs:** `~/.claude/logs/memory-agent.log` and `~/.claude/logs/memory-agent-stderr.log`
>
> **Cost:** The memory agent uses Claude Haiku for extraction — approximately $0.03-0.05 per day of normal use.
>
> **New projects:** If you start a new Claude Code project after the daemon is running, restart the daemon to detect it: `launchctl kickstart -k gui/$(id -u)/com.intelligence-engine.memory-agent`

---

## COMMANDS

After installation, these commands are available from any terminal:

| Command | What It Does |
|---------|-------------|
| `python3 ~/.claude/skills/intelligence-engine/brain/brain_memory_bridge_fm.py` | Sync memories → brain-state |
| `python3 ~/.claude/skills/intelligence-engine/brain/brain_briefing.py` | Generate fresh BRIEFING.md |
| `python3 ~/.claude/skills/intelligence-engine/verify-memory-system.py` | Health check |
| `launchctl list \| grep memory-agent` | Check daemon status |
| `launchctl kickstart gui/$(id -u)/com.intelligence-engine.memory-agent` | Restart daemon |
| `tail -20 ~/.claude/logs/memory-agent.log` | View recent logs |
