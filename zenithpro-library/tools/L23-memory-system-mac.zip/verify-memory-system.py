#!/usr/bin/env python3
"""
verify-memory-system.py — End-to-end verification for FM Memory System.
Checks all prerequisites, installed files, and daemon status.
"""

import os
import sys
import json
import subprocess

PASSED = 0
FAILED = 0
WARNINGS = 0


def check(name, condition, fix=""):
    global PASSED, FAILED
    if condition:
        print(f"  \033[32m✓\033[0m {name}")
        PASSED += 1
        return True
    else:
        print(f"  \033[31m✗\033[0m {name}")
        if fix:
            print(f"    Fix: {fix}")
        FAILED += 1
        return False


def warn(name, msg):
    global WARNINGS
    print(f"  \033[33m⚠\033[0m {name}: {msg}")
    WARNINGS += 1


def main():
    global PASSED, FAILED, WARNINGS
    print("")
    print("\033[1mMemory System Verification\033[0m")
    print("=" * 40)
    print("")

    ie_dir = os.path.expanduser("~/.claude/skills/intelligence-engine")
    brain_dir = os.path.join(ie_dir, "brain")
    creds_dir = os.path.expanduser("~/.claude/credentials")
    logs_dir = os.path.expanduser("~/.claude/logs")

    # ── Check 1: Day 6 Infrastructure ──
    print("\033[1mDay 6 Infrastructure:\033[0m")
    check("config.py exists",
          os.path.exists(os.path.join(ie_dir, "config.py")),
          "Run /setup-brain first")
    check("brain_config.py exists",
          os.path.exists(os.path.join(brain_dir, "brain_config.py")),
          "Run /setup-brain first")
    check("brain_state.py exists",
          os.path.exists(os.path.join(brain_dir, "brain_state.py")),
          "Run /setup-brain first")
    api_key_file = os.path.join(creds_dir, "anthropic-linker.env")
    api_key_ok = False
    if os.path.exists(api_key_file):
        try:
            with open(api_key_file, "r") as f:
                content = f.read()
            api_key_ok = "ANTHROPIC_API_KEY=" in content and len(content.strip()) > 20
        except IOError:
            pass
    check("Anthropic API key (exists and contains key)",
          api_key_ok,
          "Create ~/.claude/credentials/anthropic-linker.env with ANTHROPIC_API_KEY=sk-ant-...")
    print("")

    # ── Check 2: Memory System Files ──
    print("\033[1mMemory System Files:\033[0m")
    check("memory-agent-fm.py installed",
          os.path.exists(os.path.join(ie_dir, "memory-agent-fm.py")),
          "Re-run /setup-memory-system")
    check("brain_memory_bridge_fm.py installed",
          os.path.exists(os.path.join(brain_dir, "brain_memory_bridge_fm.py")),
          "Re-run /setup-memory-system")
    check("brain_briefing.py installed",
          os.path.exists(os.path.join(brain_dir, "brain_briefing.py")),
          "Re-run /setup-memory-system")

    # Test that memory-agent-fm.py can be loaded without import errors
    agent_path = os.path.join(ie_dir, "memory-agent-fm.py")
    if os.path.exists(agent_path):
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location("memory_agent_fm", agent_path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            check("memory-agent-fm.py imports cleanly", True)
        except (Exception, SystemExit) as e:
            check("memory-agent-fm.py imports cleanly", False,
                  f"Import error: {e}")
    print("")

    # ── Check 3: brain-state.json ──
    print("\033[1mBrain State:\033[0m")
    # Auto-detect vault
    vault_path = None
    try:
        sys.path.insert(0, ie_dir)
        sys.path.insert(0, brain_dir)
        import brain_config as bc
        vault_path = bc.DATA_DIR
        bs_path = bc.BRAIN_STATE_FILE
        check("brain-state.json exists", os.path.exists(bs_path),
              "Run /setup-brain first")
        if os.path.exists(bs_path):
            try:
                with open(bs_path, "r") as f:
                    state = json.load(f)
                check("brain-state.json is valid JSON", isinstance(state, dict))
                commitments = len(state.get("commitments", []))
                decisions = len(state.get("decisions", []))
                if commitments > 0 or decisions > 0:
                    print(f"    Data: {commitments} commitments, {decisions} decisions")
                else:
                    warn("brain-state.json", "Empty (this is normal before the bridge runs)")
            except json.JSONDecodeError:
                check("brain-state.json is valid JSON", False, "File is corrupted")
    except ImportError:
        check("brain_config.py importable", False, "Run /setup-brain first")
    print("")

    # ── Check 4: memory-store.json ──
    print("\033[1mMemory Store:\033[0m")
    if vault_path:
        ms_path = os.path.join(vault_path, "memory-store.json")
        if os.path.exists(ms_path):
            try:
                with open(ms_path, "r") as f:
                    store = json.load(f)
                check("memory-store.json exists and valid", isinstance(store, dict))
                memories = store.get("memories", [])
                active = sum(1 for m in memories if m.get("status") == "active")
                print(f"    Memories: {active} active out of {len(memories)} total")
                agent_status = store.get("agent_status", {})
                heartbeat = agent_status.get("last_heartbeat", "")
                if heartbeat:
                    print(f"    Last heartbeat: {heartbeat}")
                else:
                    warn("Memory Agent", "No heartbeat recorded yet")
            except json.JSONDecodeError:
                check("memory-store.json valid", False, "File corrupted — delete and restart daemon")
        else:
            warn("memory-store.json", "Not yet created (will be created when daemon starts)")
    print("")

    # ── Check 5: Python & anthropic package ──
    print("\033[1mPython Environment:\033[0m")
    try:
        result = subprocess.run([sys.executable, "--version"], capture_output=True, text=True)
        version = result.stdout.strip()
        check(f"Python 3 ({version})", True)
    except Exception:
        check("Python 3", False)

    try:
        import anthropic
        check("anthropic package installed", True)
    except ImportError:
        check("anthropic package installed", False,
              "Run: pip3 install anthropic")
    print("")

    # ── Check 6: LaunchAgent (Mac only) ──
    print("\033[1mDaemon Status:\033[0m")
    plist_path = os.path.expanduser(
        "~/Library/LaunchAgents/com.intelligence-engine.memory-agent.plist"
    )
    if sys.platform == "darwin":
        check("LaunchAgent plist exists", os.path.exists(plist_path),
              "Re-run /setup-memory-system")
        # Check if daemon is loaded
        try:
            result = subprocess.run(
                ["launchctl", "list"],
                capture_output=True, text=True, timeout=5
            )
            is_loaded = "com.intelligence-engine.memory-agent" in result.stdout
            check("Memory Agent daemon loaded", is_loaded,
                  f"Run: launchctl bootstrap gui/$(id -u) {plist_path}")
        except Exception:
            warn("Daemon check", "Could not query launchctl")

        # Check log file
        log_path = os.path.join(logs_dir, "memory-agent.log")
        if os.path.exists(log_path):
            check("Memory Agent log exists", True)
            try:
                with open(log_path, "r") as f:
                    lines = f.readlines()
                if lines:
                    last = lines[-1].strip()
                    print(f"    Last log: {last[:100]}")
            except IOError:
                pass
        else:
            warn("Log file", "Not yet created (daemon hasn't started)")
    else:
        warn("LaunchAgent", "Not applicable on this platform (Windows/Linux)")
        print("    To start manually: python3 ~/.claude/skills/intelligence-engine/memory-agent-fm.py")
    print("")

    # ── Check 7: BRIEFING.md ──
    print("\033[1mBriefing:\033[0m")
    try:
        import config as cfg
        briefing_path = os.path.join(cfg.MEMORY_DIR, "BRIEFING.md")
        if os.path.exists(briefing_path):
            size = os.path.getsize(briefing_path)
            check(f"BRIEFING.md exists ({size} bytes)", True)
        else:
            warn("BRIEFING.md", "Not yet generated. Run: python3 ~/.claude/skills/intelligence-engine/brain/brain_briefing.py")
    except ImportError:
        warn("BRIEFING.md", "Cannot determine path (config.py not importable)")
    print("")

    # ── Summary ──
    print("=" * 40)
    total = PASSED + FAILED
    if FAILED == 0:
        print(f"\033[32m\033[1m--- ALL {PASSED} CHECKS PASSED ---\033[0m")
        if WARNINGS > 0:
            print(f"  ({WARNINGS} warnings — normal for fresh install)")
    else:
        print(f"\033[31m\033[1m{FAILED} FAILED\033[0m, {PASSED} passed, {WARNINGS} warnings")
        print("  Fix the failures above and re-run this script.")
    print("")
    return 0 if FAILED == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
