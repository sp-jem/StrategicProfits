#!/usr/bin/env python3
"""
brain_briefing.py — Standalone briefing generator for Force Multiplier students.

Reads brain-state.json and memory-store.json and produces BRIEFING.md in the
configured memory directory. No LLM calls. No external dependencies beyond
config.py and brain_config.py.

Run standalone:
    python3 brain_briefing.py

Or import and call:
    from brain_briefing import generate_briefing
    path = generate_briefing()
"""

import os
import sys
import json
from datetime import datetime, date

# ---------------------------------------------------------------------------
# Path setup — same pattern as brain_memory_bridge_fm.py
#
# config.py and brain_config.py are installed by setup-brain (Day 6).
# We probe a handful of candidate locations so the script works whether
# run from the brain/ subdirectory or the intelligence-engine root.
# ---------------------------------------------------------------------------
BRAIN_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(BRAIN_DIR)

# Standard install location
_IE_SKILL = os.path.expanduser("~/.claude/skills/intelligence-engine")
_IE_BRAIN = os.path.join(_IE_SKILL, "brain")

for _p in [BRAIN_DIR, PROJECT_DIR, _IE_BRAIN, _IE_SKILL]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    import config
    import brain_config
except ImportError as e:
    print(f"\nERROR: Required module not found: {e}")
    print("The briefing generator requires config.py and brain_config.py from the Day 6 setup.")
    print("Please complete /setup-brain before running brain_briefing.py.\n")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _safe_parse_date(date_str):
    """Parse YYYY-MM-DD or ISO8601 string. Returns date or None on failure."""
    if not date_str or not isinstance(date_str, str):
        return None
    s = date_str.strip()[:10]
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None


def _days_since(date_str, today=None):
    """Return integer days since date_str. Returns None if unparseable."""
    if today is None:
        today = date.today()
    d = _safe_parse_date(date_str)
    if d is None:
        return None
    return max((today - d).days, 0)


def _format_date(date_str):
    """Format YYYY-MM-DD as 'Apr 7' style. Returns raw string on failure."""
    d = _safe_parse_date(date_str)
    if d is None:
        return date_str or "unknown date"
    # %-d works on macOS/Linux but not Windows; use portable approach
    return d.strftime("%b %d").replace(" 0", " ").strip()


def _load_memory_store(data_dir):
    """Load memory-store.json with .bak fallback. Returns (store_dict, status)."""
    primary = os.path.join(data_dir, "memory-store.json")
    backup = primary + ".bak"

    for path in (primary, backup):
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                store = json.load(f)
            if isinstance(store, dict):
                return store, ("ok" if path == primary else "used_backup")
        except (json.JSONDecodeError, IOError, OSError):
            continue

    return {}, "unavailable"


def _is_terminal_commitment(status):
    return status in brain_config.TERMINAL_STATUSES


def _is_terminal_decision(exec_status):
    return exec_status in brain_config.DECISION_TERMINAL_STATUSES


# ---------------------------------------------------------------------------
# Section builders
# ---------------------------------------------------------------------------

def _build_system_status(store):
    """Section: System Status — agent heartbeat + memory counts."""
    lines = ["## System Status"]

    agent = store.get("agent_status", {})
    if not agent:
        lines.append("- Memory Agent: Not yet running")
        lines.append("- Memories: 0 active, 0 dormant")
        lines.append("- Last extraction: Never")
        return lines

    # Overall status — derive from thread statuses
    threads = agent.get("threads", {})
    thread_statuses = [t.get("status", "unknown") for t in threads.values()]
    if all(s == "running" for s in thread_statuses) and thread_statuses:
        agent_status_str = "Running"
    elif any(s == "running" for s in thread_statuses):
        agent_status_str = "Partially running"
    elif thread_statuses:
        agent_status_str = "Stopped"
    else:
        agent_status_str = "Unknown"

    lines.append(f"- Memory Agent: {agent_status_str}")

    # Memory counts
    memories = store.get("memories", [])
    active_count = sum(1 for m in memories if m.get("status") == "active")
    dormant_count = sum(1 for m in memories if m.get("status") == "dormant")
    lines.append(f"- Memories: {active_count} active, {dormant_count} dormant")

    # Last extraction — from extract thread
    extract_thread = threads.get("extract", {})
    last_run = extract_thread.get("last_run", "")
    if last_run:
        try:
            dt = datetime.fromisoformat(last_run[:19])
            formatted = dt.strftime("%Y-%m-%d %H:%M")
        except (ValueError, TypeError):
            formatted = last_run[:19]
        lines.append(f"- Last extraction: {formatted}")
    else:
        lines.append("- Last extraction: Never")

    # API stats if available
    stats = agent.get("stats", {})
    api_calls = stats.get("api_calls_today")
    cost = stats.get("api_cost_estimate_today")
    if api_calls is not None:
        cost_str = f" (~${cost:.2f})" if cost is not None else ""
        lines.append(f"- API calls today: {api_calls}{cost_str}")

    return lines


def _build_priorities(state):
    """Section: Priorities — declared_priorities from metadata."""
    lines = ["## Priorities"]

    priorities = state.get("metadata", {}).get("declared_priorities", [])
    if not priorities:
        lines.append("No priorities declared yet.")
        return lines

    for p in priorities:
        rank = p.get("rank", "?")
        name = p.get("name", "Unnamed")
        source = p.get("source", "")
        ptype = p.get("type", "")
        declared = p.get("declared", "")

        type_tag = f" [{ptype}]" if ptype else ""
        source_note = f" — _{source}_" if source else ""
        date_note = f" (declared {_format_date(declared)})" if declared else ""
        lines.append(f"{rank}. **{name}**{type_tag}{date_note}{source_note}")

    return lines


def _build_commitments(state, today):
    """Section: Active Commitments — grouped by age."""
    commitments = state.get("commitments", [])

    # Filter to active (non-terminal) only
    active = [
        c for c in commitments
        if not _is_terminal_commitment(c.get("status", "open"))
    ]

    lines = [f"## Active Commitments ({len(active)})"]

    if not active:
        lines.append("No open commitments tracked yet.")
        return lines

    overdue = []
    aging = []
    current = []

    overdue_days = brain_config.COMMITMENT_OVERDUE_DAYS    # 14
    aging_days = brain_config.COMMITMENT_AGING_DAYS        # 7

    for c in active:
        # Prefer explicit age_days field; fall back to calculating from date_committed / created
        age = c.get("age_days")
        if age is None:
            date_str = c.get("date_committed") or c.get("created") or ""
            age = _days_since(date_str, today)
        if age is None:
            age = 0

        if age >= overdue_days:
            overdue.append((age, c))
        elif age >= aging_days:
            aging.append((age, c))
        else:
            current.append((age, c))

    # Sort each bucket by age descending (oldest first)
    overdue.sort(key=lambda x: x[0], reverse=True)
    aging.sort(key=lambda x: x[0], reverse=True)
    current.sort(key=lambda x: x[0], reverse=True)

    def _fmt_commitment(age, c):
        person = c.get("person", "")
        desc = c.get("description", "No description")
        person_str = f" ({person})" if person else ""
        return f"- [{age}d]{person_str} {desc}"

    lines.append(f"### Overdue ({overdue_days}+ days)")
    if overdue:
        for age, c in overdue:
            lines.append(_fmt_commitment(age, c))
    else:
        lines.append("None")

    lines.append(f"### Aging ({aging_days}-{overdue_days - 1} days)")
    if aging:
        for age, c in aging:
            lines.append(_fmt_commitment(age, c))
    else:
        lines.append("None")

    lines.append("### Current")
    if current:
        for age, c in current:
            lines.append(_fmt_commitment(age, c))
    else:
        lines.append("None")

    return lines


def _build_decisions(state, today):
    """Section: Open Decisions — grouped by risk level."""
    decisions = state.get("decisions", [])

    active = [
        d for d in decisions
        if not _is_terminal_decision(d.get("execution_status", "no_evidence"))
    ]

    lines = [f"## Open Decisions ({len(active)})"]

    if not active:
        lines.append("No open decisions tracked yet.")
        return lines

    at_risk_days = brain_config.DECISION_AT_RISK_DAYS   # 7

    at_risk = []
    current = []

    for d in active:
        days = d.get("days_since")
        if days is None:
            date_str = d.get("decided_date") or d.get("created") or ""
            days = _days_since(date_str, today)
        if days is None:
            days = 0

        exec_status = d.get("execution_status", "no_evidence")
        # at_risk = flagged explicitly OR old enough with no execution evidence
        evidence = d.get("execution_evidence", [])
        is_at_risk = (
            exec_status == "at_risk"
            or (days >= at_risk_days and not evidence)
        )

        if is_at_risk:
            at_risk.append((days, d))
        else:
            current.append((days, d))

    at_risk.sort(key=lambda x: x[0], reverse=True)
    current.sort(key=lambda x: x[0], reverse=True)

    def _fmt_decision(days, d):
        desc = d.get("description", "No description")
        exec_status = d.get("execution_status", "")
        status_tag = f" [{exec_status}]" if exec_status else ""
        return f"- [{days}d]{status_tag} {desc}"

    lines.append(f"### At Risk ({at_risk_days}+ days, no execution evidence)")
    if at_risk:
        for days, d in at_risk:
            lines.append(_fmt_decision(days, d))
    else:
        lines.append("None")

    lines.append("### Active")
    if current:
        for days, d in current:
            lines.append(_fmt_decision(days, d))
    else:
        lines.append("None")

    return lines


def _build_people(state):
    """Section: People with Pending Items."""
    lines = ["## People with Pending Items"]

    people_model = state.get("people_model", {})
    if not people_model:
        lines.append("No people tracked yet.")
        return lines

    # Gather commitments per person (from commitments collection, not people_model)
    # The people_model has role/communication data; pending items come from open commitments
    commitments = state.get("commitments", [])
    active_commits = [
        c for c in commitments
        if not _is_terminal_commitment(c.get("status", "open"))
    ]

    # Build person → items map from active commitments
    person_items = {}
    for c in active_commits:
        person = c.get("person", "").strip()
        if person:
            person_items.setdefault(person, []).append(c.get("description", ""))

    # Also include people in people_model who have role info
    people_with_data = {}
    for name, data in people_model.items():
        role = data.get("role", "")
        items = person_items.get(name, [])
        if items or role:
            people_with_data[name] = {"role": role, "items": items}

    # Add any people in person_items not in people_model
    for name, items in person_items.items():
        if name not in people_with_data:
            people_with_data[name] = {"role": "", "items": items}

    # Filter to only those with pending items
    with_pending = {
        name: data
        for name, data in people_with_data.items()
        if data["items"]
    }

    if not with_pending:
        lines.append("No people with pending commitments.")
        return lines

    # Sort by number of items descending
    for name in sorted(with_pending, key=lambda n: len(with_pending[n]["items"]), reverse=True):
        data = with_pending[name]
        role_str = f" ({data['role']})" if data.get("role") else ""
        count = len(data["items"])
        lines.append(f"### {name}{role_str} — {count} item{'s' if count != 1 else ''}")
        for item in data["items"][:10]:  # Cap at 10 per person
            lines.append(f"- {item}")

    return lines


def _build_memories(store):
    """Section: Recent Memories — top 15 active by recency, decay > 0.5, grouped by type."""
    lines = ["## Recent Memories"]

    memories = store.get("memories", [])
    if not memories:
        lines.append(
            "No memories extracted yet. Use Claude Code normally and the memory agent "
            "will begin capturing decisions, commitments, and context automatically."
        )
        return lines

    # Filter: active + decay_score > 0.5
    eligible = [
        m for m in memories
        if m.get("status") == "active" and m.get("decay_score", 1.0) > 0.5
    ]

    if not eligible:
        lines.append(
            "No memories extracted yet. Use Claude Code normally and the memory agent "
            "will begin capturing decisions, commitments, and context automatically."
        )
        return lines

    # Sort by created descending, take top 15
    def _mem_sort_key(m):
        return m.get("created", "") or ""

    eligible.sort(key=_mem_sort_key, reverse=True)
    top = eligible[:15]

    # Group by type
    TYPE_ORDER = ["decision", "commitment", "preference", "correction", "context",
                  "relationship", "rule", "recommendation", "reference", "concern"]

    grouped = {}
    for m in top:
        mtype = m.get("type", "context")
        grouped.setdefault(mtype, []).append(m)

    # Render in type order, then any remaining types
    rendered_types = []
    for t in TYPE_ORDER:
        if t in grouped:
            rendered_types.append(t)
    for t in grouped:
        if t not in rendered_types:
            rendered_types.append(t)

    TYPE_LABELS = {
        "decision": "Decisions",
        "commitment": "Commitments",
        "preference": "Preferences",
        "correction": "Corrections",
        "context": "Context",
        "relationship": "Relationships",
        "rule": "Rules",
        "recommendation": "Recommendations",
        "reference": "References",
        "concern": "Concerns",
    }

    for mtype in rendered_types:
        items = grouped[mtype]
        label = TYPE_LABELS.get(mtype, mtype.title() + "s")
        lines.append(f"### {label}")
        for m in items:
            content = m.get("content", "").strip()
            confidence = m.get("confidence", 0)
            created = m.get("created", "")[:10]
            conf_str = f" ({int(confidence * 100)}%)" if confidence else ""
            date_str = f" — {created}" if created else ""
            lines.append(f"- {content}{conf_str}{date_str}")

    return lines


def _build_patterns(state):
    """Section: Patterns — behavioral, business, team, systemic."""
    lines = ["## Patterns"]

    patterns = state.get("patterns", {})
    all_patterns = []
    for category, items in patterns.items():
        for p in (items or []):
            all_patterns.append((category, p))

    if not all_patterns:
        lines.append("No patterns detected yet.")
        return lines

    # Group by category for display
    CATEGORY_LABELS = {
        "behavioral": "Behavioral",
        "business": "Business",
        "team": "Team",
        "systemic": "Systemic",
    }

    category_order = ["behavioral", "business", "team", "systemic"]
    grouped = {}
    for cat, p in all_patterns:
        grouped.setdefault(cat, []).append(p)

    rendered = []
    for cat in category_order:
        if cat in grouped:
            rendered.append(cat)
    for cat in grouped:
        if cat not in rendered:
            rendered.append(cat)

    for cat in rendered:
        items = grouped[cat]
        label = CATEGORY_LABELS.get(cat, cat.title())
        lines.append(f"### {label} ({len(items)})")
        for p in items[:5]:  # Cap at 5 per category
            desc = p.get("description", "No description")
            confidence = p.get("confidence")
            conf_str = f" ({int(confidence * 100)}%)" if confidence is not None else ""
            lines.append(f"- {desc}{conf_str}")
        if len(items) > 5:
            lines.append(f"- _...and {len(items) - 5} more_")

    return lines


# ---------------------------------------------------------------------------
# Main generator
# ---------------------------------------------------------------------------

def generate_briefing():
    """Generate BRIEFING.md from brain-state.json and memory-store.json.

    Returns the path to the generated file.
    """
    today = date.today()
    now = datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M")

    # Load brain state
    state = brain_config.load_state()

    # Load memory store
    store, load_status = _load_memory_store(brain_config.DATA_DIR)
    if load_status == "unavailable":
        # Generate with empty store — graceful fallback
        store = {}

    # Build sections
    sections = []

    # Header
    sections.append(f"# Intelligence Briefing")
    sections.append(f"> Auto-generated by Memory System | {date_str} {time_str}")
    sections.append("")

    # System Status
    sections.extend(_build_system_status(store))
    sections.append("")

    # Priorities
    sections.extend(_build_priorities(state))
    sections.append("")

    # Active Commitments
    sections.extend(_build_commitments(state, today))
    sections.append("")

    # Open Decisions
    sections.extend(_build_decisions(state, today))
    sections.append("")

    # People with Pending Items
    sections.extend(_build_people(state))
    sections.append("")

    # Recent Memories
    sections.extend(_build_memories(store))
    sections.append("")

    # Patterns
    sections.extend(_build_patterns(state))
    sections.append("")

    # Footer
    sections.append("---")
    sections.append(f"_Generated {date_str} {time_str} | brain-state v{state.get('metadata', {}).get('version', '?')} | "
                    f"memories: {len(store.get('memories', []))} total_")

    content = "\n".join(sections)

    # Write atomically
    output_path = os.path.join(config.MEMORY_DIR, "BRIEFING.md")
    os.makedirs(config.MEMORY_DIR, exist_ok=True)
    config.atomic_write(output_path, content)

    return output_path


# ---------------------------------------------------------------------------
# Standalone execution
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    path = generate_briefing()
    print(path)
