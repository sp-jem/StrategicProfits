#!/usr/bin/env python3
"""
brain_memory_bridge_fm.py — Memory Bridge for Force Multiplier

Runs as Step 2b in the daily pipeline (after backup, before corrections).
Reads memory-store.json and:
  1. Propagates correction memories → pending-corrections.json
  2. Fills gaps: decisions/commitments from Claude sessions → state
  3. Detects duplicates in brain-state → pending-corrections.json
  4. Tracks what's been bridged via watermarks

Never writes to brain-state.json directly. Mutates the in-memory state dict
(same pattern as all pipeline steps) and writes to pending-corrections.json.
"""

import os
import sys
import json
import time
import hashlib
from datetime import datetime, date

BRAIN_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(BRAIN_DIR)
for p in [BRAIN_DIR, PROJECT_DIR]:
    if p not in sys.path:
        sys.path.insert(0, p)

try:
    import config
    import brain_config
except ImportError as e:
    print(f"\nERROR: Required module not found: {e}")
    print("The memory bridge requires config.py and brain_config.py from the Day 6 setup.")
    print("Please complete /setup-brain before running brain_memory_bridge_fm.py.\n")
    sys.exit(1)

log = config.setup_logging("brain-memory-bridge")

# Thresholds
JACCARD_CORRECTION_THRESHOLD = 0.5   # corrections are destructive, need stronger match
JACCARD_DEDUP_THRESHOLD = 0.6        # tighter for flagging brain's own duplicates
JACCARD_GAP_THRESHOLD = 0.4          # threshold for gap filling matches

# Limits
MAX_CORRECTIONS_PER_RUN = 20
MAX_GAPS_PER_RUN = 15
MAX_VAULT_CONTENT_CHARS = 8000
MAX_VAULT_CONTENT_FILES = 5

# Terminal statuses — import from canonical source to avoid drift
TERMINAL_STATUSES = brain_config.TERMINAL_STATUSES
DECISION_TERMINAL = brain_config.DECISION_TERMINAL_STATUSES


# ---------------------------------------------------------------------------
# Jaccard similarity
# ---------------------------------------------------------------------------
def _safe_days_since(date_iso, target_date):
    """Calculate days since date_iso, returning 1 on any parse error."""
    if not date_iso or len(date_iso) < 10:
        return 1
    try:
        return max((target_date - datetime.strptime(date_iso[:10], "%Y-%m-%d").date()).days, 0)
    except (ValueError, TypeError):
        return 1


def _jaccard(text_a, text_b):
    """Word-level Jaccard similarity between two strings."""
    if not text_a or not text_b:
        return 0.0
    words_a = set(text_a.lower().split())
    words_b = set(text_b.lower().split())
    if not words_a or not words_b:
        return 0.0
    intersection = words_a & words_b
    union = words_a | words_b
    return len(intersection) / len(union) if union else 0.0


# ---------------------------------------------------------------------------
# Safe memory store loading
# ---------------------------------------------------------------------------
def _load_memory_store_safe():
    """Load memory-store.json with mid-write protection.
    Returns (store_dict, status) where status is 'ok', 'used_backup', or 'unavailable'."""
    memory_store_path = os.path.join(brain_config.DATA_DIR, "memory-store.json")

    if not os.path.exists(memory_store_path):
        return None, "unavailable"

    # Try primary
    for attempt in range(2):
        try:
            with open(memory_store_path, "r", encoding="utf-8") as f:
                store = json.load(f)
            return store, "ok"
        except (json.JSONDecodeError, IOError):
            if attempt == 0:
                time.sleep(0.2)  # Wait 200ms for atomic write to complete

    # Try backup
    backup_path = memory_store_path + ".bak"
    if os.path.exists(backup_path):
        try:
            with open(backup_path, "r", encoding="utf-8") as f:
                store = json.load(f)
            log.warning("Used .bak file for memory store (primary was unreadable)")
            return store, "used_backup"
        except (json.JSONDecodeError, IOError):
            pass

    return None, "unavailable"


# ---------------------------------------------------------------------------
# Watermark management
# ---------------------------------------------------------------------------
BRIDGE_WATERMARKS_FILE = os.path.join(brain_config.DATA_DIR, "bridge-watermarks.json")


def _get_bridge_watermarks(store):
    """Read bridge watermarks from dedicated file (not memory-store.json).
    Falls back to memory-store.json watermarks for migration from old format."""
    # Try dedicated file first
    if os.path.exists(BRIDGE_WATERMARKS_FILE):
        try:
            with open(BRIDGE_WATERMARKS_FILE, "r", encoding="utf-8") as f:
                wm = json.load(f)
            return {
                "last_run": wm.get("last_run", ""),
                "bridged_memory_ids": set(wm.get("bridged_memory_ids", [])),
                "last_commitments_hash": wm.get("last_commitments_hash", ""),
                "last_decisions_hash": wm.get("last_decisions_hash", ""),
            }
        except (json.JSONDecodeError, IOError):
            pass

    # Migration fallback: read from old location in memory-store.json
    wm = store.get("watermarks", {}).get("bridge", {})
    return {
        "last_run": wm.get("last_run", ""),
        "bridged_memory_ids": set(wm.get("bridged_memory_ids", [])),
        "last_commitments_hash": wm.get("last_commitments_hash", ""),
        "last_decisions_hash": wm.get("last_decisions_hash", ""),
    }


def _save_bridge_watermarks(watermarks, bridged_ids_to_add, stats, all_memory_ids):
    """Write bridge watermarks to dedicated file. Never touches memory-store.json."""
    try:
        # Merge new bridged IDs with existing
        existing = set()
        if os.path.exists(BRIDGE_WATERMARKS_FILE):
            try:
                with open(BRIDGE_WATERMARKS_FILE, "r", encoding="utf-8") as f:
                    existing = set(json.load(f).get("bridged_memory_ids", []))
            except (json.JSONDecodeError, IOError):
                pass

        all_bridged = existing | bridged_ids_to_add

        # Prune IDs for memories no longer in store to keep set bounded
        pruned = all_bridged & all_memory_ids if all_memory_ids else all_bridged

        bridge_wm = {
            "last_run": datetime.now().isoformat(),
            "bridged_memory_ids": sorted(pruned),
            "last_commitments_hash": watermarks.get("last_commitments_hash", ""),
            "last_decisions_hash": watermarks.get("last_decisions_hash", ""),
            "stats_cumulative": stats,
        }

        config.atomic_write(BRIDGE_WATERMARKS_FILE, json.dumps(bridge_wm, indent=2, ensure_ascii=False))
        log.info("Bridge watermarks saved to dedicated file: %d bridged IDs tracked", len(pruned))
        return True
    except Exception as e:
        log.warning("Failed to save bridge watermarks (non-fatal, will re-scan next run): %s", e)
        return False


# ---------------------------------------------------------------------------
# Correction propagation (backward: memory corrections → pending-corrections.json)
# ---------------------------------------------------------------------------
def _extract_corrections_to_propagate(memories, state, already_bridged):
    """Find correction memories that match active brain-state items."""
    corrections = []
    correction_mems = [
        m for m in memories
        if m.get("type") == "correction"
        and m.get("status") == "active"
        and m.get("id") not in already_bridged
        and m.get("confidence", 0) >= 0.7
    ]

    if not correction_mems:
        return corrections

    # Load owner name
    _owner_name = "Owner"
    _cc_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "companion-config.json")
    if os.path.exists(_cc_path):
        try:
            with open(_cc_path, "r") as f:
                _cc = json.load(f)
            _owner_name = _cc.get("name", "Owner") or "Owner"
        except (json.JSONDecodeError, IOError):
            pass

    # Build active items from state
    active_commitments = [
        c for c in state.get("commitments", [])
        if c.get("status") not in TERMINAL_STATUSES
    ]
    active_decisions = [
        d for d in state.get("decisions", [])
        if d.get("execution_status") not in DECISION_TERMINAL
    ]

    for mem in correction_mems[:MAX_CORRECTIONS_PER_RUN]:
        mem_content = mem.get("content", "")
        best_match = None
        best_score = 0
        best_type = None

        mem_words = set(mem_content.lower().split()) if mem_content else set()

        for c in active_commitments:
            desc = c.get("description", "")
            score = _jaccard(mem_content, desc)
            desc_words = set(desc.lower().split()) if desc else set()
            shared = len(mem_words & desc_words)
            if score > JACCARD_CORRECTION_THRESHOLD and score > best_score and shared >= 5:
                best_match = c
                best_score = score
                best_type = "commitment"

        for d in active_decisions:
            desc = d.get("description", "")
            score = _jaccard(mem_content, desc)
            desc_words = set(desc.lower().split()) if desc else set()
            shared = len(mem_words & desc_words)
            if score > JACCARD_CORRECTION_THRESHOLD and score > best_score and shared >= 5:
                best_match = d
                best_score = score
                best_type = "decision"

        if best_match:
            corrections.append({
                "target_type": best_type,
                "target_id": best_match.get("id", ""),
                "correction": mem_content[:300],
                "original_value": best_match.get("description", "")[:300],
                "corrected_value": mem_content[:300],  # UPDATE description, don't invalidate
                "source": "memory_bridge",
                "memory_id": mem.get("id", ""),
                "user": _owner_name,
            })

    return corrections


# ---------------------------------------------------------------------------
# Gap filling (forward: memory decisions/commitments → state)
# ---------------------------------------------------------------------------
def _extract_gaps_to_fill(memories, state, already_bridged, target_date):
    """Find decision/commitment memories not already in brain-state."""
    new_decisions = []
    new_commitments = []

    # Load owner name
    _owner_name = "Owner"
    _cc_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "companion-config.json")
    if os.path.exists(_cc_path):
        try:
            with open(_cc_path, "r") as f:
                _cc = json.load(f)
            _owner_name = _cc.get("name", "Owner") or "Owner"
        except (json.JSONDecodeError, IOError):
            pass

    # Only bridge memories from Claude Code sessions (that's the gap the brain misses)
    gap_candidates = [
        m for m in memories
        if m.get("status") == "active"
        and m.get("id") not in already_bridged
        and m.get("confidence", 0) >= 0.8
        and m.get("source") == "claude_code"
        and m.get("type") in ("decision", "commitment")
    ]

    if not gap_candidates:
        return new_decisions, new_commitments

    # Existing non-terminal items for dedup (exclude completed/resolved to avoid permanent language shadowing)
    existing_decisions = [
        d.get("description", "").lower() for d in state.get("decisions", [])
        if d.get("execution_status") not in DECISION_TERMINAL
    ]
    existing_commitments = [
        c.get("description", "").lower() for c in state.get("commitments", [])
        if c.get("status") not in TERMINAL_STATUSES
    ]

    # Track seq counters per date prefix to avoid ID collisions within a single run
    dec_seq_by_date = {}
    com_seq_by_date = {}

    for mem in gap_candidates[:MAX_GAPS_PER_RUN]:
        content = mem.get("content", "")
        content_lower = content.lower()

        # Use memory's own creation date for IDs (not pipeline target_date)
        mem_date_str = mem.get("created", "")[:10].replace("-", "")
        if len(mem_date_str) != 8:
            mem_date_str = target_date.strftime("%Y%m%d")
        mem_date_iso = mem.get("created", "")[:10] or target_date.strftime("%Y-%m-%d")

        if mem.get("type") == "decision":
            # Dedup against existing decisions
            if any(_jaccard(content_lower, ed) > JACCARD_GAP_THRESHOLD for ed in existing_decisions):
                continue

            if mem_date_str not in dec_seq_by_date:
                decisions = state.get("decisions", [])
                dec_seq_by_date[mem_date_str] = len([d for d in decisions if d.get("id", "").startswith(f"decision_mb_{mem_date_str}")]) + 1
            seq = dec_seq_by_date[mem_date_str]
            dec_seq_by_date[mem_date_str] += 1
            new_decisions.append({
                "id": f"decision_mb_{mem_date_str}_{seq:03d}",
                "description": content,
                "source": f"memory_bridge:{mem['id']}",
                "decided_date": mem_date_iso,
                "execution_status": "no_evidence",
                "days_since": _safe_days_since(mem_date_iso, target_date),
                "execution_evidence": [],
                "resolved_date": None,
                "resolved_by": None,
                "superseded_by": None,
                "source_channel": "memory_bridge",
                "confidence": mem.get("confidence", 0.7),
                "needs_review": True,
            })
            existing_decisions.append(content_lower)  # Prevent self-duplication

        elif mem.get("type") == "commitment":
            # Dedup against existing commitments
            if any(_jaccard(content_lower, ec) > JACCARD_GAP_THRESHOLD for ec in existing_commitments):
                continue

            if mem_date_str not in com_seq_by_date:
                commitments = state.get("commitments", [])
                com_seq_by_date[mem_date_str] = len([c for c in commitments if c.get("id", "").startswith(f"commit_mb_{mem_date_str}")]) + 1
            seq = com_seq_by_date[mem_date_str]
            com_seq_by_date[mem_date_str] += 1
            new_commitments.append({
                "id": f"commit_mb_{mem_date_str}_{seq:03d}",
                "person": _owner_name,
                "description": content,
                "source": f"memory_bridge:{mem['id']}",
                "source_files": [],
                "date_committed": mem_date_iso,
                "status": "open",
                "age_days": _safe_days_since(mem_date_iso, target_date),
                "urgency_level": "normal",
                "completion_signals": [],
                "completed_date": None,
                "completed_by": None,
                "relationship": "owner_owns",
                "source_channel": "memory_bridge",
                "confidence": mem.get("confidence", 0.7),
                "linked_project": None,
                "needs_review": True,
            })
            existing_commitments.append(content_lower)

    return new_decisions, new_commitments


# ---------------------------------------------------------------------------
# Duplicate detection (brain-state items against each other)
# ---------------------------------------------------------------------------
def _detect_brain_state_duplicates(state, watermarks):
    """Cross-compare active brain-state commitments for duplicates."""
    corrections = []

    # Load owner name
    _owner_name = "Owner"
    _cc_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "companion-config.json")
    if os.path.exists(_cc_path):
        try:
            with open(_cc_path, "r") as f:
                _cc = json.load(f)
            _owner_name = _cc.get("name", "Owner") or "Owner"
        except (json.JSONDecodeError, IOError):
            pass

    # Only run if commitments have changed since last bridge run
    active_commits = [
        c for c in state.get("commitments", [])
        if c.get("status") not in TERMINAL_STATUSES
    ]
    commit_hash = hashlib.md5(
        json.dumps(sorted([c.get("id", "") for c in active_commits])).encode()
    ).hexdigest()

    if commit_hash == watermarks.get("last_commitments_hash", ""):
        return corrections, commit_hash  # No change since last run

    # O(n^2) but n is small (typically < 50 active commitments)
    flagged_ids = set()  # Prevent transitive chain inflation (A~B, B~C → B flagged twice)
    for i, c1 in enumerate(active_commits):
        if c1.get("id", "") in flagged_ids:
            continue
        desc1 = c1.get("description", "")
        for c2 in active_commits[i + 1:]:
            if c2.get("id", "") in flagged_ids:
                continue
            desc2 = c2.get("description", "")
            score = _jaccard(desc1, desc2)
            if score >= JACCARD_DEDUP_THRESHOLD:
                # Keep the newer one (higher date), flag the older as duplicate
                date1 = c1.get("date_committed", "")
                date2 = c2.get("date_committed", "")
                dupe = c1 if date1 < date2 else c2
                keeper = c2 if date1 < date2 else c1
                flagged_ids.add(dupe.get("id", ""))

                corrections.append({
                    "target_type": "commitment",
                    "target_id": dupe.get("id", ""),
                    "correction": f"Duplicate of {keeper.get('id', '')} (Jaccard {score:.2f}): {keeper.get('description', '')[:100]}",
                    "original_value": dupe.get("description", "")[:300],
                    "corrected_value": None,
                    "source": "memory_bridge_dedup",
                    "user": _owner_name,
                })

    return corrections, commit_hash


# ---------------------------------------------------------------------------
# Write pending corrections (merge with existing file)
# ---------------------------------------------------------------------------
def _write_pending_corrections(new_corrections):
    """Merge new corrections into pending-corrections.json. Returns count written."""
    if not new_corrections:
        return 0

    corrections_file = brain_config.PENDING_CORRECTIONS_FILE

    # Read existing
    existing = []
    if os.path.exists(corrections_file):
        try:
            with open(corrections_file, "r", encoding="utf-8") as f:
                existing = json.load(f)
                if not isinstance(existing, list):
                    existing = []
        except (json.JSONDecodeError, IOError):
            existing = []

    # Dedup: skip if target_id already in file
    existing_target_ids = {e.get("target_id") for e in existing}
    to_add = [c for c in new_corrections if c.get("target_id") not in existing_target_ids]

    if not to_add:
        return 0

    merged = existing + to_add
    config.atomic_write(corrections_file, json.dumps(merged, indent=2, ensure_ascii=False))
    log.info("Wrote %d corrections to pending-corrections.json (%d already existed)",
             len(to_add), len(existing))
    return len(to_add)


# ---------------------------------------------------------------------------
# Inject gaps into state
# ---------------------------------------------------------------------------
def _inject_gaps_into_state(state, new_decisions, new_commitments):
    """Insert new items into state collections. Returns count injected."""
    count = 0
    if new_decisions:
        state.setdefault("decisions", []).extend(new_decisions)
        count += len(new_decisions)
        log.info("Injected %d decisions from Memory Agent (needs_review=True)", len(new_decisions))

    if new_commitments:
        state.setdefault("commitments", []).extend(new_commitments)
        count += len(new_commitments)
        log.info("Injected %d commitments from Memory Agent (needs_review=True)", len(new_commitments))

    return count


# ---------------------------------------------------------------------------
# Story routing (memory content → new-stories-staging.md)
# ---------------------------------------------------------------------------
STORY_TAGS = {"story", "storytelling", "story-bank", "stories", "narrative", "vulnerability"}
STORY_KEYWORDS = {"story", "stories", "told the story", "narrative", "vulnerability", "origin story",
                  "story architecture", "story bank", "retelling", "anecdote"}

def _route_stories_to_staging(memories, already_bridged, target_date):
    """Find story-related memories and append to new-stories-staging.md.
    Returns (count, set_of_routed_memory_ids).
    NOTE: This function is DISABLED in the FM version. It remains here for
    reference but is never called. See run_memory_bridge() below."""
    # Story routing requires a vault-specific Story Bank path.
    # FM students don't have this structure, so this function is not called.
    return 0, set()

    candidates = []
    for m in memories:
        if m.get("id") in already_bridged:
            continue
        if m.get("type") not in ("context", "reference", "decision"):
            continue

        tags = set(t.lower() for t in m.get("tags", []))
        content_lower = m.get("content", "").lower()

        # Match by tags or content keywords
        if (tags & STORY_TAGS) or any(kw in content_lower for kw in STORY_KEYWORDS):
            candidates.append(m)

    if not candidates:
        return 0, set()

    routed_ids = {m.get("id") for m in candidates[:10] if m.get("id")}

    # Read existing staging (rotate if > 50KB to prevent unbounded growth)
    existing = ""
    if os.path.exists(staging_path):
        try:
            file_size = os.path.getsize(staging_path)
            if file_size > 50 * 1024:
                base_archive = staging_path.replace(".md", f"-archived-{datetime.now().strftime('%Y%m%d')}")
                archive_path = base_archive + ".md"
                n = 1
                while os.path.exists(archive_path):
                    archive_path = f"{base_archive}-{n}.md"
                    n += 1
                os.rename(staging_path, archive_path)
                log.info("Rotated staging file (%d bytes) to %s", file_size, archive_path)
            else:
                with open(staging_path, "r", encoding="utf-8") as f:
                    existing = f.read()
        except IOError:
            pass

    date_str = target_date.strftime("%Y-%m-%d")
    lines = []
    if not existing:
        lines.append("# New Stories Staging")
        lines.append("")
        lines.append("> Auto-extracted by the Intelligence Engine. Review weekly.")
        lines.append("")
        lines.append("---")
        lines.append("")

    lines.append(f"## Memory Bridge — {date_str}")
    lines.append("")

    for m in candidates[:10]:
        lines.append(f"### {m.get('content', '')[:80]}")
        lines.append(f"**Source:** Memory Agent ({m.get('source', 'unknown')})")
        lines.append(f"**Trigger:** memory_bridge:{m.get('id', '')}")
        lines.append(f"**Theme (auto):** {', '.join(m.get('tags', []))}")
        lines.append("")
        reasoning = m.get("reasoning", "")
        if reasoning:
            lines.append(f"> {reasoning[:500]}")
        else:
            lines.append(f"> {m.get('content', '')[:500]}")
        lines.append("")
        lines.append("**Status:** PENDING REVIEW")
        lines.append("")
        lines.append("---")
        lines.append("")

    content = existing.rstrip("\n") + "\n\n" + "\n".join(lines) if existing else "\n".join(lines)
    os.makedirs(os.path.dirname(staging_path), exist_ok=True)
    config.atomic_write(staging_path, content)
    routed_count = min(len(candidates), 10)
    log.info("Routed %d story-related memories to staging (%d candidates total)", routed_count, len(candidates))
    return routed_count, routed_ids


# ---------------------------------------------------------------------------
# Topic cluster surfacing (for session-context.md)
# ---------------------------------------------------------------------------
def _surface_topic_clusters(memories, state):
    """Group active memories by top tags, inject into state for session-context.md generation."""
    # Count tags across active memories
    tag_counts = {}
    tag_memories = {}
    for m in memories:
        for tag in m.get("tags", []):
            tag = tag.lower()
            tag_counts[tag] = tag_counts.get(tag, 0) + 1
            tag_memories.setdefault(tag, []).append(m)

    # Top 10 tags with 3+ memories
    top_tags = sorted(
        [(tag, count) for tag, count in tag_counts.items() if count >= 3],
        key=lambda x: x[1], reverse=True
    )[:10]

    if not top_tags:
        return 0

    clusters = []
    for tag, count in top_tags:
        mems = sorted(tag_memories[tag], key=lambda m: m.get("created", ""), reverse=True)
        cluster = {
            "topic": tag,
            "memory_count": count,
            "recent_items": [
                {"type": m.get("type"), "content": m.get("content", "")[:100]}
                for m in mems[:5]
            ],
        }
        clusters.append(cluster)

    state["_memory_clusters"] = clusters
    log.info("Surfaced %d topic clusters from memory", len(clusters))
    return len(clusters)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def run_memory_bridge(state, target_date):
    """Read memory-store.json, propagate corrections and gaps to brain state.
    Returns stats dict."""
    stats = {
        "corrections_written": 0,
        "gaps_filled": 0,
        "duplicates_flagged": 0,
        "memories_scanned": 0,
        "skipped_watermarked": 0,
        "memory_store_unavailable": False,
        "stories_routed": 0,
        "clusters_surfaced": 0,
    }

    # Load memory store safely
    store, load_status = _load_memory_store_safe()
    if store is None:
        log.warning("Memory store unavailable (%s) — bridge skipped", load_status)
        stats["memory_store_unavailable"] = True
        return stats

    if load_status == "used_backup":
        log.warning("Using backup memory store — results may be slightly stale")

    memories = [m for m in store.get("memories", []) if m.get("status") == "active"]
    stats["memories_scanned"] = len(memories)
    log.info("Memory bridge: %d active memories loaded", len(memories))

    # Get watermarks
    watermarks = _get_bridge_watermarks(store)
    already_bridged = watermarks["bridged_memory_ids"]
    newly_bridged = set()

    # 1. Correction propagation
    correction_entries = _extract_corrections_to_propagate(memories, state, already_bridged)
    for ce in correction_entries:
        mem_id = ce.get("memory_id", "")
        if mem_id:
            newly_bridged.add(mem_id)

    # 2. Gap filling
    new_decisions, new_commitments = _extract_gaps_to_fill(
        memories, state, already_bridged, target_date
    )
    for d in new_decisions:
        mem_id = d.get("source", "").replace("memory_bridge:", "")
        if mem_id:
            newly_bridged.add(mem_id)
    for c in new_commitments:
        mem_id = c.get("source", "").replace("memory_bridge:", "")
        if mem_id:
            newly_bridged.add(mem_id)

    # 3. Duplicate detection
    dedup_corrections, commit_hash = _detect_brain_state_duplicates(state, watermarks)
    watermarks["last_commitments_hash"] = commit_hash

    # 4. Write corrections (both from propagation and dedup)
    all_corrections = correction_entries + dedup_corrections
    stats["corrections_written"] = _write_pending_corrections(all_corrections)
    stats["duplicates_flagged"] = len(dedup_corrections)

    # 5. Inject gaps
    stats["gaps_filled"] = _inject_gaps_into_state(state, new_decisions, new_commitments)

    # Story routing disabled for FM version (requires vault-specific Story Bank structure)
    stats["stories_routed"] = 0

    # 5c. Surface topic clusters for session-context.md
    try:
        stats["clusters_surfaced"] = _surface_topic_clusters(memories, state)
    except Exception as e:
        log.warning("Topic cluster surfacing failed (non-fatal): %s", e)
        stats["clusters_surfaced"] = 0

    # 6. Watermarking note: only memories that produced actual output (corrections,
    # gaps, stories) are in newly_bridged. Memories that were evaluated but didn't
    # match are intentionally left unwatermarked so they can be retried when new
    # state items appear in future runs.

    stats["skipped_watermarked"] = len(already_bridged)

    # 7. Save watermarks — read cumulative from dedicated file (not old memory-store location)
    existing_wm = {}
    if os.path.exists(BRIDGE_WATERMARKS_FILE):
        try:
            with open(BRIDGE_WATERMARKS_FILE, "r", encoding="utf-8") as f:
                existing_wm = json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    cumulative = existing_wm.get("stats_cumulative", {})
    cumulative["corrections_written"] = cumulative.get("corrections_written", 0) + stats["corrections_written"]
    cumulative["gaps_filled"] = cumulative.get("gaps_filled", 0) + stats["gaps_filled"]
    cumulative["duplicates_flagged"] = cumulative.get("duplicates_flagged", 0) + stats["duplicates_flagged"]

    all_memory_ids = {m.get("id") for m in store.get("memories", []) if m.get("id")}
    _save_bridge_watermarks(watermarks, newly_bridged, cumulative, all_memory_ids)

    log.info("Memory bridge complete: %d corrections, %d gaps filled, %d duplicates, %d skipped (watermarked)",
             stats["corrections_written"], stats["gaps_filled"],
             stats["duplicates_flagged"], stats["skipped_watermarked"])

    return stats


if __name__ == "__main__":
    """Run bridge standalone."""
    from datetime import date
    state = brain_config.load_state()
    target = date.today()
    stats = run_memory_bridge(state, target)
    brain_config.save_state(state)
    print(f"Bridge complete: {stats}")
