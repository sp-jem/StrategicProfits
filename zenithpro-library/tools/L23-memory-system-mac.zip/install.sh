#!/bin/bash
#
# Memory System — Mac Installer
# Installs the setup-memory-system skill and its Python files.
#
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

echo ""
echo -e "${BOLD}Memory System — Installer${NC}"
echo "================================"
echo ""

SKILLS_DIR="$HOME/.claude/skills"

# Check Claude Code skills directory exists
if [ ! -d "$SKILLS_DIR" ]; then
    echo -e "  ${YELLOW}⚠${NC} Skills directory not found at $SKILLS_DIR"
    echo "  Creating it now..."
    mkdir -p "$SKILLS_DIR"
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALLED=0
SKIPPED=0

# Ensure credentials directory exists
mkdir -p "$HOME/.claude/credentials"
echo -e "  ${GREEN}✓${NC} Credentials directory ready at ~/.claude/credentials/"

# Install the setup skill
SKILL="setup-memory-system"
if [ -d "$SCRIPT_DIR/$SKILL" ]; then
    if [ -d "$SKILLS_DIR/$SKILL" ]; then
        echo -e "  ${YELLOW}⚠${NC} $SKILL already exists — replacing"
        rm -rf "$SKILLS_DIR/$SKILL"
    fi
    cp -R "$SCRIPT_DIR/$SKILL" "$SKILLS_DIR/$SKILL"
    echo -e "  ${GREEN}✓${NC} Installed $SKILL skill"
    INSTALLED=$((INSTALLED + 1))
else
    echo -e "  ${RED}✗${NC} $SKILL not found in installer directory"
    SKIPPED=$((SKIPPED + 1))
fi

# Copy Python files to the skill's references directory for the setup skill to use
if [ -d "$SKILLS_DIR/$SKILL" ]; then
    REF_DIR="$SKILLS_DIR/$SKILL/references"
    mkdir -p "$REF_DIR"

    for PYFILE in memory-agent-fm.py brain_memory_bridge_fm.py brain_briefing.py verify-memory-system.py; do
        if [ -f "$SCRIPT_DIR/$PYFILE" ]; then
            cp "$SCRIPT_DIR/$PYFILE" "$REF_DIR/$PYFILE"
            chmod +x "$REF_DIR/$PYFILE"
            echo -e "  ${GREEN}✓${NC} Copied $PYFILE"
            INSTALLED=$((INSTALLED + 1))
        else
            echo -e "  ${RED}✗${NC} $PYFILE not found in installer directory"
            SKIPPED=$((SKIPPED + 1))
        fi
    done
else
    echo -e "  ${RED}✗${NC} Skipping Python file copy — skill directory was not installed"
    SKIPPED=$((SKIPPED + 4))
fi

echo ""
echo "================================"
echo -e "${GREEN}${BOLD}Installation complete!${NC}"
echo ""
echo "  Installed: $INSTALLED items"
[ $SKIPPED -gt 0 ] && echo "  Skipped:   $SKIPPED items (check errors above)"
echo ""
echo "  Next step:"
echo "    Open Claude Code and tell it: 'Run setup-memory-system'"
echo ""
echo "  The setup skill will:"
echo "    1. Verify your Day 6 infrastructure is ready"
echo "    2. Install the memory agent, bridge, and briefing generator"
echo "    3. Start the memory agent daemon"
echo "    4. Run verification"
echo ""
echo "  Prerequisites (from Day 6):"
echo "    - setup-brain completed"
echo "    - Anthropic API key in ~/.claude/credentials/anthropic-linker.env"
echo "    - Python 3 with anthropic package"
echo ""
