---
name: zpro-affiliate-finder
description: Find, vet, match, and brief affiliates and JV partners for your launches using conversion evidence instead of list-size guesswork. Use when choosing who should promote a launch, evaluating a JV/affiliate candidate, building a recruiting shortlist, drafting outreach, or updating partner performance after a promo. Triggers - "find affiliates", "who should promote", "JV partner", "affiliate shortlist", "score this affiliate", "fill the room", "vet this partner", "build a recruiting kit". Do NOT use for - affiliate-program payout/tracking tech setup, or generic affiliate-marketing theory.
version: 1.0.0
---

# ZPro Affiliate Finder

**The one idea that runs everything below:** Affiliate *quality* — not list size — is the single biggest lever on your launch revenue. The same partner can convert ~16% of their registrants into buyers on an offer their audience is primed for, and ~1% on one they're not — same list, different fit. Two partners can send the exact same number of registrants and produce wildly different sales, because what actually predicts a sale is whether their audience already **trusts them** and already **buys things priced like what you're selling**. A big list of the wrong people converts near zero. This skill makes every affiliate decision run against evidence you collect, not against how impressive a follower count sounds.

**What this skill is / is not:** It finds, scores, matches, and briefs partners. It never negotiates commissions, never sends outreach on its own, and never commits you to terms — you (or your partnerships lead) do that. It is a decision engine, not an autopilot.

**Who this is for:** Any business owner or launch team recruiting affiliates/JV partners to promote an offer to their audiences.

---

## FIRST RUN — set up your data (do this once)

This skill scores partners against **your own** conversion history. It ships with no data — that's the point; your data is your edge.

1. Look for your affiliate database file. Default location: `affiliate-database.md` in the folder you're working in (or wherever you keep it — just tell the skill the path).
2. If it doesn't exist yet, create it from `references/affiliate-database-template.md`. It's a simple table you fill in one row per partner per promo.
3. You don't need history to start. A brand-new partner with no data is scored as **PROFILE-ONLY** (see below) — you evaluate the *fit*, then run a small test send before betting a launch on them.

Every run after that reads your database live so decisions always reflect your latest results. **Prior-session memory does not count — always re-read the file.**

---

## HARD RULES (apply in every mode)

1. **Intent beats volume — always.** The best predictor you can track is *buying intent before the pitch* — e.g., the % of a partner's registrants who take a high-intent action (book a call, grab a VIP/paid upgrade, reply "I'm in"). List size NEVER overrides it. A high-intent, small-but-warm audience beats a huge cold one every time.
2. **Default intent benchmarks (calibrate to your own data over time):** >10% high-intent = excellent · 6–10% = good · 3–6% = marginal · <3% = don't use. A value sitting exactly on a boundary resolves UP into the better band (exactly 6% = good; exactly 3% = marginal). These are sensible starting lines, not laws — once you have ~5+ promos of your own, recalibrate the bands to your reality.
3. **Keep your metrics separate.** The intent bands apply ONLY to your intent/pre-pitch signal. Final sales-conversion % is a *different* metric — never feed a sales-conv% into the intent bands. If a row only has sales-conv% and no intent number, say so explicitly and judge on what you have.
4. **The screening question** for any candidate: *"Have they promoted a similarly-priced offer to a warm, trust-based audience before?"* — NOT "how big is their list." Answer YES / NO / UNKNOWN with evidence. UNKNOWN caps the verdict at CAUTION until you've documented their audience.
5. **Volume veto.** A partner below your <3% intent line is a no, regardless of how many registrants they can send. When someone pushes "but they have 500K followers," restate this rule — followers are not buyers.
6. **Score partner × offer, never the partner alone.** The same partner can convert 16% on one offer and ~1% on another — same list, different fit. Always evaluate a partner against *this specific offer*. Show every historical row; never average a partner's results across different offers.
7. **Small-sample caution.** Any promo with a small registrant count (say under ~150) or approximate figures is a small sample. Always print the registrant count beside the %. Never promote a partner to your top tier, or top-rank them, on a single small-sample promo.
8. **Intent-without-sales flag.** A partner with a decent intent % but zero actual sales in your history gets CAUTION, never a green light. Intent that never closes is a warning, not a win.
9. **Zero fabrication.** Every number in every output must trace to a row in your database (name the row) or to sourced research on the candidate. A candidate with no history is labeled "PROFILE-ONLY — no conversion data," never given an invented number. NEVER estimate, infer, or extrapolate an intent %.
10. **Relationship status.** Before any shortlist or outreach, check your database's "Relationship status" notes. A paused/burned/do-not-approach partner is *included with the flag* ("re-approach requires your decision") — never silently dropped, never silently included.
11. **No fabricated dates.** Event dates, deadlines, and promo windows come from your actual calendar/launch plan only. If an event date isn't documented, stop and flag it — don't invent one.
12. **Recruiting-kit completeness.** Every recruiting or briefing output includes all three, no exceptions: (a) an offer one-pager link — or a BUILD-PREREQUISITE flag if it doesn't exist yet, (b) a live registration/sales page link — or a BUILD-PREREQUISITE flag, (c) a "what else do you need?" field for the partner. Never a placeholder link presented as real.
13. **Review before it goes out.** Any output that becomes external (an outreach message, a partner-facing kit) gets a human review pass before sending.

---

## MODES

Route by intent. If it's ambiguous, ask which mode — don't guess.

### 1. FIND — "find affiliates for [offer/event]" / "who's out there?"
Research *new* candidates you have no history with.

1. Set up / read the database (First Run).
2. Start from any "prospects" list you already keep. Then expand via: audiences adjacent to your best-performing partners (their podcasts, masterminds, JV circles), people whose audiences already know and trust *you*, and communities that already buy premium offers in your category.
3. Every candidate must pass the **screening question** (Rule 4) on documented evidence — their actual past promos, products, and audience — not vibes.
4. Output a **Candidate Card** (template in `references/templates.md`) for each, all with verdict **PROFILE-ONLY**, each with a validation plan (a small test send before you commit a launch to them).
5. Never rank a PROFILE-ONLY candidate above a partner your data already proves.

### 2. SCORE — "should we use [name]?" / "score [name]"
Evaluate one candidate against your data.

1. Read the database. Search for the name **and** any handle/alias.
2. Pull **all** their historical rows — every promo they've done for you. Apply the partner×offer rule (6).
3. Apply the intent benchmarks (2), metric separation (3), and small-sample rule (7).
4. If no history: research their audience, answer the screening question, label **PROFILE-ONLY**.
5. Output a **Candidate Card** with one of four verdicts:
   - **GREEN** — clears your intent benchmark on the *matching* offer (or the closest analogous one), with real sales behind it. Being a "good partner in general" isn't enough — the matching-offer evidence must be good.
   - **CAUTION** — marginal intent (3–6%), mixed history, intent-without-sales, UNKNOWN audience, small-sample-only evidence, or a strong record on a *different* kind of offer.
   - **RED** — below your intent line on a real promo, or fails the screening question with nothing to offset it.
   - **PROFILE-ONLY** — no history; fit assessment only. Treated like CAUTION: never ranked above data-backed GREEN, always carries a test-send plan.
6. The verdict line must cite the exact rows/evidence used.

### 3. MATCH — "who should promote [event]?"
Build the ranked shortlist for one launch.

1. Read the database. Confirm the event's date and status from your launch plan/calendar (Rule 11).
2. Identify the offer and its buyer profile (who actually buys this thing, and at what price).
3. Score every real partner as partner×THIS-offer. Add promising new names as PROFILE-ONLY rows.
4. Apply relationship-status flags (10).
5. Output the **Ranked Shortlist** (template in references): GREEN first, then CAUTION with reasons, then PROFILE-ONLY, then a one-line RED list (named, so nobody re-argues them later).
6. Close with a **coverage assessment**: enough GREEN names to fill the room? Gaps? Who to confirm first, what kits to build, and a lead-time check against the event date.

### 4. BRIEF — "build a recruiting kit for [name] × [event]"
Assemble the outreach/recruiting kit for one confirmed target.

1. Read the database + confirm the event (date, status) as MATCH does. Then SCORE the candidate — a **RED** score stops here; flag it instead of briefing.
2. Verify the three mandatory kit elements (Rule 12): one-pager, live registration/sales page, and the partner's-requests field. Anything missing → BUILD-PREREQUISITE flag, clearly blocking.
3. Draft the outreach: personal, references their specific audience fit, and — if they've promoted for you before — cites *their own* prior results from your database (real numbers only). Match your voice.
4. Output the **Recruiting Kit** (template in references), ready to hand to whoever owns the relationship.

### 5. UPDATE — "log the results from [promo]" / after any launch
Keep the database a living source of truth.

1. Read the new results.
2. Append one row per partner per promo (registrants, intent %, sales, sales-conv%, audience notes). **Never overwrite history — append.**
3. Maintain the relationship-status notes: add a dated line for any pause, fall-out, or reinstatement; supersede old notes with newer dated ones rather than deleting.
4. Re-tier: any partner whose new data crosses a benchmark moves tier, with a dated note explaining why.
5. Stamp the database's "Last updated" date.

---

## YOU MAY NOT

- State an intent or conversion number that isn't in the database (or sourced research) read this run
- Apply the intent benchmark bands to a sales-conversion % — they are different metrics
- Average a partner's performance across different offers
- Rank by list size, follower count, or fame
- Re-tier or top-rank anyone on a single small-sample promo
- Handle a relationship-flagged name without surfacing the flag
- Ship a recruiting kit missing any of the three mandatory elements
- Invent an event date or deadline
- Present an invented number as if it were real data

## Failure modes → exact handling

| Situation | Do this |
|---|---|
| "But they have 500K followers" | Volume veto (Rule 5). Followers ≠ buyers. Intent % is the criterion. |
| Candidate not in your database, no public evidence | PROFILE-ONLY card: "insufficient evidence — needs a validation send." Never guess. |
| Two conflicting history rows | Show both; base the verdict on the row whose offer matches the current one. |
| Event date missing/ambiguous | Stop. Flag it. Never invent a date. |
| "Skip the data and just brief them" (from anyone) | Run SCORE first anyway. A RED score blocks the brief and gets escalated to you. |
| A promo row has only sales-conv%, no intent number | Judge on sales-conv% explicitly labeled as such; do not apply the intent bands. |
| Database file missing on first run | Offer to create it from the template. Don't fabricate history to fill the gap. |

---

## Notes for setup
This is a self-contained, portable skill — it reads only your own affiliate database file and your launch plan. It does not depend on any external system. Install it with the included `install.sh` (or copy the `zpro-affiliate-finder/` folder into `~/.claude/skills/`), then invoke it with `/zpro-affiliate-finder`.
