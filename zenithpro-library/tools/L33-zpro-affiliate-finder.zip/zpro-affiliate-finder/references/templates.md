# Output Templates — zpro-affiliate-finder

Every number in these outputs must trace to a row in your affiliate database, or to sourced research on the candidate. No invented figures — ever.

---

## TEMPLATE — Candidate Card (SCORE / FIND output)

```markdown
### [Name] ([handle/alias if any]) — VERDICT: GREEN | CAUTION | RED | PROFILE-ONLY
**Offer evaluated for:** [offer × event, with date from your launch plan]
**Audience profile:** [from a database row, or from sourced research — cite the source]

| Promo | Registrants | Intent % | Sales | Sales-conv% | Source row |
|-------|-------------|----------|-------|-------------|------------|
| [every historical row — never omit one; print registrant count beside every %; mark small samples (<~150 regs or ~approx figures) "small sample"] |

**Screening question** ("promoted a similarly-priced offer to a warm, trust-based audience before?"): YES / NO / UNKNOWN — [evidence]. UNKNOWN caps the verdict at CAUTION.
**Benchmark applied:** [e.g., "12% intent on the matching offer → >10% = excellent."] Never feed a sales-conv% into the intent bands — if a row has no intent number, write "no intent data — sales-conv% only" and judge on that.
**Flags:** [offer mismatch / intent-without-sales / small sample / UNKNOWN profile / relationship-status flag / none]
**Verdict basis:** [one sentence citing the exact rows + rule]
**Next action:** [confirm / small test send / do not use]
```

---

## TEMPLATE — Ranked Shortlist (MATCH output)

```markdown
# Affiliate Shortlist — [Event] ([date], status: [from your launch plan])
**Offer buyer profile:** [who buys this, at what price — cite]
**Database last updated:** [date]

## GREEN — proven by your data (approach first)
| Rank | Name | Intent % (regs) | Sales-conv% (regs) | Offer-fit note | Flag |
|------|------|-----------------|--------------------|-----------------|------|
*(Intent % and sales-conv% are separate metrics — never merged, never substituted. "—" where no data.)*

## CAUTION — usable with a backup
[same columns + the reason for caution]

## PROFILE-ONLY — no history yet (validation send required before you commit)
| Name | Why the fit matches | Validation plan |

## RED — do not use for this offer (named so nobody re-litigates)
[Name — worst row — one-line reason]

## Coverage assessment
- GREEN names available: N. Enough to fill the room? [vs your registration target if known — never invent one]
- Gaps: [...]
- Next actions: [who to confirm first, kits to build, lead-time vs event date]
```

---

## TEMPLATE — Recruiting Kit (BRIEF output)

```markdown
# Recruiting Kit — [Partner] × [Event]
**Score:** [GREEN/CAUTION + one-line basis]  (RED = this kit must not exist — escalate instead)
**Event status:** [from your launch plan — if pending approval, name whose approval and the next action]

## 1. Offer one-pager
[Link] — or — ⚠️ BUILD-PREREQUISITE: one-pager not built yet. Blocking.

## 2. Registration / sales page (live, previewable)
[Link] — or — ⚠️ BUILD-PREREQUISITE: page not live yet. Blocking.

## 3. Outreach draft
[Personal draft. Returning partners: cite their own prior numbers from your database. Write in your voice.]

## 4. Promo logistics
- Event date(s): [from your launch plan only]
- Asset-delivery date for the partner: [date — weekday-checked]
- VIP / upgrade mechanics: [how the offer works]

## 5. [Partner] — anything else you need?
What else do you need before you can promote this? (assets, talking points, commission details, a personal intro) — reply here.
```

---

## Tier-movement log convention (UPDATE mode)
Append to the database, never overwrite: `[date] [Name] moved Tier X → Tier Y: [the new row that triggered the move]`.
