# Affiliate Database — [Your Business]

> This is your source of truth. The zpro-affiliate-finder skill reads this file every run.
> Fill in one row per partner **per promo**. Never overwrite history — always append a new row.
> Start empty and add rows as you run promos. New partners with no rows are scored PROFILE-ONLY.

**Last updated:** [date]

---

## How to use this file

- **Intent %** = the share of a partner's registrants who took a high-intent action *before* the pitch (booked a call, grabbed a VIP/paid upgrade, replied "I'm in"). This is your single best predictor. Pick ONE consistent intent signal and use it for every partner so the numbers are comparable.
- **Sales-conv %** = final buyers ÷ registrants. A *different* metric from intent — keep them in separate columns and never mix them.
- **Small sample** = fewer than ~150 registrants, or approximate figures. Mark these; never top-rank a partner on one small sample.

### Benchmarks (starting lines — recalibrate to your own data after ~5 promos)
| Intent % | Meaning |
|----------|---------|
| >10% | Excellent — top tier |
| 6–10% | Good |
| 3–6% | Marginal — use with a backup |
| <3% | Don't use, regardless of list size |

---

## Performance history (append one row per partner per promo)

| Date | Partner | Handle/alias | Offer promoted | Price point | Registrants | Intent % | Sales | Sales-conv % | Small sample? | Audience notes |
|------|---------|--------------|----------------|-------------|-------------|----------|-------|--------------|---------------|----------------|
| _2026-05-10_ | _Jane Doe (example row — delete me)_ | _@janedoe_ | _AI Bootcamp_ | _$1,500_ | _420_ | _9.2%_ | _31_ | _7.4%_ | _No_ | _Warm email list, sells $1–2k courses; strong fit_ |
| | | | | | | | | | | |

---

## Tiers (re-tier when a partner's data crosses a benchmark)

**Tier 1 — proven (GREEN):**
- [Name — one-line reason, e.g., "12% intent, 40 sales on the $2k offer"]

**Tier 2 — usable with a backup (CAUTION):**
- [Name — reason]

**Prospects — no history yet (PROFILE-ONLY, validate before betting a launch):**
- [Name — why the fit looks strong, and your planned validation send]

---

## Relationship status (never silently drop or include a flagged partner)

Add a dated line for any pause, fall-out, or reinstatement. Supersede old notes with newer dated ones — don't delete.

- [date] [Name] — [status: paused / do-not-approach / reinstated] — [reason; re-approach requires your decision]

---

## Quick decision framework (run for every candidate)

1. **Have they promoted a similarly-priced offer to a warm, trust-based audience before?** (YES / NO / UNKNOWN)
2. **What's their intent % on the offer closest to this one?** (Not their biggest promo — the most *similar* one.)
3. **Is there a relationship flag?** (Check the section above.)

If 1 is NO or UNKNOWN → cap at CAUTION and plan a test send. If 2 is below your line → RED. If 3 has a flag → surface it before doing anything.
