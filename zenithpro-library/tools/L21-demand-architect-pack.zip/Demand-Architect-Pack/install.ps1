# Demand Architect — Installer (Windows PowerShell)
# Copies the skill and sample outputs into your Claude Code configuration.

$ErrorActionPreference = "Stop"

$ScriptDir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillDest  = Join-Path $env:USERPROFILE ".claude\skills\demand-architect"
$SampleDest = Join-Path $SkillDest "references\ctd-sample"

Write-Host "=== Demand Architect Installer ===" -ForegroundColor Cyan
Write-Host ""

# Create directories
New-Item -ItemType Directory -Force -Path $SkillDest | Out-Null
New-Item -ItemType Directory -Force -Path "$SampleDest\markdown" | Out-Null
New-Item -ItemType Directory -Force -Path "$SampleDest\pdfs" | Out-Null

# Copy skill
Copy-Item "$ScriptDir\skills\demand-architect\SKILL.md" -Destination "$SkillDest\SKILL.md" -Force
Write-Host "[OK] Installed skill to $SkillDest\SKILL.md" -ForegroundColor Green

# Copy sample markdown outputs
$MarkdownPath = Join-Path $ScriptDir "references\ctd-sample\markdown"
if (Test-Path $MarkdownPath) {
    Get-ChildItem $MarkdownPath | Copy-Item -Destination "$SampleDest\markdown\" -Force
    Write-Host "[OK] Installed sample markdown outputs to $SampleDest\markdown\" -ForegroundColor Green
}

# Copy sample PDF outputs
$PdfPath = Join-Path $ScriptDir "references\ctd-sample\pdfs"
if (Test-Path $PdfPath) {
    Get-ChildItem $PdfPath | Copy-Item -Destination "$SampleDest\pdfs\" -Force
    Write-Host "[OK] Installed sample PDF outputs to $SampleDest\pdfs\" -ForegroundColor Green
}

Write-Host ""
Write-Host "Installation complete." -ForegroundColor Green
Write-Host ""
Write-Host "To run: open Claude Code and type  /demand-architect full [your market]"
Write-Host ""
Write-Host "Modes:"
Write-Host "  /demand-architect full [market]    - All 9 steps + 3 synthesis outputs"
Write-Host "  /demand-architect quick [market]   - Steps 5-8 only (when Steps 1-4 are done)"
Write-Host "  /demand-architect audit [market]   - Analyze existing marketing"
