# Demand Architect

## What It Does

The Demand Architect is a 9-step positioning pipeline that integrates Girard's mimetic desire theory with deep psychological research. It produces the strategic foundation for all marketing — positioning that connects to genuine prospect psychology AND occupies uncontested competitive territory.

Running the 9 constituent skills individually produces excellent analysis in separate buckets. The Demand Architect produces something those skills cannot: a single integrated picture where the deepest psychological truths of the prospect are mapped against the competitive desire landscape — simultaneously revealing what to create at the desire level AND what will differentiate in the market.

---

## The 9-Step Pipeline

| Step | Skill | What It Produces |
|------|-------|-----------------|
| 1 | Mimetic Market Intelligence | Competitive desire landscape — what desires are contested vs. open |
| 2 | Demand Desire Mapper | L1-L4 desire hierarchy with Strategic Desire Gaps |
| 3 | Psychographic Excavation | Deep market psychology — beliefs, rage points, failed solutions, raw language |
| 4 | Avatar Excavation | 3-5 forensic avatar profiles with mimetic model identification |
| 5 | Failure Pattern Forensics | Root cause archaeology — why this market perpetually fails |
| 6 | Core Concept Generator | 5 paradigm-shift concepts, filtered through Anti-Mimetic Test |
| 7 | Ideal Buying Mindset | Point B — the exact mental state where buying becomes automatic |
| 8 | Belief Gap Analyzer | Bridge blueprint — how to move prospect from Point A to Point B |
| 9 | USP Generator | Breakthrough positioning validated against competitive desire landscape |

---

## Three Synthesis Outputs

When all 9 steps are complete, the skill produces three integrated deliverables:

| Output | What It Is |
|--------|-----------|
| **Strategic Desire Map** | Visual map of contested vs. open desire territory in your market |
| **Demand Architecture Brief** | Complete positioning brief — Core Concept, USP, belief sequence, Point B |
| **Anti-Mimetic Positioning Statement** | Strategic north star — what to mediate, what to explicitly avoid, what to say |

---

## Modes

```
/demand-architect full [market]    # All 9 steps + 3 synthesis outputs
/demand-architect quick [market]   # Steps 5-8 only (when Steps 1-4 research is done)
/demand-architect audit [market]   # Analyze existing marketing against the framework
```

---

## Inputs Required

Before starting, you'll need:

1. **Business/product name and URL**
2. **Target market description** (3-5 sentences)
3. **Product/service description** — what it delivers, key mechanism, price point
4. **Competitor list** — or authorization to identify through research
5. **Output folder path** — where all files will be saved

---

## Installation

### macOS / Linux

```bash
chmod +x install.sh
./install.sh
```

### Windows (PowerShell)

```powershell
.\install.ps1
```

Both scripts copy the skill into `~/.claude/skills/demand-architect/` and the sample outputs into `~/.claude/skills/demand-architect/references/ctd-sample/`.

---

## How to Run

Open Claude Code and type:

```
/demand-architect full [your market or product name]
```

---

## Sample Outputs Included

This pack includes a complete set of sample step outputs and synthesis documents from a real Demand Architect run (CTD market). Both markdown and PDF versions included.

```
references/ctd-sample/markdown/   — All 9 steps + 3 synthesis outputs (markdown)
references/ctd-sample/pdfs/       — Same files in PDF format
```

Use these to understand what the pipeline produces before running it on your own market.

---

## Included Files

```
Demand-Architect-Pack/
  skills/demand-architect/SKILL.md            — The skill definition
  references/ctd-sample/markdown/             — Sample step outputs (markdown)
  references/ctd-sample/pdfs/                 — Sample step outputs (PDF)
  install.sh                                  — macOS/Linux installer
  install.ps1                                 — Windows installer
  README.md                                   — This file
```
