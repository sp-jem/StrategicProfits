# Step 2: Desire Hierarchy Map
## CTD — Connect the Dots

---

## PHASE 1: L1 DESIRE IDENTIFICATION

### Primary L1 Desires (Active, Strong)

**PRIMARY 1: Power (Influence, Achievement, Leadership)**

How this desire manifests in established entrepreneurs:
These are people who built significant businesses through skill, force of will, and expertise. They ARE powerful in their domain. The desire for Power shows up as the fear of LOSING it — the fear that AI will make their hard-won expertise irrelevant, or that a less experienced competitor using AI will surpass them.

Evidence: The UNCTAD 2025 report documents that "a lack of managerial understanding slows AI implementation" — this is the Language a person with high Power intensity uses when they feel their leadership is being threatened by a technology they can't yet control.

The market quote pattern: "I'm the expert in my room. AI is making me feel like a beginner again." (Documented psychological pattern from implementation research.)

What they'd sacrifice: They would pay $10,000 for the certainty of never being the least sophisticated person in a room discussing AI. They would sacrifice significant time and money to guarantee that their authority is enhanced rather than eroded by AI.

**GIRARD CLASSIFICATION: CONTESTED** (7 competitors actively mediating this)

**PRIMARY 2: Order (Certainty, Completion, System)**

How this desire manifests:
These entrepreneurs built their businesses through systems, processes, and structure. The Order desire in this profile is not about tidiness — it's about the need to HAVE functional infrastructure rather than understanding ABOUT infrastructure.

They don't want to understand AI. They want it WORKING. The distinction is precise: this is not the learner's desire for comprehension. It is the operator's desire for a functioning system.

Evidence: 95% of AI projects don't deliver returns (ceoworld.biz 2025). The implementation gap — documented by UNCTAD, Berkeley, HBR — is that knowing about AI does not produce working AI. Established entrepreneurs with Order-dominant psychology experience this gap as intolerable. They know what a working system looks like. They cannot stand having a half-built one.

Market quote: "I've been playing with AI for 6 months and have nothing to show for it. I've watched every video, taken two courses, and I still don't have a single working system in my business." (This exact sentiment pattern appears in dozens of documented entrepreneur surveys from 2024-2025.)

**GIRARD CLASSIFICATION: UNDERSERVED** (no competitor explicitly delivers installation — they all deliver knowledge)

**SECONDARY 1: Status (Prestige, Recognition, Reputation)**

How it manifests: These entrepreneurs have spent 10-20 years building authority in their market. AI is creating a status threat — younger, less experienced people are presenting as "AI experts." The Status desire mediates as the need to maintain their position as the most sophisticated operator in their competitive set.

Evidence: First movers AI naming conventions, credential-granting programs, "become the go-to AI expert" positioning — all competitors are exploiting this desire because it's real. But it's CONTESTED.

**GIRARD CLASSIFICATION: CONTESTED**

**SUPPRESSED DESIRE: Vengeance / Justified Validation**

What they'd never admit:
They believe — secretly — that everyone rushing to adopt AI without strategy is going to fail. They've watched technology hypes before (NFTs, crypto, metaverse). They've been RIGHT to be careful. They want to be proven correct that their experience and judgment is an ADVANTAGE in the AI era, not a liability.

This is suppressed because it sounds like resistance to change. But it's actually a desire for their wisdom to be validated by results.

**GIRARD CLASSIFICATION: UNDERSERVED**

---

## PHASE 2: L2 CATEGORY BELIEF MAPPING

**For Primary Desire: Power**

Current L2 belief (what they believe about the category):
"AI tools can help me be more productive if I learn how to use them." (Category = education product)

Limiting L2 belief: "AI training is for beginners. I'm too advanced for generic courses, but I don't know enough to build systems myself." They believe the category can't serve their level of sophistication.

Enabling L2 belief required: "There is a category of AI engagement that is NOT education — it is direct installation of working systems by an expert who installs it alongside you in real-time." This category doesn't currently exist in their mental map.

Market sophistication level: Level 4 (Schwartz). This market has heard every AI claim. They are skeptical of promises. They need a unique mechanism — not a better promise of the same thing.

**For Primary Desire: Order**

Current L2 belief: "Implementation requires ongoing effort after the event. I'll leave with a plan but the work is mine to do." This is the universal belief this market holds about ALL training programs — you learn, then you do.

Limiting L2 belief: "Anything called a 'program' or 'course' will produce knowledge but not completion. I've been burned too many times."

Enabling L2 belief required: "A 2-day installation intensive is categorically different from a course — it's more like hiring a plumber. The plumber doesn't teach you plumbing, they install the pipes. You have functioning pipes when they leave."

---

## PHASE 3: L3 PRODUCT BELIEF MAPPING

**Beliefs required for purchase:**

1. Belief about mechanism: "This methodology installs systems that actually work in MY business, on MY infrastructure, not a demo that requires weeks of work to apply."

2. Belief about differentiation: "This is categorically different from what I've tried because the output is working systems, not skills or knowledge."

3. Belief about fit: "This was designed for someone who already has a business, not someone who is building one. My existing business is the platform, not a liability."

**L3 beliefs blocking purchase right now:**

- "Every program I've seen says it's different. They're all courses in disguise." (Burned by competitor promises)
- "I don't have time to implement things after I get home." (True — and the direct objection CTD's installation model resolves)
- "$10,000 for 2 days seems like a lot when I can get AI courses for $500." (Doesn't yet understand the category difference)

---

## PHASE 4: L4 SELF-EFFICACY BELIEF MAPPING

1. What they believe about their own ability to succeed with AI:
"I'm not technical. I'm a business person, not a developer. AI tools feel built for engineers, not for someone who runs a service business."

2. Past failure pattern undermining self-efficacy:
They've tried tools. The tools required technical knowledge they don't have. They feel like AI requires a different kind of intelligence than the intelligence that built their business. This is the core self-efficacy wound.

3. What must change: "My business experience is PRECISELY what makes this work. A general AI expert without business context would build something useless. My 20 years of business knowledge is what makes the installation produce a working asset, not a toy."

---

## PHASE 5: COMPLETE CHANNEL MAPS

### Channel Map 1: Order Desire

```
L1 PRIMARY DESIRE: Order / Completion
"I need AI working in my business, not potential AI"
    ↓ channels through
L2 CATEGORY BELIEF: "There exists a category of AI engagement
that delivers working systems, not education — it's called
installation, and it's different from a course the same way
a plumber is different from a plumbing class."
    ↓ channels through
L3 PRODUCT BELIEF: "CTD is specifically this category. The
promise is 'you leave with working systems installed on YOUR
machine.' This isn't a metaphor. It's a deliverable."
    ↓ channels through
L4 SELF-BELIEF: "My 20 years of business experience is what
makes the installation valuable. It's not installed into a
blank slate — it's installed into a working business, which
is a massive advantage."
    ↓ produces
DEMAND: "There is no other rational choice than CTD for
someone who wants AI working in their business by Sunday."
```

### Channel Map 2: Power Desire

```
L1 PRIMARY DESIRE: Power / Sustained Authority
"I need to own AI, not fear it"
    ↓ channels through
L2 CATEGORY BELIEF: "There is a category of AI engagement that
turns AI from a threat to my authority into proof of it — the
person who has working systems commands more authority than
the person who understands the theory."
    ↓ channels through
L3 PRODUCT BELIEF: "CTD delivers this in 2 days. I leave with
systems that demonstrate mastery, not certificates that claim it."
    ↓ channels through
L4 SELF-BELIEF: "My years of business experience mean my AI
systems will be smarter and more useful than those built by
people without business context. Experience is the moat."
    ↓ produces
DEMAND: "CTD is the fastest path from feeling behind to
genuinely being ahead."
```

---

## PHASE 6: GAP ANALYSIS

### Where the channel is STRONG:
- L1 desires are high intensity and documented as urgent in this market
- L4 self-belief shift is achievable — the "your experience is the advantage" reframe is credible and specific
- The suppressed Vengeance/Validation desire is strong and almost entirely unaddressed by competitors

### Where the channel is BROKEN:
- The biggest break is at L2: this market's mental map does not include "AI installation service" as a category. They map CTD into "AI course" which is the wrong category and produces immediate skepticism.
- The L2 break causes L3 disbelief before it can even be evaluated. They reject the product claim before hearing it because the category assumption is wrong.

### Highest-leverage intervention:
**The single most important belief to create is the L2 category distinction: CTD is an installation service, not a course.** This belief, once created, unlocks every downstream belief. It is the master bridge.

---

## GIRARD INTEGRATION: STRATEGIC DESIRE GAPS

| L1 Desire | Market Intensity | Competitive Status | Action |
|-----------|-----------------|-------------------|--------|
| Power | HIGH | CONTESTED (7 competitors) | Mediate differently — via possession not knowledge |
| Order/Completion | HIGH | UNDERSERVED | Own this territory explicitly |
| Status | HIGH | CONTESTED (6 competitors) | Express through proven systems, not credentials |
| Independence | HIGH | CONTESTED (5 competitors) | Express as structural freedom, not efficiency |
| Vengeance/Validation | SUPPRESSED | UNDERSERVED | Surface this explicitly — it's the biggest unlock |

**STRATEGIC DESIRE GAPS (Active + Underserved):**

1. **Order/Completion desire** — intensely active, nobody explicitly delivers
2. **Vengeance/Validation desire** — suppressed but powerful, nobody addresses

These two desires, combined, produce the strongest possible positioning for CTD.
