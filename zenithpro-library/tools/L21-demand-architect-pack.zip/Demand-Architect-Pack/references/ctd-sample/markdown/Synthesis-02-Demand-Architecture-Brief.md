# Synthesis 2: Demand Architecture Brief
## CTD — Connect the Dots
## For: Alex Makarski (Clickmakers.io) — Sample Demonstration

---

## SECTION 1: PRIMARY AVATAR PROFILE

Alex is 48. He's been running a digital marketing agency for 12 years. Revenue is $1.2M. Ten people. His clients are service businesses and mid-market companies. He built the agency on his expertise — he knows more about direct response marketing, conversion optimization, and digital advertising than his clients do. That knowledge gap IS the product. That's been true for 12 years.

For the last 18 months, something has been shifting. Younger agencies are showing up with AI-generated deliverables that look professional. Alex knows the quality isn't as high — yet. He knows his strategic thinking is still superior. But the speed gap is real, and it's growing.

Alex has spent $4,600 on AI tools (subscriptions and courses). He has Claude Pro. He has ChatGPT. He has an AI writing subscription. He has taken one online course. He watched Ryan Deiss pitch the AI-Powered Entrepreneur Accelerator and bought it. He went through it. He learned a lot. He has nothing running.

His team uses AI individually — a team member uses it to write first drafts, another uses it to summarize client calls. There is no shared infrastructure. There is no systematic integration. He can't show a client: "here's how AI makes our work for you better."

He saw Rich Schefren's demo three weeks ago. He watched Rich show an AI system that's doing market research, synthesizing it, flagging competitive threats, and feeding into a brief automatically. In real-time. On his actual machine. Alex thought: "I've been using ChatGPT like Google Search and calling it AI."

He is now the buyer. He just needs the right category to exist. He's been buying education. He needs installation.

---

## SECTION 2: THE PRIMARY L1 DESIRE

**Order / Completion — the need for functioning infrastructure.**

This is the primary L1 desire driving purchase because it is simultaneously the most intensely felt unmet need AND the desire that no competitor explicitly addresses. Alex doesn't need more information about AI. He is not deficient in curiosity. He has Status concerns, he has Power concerns — but those are secondary. The primary driver is the operational gap: his business doesn't have AI infrastructure, and nothing he's tried has produced it. This is the Order desire: the need for systems to be complete and functional, not potential and promised.

Evidence of intensity: Alex has spent $4,600 and 6+ months and has nothing running. The gap between investment and output is producing genuine operational anxiety. This is not theoretical.

Why Order over Power or Status: Power and Status desires are mediated by 7 and 6 competitors respectively. Order is mediated by zero competitors who deliver what it actually requires: installation. Mediating the Order desire with a unique mechanism (installation) produces the highest differentiation.

---

## SECTION 3: SELECTED CORE CONCEPT

**THE 5% ILLUSION**

"You're not stuck at 5% of AI's potential because you haven't learned enough — you're stuck because you've been using AI as a tool when what your business needs is AI infrastructure, and nobody has offered to install it."

**Why this is the selected concept:**
- It uses the market's own language ("5%" is how they describe their situation)
- It mediates TWO underserved desires simultaneously (Order/Completion + Vengeance/Validation)
- It passes all four standard quality tests AND the Anti-Mimetic Test
- It produces the strongest Recognition Test response: "Oh my God. THAT'S why 18 months of learning produced nothing."
- It contains the complete reframe: tool vs. infrastructure (reframes both the problem AND the solution)
- It is the Master Bridge — once accepted, it makes every downstream belief easier to build

---

## SECTION 4: THE BELIEF SEQUENCE (Ordered by Dependency)

1. **ROOT CAUSE ATTRIBUTION (must come first)**
   - Point A: "I'm stuck because I haven't learned enough"
   - Point B: "I'm stuck because I've been buying the wrong category — education for an installation problem"
   - Classification: COMPETITOR-INSTALLED (by entire AI education market)
   - Evidence required: Statistics on AI implementation failure rates + the specific UNCTAD documentation of the implementation gap as systemic, not individual
   - Bridge strategy: Surface the installation BEFORE presenting CTD. "The AI education industry installed this belief by design."

2. **CATEGORY DISTINCTION**
   - Point A: "AI implementation programs teach you how to implement"
   - Point B: "CTD is an installation intensive — structurally different, like a plumber vs. a plumbing class"
   - Classification: COMPETITOR-INSTALLED
   - Evidence required: Concrete specifics of what CTD produces (named systems, stated outcomes from previous participants)
   - Bridge strategy: Name what EVERY previous program delivered. Then show the structural difference.

3. **PRODUCT MECHANISM**
   - Point A: "I'll have to implement it at home after the event"
   - Point B: "The installation happens at the event — I co-build it with Rich's team during the 2 days"
   - Classification: COMPETITOR-INSTALLED
   - Evidence required: Specific schedule description showing building time, not lecture time
   - Bridge strategy: Show them a day schedule where the default activity is building, not listening.

4. **SELF-EFFICACY**
   - Point A: "I'm not technical enough to understand or build AI systems"
   - Point B: "My business knowledge IS the technical input. Rich brings AI architecture. I bring business intelligence."
   - Classification: NATURALLY HELD + COMPETITOR-INSTALLED
   - Evidence required: Demonstration that business knowledge is the primary input, not technical knowledge
   - Bridge strategy: "Here's exactly how a past participant with zero technical background left with 3 working systems."

5. **INVESTMENT FRAMING**
   - Point A: "$10,000 for 2 days is expensive for a program"
   - Point B: "$10,000 for 2 days is correctly priced for infrastructure installation, not for education"
   - Classification: COMPETITOR-INSTALLED
   - Evidence required: Comparison to contractor/consultant pricing for equivalent output; opportunity cost calculation vs. current AI spend
   - Bridge strategy: "You've spent $8K+ on AI education. How much is running? Now compare to $10K for infrastructure that's operational before you leave."

---

## SECTION 5: PRIMARY USP

**"You leave with AI systems installed and running on your machine. Not knowledge. Not plans. Not homework. Working systems."**

**Why this USP:**
- Mediates UNDERSERVED Order/Completion desire — no competitor claims this
- Contains the explicit contrast (not knowledge, not plans, not homework) that creates the category distinction immediately
- Uses zero language from Step 1 convergence map — sounds completely different from every other AI program
- Is ownable: Rich Schefren's combination of 20+ years of business architecture expertise + AI implementation knowledge is not replicable quickly
- Is specific enough to be falsifiable — which paradoxically makes it more credible than vague transformation claims
- Connects directly to the Core Concept (tool vs. infrastructure) as its expression

---

## SECTION 6: POINT B SUMMARY

At Point B, Alex has reached:

He knows the root cause of his AI failure is the category of solution he's been buying, not his effort or intelligence. He knows CTD is the installation category — structurally different from every program he's tried. He believes his 12 years of business and marketing expertise is the primary input that makes the AI installation useful, not a deficit to overcome. He feels urgency (the AI window is real) without panic (he is the right person, at the right time, finally with the right vehicle). He sees $10,000 as correctly priced for infrastructure that will operate for years, and he's done the math on what he's already spent. He identifies as an infrastructure investor, not a program buyer. He has stopped asking "what do I get?" and started asking "how does the 2 days work?"

---

## SECTION 7: EXECUTION IMPLICATIONS

1. **Lead with the Core Concept, not the product.** Open all marketing by surfacing the "5% stuck" situation and reframing the cause. Get the root cause attribution belief established before presenting CTD. If you lead with the product, the category error filters it into "another AI program."

2. **Address the competitor-installed beliefs first.** The highest priority bridges are 1 and 2 (Root Cause Attribution and Category Distinction). These MUST be addressed before price, logistics, or social proof. A prospect who still believes they "just need to learn more" cannot rationally evaluate CTD.

3. **Avoid this language entirely:** leverage, AI-powered, competitive advantage, transform, automate, hands-on, actionable, immediately applicable. All saturated. All trigger the "I've heard this" defense. Every word in CTD marketing should pass the test: "Is this in the convergence vocabulary list? If yes, replace it."

4. **Lead the proof with specifics of what systems were installed.** "Alex left with a prospect research system, an intake summarization workflow, and a campaign brief generator" is more valuable than "Alex left with tools that will change his business." The proof that makes CTD credible is the specificity of the output, not the magnitude of the promise.

5. **Never promise transformation — promise completion.** "You will be transformed" is the promise of every program they've bought. "You will have X working on your machine" is the promise of CTD. Transformation is aspirational. Completion is verifiable. Established entrepreneurs buy verifiable over aspirational at this point — they've been burned too many times.
