# Step 9: USP Candidates
## CTD — Connect the Dots

---

## STEP A: FEATURE EXCAVATION

CTD features (24 identified):

**Structural features:**
1. 2-day in-person format (co-location — builds things together, not watching demos)
2. Small group / intensive (not conference scale — hands-on capacity preserved)
3. Rich Schefren present (primary architect, not delegated to staff)
4. Laptop-required format (installation is literal — machines are the workspace)
5. $10,000 price point (signals infrastructure investment, not education product)

**Delivery features:**
6. Systems built during the event (not assignments to complete at home)
7. AI installed on participant's actual machine (not a demo environment)
8. Participant's actual business used as the context (not generic use cases)
9. Business-architecture expertise integrated into every installation decision
10. Real-time troubleshooting and customization during installation

**Output features:**
11. Specific working AI systems at event end (defined deliverable)
12. Systems trained on participant's business data/context
13. Participant understands what was built (can maintain and extend)
14. Documentation of systems installed
15. Follow-up support window (specific — TBD)

**Credibility features:**
16. Rich Schefren's 20+ year track record building systems-based businesses
17. Rich's own use of these systems documented (peer demonstration, not theory)
18. Track record with prior cohorts (case studies of specific outcomes)
19. Not teaching from theory — teaching from personal implementation in his own business
20. Strategic Profits as the proof environment (the business this built)

**Differentiation features:**
21. No homework (installation is complete before departure)
22. No theoretical framework delivery (the output is working systems)
23. No generic AI content (everything is contextualized to participant's business)
24. Explicit "not a course" positioning (category distinction built into offer design)

---

## STEP B: THREE-LEVEL TRANSMUTATION (Key Feature Clusters)

### Cluster 1: Installation-at-Event
- **Feature:** AI systems built and installed during the 2-day event on participant's actual machine
- **Benefit:** Participant arrives home with working infrastructure rather than knowledge and homework
- **Promise:** You leave with AI running in your business. Not plans. Not skills. Not potential. Working systems that will execute for you on Monday.

### Cluster 2: Business-Contextualized Installation
- **Feature:** All systems built using participant's actual business context, data, workflows
- **Benefit:** Installed systems are useful from day one — not generic demos that require extensive customization
- **Promise:** The AI systems know your business. They don't speak in generic language about a generic business. They speak with the knowledge of your specific operations, customers, and constraints.

### Cluster 3: Rich's Business Architecture Expertise
- **Feature:** Rich Schefren's 20+ years of business architecture expertise applied to every installation decision
- **Benefit:** Systems are designed with business intelligence, not just technical capability
- **Promise:** The intelligence that built Strategic Profits is embedded in how your AI systems are designed. You're not getting generic AI. You're getting business-intelligent AI.

### Cluster 4: Category Distinction (Not a Course)
- **Feature:** Event is structured as installation intensive, not education event
- **Benefit:** Output is infrastructure, not knowledge
- **Promise:** The measure of CTD is not what you know when you leave. It's what's running.

---

## STEP C: MARKET SOPHISTICATION CALIBRATION

Schwartz Level 4 (from Step 2 analysis). Market has heard many AI promises. They require mechanism explanation.

Appropriate approach at Level 4: **Mechanism claim.** "Here's SPECIFICALLY WHY this produces something different from what you've tried. Not 'we're better.' Here's the structural difference."

The mechanism is: installation-at-event + business-contextualized + expert co-building. This is the specific mechanism. State it mechanistically, not as a benefit.

---

## STEP D: OWABILITY ANALYSIS

### USP Candidate 1: "You leave with working AI systems installed on YOUR machine."

**Can competitors say this tomorrow?** Yes, technically. But:
- No competitor currently has a track record delivering this claim
- No competitor has the combination of business architecture expertise + AI knowledge at Rich's level
- No competitor has positioned their offer as installation rather than education
- The claim requires 2-day in-person format with hands-on installation — most competitors are online or conference format

**Structural evidence only CTD can deliver:**
- Rich's personal use of these systems in his own business (documented proof of concept)
- 20+ year track record building systems-based businesses (the business intelligence layer)
- Specific alumni outcomes (working systems, documented)

**Owability verdict:** STRONGLY OWNABLE in the short term. Competitors could attempt to copy but would take 12–18 months to establish credibility, and would not have Rich's combination of business architecture + AI expertise.

### USP Candidate 2: "The only AI event where the output isn't what you know — it's what's running."

**Owability:** OWNABLE. The "output is running systems" framing is not used by any identified competitor.

### USP Candidate 3: "AI for businesses that already work — installation, not education."

**Owability:** OWNABLE. "For businesses that already work" explicitly claims the experienced entrepreneur territory. No competitor is explicitly excluding beginners from their positioning.

---

## STEP E: L1 DESIRE CONNECTION

| USP Candidate | Primary L1 Desire | Desire Classification |
|---------------|------------------|----------------------|
| "Working systems installed on YOUR machine" | Order/Completion | UNDERSERVED |
| "Output isn't what you know — it's what's running" | Order/Completion | UNDERSERVED |
| "AI for businesses that already work" | Vengeance/Validation | UNDERSERVED |

All three candidates connect to UNDERSERVED desires. This is the strongest possible configuration — the USP connects to desire territory that competitors have left open.

---

## COMPETITIVE DESIRE LANDSCAPE VALIDATION

**Validation 1: Desire Territory Check**

Primary desire for USP Candidate 1 (recommended): Order/Completion.
Step 1 shows this desire is UNDERSERVED.
No competitor has staked this territory with the explicit installation claim.

**Validation 2: Language Convergence Check**

Checking all USP candidates against Step 1 language convergence list:
- "leverage AI" — NOT used in candidates
- "AI-powered" — NOT used
- "competitive advantage" — NOT used
- "transform your business" — NOT used
- "automate" — NOT used
- "hands-on" — NOT used (replaced with "installed")
- "actionable" — NOT used

All USP candidates PASS language convergence check. None use saturated language.

**Validation 3: Enemy Convergence Check**

Dominant market enemy: "your own inefficiency" or "falling behind competitors."

USP Candidate 3 implicitly positions against a different enemy: "the wrong category of AI help." This enemy is NOT in the enemy convergence map. Available.

---

## FINAL USP RANKING

**#1 RECOMMENDED USP:**

"You leave with AI systems installed and running on your machine. Not knowledge. Not plans. Not homework. Working systems. This is what makes Connect the Dots different from every AI program you've considered."

**Supporting rationale:**
- Mediates UNDERSERVED Order/Completion desire
- Uses no language from Step 1 convergence map
- States the mechanism explicitly (installed, running)
- Contains the explicit contrast (not knowledge, not plans, not homework) — this contrast is the category distinction that makes the claim credible
- Connects directly to the Master Bridge Core Concept (tool vs. infrastructure)
- Ownable — no competitor currently claims this with evidence

**#2 STRONG ALTERNATIVE:**

"Connect the Dots is AI for established businesses — not AI education, AI installation. You leave with systems built specifically for your business, not generic frameworks you'll spend weeks trying to apply."

**#3 SECOND ALTERNATIVE:**

"Your business experience is the most valuable thing you bring to Connect the Dots. The AI systems we build will be smarter than anything a technical person without business context could produce. Because what makes an AI system useful isn't how sophisticated the technology is — it's how well it understands your specific business. That's what you bring."
