# Step 6: Core Concepts
## CTD — Connect the Dots

---

## PRELIMINARY ANALYSIS

**The Daily Bleed (Quantified):**
This market is spending $200–$500/month on AI subscriptions. They're spending 2–5 hours/week attempting to use AI productively. They're watching competitors who have working AI systems gain ground. Conservative quantification: 3 hours/week × $300/hour professional rate = $900/week in opportunity cost from ineffective AI usage. Per year: $46,800 in wasted time on top of subscription costs.

**The Identity Wound:**
They built businesses on expertise. AI is producing a competence inversion: their 25-year-old team members feel more capable with AI than they do. This is not a minor discomfort — it directly threatens the foundational identity of "I am the most capable person in this business."

**The Category Context (Schwartz Level 4):**
This market has heard every AI claim. Sophistication Level 4: they require mechanism explanation, not just promise. They will not be moved by "AI will transform your business." They need to understand specifically WHY CTD produces something different from everything they've tried.

**The Inevitability Standard:**
What must be true for purchase to be automatic: "If I attend this 2-day event, I will leave with specific working AI systems installed on my machine, built with someone who understands both AI architecture and established business operations. The installation approach is categorically different from education — it's what my business needs and what no course, mastermind, or tool has provided."

---

## FIVE CORE CONCEPT CANDIDATES

---

### CONCEPT 1: The Plumber Paradox (Invisible Pivot Point Formula)

**The concept:**
"You don't study plumbing to get running water — you hire a plumber. But for the last 2 years, the AI industry has been selling you plumbing textbooks and calling it implementation."

**Elaboration:**
Every AI program sold to established entrepreneurs is an education product. Education produces knowledge. Knowledge is not infrastructure. The invisible pivot point: the entire AI training industry is categorically misaligned with what established entrepreneurs actually need. They don't need more knowledge about AI. They need someone to come to their house and install the pipes.

**Quality Tests:**
- Inevitability Test: If they accept this, is buying the logical next step? YES. "If education is the wrong category, and CTD is the installation category, then CTD is the only rational choice for someone who actually wants working AI."
- Specificity Test: Yes — "plumbing textbooks" is viscerally specific.
- Recognition Test: "Oh my God. THAT'S why every course I took produced nothing." YES — this maps perfectly onto their graveyard archaeology.
- Irreversibility Test: Once understood, they cannot look at another AI course the same way. They will always compare it to plumbing education.

**Anti-Mimetic Test:**

Test A — Desire Differentiation Check:
Primary desire this concept mediates: Order/Completion. What Step 1 shows: UNDERSERVED. No competitor is mediating the completion desire through the installation frame.

Test B — Open Territory Check:
UNDERSERVED desire = automatic pass on desire differentiation.

Test C — Framing Check:
"Plumber" framing is NOT in the Step 1 language convergence list. It's genuinely novel framing.

**RESULT: PASS — Strong differentiation. Mediates underserved desire (Order/Completion) via novel mechanism framing.**

---

### CONCEPT 2: The Experience Trap (Expertise Trap Formula)

**The concept:**
"The very expertise that made your business successful is what's making AI fail for you. Because you think about AI the same way you think about everything else: 'I'll learn it and master it.' But AI isn't a skill. It's an infrastructure project. And the people who built the businesses you admire didn't master plumbing. They hired plumbers."

**Elaboration:**
Established entrepreneurs are the people most likely to attack a new challenge by learning it themselves. That's how they built their businesses. AI rewards this approach in a strange way: the more they learn, the more they understand how sophisticated the infrastructure SHOULD be — which makes the gap between their knowledge and their actual systems feel larger, not smaller. The expertise trap: their drive to master things is keeping them in the knowledge loop rather than the ownership loop.

**Quality Tests:**
- Inevitability Test: Partially. "If my approach to learning AI is the problem, and CTD provides the architectural guidance I can't give myself, then CTD becomes necessary." PASS.
- Specificity Test: Needs specific quantification. Weak on this dimension.
- Recognition Test: "That's me — I keep learning more about AI and feeling more behind." STRONG.
- Irreversibility Test: Medium. Less "oh my God" than Concept 1.

**Anti-Mimetic Test:**

Test A: Primary desire mediated = Power + Vengeance/Validation. Power is CONTESTED (7 competitors). But Vengeance/Validation is UNDERSERVED.

Test B: Does it mediate the underserved desire? YES — it validates their instinct that their expertise is not the problem. Their approach to learning new things (which is their superpower) is being mis-applied to an infrastructure problem.

Test C: "Expertise trap" framing is not in Step 1 language convergence list.

**RESULT: CONDITIONAL PASS — Mediates BOTH a contested desire (Power) and an underserved desire (Validation/Vengeance). The underserved element saves it. Risk: competitors could adopt this framing.**

---

### CONCEPT 3: The 5% Illusion (False Enemy Formula)

**The concept:**
"You think you're using AI at 5% of its potential because you need to learn more. You're not. You're using AI at 5% of its potential because you're using it as a tool, not as infrastructure. And the difference between a tool and infrastructure is the difference between carrying water in buckets and having running water in your house."

**Elaboration:**
The false enemy is "my lack of knowledge." The real enemy is the absence of architecture. This concept reframes the cause of their stuck state from personal deficit (I haven't learned enough) to structural diagnosis (I've been using the wrong category of solution). The "5%" figure is sourced from the brief — "they feel stuck at ~5% of AI's potential."

**Quality Tests:**
- Inevitability Test: STRONG. "If the problem is infrastructure, not knowledge, then the solution is installation, not more education."
- Specificity Test: YES — "5%" is their own language, directly sourced from their self-assessment.
- Recognition Test: EXTREMELY STRONG — this is precisely how they describe their situation to themselves.
- Irreversibility Test: Once they see the tool vs. infrastructure distinction, every AI product they look at they'll instantly classify.

**Anti-Mimetic Test:**

Test A: Primary desire mediated: Order/Completion + Vengeance/Validation. Both UNDERSERVED.

Test B: Underserved desires = automatic pass.

Test C: "Tool vs. infrastructure" framing. Searching Step 1 language convergence list — "infrastructure" does NOT appear. "Tool" appears but not contrasted with "infrastructure." This framing is available.

**RESULT: PASS — Mediates two underserved desires. Highly specific (uses their "5%" language). Strong recognition and irreversibility.**

---

### CONCEPT 4: The Knowledge-Infrastructure Gap (Systemic Mismatch Formula)

**The concept:**
"The AI training industry is built on the assumption that knowledge produces implementation. That assumption is wrong for established business owners. For someone building their first business, learning AI is appropriate — they're building from scratch. For someone with a $1M+ business already running, the challenge is integration, not comprehension. The industry has been serving the wrong person."

**Quality Tests:**
- Inevitability Test: MEDIUM. The conclusion is valid but the pathway is longer.
- Specificity Test: Needs more specificity. "$1M+" helps but feels formulaic.
- Recognition Test: STRONG for sophisticated buyers. Medium for others.

**Anti-Mimetic Test:**

Test A: Mediates Power desire primarily (through "this industry doesn't serve your level"). CONTESTED.
Test B: No clear underserved desire mediated.
Test C: "The AI industry built for beginners" framing is somewhat in the language convergence space.

**RESULT: FAIL — Primarily mediates a contested desire. Lacks the visceral recognition of Concepts 1, 2, and 3. Too diagnostic, not enough emotional.**

---

### CONCEPT 5: The Monday Morning Test (Success Paradox Formula)

**The concept:**
"Here's the test every AI program should be judged by: On Monday morning after you get home, what specifically is different about how your business runs? Not what you know. Not what you're planning to build. What is running. For 95% of AI program graduates, the answer is nothing."

**Quality Tests:**
- Inevitability Test: STRONG — "If no other program passes the Monday Morning Test and CTD does, the choice is obvious."
- Specificity Test: STRONG — "Monday morning" is time-specific and emotionally loaded.
- Recognition Test: STRONG — they know exactly what their Monday morning looked like after previous programs.
- Irreversibility Test: STRONG — they will apply this test to every AI program they see.

**Anti-Mimetic Test:**

Test A: Primary desire mediated: Order/Completion. UNDERSERVED.
Test B: Underserved desire = automatic pass.
Test C: "Monday Morning Test" framing. NOT in Step 1 language convergence list. Available.

**RESULT: PASS — Mediates underserved desire. Specific, emotionally loaded, irreversible framing.**

---

## FINAL RANKING (Anti-Mimetic Differentiation as Primary Factor)

| Rank | Concept | Anti-Mimetic Score | Inevitability | Desire | Recommendation |
|------|---------|-------------------|---------------|--------|----------------|
| 1 | The 5% Illusion | PASS — 2 underserved desires | STRONG | Order + Validation | PRIMARY RECOMMENDATION |
| 2 | The Plumber Paradox | PASS — 1 underserved desire | STRONG | Order/Completion | STRONG ALTERNATIVE |
| 3 | The Monday Morning Test | PASS — 1 underserved desire | STRONG | Order/Completion | STRONG ALTERNATIVE |
| 4 | The Experience Trap | CONDITIONAL PASS | MEDIUM | Power + Validation | SECONDARY |
| 5 | Knowledge-Infrastructure Gap | FAIL | MEDIUM | Power (contested) | DISCARD |

**PRIMARY SELECTED CONCEPT: The 5% Illusion**

Reasoning: It uses the market's own language ("5%"), it mediates TWO underserved desires simultaneously (Order/Completion + Vengeance/Validation), it contains the tool-vs-infrastructure distinction that repositions the entire category, and it produces the highest Recognition Test score.

**One-sentence expression:** "You're not stuck at 5% of AI's potential because you haven't learned enough — you're stuck because you've been using AI as a tool when what your business needs is AI infrastructure, and nobody has offered to install it."
