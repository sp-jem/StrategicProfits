# CTD — Connect the Dots: Demand Architect Project Brief

**Date:** 2026-02-28
**Run mode:** Full (all 9 steps + 3 synthesis outputs)
**Audience:** This output is the sample shown to Alex Makarski (agency owner, Clickmakers.io) to demonstrate what the demand-architect skill can produce for clients

---

## INPUTS CONFIRMED

**Business/Product:** Connect the Dots (CTD)
**URL:** strategicprofits.com
**Product description:** 2-day in-person AI implementation intensive, $10,000. Promise: "You leave with working AI systems installed on YOUR machine" — not education, installation.

**Target market:** Established entrepreneurs
- Revenue: $300K–$50M
- Age: 35–60
- Business types: service, agency, coaching, information businesses
- Experience: 5–20+ years in business
- AI experience: They've tried ChatGPT and Claude basics. Feel stuck at ~5% of AI's potential.
- Entry trigger: Saw Rich Schefren's demo and realized they're doing AI wrong

**Emotional drivers:**
- Fear of being left behind as competitors adopt AI
- Desire for the leverage that comes from AI systems (not just tools)

**Competitive context:** General AI courses, other implementation programs, AI coaching services

**Output folder:** `/Users/richardschefren/Documents/Obsidian/Active-Brain/00 Projects/01 Zenith/01 ZenithPro/Demand-Architect-Sample/CTD/`
