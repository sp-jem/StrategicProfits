# Step 4: Avatar Profiles
## CTD — Connect the Dots

Three primary avatar segments with full psychological profiles. Pipeline depth applied.

---

## AVATAR 1: "The Agency Owner Who Is Losing the Narrative"

### Section A: Demographic & Situational Context

Alex, 48. Runs a digital marketing or creative agency. $800K–$3M revenue. 8–15 person team. Has been in business 12–18 years. Clients are service businesses, mid-market companies. Revenue has been relatively stable for 3–5 years — good business, not a rocket ship. Increasingly getting asked by prospects: "How are you using AI?"

### Section B: Identity & Core Beliefs

Alex built the agency on his ability to know more about digital marketing than his clients. His value proposition has always been expertise. The unspoken threat AI represents: "If a client can now use AI to produce marketing assets directly, what am I selling?"

Core belief about himself: "I'm the expert. My experience makes my work better than what you could do yourself." This identity is under attack.

Core belief about AI: "AI is going to take over a lot of what we do for clients. I need to figure out how to get ahead of this before my clients figure it out first."

### Section G: Objection Archaeology

Primary objections:
1. "I've bought AI programs before and came away with nothing I could use." (Competitor-installed belief)
2. "I can't justify being out of office for 2 days plus the cost."
3. "Will this actually apply to an agency or is it generic business stuff?"

### Section H: Decision Neuroscience

Alex makes purchasing decisions when the THREAT feels more immediate than the investment. He buys when he reads something (or sees someone) that triggers the "this is happening faster than I thought" response. Rich Schefren's demo triggers this: "He's doing things with AI I don't know how to do, and he's doing it in real time."

### Section J: Purchase Triggers

The specific trigger: Watching Rich work with AI in real-time and realizing the gap between what he's doing and what Rich is doing is not a knowledge gap — it's an infrastructure gap. Knowledge he could study his way out of. Infrastructure requires someone to build it with him.

### Section M: Mimetic Model Profile

**Aspirational model:** Ryan Deiss or similar "serious entrepreneur who took AI seriously and built it into everything." The model Alex is trying to become is the well-respected agency owner who has AI embedded in his operations so deeply that his agency is now 3x more efficient than his competitors.

**Competitor whose model Alex has been trying to emulate:** Ryan Deiss. Alex probably bought the AI-Powered Entrepreneur Accelerator or something similar.

**What that competitor's model offered:** "Become the AI-forward operator." The desire mediated: Status + Power.

**What happened when Alex pursued that model:** He has more knowledge. He has no installed systems. He feels more anxious, not less, because now he can see the gap more clearly than before.

**The mimetic wound:** Alex spent $2,000+ on AI education and is MORE aware of being behind than when he started. The education increased his anxiety by making the gap visible without closing it.

**What Alex actually wants vs. what he asks for:** He asks for "how to use AI in my agency." What he actually wants is to feel like the most sophisticated operator in his competitive set again. He wants his expertise advantage restored.

---

## AVATAR 2: "The Information Marketer Who Knows AI is the Next Chapter"

### Section A: Demographic & Situational Context

Marcus, 52. Runs an online education or information business. $500K–$5M revenue. Sells courses, coaching programs, memberships. Small team (2–5 people). Has been selling information products for 10+ years. Rich Schefren's original "Internet Business Manifesto" era.

### Section B: Identity & Core Beliefs

Marcus built his business on being the person with the answer. His email list is his asset. His knowledge is his product. He's been watching AI-native competitors enter his market and create content faster.

Core belief about himself: "I know more about my subject than anyone. My content is better because I've lived it. AI-generated content is shallow."

Core belief about AI: "AI is going to commoditize generic information. The only defense is to use AI to go deeper, faster — not to use it to go cheaper."

### Section G: Objection Archaeology

1. "I don't want AI content to replace my authentic voice." (Valid — and shows the sophistication of this buyer)
2. "I'm not sure AI systems will integrate with my existing tools." (Legitimate operational concern)
3. "I don't have an ops person to maintain AI systems after I build them." (True — and CTD needs to address ongoing maintenance)

### Section H: Decision Neuroscience

Marcus buys when he sees a specific demonstration that maps to his exact situation. He is skeptical of general promises. He buys ROI when he can see the mechanism clearly. Abstract "you'll be more efficient" does not move him. Specific: "Here's how your course launch will work with AI running the email sequence diagnostics" — that moves him.

### Section M: Mimetic Model Profile

**Aspirational model:** A slightly more AI-capable version of Rich Schefren himself. Marcus has been watching Rich for years. Rich IS the model he's aspiring toward.

**What Rich's model offers:** "The business architect who uses AI to leverage a small team into enterprise-level output."

**Previous AI attempts:** Marcus has built some GPT assistants. They are technically functional but produce generic output. He hasn't figured out how to give them enough of his specific knowledge and voice to make them useful.

**The mimetic wound:** He built AI tools that felt like they belonged to a stranger, not his business. They produced outputs that didn't sound like him. This has reinforced the "AI can't replace my authentic voice" defense mechanism.

**What Marcus actually wants:** He wants to see what his business looks like when AI is handling the parts that drain him (operations, research, first drafts of support responses) so he can spend all his time on the parts that require him specifically (big ideas, relationship building, content strategy). He wants the AI systems to be INVISIBLE — working in the background — not something he has to operate.

---

## AVATAR 3: "The Service Business Owner Drowning in Delivery"

### Section A: Demographic & Situational Context

Sandra, 44. Runs a consulting, financial planning, or professional services business. $400K–$2M revenue. 3–8 people. Built on referrals and reputation. She is the primary deliverer of the service. The business cannot run without her. This creates a ceiling she's been trying to break through for years.

### Section B: Identity & Core Beliefs

Sandra's identity is built on personal expertise. She IS the product. Her challenge: she can't clone herself. She has been told many times that she needs to "systemize and scale" but her clients hire HER. You can't systemize a relationship.

Core belief about herself: "My clients pay for ME. Not a process. Not a system. Me."

Core belief about AI: "Maybe AI can handle the parts that don't require my judgment. That would free me to do more of what clients actually pay for."

### Section G: Objection Archaeology

1. "My work is too nuanced for AI to handle." (The specific professional services objection)
2. "My clients trust me. If they find out I'm using AI, they might feel deceived." (Real concern in regulated/trust-based industries)
3. "The time to set this up would cost me more than the time it saves." (Has tried before and spent 3x the promised payback period)

### Section J: Purchase Triggers

Sandra's trigger is a demonstration of a system doing something she currently does herself, in her exact business context. If Rich shows her an AI handling client onboarding screening, research summarization, or report drafting — things she PERSONALLY spends time on — she responds immediately. Abstract "AI will free up your time" means nothing. Concrete "here's your onboarding questionnaire being processed and a client brief generated automatically" lands.

### Section M: Mimetic Model Profile

**Aspirational model:** A version of herself that delivers the same quality but has 4 extra hours a day. Not a different person — the same person with restored capacity.

**Competitor whose model has influenced Sandra:** Less influenced by specific AI trainers. More influenced by general "systems and scale" consultants who promised delegation/leverage before AI existed. She's tried that. It didn't work. AI feels like another iteration of the same promise.

**The mimetic wound:** Every "systemize your business" program she's done increased her administrative burden without reducing her delivery hours. She has more processes, more documentation, more team management — and still works the same hours. The promise of "systems = freedom" has been broken multiple times.

**What Sandra actually wants:** She wants 2 hours back per day. Not theoretical. Literally, by next week, she wants to spend less time on the parts of her business that don't require her specific judgment. She is entirely practical. She would not describe herself as wanting "AI systems" — she wants specific tasks off her plate. The vehicle doesn't matter. The result matters.

---

## CROSS-AVATAR PATTERNS

**All three avatars share:**

1. They have tried AI and gotten minimal working output
2. They are skeptical of programs that promise more of the same
3. They would respond to specific, concrete demonstrations over general claims
4. Their businesses already work — they need AI integrated into existing infrastructure, not a new business model
5. The Section M Mimetic Wound is essentially the same: they pursued the "AI-powered entrepreneur" model that competitors mediate, invested money, gained knowledge, and came away with nothing operational

**The shared desire:** Completion over education. Systems that exist, not systems they'll someday build.
