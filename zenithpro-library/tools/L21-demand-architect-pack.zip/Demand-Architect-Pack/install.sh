#!/bin/bash
# Demand Architect — Installer (macOS / Linux)
# Copies the skill and sample outputs into your Claude Code configuration.

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DEST="$HOME/.claude/skills/demand-architect"
SAMPLE_DEST="$SKILL_DEST/references/ctd-sample"

echo "=== Demand Architect Installer ==="
echo ""

# Create directories
mkdir -p "$SKILL_DEST"
mkdir -p "$SAMPLE_DEST/markdown"
mkdir -p "$SAMPLE_DEST/pdfs"

# Copy skill
cp "$SCRIPT_DIR/skills/demand-architect/SKILL.md" "$SKILL_DEST/SKILL.md"
echo "[OK] Installed skill to $SKILL_DEST/SKILL.md"

# Copy sample markdown outputs
if [ -d "$SCRIPT_DIR/references/ctd-sample/markdown" ]; then
  cp "$SCRIPT_DIR/references/ctd-sample/markdown/"* "$SAMPLE_DEST/markdown/"
  echo "[OK] Installed sample markdown outputs to $SAMPLE_DEST/markdown/"
fi

# Copy sample PDF outputs
if [ -d "$SCRIPT_DIR/references/ctd-sample/pdfs" ]; then
  cp "$SCRIPT_DIR/references/ctd-sample/pdfs/"* "$SAMPLE_DEST/pdfs/"
  echo "[OK] Installed sample PDF outputs to $SAMPLE_DEST/pdfs/"
fi

echo ""
echo "Installation complete."
echo ""
echo "To run: open Claude Code and type  /demand-architect full [your market]"
echo ""
echo "Modes:"
echo "  /demand-architect full [market]    — All 9 steps + 3 synthesis outputs"
echo "  /demand-architect quick [market]   — Steps 5-8 only (when Steps 1-4 are done)"
echo "  /demand-architect audit [market]   — Analyze existing marketing"
