# George Loewenstein Curiosity & Behavioral Skills
## Strategic Profits / Deep Marketing Thinkers Series

---

## What This Is

7 Claude Code skills built on George Loewenstein's behavioral economics research — the psychology of curiosity, visceral decision-making, and temporal experience. Loewenstein's core insight: **people don't make decisions through rational analysis alone — curiosity, emotional states, risk perception, and the passage of time shape behavior in predictable, designable ways.** Most marketing uses these forces intuitively. These skills make them visible and auditable.

These skills translate that research into executable marketing intelligence tools that decode the behavioral dynamics in any funnel, offer, or customer journey.

---

## Installation

**Mac / Linux:**
```bash
chmod +x install.sh
./install.sh
```

**Windows (PowerShell):**
```powershell
.\install.ps1
```

Restart Claude Code after installing.

---

## The 7 Skills

### 1. `/loewenstein-curiosity-architect {funnel-or-content}`
**Audit and design information gap structures.**
Maps where curiosity is being triggered or killed in your funnel. Diagnoses whether your audience has enough knowledge to FEEL the gap (the inverted-U — total mystery kills curiosity for uninformed audiences). Classifies every gap as diversive (drives clicks) or specific (drives purchases). Identifies dead zones, premature closures, and orphaned gaps.

### 2. `/loewenstein-empathy-gap-map {offer-or-journey}`
**Map the hot-cold empathy gaps across your customer journey.**
Tracks emotional state from marketing (hot) through purchase (peak hot) to consumption (cold reality). Identifies where projection bias causes buyers to overestimate future engagement, where buyer's remorse emerges, and where the gap between purchase-state enthusiasm and implementation-state reality creates churn. Evaluates bridge mechanisms.

### 3. `/loewenstein-risk-as-feelings {offer-or-funnel}`
**Audit how your offer addresses BOTH risk systems.**
Most marketing addresses analytical risk (proof, guarantees, statistics) but ignores emotional risk (what the buyer FEELS when imagining failure). This skill maps where the two systems diverge, inventories dread factors, assesses personal-experience-based risk from previous burns, and evaluates whether risk-reduction elements target the right system.

### 4. `/loewenstein-anticipation-engine {sequence-or-experience}`
**Audit and design temporal sequences for optimal anticipation.**
Maps where anticipation is being built or squandered in launches, courses, events, and onboarding. Tracks dread accumulation, evaluates whether sequences improve or decline over time, checks peak placement and ending quality (peak-end rule), and assesses countdown mechanics. Time is an asset, not an enemy.

### 5. `/loewenstein-visceral-audit {funnel-or-sequence}`
**Audit visceral factor triggers across your marketing.**
Maps WHERE specific visceral factors fire (fear, excitement, urgency, FOMO, status anxiety — not just "emotions"), whether those triggers are calibrated (too weak = no action, too strong = exploitation), and whether CTAs align with visceral intensity peaks. Includes ethical calibration assessment.

### 6. `/loewenstein-information-flow {funnel-or-journey}`
**Audit the complete information architecture of a customer journey.**
Maps what the buyer KNOWS, DOESN'T KNOW, and is AVOIDING knowing (ostrich effect) at every stage. Evaluates the wanting/liking balance (are you creating desire that delivery can sustain?). Classifies engagement as diversive (passive consumption) or specific (drives action). Surfaces the knowledge curse.

### 7. `/loewenstein-field-intelligence`
**Master synthesis layer — reads all Loewenstein outputs simultaneously.**
Cross-layer synthesis that detects convergence zones invisible to individual skills. Produces a unified Behavioral Field Briefing with: convergence map, the Single Move (one highest-leverage action), self-examination mirror, temporal coherence check, 90-day projection, and risk/opportunity matrix. Run this after running multiple Loewenstein skills on the same business.

---

## Key Concepts

### The Inverted-U of Curiosity
Curiosity peaks at MODERATE knowledge — not maximum mystery. Too little knowledge = no curiosity (you don't know what you're missing). Too much = no curiosity (gap is closed). This means GIVING information often INCREASES curiosity. The common advice to "be mysterious" backfires with cold audiences.

### The Hot-Cold Empathy Gap
People in a calm state can't predict how they'll behave when emotional, and vice versa. The buyer excited at a webinar genuinely believes they'll implement at that level of enthusiasm. They won't. The gap between purchase-state and consumption-state is predictable and designable.

### Risk as Feelings
People evaluate risk through TWO parallel systems: cognitive analysis (probability x consequence) and emotional response (how it FEELS to imagine failure). When the two diverge, feelings predict behavior. More proof doesn't fix emotional risk. A guarantee addresses analytical risk but not the FEELING of "what if this doesn't work for me."

### The Ostrich Effect
People actively avoid information they expect to be negative — even when that information is free and useful. Your prospect may be avoiding the exact truth your marketing needs to deliver. Making uncomfortable information ACTIONABLE (not just diagnostic) converts avoidance to seeking.

### Wanting vs. Liking
Neurologically separate systems. Wanting (dopamine) drives acquisition. Liking (opioids) determines satisfaction. Marketing optimizes wanting; delivery determines liking. High wanting + low liking = refunds. Low wanting + high liking = invisible product. The sustainable sweet spot requires both.

---

## Recommended Starting Sequence

1. **`/loewenstein-curiosity-architect`** — audit your funnel's information gaps
2. **`/loewenstein-empathy-gap-map`** — map where hot/cold state mismatches create problems
3. **`/loewenstein-risk-as-feelings`** — check if you're addressing the right risk system
4. **`/loewenstein-field-intelligence`** — synthesize findings into one strategic direction

Then run **`/loewenstein-anticipation-engine`** before any launch or temporal sequence design, **`/loewenstein-visceral-audit`** before any conversion optimization, and **`/loewenstein-information-flow`** for complete journey architecture.

---

## Works With Girard and Veblen Skills

If you have the Girard and/or Veblen skills installed, the Loewenstein skills cross-reference them:
- **Girard** explains WHAT people want (borrowed desire from models)
- **Veblen** explains HOW they signal what they've acquired (status display)
- **Loewenstein** explains what DRIVES or BLOCKS action on that wanting (curiosity, emotion, risk, time)

Together they answer: what does this market want, how does it signal what it has, and what moves or stops people from acting? Each Loewenstein skill includes Girard and Veblen Cross-Reference sections that activate when those outputs exist.

---

## Source

Based on the work of **George Loewenstein (1955–present)** — *The Psychology of Curiosity* (1994), *Out of Control: Visceral Influences on Behavior* (1996), *Risk as Feelings* (2001, with Weber, Hsee, Welch), *Anticipation and the Valuation of Delayed Consumption* (1987), *Projection Bias in Predicting Future Utility* (2003, with O'Donoghue, Rabin), *The Ostrich Effect* (2009, with Karlsson, Seppi).

Part of the Deep Marketing Thinkers series — thinkers who described the real mechanisms behind how desire forms, how decisions get made, and how behaviors spread through populations.

---

*Strategic Profits — Deep Marketing Thinkers Series*
