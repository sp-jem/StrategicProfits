#!/bin/bash
# ============================================================
# George Loewenstein Curiosity & Behavioral Skills — Installer (Mac/Linux)
# Strategic Profits / Deep Marketing Thinkers Series
# ============================================================

SKILLS_DIR="$HOME/.claude/skills"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/skills"

SKILLS=(
  "loewenstein-curiosity-architect"
  "loewenstein-empathy-gap-map"
  "loewenstein-risk-as-feelings"
  "loewenstein-anticipation-engine"
  "loewenstein-visceral-audit"
  "loewenstein-information-flow"
  "loewenstein-field-intelligence"
)

echo ""
echo "============================================================"
echo " George Loewenstein Curiosity & Behavioral Skills — Installer"
echo " Strategic Profits / Deep Marketing Thinkers Series"
echo "============================================================"
echo ""

# Check Claude Code skills directory exists
if [ ! -d "$SKILLS_DIR" ]; then
  echo "Creating ~/.claude/skills/ directory..."
  mkdir -p "$SKILLS_DIR"
fi

INSTALLED=0
SKIPPED=0

for skill in "${SKILLS[@]}"; do
  if [ -d "$SKILLS_DIR/$skill" ]; then
    echo "  SKIP  $skill  (already installed)"
    ((SKIPPED++))
  else
    cp -r "$SOURCE_DIR/$skill" "$SKILLS_DIR/$skill"
    echo "  OK    $skill"
    ((INSTALLED++))
  fi
done

echo ""
echo "------------------------------------------------------------"
echo "  Installed: $INSTALLED skills"
echo "  Skipped:   $SKIPPED (already present)"
echo "------------------------------------------------------------"
echo ""
echo "NEXT STEP: Restart Claude Code, then try:"
echo "  /loewenstein-curiosity-architect  — audit information gap structures"
echo "  /loewenstein-empathy-gap-map      — map hot-cold empathy gaps"
echo "  /loewenstein-risk-as-feelings     — audit both risk systems"
echo "  /loewenstein-anticipation-engine  — design temporal sequences"
echo "  /loewenstein-visceral-audit       — audit visceral factor triggers"
echo "  /loewenstein-information-flow     — audit information architecture"
echo "  /loewenstein-field-intelligence   — master synthesis across all outputs"
echo ""
echo "See README.md for full usage guide."
echo ""
