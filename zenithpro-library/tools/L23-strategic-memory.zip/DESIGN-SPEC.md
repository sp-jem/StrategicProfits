# Strategic Memory — Design Specification

## What This Is

A fully autonomous persistent memory system for Claude Code. After a one-time setup command, it captures decisions, commitments, preferences, and insights mechanically across every session — no user intervention needed. Memories are stored as markdown files in the Obsidian vault, browseable and searchable. A briefing generates at every session start with overdue commitments, stale decisions, and people tracking.

## How We Built It

### The Two Systems We Combined

This system was built by combining two independently developed memory architectures:

**System A — Rich's Memory Agent Daemon** (production-tested, 31 days, 2,473 memories)
A 5-thread Python daemon that polls Claude Code session .jsonl files every 10 seconds, extracts memories via Haiku, stores them in a JSON file, and runs consolidation and decay scoring. Runs as a macOS LaunchAgent — always on, always capturing.

**System B — Hook-Based Skill Architecture** (built from scratch, informed by 5 OSS frameworks)
A Claude Code skill that captures memories via settings.json hooks (SessionStart for briefing, Stop for extraction) and CLAUDE.md instructions for in-session awareness. Stores memories as individual markdown files in the Obsidian vault — browseable, searchable, and linked.

### Why We Combined Them This Way

Rich's daemon is better at one thing: between-session capture. It runs 24/7 and catches everything — even sessions that crash without the Stop hook firing.

The hook-based approach is better at everything else: simpler delivery (no launchd, no background process, cross-platform), vault-native storage (markdown files in Obsidian), temporal validity, semantic search, autonomous corrections, and a refined extraction prompt.

The combined system uses hooks as the primary capture mechanism (simpler, works for everyone) while making the architecture compatible with a daemon running alongside for power users who want the safety net.

The briefing engine reads both data sources — our memory markdown files AND Rich's brain-state.json (if present). If a student only has our system, the briefing works from memory files alone. If they also have Rich's brain infrastructure, the briefing automatically pulls in the richer data — priorities, behavioral patterns, people model with follow-through rates, execution evidence on decisions.

### What We Took From Each Source

**From Rich's production system:**
- Decay formula: `1.0 * (0.95 ^ days_since_last_access) * (1 + 0.1 * access_count)`
- Confidence threshold: 0.8 minimum
- "Would they be pissed if lost?" extraction philosophy
- Commitment aging thresholds (7 days = aging, 14 days = overdue)
- People tracking model (pending items, follow-through rate)
- Consolidation logic (hash + Jaccard dedup with auto-merge at 0.8+)
- Memory types: decision, commitment, preference, context, correction, reference

**From 5 open source frameworks (166K+ combined GitHub stars):**

- **claude-mem (46K stars):** Hook-based capture on SessionStart/Stop lifecycle events. Progressive disclosure retrieval (search → timeline → full detail) for token efficiency.
- **Mem0 (52K stars):** Multi-type memory taxonomy. Multi-level scoping (user, session, agent). Pinecone as a supported vector backend.
- **Graphiti (25K stars):** Bi-temporal validity — every fact has valid_from and valid_until. Old facts are invalidated, never deleted. Enables "what was true in March vs now?" queries.
- **Letta (22K stars):** Attached vs detached memory concept. Some context always in the prompt (BRIEFING.md at session start); full store retrieved on demand (semantic search).
- **Cognee (15K stars):** Cross-agent shared memory. What one session learns should be accessible to all sessions. Vault-native markdown files make this automatic via vault sync.

**From our existing Claude Code infrastructure:**
- Hook-based mechanical enforcement (100% fire rate — hooks are executed by the harness, not by Claude)
- Markdown-native storage (Obsidian-first — every memory is a file you can browse, link, and search)
- Zero external dependencies beyond what students already have from Day 6

### The Pivot From Daemon to Skill + Hooks

Rich's original spec called for packaging his memory agent daemon for FM students. This required: Python environment setup, launchd plists, background process management, crash recovery, log file debugging, and macOS-only infrastructure.

The skill + hooks approach accomplishes the exact same capture with none of that complexity. Settings.json hooks fire 100% mechanically on SessionStart and Stop. Students already use hooks from their existing setup. Works on Mac and Windows identically. No new process to manage, no new infrastructure to debug, no support tickets about "my daemon won't start."

Same result, radically simpler delivery.

## Architecture

```
AUTONOMOUS BEHAVIOR (no user commands needed after setup):
  SessionStart hook  →  briefing.py  →  BRIEFING.md + session context injection
  CLAUDE.md block    →  in-session capture + corrections + search
  Stop hook          →  extract.py   →  memory files + Pinecone upsert + state update

MEMORY ENGINE (Python):
  extract.py              — Haiku extraction + corrections + temporal validity
  state.py                — state index, decay scoring, review items, search
  briefing.py             — BRIEFING.md generator (reads both memory files AND brain-state.json)
  consolidate.py           — hash + Jaccard deduplication
  pinecone_integration.py  — semantic search + upsert + backfill
  verify.py                — installation verification + frontmatter integrity check

STORAGE (Obsidian vault):
  memory/decisions/        — browseable .md files with YAML frontmatter
  memory/commitments/      — temporal validity (valid_from/valid_until)
  memory/preferences/      — decay scores, tags, confidence
  memory/insights/
  memory/people/
  memory/corrections/
  memory/_archive/         — superseded + dormant memories (never deleted)
  data/state.json          — computed index (active counts, people, timestamps)
  data/BRIEFING.md         — auto-generated intelligence briefing

PINECONE (existing from Day 6):
  Index: business-operations
  Namespace: strategic-memory
  Semantic search over all memory content
```

## Quality Assurance Process

This system was tested by 8 independent QA agents running in parallel:

| Agent | What It Tested | Key Findings (Fixed) |
|-------|---------------|---------------------|
| **Gauntlet** | 8-phase pipeline (structure, triggers, quality /50) | $HOME path bug, nested code fences, description mismatch, double-append risk |
| **Coherent Design** | Cross-file references, schema drift, data flow | Pinecone SDK attribute access, last_extraction never written, total_memories counting superseded |
| **Code Reviewer** | Bugs, security, error handling, portability | Atomic write missing in frontmatter updates, os.walk performance, briefing timeout risk |
| **Skill Mastery** | 10-criterion skill quality rubric | Constraint ratio, missing exemplars, feedback/calibration gaps |
| **Phoenix** | Source-truth audit, claim verification, seam scan | False "zero dependencies" claim, false "only command" claim, $HOME literal paths |
| **Prompt Architect** | Four-Block Blueprint, guardrails, anti-slop | Missing exemplars, identity invariants absent, three-tier uncertainty absent |
| **Saboteur** | 10 adversarial break scenarios | Settings.json clobber risk, silent API failure, Obsidian edit corruption, Windows bash failure |
| **Novice** | First-timer walkthrough, jargon audit | 21 undefined terms, no success signals, no "Before You Begin" section |

All findings were consolidated and fixed in a single pass. Critical fixes:
- `$HOME` → `os.path.expanduser("~")` in all Python snippets
- Atomic write for frontmatter field updates (tmp + os.replace)
- Three-tier confidence for capture decisions (HIGH/MEDIUM/LOW)
- API failure error flag surfaced in briefing
- Settings.json backup before merge
- Pinecone SDK v3 Pydantic attribute access
- Frontmatter integrity check in verify.py
- Windows caveat in setup instructions

## What It Does That Nothing Else Does

| Feature | Rich's Daemon | claude-mem | Mem0 | Strategic Memory |
|---------|---------------|-----------|------|-----------------|
| Obsidian-native (browseable) | No (JSON) | No (SQLite) | No (JSON) | Yes (markdown) |
| Temporal validity | No | No | No | Yes |
| Mechanical capture (hooks) | Yes (daemon) | Yes (hooks) | No (API calls) | Yes (hooks) |
| Semantic search | No | Yes (ChromaDB) | Yes | Yes (Pinecone) |
| Decay scoring | Yes | No | No | Yes |
| Business intel (commitments, people) | Yes | No | No | Yes |
| Autonomous corrections | No | No | No | Yes |
| Cross-platform (Mac + Windows) | No | Partial | Yes | Yes |
| 8-agent QA tested | No | No | No | Yes |

## For Students

Drop the `strategic-memory/` folder into `~/.claude/skills/`. Say "set up strategic memory." Never think about it again.

The system captures, stores, decays, deduplicates, corrects, searches, and briefs — all mechanically. Every session starts informed. Intelligence compounds automatically.
