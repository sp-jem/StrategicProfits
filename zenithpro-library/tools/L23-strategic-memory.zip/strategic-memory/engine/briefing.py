#!/usr/bin/env python3
"""
briefing.py — Strategic Memory briefing generator.
Combined version: reads state.json + memory files (our system) AND brain-state.json
(Rich's system, if available) for maximum intelligence depth.

No API calls. Pure file reads + string formatting. Must complete in <5 seconds.
"""

import os
import sys
import json
from datetime import datetime, date

_this_dir = os.path.dirname(os.path.abspath(__file__))
if _this_dir not in sys.path:
    sys.path.insert(0, _this_dir)

from state import (
    _get_memory_dir, _get_state_path, load_state, scan_memories,
    run_decay, recompute_state, log
)

_ie_dir = os.path.join(os.path.expanduser("~/.claude/skills/intelligence-engine"))
for p in [_ie_dir, os.path.join(_ie_dir, "brain")]:
    if p not in sys.path:
        sys.path.insert(0, p)

try:
    import brain_config
except ImportError:
    brain_config = None


def _get_briefing_path():
    if brain_config and brain_config.DATA_DIR:
        return os.path.join(brain_config.DATA_DIR, "BRIEFING.md")
    return None


def _load_brain_state():
    """Load brain-state.json if available (Rich's Day 6 infrastructure)."""
    if not brain_config or not brain_config.BRAIN_STATE_FILE:
        return None
    try:
        if os.path.exists(brain_config.BRAIN_STATE_FILE):
            with open(brain_config.BRAIN_STATE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except (json.JSONDecodeError, IOError):
        pass
    return None


def _days_since(date_str):
    """Calculate days since a date string."""
    if not date_str:
        return 0
    try:
        dt = datetime.fromisoformat(str(date_str).split("+")[0].split("T")[0])
        return max(0, (datetime.now() - dt).days)
    except (ValueError, TypeError):
        return 0


def _format_date(date_str):
    """Format a date string for display."""
    if not date_str:
        return "unknown"
    return str(date_str)[:10]


# ---------------------------------------------------------------------------
# Section builders
# ---------------------------------------------------------------------------

def _build_header(now, total_memories):
    lines = [
        f"# Strategic Memory Briefing",
        f"*Generated: {now.strftime('%Y-%m-%d @ %I:%M %p')}*",
    ]
    if total_memories > 0:
        lines.append(f"*{total_memories} active memories across your vault*")
    lines.append("")
    return lines


def _build_priorities(state, brain_state):
    """Build priorities from our state.json and/or brain-state.json."""
    lines = ["## Priorities"]

    # Try our state first
    priorities = state.get("priorities", [])

    # Fall back to brain-state declared_priorities
    if not priorities and brain_state:
        priorities = brain_state.get("metadata", {}).get("declared_priorities", [])

    if not priorities:
        lines.append("No priorities declared yet.")
        return lines

    for p in priorities:
        rank = p.get("rank", "?")
        name = p.get("name", "Unnamed")
        declared = p.get("declared_date") or p.get("declared", "")
        date_note = f" *(declared {_format_date(declared)})*" if declared else ""
        lines.append(f"{rank}. {name}{date_note}")

    lines.append("")
    return lines


def _build_attention(stats, people, brain_state):
    """Build attention-required section from both data sources."""
    warnings = []

    # From our stats
    overdue = stats.get("commitments_overdue", 0)
    stale = stats.get("decisions_stale", 0)
    if overdue > 0:
        warnings.append(f"- **{overdue} commitment{'s' if overdue > 1 else ''} overdue** (14+ days)")
    if stale > 0:
        warnings.append(f"- **{stale} decision{'s' if stale > 1 else ''} going stale** (21+ days, no execution)")

    # From brain-state (if available and has additional data)
    if brain_state:
        bs_commits = brain_state.get("commitments", [])
        bs_overdue = sum(1 for c in bs_commits
                         if c.get("age_days", 0) >= 14
                         and c.get("status", "open") not in ("resolved", "completed", "cancelled", "expired"))
        if bs_overdue > overdue:
            warnings = [f"- **{bs_overdue} commitment{'s' if bs_overdue > 1 else ''} overdue** (14+ days)"]

    # People warnings
    for name, pdata in people.items():
        pending = pdata.get("pending_items", 0)
        if pending > 0:
            warnings.append(f"- {name} has {pending} pending item{'s' if pending > 1 else ''} from you")

    if not warnings:
        return []

    lines = ["## Attention Required"]
    lines.extend(warnings)
    lines.append("")
    return lines


def _build_commitments(memories, brain_state):
    """Build commitments section from memory files and/or brain-state."""
    commitments = []

    # From our memory files
    for fp, fm in memories:
        if fm.get("type") == "commitment" and fm.get("status") == "active":
            age = _days_since(fm.get("created"))
            commitments.append({
                "content": fm.get("content", ""),
                "person": fm.get("person", ""),
                "age_days": age,
                "source": "memory",
            })

    # From brain-state (merge, dedup by content similarity)
    if brain_state:
        existing_content = {c["content"].lower()[:50] for c in commitments}
        terminal = getattr(brain_config, 'TERMINAL_STATUSES', {"resolved", "completed", "cancelled", "expired"})
        for c in brain_state.get("commitments", []):
            if c.get("status", "open") in terminal:
                continue
            desc = c.get("description", "")
            if desc.lower()[:50] not in existing_content:
                commitments.append({
                    "content": desc,
                    "person": c.get("person", ""),
                    "age_days": c.get("age_days", _days_since(c.get("date_committed") or c.get("created"))),
                    "source": "brain-state",
                })

    if not commitments:
        return []

    commitments.sort(key=lambda x: -x["age_days"])

    lines = [f"## Active Commitments ({len(commitments)})"]

    # Group by urgency
    overdue = [c for c in commitments if c["age_days"] >= 14]
    aging = [c for c in commitments if 7 <= c["age_days"] < 14]
    current = [c for c in commitments if c["age_days"] < 7]

    if overdue:
        lines.append(f"### Overdue (14+ days)")
        for c in overdue:
            person_str = f" *(to {c['person']})*" if c["person"] else ""
            lines.append(f"- [{c['age_days']}d] {c['content']}{person_str}")

    if aging:
        lines.append(f"### Aging (7-13 days)")
        for c in aging:
            person_str = f" *(to {c['person']})*" if c["person"] else ""
            lines.append(f"- [{c['age_days']}d] {c['content']}{person_str}")

    if current:
        lines.append(f"### Current")
        for c in current[:10]:
            person_str = f" *(to {c['person']})*" if c["person"] else ""
            lines.append(f"- [{c['age_days']}d] {c['content']}{person_str}")

    lines.append("")
    return lines


def _build_decisions(memories, brain_state):
    """Build decisions section from memory files and/or brain-state."""
    decisions = []

    for fp, fm in memories:
        if fm.get("type") == "decision" and fm.get("status") == "active":
            age = _days_since(fm.get("created"))
            decisions.append({
                "content": fm.get("content", ""),
                "age_days": age,
                "execution_status": fm.get("execution_status", ""),
                "source": "memory",
            })

    if brain_state:
        existing_content = {d["content"].lower()[:50] for d in decisions}
        terminal = getattr(brain_config, 'DECISION_TERMINAL_STATUSES', {"executed", "abandoned", "superseded"})
        for d in brain_state.get("decisions", []):
            if d.get("execution_status", "no_evidence") in terminal:
                continue
            desc = d.get("description", "")
            if desc.lower()[:50] not in existing_content:
                decisions.append({
                    "content": desc,
                    "age_days": d.get("days_since", _days_since(d.get("decided_date") or d.get("created"))),
                    "execution_status": d.get("execution_status", ""),
                    "source": "brain-state",
                })

    if not decisions:
        return []

    decisions.sort(key=lambda x: x["age_days"])

    lines = [f"## Open Decisions ({len(decisions)})"]

    at_risk = [d for d in decisions if d["age_days"] >= 21 and d["execution_status"] in ("", "not_started", "no_evidence")]
    active = [d for d in decisions if d not in at_risk]

    if at_risk:
        lines.append("### At Risk (21+ days, no execution)")
        for d in at_risk:
            lines.append(f"- [{d['age_days']}d] {d['content']} — **STALE**")

    if active:
        lines.append("### Active")
        for d in active[:10]:
            status_str = f" [{d['execution_status']}]" if d["execution_status"] and d["execution_status"] not in ("", "not_started", "no_evidence") else ""
            lines.append(f"- [{d['age_days']}d] {d['content']}{status_str}")

    lines.append("")
    return lines


def _build_people(people, brain_state):
    """Build people section from our state and/or brain-state people_model."""
    all_people = dict(people)

    if brain_state:
        for name, pdata in brain_state.get("people_model", {}).items():
            if name not in all_people:
                role = pdata.get("role", "")
                all_people[name] = {
                    "role": role,
                    "pending_items": 0,
                    "follow_through_rate": pdata.get("commitment_follow_through_rate", 0),
                }

    with_items = {n: d for n, d in all_people.items() if d.get("pending_items", 0) > 0}
    if not with_items:
        return []

    lines = ["## People"]
    for name, pdata in sorted(with_items.items(), key=lambda x: -x[1].get("pending_items", 0)):
        rate = pdata.get("follow_through_rate", 0)
        rate_str = f", {rate:.0%} follow-through" if rate > 0 else ""
        role_str = f" ({pdata['role']})" if pdata.get("role") else ""
        lines.append(f"- **{name}**{role_str}: {pdata.get('pending_items', 0)} pending{rate_str}")

    lines.append("")
    return lines


def _build_insights(memories):
    """Build insights section from memory files."""
    insights = [(fp, fm) for fp, fm in memories
                if fm.get("type") == "insight" and fm.get("status") == "active"]
    if not insights:
        return []

    insights.sort(key=lambda x: x[1].get("created", ""), reverse=True)

    lines = ["## Recent Insights"]
    for fp, fm in insights[:5]:
        conf = fm.get("confidence", 0)
        lines.append(f"- {fm.get('content', '')} *(confidence: {conf})*")

    lines.append("")
    return lines


def _build_patterns(brain_state):
    """Build patterns section from brain-state (Rich's system)."""
    if not brain_state:
        return []

    patterns = brain_state.get("patterns", {})
    all_patterns = []
    for category, items in patterns.items():
        for p in (items or []):
            all_patterns.append((category, p))

    if not all_patterns:
        return []

    category_labels = {
        "behavioral": "Behavioral", "business": "Business",
        "team": "Team", "systemic": "Systemic",
    }

    lines = ["## Patterns"]
    grouped = {}
    for cat, p in all_patterns:
        grouped.setdefault(cat, []).append(p)

    for cat in ["behavioral", "business", "team", "systemic"]:
        if cat not in grouped:
            continue
        items = grouped[cat]
        label = category_labels.get(cat, cat.title())
        lines.append(f"### {label} ({len(items)})")
        for p in items[:5]:
            desc = p.get("description", "")
            conf = p.get("confidence")
            conf_str = f" ({int(conf * 100)}%)" if conf is not None else ""
            lines.append(f"- {desc}{conf_str}")

    lines.append("")
    return lines


def _build_preferences(memories):
    """Build preferences section."""
    prefs = [(fp, fm) for fp, fm in memories
             if fm.get("type") == "preference" and fm.get("status") == "active"]
    if not prefs:
        return []

    prefs.sort(key=lambda x: x[1].get("created", ""), reverse=True)

    lines = [f"## Preferences ({len(prefs)} stored)"]
    for fp, fm in prefs[:3]:
        lines.append(f"- {fm.get('content', '')}")
    if len(prefs) > 3:
        lines.append(f"- *...and {len(prefs) - 3} more*")

    lines.append("")
    return lines


# ---------------------------------------------------------------------------
# Main generator
# ---------------------------------------------------------------------------

def generate_briefing(memory_dir=None, state_path=None):
    """Generate BRIEFING.md from all available data sources."""
    mem_dir = memory_dir or _get_memory_dir()
    now = datetime.now()

    # Run decay only if stale (once per day, not every session start)
    if mem_dir:
        state = load_state(state_path)
        last_decay = state.get("stats", {}).get("last_decay_run", "")
        decay_stale = True
        if last_decay:
            try:
                last_dt = datetime.fromisoformat(str(last_decay).split("+")[0])
                decay_stale = (now - last_dt).total_seconds() > 86400  # 24 hours
            except (ValueError, TypeError):
                pass
        if decay_stale:
            run_decay(mem_dir)
        state = recompute_state(mem_dir, state_path)
    else:
        state = load_state(state_path)

    memories = scan_memories(mem_dir) if mem_dir else []
    active = [(fp, fm) for fp, fm in memories if fm.get("status") == "active"]
    brain_state = _load_brain_state()

    # Empty state — onboarding message
    if not active and not brain_state:
        return (
            f"# Strategic Memory Briefing\n"
            f"*Generated: {now.strftime('%Y-%m-%d @ %I:%M %p')}*\n\n"
            f"No memories tracked yet — use Claude Code normally and Strategic Memory "
            f"will capture your decisions, commitments, and insights automatically.\n\n"
            f"As you make decisions, commitments, and observations during sessions, "
            f"they'll appear here at the start of your next session.\n"
        )

    stats = state.get("stats", {})
    people = state.get("people", {})

    sections = []
    sections.extend(_build_header(now, len(active)))

    # Check for extraction error flag
    error_flag = os.path.expanduser("~/.claude/logs/strategic-memory-error-flag")
    if os.path.exists(error_flag):
        try:
            with open(error_flag) as f:
                err_content = f.read().strip()
            sections.append("## WARNING: Extraction Failed")
            sections.append(f"Last extraction error: {err_content}")
            sections.append("Check your Anthropic API key at `~/.claude/credentials/anthropic-linker.env`")
            sections.append("")
            # Clear the flag after surfacing
            os.remove(error_flag)
        except (IOError, OSError):
            pass
    sections.extend(_build_priorities(state, brain_state))
    sections.extend(_build_attention(stats, people, brain_state))
    sections.extend(_build_commitments(active, brain_state))
    sections.extend(_build_decisions(active, brain_state))
    sections.extend(_build_people(people, brain_state))
    sections.extend(_build_insights(active))
    sections.extend(_build_patterns(brain_state))
    sections.extend(_build_preferences(active))

    return "\n".join(sections)


def write_briefing(briefing_text, briefing_path=None):
    """Write BRIEFING.md to vault."""
    path = briefing_path or _get_briefing_path()
    if not path:
        log.error("No briefing path available")
        return False

    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(briefing_text)
        log.info("BRIEFING.md written to %s", path)
        return True
    except (IOError, OSError) as e:
        log.error("Failed to write BRIEFING.md: %s", e)
        return False


def generate_summary(briefing_text):
    """Extract compact summary for session context injection."""
    lines = briefing_text.split("\n")
    summary_lines = []
    in_attention = False

    for line in lines:
        if line.startswith("# Strategic Memory Briefing"):
            continue
        if line.startswith("*Generated:"):
            continue
        if "active memories" in line.lower():
            summary_lines.insert(0, line.strip().strip("*"))
        if line.startswith("## Attention Required"):
            in_attention = True
            summary_lines.append("ATTENTION:")
            continue
        if in_attention and line.startswith("- "):
            summary_lines.append(line)
            continue
        if in_attention and line.startswith("##"):
            in_attention = False

    if not summary_lines:
        summary_lines.append("Strategic Memory active. No urgent items.")

    return "\n".join(summary_lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    mem_dir = _get_memory_dir()
    briefing = generate_briefing(mem_dir)
    write_briefing(briefing)
    summary = generate_summary(briefing)
    print(summary)

    st = load_state()
    st["stats"]["last_briefing"] = datetime.now().isoformat()
    save_state(st)
