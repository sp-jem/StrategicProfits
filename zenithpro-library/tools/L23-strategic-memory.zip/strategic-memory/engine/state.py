#!/usr/bin/env python3
"""
state.py — Strategic Memory state manager.
Owns state.json exclusively. Scans memory files, computes stats,
runs decay scoring, archives dormant memories.

Can be run standalone or imported.
"""

import json
import os
import re
import shutil
import sys
from datetime import datetime

# ---------------------------------------------------------------------------
# Import shared config (brain_config for vault path, config for logging/atomic_write)
# ---------------------------------------------------------------------------
_this_dir = os.path.dirname(os.path.abspath(__file__))
_ie_dir = os.path.join(os.path.expanduser("~/.claude/skills/intelligence-engine"))
for p in [_this_dir, _ie_dir, os.path.join(_ie_dir, "brain")]:
    if p not in sys.path:
        sys.path.insert(0, p)

try:
    import config
    import brain_config
    log = config.setup_logging("strategic-memory")
except ImportError as e:
    import logging
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger("strategic-memory")
    log.warning("Could not import config/brain_config: %s", e)
    config = None
    brain_config = None

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
def _get_memory_dir():
    """Get memory directory path from brain_config."""
    if brain_config and brain_config.DATA_DIR:
        return os.path.join(os.path.dirname(brain_config.DATA_DIR), "memory")
    return None

def _get_state_path():
    """Get state.json path."""
    if brain_config and brain_config.DATA_DIR:
        return os.path.join(brain_config.DATA_DIR, "state.json")
    return None

MEMORY_TYPES = ["decisions", "commitments", "preferences", "insights", "people", "corrections"]
SCHEMA_VERSION = "1.0.0"

# ---------------------------------------------------------------------------
# YAML frontmatter parser (no external dependency)
# ---------------------------------------------------------------------------
def parse_frontmatter(filepath):
    """Parse YAML frontmatter from a markdown file. Returns dict or None."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
    except (IOError, OSError):
        return None

    if not content.startswith("---"):
        return None

    end = content.find("---", 3)
    if end == -1:
        return None

    yaml_str = content[3:end].strip()
    fm = {}
    for line in yaml_str.split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ": " in line:
            key, val = line.split(": ", 1)
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            # Parse types
            if val == "null" or val == "~":
                fm[key] = None
            elif val.lower() == "true":
                fm[key] = True
            elif val.lower() == "false":
                fm[key] = False
            elif re.match(r'^-?\d+$', val):
                fm[key] = int(val)
            elif re.match(r'^-?\d+\.\d+$', val):
                fm[key] = float(val)
            elif val.startswith("[") and val.endswith("]"):
                # Simple array: [tag1, tag2, tag3]
                items = val[1:-1].split(",")
                fm[key] = [i.strip().strip('"').strip("'") for i in items if i.strip()]
            else:
                fm[key] = val
        elif ":" in line:
            key = line.split(":")[0].strip()
            fm[key] = ""
    return fm


def write_frontmatter_field(filepath, field, value):
    """Update a single frontmatter field in a memory file."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
    except (IOError, OSError):
        return False

    if not content.startswith("---"):
        return False

    end = content.find("---", 3)
    if end == -1:
        return False

    yaml_section = content[3:end]
    rest = content[end:]

    # Format value
    if value is None:
        val_str = "null"
    elif isinstance(value, bool):
        val_str = str(value).lower()
    elif isinstance(value, list):
        val_str = "[" + ", ".join(str(v) for v in value) + "]"
    elif isinstance(value, float):
        val_str = f"{value:.4f}"
    else:
        val_str = str(value)

    # Replace existing field or append
    pattern = re.compile(rf'^{re.escape(field)}:.*$', re.MULTILINE)
    new_line = f"{field}: {val_str}"
    if pattern.search(yaml_section):
        yaml_section = pattern.sub(new_line, yaml_section)
    else:
        yaml_section = yaml_section.rstrip() + "\n" + new_line + "\n"

    new_content = "---" + yaml_section + rest
    try:
        # Atomic write: tmp + rename to prevent corruption on crash
        tmp_path = filepath + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(new_content)
        os.replace(tmp_path, filepath)
        return True
    except (IOError, OSError):
        # Clean up tmp file if rename failed
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        return False


# ---------------------------------------------------------------------------
# State management
# ---------------------------------------------------------------------------
def _default_state():
    """Return empty state.json schema."""
    return {
        "schema_version": SCHEMA_VERSION,
        "metadata": {
            "owner_name": "",
            "business_name": "",
            "configured_date": datetime.now().strftime("%Y-%m-%d"),
            "last_updated": datetime.now().isoformat(),
            "total_memories": 0,
            "total_archived": 0,
        },
        "priorities": [],
        "people": {},
        "stats": {
            "decisions_active": 0,
            "decisions_stale": 0,
            "commitments_active": 0,
            "commitments_overdue": 0,
            "insights_total": 0,
            "last_briefing": "",
            "last_extraction": "",
            "last_consolidation": "",
            "last_decay_run": "",
        },
        "consolidation_review_queue": [],
    }


def load_state(state_path=None):
    """Load state.json. Falls back to .bak, then default."""
    path = state_path or _get_state_path()
    if not path:
        log.warning("No state path available")
        return _default_state()

    for try_path in [path, path + ".bak"]:
        if os.path.exists(try_path):
            try:
                with open(try_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if data.get("schema_version") != SCHEMA_VERSION:
                    log.warning("state.json schema_version %s != expected %s",
                                data.get("schema_version"), SCHEMA_VERSION)
                if try_path.endswith(".bak"):
                    log.warning("Loaded state from backup: %s", try_path)
                return data
            except (json.JSONDecodeError, IOError) as e:
                log.warning("Failed to load %s: %s", try_path, e)
                continue

    log.info("No state.json found, creating default")
    return _default_state()


def save_state(data, state_path=None):
    """Save state.json atomically with backup."""
    path = state_path or _get_state_path()
    if not path:
        log.error("No state path available — cannot save")
        return False

    os.makedirs(os.path.dirname(path), exist_ok=True)
    data["metadata"]["last_updated"] = datetime.now().isoformat()

    # Backup
    if os.path.exists(path):
        try:
            shutil.copy2(path, path + ".bak")
        except (IOError, OSError) as e:
            log.warning("Failed to create backup: %s", e)

    # Atomic write
    content = json.dumps(data, indent=2, default=str)
    if config:
        config.atomic_write(path, content)
    else:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(content)
        os.replace(tmp, path)

    return True


def scan_memories(memory_dir=None):
    """Scan all memory files and return list of (filepath, frontmatter) tuples."""
    mem_dir = memory_dir or _get_memory_dir()
    if not mem_dir or not os.path.isdir(mem_dir):
        return []

    results = []
    for type_name in MEMORY_TYPES:
        type_dir = os.path.join(mem_dir, type_name)
        if not os.path.isdir(type_dir):
            continue
        for fname in os.listdir(type_dir):
            if not fname.endswith(".md"):
                continue
            fpath = os.path.join(type_dir, fname)
            fm = parse_frontmatter(fpath)
            if fm:
                results.append((fpath, fm))
    return results


def run_decay(memory_dir=None):
    """Apply decay scoring to all active memories. Archive dormant ones."""
    memories = scan_memories(memory_dir)
    mem_dir = memory_dir or _get_memory_dir()
    now = datetime.now()
    decayed = 0
    archived = 0

    for fpath, fm in memories:
        if fm.get("status") != "active":
            continue

        tags = fm.get("tags", [])
        if isinstance(tags, str):
            tags = [tags]
        if "core_belief" in tags or "permanent" in tags:
            continue

        # Days since last access
        last_accessed = fm.get("last_accessed") or fm.get("created", "")
        try:
            last_dt = datetime.fromisoformat(str(last_accessed).replace("Z", "+00:00").split("+")[0])
            days_since = max(0, (now - last_dt).days)
        except (ValueError, TypeError):
            days_since = 30

        # Decay rate: preferences decay slower
        mem_type = fm.get("type", "")
        rate = 0.98 if mem_type == "preference" else 0.95

        access_count = fm.get("access_count", 0)
        if isinstance(access_count, str):
            access_count = int(access_count) if access_count.isdigit() else 0

        decay_score = 1.0 * (rate ** days_since) * (1 + 0.1 * access_count)
        decay_score = round(min(1.0, max(0.0, decay_score)), 4)

        if decay_score != fm.get("decay_score"):
            write_frontmatter_field(fpath, "decay_score", decay_score)
            decayed += 1

        # Archive if dormant
        if decay_score < 0.1 and mem_dir:
            archive_dir = os.path.join(mem_dir, "_archive")
            os.makedirs(archive_dir, exist_ok=True)
            write_frontmatter_field(fpath, "status", "dormant")
            dest = os.path.join(archive_dir, os.path.basename(fpath))
            try:
                shutil.move(fpath, dest)
                archived += 1
            except (IOError, OSError) as e:
                log.warning("Failed to archive %s: %s", fpath, e)

    if decayed > 0 or archived > 0:
        log.info("Decay: updated %d scores, archived %d dormant memories", decayed, archived)
    return decayed, archived


def recompute_state(memory_dir=None, state_path=None):
    """Full state recomputation from memory files."""
    memories = scan_memories(memory_dir)
    state = load_state(state_path)
    now = datetime.now()

    # Reset counters
    stats = state["stats"]
    stats["decisions_active"] = 0
    stats["decisions_stale"] = 0
    stats["commitments_active"] = 0
    stats["commitments_overdue"] = 0
    stats["insights_total"] = 0

    people = {}

    for fpath, fm in memories:
        if fm.get("status") != "active":
            continue

        mem_type = fm.get("type", "")

        if mem_type == "decision":
            stats["decisions_active"] += 1
            # Stale: 21+ days with no execution
            created = fm.get("created", "")
            exec_status = fm.get("execution_status", "not_started")
            if exec_status in ("not_started", ""):
                try:
                    created_dt = datetime.fromisoformat(str(created).split("+")[0])
                    if (now - created_dt).days >= 21:
                        stats["decisions_stale"] += 1
                except (ValueError, TypeError):
                    pass

        elif mem_type == "commitment":
            stats["commitments_active"] += 1
            # Overdue: 14+ days
            created = fm.get("created", "")
            try:
                created_dt = datetime.fromisoformat(str(created).split("+")[0])
                if (now - created_dt).days >= 14:
                    stats["commitments_overdue"] += 1
            except (ValueError, TypeError):
                pass

            # People tracking
            person = fm.get("person", "")
            if person and person != "null":
                if person not in people:
                    people[person] = {"role": "", "pending_items": 0,
                                      "follow_through_rate": 0.0,
                                      "communication_style": "",
                                      "last_updated": now.strftime("%Y-%m-%d")}
                people[person]["pending_items"] += 1
                people[person]["last_updated"] = now.strftime("%Y-%m-%d")

        elif mem_type == "insight":
            stats["insights_total"] += 1

        elif mem_type == "person":
            # Person-type memories update the people model
            person_name = fm.get("content", "").split(" — ")[0] if " — " in fm.get("content", "") else fm.get("content", "")
            if person_name:
                if person_name not in people:
                    people[person_name] = {"role": "", "pending_items": 0,
                                           "follow_through_rate": 0.0,
                                           "communication_style": "",
                                           "last_updated": now.strftime("%Y-%m-%d")}

    # Count archived
    mem_dir = memory_dir or _get_memory_dir()
    archive_count = 0
    if mem_dir:
        archive_dir = os.path.join(mem_dir, "_archive")
        if os.path.isdir(archive_dir):
            archive_count = len([f for f in os.listdir(archive_dir) if f.endswith(".md")])

    active_count = sum(1 for _, fm in memories if fm.get("status") == "active")
    state["metadata"]["total_memories"] = active_count
    state["metadata"]["total_archived"] = archive_count
    state["metadata"]["last_updated"] = now.isoformat()
    state["stats"]["last_decay_run"] = now.isoformat()

    # Merge people (preserve existing data, update counts)
    existing_people = state.get("people", {})
    for name, data in people.items():
        if name in existing_people:
            existing_people[name]["pending_items"] = data["pending_items"]
            existing_people[name]["last_updated"] = data["last_updated"]
        else:
            existing_people[name] = data
    state["people"] = existing_people

    save_state(state, state_path)
    log.info("State recomputed: %d active memories, %d archived", len(memories), archive_count)
    return state


# ---------------------------------------------------------------------------
# Review Items (Phase 2)
# ---------------------------------------------------------------------------
def get_review_items(memory_dir=None):
    """Get items needing human attention: aging commitments, stale decisions,
    consolidation review queue, and low-decay items about to archive."""
    memories = scan_memories(memory_dir)
    now = datetime.now()

    aging_commitments = []      # 7-13 days
    overdue_commitments = []    # 14+ days
    stale_decisions = []        # 21+ days, no execution
    low_decay = []              # decay 0.1-0.3, about to archive

    for fpath, fm in memories:
        if fm.get("status") != "active":
            continue

        mem_type = fm.get("type", "")
        created = fm.get("created", "")
        try:
            created_dt = datetime.fromisoformat(str(created).split("+")[0])
            age_days = (now - created_dt).days
        except (ValueError, TypeError):
            age_days = 0

        if mem_type == "commitment":
            if age_days >= 14:
                overdue_commitments.append({
                    "id": fm.get("id"), "content": fm.get("content"),
                    "person": fm.get("person"), "age_days": age_days,
                    "filepath": fpath,
                })
            elif age_days >= 7:
                aging_commitments.append({
                    "id": fm.get("id"), "content": fm.get("content"),
                    "person": fm.get("person"), "age_days": age_days,
                    "filepath": fpath,
                })

        elif mem_type == "decision":
            exec_status = fm.get("execution_status", "not_started")
            if age_days >= 21 and exec_status in ("not_started", ""):
                stale_decisions.append({
                    "id": fm.get("id"), "content": fm.get("content"),
                    "age_days": age_days, "filepath": fpath,
                })

        decay = fm.get("decay_score", 1.0)
        if isinstance(decay, str):
            try:
                decay = float(decay)
            except ValueError:
                decay = 1.0
        if 0.1 <= decay <= 0.3:
            low_decay.append({
                "id": fm.get("id"), "content": fm.get("content"),
                "type": mem_type, "decay_score": decay, "filepath": fpath,
            })

    # Get consolidation review queue from state
    state = load_state()
    review_queue = [item for item in state.get("consolidation_review_queue", [])
                    if item.get("status") == "pending"]

    return {
        "overdue_commitments": sorted(overdue_commitments, key=lambda x: -x["age_days"]),
        "aging_commitments": sorted(aging_commitments, key=lambda x: -x["age_days"]),
        "stale_decisions": sorted(stale_decisions, key=lambda x: -x["age_days"]),
        "low_decay": sorted(low_decay, key=lambda x: x["decay_score"]),
        "consolidation_queue": review_queue[:10],
        "total_attention_items": (len(overdue_commitments) + len(aging_commitments) +
                                  len(stale_decisions) + len(review_queue)),
    }


def search_memories(query, memory_dir=None, limit=10):
    """Keyword search across all active memories. Returns scored results."""
    memories = scan_memories(memory_dir)
    query_lower = query.lower()
    query_words = set(query_lower.split())
    results = []

    for fpath, fm in memories:
        if fm.get("status") != "active":
            continue

        content = fm.get("content", "").lower()
        tags = fm.get("tags", [])
        if isinstance(tags, str):
            tags = [tags]
        tags_str = " ".join(t.lower() for t in tags)
        searchable = content + " " + tags_str

        matches = sum(1 for w in query_words if w in searchable)
        if matches == 0:
            continue

        overlap_score = matches / len(query_words) if query_words else 0
        decay = fm.get("decay_score", 1.0)
        if isinstance(decay, str):
            try:
                decay = float(decay)
            except ValueError:
                decay = 1.0

        score = round(overlap_score * decay, 4)
        results.append({
            "score": score,
            "id": fm.get("id"),
            "type": fm.get("type"),
            "content": fm.get("content"),
            "created": fm.get("created"),
            "confidence": fm.get("confidence"),
            "decay_score": decay,
            "tags": tags,
            "filepath": fpath,
        })

    results.sort(key=lambda x: -x["score"])
    return results[:limit]


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    mem_dir = _get_memory_dir()
    if not mem_dir:
        print("ERROR: Could not detect vault path. Is Day 6 setup complete?")
        sys.exit(1)

    print(f"Memory directory: {mem_dir}")
    print("Running decay...")
    decayed, archived = run_decay(mem_dir)
    print(f"  Decayed: {decayed}, Archived: {archived}")

    print("Recomputing state...")
    state = recompute_state(mem_dir)
    print(f"  Active memories: {state['metadata']['total_memories']}")
    print(f"  Archived: {state['metadata']['total_archived']}")
    print(f"  Decisions: {state['stats']['decisions_active']} active, {state['stats']['decisions_stale']} stale")
    print(f"  Commitments: {state['stats']['commitments_active']} active, {state['stats']['commitments_overdue']} overdue")
    print(f"  Insights: {state['stats']['insights_total']}")
    print("Done.")
