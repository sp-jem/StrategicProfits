#!/usr/bin/env python3
"""
verify.py — Strategic Memory installation verification.
Checks all components are installed and functional.
"""

import json
import os
import sys

checks_passed = 0
checks_failed = 0


def check(name, condition, fix_hint=""):
    global checks_passed, checks_failed
    if condition:
        print(f"  ✓ {name}")
        checks_passed += 1
    else:
        print(f"  ✗ {name}")
        if fix_hint:
            print(f"    → {fix_hint}")
        checks_failed += 1


def main():
    global checks_passed, checks_failed
    print("Strategic Memory — Installation Verification\n")

    # Check 1: brain_config importable
    print("[1] Day 6 Prerequisites")
    ie_dir = os.path.expanduser("~/.claude/skills/intelligence-engine")
    brain_dir = os.path.join(ie_dir, "brain")
    for p in [ie_dir, brain_dir]:
        if p not in sys.path:
            sys.path.insert(0, p)

    try:
        import brain_config
        vault = brain_config.ACTIVE_VAULT
        check("brain_config.py importable", True)
        check("Vault detected", vault is not None,
              "Run /setup-brain to configure your vault")
        data_dir = brain_config.DATA_DIR
        check("DATA_DIR set", data_dir is not None)
    except ImportError:
        check("brain_config.py importable", False,
              "Run /setup-brain first (Day 6)")
        print("\n  Cannot continue without Day 6 setup. Stopping.")
        return

    # Check 2: Anthropic API key
    print("\n[2] API Key")
    try:
        key = brain_config.get_anthropic_key()
        check("Anthropic API key found", bool(key))
    except Exception as e:
        check("Anthropic API key found", False,
              f"Set ANTHROPIC_API_KEY in ~/.claude/credentials/anthropic-linker.env")

    # Check 3: Memory folder structure
    print("\n[3] Vault Structure")
    if vault:
        # Use same path derivation as engine scripts
        try:
            from state import _get_memory_dir
            mem_dir = _get_memory_dir() or os.path.join(vault, "00 Intelligence Engine", "memory")
        except ImportError:
            mem_dir = os.path.join(vault, "00 Intelligence Engine", "memory")
        check("memory/ folder exists", os.path.isdir(mem_dir),
              "Run /memory setup to create folders")
        for subdir in ["decisions", "commitments", "preferences", "insights", "people", "corrections", "_archive"]:
            path = os.path.join(mem_dir, subdir)
            check(f"  memory/{subdir}/", os.path.isdir(path))

        # Frontmatter integrity check
        try:
            from state import scan_memories, parse_frontmatter
            total_md = 0
            corrupt_md = 0
            for subdir in ["decisions", "commitments", "preferences", "insights", "people", "corrections"]:
                sdir = os.path.join(mem_dir, subdir)
                if not os.path.isdir(sdir):
                    continue
                for fname in os.listdir(sdir):
                    if fname.endswith(".md"):
                        total_md += 1
                        if parse_frontmatter(os.path.join(sdir, fname)) is None:
                            corrupt_md += 1
            if total_md > 0:
                check(f"  Memory file integrity ({total_md} files)", corrupt_md == 0,
                      f"{corrupt_md} file(s) have corrupt YAML frontmatter — check manually in Obsidian")
        except ImportError:
            pass

    # Check 4: state.json
    print("\n[4] State File")
    if data_dir:
        state_path = os.path.join(data_dir, "state.json")
        exists = os.path.exists(state_path)
        check("state.json exists", exists, "Run /memory setup to initialize")
        if exists:
            try:
                with open(state_path) as f:
                    data = json.load(f)
                check("state.json valid JSON", True)
                check("schema_version = 1.0.0",
                      data.get("schema_version") == "1.0.0",
                      "Re-run /memory setup to upgrade")
            except (json.JSONDecodeError, IOError):
                check("state.json valid JSON", False, "Re-run /memory setup")

    # Check 5: Hooks in settings.json
    print("\n[5] Hooks")
    settings_path = os.path.expanduser("~/.claude/settings.json")
    if os.path.exists(settings_path):
        try:
            with open(settings_path) as f:
                settings = json.load(f)
            hooks = settings.get("hooks", {})

            session_start = hooks.get("SessionStart", [])
            has_start = any("strategic-memory" in str(h.get("command", "")) or
                           "briefing.py" in str(h.get("command", ""))
                           for h in session_start)
            check("SessionStart hook installed", has_start,
                  "Run /memory setup to install hooks")

            stop = hooks.get("Stop", [])
            has_stop = any("strategic-memory" in str(h.get("command", "")) or
                          "extract.py" in str(h.get("command", ""))
                          for h in stop)
            check("Stop hook installed", has_stop,
                  "Run /memory setup to install hooks")
        except (json.JSONDecodeError, IOError):
            check("settings.json readable", False)
    else:
        check("settings.json exists", False,
              "Claude Code settings file not found")

    # Check 6: CLAUDE.md block
    print("\n[6] CLAUDE.md Integration")
    claude_md_paths = [
        os.path.expanduser("~/.claude/CLAUDE.md"),
    ]
    found_block = False
    for path in claude_md_paths:
        if os.path.exists(path):
            try:
                with open(path) as f:
                    content = f.read()
                if "Strategic Memory" in content:
                    found_block = True
                    break
            except IOError:
                pass
    check("Strategic Memory block in CLAUDE.md", found_block,
          "Run /memory setup to add the instruction block")

    # Check 7: Engine scripts
    print("\n[7] Engine Scripts")
    engine_dir = os.path.expanduser("~/.claude/skills/strategic-memory/engine")
    for script in ["extract.py", "state.py", "briefing.py", "consolidate.py", "pinecone_integration.py", "verify.py"]:
        path = os.path.join(engine_dir, script)
        check(f"{script} exists", os.path.exists(path),
              f"Re-run installer (install.sh)")

    # Summary
    print(f"\n{'=' * 40}")
    total = checks_passed + checks_failed
    if checks_failed == 0:
        print(f"ALL {total} CHECKS PASSED ✓")
        print("Strategic Memory is fully operational.")
    else:
        print(f"{checks_passed}/{total} checks passed, {checks_failed} FAILED")
        print("Run /memory setup to fix the issues above.")

    return checks_failed == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
