#!/usr/bin/env python3
"""
pinecone_integration.py — Strategic Memory Pinecone integration.
Upserts memory vectors on creation, queries semantically on search.
Degrades gracefully if Pinecone is not configured.

Uses the existing business-operations index from Day 6 setup-pinecone.
Namespace: "strategic-memory" (separate from other brain data).
"""

import os
import sys

_this_dir = os.path.dirname(os.path.abspath(__file__))
if _this_dir not in sys.path:
    sys.path.insert(0, _this_dir)

from state import parse_frontmatter, scan_memories, log

_ie_dir = os.path.join(os.path.expanduser("~/.claude/skills/intelligence-engine"))
for p in [_ie_dir, os.path.join(_ie_dir, "brain")]:
    if p not in sys.path:
        sys.path.insert(0, p)

try:
    import brain_config
except ImportError:
    brain_config = None

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
INDEX_NAME = "business-operations"
NAMESPACE = "strategic-memory"
EMBED_MODEL = "llama-text-embed-v2"
EMBED_BATCH = 20

# ---------------------------------------------------------------------------
# Lazy-loaded Pinecone client
# ---------------------------------------------------------------------------
_pc = None
_index = None


def _get_client():
    """Lazy-load Pinecone client. Returns (pc, index) or (None, None)."""
    global _pc, _index
    if _pc is not None:
        return _pc, _index

    if not brain_config:
        log.debug("brain_config not available — Pinecone disabled")
        return None, None

    try:
        api_key = brain_config.get_pinecone_key()
    except (RuntimeError, AttributeError):
        log.debug("Pinecone API key not found — Pinecone disabled")
        return None, None

    try:
        from pinecone import Pinecone
        _pc = Pinecone(api_key=api_key)
        _index = _pc.Index(INDEX_NAME)
        log.info("Pinecone connected: index=%s, namespace=%s", INDEX_NAME, NAMESPACE)
        return _pc, _index
    except Exception as e:
        log.warning("Pinecone initialization failed: %s", e)
        return None, None


def _embed_texts(texts, input_type="passage"):
    """Embed texts using Pinecone Inference API in safe batches."""
    pc, _ = _get_client()
    if not pc:
        return []

    all_vectors = []
    for i in range(0, len(texts), EMBED_BATCH):
        batch = texts[i:i + EMBED_BATCH]
        result = pc.inference.embed(
            model=EMBED_MODEL,
            inputs=batch,
            parameters={"input_type": input_type, "truncate": "END"},
        )
        all_vectors.extend([r.values for r in result])
    return all_vectors


# ---------------------------------------------------------------------------
# Upsert
# ---------------------------------------------------------------------------
def upsert_memories(memory_dir, filepaths):
    """Upsert newly created memory files to Pinecone.

    Args:
        memory_dir: vault memory directory (for context)
        filepaths: list of memory file paths to upsert
    """
    pc, index = _get_client()
    if not index:
        return 0

    records = []
    texts = []
    metas = []

    for fpath in filepaths:
        fm = parse_frontmatter(fpath)
        if not fm:
            continue

        mem_id = fm.get("id", os.path.basename(fpath))
        content = fm.get("content", "")
        reasoning = fm.get("reasoning", "")
        mem_type = fm.get("type", "")
        tags = fm.get("tags", [])
        if isinstance(tags, str):
            tags = [tags]

        # Combine content + reasoning for richer embedding
        embed_text = f"{content}. {reasoning}" if reasoning else content
        texts.append(embed_text)
        metas.append({
            "memory_id": mem_id,
            "content": content[:500],
            "type": mem_type,
            "tags": ", ".join(tags),
            "file_path": fpath,
            "created": fm.get("created", ""),
            "confidence": fm.get("confidence", 0),
        })

    if not texts:
        return 0

    # Embed
    try:
        vectors = _embed_texts(texts, input_type="passage")
    except Exception as e:
        log.warning("Pinecone embedding failed: %s", e)
        return 0

    if len(vectors) != len(texts):
        log.warning("Embedding count mismatch: %d texts, %d vectors", len(texts), len(vectors))
        return 0

    # Build upsert records
    for i, (vec, meta) in enumerate(zip(vectors, metas)):
        records.append({
            "id": meta["memory_id"],
            "values": vec,
            "metadata": meta,
        })

    # Upsert
    try:
        index.upsert(vectors=records, namespace=NAMESPACE)
        log.info("Pinecone: upserted %d memories to namespace '%s'", len(records), NAMESPACE)
        return len(records)
    except Exception as e:
        log.warning("Pinecone upsert failed: %s", e)
        return 0


def semantic_search(query, top_k=10):
    """Semantic search over memory vectors in Pinecone.

    Returns list of dicts with score, memory_id, content, type, tags.
    Falls back to empty list if Pinecone unavailable.
    """
    pc, index = _get_client()
    if not index:
        log.debug("Pinecone not available — semantic search disabled")
        return []

    try:
        q_vec = _embed_texts([query], input_type="query")
        if not q_vec:
            return []

        results = index.query(
            vector=q_vec[0],
            top_k=top_k,
            include_metadata=True,
            namespace=NAMESPACE,
        )

        # Handle both Pinecone SDK v3 (Pydantic objects) and v2 (dicts)
        matches = getattr(results, 'matches', None)
        if matches is None:
            matches = results.get("matches", []) if hasattr(results, 'get') else []
        output = []
        for match in matches:
            meta = getattr(match, 'metadata', None) or (match.get("metadata", {}) if hasattr(match, 'get') else {})
            score = getattr(match, 'score', None) or (match.get("score", 0) if hasattr(match, 'get') else 0)
            output.append({
                "score": round(score, 4),
                "memory_id": meta.get("memory_id", "") if hasattr(meta, 'get') else getattr(meta, 'memory_id', ''),
                "content": meta.get("content", "") if hasattr(meta, 'get') else getattr(meta, 'content', ''),
                "type": meta.get("type", "") if hasattr(meta, 'get') else getattr(meta, 'type', ''),
                "tags": meta.get("tags", "") if hasattr(meta, 'get') else getattr(meta, 'tags', ''),
                "file_path": meta.get("file_path", "") if hasattr(meta, 'get') else getattr(meta, 'file_path', ''),
                "created": meta.get("created", "") if hasattr(meta, 'get') else getattr(meta, 'created', ''),
                "confidence": meta.get("confidence", 0) if hasattr(meta, 'get') else getattr(meta, 'confidence', 0),
            })

        log.info("Pinecone semantic search: '%s' → %d results", query[:50], len(output))
        return output

    except Exception as e:
        log.warning("Pinecone search failed: %s", e)
        return []


def backfill_all(memory_dir=None):
    """Backfill all existing active memories into Pinecone.
    Run once after Phase 3 upgrade to index pre-existing memories."""
    if not memory_dir:
        from state import _get_memory_dir
        memory_dir = _get_memory_dir()
    if not memory_dir:
        log.error("No memory directory found")
        return 0

    memories = scan_memories(memory_dir)
    active_paths = [fpath for fpath, fm in memories if fm.get("status") == "active"]

    if not active_paths:
        log.info("No active memories to backfill")
        return 0

    count = upsert_memories(memory_dir, active_paths)
    log.info("Backfill complete: %d memories indexed in Pinecone", count)
    return count


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Strategic Memory Pinecone integration")
    parser.add_argument("--backfill", action="store_true", help="Backfill all existing memories to Pinecone")
    parser.add_argument("--search", help="Semantic search query")
    parser.add_argument("--status", action="store_true", help="Check Pinecone connectivity")
    args = parser.parse_args()

    if args.backfill:
        count = backfill_all()
        print(f"Backfilled {count} memories to Pinecone")
    elif args.search:
        results = semantic_search(args.search)
        if results:
            for r in results:
                print(f"[{r['type']}] {r['content']} (score: {r['score']})")
        else:
            print("No results (Pinecone may not be configured)")
    elif args.status:
        pc, index = _get_client()
        if index:
            try:
                stats = index.describe_index_stats()
                namespaces = getattr(stats, 'namespaces', None) or (stats.get("namespaces", {}) if hasattr(stats, 'get') else {})
                ns = namespaces.get(NAMESPACE, {}) if hasattr(namespaces, 'get') else getattr(namespaces, NAMESPACE, {})
                count = ns.get("vector_count", 0) if hasattr(ns, 'get') else getattr(ns, 'vector_count', 0)
                print(f"Pinecone connected: {count} vectors in namespace '{NAMESPACE}'")
            except Exception as e:
                print(f"Pinecone error: {e}")
        else:
            print("Pinecone not configured or not available")
    else:
        parser.print_help()
