#!/usr/bin/env python3
"""
consolidate.py — Strategic Memory deduplication.
Exact hash dedup + Jaccard near-duplicate detection.
Called as post-write step by extract.py.
"""

import os
import sys
from datetime import datetime

_this_dir = os.path.dirname(os.path.abspath(__file__))
if _this_dir not in sys.path:
    sys.path.insert(0, _this_dir)

from state import (
    _get_memory_dir, scan_memories, parse_frontmatter,
    write_frontmatter_field, load_state, save_state, log
)

JACCARD_AUTO_MERGE = 0.8
JACCARD_FLAG_REVIEW = 0.6
REVIEW_QUEUE_MAX = 100


def _jaccard(text_a, text_b):
    """Jaccard similarity between two strings (word-level)."""
    words_a = set(text_a.lower().split())
    words_b = set(text_b.lower().split())
    if not words_a or not words_b:
        return 0.0
    intersection = len(words_a & words_b)
    union = len(words_a | words_b)
    return intersection / union if union > 0 else 0.0


def run_consolidation(memory_dir=None):
    """Deduplicate memories. Returns count of merged items."""
    mem_dir = memory_dir or _get_memory_dir()
    if not mem_dir:
        return 0

    memories = scan_memories(mem_dir)
    active = [(fp, fm) for fp, fm in memories if fm.get("status") == "active"]

    if len(active) < 2:
        return 0

    merged = 0
    state = load_state()
    review_queue = state.get("consolidation_review_queue", [])
    existing_pairs = {
        tuple(sorted(item["pair"]))
        for item in review_queue
        if item.get("status") == "pending"
    }

    for i in range(len(active)):
        fp_a, fm_a = active[i]
        if fm_a.get("status") != "active":
            continue

        for j in range(i + 1, len(active)):
            fp_b, fm_b = active[j]
            if fm_b.get("status") != "active":
                continue

            content_a = fm_a.get("content", "")
            content_b = fm_b.get("content", "")
            sim = _jaccard(content_a, content_b)

            if sim >= JACCARD_AUTO_MERGE:
                # Auto-merge: keep higher confidence
                conf_a = fm_a.get("confidence", 0)
                conf_b = fm_b.get("confidence", 0)
                if isinstance(conf_a, str):
                    conf_a = float(conf_a) if conf_a.replace('.', '').isdigit() else 0
                if isinstance(conf_b, str):
                    conf_b = float(conf_b) if conf_b.replace('.', '').isdigit() else 0

                if conf_a >= conf_b:
                    primary_fm, secondary_fp, secondary_fm = fm_a, fp_b, fm_b
                else:
                    primary_fm, secondary_fp, secondary_fm = fm_b, fp_a, fm_a

                write_frontmatter_field(secondary_fp, "status", "superseded")
                write_frontmatter_field(secondary_fp, "superseded_by", primary_fm.get("id", ""))
                secondary_fm["status"] = "superseded"  # Update in-memory too
                merged += 1
                log.info("Auto-merged: '%s' superseded by '%s' (Jaccard=%.2f)",
                         secondary_fm.get("id"), primary_fm.get("id"), sim)

            elif sim >= JACCARD_FLAG_REVIEW:
                pair_key = tuple(sorted([fm_a.get("id", ""), fm_b.get("id", "")]))
                if pair_key not in existing_pairs:
                    review_queue.append({
                        "pair": list(pair_key),
                        "jaccard": round(sim, 4),
                        "flagged_at": datetime.now().isoformat(),
                        "status": "pending",
                        "content_a": content_a[:80],
                        "content_b": content_b[:80],
                    })
                    existing_pairs.add(pair_key)

    # Cap review queue
    pending = [item for item in review_queue if item.get("status") == "pending"]
    if len(pending) > REVIEW_QUEUE_MAX:
        pending.sort(key=lambda x: x.get("flagged_at", ""))
        for item in pending[:len(pending) - REVIEW_QUEUE_MAX]:
            item["status"] = "dropped"

    state["consolidation_review_queue"] = review_queue
    state["stats"]["last_consolidation"] = datetime.now().isoformat()
    save_state(state)

    if merged > 0:
        log.info("Consolidation complete: %d auto-merged", merged)
    return merged


if __name__ == "__main__":
    mem_dir = _get_memory_dir()
    if not mem_dir:
        print("ERROR: Could not detect memory directory.")
        sys.exit(1)
    count = run_consolidation(mem_dir)
    print(f"Consolidation: {count} memories merged")
