#!/usr/bin/env python3
"""
extract.py — Strategic Memory extraction engine.
Takes conversation text, sends to Haiku for structured memory extraction,
writes markdown files to vault, calls consolidation and state recompute.

Usage:
  echo "conversation text" | python3 extract.py
  python3 extract.py --file /path/to/conversation.txt
  python3 extract.py --text "inline conversation text"
"""

import hashlib
import json
import os
import re
import sys
from datetime import datetime

_this_dir = os.path.dirname(os.path.abspath(__file__))
if _this_dir not in sys.path:
    sys.path.insert(0, _this_dir)

from state import (
    _get_memory_dir, scan_memories, parse_frontmatter,
    recompute_state, log
)

# Also need brain_config for API key
_ie_dir = os.path.join(os.path.expanduser("~/.claude/skills/intelligence-engine"))
for p in [_ie_dir, os.path.join(_ie_dir, "brain")]:
    if p not in sys.path:
        sys.path.insert(0, p)

try:
    import brain_config
except ImportError:
    brain_config = None

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
EXTRACTION_MODEL = "claude-haiku-4-5-20251001"  # Haiku 4.5 — verify against Anthropic docs if API returns 400
EXTRACTION_MAX_TOKENS = 2048
MAX_INPUT_CHARS = 20000
CONFIDENCE_THRESHOLD = 0.8

# ---------------------------------------------------------------------------
# Extraction prompt (refined from prototype testing)
# ---------------------------------------------------------------------------
EXTRACTION_PROMPT = """You are a business owner's chief of staff with perfect judgment about what matters. Read this conversation and extract ONLY memories that pass this test:

"If the owner came back in 2 weeks with a completely fresh AI session and this information was gone, would it cause real harm — a missed commitment, a reversed decision, a lost insight that took real work to derive?"

If the answer is "they could re-derive it from the codebase, calendar, or git history" — DO NOT extract it. If it's a completed action — DO NOT extract it (it's done, not a memory). If it's a calendar event — DO NOT extract it (the calendar handles that).

Memory types:
- DECISION: A choice that CHANGES how the business operates going forward. Not "decided to delete a file" but "decided to switch from weekly to daily standups."
- COMMITMENT: Owner PERSONALLY promised to do something for a SPECIFIC person that hasn't been done yet. Already-completed commitments are NOT memories.
- PREFERENCE: How the owner wants things done, permanently. "I don't take meetings before 10am."
- INSIGHT: A pattern or observation that required real analysis to reach and would be expensive to re-derive. Not state descriptions ("we have 53 tools") but conclusions ("we consistently avoid sales conversations").
- CORRECTION: Owner explicitly contradicted something the system believed.

Return a JSON array. Each object must have:
- "type": one of the above (lowercase)
- "content": standalone sentence, max 200 chars. Include names, URLs, specifics. Not "user found a repo" but "Found danielmiessler/PAI on GitHub — adapted PI and Extract Wisdom skills"
- "reasoning": why this matters, max 200 chars
- "confidence": 0.8-1.0 ONLY. If below 0.8, don't include it.
- "tags": 2-5 lowercase keyword tags
- "person": name of person involved (for commitments only, otherwise null)

NEVER extract:
- Technical implementation details (file paths, function names, build configs)
- The AI assistant's own plans or commitments ("I will save this", "I should check X")
- Current state observations ("dashboard shows 25 items", "we have 53 tools")
- Things obvious from reading the code or git history
- Conversation mechanics ("user asked about X")
- Progress updates ("Phase 3 complete", "build succeeded")
- Preferences about how the AI assistant should behave (those belong in CLAUDE.md)
- Completed actions that are already done
- Calendar events or scheduled meetings

ALWAYS extract:
- Decisions that reverse or change previous direction
- Commitments to real humans that haven't been fulfilled
- The reasoning behind non-obvious decisions (the WHY that would be lost)
- Patterns that took weeks of data to notice

Return ONLY the JSON array. If nothing worth extracting, return []. Returning [] is the CORRECT answer for most conversation chunks."""


# ---------------------------------------------------------------------------
# Memory file creation
# ---------------------------------------------------------------------------
def _slugify(text, max_len=40):
    """Create a filename-safe slug from text."""
    slug = re.sub(r'[^a-z0-9]+', '-', text.lower().strip())
    slug = slug.strip('-')
    slug = slug[:max_len].rstrip('-')
    return slug if slug else "memory"


def _content_hash(text):
    """SHA-256 of normalized content for dedup."""
    normalized = re.sub(r'\s+', ' ', text.strip().lower())
    return hashlib.sha256(normalized.encode('utf-8')).hexdigest()


def _existing_hashes(memory_dir):
    """Collect content hashes from all existing memory files."""
    hashes = set()
    for fpath, fm in scan_memories(memory_dir):
        h = fm.get("_content_hash", "")
        if h:
            hashes.add(h)
        # Also hash the content field for fallback dedup
        content = fm.get("content", "")
        if content:
            hashes.add(_content_hash(content))
    return hashes


def _next_id(memory_dir):
    """Generate next memory ID: mem_YYYYMMDD_NNN."""
    today = datetime.now().strftime("%Y%m%d")
    existing = []
    for fpath, fm in scan_memories(memory_dir):
        mid = fm.get("id", "")
        if mid.startswith(f"mem_{today}_"):
            try:
                num = int(mid.split("_")[2])
                existing.append(num)
            except (IndexError, ValueError):
                pass
    next_num = max(existing) + 1 if existing else 1
    return f"mem_{today}_{next_num:03d}"


def _type_to_dir(mem_type):
    """Map memory type to subfolder name."""
    mapping = {
        "decision": "decisions",
        "commitment": "commitments",
        "preference": "preferences",
        "insight": "insights",
        "person": "people",
        "correction": "corrections",
    }
    return mapping.get(mem_type, "insights")


def write_memory_file(memory_dir, mem_id, unit):
    """Write a single memory as a markdown file with YAML frontmatter."""
    mem_type = unit.get("type", "insight")
    type_dir = os.path.join(memory_dir, _type_to_dir(mem_type))
    os.makedirs(type_dir, exist_ok=True)

    content = unit.get("content", "").replace("\n", " ").replace("\r", " ").replace("---", "—").strip()
    reasoning = unit.get("reasoning", "").replace("\n", " ").replace("\r", " ").replace("---", "—").strip()
    slug = _slugify(content)
    filename = f"{mem_id}_{slug}.md"
    filepath = os.path.join(type_dir, filename)

    now = datetime.now().isoformat()
    tags = unit.get("tags", [])
    if isinstance(tags, str):
        tags = [tags]

    frontmatter = f"""---
id: {mem_id}
type: {mem_type}
content: "{content.replace('"', "'")}"
reasoning: "{reasoning.replace('"', "'")}"
confidence: {unit.get('confidence', 0.8)}
tags: [{', '.join(tags)}]
valid_from: {datetime.now().strftime('%Y-%m-%d')}
valid_until: null
source_session: "{unit.get('source_session', 'unknown')}"
source_context: "{unit.get('source_context', '').replace('"', "'")}"
created: {now}
last_accessed: {now}
access_count: 0
decay_score: 1.0
status: active
superseded_by: null
person: {unit.get('person') or 'null'}
_content_hash: {_content_hash(content)}
---

{content}

**Why this matters:** {unit.get('reasoning', '')}
"""

    try:
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(frontmatter)
        log.info("Wrote memory %s: [%s] %s", mem_id, mem_type, content[:80])
        return filepath
    except (IOError, OSError) as e:
        log.error("Failed to write memory file %s: %s", filepath, e)
        return None


# ---------------------------------------------------------------------------
# Extraction
# ---------------------------------------------------------------------------
def extract_memories(text, source_session="unknown"):
    """Send text to Haiku, extract structured memories. Returns list of dicts."""
    if not text or len(text.strip()) < 50:
        return []

    # Truncate from beginning if too long (keep recent context)
    if len(text) > MAX_INPUT_CHARS:
        text = text[-MAX_INPUT_CHARS:]

    if not brain_config:
        log.error("brain_config not available — cannot call Haiku API")
        return []

    try:
        api_key = brain_config.get_anthropic_key()
    except RuntimeError as e:
        log.error("API key not found: %s", e)
        return []

    try:
        import anthropic
        client = anthropic.Anthropic(api_key=api_key)

        prompt = f"{EXTRACTION_PROMPT}\n\n--- CONVERSATION ---\n{text}"

        response = client.messages.create(
            model=EXTRACTION_MODEL,
            max_tokens=EXTRACTION_MAX_TOKENS,
            messages=[{"role": "user", "content": prompt}],
        )

        response_text = response.content[0].text if response.content else "[]"

        # Handle markdown code fences
        if "```" in response_text:
            match = re.search(r'```(?:json)?\s*\n?(.*?)\n?```', response_text, re.DOTALL)
            if match:
                response_text = match.group(1)

        memories = json.loads(response_text.strip())
        if not isinstance(memories, list):
            memories = []

        # Filter by confidence
        results = []
        for mem in memories:
            if not isinstance(mem, dict):
                continue
            confidence = mem.get("confidence", 0.5)
            if isinstance(confidence, str):
                try:
                    confidence = float(confidence)
                except ValueError:
                    confidence = 0.5
            if confidence < CONFIDENCE_THRESHOLD:
                continue

            mem_type = mem.get("type", "insight").lower()
            if mem_type not in ["decision", "commitment", "preference", "insight", "correction", "person"]:
                mem_type = "insight"

            results.append({
                "type": mem_type,
                "content": str(mem.get("content", ""))[:200],
                "reasoning": str(mem.get("reasoning", ""))[:200],
                "confidence": confidence,
                "tags": (mem.get("tags", []) or [])[:5],
                "person": mem.get("person"),
                "source_session": source_session,
                "source_context": f"Extracted at session end",
            })

        log.info("Extraction: %d memories from %d chars of conversation", len(results), len(text))
        return results

    except json.JSONDecodeError as e:
        log.warning("Failed to parse extraction response: %s", e)
        _write_error_flag("JSON parse error in extraction response")
        return []
    except Exception as e:
        log.error("Extraction API error: %s", e)
        _write_error_flag(str(e))
        return []


def _write_error_flag(error_msg):
    """Write a sentinel file so briefing.py can surface extraction failures."""
    flag_path = os.path.expanduser("~/.claude/logs/strategic-memory-error-flag")
    try:
        os.makedirs(os.path.dirname(flag_path), exist_ok=True)
        with open(flag_path, "w") as f:
            f.write(f"{datetime.now().isoformat()}: {error_msg}\n")
    except (IOError, OSError):
        pass


def run_extraction(text, source_session="unknown"):
    """Full extraction pipeline: extract → dedup → write → consolidate → recompute state."""
    memory_dir = _get_memory_dir()
    if not memory_dir:
        log.error("No memory directory — is Day 6 setup complete?")
        return []

    # Extract
    memories = extract_memories(text, source_session)
    if not memories:
        log.info("No memories extracted from this conversation")
        return []

    # Dedup against existing
    existing = _existing_hashes(memory_dir)
    written = []

    for unit in memories:
        c_hash = _content_hash(unit.get("content", ""))
        if c_hash in existing:
            log.debug("Duplicate skipped: %s", unit.get("content", "")[:60])
            continue

        mem_id = _next_id(memory_dir)
        filepath = write_memory_file(memory_dir, mem_id, unit)
        if filepath:
            written.append(filepath)
            existing.add(c_hash)

    if not written:
        log.info("All extracted memories were duplicates")
        return []

    # Run consolidation
    try:
        from consolidate import run_consolidation
        run_consolidation(memory_dir)
    except ImportError:
        log.warning("consolidate.py not found — skipping consolidation")
    except Exception as e:
        log.warning("Consolidation failed: %s", e)

    # Recompute state
    try:
        recompute_state(memory_dir)
    except Exception as e:
        log.warning("State recompute failed: %s", e)

    # Upsert to Pinecone (Phase 3)
    try:
        from pinecone_integration import upsert_memories
        upsert_memories(memory_dir, written)
    except ImportError:
        pass  # Pinecone integration not installed yet — silent skip
    except Exception as e:
        log.warning("Pinecone upsert failed (non-fatal): %s", e)

    # Update last_extraction timestamp
    try:
        from state import load_state, save_state
        st = load_state()
        st["stats"]["last_extraction"] = datetime.now().isoformat()
        save_state(st)
    except Exception:
        pass

    log.info("Extraction complete: %d new memories written", len(written))
    return written


# ---------------------------------------------------------------------------
# Correction / Temporal Validity (Phase 2)
# ---------------------------------------------------------------------------
def correct_memory(memory_dir, target_id=None, target_content=None,
                   correction_text="", new_value=None, source_session="unknown"):
    """Invalidate an existing memory and optionally create a replacement.

    Graphiti pattern: old memory gets valid_until + status=superseded.
    If new_value provided, a new memory is created with valid_from = today.

    Args:
        memory_dir: vault memory directory
        target_id: memory ID to correct (e.g., "mem_20260408_001")
        target_content: fuzzy content match if ID not known
        correction_text: what the user said ("I already did that" / "that changed to X")
        new_value: replacement content (if the decision/commitment changed, not just completed)
        source_session: session ID for provenance

    Returns: dict with 'invalidated' (filepath or None) and 'replacement' (filepath or None)
    """
    from state import write_frontmatter_field

    result = {"invalidated": None, "replacement": None}

    # Find target memory
    target_path = None
    target_fm = None

    for fpath, fm in scan_memories(memory_dir):
        if fm.get("status") != "active":
            continue
        if target_id and fm.get("id") == target_id:
            target_path = fpath
            target_fm = fm
            break
        if target_content:
            # Fuzzy match: check if target_content words overlap significantly
            content = fm.get("content", "").lower()
            query_words = set(target_content.lower().split())
            content_words = set(content.split())
            if query_words and content_words:
                overlap = len(query_words & content_words) / len(query_words)
                if overlap >= 0.6:
                    target_path = fpath
                    target_fm = fm
                    break

    if not target_path:
        log.warning("Correction target not found: id=%s content=%s",
                    target_id, target_content)
        # Still create the correction memory as standalone
        correction_unit = {
            "type": "correction",
            "content": correction_text[:200],
            "reasoning": f"Target not found — manual review needed. Searched for: {target_id or target_content}",
            "confidence": 0.8,
            "tags": ["correction", "unmatched"],
            "person": None,
            "source_session": source_session,
            "source_context": "Correction with no matched target",
        }
        mem_id = _next_id(memory_dir)
        filepath = write_memory_file(memory_dir, mem_id, correction_unit)
        result["replacement"] = filepath
        return result

    # Invalidate the target (Graphiti pattern)
    today = datetime.now().strftime("%Y-%m-%d")
    write_frontmatter_field(target_path, "valid_until", today)
    write_frontmatter_field(target_path, "status", "superseded")
    result["invalidated"] = target_path
    log.info("Invalidated memory %s: %s", target_fm.get("id"), target_fm.get("content", "")[:60])

    # Create replacement if new value provided
    if new_value:
        replacement_unit = {
            "type": target_fm.get("type", "decision"),
            "content": new_value[:200],
            "reasoning": f"Replaces {target_fm.get('id')}: {correction_text[:100]}",
            "confidence": target_fm.get("confidence", 0.8),
            "tags": target_fm.get("tags", []),
            "person": target_fm.get("person"),
            "source_session": source_session,
            "source_context": f"Correction of {target_fm.get('id')}",
        }
        new_id = _next_id(memory_dir)
        new_path = write_memory_file(memory_dir, new_id, replacement_unit)
        if new_path:
            write_frontmatter_field(target_path, "superseded_by", new_id)
            result["replacement"] = new_path
            log.info("Created replacement %s for %s", new_id, target_fm.get("id"))
    else:
        # Just a completion correction ("I already did that")
        correction_unit = {
            "type": "correction",
            "content": f"Resolved: {target_fm.get('content', '')}. {correction_text}",
            "reasoning": f"Owner confirmed completion of {target_fm.get('id')}",
            "confidence": 0.9,
            "tags": ["correction", "resolved"],
            "person": target_fm.get("person"),
            "source_session": source_session,
            "source_context": f"Completion correction for {target_fm.get('id')}",
        }
        corr_id = _next_id(memory_dir)
        corr_path = write_memory_file(memory_dir, corr_id, correction_unit)
        result["replacement"] = corr_path

    # Recompute state after correction
    try:
        recompute_state(memory_dir)
    except Exception as e:
        log.warning("State recompute after correction failed: %s", e)

    return result


# ---------------------------------------------------------------------------
# Session JSONL reading (for Stop hook)
# ---------------------------------------------------------------------------
def read_session_jsonl(filepath):
    """Read a Claude Code session .jsonl file and extract user/assistant messages."""
    messages = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue

                msg_type = entry.get("type", "")
                if msg_type in ("user", "human"):
                    content = entry.get("message", {}).get("content", "")
                    if isinstance(content, str) and content.strip():
                        messages.append(f"USER: {content.strip()}")
                    elif isinstance(content, list):
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "text":
                                text = block.get("text", "").strip()
                                if text:
                                    messages.append(f"USER: {text}")
                elif msg_type in ("assistant", "ai"):
                    content = entry.get("message", {}).get("content", "")
                    if isinstance(content, str) and content.strip():
                        messages.append(f"ASSISTANT: {content.strip()[:500]}")
                    elif isinstance(content, list):
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "text":
                                text = block.get("text", "").strip()[:500]
                                if text:
                                    messages.append(f"ASSISTANT: {text}")
    except (IOError, OSError) as e:
        log.error("Failed to read session file %s: %s", filepath, e)
        return ""

    return "\n\n".join(messages)


def find_session_file(session_id):
    """Find the .jsonl file for a session ID across project directories.
    Limits to 2 levels deep to avoid slow traversal on large machines."""
    projects_dir = os.path.expanduser("~/.claude/projects")
    if not os.path.isdir(projects_dir):
        return None

    target = f"{session_id}.jsonl"
    # Level 1: direct children of projects/
    for entry in os.listdir(projects_dir):
        subdir = os.path.join(projects_dir, entry)
        if not os.path.isdir(subdir):
            continue
        # Level 2: files inside each project directory
        candidate = os.path.join(subdir, target)
        if os.path.exists(candidate):
            return candidate
        # Also check one level deeper (some projects nest)
        for sub_entry in os.listdir(subdir):
            sub_sub = os.path.join(subdir, sub_entry)
            if os.path.isdir(sub_sub):
                deep_candidate = os.path.join(sub_sub, target)
                if os.path.exists(deep_candidate):
                    return deep_candidate
    return None


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse
    import select

    parser = argparse.ArgumentParser(description="Strategic Memory extraction engine")
    parser.add_argument("--file", help="Path to conversation text file or .jsonl")
    parser.add_argument("--text", help="Inline conversation text")
    parser.add_argument("--hook", action="store_true",
                        help="Running as Stop hook — read session_id from stdin JSON")
    args = parser.parse_args()

    conversation = ""
    session_id = "unknown"

    if args.hook:
        # Stop hook mode: read session_id from stdin JSON, find .jsonl, extract
        try:
            if select.select([sys.stdin], [], [], 1.0)[0]:
                hook_data = json.load(sys.stdin)
                session_id = hook_data.get("session_id", "unknown")
        except Exception:
            pass

        if session_id != "unknown":
            jsonl_path = find_session_file(session_id)
            if jsonl_path:
                conversation = read_session_jsonl(jsonl_path)
                log.info("Read session %s from %s (%d chars)",
                         session_id, jsonl_path, len(conversation))
            else:
                log.warning("Session file not found for %s", session_id)
        else:
            log.warning("No session_id in hook stdin")

    elif args.file:
        filepath = args.file
        if not os.path.exists(filepath):
            log.error("File not found: %s", filepath)
            sys.exit(0)
        try:
            if filepath.endswith(".jsonl"):
                conversation = read_session_jsonl(filepath)
            else:
                with open(filepath, "r", encoding="utf-8") as f:
                    conversation = f.read()
        except (IOError, OSError) as e:
            log.error("Failed to read file %s: %s", filepath, e)
            sys.exit(0)
        session_id = os.path.basename(filepath).replace(".jsonl", "").replace(".txt", "").replace(".md", "")

    elif args.text:
        conversation = args.text

    elif not sys.stdin.isatty():
        conversation = sys.stdin.read()

    else:
        print("Usage: python3 extract.py --hook  (Stop hook mode)")
        print("       python3 extract.py --file conversation.jsonl")
        print("       python3 extract.py --text 'conversation text'")
        print("       echo 'text' | python3 extract.py")
        sys.exit(0)

    if not conversation.strip():
        log.info("Empty conversation — nothing to extract")
        sys.exit(0)

    written = run_extraction(conversation, source_session=session_id)
    if written:
        for fp in written:
            log.info("  Written: %s", fp)
    sys.exit(0)
