---
name: strategic-memory
description: "Fully autonomous persistent business memory system for Claude Code. Captures decisions, commitments, preferences, and insights mechanically via hooks. Commands: /memory setup (one-time install), /memory briefing, /memory search [query], /memory status. After setup, everything runs autonomously — commands are optional manual overrides. NOT for casual note-taking, one-off reminders, or personal journal entries."
version: 2.0.0
tags: [memory, intelligence, persistence, briefing, force-multiplier]
---

# Strategic Memory

## Purpose

Persistent memory that captures your business decisions, commitments, preferences, and insights across Claude Code sessions. Memories are stored as markdown files in your Obsidian vault — browseable, searchable, and growing.

**Problem it solves:** Every Claude Code session starts cold. Decisions from last week are forgotten. Commitments vanish. Strategic Memory fixes this by capturing important information mechanically and briefing you at every session start.

**What "done" looks like after setup:**
- Hooks in settings.json capture memories at session end
- BRIEFING.md generates at every session start
- Memory files appear in your vault under `00 Intelligence Engine/memory/`
- You can browse decisions, commitments, preferences, and insights in Obsidian

**Non-goals:**
- NOT a calendar replacement — calendar events belong in your calendar, not memory
- NOT for technical implementation details — file paths, function names, and build configs are in the code, not memory
- NOT for cross-machine sync — memories live in the vault, synced by your existing vault sync (Syncthing, iCloud, etc.)
- NOT for AI assistant behavior preferences — those belong in CLAUDE.md

---

## Triggers

**Should fire:**
- "/memory setup" — first-time installation (the ONLY required command)
- "/memory status" — system health check (manual escape hatch)
- "set up strategic memory" — natural language setup request

**Should NOT fire:**
- "remember to buy milk" — personal reminder, not business memory
- "save this code snippet" — technical detail, not a memory
- "add this to my notes" — general note-taking, not Strategic Memory

**Bare `/memory` (no subcommand):** Show that setup is the only required command, everything else is autonomous.

**Note:** Corrections, search, review, and briefing are ALL autonomous — handled by CLAUDE.md instructions and hooks. No slash commands needed. The user just talks naturally.

---

## Commands

### /memory setup
First-time installation. Run once after installing the package.

**Windows users:** The bash commands below work in WSL, Git Bash, or any bash-compatible shell. If using native PowerShell/CMD, use the `install.ps1` script instead for file installation, then run `/memory setup` in Claude Code (Claude handles the shell differences).

**Steps the agent MUST follow in order:**

1. **Verify prerequisites:**
   ```bash
   python3 << 'PYEOF'
   import sys, os
   sys.path.insert(0, os.path.expanduser("~/.claude/skills/intelligence-engine"))
   sys.path.insert(0, os.path.expanduser("~/.claude/skills/intelligence-engine/brain"))
   import brain_config
   print(f"brain_config: OK, vault: {brain_config.ACTIVE_VAULT}")
   PYEOF
   ```
   If this fails: STOP. Tell user to complete Day 6 setup first (run `/setup-brain`).

2. **Verify Python + anthropic:**
   ```bash
   python3 -c "import anthropic; print('anthropic: OK')"
   ```
   If this fails: tell user to run `pip3 install anthropic`.

3. **Create vault folder structure:**
   ```bash
   VAULT_PATH=$(python3 << 'PYEOF'
   import sys, os
   sys.path.insert(0, os.path.expanduser("~/.claude/skills/intelligence-engine"))
   sys.path.insert(0, os.path.expanduser("~/.claude/skills/intelligence-engine/brain"))
   import brain_config
   print(brain_config.ACTIVE_VAULT)
   PYEOF
   )
   for dir in decisions commitments preferences insights people corrections _archive; do
     mkdir -p "$VAULT_PATH/00 Intelligence Engine/memory/$dir"
   done
   ```

4. **Initialize state.json** (if it doesn't exist):
   ```bash
   python3 ~/.claude/skills/strategic-memory/engine/state.py
   ```

5. **Write hooks to settings.json:**
   MUST back up settings.json FIRST: `cp ~/.claude/settings.json ~/.claude/settings.json.bak`
   Then read `~/.claude/settings.json`. Add these hooks if not already present (preserve existing hooks).
   After writing, verify the result parses as valid JSON: `python3 -c "import json, os; json.load(open(os.path.expanduser('~/.claude/settings.json')))"` — if it fails, restore from .bak immediately.

   ```json
   {
     "hooks": {
       "SessionStart": [
         {
           "type": "command",
           "command": "python3 ~/.claude/skills/strategic-memory/engine/briefing.py 2>>~/.claude/logs/strategic-memory.log || true",
           "timeout": 10000
         }
       ],
       "Stop": [
         {
           "type": "command",
           "command": "python3 ~/.claude/skills/strategic-memory/engine/extract.py --hook 2>>~/.claude/logs/strategic-memory.log || true",
           "timeout": 30000
         }
       ]
     }
   }
   ```

   **CRITICAL:** Do NOT overwrite existing hooks. MERGE with existing hook arrays. If SessionStart or Stop already has hooks, APPEND these entries.

6. **Add CLAUDE.md instruction block** (if not already present):
   Append to the user's project-level or global CLAUDE.md:

   Append the following text EXACTLY to the user's CLAUDE.md. Do NOT wrap in a code fence — append as raw markdown. MUST check `grep -q "Strategic Memory — Active" ~/.claude/CLAUDE.md` first — if found, SKIP (already present).

   ---BEGIN BLOCK (append everything below this line)---

   ## Strategic Memory — Active (Fully Autonomous)

   ### Session Start
   MUST read the file at `00 Intelligence Engine/data/BRIEFING.md` in your vault at the start of every session. MUST surface any attention-required items (overdue commitments, stale decisions) to the user immediately.

   MUST run this review check at session start:

       python3 -c "import sys, os; sys.path.insert(0, os.path.expanduser('~/.claude/skills/strategic-memory/engine')); from state import get_review_items, _get_memory_dir; items = get_review_items(_get_memory_dir()); print(f'{items[\"total_attention_items\"]} items need attention') if items['total_attention_items'] > 0 else None"

   If items need attention, surface them naturally: "You have 2 overdue commitments..."

   ### During Session — Autonomous Capture
   You MUST ALWAYS watch for these memory types during every conversation:
   - DECISION: Owner makes a choice that changes how the business operates going forward
   - COMMITMENT: Owner personally promises to do something for a specific person
   - PREFERENCE: Owner states how they want things done permanently
   - INSIGHT: A pattern or observation that required real analysis and would be expensive to re-derive

   When you detect one with HIGH confidence (you are certain this is a real decision/commitment, not exploratory thinking), MUST capture it immediately:

       python3 ~/.claude/skills/strategic-memory/engine/extract.py --text "USER: [what user said] ASSISTANT: [relevant context]" 2>>~/.claude/logs/strategic-memory.log

   Then confirm in one sentence: "Captured [type]: [summary]"

   When confidence is MEDIUM (sounds like it could be a decision but the owner is thinking out loud), DO NOT capture. Wait for the owner to confirm or revisit.

   When confidence is LOW (routine conversation, no decisions being made), DO NOT capture. Most conversation produces zero captures — that is correct behavior.

   NEVER capture: completed actions, calendar events, technical implementation details, things derivable from code/git, AI behavior preferences.

   ### During Session — Autonomous Corrections
   When the owner says "I already did that", "that changed", "that's not right anymore", "we decided differently" — MUST handle the correction immediately:

       python3 -c "import sys, os; sys.path.insert(0, os.path.expanduser('~/.claude/skills/strategic-memory/engine')); from extract import correct_memory; from state import _get_memory_dir; result = correct_memory(memory_dir=_get_memory_dir(), target_content='THE_CONTENT_BEING_CORRECTED', correction_text='WHAT_THE_OWNER_SAID', new_value='NEW_VALUE_OR_NONE')"

   After running, check the result:
   - If result['invalidated'] is not None: confirm "Updated — marked the old memory as superseded and created the replacement."
   - If result['invalidated'] is None: say "I couldn't find a matching memory to correct. I've logged the correction for manual review."

   ### During Session — Autonomous Search
   When the owner asks "what did I decide about X?" or "do I have any commitments about Y?" — MUST search memories:

       python3 ~/.claude/skills/strategic-memory/engine/pinecone_integration.py --search "[query]"

   If Pinecone returns nothing or is not configured, fall back to keyword search:

       python3 -c "import sys, os; sys.path.insert(0, os.path.expanduser('~/.claude/skills/strategic-memory/engine')); from state import search_memories, _get_memory_dir; results = search_memories('[query]', _get_memory_dir()); [print(f'[{r[\"type\"]}] {r[\"content\"]} (score: {r[\"score\"]})') for r in results]"

   Present the top 3-5 results conversationally. If zero results: "No memories match that query. I searched [N] active memories."

   ### Session End
   The Stop hook runs extract.py automatically as a final sweep. No action needed — this is mechanical.

   ---END BLOCK---

7. **Generate initial BRIEFING.md:**
   ```bash
   python3 ~/.claude/skills/strategic-memory/engine/briefing.py
   ```

8. **Run verification:**
   ```bash
   python3 ~/.claude/skills/strategic-memory/engine/verify.py
   ```

Report results of each step. If all pass: "Strategic Memory installed. Your next session will start with a briefing."

### /memory briefing
Regenerate BRIEFING.md on demand. Run:
```bash
python3 ~/.claude/skills/strategic-memory/engine/briefing.py
```
Then read and present the BRIEFING.md content to the user.

### /memory search [query]
Search memories using semantic search (Pinecone) with keyword fallback. Tries Pinecone first for meaning-based results. Falls back to keyword matching if Pinecone is not configured.

```bash
# Semantic search (if Pinecone available)
python3 ~/.claude/skills/strategic-memory/engine/pinecone_integration.py --search "[query]"
```

If Pinecone returns no results or is unavailable, fall back to keyword search by reading memory files and matching against frontmatter tags + content.

**Success:** At least 1 result returned with score > 0. If 0 results, report "No memories match '[query]' — [N] files scanned. Pinecone: [connected/not configured]."

**Output format per result:**
```
[decision] Switch to daily standups (score: 0.92, confidence: 0.92, decay: 0.87)
  Created: 2026-04-01 | Tags: process, team
  "Weekly standups miss too many blockers — switching to daily."
```

### /memory status (manual override)
Read state.json and report system health.

**Output format:**
```
Strategic Memory Status
━━━━━━━━━━━━━━━━━━━━━━
Memories: 47 active, 12 archived
  Decisions:   15 (3 stale)
  Commitments: 8 (2 overdue)
  Preferences: 9
  Insights:    12
  People:      2
  Corrections: 1

Last briefing:      2026-04-08 @ 09:15 AM
Last extraction:    2026-04-08 @ 08:45 AM
Last consolidation: 2026-04-07 @ 11:30 PM
Last decay run:     2026-04-08 @ 09:15 AM

Hooks: SessionStart ✓  Stop ✓
Vault: ✓ (47 files in memory/)
Warnings: 2 commitments overdue (14+ days)
```

Check that hooks exist in settings.json. Check that memory folder exists.

---

## Before You Respond

Before executing ANY /memory command, verify:

1. **Check hooks exist** — `grep -l "strategic-memory" ~/.claude/settings.json` should match. If not, suggest `/memory setup`.
2. **Check vault path** — memory folder must exist at `<vault>/00 Intelligence Engine/memory/`. If not, suggest `/memory setup`.
3. **Check state.json** — must exist and parse as valid JSON. If corrupt, run `python3 ~/.claude/skills/strategic-memory/engine/state.py` to regenerate from memory files.
4. **For /memory search** — if no results found, check that memory files actually exist. Report count of files scanned.
5. **For /memory setup** — read existing settings.json BEFORE writing. Never clobber existing hooks. Merge, don't replace.

---

## Edge Cases

| Scenario | Expected Behavior |
|----------|------------------|
| Day 6 setup not complete (brain_config missing) | `/memory setup` detects at Step 1, stops with "Run /setup-brain first" |
| Hooks already exist in settings.json | MERGE — append Strategic Memory hooks to existing arrays. Never overwrite. |
| Vault path changes after setup | Hooks reference engine scripts (fixed path), but engine reads vault from brain_config (dynamic). Self-healing. |
| state.json corrupted | state.py restores from .bak. If both corrupt, regenerates from memory files (they are source of truth). |
| Extraction returns [] (no memories worth saving) | Normal. Most conversations produce zero extractions. Log and exit 0. |
| Student runs /memory setup twice | Idempotent — existing memories preserved, state.json not overwritten if valid, hooks updated if missing |
| Anthropic API key expired or invalid | extract.py logs error, exits 0. Memories from that session lost but system continues. Next session unaffected. |
| 500+ memory files (performance) | Briefing scans frontmatter only (fast). Decay runs on active files only. Archive moves dormant files out of active scan. |

---

## Anti-Patterns

| Pattern | Why It's Wrong | What To Do Instead |
|---------|---------------|-------------------|
| Overwriting settings.json with only Strategic Memory hooks | Destroys the user's existing hooks (safeguard, watchdog, etc.) | Read existing hooks, MERGE new entries into existing arrays |
| Deleting memory files to "clean up" | Violates Graphiti principle — invalidated data has historical value | Move to `_archive/` folder, set status=dormant |
| Running /memory setup on every session start | Setup is one-time. Repeated runs waste time and risk hook duplication. | Setup runs ONCE. Hooks handle ongoing capture mechanically. |
| Storing API keys or credentials in memory files | Security risk — memory files are plaintext in the vault | Credentials stay in `~/.claude/credentials/` only |
| Extracting completed actions as memories | "Deleted the handoff file" is done — not a memory | Only extract decisions, commitments, preferences, insights that affect the FUTURE |

---

## Invariant Rules

- **NEVER overwrite existing memory files** — append only, or update frontmatter fields
- **NEVER delete memory files** — archive (move to _archive/) instead
- **NEVER store credentials** in memory files or state.json
- **NEVER modify settings.json hooks without preserving existing hooks**
- **ALWAYS exit 0 from hook scripts** — never block Claude Code lifecycle
- **ALWAYS check state.json schema_version** — fail explicitly if version mismatch

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-04-08 | Phase 1: Core memory loop — extraction, state, briefing, dedup, hooks. |
| 2.0.0 | 2026-04-08 | Full release: temporal validity, corrections, review, Pinecone semantic search, fully autonomous CLAUDE.md block. All three phases merged into one release. |

## Upgrade Notes

**Fresh install:** Run installer, then `/memory setup`. Everything configures automatically.

**Existing v1.0.0 → v2.0.0:** Re-run installer (overwrites engine scripts), then `/memory setup` (updates hooks + CLAUDE.md block). Existing memory files are preserved. New features activate automatically. Run `python3 ~/.claude/skills/strategic-memory/engine/pinecone_integration.py --backfill` to index existing memories into Pinecone for semantic search.
