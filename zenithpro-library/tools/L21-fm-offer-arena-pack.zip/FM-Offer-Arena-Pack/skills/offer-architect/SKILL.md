---
name: offer-architect
description: >
  Structures irresistible offers using value stacking, risk reversal, bonus architecture,
  and price anchoring. Takes a core product or service and builds the complete offer
  around it -- what's included, how it's framed, what bonuses amplify perceived value,
  and how to position price against the cost of inaction. Use when asked to "build my
  offer", "structure my offer", "offer architecture", "stack my offer", "design an
  irresistible offer", "price my offer", or "create my offer stack".
  Do NOT use for: copywriting (use landing-page-copy or email-sequence-architect),
  competitive positioning (use demand-architect), or audience research
  (use psychographic-excavation).
version: 1.0.0
---

# Offer Architect

## What This Skill Does

Takes a product or service and constructs the complete offer architecture around it. The output is a structured offer document that any copywriter, sales page builder, or webinar presenter can use to present the offer compellingly.

An offer is NOT the product. The product is what you deliver. The offer is how you frame, stack, price, guarantee, and present the product so that buying feels like the only rational decision.

---

## Invariants

ALWAYS: Produce dollar-value estimates for every element in the offer stack.
ALWAYS: Include at least one risk reversal mechanism (guarantee, trial, or conditional).
ALWAYS: Anchor the price against a larger number before revealing the actual price.
ALWAYS: State the cost of inaction in specific, quantified terms.
ALWAYS: Test the offer against the "Would I be stupid NOT to buy this?" standard.
ALWAYS: Include a reason-why for every bonus (why it's included, why it matters).

NEVER: Fabricate testimonials, case studies, or specific revenue numbers.
NEVER: Use vague value language ("priceless," "invaluable," "transformational").
NEVER: Present bonuses without individual value justification.
NEVER: Skip the cost-of-inaction calculation.
NEVER: Use manipulative scarcity (fake countdown timers, fake limited spots) -- use real constraints only.

---

## Input Required

Ask the user to provide:

**Required:**
- Core product/service description (what it is, what it delivers)
- Price point (or desired price range)
- Target buyer (who this is for -- role, situation, pain)
- Primary transformation (the specific outcome buyers get)

**Strongly Recommended:**
- Current conversion rate (if they have one)
- Competitor pricing (what alternatives cost)
- Existing bonuses or inclusions (if any)
- Delivery format (course, coaching, done-for-you, SaaS, etc.)

**Optional:**
- Failed offer versions (what they tried before that did not convert)
- Customer objections they hear most often
- Timeline to results

---

## Execution Protocol

### Step 1 -- Core Value Proposition Lock

Define the core transformation in one sentence:
> "[Product] takes [specific person] from [current painful state] to [desired outcome] in [timeframe] by [mechanism]."

Every element in the offer stack must support, amplify, or accelerate this core transformation. If a bonus or element does not connect to this sentence, it does not belong in the offer.

### Step 2 -- Value Stack Construction

Build the offer stack in layers:

| Layer | Purpose | Example |
|-------|---------|---------|
| Core Product | The primary deliverable | The 8-week program, the software, the service |
| Accelerators | Speed up the result | Templates, swipe files, done-for-you setup |
| Risk Eliminators | Remove barriers to action | Guarantee, trial period, payment plan |
| Status Elevators | Make the buyer feel like an insider | Community access, private group, direct access |
| Urgency Drivers | Create a real reason to act now | Cohort start date, price increase, limited capacity |

For each element in the stack:
1. **Name it** -- Give it a specific, benefit-oriented name (not "Bonus 1")
2. **Value it** -- Assign a standalone dollar value with justification
3. **Connect it** -- Explain how it supports the core transformation
4. **Reason-why** -- State why you are including it (the reason-why doubles perceived value)

### Step 3 -- Price Architecture

Build the price presentation in this sequence:

1. **Anchor high:** What would it cost to solve this problem WITHOUT this offer? (Hiring a consultant, trial and error, lost revenue over 12 months)
2. **Stack the value:** Total the standalone values of every element
3. **Reveal the gap:** Show the distance between total value and actual price
4. **Cost of inaction:** Calculate what NOT buying costs per month/year in specific dollar terms
5. **Risk reversal:** Present the guarantee that absorbs the buyer's risk
6. **Payment structure:** If above $500, offer payment plan. State both options.

### Step 4 -- Objection Preemption Map

For each of the top 5 likely objections:

| Objection | Where It Lives in the Offer | How the Offer Answers It |
|-----------|---------------------------|-------------------------|
| "Too expensive" | Price architecture (Step 3) | Anchor + cost of inaction |
| "Won't work for me" | Risk eliminator (guarantee) | Specific, conditional guarantee |
| "I don't have time" | Accelerator bonus | Template/shortcut that compresses timeline |
| "I've tried this before" | Core mechanism | Explain what makes this approach different |
| "I need to think about it" | Urgency driver | Real deadline or capacity constraint |

### Step 5 -- The Offer Document

Produce the complete offer document in this format:

```
# [OFFER NAME]

## The Core Promise
[One sentence: who it's for, what they get, by when, through what mechanism]

## What's Included

### Core: [Product Name] — Value: $[X]
[Description + what it delivers]

### Accelerator: [Bonus Name] — Value: $[X]
[Description + why it's included + how it speeds results]

[Repeat for each element]

## Total Value: $[sum]
## Your Investment: $[price]
## You Save: $[difference]

## The Guarantee
[Specific, conditional guarantee with clear terms]

## The Cost of Waiting
[Quantified cost of inaction per month/quarter/year]

## Payment Options
[Full pay + payment plan if applicable]

## Who This Is For (And Who It's NOT For)
[Qualification criteria -- self-select in/out]
```

### Step 6 -- Offer Stress Test

Before delivering, run these checks:

1. **The Stupid Test:** If someone described this offer to a friend, would the friend say "You'd be stupid NOT to take that"? If no -- the value stack or guarantee is weak.
2. **The Swap Test:** Could a competitor copy this offer element-for-element? If yes -- the mechanism or positioning is not differentiated enough.
3. **The Objection Test:** For each of the top 5 objections, does the offer have a built-in answer? If any objection is unaddressed, add an element.
4. **The Math Test:** Does the ROI math work? Is the promised outcome worth at least 10x the price?
5. **The Urgency Test:** Is there a real reason to buy NOW vs. next month? If not, add one (cohort date, price increase, capacity).

Report results of all 5 tests. Fix any failures before delivering.

---

## Output Format

Deliver two documents:

1. **Offer Architecture Brief** -- The strategic document (Steps 1-5 above) showing the full reasoning, value justification, and stress test results. This is for the business owner.

2. **Offer Summary Card** -- A one-page summary suitable for handing to a copywriter, webinar presenter, or sales team. Contains: offer name, core promise, what's included with values, price, guarantee, and urgency driver. No strategy -- just the facts they need to present it.

---

## Rules

1. Every bonus must have a standalone dollar value AND a reason-why for its inclusion.
2. The guarantee must be specific and conditional -- not "satisfaction guaranteed" (meaningless) but "If you complete X and don't get Y, here's what happens."
3. Price anchoring must use real comparisons (cost of alternatives, cost of the problem) -- never invented numbers.
4. The offer must include at least one element from each of the 5 stack layers.
5. Urgency must be real. If there is no genuine deadline or constraint, say so and suggest creating one (cohort model, seasonal pricing, capacity limit).
6. Never present the price before the value case is complete.
