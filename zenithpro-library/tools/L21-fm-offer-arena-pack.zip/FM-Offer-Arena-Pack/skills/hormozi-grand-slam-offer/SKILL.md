---
name: hormozi-grand-slam-offer
description: >
  Transform any product or service into an irresistible offer using Hormozi's Value Equation.
  Use when: "build an offer," "create an irresistible offer," "grand slam offer," "hormozi offer,"
  "value equation," "make my offer irresistible," "why isn't my offer converting," or when a student
  needs to design an offer that makes saying no feel stupid. Complements offer-architect (structural)
  with Hormozi's constraint-optimization approach.
version: 1.0.0
author: Strategic Profits
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/hormozi-grand-slam-offer [offer-name]"
  called_by: [user, offer-arena]
  outputs_to: [project folder]
---

# Hormozi Grand Slam Offer

Designs offers using Alex Hormozi's Value Equation — the mathematical framework that makes offers so good people feel stupid saying no.

## THE VALUE EQUATION

```
VALUE = (Dream Outcome x Perceived Likelihood of Achievement) / (Time Delay x Effort & Sacrifice)
```

**To maximize value:** Increase the top (dream outcome, likelihood). Decrease the bottom (time, effort).

An offer is a Grand Slam when the value equation is so lopsided in the buyer's favor that price becomes irrelevant.

---

## LAYER 1: INVARIANTS

1. **Start with Dream Outcome, not product features.** The offer is built around what the buyer actually wants, not what you deliver.
2. **Score all 4 Value Equation components** before constructing the offer. No element skipped.
3. **Every offer element must move at least one Value Equation lever.** If a bonus doesn't increase likelihood, decrease time, or reduce effort — cut it.
4. **Price must be anchored against the Dream Outcome value**, not against competitor pricing.
5. **The "Stupid Test" must pass:** "Would I be stupid NOT to buy this?" If no → offer isn't done.
6. **Never fabricate** testimonials, case studies, or specific revenue numbers.
7. **Quantify the cost of inaction** in specific dollar terms per month/quarter.

---

## LAYER 2: QUALITY GUIDANCE

- Voice is direct, specific, no-BS. Hormozi doesn't hedge.
- Every element gets a dollar value with justification.
- Guarantees must be real and specific, not vague ("satisfaction guaranteed" is weak).
- Bonuses accelerate results or remove obstacles — never filler.
- The offer should feel like a "category of one" — not comparable to alternatives.

---

## INPUTS REQUIRED

**Required:**
- Core product/service description (what it is, what it delivers)
- Price point (or desired price range)
- Target buyer (who — role, situation, pain)
- Dream Outcome (the specific result buyers want in their own words)

**Strongly Recommended:**
- Current conversion rate (if they have one)
- Top 3 objections they hear
- Competitor pricing
- Timeline to results
- Delivery format (course, coaching, done-for-you, SaaS, etc.)

---

## EXECUTION PROTOCOL

### Step 1 — Define the Dream Outcome

Answer in the buyer's language (not yours):
- "What do they go to bed wanting?"
- "What would they pay almost anything to get?"
- "What specific, measurable result defines success?"

Write it as: "[Buyer] goes from [current painful state] to [dream outcome] in [timeframe]."

**Dollar-value the Dream Outcome:** What is this transformation worth to them annually? This becomes the price anchor.

---

### Step 2 — Audit the 4 Value Equation Levers

Score each lever 1-10 for the current offer:

| Lever | Current Score | Target | Gap |
|-------|-------------|--------|-----|
| **Dream Outcome** (how desirable is the result?) | /10 | 9+ | |
| **Perceived Likelihood** (how believable is achievement?) | /10 | 8+ | |
| **Time Delay** (how fast do they see results?) | /10 (lower = better) | 3 or less | |
| **Effort & Sacrifice** (how much work for them?) | /10 (lower = better) | 3 or less | |

**Calculate Value Score:** (Dream x Likelihood) / (Time x Effort) = ___

Target: Value Score > 10. Grand Slam territory: > 25.

---

### Step 3 — Engineer Each Lever

For each lever, identify specific mechanisms to improve the score:

**Increasing Dream Outcome:**
- Make the outcome more specific and measurable
- Add status/identity transformation (not just functional result)
- Include "beyond the obvious" benefits they haven't considered

**Increasing Perceived Likelihood:**
- Proof elements (testimonials, case studies, data)
- "Done-for-you" components that remove failure risk
- Conditional guarantees tied to specific actions
- Track record and credibility markers

**Decreasing Time Delay:**
- Quick wins in first 24-48 hours
- Accelerator tools (templates, swipe files, checklists)
- "Skip the line" mechanisms
- Phased results (small wins → medium wins → big wins)

**Decreasing Effort & Sacrifice:**
- Done-for-you vs. done-with-you vs. DIY continuum
- Templates and frameworks that eliminate blank-page problem
- Community/accountability that makes showing up easier
- Remove decisions they'd have to make themselves

---

### Step 4 — Build the Offer Stack

Layer the offer using Hormozi's stack structure:

| Layer | Purpose | Value Equation Lever | Element | Dollar Value |
|-------|---------|---------------------|---------|-------------|
| **Core Product** | Primary deliverable | Dream Outcome | [What it is] | $X |
| **Accelerator 1** | Speed up results | Time Delay ↓ | [Tool/template/shortcut] | $X |
| **Accelerator 2** | Speed up results | Time Delay ↓ | [Another speed mechanism] | $X |
| **Risk Eliminator 1** | Remove failure risk | Likelihood ↑ | [Guarantee/support/DFY element] | $X |
| **Risk Eliminator 2** | Remove effort | Effort ↓ | [Templates/done-for-you] | $X |
| **Status Elevator** | Identity upgrade | Dream Outcome ↑ | [Community/access/title] | $X |
| **Urgency Driver** | Real reason to act now | — | [Cohort/capacity/price] | — |

**Stack Rules:**
- Every element must connect to a Value Equation lever
- Every element needs a specific dollar value with justification
- The total stack value should be 10x-30x the asking price
- Bonuses should feel more valuable than the core product alone

---

### Step 5 — Price Architecture

Follow this sequence exactly:

1. **Anchor to Dream Outcome value:** "This transformation is worth $X/year to your business"
2. **Stack total value:** "The complete package is valued at $X" (sum of all elements)
3. **Reveal the gap:** "You're not paying $X. You're not even paying $Y."
4. **State the price:** "Your investment is $Z"
5. **Cost of inaction:** "Every month you don't have this, you're losing $X" (quantified)
6. **Payment options:** Full pay discount + payment plan
7. **Guarantee:** Specific, conditional, tied to action ("Do X, get Y, or we refund Z")

---

### Step 6 — Stress Test the Offer

Run all 5 tests:

| Test | Question | Pass Criteria |
|------|----------|---------------|
| **Stupid Test** | "Would I be stupid NOT to buy this?" | Instinctive "yes" |
| **Swap Test** | "Would the buyer trade their money for this result instantly?" | Clear yes — the offer feels like arbitrage |
| **Objection Test** | "Does the offer preempt the top 3 objections?" | Each objection has a specific counter-element |
| **Math Test** | "Does the ROI math work on paper?" | Clear positive ROI within stated timeframe |
| **Urgency Test** | "Is there a real, honest reason to buy now vs. later?" | Genuine constraint (not manufactured) |

**If any test fails:** Go back and fix before delivering.

---

### Step 7 — Re-score Value Equation

After offer construction, re-score:

| Lever | Before | After | Delta |
|-------|--------|-------|-------|
| Dream Outcome | /10 | /10 | +X |
| Perceived Likelihood | /10 | /10 | +X |
| Time Delay | /10 | /10 | -X |
| Effort & Sacrifice | /10 | /10 | -X |

**New Value Score:** (Dream x Likelihood) / (Time x Effort) = ___

Target improvement: 3x or better vs. starting score.

---

## OUTPUT FILES

### 1. `Grand-Slam-Offer-[Name].md`

```markdown
# Grand Slam Offer: [Offer Name]

## Dream Outcome
[Buyer's dream in their language]
Worth: $X/year to the buyer

## Value Equation Audit
| Lever | Score | Justification |
|-------|-------|---------------|
| Dream Outcome | X/10 | [Evidence] |
| Perceived Likelihood | X/10 | [Evidence] |
| Time Delay | X/10 | [Evidence] |
| Effort & Sacrifice | X/10 | [Evidence] |
**Value Score:** X

## Offer Stack
[Full stack table with dollar values]

## Price Architecture
- Dream Outcome value: $X
- Stack total: $X
- Asking price: $X
- Cost of inaction: $X/month
- Guarantee: [Specific terms]
- Payment options: [Full pay + plans]

## Stress Test Results
[All 5 tests with pass/fail and notes]

## Value Equation: Before vs. After
[Comparison table showing improvement]
```

### 2. `Offer-Summary-Card-[Name].md`

One-page summary a copywriter or presenter can use:
- Dream Outcome (1 sentence)
- Core offer (1 paragraph)
- Stack (bullet list with values)
- Price + guarantee
- Top 3 proof points
- Urgency mechanism

---

## QUALITY GATE

- [ ] Dream Outcome defined in buyer's language (not product language)
- [ ] All 4 Value Equation levers scored with evidence
- [ ] Every stack element connects to a specific lever
- [ ] Every element has a dollar value with justification
- [ ] Price anchored to Dream Outcome (not competitors)
- [ ] Cost of inaction quantified per month
- [ ] All 5 stress tests passed
- [ ] Value Score improved 3x+ from starting point
- [ ] No fabricated proof points
- [ ] Output files saved to disk
