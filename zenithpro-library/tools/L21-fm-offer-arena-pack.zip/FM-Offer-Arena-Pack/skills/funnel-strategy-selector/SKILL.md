---
name: funnel-strategy-selector
description: >
  Recommends the optimal funnel type (webinar, VSL, challenge, application, lead magnet, etc.)
  based on upstream research from demand-architect, offer-architect, and mimetic-market-intelligence.
  Scores 11 funnel types against 8 evidence-based decision factors, maps the recommended funnel
  stage-by-stage to belief gaps and proof layers, and produces a content requirements spec.
  Use when: "which funnel should I build", "what type of funnel", "funnel strategy", "webinar or
  challenge", "should I do a webinar", "funnel selection", "what's the best funnel for my offer",
  or after completing demand-architect and offer-architect.
version: 1.0.0
author: Strategic Profits
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/funnel-strategy-selector {mode} [offer-name]"
  modes: [full, quick, audit]
  called_by: [user]
  outputs_to: [project folder]
dependencies:
  - demand-architect
  - offer-architect
  - mimetic-market-intelligence
  - belief-gap-analyzer
  - core-concept-generator
expert_sources:
  - Russell Brunson (Value Ladder, funnel-to-price mapping)
  - Alex Hormozi (offer-first simplicity, 4-step framework)
  - Pedro Adao (challenge funnel selection criteria)
  - Frank Kern (evergreen hybrid, On-Demand Class)
  - Sam Ovens (sophistication escalation, webinar-to-application evolution)
  - Todd Brown (Big Idea > funnel type)
  - Jeff Walker (Product Launch Formula, launch sequencing)
  - Perry Belcher (tripwire entry, buyer identification)
  - Myron Golden (four levels of value, high-ticket strategy)
---

# Funnel Strategy Selector

Answers the question every student asks after completing their research: **"What type of funnel should I build?"**

This skill sits in the pipeline AFTER demand-architect and offer-architect have produced their outputs. It consumes the research evidence — desire hierarchy, belief gaps, core concepts, competitive landscape, offer architecture — and produces a scored recommendation for the optimal funnel type with a stage-by-stage blueprint.

The recommendation is evidence-based, not opinion-based. Every score cites the specific upstream document and data point it draws from.

---

## LAYER 1: INVARIANTS

These are hard constraints. Violating any one makes the output invalid.

1. **Score all 11 funnel types** against all decision factors before making a recommendation. Never skip types or pre-filter without evidence.
2. **Cite evidence from 3+ upstream documents** for every factor score. No score without a source.
3. **Price point must fall within the funnel type's proven range.** A $27 offer cannot be recommended for an application funnel. A $15K offer cannot be recommended for a direct sales page.
4. **Belief gap count must align to funnel length.** More gaps = longer funnel with more education stages. Never recommend a short funnel for 10+ belief gaps.
5. **Run the Simplicity Check (Step 0) before the full scorecard.** If the offer passes all stress tests AND belief gaps < 4, recommend the simplest viable funnel. Do not over-engineer.
6. **Competitor funnel convergence must inform differentiation.** If 80%+ of competitors use the same funnel type (e.g., everyone does webinars), flag this and weight alternative types higher.
7. **Single primary recommendation + one fallback.** Not a menu. Not "top 3." One clear answer with one backup in case constraints (budget, tech, timeline) make the primary impractical.

---

## LAYER 2: QUALITY GUIDANCE

- Voice is forensic analyst: specific evidence, direct declaratives, comparison tables. No consultant-speak.
- Every score must cite the exact upstream document and section it draws from.
- The Blueprint output must map belief gaps 1:1 to funnel stages.
- Content Requirements Spec must be actionable — specific asset types with purpose, not vague categories.
- Surface surprising recommendations with extra justification. If the data says "challenge" but the student expects "webinar," explain WHY with evidence.
- Never fabricate upstream data. If a document is missing, ask for it or note the gap.

---

## INPUTS REQUIRED

### From Upstream Skills (read these files):
- **demand-architect**: `Synthesis-02-Demand-Architecture-Brief.md` (Core Concept + USP), `Synthesis-03-Anti-Mimetic-Positioning-Statement.md`, `Step-08-Belief-Gap-Blueprint.md`
- **offer-architect**: `Offer Architecture Brief.md` (value stack, stress tests), `Offer Summary Card.md`
- **mimetic-market-intelligence**: `Doc 1 - Anti-Mimetic Differentiator Analysis.md` (convergence map)
- **belief-gap-analyzer**: `Belief-Gap-Analysis-[Market].md` (bridge sequence, evidence types)
- **core-concept-generator**: `Core-Concept-Candidates-[Market].md` (all 5 ranked)

### Ask the User (if not in upstream docs):
- **List size / audience**: "How large is your current email list or audience? (No list / Under 1K / 1K-10K / 10K+)"
- **Traffic temperature**: "Is your primary traffic cold (strangers), warm (know you but haven't bought), or hot (existing customers)?"
- **Budget / tech constraints**: "Any constraints on funnel complexity? (e.g., no sales team, limited tech, tight timeline)"
- **Delivery format** (if not in offer-architect): "How is your offer delivered? (Course / Coaching / Done-for-you / SaaS / Physical product)"

---

## MODES

### `full` — Complete Analysis (default)
Runs all steps. Produces all 3 output files: Scorecard, Blueprint, Content Spec.
Use when: starting from scratch, need the complete strategic picture.

### `quick` — Fast Recommendation
Extracts the 8 decision factors, runs Simplicity Check, produces a 1-page recommendation with primary + fallback funnel types and brief rationale.
Skips: full 11-type scorecard, detailed blueprint, content spec.
Use when: need a fast answer, will flesh out details later.

### `audit` — Grade Existing Choice
Takes the student's current funnel choice and grades it against the evidence.
Produces: pass/fail score with specific gaps, recommended adjustments.
Use when: student already picked a funnel type and wants validation.

---

## EXECUTION PROTOCOL

### Step 0 — Simplicity Check (Hormozi Gate)

Before scoring all 11 types, answer this question:

> "Is the offer strong enough that a simple 4-step funnel works?"
> (Attention → Lead Capture → VSL/Education → Conversion)

**Check these conditions:**
- Offer-architect stress tests: Did ALL 5 pass? (Stupid Test, Swap Test, Objection Test, Math Test, Urgency Test)
- Belief gap count: Are there fewer than 4 gaps?
- Core Concept strength: Did the primary Core Concept score A on all 4 quality tests?

**If ALL conditions are met:** Recommend the simplest viable funnel for the price point (Direct Sales Page for < $197, VSL for $197-$497, simple Webinar for $497+). Skip the full scorecard. Note: "Simplicity Check PASSED — your offer is strong enough that funnel complexity won't improve conversion. Build the simplest version first."

**If ANY condition fails:** Proceed to Step 1.

---

### Step 1 — Consume Upstream Documents

Read all available upstream files. Produce a consumption receipt:
- Documents read (with dates)
- Key data extracted per document
- Missing documents flagged

---

### Step 2 — Extract the 8 Decision Factors

For each factor, extract the specific evidence from the upstream documents:

| # | Factor | Source | What to Extract |
|---|--------|--------|-----------------|
| 1 | **Price point** | Offer Architecture Brief | Exact price, payment options, price anchor |
| 2 | **Belief gap count + sequence** | Belief-Gap-Analysis | Total gaps, Foundation/Middle/Upper/Capstone distribution, critical path length |
| 3 | **Market sophistication** | Demand Architecture Brief, Synthesis-03 | Schwartz awareness level, competitor saturation, how jaded the market is |
| 4 | **Core Concept / Big Idea strength** | Core-Concept-Candidates | Primary concept quality scores, uniqueness rating, market response prediction |
| 5 | **Trust deficit** | Belief-Gap-Analysis | Evidence types required (Story/Data/Demo/Logic/Authority), proof layer depth needed |
| 6 | **Competitor funnel convergence** | Doc 1 Anti-Mimetic Analysis | What funnel types competitors use, convergence percentage, uncontested approaches |
| 7 | **List size / audience** | Ask user | Current reach, platform presence, existing buyer list |
| 8 | **Traffic temperature** | Ask user | Cold/warm/hot, primary traffic source |

---

### Step 3 — Score All 11 Funnel Types

Score each funnel type against each factor on a 1-5 scale. Price point and belief gap count are **weighted 2x**.

#### The 11 Funnel Types

| # | Funnel Type | Proven Price Range | Best When | Expert Source |
|---|-------------|-------------------|-----------|---------------|
| 1 | **Direct Sales Page** | $27-$197 | Simple offer, warm/hot traffic, < 3 belief gaps | Brunson |
| 2 | **Tripwire Funnel** | $1-$47 | Buyer identification, value ladder entry, list building | Belcher, Brunson |
| 3 | **VSL Funnel** | $47-$497 | Clear pain/solution, direct response, medium sophistication | Hormozi |
| 4 | **Lead Magnet + Email Sequence** | Free entry → $27-$497 backend | Trust-first markets, awareness building, long nurture needed | Brunson, Kern |
| 5 | **Book / Free+Shipping** | $0+shipping → backend | Authority positioning, cold traffic, market building | Kern, Brunson |
| 6 | **Workshop / Masterclass** | $47-$997 | Demonstration-heavy, "taste and see," need to show mechanism working | Kern |
| 7 | **Webinar Funnel** | $297-$2K | Education-heavy, complex mechanism, 7+ belief gaps, existing list | Brunson, Ovens |
| 8 | **Challenge Funnel** | $19-$2K | Transformation-based, community-driven, no list, webinar fatigue | Adao |
| 9 | **Launch / PLF Funnel** | $197-$2K | New product, event-based, anticipation building, existing list preferred | Walker |
| 10 | **Quiz / Assessment Funnel** | Varies by backend | Multiple avatars, segmentation-first, routes to personalized offer | — |
| 11 | **Application Funnel** | $3K-$25K+ | High-ticket, qualification required, sophisticated market, sales team | Ovens, Brunson |

#### Scoring Rubric (per factor)

| Score | Meaning |
|-------|---------|
| 5 | Perfect fit — this funnel type was designed for this exact scenario |
| 4 | Strong fit — works well with minor adaptation |
| 3 | Acceptable — could work but not optimal |
| 2 | Weak fit — would require significant workarounds |
| 1 | Mismatch — this funnel type conflicts with this factor |

#### Weight Multipliers
- Price point: **2x**
- Belief gap count: **2x**
- All other factors: **1x**

**Maximum possible score:** (2 factors x 5 x 2 weight) + (6 factors x 5 x 1 weight) = 20 + 30 = **50 points**

---

### Step 4 — Apply Decision Trees

After scoring, apply these expert-derived decision trees to validate or override the scores:

#### Challenge vs. Webinar Tree (Adao)
When scores are close between Challenge and Webinar, apply these tiebreakers:
- No email list or list < 1K → **Challenge wins**
- Offer requires prospect to DO something (transformation) → **Challenge wins**
- Need to break objections in real-time, not just present → **Challenge wins**
- Market shows webinar fatigue (from mimetic analysis) → **Challenge wins**
- Pure information/education delivery → **Webinar wins**
- Need automated/evergreen version → **Webinar wins**
- Complex mechanism that needs step-by-step teaching → **Webinar wins**

#### Sophistication Escalation (Ovens)
When market sophistication is high (from demand-architect):
- Consider hybrid approaches: Webinar + Application, Challenge + Application
- Pure webinar may underperform in sophisticated markets — add qualification step

#### Value Ladder Position (Brunson)
Identify which rung the offer sits on and confirm the recommended funnel matches:
- Bait rung → Lead Magnet or Book funnel
- Frontend rung → Tripwire or VSL
- Middle rung → Webinar, Challenge, or Workshop
- Backend rung → Application or Webinar + Call hybrid

#### Big Idea Override (Todd Brown)
If Core Concept scored A on all quality tests AND is genuinely unique in the market:
- The funnel type matters less — the Big Idea will carry any reasonably appropriate format
- Note this in the recommendation: "Your Core Concept is strong enough that execution matters more than funnel type selection"

---

### Step 5 — Determine Primary + Fallback

From the scored and validated results:
1. **Primary recommendation**: Highest total score after decision tree validation
2. **Fallback recommendation**: Second highest score, chosen specifically because it addresses a different constraint (e.g., if primary needs a sales team and student doesn't have one, fallback doesn't)

State clearly WHY primary beats fallback, and under what conditions the student should use the fallback instead.

---

### Step 6 — Map Funnel Stages to Belief Gaps (Full mode only)

For the primary recommendation, create a stage-by-stage map:

| Funnel Stage | Belief Gap(s) Addressed | Bridge Type | Evidence Type Needed | Desire Layer Activated | Proof Layer Required |
|-------------|------------------------|-------------|---------------------|----------------------|---------------------|
| [Stage name] | [Gap from belief-gap-analyzer] | Foundation/Middle/Upper/Capstone | Story/Data/Demo/Logic/Authority | L1/L2/L3/L4 | [From proof architecture] |

Rules:
- Foundation bridges must come early in the funnel (awareness/entry stages)
- Capstone bridges come at or near the close
- Each stage should address 1-3 belief gaps maximum
- The Master Bridge (usually the Core Concept) gets its own dedicated stage

---

### Step 7 — Specify Content Requirements (Full mode only)

For each funnel stage, specify:
- **Asset type**: What format (video, email, landing page, PDF, live session, etc.)
- **Purpose**: What this asset must accomplish (which belief gap, which emotion, which proof)
- **Length/format guidance**: Approximate duration or word count
- **Key elements**: What must be included (specific proof points, stories, data from upstream research)

---

### Step 8 — Quality Gate

Before delivering, verify all items pass:

- [ ] Simplicity Check was run (Step 0)
- [ ] All available upstream documents were consumed with receipt
- [ ] All 8 decision factors have evidence-backed values
- [ ] All 11 funnel types were scored (no types skipped)
- [ ] Price point falls within recommended funnel's proven range
- [ ] Belief gap count aligns with funnel length
- [ ] Competitor convergence was checked — recommendation differs from 80%+ convergence
- [ ] Decision trees were applied where scores were close
- [ ] Primary + fallback are clearly stated with rationale
- [ ] All output files saved to disk (not just chat)

---

## OUTPUT FILES

### 1. `Funnel-Strategy-Scorecard.md`

```markdown
# Funnel Strategy Scorecard: [Offer Name]

## Simplicity Check Result
[PASSED/FAILED] — [Brief explanation]

## Decision Factor Summary
| Factor | Value | Source Document |
|--------|-------|----------------|
| Price point | $X | Offer Architecture Brief |
| Belief gaps | X gaps (Y foundation, Z capstone) | Belief-Gap-Analysis |
| [etc.] | | |

## Full Scorecard
| Funnel Type | Price (2x) | Gaps (2x) | Sophistication | Big Idea | Trust | Competition | List | Traffic | TOTAL |
|-------------|-----------|----------|---------------|---------|-------|-------------|------|---------|-------|
| [each type] | X | X | X | X | X | X | X | X | XX/50 |

## Decision Tree Adjustments
[Any overrides or tiebreakers applied]

## Recommendation
**PRIMARY: [Funnel Type]** — Score: XX/50
[2-3 sentence evidence-based rationale]

**FALLBACK: [Funnel Type]** — Score: XX/50
[When to use this instead]
```

### 2. `Funnel-Architecture-Blueprint.md`

```markdown
# Funnel Architecture Blueprint: [Offer Name]
## Funnel Type: [Recommended Type]

## Stage-by-Stage Map
| Stage | Belief Gap(s) | Bridge Type | Evidence Needed | Desire Layer | Proof Layer |
|-------|--------------|-------------|-----------------|-------------|-------------|
| [Stage 1] | [Gap] | Foundation | [Type] | [L1-L4] | [Layer] |
| [etc.] | | | | | |

## Flow Diagram
[Text-based flow: Entry → Stage 1 → Stage 2 → ... → Close]

## Anti-Mimetic Validation
- Competitor funnel convergence: [What competitors do]
- How this funnel diverges: [Specific differentiation points]
- Uncontested territory occupied: [From mimetic analysis]
```

### 3. `Content-Requirements-Spec.md`

```markdown
# Content Requirements: [Offer Name]
## Funnel Type: [Recommended Type]

## Stage 1: [Name]
- **Asset**: [Type and format]
- **Purpose**: [What it must accomplish]
- **Belief gap addressed**: [Specific gap]
- **Key elements**: [What must be included]
- **Estimated length**: [Duration or word count]

## Stage 2: [Name]
[Same structure]

[Continue for all stages]

## Asset Checklist
- [ ] [Asset 1]
- [ ] [Asset 2]
- [ ] [etc.]
```

---

## QUICK MODE OUTPUT

For `/funnel-strategy-selector quick`, produce a single document:

```markdown
# Funnel Recommendation: [Offer Name]

**Simplicity Check**: [PASSED/FAILED]

**Key Factors**:
- Price: $X → eliminates [types], favors [types]
- Belief gaps: X → needs [short/medium/long] funnel
- Market sophistication: [Level] → [implication]
- Traffic: [Cold/Warm/Hot] → [implication]

**PRIMARY: [Funnel Type]**
[3-5 sentence rationale with evidence citations]

**FALLBACK: [Funnel Type]**
[When to use this instead — 1-2 sentences]

**Next step**: Run `/funnel-strategy-selector full` for the complete blueprint and content spec.
```

---

## AUDIT MODE OUTPUT

For `/funnel-strategy-selector audit`, produce:

```markdown
# Funnel Audit: [Offer Name]
## Current Choice: [Student's funnel type]

**Verdict**: [VALIDATED / ADJUST / RECONSIDER]

**Score**: XX/50 (vs. optimal choice at XX/50)

**Strengths of current choice**:
- [What aligns with the evidence]

**Gaps in current choice**:
- [Where evidence suggests a different approach]

**Recommended adjustments**:
1. [Specific change]
2. [Specific change]
```
