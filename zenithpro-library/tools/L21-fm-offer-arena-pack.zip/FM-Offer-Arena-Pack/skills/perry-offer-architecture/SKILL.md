# Perry Belcher - Offer Architecture

---
name: perry-offer-architecture
description: Perry Belcher's offer design frameworks including Four Opportunity Types and Points of Belief. Use when designing new offers, diagnosing why offers fail, or repositioning products for higher conversion. (user)
---

## Core Principle

**Reduce what they must believe to ONE thing.**

The more beliefs required, the lower your conversion.

## Four Opportunity Types (Best → Worst)

| Rank | Type | Conversion | Description |
|------|------|------------|-------------|
| 1 | **Bolt-On** | HIGHEST | Add to existing success |
| 2 | **Dream Replacement** | HIGH | Entirely new dream |
| 3 | **Total Departure** | MEDIUM | Complete life change |
| 4 | **Repair/Improvement** | LOWEST | Fix what's broken |

### Bolt-On (BEST)
- They already have something working
- No identity threat, no admission of failure
- **Angles:** "Make your winning system even better" / "The missing piece for people already succeeding"

### Dream Replacement
- Old dream isn't working
- Give permission to want something new
- **Angles:** "Forget everything you thought you wanted" / "A better dream"

### Total Departure
- Big leap, high fear
- Requires strong origin story
- **Angles:** "Leave your old life behind" / "Fresh beginning"

### Repair/Improvement (WORST)
- Every engagement reminds of failure
- Status threat is constant
- **ALWAYS reframe as opportunity instead**

## Reframing Repair to Opportunity

| Repair Framing | Opportunity Reframe |
|---------------|---------------------|
| "Fix your broken funnel" | "The new approach that makes your old funnel obsolete" |
| "Repair your failing business" | "The business model that successful people are switching to" |
| "Get back on track" | "The path that top performers discovered" |

## Points of Belief

| Beliefs Required | Result |
|-----------------|--------|
| 1 | Offer works (maximum conversion) |
| 2 | Conversion significantly reduced |
| 3+ | Offer fails |

### Common Belief Stacks (Problems)
- "This method works"
- "It will work for ME"
- "I have the time/skills"
- "The price is worth it"
- "I can trust the seller"

### Reduction Strategies

**1. Single Mechanism**
Everything flows from ONE discovery.
*"Once you understand the Status Equation, everything else falls into place."*

**2. Belief Laddering**
Make belief #2 automatic consequence of #1.
*"If you believe people buy for status, you automatically understand why they reject repair offers."*

**3. Third-Party Validation**
Use authority to pre-establish beliefs.
*"Harvard psychologists discovered..."* (one belief in authority carries others)

**4. Demonstration**
Show, don't tell - seeing eliminates need to believe.

## The Insanity Offer

For people who have tried EVERYTHING and believe NOTHING works:

1. **Acknowledge Skepticism:** "You've tried X, Y, and Z. None of them worked."
2. **Validate Intelligence:** "You're not stupid - those methods don't work for people like you."
3. **Single Distinction:** "There's ONE reason they failed..."
4. **One Belief Required:** "All you need to believe is [single mechanism]."

## Same Desire Set Upsells

Upsells don't need to be related - they need to be in the same DESIRE SET.

**Examples:**
- Tanning product → Teeth whitening (same desire: look better)
- Author course → Speaker training (same desire: recognition)

**Best Upsells = Speed + Automation**
- How can they get results faster?
- What work can we do for them?

## Diagnostic Questions

1. What type of offer is this? (Bolt-On/Dream/Departure/Repair)
2. How can I reframe it higher on the hierarchy?
3. How many beliefs are currently required?
4. Which beliefs can I eliminate or combine?
5. What's the single master belief?

## Robert Wang's Lesson

> "Two percent of people have good taste. I sell everybody else."

- Don't design for sophisticated 2%
- Design for desire, not ambition
- Make it easy to understand
- Focus on result, not process

## Key Quotes

> "The more things someone must believe to buy, the lower your conversion."

> "Don't be the cure. Be the opportunity."

> "Repair offers fail because they remind people of their failures."

## Related Skills
- `perry-belcher` - Main orchestrator
- `perry-status-psychology` - Why they buy/don't buy
- `perry-tripwire-system` - Funnel economics
