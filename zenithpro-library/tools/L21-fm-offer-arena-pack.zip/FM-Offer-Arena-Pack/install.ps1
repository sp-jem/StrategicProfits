$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillsDir = Join-Path $env:USERPROFILE ".claude\skills"

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  FM Offer Arena Pack - Installer (Windows)" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# Create skills directory if needed
if (-not (Test-Path $SkillsDir)) {
    Write-Host "Creating $SkillsDir ..."
    New-Item -ItemType Directory -Path $SkillsDir -Force | Out-Null
}

$Skills = @(
    "offer-arena"
    "perry-offer-architecture"
    "carlton-offers"
    "clayton-offers"
    "hormozi-grand-slam-offer"
    "offer-architect"
    "funnel-strategy-selector"
)

$Installed = 0

foreach ($skill in $Skills) {
    $Source = Join-Path $ScriptDir "skills\$skill"
    $Dest = Join-Path $SkillsDir $skill

    if (-not (Test-Path $Source)) {
        Write-Host "  WARNING: Source folder not found: $Source" -ForegroundColor Yellow
        continue
    }

    if (Test-Path $Dest) {
        Write-Host "  [EXISTS] $skill - backing up to ${skill}.bak" -ForegroundColor Yellow
        $BackupDest = "${Dest}.bak"
        if (Test-Path $BackupDest) {
            Remove-Item -Recurse -Force $BackupDest
        }
        Copy-Item -Recurse -Force $Dest $BackupDest
    }

    Write-Host "  [INSTALL] $skill" -ForegroundColor Green
    if (-not (Test-Path $Dest)) {
        New-Item -ItemType Directory -Path $Dest -Force | Out-Null
    }
    Copy-Item -Recurse -Force "$Source\*" $Dest
    $Installed++
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Installation Complete" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Skills installed: $Installed"
Write-Host "  Location: $SkillsDir"
Write-Host ""
Write-Host "  Installed skills:"
foreach ($skill in $Skills) {
    $SkillFile = Join-Path $SkillsDir "$skill\SKILL.md"
    if (Test-Path $SkillFile) {
        Write-Host "    [OK] $skill" -ForegroundColor Green
    } else {
        Write-Host "    [MISSING] $skill" -ForegroundColor Red
    }
}
Write-Host ""
Write-Host "  Usage:"
Write-Host "    /offer-arena [your-offer-name]"
Write-Host "    /funnel-strategy-selector [your-offer-name]"
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
