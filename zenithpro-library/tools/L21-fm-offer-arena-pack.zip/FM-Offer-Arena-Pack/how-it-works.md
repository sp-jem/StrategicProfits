# How the Offer Arena Works

## Overview: The Student Pipeline

```mermaid
flowchart TD
A[Your Research<br>demand-architect + mimetic] --> B[Your Offer Brief]
B --> C[offer-arena]
C --> D[6 Competing Offers<br>+ Scored Winner]
D --> E[funnel-strategy-selector]
E --> F[Recommended Funnel Type<br>+ Stage Blueprint]
```

---

## The Offer Arena Competition Flow

```mermaid
flowchart TD
A[Brief Submitted] --> B[Phase 1: Setup]
B --> C[Phase 2: 5 Experts Draft in Parallel]
C --> D[Synthesis Reads All 5 + Combines Best]
D --> E[Phase 3: Each Entry Critiqued]
E --> F[Phase 4: Each Expert Revises]
F --> G[Phase 5: Judge Scores All 6]
G --> H[Winner Declared + Learning Saved]
```

---

## The 5 Experts + Synthesis

```mermaid
flowchart TD
B[Your Brief] --> P[Perry Belcher<br>Opportunity Positioning]
B --> CA[John Carlton<br>Guarantee Engineering]
B --> CL[Clayton Makepeace<br>Price Psychology]
B --> H[Alex Hormozi<br>Value Equation]
B --> OA[Offer Architect<br>Structural Baseline]
P --> S[Synthesis<br>Best of All 5]
CA --> S
CL --> S
H --> S
OA --> S
```

---

## Judgment Criteria

| Criterion | Weight |
|-----------|--------|
| Irresistibility | 25% |
| Value Architecture | 20% |
| Risk Reversal | 15% |
| Price Psychology | 15% |
| Structural Completeness | 10% |
| Differentiation | 10% |
| Stress Test Results | 5% |

---

## Funnel Strategy Selector Flow

```mermaid
flowchart TD
A[Winning Offer] --> B[Step 0: Simplicity Check]
B -->|PASS| C[Recommend Simplest Funnel]
B -->|FAIL| D[Score 11 Funnel Types<br>Against 8 Factors]
D --> E[Apply Decision Trees]
E --> F[Primary + Fallback<br>Recommendation]
F --> G[Stage-by-Stage Blueprint]
```

---

## File Structure After Running

```
Your Obsidian Vault/
  00 Projects/
    Offer Arena/
      {competition-name}/
        brief.md
        round-1/
          drafts/     (6 offer files)
          critiques/  (6 critique files)
          revisions/  (6 revised files)
          judgment.md
        arena-summary.md
```
