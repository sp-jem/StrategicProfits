#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILLS_DIR="$HOME/.claude/skills"

echo "============================================"
echo "  FM Offer Arena Pack — Installer (Mac/Linux)"
echo "============================================"
echo ""

# Check if .claude/skills exists
if [ ! -d "$SKILLS_DIR" ]; then
    echo "Creating $SKILLS_DIR ..."
    mkdir -p "$SKILLS_DIR"
fi

SKILLS=(
    "offer-arena"
    "perry-offer-architecture"
    "carlton-offers"
    "clayton-offers"
    "hormozi-grand-slam-offer"
    "offer-architect"
    "funnel-strategy-selector"
)

INSTALLED=0
SKIPPED=0

for skill in "${SKILLS[@]}"; do
    SOURCE="$SCRIPT_DIR/skills/$skill"
    DEST="$SKILLS_DIR/$skill"

    if [ ! -d "$SOURCE" ]; then
        echo "WARNING: Source folder not found: $SOURCE"
        continue
    fi

    if [ -d "$DEST" ]; then
        echo "  [EXISTS] $skill — backing up to ${skill}.bak"
        if [ -d "${DEST}.bak" ]; then
            rm -rf "${DEST}.bak"
        fi
        cp -r "$DEST" "${DEST}.bak"
    fi

    echo "  [INSTALL] $skill"
    mkdir -p "$DEST"
    cp -r "$SOURCE"/* "$DEST"/
    INSTALLED=$((INSTALLED + 1))
done

echo ""
echo "============================================"
echo "  Installation Complete"
echo "============================================"
echo ""
echo "  Skills installed: $INSTALLED"
echo "  Location: $SKILLS_DIR"
echo ""
echo "  Installed skills:"
for skill in "${SKILLS[@]}"; do
    if [ -f "$SKILLS_DIR/$skill/SKILL.md" ]; then
        echo "    [OK] $skill"
    else
        echo "    [MISSING] $skill"
    fi
done
echo ""
echo "  Usage:"
echo "    /offer-arena [your-offer-name]"
echo "    /funnel-strategy-selector [your-offer-name]"
echo ""
echo "============================================"
