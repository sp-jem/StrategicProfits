# FM Offer Arena Pack

Run one command and get 6 competing offer designs from 5 world-class methodologies — then pick the winner.

---

## What This Does For You

The Offer Arena takes your product brief and runs it through 5 expert offer methodologies simultaneously: Perry Belcher (opportunity positioning), John Carlton (guarantee engineering), Clayton Makepeace (price psychology), Alex Hormozi (Value Equation optimization), and a structural baseline (offer-architect). A 6th entry — the Synthesis — combines the strongest elements from all five.

Each entry gets critiqued against its own methodology's standards, revised, then judged head-to-head for marketplace irresistibility. You get a scored winner with specific evidence for why it wins, plus all 6 complete offer architectures to pull from.

After the arena picks a winner, the Funnel Strategy Selector takes that winning offer and recommends the optimal funnel type (webinar, VSL, challenge, application, etc.) based on your price point, belief gaps, market sophistication, and 8 other evidence-based factors.

**Two commands. That's it:**
1. `/offer-arena` — produces 6 competing offers + declares a winner
2. `/funnel-strategy-selector` — recommends the right funnel for the winning offer

---

## How It Works

The offer-arena orchestrator spawns 5 expert sub-agents in parallel. Each loads its methodology and designs a complete offer from your brief. After all 5 finish, a Synthesis agent combines the best elements. Then critique, revision, and judgment phases run automatically.

See [how-it-works.md](how-it-works.md) for visual diagrams.

---

## Installation

### Mac (Terminal)

```bash
cd ~/Downloads/FM-Offer-Arena-Pack
chmod +x install.sh
./install.sh
```

### Windows (PowerShell)

```powershell
cd $env:USERPROFILE\Downloads\FM-Offer-Arena-Pack
.\install.ps1
```

---

## What Gets Installed

| Skill | Location | Purpose |
|-------|----------|---------|
| `offer-arena` | `~/.claude/skills/offer-arena/` | The orchestrator — runs everything |
| `perry-offer-architecture` | `~/.claude/skills/perry-offer-architecture/` | Perry Belcher methodology |
| `carlton-offers` | `~/.claude/skills/carlton-offers/` | John Carlton methodology + reference frameworks |
| `clayton-offers` | `~/.claude/skills/clayton-offers/` | Clayton Makepeace methodology + 23 framework files |
| `hormozi-grand-slam-offer` | `~/.claude/skills/hormozi-grand-slam-offer/` | Alex Hormozi Value Equation methodology |
| `offer-architect` | `~/.claude/skills/offer-architect/` | Structural baseline methodology |
| `funnel-strategy-selector` | `~/.claude/skills/funnel-strategy-selector/` | Post-arena funnel recommendation |

**Total: 7 skills, ~30 files**

---

## How to Use

### Step 1: Run the Offer Arena

```
/offer-arena
```

That's it. The arena will ask you one question first:

> **Do you already have an offer you'd like to improve, or are you building one from scratch?**

- **Build from scratch** — 5 expert methodologies each create a competing offer for you. You get 6 complete versions + a winner.
- **Improve my existing offer** — Paste or point to your current offer. 5 experts diagnose what's working and what's not, then produce a revised version with a before/after comparison.

You don't need to remember any special commands — just run `/offer-arena` and answer the question.

### Step 2: Select Your Funnel

```
/funnel-strategy-selector [your-offer-name]
```

Takes the winning offer and scores 11 funnel types against 8 decision factors. Produces a primary recommendation + fallback with stage-by-stage blueprint.

**Modes:**
- `full` — Complete analysis with scorecard, blueprint, and content spec
- `quick` — Fast recommendation (1-page)
- `audit` — Grade an existing funnel choice

### Step 3: Build Your Funnel

Take the winning offer + recommended funnel type and start building.

---

## Troubleshooting

**"Skill not found" when running /offer-arena:**
The installer copies skills to `~/.claude/skills/`. Verify they exist:
```bash
ls ~/.claude/skills/offer-arena/SKILL.md
```

**Arena sub-agents fail to load methodology:**
The arena reads methodology files from `~/.claude/skills/`. All 5 expert skills must be installed — not just the arena.

**Permission denied on install.sh:**
Run `chmod +x install.sh` first, then `./install.sh`.

**Windows: "scripts disabled" error:**
Run PowerShell as Administrator and execute:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**Clayton or Carlton skills missing frameworks:**
These skills include `references/` folders with framework files. Re-run the installer to ensure they copied correctly.

---

## Requirements

- Claude Code installed and working
- No API keys needed — these are methodology skills, not API integrations
- Works on Mac, Linux, and Windows

---

*Packaged by Rich Schefren - Strategic Profits*
