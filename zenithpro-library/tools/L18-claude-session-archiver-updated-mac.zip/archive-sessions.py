#!/usr/bin/env python3
"""
Claude Code Session Archiver
Converts Claude Code conversation history into searchable Obsidian markdown files.

Usage:
    python3 archive-sessions.py OUTPUT_FOLDER [options]

Options:
    --dry-run          Show what would be archived without writing files
    --since YYYY-MM-DD Only archive sessions created on or after this date
    --force            Re-archive sessions even if output file already exists
    --no-subagents     Skip sub-agent conversations
    --help             Show this help message

Examples:
    python3 archive-sessions.py ~/Documents/Claude-Archive
    python3 archive-sessions.py ~/Documents/Obsidian/MyVault --dry-run
    python3 archive-sessions.py ~/Claude-Archive --since 2026-02-01
    python3 archive-sessions.py ~/Claude-Archive --force

Requirements:
    - Python 3.8+ (ships with macOS)
    - No external packages needed
"""

import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args():
    args = sys.argv[1:]

    if not args or "--help" in args or "-h" in args:
        print(__doc__.strip())
        sys.exit(0)

    opts = {
        "output": None,
        "dry_run": False,
        "since": None,
        "force": False,
        "no_subagents": False,
    }

    positional = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--dry-run":
            opts["dry_run"] = True
        elif a == "--force":
            opts["force"] = True
        elif a == "--no-subagents":
            opts["no_subagents"] = True
        elif a == "--since":
            i += 1
            if i >= len(args):
                die("--since requires a date (YYYY-MM-DD)")
            try:
                opts["since"] = datetime.strptime(args[i], "%Y-%m-%d").replace(
                    tzinfo=timezone.utc
                )
            except ValueError:
                die(f"Invalid date format: {args[i]}  (expected YYYY-MM-DD)")
        elif a.startswith("-"):
            die(f"Unknown option: {a}\nRun with --help for usage.")
        else:
            positional.append(a)
        i += 1

    if not positional:
        die("Missing required argument: OUTPUT_FOLDER\nRun with --help for usage.")

    opts["output"] = Path(os.path.expanduser(positional[0]))
    return opts


def die(msg):
    print(f"Error: {msg}", file=sys.stderr)
    sys.exit(2)


# ---------------------------------------------------------------------------
# Session Discovery
# ---------------------------------------------------------------------------

def discover_sessions(projects_dir, include_subagents=True):
    """Walk ~/.claude/projects/ and build a list of session descriptors."""
    sessions = []
    index_cache = {}  # project_dir -> {sessionId: entry}

    for project_dir in sorted(projects_dir.iterdir()):
        if not project_dir.is_dir():
            continue

        # Load sessions-index.json if present
        index_path = project_dir / "sessions-index.json"
        index_entries = {}
        original_path = None
        if index_path.exists():
            try:
                with open(index_path, "r", encoding="utf-8") as f:
                    idx = json.load(f)
                original_path = idx.get("originalPath")
                for entry in idx.get("entries", []):
                    sid = entry.get("sessionId", "")
                    if sid:
                        index_entries[sid] = entry
            except (json.JSONDecodeError, OSError) as e:
                warn(f"Could not read {index_path}: {e}")
        index_cache[project_dir] = index_entries

        # Use originalPath from index (accurate), fall back to dirname decoding
        if original_path:
            project_name = format_project_path(original_path)
        else:
            project_name = decode_project_name(project_dir.name)

        # Discover top-level .jsonl files
        for jsonl_file in sorted(project_dir.glob("*.jsonl")):
            if jsonl_file.stat().st_size == 0:
                continue
            session_id = jsonl_file.stem
            idx_entry = index_entries.get(session_id)
            sessions.append({
                "path": jsonl_file,
                "session_id": session_id,
                "project": project_name,
                "project_dir": project_dir,
                "index_entry": idx_entry,
                "is_subagent": False,
                "parent_session_id": None,
                "file_size": jsonl_file.stat().st_size,
            })

        # Discover subagent sessions
        if include_subagents:
            for session_dir in sorted(project_dir.iterdir()):
                if not session_dir.is_dir():
                    continue
                subagent_dir = session_dir / "subagents"
                if not subagent_dir.exists():
                    continue
                parent_id = session_dir.name
                for agent_file in sorted(subagent_dir.glob("agent-*.jsonl")):
                    if agent_file.stat().st_size == 0:
                        continue
                    sessions.append({
                        "path": agent_file,
                        "session_id": agent_file.stem,
                        "project": project_name,
                        "project_dir": project_dir,
                        "index_entry": None,
                        "is_subagent": True,
                        "parent_session_id": parent_id,
                        "file_size": agent_file.stat().st_size,
                    })

    return sessions


def format_project_path(abs_path):
    """Convert an absolute project path to a readable display name with ~."""
    home = str(Path.home())
    if abs_path.startswith(home):
        return "~" + abs_path[len(home):]
    return abs_path


def decode_project_name(dirname):
    """Convert encoded project directory name to readable name.

    Claude Code encodes paths like:
        -Users-jane-Documents-Obsidian-My-Vault
    This converts to a readable display name.
    """
    name = dirname
    if name.startswith("-"):
        name = name[1:]

    # Split on hyphens and reconstruct as path
    parts = name.split("-")

    # Try to find home directory prefix and replace with ~
    home_parts = str(Path.home()).strip("/").split("/")
    home_len = len(home_parts)
    if parts[:home_len] == home_parts:
        remaining = parts[home_len:]
        if remaining:
            return "~/" + "/".join(remaining)
        return "~"

    return "/".join(parts)


# ---------------------------------------------------------------------------
# JSONL Parser
# ---------------------------------------------------------------------------

def parse_session_file(jsonl_path):
    """Parse a JSONL session file and extract structured data."""
    messages = []
    skills_used = set()
    files_modified = []
    tools_invoked = set()
    first_timestamp = None
    last_timestamp = None
    inline_summary = None
    model_used = None
    line_count = 0
    parse_errors = []

    with open(jsonl_path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            line_count += 1
            try:
                entry = json.loads(line)
            except json.JSONDecodeError as e:
                parse_errors.append(f"Line {line_num}: {e}")
                continue

            # Track timestamps
            ts = parse_timestamp(entry.get("timestamp"))
            if ts:
                if first_timestamp is None:
                    first_timestamp = ts
                last_timestamp = ts

            entry_type = entry.get("type")

            if entry_type == "user":
                text = extract_user_content(entry)
                if text:
                    messages.append(("user", text))

            elif entry_type == "assistant":
                msg_obj = entry.get("message", {})
                # Track model
                if not model_used:
                    model_used = msg_obj.get("model")
                blocks = msg_obj.get("content", [])
                if isinstance(blocks, list):
                    text_parts = []
                    for block in blocks:
                        if not isinstance(block, dict):
                            continue
                        btype = block.get("type")
                        if btype == "text":
                            t = block.get("text", "")
                            if t:
                                text_parts.append(t)
                        elif btype == "tool_use":
                            tool_name = block.get("name", "")
                            tools_invoked.add(tool_name)
                            params = block.get("input", {})
                            if tool_name == "Skill":
                                skill = params.get("skill", "")
                                if skill:
                                    skills_used.add(skill)
                            if tool_name in ("Write", "Edit"):
                                fp = params.get("file_path", "")
                                if fp:
                                    files_modified.append({
                                        "path": fp,
                                        "operation": tool_name.lower(),
                                    })
                            text_parts.append(f"[Used tool: {tool_name}]")
                        # Skip thinking blocks -- internal reasoning
                    if text_parts:
                        messages.append(("assistant", "\n\n".join(text_parts)))

            elif entry_type == "summary":
                s = entry.get("summary")
                if s:
                    inline_summary = s

    # Duration
    duration_minutes = 0
    if first_timestamp and last_timestamp:
        delta = (last_timestamp - first_timestamp).total_seconds()
        duration_minutes = max(0, int(delta / 60))

    return {
        "messages": messages,
        "skills_used": sorted(skills_used),
        "files_modified": files_modified,
        "tools_invoked": sorted(tools_invoked),
        "duration_minutes": duration_minutes,
        "first_timestamp": first_timestamp,
        "last_timestamp": last_timestamp,
        "inline_summary": inline_summary,
        "model": model_used,
        "line_count": line_count,
        "parse_errors": parse_errors,
    }


def extract_user_content(entry):
    """Extract readable text from a user message entry."""
    content = entry.get("message", {}).get("content", "")

    if isinstance(content, str):
        return content if content.strip() else None

    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                btype = block.get("type", "")
                if btype == "text":
                    t = block.get("text", "")
                    if t:
                        parts.append(t)
                elif btype == "image":
                    parts.append("[Image attached]")
                elif btype == "tool_result":
                    parts.append("[Tool result]")
        return "\n".join(parts) if parts else None

    return None


def parse_timestamp(ts_val):
    """Parse ISO timestamp string to datetime."""
    if not ts_val or not isinstance(ts_val, str):
        return None
    try:
        # Handle Z suffix and +00:00
        ts_val = ts_val.replace("Z", "+00:00")
        return datetime.fromisoformat(ts_val)
    except (ValueError, TypeError):
        return None


# ---------------------------------------------------------------------------
# Topic Detection
# ---------------------------------------------------------------------------

TOPIC_KEYWORDS = {
    "debugging": ["debug", "error", "traceback", "exception", "fix", "broken", "bug"],
    "skill-development": ["SKILL.md", "create skill", "skill file", "skill system"],
    "agent-development": ["AGENT.md", "critic agent", "sub-agent", "subagent"],
    "webinar": ["webinar", "presentation", "slides", "webinar arena"],
    "marketing": ["marketing", "campaign", "copy", "email sequence", "funnel"],
    "infrastructure": ["MCP", "server", "deploy", "infrastructure", "docker"],
    "research": ["research", "analysis", "deep research", "study"],
    "coding": ["function", "class", "import", "def ", "const ", "async", "python", "javascript"],
    "writing": ["draft", "article", "blog", "content", "write"],
    "data": ["stripe", "analytics", "revenue", "metrics", "dashboard"],
}


def detect_topics(messages):
    """Auto-detect topics from message content."""
    # Sample first 20 messages to avoid scanning huge transcripts
    sample = " ".join(msg[1] for msg in messages[:20]).lower()
    topics = []
    for tag, keywords in TOPIC_KEYWORDS.items():
        if any(kw.lower() in sample for kw in keywords):
            topics.append(tag)
    return sorted(topics)


# ---------------------------------------------------------------------------
# Metadata Assembly
# ---------------------------------------------------------------------------

def assemble_metadata(session_info, parsed):
    """Combine index metadata + parsed data into final metadata."""
    idx = session_info.get("index_entry") or {}

    # Summary: prefer index, fall back to inline, then generate
    summary = idx.get("summary") or parsed.get("inline_summary") or ""
    if not summary and parsed["messages"]:
        summary = generate_summary_from_first_message(parsed["messages"][0][1])

    # First prompt
    first_prompt = idx.get("firstPrompt") or ""
    if not first_prompt and parsed["messages"]:
        first_prompt = parsed["messages"][0][1][:200]

    # Dates
    created = None
    if idx.get("created"):
        created = parse_timestamp(idx["created"])
    if not created:
        created = parsed["first_timestamp"]
    if not created:
        # Last resort: file modification time
        created = datetime.fromtimestamp(
            session_info["path"].stat().st_mtime, tz=timezone.utc
        )

    modified = None
    if idx.get("modified"):
        modified = parse_timestamp(idx["modified"])
    if not modified:
        modified = parsed["last_timestamp"]

    # Message count: prefer index (includes tool results etc)
    message_count = idx.get("messageCount") or len(parsed["messages"])

    topics = detect_topics(parsed["messages"])

    return {
        "summary": summary,
        "first_prompt": first_prompt,
        "created": created,
        "modified": modified,
        "message_count": message_count,
        "topics": topics,
        "git_branch": idx.get("gitBranch", ""),
        "is_sidechain": idx.get("isSidechain", session_info.get("is_subagent", False)),
    }


def generate_summary_from_first_message(text):
    """Generate a short summary from the first user message."""
    # Clean and truncate
    text = re.sub(r"\s+", " ", text).strip()
    # Take first sentence or first 80 chars
    for sep in [".", "?", "!", "\n"]:
        pos = text.find(sep)
        if 0 < pos < 100:
            return text[: pos + 1].strip()
    return text[:80].strip()


# ---------------------------------------------------------------------------
# Markdown Generator
# ---------------------------------------------------------------------------

def generate_markdown(session_info, parsed, meta):
    """Generate the full markdown file content."""
    sid = session_info["session_id"]
    project = session_info["project"]
    created = meta["created"]

    date_str = created.strftime("%Y-%m-%d")
    time_str = created.strftime("%I:%M %p").lstrip("0")
    duration = format_duration(parsed["duration_minutes"])
    title = meta["summary"] or "Untitled Session"

    # YAML frontmatter
    lines = ["---"]
    lines.append(f"date: {date_str}")
    lines.append(f"time: \"{time_str}\"")
    lines.append(f"project: \"{escape_yaml(project)}\"")
    lines.append(f"duration: \"{duration}\"")
    lines.append(f"summary: \"{escape_yaml(title)}\"")
    if meta["first_prompt"]:
        fp = meta["first_prompt"].replace("\n", " ")[:200]
        lines.append(f"first-prompt: \"{escape_yaml(fp)}\"")
    lines.append(f"skills-used: {json.dumps(parsed['skills_used'])}")
    lines.append(f"files-modified: {json.dumps([f['path'] for f in parsed['files_modified']])}")
    lines.append(f"topics: {json.dumps(meta['topics'])}")
    lines.append(f"session-id: \"{sid}\"")
    lines.append(f"message-count: {meta['message_count']}")
    if parsed["model"]:
        lines.append(f"model: \"{parsed['model']}\"")
    if meta["git_branch"]:
        lines.append(f"git-branch: \"{escape_yaml(meta['git_branch'])}\"")
    if session_info["is_subagent"]:
        lines.append(f"is-subagent: true")
        if session_info["parent_session_id"]:
            lines.append(f"parent-session: \"{session_info['parent_session_id']}\"")
    lines.append("---")
    lines.append("")

    # Header
    lines.append(f"# {title}")
    lines.append("")
    lines.append(f"**Date:** {date_str}  ")
    lines.append(f"**Time:** {time_str}  ")
    lines.append(f"**Project:** {project}  ")
    lines.append(f"**Duration:** {duration}  ")
    if session_info["is_subagent"]:
        lines.append(f"**Type:** Sub-agent session  ")
    lines.append("")

    # Size warning for very large sessions
    size_mb = session_info["file_size"] / (1024 * 1024)
    if size_mb > 10:
        lines.append(f"> **Note:** This was a large session ({size_mb:.0f} MB source file, {len(parsed['messages'])} messages). Transcript below may be lengthy.")
        lines.append("")

    # Metadata section
    lines.append("## Metadata")
    lines.append("")
    if parsed["skills_used"]:
        lines.append(f"**Skills Used:** {', '.join(parsed['skills_used'])}  ")
    if meta["topics"]:
        lines.append(f"**Topics:** {', '.join(meta['topics'])}  ")
    if parsed["model"]:
        lines.append(f"**Model:** {parsed['model']}  ")
    lines.append("")

    if parsed["files_modified"]:
        lines.append("**Files Modified:**")
        # Deduplicate
        seen = set()
        for f in parsed["files_modified"]:
            key = f"{f['path']}|{f['operation']}"
            if key not in seen:
                seen.add(key)
                lines.append(f"- `{f['path']}` ({f['operation']})")
        lines.append("")

    lines.append("---")
    lines.append("")

    # Transcript
    lines.append("## Transcript")
    lines.append("")

    for role, content in parsed["messages"]:
        if role == "user":
            lines.append("**User:**")
            lines.append("")
            lines.append(content)
            lines.append("")
        elif role == "assistant":
            lines.append("**Assistant:**")
            lines.append("")
            lines.append(content)
            lines.append("")

    return "\n".join(lines)


def escape_yaml(s):
    """Escape a string for use in YAML double-quoted values."""
    return s.replace("\\", "\\\\").replace('"', '\\"')


def format_duration(minutes):
    if minutes < 1:
        return "< 1 minute"
    if minutes < 60:
        return f"{minutes} minutes"
    hours = minutes // 60
    mins = minutes % 60
    if mins:
        return f"{hours}h {mins}m"
    return f"{hours}h"


# ---------------------------------------------------------------------------
# Filename & Output
# ---------------------------------------------------------------------------

def sanitize_filename(text, max_len=60):
    """Convert text to a safe filename component."""
    # Lowercase, replace non-alnum with hyphens
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text)
    text = text.strip("-")
    return text[:max_len] if text else "untitled"


def output_path_for_session(session_info, meta, archive_base):
    """Compute the output file path for a session.

    Main conversations go in: Conversations/YYYY/MM-Month/
    Sub-agent conversations go in: Conversations/YYYY/MM-Month/subagents/
    """
    created = meta["created"]
    year = created.strftime("%Y")
    month = created.strftime("%m-%B")
    date = created.strftime("%Y-%m-%d")

    desc = sanitize_filename(meta["summary"])
    short_id = session_info["session_id"][:8]

    prefix = "subagent-" if session_info["is_subagent"] else ""
    filename = f"{date}-{prefix}{desc}-{short_id}.md"

    month_dir = archive_base / "Conversations" / year / month
    if session_info["is_subagent"]:
        return month_dir / "subagents" / filename
    return month_dir / filename


def build_archived_session_ids(archive_base):
    """Scan existing archive files and extract session IDs from filenames.

    Works with any naming convention as long as the session ID (8+ hex chars)
    appears before .md at the end of the filename.
    """
    archived = set()
    conv_dir = archive_base / "Conversations"
    if not conv_dir.exists():
        return archived
    for md_file in conv_dir.rglob("*.md"):
        # Extract last component before .md that looks like a session ID
        stem = md_file.stem  # filename without .md
        # Session ID is the last hyphen-separated segment
        parts = stem.rsplit("-", 1)
        if len(parts) == 2:
            candidate = parts[-1]
            # Valid session IDs are 8+ hex chars (UUIDs truncated or agent hashes)
            if len(candidate) >= 2 and all(c in "0123456789abcdef" for c in candidate):
                archived.add(candidate)
    return archived


def session_already_archived(session_info, archive_base, meta, _cache={}):
    """Check if session is already archived (by session ID in any existing filename)."""
    # Build cache on first call
    cache_key = str(archive_base)
    if cache_key not in _cache:
        _cache[cache_key] = build_archived_session_ids(archive_base)
    archived_ids = _cache[cache_key]

    short_id = session_info["session_id"][:8]
    return short_id in archived_ids


# ---------------------------------------------------------------------------
# Main Processing
# ---------------------------------------------------------------------------

def process_session(session_info, archive_base, opts):
    """Process one session. Returns result dict or raises."""
    parsed = parse_session_file(session_info["path"])

    if not parsed["messages"]:
        return {"status": "skipped", "reason": "no messages"}

    meta = assemble_metadata(session_info, parsed)

    # Date filter
    if opts["since"] and meta["created"]:
        if meta["created"] < opts["since"]:
            return {"status": "skipped", "reason": "before --since date"}

    # Incremental: skip if already exists
    if not opts["force"] and session_already_archived(session_info, archive_base, meta):
        return {"status": "skipped", "reason": "already archived"}

    out_path = output_path_for_session(session_info, meta, archive_base)

    if opts["dry_run"]:
        return {
            "status": "would_archive",
            "path": out_path,
            "messages": len(parsed["messages"]),
            "summary": meta["summary"],
            "date": meta["created"],
        }

    # Generate and write
    markdown = generate_markdown(session_info, parsed, meta)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(markdown)

    return {
        "status": "archived",
        "path": out_path,
        "messages": len(parsed["messages"]),
        "summary": meta["summary"],
        "date": meta["created"],
        "duration": parsed["duration_minutes"],
        "parse_errors": parsed["parse_errors"],
    }


def main():
    opts = parse_args()
    projects_dir = Path.home() / ".claude" / "projects"
    archive_base = opts["output"]

    if not projects_dir.exists():
        die(f"No Claude Code sessions found at {projects_dir}\n"
            "Make sure Claude Code has been used on this machine.")

    # Banner
    print("=" * 60, file=sys.stderr)
    print("  CLAUDE CODE SESSION ARCHIVER", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    print(f"  Sessions:  {projects_dir}", file=sys.stderr)
    print(f"  Output:    {archive_base}", file=sys.stderr)
    if opts["dry_run"]:
        print(f"  Mode:      DRY RUN (no files will be written)", file=sys.stderr)
    if opts["since"]:
        print(f"  Since:     {opts['since'].strftime('%Y-%m-%d')}", file=sys.stderr)
    if opts["force"]:
        print(f"  Force:     YES (re-archive existing)", file=sys.stderr)
    if opts["no_subagents"]:
        print(f"  Subagents: EXCLUDED", file=sys.stderr)
    print("=" * 60, file=sys.stderr)

    # Discover
    print("\nDiscovering sessions...", file=sys.stderr)
    include_sub = not opts["no_subagents"]
    sessions = discover_sessions(projects_dir, include_subagents=include_sub)

    main_count = sum(1 for s in sessions if not s["is_subagent"])
    sub_count = sum(1 for s in sessions if s["is_subagent"])
    print(f"Found {main_count} sessions + {sub_count} sub-agent sessions "
          f"({len(sessions)} total)", file=sys.stderr)

    if not sessions:
        print("No sessions to archive.", file=sys.stderr)
        sys.exit(0)

    # Size warnings
    large = [s for s in sessions if s["file_size"] > 50 * 1024 * 1024]
    if large:
        print(f"\n  Warning: {len(large)} session(s) over 50 MB -- may take a moment:",
              file=sys.stderr)
        for s in large[:5]:
            mb = s["file_size"] / (1024 * 1024)
            print(f"    {s['session_id'][:8]}... ({mb:.0f} MB)", file=sys.stderr)

    # Process
    print(f"\n{'Scanning' if opts['dry_run'] else 'Archiving'}...\n", file=sys.stderr)

    results = {"archived": [], "would_archive": [], "skipped": [], "errors": []}
    total = len(sessions)

    for i, session_info in enumerate(sessions, 1):
        # Progress
        pct = int(i / total * 100)
        sid_short = session_info["session_id"][:8]
        print(f"\r  [{i}/{total}] ({pct}%) {sid_short}...", end="", file=sys.stderr)

        try:
            result = process_session(session_info, archive_base, opts)
            status = result["status"]
            results[status].append(result)
        except Exception as e:
            results["errors"].append({
                "session_id": session_info["session_id"],
                "path": str(session_info["path"]),
                "error": str(e),
            })

    print("\r" + " " * 60, file=sys.stderr)  # Clear progress line

    # Report
    print("\n" + "=" * 60, file=sys.stderr)
    print("  RESULTS", file=sys.stderr)
    print("=" * 60, file=sys.stderr)

    archived = results["archived"]
    would = results["would_archive"]
    skipped = results["skipped"]
    errors = results["errors"]

    if opts["dry_run"]:
        print(f"  Would archive: {len(would)}", file=sys.stderr)
        print(f"  Would skip:    {len(skipped)}", file=sys.stderr)
        if errors:
            print(f"  Errors:        {len(errors)}", file=sys.stderr)
        if would:
            total_msgs = sum(r["messages"] for r in would)
            dates = [r["date"] for r in would if r.get("date")]
            print(f"  Total messages: {total_msgs:,}", file=sys.stderr)
            if dates:
                print(f"  Date range:    {min(dates).strftime('%Y-%m-%d')} to "
                      f"{max(dates).strftime('%Y-%m-%d')}", file=sys.stderr)
    else:
        print(f"  Archived: {len(archived)}", file=sys.stderr)
        print(f"  Skipped:  {len(skipped)}", file=sys.stderr)
        if errors:
            print(f"  Errors:   {len(errors)}", file=sys.stderr)
        if archived:
            total_msgs = sum(r["messages"] for r in archived)
            total_dur = sum(r.get("duration", 0) for r in archived)
            dates = [r["date"] for r in archived if r.get("date")]
            print(f"  Messages: {total_msgs:,}", file=sys.stderr)
            print(f"  Duration: {format_duration(total_dur)}", file=sys.stderr)
            if dates:
                print(f"  Range:    {min(dates).strftime('%Y-%m-%d')} to "
                      f"{max(dates).strftime('%Y-%m-%d')}", file=sys.stderr)

    # Skip reasons
    skip_reasons = {}
    for s in skipped:
        r = s.get("reason", "unknown")
        skip_reasons[r] = skip_reasons.get(r, 0) + 1
    if skip_reasons:
        print(f"\n  Skip breakdown:", file=sys.stderr)
        for reason, count in sorted(skip_reasons.items()):
            print(f"    {reason}: {count}", file=sys.stderr)

    # Errors detail
    if errors:
        print(f"\n  Errors:", file=sys.stderr)
        for e in errors[:20]:
            print(f"    {e['session_id'][:8]}: {e['error']}", file=sys.stderr)
        if len(errors) > 20:
            print(f"    ... and {len(errors) - 20} more", file=sys.stderr)

    # Parse warnings
    if not opts["dry_run"]:
        sessions_with_errors = [r for r in archived if r.get("parse_errors")]
        if sessions_with_errors:
            print(f"\n  Parse warnings in {len(sessions_with_errors)} session(s):",
                  file=sys.stderr)
            for r in sessions_with_errors[:5]:
                print(f"    {r['path'].name}: {len(r['parse_errors'])} malformed line(s)",
                      file=sys.stderr)

    print(f"\n  Output: {archive_base / 'Conversations/'}", file=sys.stderr)
    print("=" * 60, file=sys.stderr)

    # Exit code
    if errors and not archived and not would:
        sys.exit(2)  # Total failure
    elif errors:
        sys.exit(1)  # Partial failure
    sys.exit(0)


def warn(msg):
    print(f"  Warning: {msg}", file=sys.stderr)


if __name__ == "__main__":
    main()
