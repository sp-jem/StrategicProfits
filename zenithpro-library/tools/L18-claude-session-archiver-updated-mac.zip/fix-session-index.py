#!/usr/bin/env python3
"""
SessionStart hook: Detects and repairs broken sessions-index.json files.
Runs on every session start. Fast path: if index matches disk, exits in <100ms.
If mismatch found, rebuilds the index from actual .jsonl files on disk.
"""

import json
import os
import glob
import shutil
from datetime import datetime, timezone

PROJECTS_DIR = os.path.expanduser("~/.claude/projects")
BACKUPS_DIR = os.path.expanduser("~/.claude/backups")


def get_disk_session_ids(project_path):
    """Get set of session IDs from .jsonl files on disk."""
    files = glob.glob(os.path.join(project_path, "*.jsonl"))
    return {os.path.basename(f).replace(".jsonl", "") for f in files}


def check_index_health(project_path):
    """Returns True if index is healthy, False if it needs rebuild."""
    idx_path = os.path.join(project_path, "sessions-index.json")
    disk_ids = get_disk_session_ids(project_path)

    if not disk_ids:
        return True  # No sessions, nothing to fix

    if not os.path.exists(idx_path):
        return False  # Sessions exist but no index

    try:
        with open(idx_path) as f:
            idx = json.load(f)
        indexed_ids = {e["sessionId"] for e in idx.get("entries", [])}
    except (json.JSONDecodeError, KeyError):
        return False  # Corrupt index

    # Check for orphaned files (on disk but not indexed)
    orphaned = disk_ids - indexed_ids
    if orphaned:
        return False

    return True


def rebuild_index(project_path):
    """Rebuild sessions-index.json from .jsonl files on disk."""
    idx_path = os.path.join(project_path, "sessions-index.json")
    jsonl_files = sorted(glob.glob(os.path.join(project_path, "*.jsonl")))

    if not jsonl_files:
        return

    # Backup existing index
    if os.path.exists(idx_path):
        os.makedirs(BACKUPS_DIR, exist_ok=True)
        proj_name = os.path.basename(project_path)
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup_path = os.path.join(BACKUPS_DIR, f"sessions-index-{proj_name}-{ts}.json")
        shutil.copy2(idx_path, backup_path)

    entries = []

    for fpath in jsonl_files:
        session_id = os.path.basename(fpath).replace(".jsonl", "")
        if "backup" in session_id:
            continue
        try:
            first_prompt = None
            first_timestamp = None
            last_timestamp = None
            message_count = 0
            git_branch = ""
            project_path_val = ""
            is_sidechain = False

            with open(fpath, "r") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    if first_timestamp is None:
                        ts = obj.get("timestamp")
                        if ts:
                            first_timestamp = ts
                        git_branch = obj.get("gitBranch", git_branch) or git_branch
                        project_path_val = obj.get("cwd", project_path_val) or project_path_val
                        is_sidechain = obj.get("isSidechain", is_sidechain)

                    ts = obj.get("timestamp")
                    if ts:
                        last_timestamp = ts

                    if obj.get("type") == "user" and "message" in obj:
                        msg = obj["message"]
                        if isinstance(msg, dict):
                            content = msg.get("content", "")
                            text = ""
                            if isinstance(content, list):
                                for part in content:
                                    if isinstance(part, dict) and part.get("type") == "text":
                                        text = part["text"]
                                        break
                            elif isinstance(content, str):
                                text = content
                            if text and not text.startswith("<local-command") and not text.startswith("<system"):
                                message_count += 1
                                if first_prompt is None:
                                    first_prompt = text[:200]

            stat = os.stat(fpath)
            file_mtime = int(stat.st_mtime * 1000)

            if not first_timestamp:
                first_timestamp = datetime.fromtimestamp(
                    stat.st_ctime, tz=timezone.utc
                ).isoformat().replace("+00:00", "Z")
            if not last_timestamp:
                last_timestamp = datetime.fromtimestamp(
                    stat.st_mtime, tz=timezone.utc
                ).isoformat().replace("+00:00", "Z")

            entries.append({
                "sessionId": session_id,
                "fullPath": fpath,
                "fileMtime": file_mtime,
                "firstPrompt": first_prompt or "No prompt",
                "summary": first_prompt[:80] if first_prompt else "Session",
                "messageCount": message_count,
                "created": first_timestamp,
                "modified": last_timestamp,
                "gitBranch": git_branch,
                "projectPath": project_path_val or project_path,
                "isSidechain": is_sidechain,
            })
        except Exception:
            continue

    entries.sort(key=lambda x: x.get("modified", ""), reverse=True)

    with open(idx_path, "w") as f:
        json.dump({"version": 1, "entries": entries}, f, indent=2)

    return len(entries)


def main():
    if not os.path.isdir(PROJECTS_DIR):
        return

    for proj in os.listdir(PROJECTS_DIR):
        proj_path = os.path.join(PROJECTS_DIR, proj)
        if not os.path.isdir(proj_path):
            continue
        if not check_index_health(proj_path):
            count = rebuild_index(proj_path)
            if count:
                print(f"[session-index-fix] Rebuilt index for {proj}: {count} sessions")


if __name__ == "__main__":
    main()
