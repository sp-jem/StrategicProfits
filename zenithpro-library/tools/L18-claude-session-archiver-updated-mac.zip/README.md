# Claude Code Session Archiver

Converts all your Claude Code conversation history into searchable markdown files, organized by date. Includes an index generator that creates weekly summaries, monthly summaries, and a master table of contents. Works perfectly with Obsidian.

## What's In This Package

| File | What It Does |
|------|-------------|
| `archive-sessions.py` | Archives Claude Code conversations to markdown |
| `generate-index.py` | Builds weekly/monthly summaries and a master index |
| `fix-session-index.py` | SessionStart hook that fixes resumed conversation tracking |
| `install.sh` | Mac/Linux installer (optional) |
| `install.ps1` | Windows installer (optional) |

## What You Get

**From the archiver:** Each conversation becomes a markdown file with:
- Full transcript (every message, user and assistant)
- Searchable YAML frontmatter (date, time, project, duration, model, session ID)
- Skills used, files modified, auto-detected topics
- Sub-agent conversations stored separately in `subagents/` subfolders
- Incremental mode -- re-run safely without duplicating work

**From the index generator:** Navigation files that make thousands of sessions browsable:
- `_INDEX.md` -- master index with all-time stats, monthly links, workspace breakdown
- `_MONTH-SUMMARY.md` -- monthly overview with weekly links, project breakdown, topics
- `Week-NN.md` -- weekly detail with every session linked, grouped by workspace

**Folder structure:**
```
Your-Archive/
  Conversations/
    _INDEX.md                          <-- Master index
    2026/
      01-January/
        _MONTH-SUMMARY.md             <-- January summary
        weekly/
          Week-02.md                   <-- Weekly summaries
          Week-03.md
        2026-01-15-daily-briefing-ee81.md
        2026-01-16-fix-auth-bug-def6.md
        subagents/                     <-- Sub-agents separated
          2026-01-15-subagent-...md
      02-February/
        ...
```

Your conversations are front and center. Sub-agent sessions are tucked away in their own folder so they don't bury your actual work.

## Requirements

- macOS, Linux, or Windows (with Python)
- Python 3.8+ (ships with macOS -- check with `python3 --version`)
- Claude Code must have been used on this machine
- No external packages needed

## Quick Start

**Step 1: Archive your sessions**
```bash
python3 archive-sessions.py ~/Documents/Claude-Archive
```

**Step 2: Generate the index**
```bash
python3 generate-index.py ~/Documents/Claude-Archive
```

That's it. Open the folder in Obsidian and start browsing from `_INDEX.md`.

## Installation (Optional)

The installers put both scripts somewhere predictable and create shortcuts:

**Mac/Linux:**
```bash
bash install.sh
```

**Windows (PowerShell):**
```powershell
.\install.ps1
```

After installing, you can run:
```bash
archive-sessions ~/Documents/Claude-Archive
archive-index ~/Documents/Claude-Archive
```

## Archiver Usage

### Archive everything
```bash
python3 archive-sessions.py ~/Documents/Claude-Archive
```

### Dry run (preview without writing files)
```bash
python3 archive-sessions.py ~/Documents/Claude-Archive --dry-run
```

### Only recent sessions
```bash
python3 archive-sessions.py ~/Documents/Claude-Archive --since 2026-02-01
```

### Re-archive everything (overwrite existing)
```bash
python3 archive-sessions.py ~/Documents/Claude-Archive --force
```

### Skip sub-agent conversations
```bash
python3 archive-sessions.py ~/Documents/Claude-Archive --no-subagents
```

### Combine options
```bash
python3 archive-sessions.py ~/Documents/Claude-Archive --since 2026-01-01 --no-subagents --dry-run
```

## Index Generator Usage

### Generate all summaries
```bash
python3 generate-index.py ~/Documents/Claude-Archive
```

### Dry run
```bash
python3 generate-index.py ~/Documents/Claude-Archive --dry-run
```

Run the index generator after every archiver run to keep summaries current. It regenerates everything each time (fast -- only reads frontmatter, not full files).

## Session Index Fix (Important)

Claude Code tracks conversations in `sessions-index.json` files. When you **resume** a conversation (instead of starting a new one), the index doesn't always get updated. This means the archiver won't see the new content from resumed sessions.

The `fix-session-index.py` hook solves this. It runs automatically every time Claude Code starts and:
1. Scans all `.jsonl` session files on disk
2. Compares them to what's in `sessions-index.json`
3. If any sessions exist on disk but aren't indexed, rebuilds the index
4. Backs up the old index before replacing it

The installer registers this as a SessionStart hook automatically. If you installed manually, add this to `~/.claude/settings.json`:

```json
{
  "hooks": {
    "SessionStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 ~/.claude/hooks/fix-session-index.py"
          }
        ]
      }
    ]
  }
}
```

## How It Works

### The Archiver

1. **Discovers** all session files in `~/.claude/projects/`
2. **Reads metadata** from `sessions-index.json` when available (summaries, message counts, dates)
3. **Parses** each JSONL transcript file line-by-line (memory-safe for large files)
4. **Extracts** messages, skills used, files modified, tools invoked, topics
5. **Generates** markdown with YAML frontmatter and clean transcript
6. **Saves** main conversations to `Conversations/YYYY/MM-Month/`
7. **Saves** sub-agent conversations to `Conversations/YYYY/MM-Month/subagents/`

### The Index Generator

1. **Scans** all archived `.md` files, reading only YAML frontmatter (fast)
2. **Groups** sessions by week, month, and workspace
3. **Normalizes** project names so the same vault doesn't appear multiple times
4. **Generates** weekly summaries with session listings and Obsidian wiki-links
5. **Generates** monthly summaries with weekly links and project breakdowns
6. **Generates** a master index with all-time stats and Dataview queries

### Incremental Mode (Default)

Re-running the archiver skips sessions that are already archived (matched by session ID in the filename). This means:
- First run: archives everything
- Second run: only archives new sessions since last run
- Use `--force` to override and re-archive everything

### What Gets Parsed

| Content Type | How It's Handled |
|-------------|-----------------|
| User text messages | Full text in transcript |
| Assistant text | Full text in transcript |
| Tool calls | Noted as `[Used tool: ToolName]` |
| Skills invoked | Listed in frontmatter + metadata |
| Files written/edited | Listed in frontmatter + metadata |
| Images in messages | Noted as `[Image attached]` |
| Tool results | Noted as `[Tool result]` (content skipped -- too large) |
| Thinking blocks | Skipped (internal reasoning) |
| Sub-agent sessions | Separate files in `subagents/` subfolder |

## Obsidian Integration

### Dataview Queries

Once archived, you can query conversations in Obsidian with Dataview:

**Recent conversations (excludes sub-agents and index files):**
```dataview
TABLE date, duration, summary
FROM "Conversations"
WHERE !contains(file.path, "subagents")
  AND !contains(file.name, "_")
  AND !contains(file.name, "Week-")
SORT date DESC
LIMIT 20
```

**By project:**
```dataview
TABLE date, summary, duration
FROM "Conversations"
WHERE contains(project, "Active-Brain")
  AND !contains(file.path, "subagents")
SORT date DESC
```

**By topic:**
```dataview
TABLE date, project, duration
FROM "Conversations"
WHERE contains(topics, "coding")
  AND !contains(file.path, "subagents")
```

**By skill used:**
```dataview
TABLE date, project, summary
FROM "Conversations"
WHERE contains(skills-used, "deep-research")
```

**Sessions by project (grouped):**
```dataview
TABLE length(rows) as Sessions
FROM "Conversations"
WHERE !contains(file.path, "subagents")
  AND !contains(file.name, "_")
  AND !contains(file.name, "Week-")
GROUP BY project
SORT length(rows) DESC
```

**Or just use Obsidian's full-text search (Cmd+Shift+F) to find any conversation by content.**

## Daily Workflow

For the best experience, run both scripts daily:

```bash
# Archive any new sessions
python3 archive-sessions.py ~/Documents/Claude-Archive

# Rebuild the index
python3 generate-index.py ~/Documents/Claude-Archive
```

Or if you installed the aliases:
```bash
archive-sessions ~/Documents/Claude-Archive && archive-index ~/Documents/Claude-Archive
```

The archiver takes seconds for incremental runs (just checks what's new). The index generator takes seconds to scan all frontmatter and rebuild summaries.

## Troubleshooting

**"No Claude Code sessions found"**
Claude Code hasn't been used on this machine, or sessions are stored elsewhere. Check if `~/.claude/projects/` exists.

**"python3: command not found"**
Install Python: https://www.python.org/downloads/
On Mac: `xcode-select --install` also works.

**Permission errors on output folder**
Make sure you have write access to the target directory.

**Large sessions take a while**
Sessions over 50 MB are flagged with a warning. The script processes them line-by-line so memory isn't an issue, but parsing takes time.

**Some filenames are long/ugly**
Filenames are generated from session summaries when available, or from the first user message otherwise. The session ID suffix (8 chars) ensures uniqueness.

**"Parse warnings in X session(s)"**
Some JSONL lines couldn't be parsed (usually truncated writes). The rest of the session is still archived. This is informational, not an error.

**Index shows "0 messages" for old sessions**
Sessions archived with an older version of the script may not have `message-count` in their frontmatter. The index reports what's available. Re-archive with `--force` to regenerate those files with full metadata.

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success (all sessions processed) |
| 1 | Partial failure (some sessions had errors) |
| 2 | Total failure or bad arguments |
