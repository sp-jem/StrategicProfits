#!/bin/bash
# Claude Code Session Archiver - Mac/Linux Installer
# Copies the script to ~/.claude/tools/ and creates a shell alias

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/.claude/tools"
HOOKS_DIR="$HOME/.claude/hooks"
SCRIPT_NAME="archive-sessions.py"
INDEX_NAME="generate-index.py"
HOOK_NAME="fix-session-index.py"

echo "========================================"
echo "  Claude Code Session Archiver Installer"
echo "========================================"
echo ""

# Check Python
if ! command -v python3 &>/dev/null; then
    echo "ERROR: python3 not found."
    echo "Install Python 3.8+: https://www.python.org/downloads/"
    echo "On Mac: xcode-select --install"
    exit 1
fi

PYVER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "Python version: $PYVER"

# Check Claude Code sessions exist
if [ ! -d "$HOME/.claude/projects" ]; then
    echo ""
    echo "WARNING: No Claude Code sessions found at ~/.claude/projects/"
    echo "The archiver won't have anything to archive until you use Claude Code."
    echo "Continuing installation anyway..."
    echo ""
fi

# Create install directory
mkdir -p "$INSTALL_DIR"

# Copy scripts
cp "$SCRIPT_DIR/$SCRIPT_NAME" "$INSTALL_DIR/$SCRIPT_NAME"
chmod +x "$INSTALL_DIR/$SCRIPT_NAME"
echo "Installed: $INSTALL_DIR/$SCRIPT_NAME"

cp "$SCRIPT_DIR/$INDEX_NAME" "$INSTALL_DIR/$INDEX_NAME"
chmod +x "$INSTALL_DIR/$INDEX_NAME"
echo "Installed: $INSTALL_DIR/$INDEX_NAME"

# Install session index fix hook
mkdir -p "$HOOKS_DIR"
cp "$SCRIPT_DIR/$HOOK_NAME" "$HOOKS_DIR/$HOOK_NAME"
chmod +x "$HOOKS_DIR/$HOOK_NAME"
echo "Installed: $HOOKS_DIR/$HOOK_NAME"

# Register the SessionStart hook in settings.json
SETTINGS_FILE="$HOME/.claude/settings.json"
if [ -f "$SETTINGS_FILE" ]; then
    # Check if hook is already registered
    if ! grep -q "fix-session-index.py" "$SETTINGS_FILE" 2>/dev/null; then
        python3 -c "
import json, os
path = os.path.expanduser('$SETTINGS_FILE')
with open(path) as f:
    settings = json.load(f)
hooks = settings.setdefault('hooks', {})
ss = hooks.setdefault('SessionStart', [])
# Find or create the entry with hooks array
entry = None
for e in ss:
    if 'hooks' in e:
        entry = e
        break
if entry is None:
    entry = {'hooks': []}
    ss.append(entry)
# Add our hook if not present
hook_cmd = '/opt/homebrew/bin/python3 ~/.claude/hooks/fix-session-index.py'
# Use system python on Linux
import platform
if platform.system() != 'Darwin':
    hook_cmd = 'python3 ~/.claude/hooks/fix-session-index.py'
existing = [h.get('command','') for h in entry['hooks']]
if not any('fix-session-index' in c for c in existing):
    entry['hooks'].append({'type': 'command', 'command': hook_cmd})
with open(path, 'w') as f:
    json.dump(settings, f, indent=2)
print('Hook registered in settings.json')
"
    else
        echo "Hook already registered in settings.json"
    fi
else
    # Create settings.json with the hook
    python3 -c "
import json, os, platform
path = os.path.expanduser('$SETTINGS_FILE')
hook_cmd = 'python3 ~/.claude/hooks/fix-session-index.py'
if platform.system() == 'Darwin':
    hook_cmd = '/opt/homebrew/bin/python3 ~/.claude/hooks/fix-session-index.py'
settings = {'hooks': {'SessionStart': [{'hooks': [{'type': 'command', 'command': hook_cmd}]}]}}
os.makedirs(os.path.dirname(path), exist_ok=True)
with open(path, 'w') as f:
    json.dump(settings, f, indent=2)
print('Created settings.json with hook')
"
fi

# Create aliases
ALIAS_LINE="alias archive-sessions='python3 $INSTALL_DIR/$SCRIPT_NAME'"
ALIAS_LINE_2="alias archive-index='python3 $INSTALL_DIR/$INDEX_NAME'"
SHELL_NAME=$(basename "$SHELL")
RC_FILE=""

if [ "$SHELL_NAME" = "zsh" ]; then
    RC_FILE="$HOME/.zshrc"
elif [ "$SHELL_NAME" = "bash" ]; then
    if [ -f "$HOME/.bash_profile" ]; then
        RC_FILE="$HOME/.bash_profile"
    else
        RC_FILE="$HOME/.bashrc"
    fi
fi

if [ -n "$RC_FILE" ]; then
    # Remove old aliases if present
    if grep -q "alias archive-sessions=" "$RC_FILE" 2>/dev/null; then
        grep -v "alias archive-sessions=" "$RC_FILE" > "${RC_FILE}.tmp"
        mv "${RC_FILE}.tmp" "$RC_FILE"
    fi
    if grep -q "alias archive-index=" "$RC_FILE" 2>/dev/null; then
        grep -v "alias archive-index=" "$RC_FILE" > "${RC_FILE}.tmp"
        mv "${RC_FILE}.tmp" "$RC_FILE"
    fi
    echo "$ALIAS_LINE" >> "$RC_FILE"
    echo "$ALIAS_LINE_2" >> "$RC_FILE"
    echo "Aliases added to $RC_FILE"
fi

echo ""
echo "========================================"
echo "  Installation complete!"
echo "========================================"
echo ""
echo "Usage:"
echo "  archive-sessions ~/Documents/Claude-Archive        # Archive sessions"
echo "  archive-index ~/Documents/Claude-Archive           # Generate index"
echo "  archive-sessions ~/Documents/Claude-Archive --dry-run  # Preview"
echo ""
if [ -n "$RC_FILE" ]; then
    echo "(Run 'source $RC_FILE' to use aliases in this terminal)"
fi
