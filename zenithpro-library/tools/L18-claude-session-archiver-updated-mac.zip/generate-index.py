#!/usr/bin/env python3
"""
Archive Index Generator
Generates weekly summaries, monthly summaries, and a master index for the
Claude Code Session Archive vault.

Usage:
    python3 generate-index.py ARCHIVE_FOLDER
    python3 generate-index.py ARCHIVE_FOLDER --dry-run

Reads YAML frontmatter from all archived .md files and produces:
- Weekly summaries: Conversations/YYYY/MM-Month/weekly/Week-NN.md
- Monthly summaries: Conversations/YYYY/MM-Month/_MONTH-SUMMARY.md
- Master index: Conversations/_INDEX.md

Designed to run after archive-sessions.py (e.g., in the daily briefing).
Regenerates all summaries each run (fast -- just reads frontmatter, not full files).
"""

import os
import re
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args():
    args = sys.argv[1:]
    if not args or "--help" in args or "-h" in args:
        print(__doc__.strip())
        sys.exit(0)

    opts = {"output": None, "dry_run": False}
    positional = []

    for a in args:
        if a == "--dry-run":
            opts["dry_run"] = True
        elif a.startswith("-"):
            print(f"Error: Unknown option: {a}", file=sys.stderr)
            sys.exit(2)
        else:
            positional.append(a)

    if not positional:
        print("Error: Missing ARCHIVE_FOLDER argument", file=sys.stderr)
        sys.exit(2)

    opts["output"] = Path(os.path.expanduser(positional[0]))
    return opts


# ---------------------------------------------------------------------------
# Frontmatter Parser
# ---------------------------------------------------------------------------

def parse_frontmatter(filepath):
    """Read YAML frontmatter from a markdown file. Returns dict or None."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            first_line = f.readline().strip()
            if first_line != "---":
                return None
            yaml_lines = []
            for line in f:
                if line.strip() == "---":
                    break
                yaml_lines.append(line)
            else:
                return None  # No closing ---
        return parse_yaml_simple(yaml_lines)
    except (OSError, UnicodeDecodeError):
        return None


def parse_yaml_simple(lines):
    """Minimal YAML parser for our frontmatter (no dependency on PyYAML)."""
    data = {}
    for line in lines:
        line = line.rstrip("\n")
        if not line.strip() or line.strip().startswith("#"):
            continue
        match = re.match(r'^(\S[\w-]+):\s*(.*)', line)
        if match:
            key = match.group(1)
            val = match.group(2).strip()
            # Remove quotes
            if val.startswith('"') and val.endswith('"'):
                val = val[1:-1].replace('\\"', '"')
            elif val.startswith("'") and val.endswith("'"):
                val = val[1:-1]
            # Parse lists
            if val.startswith("[") and val.endswith("]"):
                inner = val[1:-1]
                if not inner.strip():
                    val = []
                else:
                    items = []
                    for item in re.findall(r'"([^"]*)"', inner):
                        items.append(item)
                    if not items:
                        items = [i.strip().strip('"').strip("'") for i in inner.split(",")]
                    val = [i for i in items if i]
            # Parse booleans
            elif val.lower() == "true":
                val = True
            elif val.lower() == "false":
                val = False
            # Parse integers
            elif val.isdigit():
                val = int(val)
            data[key] = val
    return data


# ---------------------------------------------------------------------------
# Project Name Normalization
# ---------------------------------------------------------------------------

# If you previously archived sessions with an older version of the archiver that
# split hyphens in project names (turning "My-Project" into "My/Project"), you can
# add known broken→fixed mappings here so the index groups them correctly.
# Example: "My/Project": "My-Project"
_PROJECT_NORMALIZATIONS = {}


def normalize_project(name):
    """Normalize a project name for consistent grouping.

    Handles two formats:
    - New archiver output: ~/Documents/Obsidian/MyVault (already clean)
    - Old archiver output: Users/username/Documents/Obsidian/My/Vault (needs fixing)
    """
    if not name:
        return "Unknown"

    # Already normalized (starts with ~)
    if name.startswith("~"):
        return name

    # Replace home dir prefix with ~
    # Works for any username on any platform
    home = str(Path.home()).lstrip("/")
    if name.startswith(home):
        name = "~" + name[len(home):]
    elif "/" in home:
        # Try just the Users/username part (macOS/Linux)
        parts = home.split("/")
        if len(parts) >= 2:
            short_prefix = "/".join(parts[:2])
            if name.startswith(short_prefix):
                name = "~" + name[len(short_prefix):]

    # Apply any user-defined normalizations
    for broken, fixed in _PROJECT_NORMALIZATIONS.items():
        name = name.replace(broken, fixed)

    # Clean up doubled slashes
    while "//" in name:
        name = name.replace("//", "/")

    return name.rstrip("/")


def vault_group(project):
    """Extract a clean workspace/vault name from a project path.

    Strips common prefixes (~/Documents/, ~/Documents/Obsidian/) to find
    the meaningful top-level directory name for grouping.
    """
    if not project or project in ("~", "~/"):
        return "Home (~)"

    name = project

    # Strip ~ and common prefixes to find the vault/workspace name
    prefixes = [
        "~/Documents/Obsidian/",
        "~/Documents/",
        "~/",
    ]
    for prefix in prefixes:
        if name.startswith(prefix):
            name = name[len(prefix):]
            break

    # Take the first path component as the workspace name
    if "/" in name:
        name = name.split("/")[0]

    return name if name else project


# ---------------------------------------------------------------------------
# Session Collection
# ---------------------------------------------------------------------------

def collect_sessions(archive_base):
    """Collect frontmatter from all archived sessions."""
    conv_dir = archive_base / "Conversations"
    if not conv_dir.exists():
        return [], []

    main_sessions = []
    subagent_sessions = []

    for md_file in sorted(conv_dir.rglob("*.md")):
        # Skip our own generated index/summary files
        if md_file.name.startswith("_") or md_file.name.startswith("Week-"):
            continue
        if md_file.parent.name == "weekly":
            continue

        fm = parse_frontmatter(md_file)
        if not fm:
            continue

        # Normalize project name for consistent grouping
        if "project" in fm:
            fm["project"] = normalize_project(fm["project"])

        fm["_filepath"] = md_file
        fm["_filename"] = md_file.name
        fm["_relative"] = md_file.relative_to(conv_dir)

        is_sub = fm.get("is-subagent", False) or "/subagents/" in str(md_file)
        if is_sub:
            subagent_sessions.append(fm)
        else:
            main_sessions.append(fm)

    return main_sessions, subagent_sessions


def parse_date(fm):
    """Extract a date object from frontmatter."""
    d = fm.get("date", "")
    if isinstance(d, str):
        try:
            return datetime.strptime(d, "%Y-%m-%d").date()
        except ValueError:
            pass
    return None


def get_week_key(d):
    """Return (year, week_number) for ISO week."""
    iso = d.isocalendar()
    return (iso[0], iso[1])


def week_date_range(year, week):
    """Return (monday, sunday) for a given ISO week."""
    jan4 = datetime(year, 1, 4).date()
    start = jan4 - timedelta(days=jan4.weekday())
    monday = start + timedelta(weeks=week - 1)
    sunday = monday + timedelta(days=6)
    return monday, sunday


# ---------------------------------------------------------------------------
# Grouping
# ---------------------------------------------------------------------------

def group_by_month(sessions):
    """Group sessions by (year, month_num)."""
    groups = defaultdict(list)
    for fm in sessions:
        d = parse_date(fm)
        if d:
            groups[(d.year, d.month)].append(fm)
    return dict(groups)


def group_by_week(sessions):
    """Group sessions by (year, week_number)."""
    groups = defaultdict(list)
    for fm in sessions:
        d = parse_date(fm)
        if d:
            groups[get_week_key(d)].append(fm)
    return dict(groups)


def group_by_project(sessions):
    """Group sessions by project name."""
    groups = defaultdict(list)
    for fm in sessions:
        proj = fm.get("project", "Unknown")
        groups[proj].append(fm)
    return dict(groups)


def group_by_vault(sessions):
    """Group sessions by vault/workspace using vault_group()."""
    groups = defaultdict(list)
    for fm in sessions:
        proj = fm.get("project", "Unknown")
        vg = vault_group(proj)
        groups[vg].append(fm)
    return dict(groups)


def group_by_topic(sessions):
    """Count topic occurrences. Normalizes hashtag prefixes."""
    counts = defaultdict(int)
    for fm in sessions:
        topics = fm.get("topics", [])
        if isinstance(topics, list):
            for t in topics:
                # Normalize: strip # prefix for consistency
                t = t.lstrip("#").strip()
                if t:
                    counts[t] += 1
    return dict(counts)


# ---------------------------------------------------------------------------
# Weekly Summary Generator
# ---------------------------------------------------------------------------

def generate_weekly_summary(year, week, main_sessions, sub_sessions):
    """Generate markdown for a weekly summary."""
    monday, sunday = week_date_range(year, week)
    month_name = monday.strftime("%B %Y")

    lines = ["---"]
    lines.append(f"type: weekly-summary")
    lines.append(f"week: {week}")
    lines.append(f"year: {year}")
    lines.append(f"date-range: \"{monday.strftime('%Y-%m-%d')} to {sunday.strftime('%Y-%m-%d')}\"")
    lines.append(f"sessions: {len(main_sessions)}")
    lines.append(f"subagent-sessions: {len(sub_sessions)}")
    lines.append("---")
    lines.append("")
    lines.append(f"# Week {week} ({monday.strftime('%b %d')} - {sunday.strftime('%b %d, %Y')})")
    lines.append("")

    # Quick stats
    total_msgs = sum(fm.get("message-count", 0) for fm in main_sessions)
    projects = group_by_project(main_sessions)
    topics = group_by_topic(main_sessions)

    lines.append(f"**Sessions:** {len(main_sessions)} conversations + {len(sub_sessions)} sub-agents  ")
    lines.append(f"**Messages:** {total_msgs:,}  ")
    lines.append(f"**Projects:** {len(projects)}  ")
    lines.append("")

    # By workspace
    vaults = group_by_vault(main_sessions)
    if vaults:
        lines.append("## By Workspace")
        lines.append("")
        for vault_name in sorted(vaults.keys(), key=lambda v: -len(vaults[v])):
            sess = vaults[vault_name]
            lines.append(f"### {vault_name} ({len(sess)} sessions)")
            lines.append("")
            # Sort by date
            sess_sorted = sorted(sess, key=lambda fm: fm.get("date", ""))
            for fm in sess_sorted:
                date = fm.get("date", "?")
                duration = fm.get("duration", "?")
                link = f"[[{fm['_filename'][:-3]}]]" if fm.get("_filename") else "Untitled"
                lines.append(f"- **{date}** {link} ({duration})")
            lines.append("")

    # Top topics
    if topics:
        lines.append("## Topics")
        lines.append("")
        for topic, count in sorted(topics.items(), key=lambda x: -x[1])[:10]:
            lines.append(f"- {topic}: {count} sessions")
        lines.append("")

    # Skills used this week
    all_skills = set()
    for fm in main_sessions:
        skills = fm.get("skills-used", [])
        if isinstance(skills, list):
            all_skills.update(skills)
    if all_skills:
        lines.append("## Skills Used")
        lines.append("")
        for skill in sorted(all_skills):
            lines.append(f"- {skill}")
        lines.append("")

    # Sub-agent summary (just counts, not full listings)
    if sub_sessions:
        lines.append("## Sub-agent Activity")
        lines.append("")
        lines.append(f"{len(sub_sessions)} sub-agent sessions ran this week supporting the conversations above.")
        sub_vaults = group_by_vault(sub_sessions)
        for vault_name in sorted(sub_vaults.keys()):
            lines.append(f"- {vault_name}: {len(sub_vaults[vault_name])} sub-agents")
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Monthly Summary Generator
# ---------------------------------------------------------------------------

def generate_monthly_summary(year, month, main_sessions, sub_sessions):
    """Generate markdown for a monthly summary."""
    month_name = datetime(year, month, 1).strftime("%B %Y")
    month_folder = datetime(year, month, 1).strftime("%m-%B")

    lines = ["---"]
    lines.append(f"type: monthly-summary")
    lines.append(f"month: {month}")
    lines.append(f"year: {year}")
    lines.append(f"month-name: \"{month_name}\"")
    lines.append(f"sessions: {len(main_sessions)}")
    lines.append(f"subagent-sessions: {len(sub_sessions)}")
    lines.append("---")
    lines.append("")
    lines.append(f"# {month_name} Summary")
    lines.append("")

    # Overview
    total_msgs = sum(fm.get("message-count", 0) for fm in main_sessions)
    projects = group_by_project(main_sessions)
    topics = group_by_topic(main_sessions)

    lines.append("## Overview")
    lines.append("")
    lines.append(f"| Metric | Count |")
    lines.append(f"|--------|-------|")
    lines.append(f"| Conversations | {len(main_sessions)} |")
    lines.append(f"| Sub-agents | {len(sub_sessions)} |")
    lines.append(f"| Messages | {total_msgs:,} |")
    lines.append(f"| Projects | {len(projects)} |")
    lines.append("")

    # Weekly breakdown with links
    weeks = group_by_week(main_sessions)
    sub_weeks = group_by_week(sub_sessions)
    if weeks:
        lines.append("## Weekly Breakdown")
        lines.append("")
        for (wy, wn) in sorted(weeks.keys()):
            monday, sunday = week_date_range(wy, wn)
            w_sessions = weeks[(wy, wn)]
            w_sub = sub_weeks.get((wy, wn), [])
            week_link = f"[[Week-{wn:02d}]]"
            lines.append(f"- **{week_link}** ({monday.strftime('%b %d')} - {sunday.strftime('%b %d')}): "
                        f"{len(w_sessions)} sessions, {len(w_sub)} sub-agents")
        lines.append("")

    # By workspace
    vaults = group_by_vault(main_sessions)
    if vaults:
        lines.append("## By Workspace")
        lines.append("")
        for vault_name in sorted(vaults.keys(), key=lambda v: -len(vaults[v])):
            sess = vaults[vault_name]
            v_msgs = sum(fm.get("message-count", 0) for fm in sess)
            lines.append(f"### {vault_name}")
            lines.append(f"**{len(sess)} sessions, {v_msgs:,} messages**")
            lines.append("")
            # Show first 15 sessions, summarize rest
            sess_sorted = sorted(sess, key=lambda fm: fm.get("date", ""))
            display = sess_sorted[:15]
            for fm in display:
                date = fm.get("date", "?")
                link = f"[[{fm['_filename'][:-3]}]]" if fm.get("_filename") else "Untitled"
                lines.append(f"- {date}: {link}")
            if len(sess_sorted) > 15:
                lines.append(f"- ... and {len(sess_sorted) - 15} more sessions")
            lines.append("")

    # Top topics
    if topics:
        lines.append("## Top Topics")
        lines.append("")
        for topic, count in sorted(topics.items(), key=lambda x: -x[1])[:15]:
            bar = "#" * min(count, 30)
            lines.append(f"- **{topic}**: {count} {bar}")
        lines.append("")

    # All skills used
    all_skills = set()
    for fm in main_sessions:
        skills = fm.get("skills-used", [])
        if isinstance(skills, list):
            all_skills.update(skills)
    if all_skills:
        lines.append("## Skills Used")
        lines.append("")
        for skill in sorted(all_skills):
            lines.append(f"- {skill}")
        lines.append("")

    # Models used
    models = defaultdict(int)
    for fm in main_sessions:
        m = fm.get("model", "unknown")
        if m:
            models[m] += 1
    if models:
        lines.append("## Models Used")
        lines.append("")
        for model, count in sorted(models.items(), key=lambda x: -x[1]):
            lines.append(f"- {model}: {count} sessions")
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Master Index Generator
# ---------------------------------------------------------------------------

def generate_master_index(archive_base, main_sessions, sub_sessions):
    """Generate the top-level master index."""
    lines = ["---"]
    lines.append("type: master-index")
    lines.append(f"generated: \"{datetime.now().strftime('%Y-%m-%d %H:%M')}\"")
    lines.append(f"total-sessions: {len(main_sessions)}")
    lines.append(f"total-subagents: {len(sub_sessions)}")
    lines.append("---")
    lines.append("")
    lines.append("# Claude Code Session Archive")
    lines.append("")
    lines.append(f"*Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M')}*")
    lines.append("")

    # Grand totals
    total_msgs = sum(fm.get("message-count", 0) for fm in main_sessions)
    projects = group_by_project(main_sessions)

    lines.append("## Archive Stats")
    lines.append("")
    lines.append(f"| Metric | Count |")
    lines.append(f"|--------|-------|")
    lines.append(f"| Your conversations | {len(main_sessions):,} |")
    lines.append(f"| Sub-agent sessions | {len(sub_sessions):,} |")
    lines.append(f"| Total messages | {total_msgs:,} |")
    lines.append(f"| Projects | {len(projects)} |")
    lines.append("")

    # Monthly navigation
    months = group_by_month(main_sessions)
    sub_months = group_by_month(sub_sessions)

    lines.append("## By Month")
    lines.append("")
    for (y, m) in sorted(months.keys(), reverse=True):
        month_name = datetime(y, m, 1).strftime("%B %Y")
        month_folder = datetime(y, m, 1).strftime("%m-%B")
        m_sessions = months[(y, m)]
        m_sub = sub_months.get((y, m), [])
        m_msgs = sum(fm.get("message-count", 0) for fm in m_sessions)
        link = f"[[{y}/{month_folder}/_MONTH-SUMMARY|{month_name}]]"
        lines.append(f"### {link}")
        lines.append(f"{len(m_sessions)} conversations, {len(m_sub)} sub-agents, {m_msgs:,} messages")
        lines.append("")

        # Week links for this month
        m_weeks = group_by_week(m_sessions)
        for (wy, wn) in sorted(m_weeks.keys()):
            monday, sunday = week_date_range(wy, wn)
            w_count = len(m_weeks[(wy, wn)])
            week_link = f"[[{y}/{month_folder}/weekly/Week-{wn:02d}|Week {wn}]]"
            lines.append(f"- {week_link} ({monday.strftime('%b %d')}-{sunday.strftime('%b %d')}): {w_count} sessions")
        lines.append("")

    # By vault/workspace (all-time)
    vaults = group_by_vault(main_sessions)
    lines.append("## By Workspace (All Time)")
    lines.append("")
    for vault_name in sorted(vaults.keys(), key=lambda v: -len(vaults[v])):
        v_sessions = vaults[vault_name]
        count = len(v_sessions)
        v_msgs = sum(fm.get("message-count", 0) for fm in v_sessions)
        lines.append(f"- **{vault_name}**: {count} sessions, {v_msgs:,} messages")
    lines.append("")

    # Top topics (all-time)
    topics = group_by_topic(main_sessions)
    if topics:
        lines.append("## Top Topics (All Time)")
        lines.append("")
        for topic, count in sorted(topics.items(), key=lambda x: -x[1])[:20]:
            lines.append(f"- **{topic}**: {count} sessions")
        lines.append("")

    # Dataview queries
    lines.append("## Useful Dataview Queries")
    lines.append("")
    lines.append("### Recent conversations (last 7 days)")
    lines.append("```dataview")
    lines.append('TABLE date, duration, summary')
    lines.append('FROM "Conversations"')
    lines.append('WHERE !contains(file.path, "subagents") AND !contains(file.name, "_") AND !contains(file.name, "Week-")')
    lines.append('SORT date DESC')
    lines.append('LIMIT 20')
    lines.append("```")
    lines.append("")
    lines.append("### Sessions by project")
    lines.append("```dataview")
    lines.append('TABLE length(rows) as Sessions')
    lines.append('FROM "Conversations"')
    lines.append('WHERE !contains(file.path, "subagents") AND !contains(file.name, "_") AND !contains(file.name, "Week-")')
    lines.append('GROUP BY project')
    lines.append('SORT length(rows) DESC')
    lines.append("```")
    lines.append("")
    lines.append("### Sessions using a specific skill")
    lines.append("```dataview")
    lines.append('TABLE date, summary')
    lines.append('FROM "Conversations"')
    lines.append('WHERE contains(skills-used, "daily-briefing")')
    lines.append('SORT date DESC')
    lines.append("```")
    lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    opts = parse_args()
    archive_base = opts["output"]
    conv_dir = archive_base / "Conversations"

    if not conv_dir.exists():
        print(f"Error: {conv_dir} does not exist", file=sys.stderr)
        sys.exit(2)

    print("=" * 60, file=sys.stderr)
    print("  ARCHIVE INDEX GENERATOR", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    print(f"  Archive: {archive_base}", file=sys.stderr)
    if opts["dry_run"]:
        print(f"  Mode:    DRY RUN", file=sys.stderr)
    print("=" * 60, file=sys.stderr)

    # Collect all sessions
    print("\nScanning archive...", file=sys.stderr)
    main_sessions, sub_sessions = collect_sessions(archive_base)
    print(f"Found {len(main_sessions)} conversations + {len(sub_sessions)} sub-agents", file=sys.stderr)

    if not main_sessions:
        print("No sessions found. Nothing to index.", file=sys.stderr)
        sys.exit(0)

    files_written = 0

    # Generate weekly summaries
    print("\nGenerating weekly summaries...", file=sys.stderr)
    main_by_week = group_by_week(main_sessions)
    sub_by_week = group_by_week(sub_sessions)

    for (year, week) in sorted(main_by_week.keys()):
        w_main = main_by_week[(year, week)]
        w_sub = sub_by_week.get((year, week), [])

        # Determine which month folder this week belongs to
        # Use the Monday of the week to pick the month
        monday, _ = week_date_range(year, week)
        month_folder = monday.strftime("%m-%B")
        week_dir = conv_dir / str(monday.year) / month_folder / "weekly"

        content = generate_weekly_summary(year, week, w_main, w_sub)
        out_path = week_dir / f"Week-{week:02d}.md"

        if opts["dry_run"]:
            print(f"  Would write: {out_path.relative_to(archive_base)}", file=sys.stderr)
        else:
            week_dir.mkdir(parents=True, exist_ok=True)
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(content)
        files_written += 1

    # Generate monthly summaries
    print("Generating monthly summaries...", file=sys.stderr)
    main_by_month = group_by_month(main_sessions)
    sub_by_month = group_by_month(sub_sessions)

    for (year, month) in sorted(main_by_month.keys()):
        m_main = main_by_month[(year, month)]
        m_sub = sub_by_month.get((year, month), [])

        month_folder = datetime(year, month, 1).strftime("%m-%B")
        month_dir = conv_dir / str(year) / month_folder

        content = generate_monthly_summary(year, month, m_main, m_sub)
        out_path = month_dir / "_MONTH-SUMMARY.md"

        if opts["dry_run"]:
            print(f"  Would write: {out_path.relative_to(archive_base)}", file=sys.stderr)
        else:
            month_dir.mkdir(parents=True, exist_ok=True)
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(content)
        files_written += 1

    # Generate master index
    print("Generating master index...", file=sys.stderr)
    content = generate_master_index(archive_base, main_sessions, sub_sessions)
    out_path = conv_dir / "_INDEX.md"

    if opts["dry_run"]:
        print(f"  Would write: {out_path.relative_to(archive_base)}", file=sys.stderr)
    else:
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(content)
    files_written += 1

    # Report
    print(f"\n{'Would write' if opts['dry_run'] else 'Wrote'} {files_written} files:", file=sys.stderr)
    print(f"  Weekly summaries: {len(main_by_week)}", file=sys.stderr)
    print(f"  Monthly summaries: {len(main_by_month)}", file=sys.stderr)
    print(f"  Master index: 1", file=sys.stderr)
    print(f"\n  Output: {conv_dir}", file=sys.stderr)
    print("=" * 60, file=sys.stderr)


if __name__ == "__main__":
    main()
