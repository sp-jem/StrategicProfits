# Claude Code Session Archiver - Windows (PowerShell) Installer
# Copies the script to ~/.claude/tools/ and creates a PowerShell alias

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDir = Join-Path $env:USERPROFILE ".claude\tools"
$HooksDir = Join-Path $env:USERPROFILE ".claude\hooks"
$ScriptName = "archive-sessions.py"
$IndexName = "generate-index.py"
$HookName = "fix-session-index.py"

Write-Host "========================================"
Write-Host "  Claude Code Session Archiver Installer"
Write-Host "========================================"
Write-Host ""

# Check Python
try {
    $pyver = python3 --version 2>&1
    Write-Host "Python version: $pyver"
} catch {
    try {
        $pyver = python --version 2>&1
        Write-Host "Python version: $pyver"
    } catch {
        Write-Host "ERROR: Python not found."
        Write-Host "Install Python 3.8+: https://www.python.org/downloads/"
        exit 1
    }
}

# Check Claude Code sessions exist
$ProjectsDir = Join-Path $env:USERPROFILE ".claude\projects"
if (-not (Test-Path $ProjectsDir)) {
    Write-Host ""
    Write-Host "WARNING: No Claude Code sessions found at $ProjectsDir"
    Write-Host "The archiver won't have anything to archive until you use Claude Code."
    Write-Host "Continuing installation anyway..."
    Write-Host ""
}

# Create install directory
if (-not (Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
}

# Copy scripts
$Source = Join-Path $ScriptDir $ScriptName
$Dest = Join-Path $InstallDir $ScriptName
Copy-Item $Source $Dest -Force
Write-Host "Installed: $Dest"

$IndexSource = Join-Path $ScriptDir $IndexName
$IndexDest = Join-Path $InstallDir $IndexName
Copy-Item $IndexSource $IndexDest -Force
Write-Host "Installed: $IndexDest"

# Install session index fix hook
if (-not (Test-Path $HooksDir)) {
    New-Item -ItemType Directory -Path $HooksDir -Force | Out-Null
}
$HookSource = Join-Path $ScriptDir $HookName
$HookDest = Join-Path $HooksDir $HookName
Copy-Item $HookSource $HookDest -Force
Write-Host "Installed: $HookDest"

# Register the SessionStart hook in settings.json
$SettingsFile = Join-Path $env:USERPROFILE ".claude\settings.json"
$HookCmd = "python3 ~/.claude/hooks/fix-session-index.py"

if (Test-Path $SettingsFile) {
    $content = Get-Content $SettingsFile -Raw | ConvertFrom-Json
    if (-not $content.hooks) {
        $content | Add-Member -NotePropertyName "hooks" -NotePropertyValue @{} -Force
    }
    $needsAdd = $true
    $raw = Get-Content $SettingsFile -Raw
    if ($raw -match "fix-session-index") { $needsAdd = $false }
    if ($needsAdd) {
        $hookEntry = @{ "type" = "command"; "command" = $HookCmd }
        if (-not $content.hooks.SessionStart) {
            $content.hooks | Add-Member -NotePropertyName "SessionStart" -NotePropertyValue @(@{ "hooks" = @($hookEntry) }) -Force
        } else {
            $content.hooks.SessionStart[0].hooks += $hookEntry
        }
        $content | ConvertTo-Json -Depth 10 | Set-Content $SettingsFile
        Write-Host "Hook registered in settings.json"
    } else {
        Write-Host "Hook already registered in settings.json"
    }
} else {
    $settings = @{
        hooks = @{
            SessionStart = @(@{
                hooks = @(@{ type = "command"; command = $HookCmd })
            })
        }
    }
    $settings | ConvertTo-Json -Depth 10 | Set-Content $SettingsFile
    Write-Host "Created settings.json with hook"
}

# Create PowerShell alias via profile
$AliasFunction = @"

# Claude Code Session Archiver aliases
function archive-sessions { python3 "$Dest" @args }
function archive-index { python3 "$IndexDest" @args }
"@

$ProfilePath = $PROFILE.CurrentUserCurrentHost
$ProfileDir = Split-Path -Parent $ProfilePath

if (-not (Test-Path $ProfileDir)) {
    New-Item -ItemType Directory -Path $ProfileDir -Force | Out-Null
}

if (Test-Path $ProfilePath) {
    # Remove old aliases if present (handles both singular and plural comment formats)
    $content = Get-Content $ProfilePath -Raw
    $content = $content -replace '(?m)^# Claude Code Session Archiver alias(es)?\r?\n(function archive-(sessions|index).*\r?\n?)*', ''
    Set-Content $ProfilePath $content.Trim()
}

Add-Content $ProfilePath $AliasFunction
Write-Host "Alias added to $ProfilePath"

Write-Host ""
Write-Host "========================================"
Write-Host "  Installation complete!"
Write-Host "========================================"
Write-Host ""
Write-Host "Usage:"
Write-Host "  archive-sessions ~\Documents\Claude-Archive        # Archive sessions"
Write-Host "  archive-index ~\Documents\Claude-Archive           # Generate index"
Write-Host "  archive-sessions ~\Documents\Claude-Archive --dry-run  # Preview"
