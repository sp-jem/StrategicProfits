#!/bin/bash
# Distinction System v2 — Mac Installer
# Installs 3 skills, 2 agents, and optionally copies personas + methodology

set -e

echo "============================================"
echo "  Distinction System v2 — Installer (Mac)"
echo "============================================"
echo ""

# Get the directory where this script lives
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Check for ~/.claude directory
if [ ! -d "$HOME/.claude" ]; then
    echo "ERROR: ~/.claude directory not found."
    echo "Make sure Claude Code is installed and has been run at least once."
    exit 1
fi

# Create skills and agents directories if needed
mkdir -p "$HOME/.claude/skills"
mkdir -p "$HOME/.claude/agents"

echo "Installing skills..."

# Install Distinction Finder
if [ -d "$HOME/.claude/skills/distinction-finder" ]; then
    echo "  [SKIP] distinction-finder already exists (not overwriting)"
else
    cp -R "$SCRIPT_DIR/skills/distinction-finder" "$HOME/.claude/skills/distinction-finder"
    echo "  [OK] distinction-finder installed"
fi

# Install Distinction Expander
if [ -d "$HOME/.claude/skills/distinction-expander" ]; then
    echo "  [SKIP] distinction-expander already exists (not overwriting)"
else
    cp -R "$SCRIPT_DIR/skills/distinction-expander" "$HOME/.claude/skills/distinction-expander"
    echo "  [OK] distinction-expander installed"
fi

# Install Distinction Pipeline
if [ -d "$HOME/.claude/skills/distinction-pipeline" ]; then
    echo "  [SKIP] distinction-pipeline already exists (not overwriting)"
else
    cp -R "$SCRIPT_DIR/skills/distinction-pipeline" "$HOME/.claude/skills/distinction-pipeline"
    echo "  [OK] distinction-pipeline installed"
fi

echo ""
echo "Installing agents..."

# Install Finder Critic
if [ -d "$HOME/.claude/agents/distinction-finder-critic" ]; then
    echo "  [SKIP] distinction-finder-critic already exists (not overwriting)"
else
    cp -R "$SCRIPT_DIR/agents/distinction-finder-critic" "$HOME/.claude/agents/distinction-finder-critic"
    echo "  [OK] distinction-finder-critic installed"
fi

# Install Expander Critic
if [ -d "$HOME/.claude/agents/distinction-expander-critic" ]; then
    echo "  [SKIP] distinction-expander-critic already exists (not overwriting)"
else
    cp -R "$SCRIPT_DIR/agents/distinction-expander-critic" "$HOME/.claude/agents/distinction-expander-critic"
    echo "  [OK] distinction-expander-critic installed"
fi

echo ""

# Vault Path for Pipeline
echo "The Distinction Pipeline needs a folder to store extractions, teaching units,"
echo "and the master inventory. This is typically your Obsidian vault."
echo ""
echo "Enter the full path to your Obsidian vault (or working directory):"
echo "  Example: /Users/yourname/Documents/Obsidian/MyVault"
echo ""
read -p "Vault path: " VAULT_PATH
VAULT_PATH="${VAULT_PATH/#\~/$HOME}"

if [ -d "$VAULT_PATH" ]; then
    # Create distinction folder structure
    mkdir -p "$VAULT_PATH/Distinctions/by-source"
    touch "$VAULT_PATH/Distinctions/MASTER-INVENTORY.md"

    echo "  [OK] Created Distinctions folder structure at $VAULT_PATH/Distinctions/"
    echo ""

    # Update the pipeline SKILL.md with the actual vault path
    PIPELINE_SKILL="$HOME/.claude/skills/distinction-pipeline/SKILL.md"
    if [ -f "$PIPELINE_SKILL" ]; then
        sed -i '' "s|\$VAULT_PATH|$VAULT_PATH|g" "$PIPELINE_SKILL"
        echo "  [OK] Pipeline skill configured with your vault path"
    fi

    # Update the finder SKILL.md with the actual vault path
    FINDER_SKILL="$HOME/.claude/skills/distinction-finder/SKILL.md"
    if [ -f "$FINDER_SKILL" ]; then
        sed -i '' "s|\$VAULT_PATH|$VAULT_PATH|g" "$FINDER_SKILL"
        echo "  [OK] Finder skill configured with your vault path"
    fi

    # Update the expander SKILL.md with the actual vault path
    EXPANDER_SKILL="$HOME/.claude/skills/distinction-expander/SKILL.md"
    if [ -f "$EXPANDER_SKILL" ]; then
        sed -i '' "s|\$VAULT_PATH|$VAULT_PATH|g" "$EXPANDER_SKILL"
        echo "  [OK] Expander skill configured with your vault path"
    fi
else
    echo "  [WARN] Directory does not exist: $VAULT_PATH"
    echo "  You can create it later and update the skills manually."
    echo "  Look for \$VAULT_PATH in the SKILL.md files and replace with your path."
fi

echo ""

# Personas
echo "Where should personas be installed?"
echo "  1) ~/.claude/personas/ (accessible from any project)"
echo "  2) Skip (I'll place them manually)"
echo ""
read -p "Choice [1/2]: " PERSONA_CHOICE

if [ "$PERSONA_CHOICE" = "1" ]; then
    mkdir -p "$HOME/.claude/personas"
    cp "$SCRIPT_DIR/personas/"*.md "$HOME/.claude/personas/"
    echo "  [OK] 3 personas installed to ~/.claude/personas/"
else
    echo "  [SKIP] Personas not installed. Copy from personas/ folder when ready."
fi

echo ""

# Methodology
echo "Where should methodology docs be installed?"
echo "  1) ~/.claude/methodology/ (accessible from any project)"
echo "  2) Enter a custom path (e.g., your Obsidian vault)"
echo "  3) Skip (I'll place them manually)"
echo ""
read -p "Choice [1/2/3]: " METHOD_CHOICE

if [ "$METHOD_CHOICE" = "1" ]; then
    mkdir -p "$HOME/.claude/methodology"
    cp "$SCRIPT_DIR/methodology/"*.md "$HOME/.claude/methodology/"
    echo "  [OK] 4 methodology docs installed to ~/.claude/methodology/"
elif [ "$METHOD_CHOICE" = "2" ]; then
    read -p "Enter full path: " CUSTOM_PATH
    CUSTOM_PATH="${CUSTOM_PATH/#\~/$HOME}"
    if [ -d "$CUSTOM_PATH" ]; then
        mkdir -p "$CUSTOM_PATH/methodology"
        cp "$SCRIPT_DIR/methodology/"*.md "$CUSTOM_PATH/methodology/"
        echo "  [OK] 4 methodology docs installed to $CUSTOM_PATH/methodology/"
    else
        echo "  [ERROR] Directory does not exist: $CUSTOM_PATH"
        echo "  Skipping methodology install. Copy from methodology/ folder when ready."
    fi
else
    echo "  [SKIP] Methodology not installed. Copy from methodology/ folder when ready."
fi

echo ""
echo "============================================"
echo "  Installation Complete"
echo "============================================"
echo ""
echo "WHAT WAS INSTALLED:"
echo "  Skills:  distinction-finder, distinction-expander, distinction-pipeline"
echo "  Agents:  distinction-finder-critic, distinction-expander-critic"
echo ""
echo "NEXT STEPS:"
echo "  1. Fill in your voice patterns:"
echo "     ~/.claude/skills/distinction-expander/references/your-patterns.md"
echo "     (See richs-patterns-EXAMPLE.md for a completed example)"
echo ""
echo "  2. Read the methodology docs (00-03) before your first extraction"
echo ""
echo "  3. Open Claude Code and try one of these:"
echo ""
echo "     SINGLE SKILL:"
echo "     'Use the distinction-finder skill to extract distinctions from [your content]'"
echo ""
echo "     FULL PIPELINE:"
echo "     'Use the distinction-pipeline skill to process [your source file or folder]'"
echo ""
echo "  The pipeline runs: Find -> Critic -> Expand -> Critic -> Inventory Update"
echo "  all in one command."
echo ""
echo "  See README.md for the full Quick Start guide."
echo ""
