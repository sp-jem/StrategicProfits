#!/bin/bash
# ZenithPro: Toward Markets — Install All 11 Skills
# Run this from the folder where you unzipped the package.

SKILLS=(
  "toward-desire-mapper"
  "aspiration-excavation"
  "aspiration-avatar-excavation"
  "progression-pattern-analysis"
  "permission-concept-generator"
  "ideal-aspiration-mindset"
  "identity-belief-gap-analyzer"
  "toward-usp-generator"
  "aspiration-mimetic-intelligence"
  "community-architect"
  "toward-demand-architect"
)

echo "Installing ZenithPro: Toward Markets (11 skills)..."
echo ""

SUCCESS=0
FAILED=0

for SKILL in "${SKILLS[@]}"; do
  INSTALL_DIR="$HOME/.claude/skills/$SKILL"
  mkdir -p "$INSTALL_DIR"
  cp "$SKILL/SKILL.md" "$INSTALL_DIR/SKILL.md"
  if [ -f "$INSTALL_DIR/SKILL.md" ]; then
    echo "✅ $SKILL"
    ((SUCCESS++))
  else
    echo "❌ $SKILL — FAILED"
    ((FAILED++))
  fi
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Installed: $SUCCESS / 11 skills"
if [ $FAILED -gt 0 ]; then
  echo "Failed: $FAILED skills — check that ~/.claude/skills/ exists"
fi
echo ""
echo "Run any skill with: /[skill-name]"
echo "Run full pipeline:  /toward-demand-architect full [your market]"
echo "Diagnose market:    /motivation-spectrum-analyzer [your market]"
