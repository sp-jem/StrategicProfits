---
name: offer-launch-pipeline
description: "Orchestrates the full offer launch workflow by chaining 6 skills in sequence: demand-architect → girard-desire-autopsy → funnel-one-pager → copywriter-brief → webinar-arena → webinar-critic (multi-expert audit on winner). Each step's output feeds the next. User gates after steps 1-4. Step 5 (arena) runs internally parallel. Step 6 audits the winning script against the conversion target before declaring pipeline complete. Trigger: /offer-launch-pipeline"
version: 1.0.0
author: Ashley Shaw / Strategic Profits
trigger: /offer-launch-pipeline
---

# Offer Launch Pipeline

Full-stack offer launch orchestrator. Chains 5 validated skills into a single pipeline that takes you from raw offer inputs to a winning webinar script — with positioning, campaign diagnosis, logistics, and copy direction locked in along the way.

---

## ⛔ NON-NEGOTIABLE RULES

| Rule | Why |
|------|-----|
| Steps execute in strict sequence. No skipping. | Each step's output is a required input to the next. Skipping breaks the chain. |
| Do not proceed past a gate until user confirms | Gates exist because user review can correct assumptions before they compound downstream |
| All outputs saved to files before proceeding | Chat-only delivery = broken chain. Every step must produce a file. |
| Never fabricate inputs to feed a downstream step | If a step's output is incomplete, fix it before proceeding — don't invent data |
| Ask the awareness level and segmentation questions BEFORE step 1 | These answers shape every downstream step. Getting them late means rework. |
| funnel-one-pager lives in Vault .claude/skills/ — all others live in ~/.claude/skills/ | Invoke accordingly — they are not in the same location |

---

## PIPELINE OVERVIEW

```
[Inputs Collected]
        ↓
Step 1: demand-architect          → Market positioning + desire architecture
        ↓ [GATE 1 — User reviews]
Step 2: girard-desire-autopsy     → Campaign diagnosis, what worked/broke
        ↓ [GATE 2 — User reviews]
Step 3: funnel-one-pager          → Logistics, dates, pages, pricing, sequences
        ↓ [GATE 3 — User reviews]
Step 4: copywriter-brief          → Asset-by-asset copy direction
        ↓ [GATE 4 — User reviews]
Step 5: webinar-arena             → 7 competing scripts → critiques → revisions → winner
        ↓
Step 6: webinar-critic            → Multi-expert audit of winning script vs. conversion target
        ↓ [If gaps: targeted revision of winner only]
[Pipeline Complete]
```

Steps 1-4: Sequential, user-gated.
Step 5: Internally parallel (7 experts draft simultaneously per arena protocol).
Step 6: Runs on winning script only. Validates against absolute conversion target (not just relative ranking).

---

## PHASE 0: INPUT COLLECTION

Before invoking any skill, collect ALL of the following. Do not proceed until every required input is confirmed.

### Required Inputs

Ask the user for:

1. **Offer name** — What is this offer called? (Used for file naming and folder routing)
2. **Event format** — What is the delivery mechanism? (Live webinar, recorded webinar, challenge, workshop, VSL, etc.)
3. **Event date** — When is the event? (Used in funnel one-pager and webinar arena brief)
4. **Price point / tier structure** — What are the tiers, prices, and what's included at each?
5. **Audience segments** — Who is this going to? For each segment: (a) warm vs. cold, (b) prior exposure to this product/person, (c) estimated % of registrations
6. **Awareness level question** — *"Has this audience been pitched this exact product before? If yes, at what awareness level are they now (0=unaware → 5=most aware)?"* This is the single most important question for all downstream copy direction.
7. **Voice DNA file location** — Path to the Voice DNA file for the presenter. Required for copywriter-brief and arena.
8. **Previous campaign data** (if any) — Transcripts, sales data, Slack purchase notifications, conversion rates, refund rates from prior launches of this offer. If none, state "first launch."
9. **Output folder** — Where should all pipeline outputs be saved? Default: `01 Strategic Profits/Offers/{Offer Name}/`

### Optional Inputs

- Competitor context (who else is in this market space right now)
- Proof points already confirmed (testimonials, revenue numbers, graduate results)
- Named enemies or positioning angles already decided
- Affiliate partner list (for affiliate-specific copy in Step 4)

### Confirmation

Before starting Step 1, display a summary table:

```
PIPELINE INPUTS CONFIRMED
=========================
Offer Name:          [name]
Event Format:        [format]
Event Date:          [date]
Tiers/Pricing:       [summary]
Audience Segments:   [list]
Awareness Level:     [level + rationale]
Voice DNA:           [path]
Previous Campaigns:  [yes/no + what exists]
Output Folder:       [path]

Ready to begin Step 1: demand-architect? (yes/no)
```

---

## STEP 1: DEMAND ARCHITECT

**Skill:** `demand-architect` (`~/.claude/skills/demand-architect/SKILL.md`)
**Mode:** `full` (runs all 9 steps + 3 synthesis outputs)

**What to pass in:**
- Market definition (derived from offer name + audience segments)
- Audience segments with awareness levels
- Previous campaign data (if any) as competitive context
- Competitor context (if provided)

**Runs:** Demand Architect's 9-step pipeline + 3 synthesis documents:
1. Strategic Desire Map
2. Demand Architecture Brief
3. Anti-Mimetic Positioning Statement

**Save outputs to:** `{output-folder}/01-Demand-Architect/`

**Note:** Step 1 requires live web research (demand-architect invariant). If web research tools are unavailable, halt and notify user.

### GATE 1

After Step 1 saves all outputs, present to user:

```
GATE 1 — DEMAND ARCHITECT COMPLETE
====================================
Outputs saved to: {output-folder}/01-Demand-Architect/

Key findings:
- Primary Core Concept: [from Demand Architecture Brief]
- Anti-Mimetic Position: [one line from positioning statement]
- Top desire architecture finding: [one finding]

Review the outputs. Corrections needed before we proceed?
(If yes — what needs to change? If no — reply 'proceed to Step 2')
```

Do NOT proceed to Step 2 until user explicitly confirms.

---

## STEP 2: GIRARD DESIRE AUTOPSY

**Skill:** `girard-desire-autopsy` (`~/.claude/skills/girard-desire-autopsy/SKILL.md`)

**What to pass in:**
- Previous campaign materials (from Phase 0 inputs)
- Results data (conversion rates, revenue, refunds) if available
- Target market definition (from Step 1 — Strategic Desire Map)
- Competitor context (from Step 1 — competitive landscape)

**If no previous campaign exists:** Run a "pre-launch desire architecture blueprint" instead of a diagnosis. Use the desire autopsy framework to specify WHICH desire structure to build for this launch — not what broke, but what to build and why.

**Save output to:** `{output-folder}/02-Desire-Autopsy/`

**Filename:** `Desire-Autopsy-[Offer-Name]-[Date].md`

### GATE 2

```
GATE 2 — DESIRE AUTOPSY COMPLETE
==================================
Output saved to: {output-folder}/02-Desire-Autopsy/

Key findings:
- Primary failure mode (or primary desire architecture): [one line]
- Model type assessment: [STRONG / WEAK / MISALIGNED]
- Top correction for this launch: [one line]

Review the diagnosis. Anything to correct before we build the logistics?
(If yes — what needs to change? If no — reply 'proceed to Step 3')
```

Do NOT proceed to Step 3 until user explicitly confirms.

---

## STEP 3: FUNNEL ONE-PAGER

**Skill:** `funnel-one-pager` (Vault: `.claude/skills/funnel-one-pager/SKILL.md`)

**What to pass in:**
- Offer name, event format, event date (from Phase 0)
- Tier structure and pricing (from Phase 0)
- Audience segments (from Phase 0)
- Positioning angle (from Step 1 — Demand Architecture Brief)
- Desire structure corrections (from Step 2 — Autopsy)

**The one-pager produces:** Every page needed, every email sequence, dates, pricing, fulfillment, tech requirements, open questions. The full logistics map.

**Save output to:** `{output-folder}/`

**Filename:** `Funnel One-Pager - [Offer Name].md`

### GATE 3

```
GATE 3 — FUNNEL ONE-PAGER COMPLETE
=====================================
Output saved to: {output-folder}/Funnel One-Pager - [Offer Name].md

Quick summary:
- Total assets in funnel: [count]
- Event date confirmed: [date]
- Tiers: [list]
- Open questions remaining: [count]

Review logistics. Dates, pages, pricing, sequences all correct?
(If yes — reply 'proceed to Step 4'. If no — what needs to change?)
```

Do NOT proceed to Step 4 until user explicitly confirms.

---

## STEP 4: COPYWRITER BRIEF

**Skill:** `copywriter-brief` (`~/.claude/skills/copywriter-brief/SKILL.md`)

**What to pass in:**
- Funnel One-Pager (Step 3 output — asset list source)
- Desire Autopsy (Step 2 output — what worked/broke)
- Demand Architecture Brief (Step 1 output — positioning)
- Awareness level answer (from Phase 0 — shapes entire brief)
- Audience segments (from Phase 0 — carried through)
- Voice DNA file path (from Phase 0)
- Proof points (from Phase 0 or confirmed during Steps 1-3)

**The brief produces:**
- Section 1: Strategic Direction
- Section 2: Audience Segments + Awareness Level Strategy
- Section 3: Rules for All Assets
- Section 4: Asset-by-asset direction (every asset from the one-pager)
- Section 5: Proof Points Available
- Section 6: Event Name / Hook Options
- Section 7: Dependencies

**Save output to:** `{output-folder}/`

**Filename:** `Copywriter Brief - [Offer Name].md`

### GATE 4

```
GATE 4 — COPYWRITER BRIEF COMPLETE
=====================================
Output saved to: {output-folder}/Copywriter Brief - [Offer Name].md

This is the last gate before the arena runs.

Key directions:
- Universal writing level: Level [X] — [rationale]
- Named enemy: [one line]
- Big Domino: [one line]
- Assets directed: [count]
- Blocked assets: [count and what's blocking]

Review the brief. All copy directions correct?
(If yes — reply 'proceed to Step 5 / webinar arena'. If no — what needs to change?)
```

Do NOT launch the arena until user explicitly confirms.

---

## STEP 5: WEBINAR ARENA

**Skill:** `webinar-arena` (`~/.claude/skills/webinar-arena/SKILL.md`)

**What to pass in:**
- Copywriter Brief (Step 4 — competition brief)
- Funnel One-Pager (Step 3 — logistics context)
- Desire Autopsy (Step 2 — positioning corrections)
- Voice DNA file path (for Rich's voice requirement)
- Event date, format, audience, awareness level, price point (from Phase 0)

**Arena structure (follows webinar-arena v3.1 protocol):**
- 7 experts draft simultaneously (Fladlien, Cage, Brunson, Kern, Joon, Kennedy + Synthesis)
- 7 critics run in parallel on all drafts
- 7 revisions based on critiques
- Marketplace judge evaluates anonymized entries (A-G)
- Winner declared, learning brief produced

**Outputs save to:** `00 Projects/Webinar Arena/{offer-name-slug}/round-1/`

**This step runs autonomously per the webinar-arena protocol.** The orchestrator dispatches and waits — it does not write any webinar content directly.

---

## STEP 6: WEBINAR CRITIC — CONVERSION AUDIT

**Agent:** `webinar-critic` (multi-expert)

**WHY THIS STEP EXISTS:** The arena marketplace judge ranks entries by relative conversion probability. It does not validate whether the winner will hit the absolute conversion target. The webinar-critic stress-tests the winning script against ALL expert standards simultaneously and renders a predicted conversion range vs. the target stated in Phase 0.

**What to pass in:**
- Winning revision (from Step 5 — file path)
- Copywriter Brief (Step 4 — for conversion target and audience context)
- Voice DNA file path (from Phase 0)
- Conversion target (from Phase 0 inputs — e.g. "30% live")

**The audit produces:**
- Overall grade + predicted conversion range
- Top gaps between current script and conversion target
- Production-ready verdict: YES / NOT YET
- If NOT YET: specific fixes required (scope, location, word count estimate)

**Save audit to:** `{arena-output-folder}/round-1/results/winner-multi-expert-audit.md`

**If gaps found:** Run a targeted revision on the winning script only (additions only — do not restructure). Save to `{arena-output-folder}/round-1/revisions/winner-final.md`. This is the production script.

**If production-ready:** Winning revision is the production script as-is.

---

## STEP 7: DESIRE AUTOPSY CROSS-CHECK

**WHY THIS STEP EXISTS:** The Desire Autopsy contains campaign-specific data (actual tier conversion rates, drop-off signals, cold traffic confusion patterns, specific high-leverage fixes) that may not be fully captured in the Copywriter Brief. The Brief summarizes the Autopsy — but the Autopsy itself contains granular details that can expose gaps in the production script that the audit missed.

**Always run this step, even if the webinar-critic returned production-ready.**

**What to do:**
1. Read the Desire Autopsy in full (Step 2 output — `{output-folder}/02-Desire-Autopsy/`)
2. Check the production script against every item in the Autopsy's "highest-leverage fixes" section
3. Verify each specific scripted element the Autopsy calls out is present (e.g. CTD desire activation, specific vulnerability moments, cold traffic onboarding language)
4. Flag any item in the Autopsy that is NOT in the production script

**If gaps found:** Add the missing elements to `winner-final.md` (or create `winner-final-v2.md` if already delivered). Additions only.

**If no gaps:** Confirm explicitly: "Desire Autopsy cross-check complete — all high-leverage fixes present in production script."

**Save confirmation or gap report to:** `{arena-output-folder}/round-1/results/autopsy-crosscheck.md`

### PIPELINE COMPLETE

When the audit passes, deliver:

```
OFFER LAUNCH PIPELINE — COMPLETE
==================================
Offer: [name]
Event: [date]

All outputs saved to: {output-folder}/

Pipeline Deliverables:
✓ Step 1: Demand Architecture (Strategic Desire Map, Demand Brief, Positioning Statement)
✓ Step 2: Desire Autopsy
✓ Step 3: Funnel One-Pager
✓ Step 4: Copywriter Brief
✓ Step 5: Webinar Arena (7 drafts → critiques → revisions → winner)
✓ Step 6: Conversion Audit (multi-expert webinar-critic on winning script)

Arena Winner: [expert name or synthesis] — [one line rationale]
Audit result: [grade] — [predicted conversion range]
Production script: [file path — revision or winner-final if additional pass was needed]

Next: Hand copywriter brief + production script to copy team.
```

---

## ERROR HANDLING

| Situation | Action |
|-----------|--------|
| Web research unavailable for Step 1 | Halt. Notify user. Do not substitute training knowledge. |
| No previous campaign data for Step 2 | Run pre-launch desire architecture blueprint instead of autopsy. State clearly: "No prior campaign — building blueprint." |
| Step output file missing before gate | Produce missing file before presenting gate. Never gate on incomplete work. |
| User corrections at any gate | Apply corrections to that step's output, re-save, re-present gate. Then proceed. |
| Arena fails to produce 7 drafts | Follow webinar-arena error protocol. Do not proceed to judgment with fewer than 7. |
| Component skill missing | Error clearly: "Skill [name] not found at [path]. Cannot proceed until resolved." |

---

## SKILL LOCATIONS (REFERENCE)

| Skill | Location |
|-------|----------|
| demand-architect | `~/.claude/skills/demand-architect/SKILL.md` |
| girard-desire-autopsy | `~/.claude/skills/girard-desire-autopsy/SKILL.md` |
| funnel-one-pager | `{vault}/.claude/skills/funnel-one-pager/SKILL.md` |
| copywriter-brief | `~/.claude/skills/copywriter-brief/SKILL.md` |
| webinar-arena | `~/.claude/skills/webinar-arena/SKILL.md` |
| webinar-critic | Agent type: `webinar-critic` (invoked via Task tool) |

---

## GOLD STANDARD REFERENCE

The Calibration Gap (ZenithMind OS — April 16, 2026) is the reference execution of this pipeline, run manually:

| Step | Output Location |
|------|----------------|
| Step 1 (Demand) | *(run as part of ZenithMind positioning work)* |
| Step 2 (Autopsy) | `01 Strategic Profits/AI Imprint Challenge/ZenithMind-Desire-Autopsy-Copywriter-Brief.md` |
| Step 3 (One-Pager) | `01 Strategic Profits/Offers/ZenithMind OS Webinar April 16/Funnel One-Pager - ZenithMind OS Webinar April 16.md` |
| Step 4 (Brief) | `01 Strategic Profits/Offers/ZenithMind OS Webinar April 16/Copywriter Brief - The Calibration Gap.md` |
| Step 5 (Arena) | `00 Projects/Webinar Arena/calibration-gap-april16/` |

When in doubt about what any step's output should look like — read the gold standard.
