# Offer Launch Pipeline — Install Pack

## What It Does
Full-stack offer launch orchestrator. Chains 6 validated skills into a single pipeline that takes you from raw offer inputs to a winning webinar script — with positioning, campaign diagnosis, logistics, and copy direction locked in along the way.

**The 6-Step Chain:**
1. **Demand Architect** — Market positioning + desire architecture
2. **Girard Desire Autopsy** — Campaign diagnosis (what worked/broke last time)
3. **Funnel One-Pager** — Logistics, dates, pages, pricing, sequences
4. **Copywriter Brief** — Asset-by-asset copy direction
5. **Webinar Arena** — 7 competing scripts, critiques, revisions, winner declared
6. **Webinar Critic** — Multi-expert audit of winning script

Steps 1-4 have user review gates. Step 5 runs autonomously (7 experts compete). Step 6 validates the winner.

## How to Install
1. Unzip this package
2. Copy the `offer-launch-pipeline/` folder into `~/.claude/skills/`
3. Restart Claude Code

## How to Run
**Trigger:** `/offer-launch-pipeline`

It will ask you for:
- Your offer (name, price, what's included, who it's for)
- Target market and awareness level
- Previous campaign data (if any)
- Launch dates and logistics

Then it runs the full chain — you review at each gate, and it builds on your feedback.

## What You Get Out
- Complete demand architecture brief
- Campaign autopsy (if previous data provided)
- Funnel one-pager ready for your team
- Copywriter brief for all assets
- 7 competing webinar scripts with a declared winner
- Multi-expert audit of the winning script

## Prerequisites
These skills must already be installed (you should have them from previous lessons):
- demand-architect
- girard-desire-autopsy
- funnel-one-pager
- copywriter-brief (copy-brief)
- webinar-arena
- webinar-critic

## Version
v1.0.0 — Tested in Force Multiplier, certified for ZenithPro delivery.
