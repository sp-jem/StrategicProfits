#!/bin/bash
# ============================================================
# Short-Form Copy Mastery - Installer (Mac/Linux)
# Strategic Profits
# ============================================================

set -e

SKILL_NAME="short-form-copy"
SKILL_DIR="$HOME/.claude/skills/$SKILL_NAME"

echo "============================================================"
echo "  Short-Form Copy Mastery - Installer"
echo "  Strategic Profits"
echo "============================================================"
echo ""

# Check if skill already exists
if [ -d "$SKILL_DIR" ]; then
    echo "WARNING: $SKILL_DIR already exists."
    read -p "Overwrite? (y/n): " CONFIRM
    if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
        echo "Installation cancelled."
        exit 0
    fi
    rm -rf "$SKILL_DIR"
fi

# Create skill directory
mkdir -p "$SKILL_DIR/references"

# Get the directory where this script lives
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Copy files
echo "Installing skill files..."
cp "$SCRIPT_DIR/SKILL.md" "$SKILL_DIR/SKILL.md"
cp "$SCRIPT_DIR/references/training.md" "$SKILL_DIR/references/training.md"
cp "$SCRIPT_DIR/references/platform-specs.md" "$SKILL_DIR/references/platform-specs.md"
cp "$SCRIPT_DIR/references/examples.md" "$SKILL_DIR/references/examples.md"
cp "$SCRIPT_DIR/references/validate_copy.py" "$SKILL_DIR/references/validate_copy.py"

# Make validation script executable
chmod +x "$SKILL_DIR/references/validate_copy.py"

echo ""
echo "============================================================"
echo "  Installation complete!"
echo "============================================================"
echo ""
echo "  Installed to: $SKILL_DIR"
echo ""
echo "  Files:"
echo "    - SKILL.md (main skill)"
echo "    - references/training.md"
echo "    - references/platform-specs.md"
echo "    - references/examples.md"
echo "    - references/validate_copy.py"
echo ""
echo "  OPTIONAL: For best results, make sure your Obsidian vault"
echo "  has these files (ask Rich for them if needed):"
echo "    - 000 Core Context/Rich Schefren/_AI-COPYWRITING-RESOURCES/01-VOICE-AND-TONE.md"
echo "    - 000 Core Context/Strategic Profits/04-Product-Registry.md"
echo ""
echo "  Usage: Tell Claude 'I need short-form copy' or invoke"
echo "  the skill with /short-form-copy"
echo ""
echo "  Restart Claude Code to pick up the new skill."
echo "============================================================"
