# PPTX Skill — Usage & License Notice

## This skill is built for Claude Code only

This skill is designed exclusively for use with **Claude Code** (Anthropic's CLI tool).
It will not work in any other AI platform, application, or tool. Do not attempt to adapt
or port it elsewhere — it depends on Claude Code's skill system architecture.

## Who can use this

You must have an active **Claude Code** installation with a valid Anthropic account.
If you don't have Claude Code, get it at: https://claude.ai/code

## Underlying license

The core scripts and tooling in this skill are proprietary to **Anthropic, PBC**
(© 2025 Anthropic, PBC. All rights reserved), distributed as part of the Claude Code
platform under Anthropic's Terms of Service.

This package is shared for use by students with active Claude Code subscriptions.
It is not for resale, redistribution outside of this context, or use in any commercial
product or service.

Full Anthropic license terms: https://www.anthropic.com/legal/commercial-terms

## What's in this skill

The PPTX skill gives Claude the ability to:
- **Create presentations from scratch** using pptxgenjs (JavaScript)
- **Edit existing PPTX files** by unpacking, modifying XML, and repacking
- **Read and analyze** any .pptx file
- **Generate visual thumbnails** of slides for QA

It includes a full extraction of **Garr Reynolds' Presentation Zen methodology** —
the design philosophy behind every presentation Claude builds with this skill.
Every slide Claude creates passes Reynolds' 6-slide tests (3-Second, Billboard,
Back Row, "So What?", Removal, Standalone).

## Dependencies to install

Run the installer for your platform (install.sh for Mac, install.ps1 for PC).
The installer will check for and prompt you to install:

| Dependency | What it does | Install command |
|------------|-------------|-----------------|
| `markitdown` | Reads/extracts text from PPTX | `pip install "markitdown[pptx]"` |
| `Pillow` | Creates slide thumbnail grids | `pip install Pillow` |
| `pptxgenjs` | Builds PPTX from scratch | `npm install -g pptxgenjs` |
| LibreOffice | Converts PPTX to PDF for QA | Download at libreoffice.org |
| Poppler | Converts PDF to images for QA | `brew install poppler` (Mac) |

The core create/edit/read workflow works with just `markitdown` and `pptxgenjs`.
LibreOffice + Poppler are only needed for the visual QA workflow.
