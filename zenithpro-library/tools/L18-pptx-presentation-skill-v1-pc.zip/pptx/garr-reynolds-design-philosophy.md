# Garr Reynolds / Presentation Zen Design Philosophy

Complete extraction of design principles, visual philosophy, and slide creation rules from Garr Reynolds' Presentation Zen methodology. Use this as a design reference when creating any presentation.

---

## CORE PHILOSOPHY

**"Making the complicated simple, awesomely simple — that's creativity."**

Reynolds applies Zen aesthetics — restraint, simplicity, naturalness — to transform presentations from information dumps into visual experiences. The fundamental question is never "What can I add?" but always **"What can I remove?"**

### The Three Pillars
1. **Restraint** in preparation
2. **Simplicity** in design
3. **Naturalness** in delivery

### The Anti-Slideument Doctrine
Slides are NOT documents. A "slideument" (slide + document) is the root cause of Death by PowerPoint. Slides should be virtually meaningless without the presenter's narration — that's by design. If you need to distribute information, create a separate handout document.

---

## THE 7 JAPANESE AESTHETIC PRINCIPLES

These are the philosophical foundation that separates Presentation Zen from every other slide methodology.

### 1. Kanso (簡素) — Simplicity
Beauty and visual elegance achieved through elimination and omission. "Think not in terms of decoration but in terms of clarity, a kind of clarity achieved through omission or exclusion of the non-essential." Maximum effect with minimum means.

**Applied:** Strip slides to their essence. One idea per slide. No decorative borders, no unnecessary logos, no visual noise.

### 2. Fukinsei (不均整) — Asymmetry
Asymmetry, irregularity, and imperfection as sources of natural beauty. Rejects Western obsession with perfect symmetry.

**Applied:** Use the Rule of Thirds. Place subjects off-center at power points. Asymmetrical balance feels dynamic and alive; centered layouts feel static and dead.

### 3. Shibumi (渋味) — Understated Elegance
Elegant simplicity, articulate brevity. Beautiful by being understated. Contains subtle complexity beneath apparent simplicity.

**Applied:** Don't visually spell out everything. Don't hammer details. Let images and sparse text suggest rather than declare. Subdued, sophisticated styling over heavy ornamentation.

### 4. Shizen (自然) — Naturalness
Creating without artifice or pretense. Genuine creative intent that flows effortlessly. Not the absence of effort, but the absence of forced effort.

**Applied:** Slides should feel effortless and authentic. Avoid forced effects, gimmicky transitions, and clip art. Clean layouts with breathing space that unfold naturally.

### 5. Yugen (幽玄) — Subtle Profundity
Mysterious beauty beyond words. Suggestion rather than revelation. Show less to evoke deeper emotional response.

**Applied:** Imply more through restraint. A single powerful image communicates more than a slide full of bullets. Foster contemplation. Leave room for the audience's imagination.

### 6. Datsuzoku (脱俗) — Freedom from Convention
Escape from the ordinary. Transcending the conventional. Breaking from habit or formula.

**Applied:** Reject the default template. Reject the bullet-point reflex. Surprise the audience. Reveal essential truths through unexpected perspectives.

### 7. Seijaku (静寂) — Tranquility
Stillness, solitude, energized calm. A mindful presence that creates peace even in chaos.

**Applied:** Design that encourages quiet reflection without overwhelming. Slow viewers down. Ground them in presence through active calm rather than noise.

---

## DESIGN PRINCIPLES

### Signal-to-Noise Ratio (SNR)
The ratio of relevant to irrelevant information on a slide. **Maximize signal, eliminate noise.**

- Remove degrading elements: inappropriate charts, ambiguous labels, unnecessary lines/shapes/symbols
- Minimize or eliminate footers, logos, gridlines
- Before adding ANY element, ask: "Does this clarify or confuse?"
- Every element must directly support the core message
- Reference: Edward Tufte's concept of "chart junk"

### Picture Superiority Effect
Images are remembered better than words — especially when exposure time exceeds 30 seconds and people are casually exposed to information.

- Use pictures and words together that reinforce the SAME information
- Most effective with common, concrete imagery
- The best slides may contain NO text at all
- One large, powerful image beats multiple small ones

### Ma (空) — Empty Space
Empty space is ACTIVE, not passive. It directs the eye to what is important.

- Whitespace is the breathing room of design
- Resist filling every inch of the slide
- Empty space helps audiences focus and absorb information
- Less clutter = more powerful visual message

### Text Placement on Images (Critical Technique)
Reynolds places text in the **natural dark or empty zones** of photographs — NOT uniformly across the image with a darkening overlay. The image's own composition provides the contrast.

**The right way:**
- Choose or create images that have natural dark areas (shadows, sky, out-of-focus regions)
- Place text IN those dark zones where it reads naturally
- The rest of the image stays vivid and unobscured

**The wrong way:**
- Lay a uniform semi-transparent black overlay across the entire image
- Place text wherever the layout dictates, regardless of what's behind it
- Fight readability problems by making the overlay darker (which kills the image)

**For AI-generated images:** Prompt for compositions with subject on one side and dark negative space on the other. Example: "subject positioned in the right third, deep dark background on the left two-thirds."

**Localized panels (when needed):** If text must cross a bright area, use a small semi-transparent panel only behind the text — not a full-slide overlay. This preserves the image everywhere except the text zone.

### Contrast
Contrast creates visual energy, attracts interest, and establishes hierarchy.

Methods of creating contrast:
- **Space:** near/far, empty/filled
- **Color:** dark/light, cool/warm
- **Typeface:** serif/sans serif, bold/narrow
- **Size:** large/small (extreme size contrast recommended)
- **Position:** high/low, left/right

Rules:
- One dominant focal point with clear contrast among elements
- Weak contrast = boring, confusing, hard to read
- Strong contrast = clear visual hierarchy

### Rule of Thirds
Divide the frame into a 3x3 grid (tic-tac-toe pattern). Place main subjects at the four intersecting "power points" rather than dead center.

- Creates asymmetrical balance (Fukinsei)
- More dynamic and aesthetically pleasing than centered composition
- Apply to both photography and slide layout

### One Idea Per Slide
Each slide expresses only ONE clear idea. Replace multi-point bullet lists with individual slides. This allows audiences to absorb single concepts without cognitive overload.

- If you have 5 points, that's 5 slides minimum
- Breaking information into smaller chunks improves comprehension (Segmenting Principle)
- Use Slide Sorter view to see the flow at 35,000 feet

---

## VISUAL DESIGN RULES

### Images
- **Full-bleed images** (edge to edge) with text overlay create maximum impact
- One large image always beats multiple small ones
- Side-by-side only acceptable for Before/After or Then/Now comparisons
- Images must be comprehensible within 3 seconds (Nancy Duarte: "glance media")
- Design for the back of the room — treat slides like highway billboards

### Typography
- **Sans serif** generally preferred for projected slides (legibility at large sizes)
- **Slab serif (Rockwell)** is excellent for presentations — heavy block-like serifs project with authority and read clearly at distance
- Serif fonts work at large sizes but are NOT the default recommendation
- Make text LARGE — if the back of the room can't read it, it's too small
- Keep it simple — 1-2 fonts maximum
- Adjust character spacing and line spacing at large sizes — at large sizes, default tracking may be too tight or too loose
- Match billboard/signage logic: instant understanding

**Font hierarchy for presentations (Reynolds' preference):**
1. Sans serif (Helvetica, Arial, Calibri) — clean, modern, default choice
2. Slab serif (Rockwell, Courier Slab) — bold authority, excellent projection
3. Serif (Garamond, Georgia) — works at large sizes only, best for quotes or accent text

### Color
- Color evokes emotion and aids persuasion, motivation, comprehension, and retention
- **Cool colors** (blue, green) work for backgrounds — they recede visually
- **Warm colors** (orange, red) work for foreground — they appear to advance
- Choose 2-3 colors maximum; maintain consistency for unity
- Use color for attention, highlighting, eye guidance — NEVER for decoration

### Room Lighting Drives the Palette
This is Reynolds' most overlooked rule:
- **Dark room (theater, keynote):** Dark background + light text — images pop, text glows
- **Well-lit room / ambient light:** White or light background + dark text — dark backgrounds WASH OUT under ambient light; light backgrounds resist washout
- **Screen viewing (laptops, monitors):** Either works, but dark-on-dark loses impact on lower-quality displays

**Before choosing your palette, ask: "Where will this be viewed?"**

### Charts & Graphs
Apply three principles: **Restrain, Reduce, Emphasize**

**Restrain:** Edit ruthlessly. Include only necessary information. Remove clutter.

**Reduce:** Ask before including any element:
- What will this really show the audience?
- How does it support my point?
- What's the essence of this data?
- Are any elements nonessential?

**Emphasize:** Direct viewer attention with:
- Contrast/color highlighting on the key data point
- Declarative statement titles (e.g., "Cases decreased by 17%" NOT "Cases 2021")

### Animation & Transitions
- Movement is highly noticeable to brains — use VERY cautiously
- Never animate bullet points sliding in on every slide
- Subtle animations only: "Wipe Left-to-Right" acceptable; "Fly," "Move" are tedious
- Limit to 2-3 different transition types in entire presentation
- Most slides need NO transition at all
- "The more you use an effect, the less effective it will be"

### Video
- Short video clips promote active cognitive processing
- Shows concrete examples effectively
- Provides pacing change and increased interest
- Embed full-screen at 1080p when possible
- AVOID cheesy PowerPoint sound effects
- Can play videos with live speaker narration as B-roll

---

## PREPARATION PHILOSOPHY

### Start Analog
Begin with pen, paper, or whiteboard — NOT the computer. Sketch ideas, create rough storyboards, outline content before opening any software. This clarifies messaging before you get trapped by templates.

### The "So What?" Test
For every piece of content, ask: "So what?" (Japanese: *dakara nani?*). If you cannot justify why it matters to the audience, remove it.

### Core Message Discipline
- Identify ONE fundamental takeaway you want remembered
- Write it in one or two sentences
- Limit key messages to THREE maximum
- If audiences remember only three things, what should they be?

### The 10-Minute Rule
Attention decreases after 9-10 minutes (Dr. John Medina research). Design intentional pattern interrupts:
- Short videos
- Varied charts and graphs
- Stories and examples
- Large photos or diagrams
- Questions or quizzes to the audience

For virtual presentations, compress this to 3-4 minutes.

### Structure
Build on clear frameworks:
- Top-10 lists, "X Ways to Y" formats
- Problem/Solution: Introduce problem with background, data, stories → propose solutions
- Visual design can reinforce structure (e.g., distinct colored section title slides)

### Opening & Closing
Serial position effect: audiences remember beginnings and endings best.

**Opening:** Grab attention immediately with surprising statistics or compelling stories — NOT generic introductions. Explain what's in it for them early.

**Closing:** Don't end with Q&A alone. After questions, reinforce your key message with stories, video clips, or other memorable elements. Include explicit calls to action.

---

## DELIVERY PRINCIPLES

### Presence Over Slides
- The first 2-3 minutes are the most important
- Show genuine passion — your feelings are contagious
- Move away from the lectern — physical barriers kill connection
- Make direct eye contact with individuals, not general scanning
- Keep the lights ON — focus should be on the presenter

### The B Key
Press B during presentation to black the screen (W for white). Redirects all attention to you. Use for digressions, emphasis shifts, or powerful moments.

### Hara Hachi Bu (腹八分)
Japanese principle: eat until 80% full. Applied to presentations: **finish before the audience is full**. If given 30 minutes, finish in 25. Better to have them wanting more than wishing you'd stopped.

### Embrace Constraints
Deadlines, slide limits, and brand guidelines aren't limitations — they inspire better solutions. Less space forces better decisions.

---

## VIRTUAL PRESENTATION ADAPTATIONS

- **Extreme simplification** — bare essentials only
- **3-4 minute attention rule** instead of 10-minute rule
- **Enlarge all elements** significantly — account for smartphone viewers
- **Center yourself prominently** in frame — not a tiny corner box
- **Camera at eye level** or slightly above, eyes in upper third of frame
- **Clean background** — eliminate visual clutter
- **Audio quality is paramount** — audiences tolerate poor video but not bad sound
- **Look directly into the camera** to simulate eye contact

---

## SLIDE MAKEOVER PRINCIPLES

When redesigning slides, Reynolds consistently applies:

1. **Break one overcrowded slide into multiple visual slides** — each carrying one idea
2. **Replace descriptive text with images** that communicate the same concept visually
3. **Use "magic move" transitions** to smoothly reduce type size between related slides
4. **Incorporate charts as alternatives** to text-heavy explanations
5. **Ask:** "If people cannot listen and read at the same time, why do most slides contain far more words than images?"

---

## THE GARR REYNOLDS AESTHETIC IN PRACTICE

When creating a Presentation Zen-style deck, every slide should pass these tests:

1. **The 3-Second Test:** Can the audience grasp the slide's message in 3 seconds?
2. **The Billboard Test:** Would this work as a highway billboard at 65mph?
3. **The Back Row Test:** Can the person in the last row read and understand it?
4. **The "So What?" Test:** Does this matter to the audience?
5. **The Removal Test:** If I remove this element, does the slide get BETTER?
6. **The Standalone Test:** Would this slide be virtually meaningless without narration? (It should be.)

### The Signature Look
- Full-bleed, high-quality photographs
- Minimal text (often just a word or short phrase)
- Enormous whitespace
- Sans serif typography at large sizes
- Muted, intentional color palettes (2-3 colors)
- Asymmetrical composition using Rule of Thirds
- No bullet points
- No clip art
- No decorative borders or logos
- No footer text or slide numbers
- No gratuitous animation
- Feels like a photo essay, not a business document

---

## FREE IMAGE RESOURCES (Reynolds-Recommended)

- Pexels.com
- Unsplash.com
- Pixabay.com
- Freeimages.com
- Stocksnap.io
- Kaboompics.com
- Burst.shopify.com
- Reshot.com
- Lifeofpix.com
- Barnimages.com

Paid: Adobe Stock, Shutterstock, iStockphoto, Storyblocks, Canva

---

*Sources: garrreynolds.com, presentationzen.com, Presentation Zen (3rd Ed.), Presentation Zen Design (2nd Ed.)*
