#!/bin/bash
# PPTX Skill Installer — Mac
# Installs the PPTX skill into ~/.claude/skills/pptx/

set -e

SKILL_NAME="pptx"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/$SKILL_NAME"
DEST_DIR="$HOME/.claude/skills/$SKILL_NAME"

echo ""
echo "======================================"
echo "  PPTX Skill Installer (Mac)"
echo "======================================"
echo ""

# Check Claude Code is installed
if [ ! -d "$HOME/.claude" ]; then
  echo "ERROR: Claude Code not found at ~/.claude"
  echo "Install Claude Code first: https://claude.ai/code"
  exit 1
fi

# Check if skill already exists
if [ -d "$DEST_DIR" ]; then
  echo "WARNING: A pptx skill already exists at $DEST_DIR"
  read -p "Overwrite it? (y/N): " confirm
  if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo "Aborted."
    exit 0
  fi
  rm -rf "$DEST_DIR"
fi

# Install the skill
echo "Installing skill to $DEST_DIR..."
mkdir -p "$HOME/.claude/skills"
cp -r "$SOURCE_DIR" "$DEST_DIR"
echo "Skill installed."
echo ""

# -----------------------------------------------
# Dependency checks
# -----------------------------------------------

echo "Checking dependencies..."
echo ""

MISSING_DEPS=0

# Python
if ! command -v python3 &>/dev/null; then
  echo "  [MISSING] python3 — required for PPTX editing and thumbnails"
  echo "            Install: brew install python3"
  MISSING_DEPS=1
else
  echo "  [OK]      python3 ($(python3 --version 2>&1))"
fi

# markitdown
if ! python3 -c "import markitdown" &>/dev/null 2>&1; then
  echo "  [MISSING] markitdown — required for reading PPTX files"
  echo "            Install: pip install \"markitdown[pptx]\""
  MISSING_DEPS=1
else
  echo "  [OK]      markitdown"
fi

# Pillow
if ! python3 -c "import PIL" &>/dev/null 2>&1; then
  echo "  [MISSING] Pillow — required for slide thumbnails"
  echo "            Install: pip install Pillow"
  MISSING_DEPS=1
else
  echo "  [OK]      Pillow"
fi

# defusedxml
if ! python3 -c "import defusedxml" &>/dev/null 2>&1; then
  echo "  [MISSING] defusedxml — required for safe XML parsing in edit workflow"
  echo "            Install: pip install defusedxml"
  MISSING_DEPS=1
else
  echo "  [OK]      defusedxml"
fi

# Node + pptxgenjs
if ! command -v node &>/dev/null; then
  echo "  [MISSING] Node.js — required for creating PPTX from scratch"
  echo "            Install: brew install node"
  MISSING_DEPS=1
else
  if ! node -e "require('pptxgenjs')" &>/dev/null 2>&1; then
    echo "  [MISSING] pptxgenjs — required for creating PPTX from scratch"
    echo "            Install: npm install -g pptxgenjs"
    MISSING_DEPS=1
  else
    echo "  [OK]      pptxgenjs"
  fi
fi

# LibreOffice (optional — needed for visual QA)
if ! command -v soffice &>/dev/null && [ ! -f "/Applications/LibreOffice.app/Contents/MacOS/soffice" ]; then
  echo "  [OPTIONAL] LibreOffice — needed for visual QA (PPTX to image conversion)"
  echo "             Download: https://www.libreoffice.org/download/download/"
else
  echo "  [OK]      LibreOffice"
fi

# Poppler / pdftoppm (optional — needed for visual QA)
if ! command -v pdftoppm &>/dev/null; then
  echo "  [OPTIONAL] Poppler — needed for visual QA (PDF to images)"
  echo "             Install: brew install poppler"
else
  echo "  [OK]      pdftoppm (Poppler)"
fi

echo ""

if [ "$MISSING_DEPS" -eq 1 ]; then
  echo "Some required dependencies are missing. Install them, then restart Claude Code."
else
  echo "All required dependencies are installed."
fi

echo ""
echo "======================================"
echo "  Installation complete!"
echo "======================================"
echo ""
echo "Restart Claude Code, then try: 'build me a 5-slide pitch deck'"
echo ""
