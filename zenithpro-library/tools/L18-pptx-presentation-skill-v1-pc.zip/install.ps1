# PPTX Skill Installer — Windows (PowerShell)
# Installs the PPTX skill into ~/.claude/skills/pptx/

$ErrorActionPreference = "Stop"

$SkillName = "pptx"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceDir = Join-Path $ScriptDir $SkillName
$DestDir = Join-Path $env:USERPROFILE ".claude\skills\$SkillName"

Write-Host ""
Write-Host "======================================"
Write-Host "  PPTX Skill Installer (Windows)"
Write-Host "======================================"
Write-Host ""

# Check Claude Code is installed
$ClaudeDir = Join-Path $env:USERPROFILE ".claude"
if (-not (Test-Path $ClaudeDir)) {
    Write-Host "ERROR: Claude Code not found at $ClaudeDir"
    Write-Host "Install Claude Code first: https://claude.ai/code"
    exit 1
}

# Check if skill already exists
if (Test-Path $DestDir) {
    Write-Host "WARNING: A pptx skill already exists at $DestDir"
    $confirm = Read-Host "Overwrite it? (y/N)"
    if ($confirm -ne "y" -and $confirm -ne "Y") {
        Write-Host "Aborted."
        exit 0
    }
    Remove-Item -Recurse -Force $DestDir
}

# Install the skill
Write-Host "Installing skill to $DestDir..."
$SkillsDir = Join-Path $env:USERPROFILE ".claude\skills"
if (-not (Test-Path $SkillsDir)) { New-Item -ItemType Directory -Path $SkillsDir | Out-Null }
Copy-Item -Recurse $SourceDir $DestDir
Write-Host "Skill installed."
Write-Host ""

# -----------------------------------------------
# Dependency checks
# -----------------------------------------------

Write-Host "Checking dependencies..."
Write-Host ""

$MissingDeps = $false

# Python
try {
    $pyVersion = python --version 2>&1
    Write-Host "  [OK]      python ($pyVersion)"
} catch {
    Write-Host "  [MISSING] python3 — required for PPTX editing and thumbnails"
    Write-Host "            Install: https://www.python.org/downloads/"
    $MissingDeps = $true
}

# markitdown
try {
    python -c "import markitdown" 2>$null
    Write-Host "  [OK]      markitdown"
} catch {
    Write-Host "  [MISSING] markitdown — required for reading PPTX files"
    Write-Host "            Install: pip install `"markitdown[pptx]`""
    $MissingDeps = $true
}

# Pillow
try {
    python -c "import PIL" 2>$null
    Write-Host "  [OK]      Pillow"
} catch {
    Write-Host "  [MISSING] Pillow — required for slide thumbnails"
    Write-Host "            Install: pip install Pillow"
    $MissingDeps = $true
}

# defusedxml
try {
    python -c "import defusedxml" 2>$null
    Write-Host "  [OK]      defusedxml"
} catch {
    Write-Host "  [MISSING] defusedxml — required for safe XML parsing"
    Write-Host "            Install: pip install defusedxml"
    $MissingDeps = $true
}

# Node + pptxgenjs
try {
    $nodeVersion = node --version 2>&1
    Write-Host "  [OK]      node ($nodeVersion)"
    try {
        node -e "require('pptxgenjs')" 2>$null
        Write-Host "  [OK]      pptxgenjs"
    } catch {
        Write-Host "  [MISSING] pptxgenjs — required for creating PPTX from scratch"
        Write-Host "            Install: npm install -g pptxgenjs"
        $MissingDeps = $true
    }
} catch {
    Write-Host "  [MISSING] Node.js — required for creating PPTX from scratch"
    Write-Host "            Install: https://nodejs.org/"
    $MissingDeps = $true
}

# LibreOffice (optional)
$libreOfficePath = "C:\Program Files\LibreOffice\program\soffice.exe"
if (Test-Path $libreOfficePath) {
    Write-Host "  [OK]      LibreOffice"
} else {
    Write-Host "  [OPTIONAL] LibreOffice — needed for visual QA (PPTX to image conversion)"
    Write-Host "             Download: https://www.libreoffice.org/download/download/"
}

Write-Host ""

if ($MissingDeps) {
    Write-Host "Some required dependencies are missing. Install them, then restart Claude Code."
} else {
    Write-Host "All required dependencies are installed."
}

Write-Host ""
Write-Host "======================================"
Write-Host "  Installation complete!"
Write-Host "======================================"
Write-Host ""
Write-Host "Restart Claude Code, then try: 'build me a 5-slide pitch deck'"
Write-Host ""
