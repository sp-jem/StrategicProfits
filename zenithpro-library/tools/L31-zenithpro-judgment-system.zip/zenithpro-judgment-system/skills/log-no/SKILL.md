---
name: log-no
description: Capture a correction/rejection into your NO Log so your judgment stops evaporating. Use the instant you tell the AI an output is wrong and want that call saved. Triggers: "log this NO", "log that NO", "log my NO", "save this judgment", "save this correction", "/log-no", "that's wrong - save it", "capture this NO", "add to my judgment library", "log my NOs" (plural = scan whole session).
version: 1.0.0
---

# Log NO — Capture Your Judgment

The capture path. Your judgment evaporates the moment a session ends — every "no, that's wrong, because…" you give is teaching that gets lost unless it's banked. This skill banks it, in your words, the instant you give it.

## Where your files live (resolve first)

1. Read `~/.claude/skills/judgment-system-config.json` → `vault` and `judgment_library` paths.
2. If it doesn't exist, ask once: "Where is your Obsidian vault?" — then offer to save the answer to `~/.claude/skills/judgment-system-config.json` so you're never asked again.

**Where corrections go:** the NO Log at `<judgment_library>/NO-Log.md` (created from this package's template on install).

---

## When to use

- You review an AI output (in THIS session or one you paste in) and it's wrong.
- You say any trigger phrase, OR clearly reject something and want it remembered.
- Singular ("log this NO") = capture the one correction at hand.
- Plural ("log my NOs") = scan the whole current session for every correction and append them all.

## The procedure

1. **Get the date:** run `date "+%Y-%m-%d"` via Bash (Windows: `Get-Date -Format yyyy-MM-dd`). Never guess the date.

2. **Determine the correction.** Pull from what the operator just said + the session context:
   - **What the AI produced** — the thing they rejected (paste/summarize the actual output).
   - **Their NO** — what they said was wrong, in their words.
   - **WHY it was wrong** — the reasoning. *This is the gold.* If it's genuinely unclear from context, ask ONE tight question: "What made it wrong — so the system learns the rule, not just the fix?" Never fabricate the why.
   - **What right looks like** — the standard it should have hit (infer from the correction; keep it concrete).
   - **Category** — one of: copy / strategy / process / benchmark.

3. **Append to the NO Log**, newest at top, under the `## Log` section, in this exact block:

```
### [DATE] — [one-line topic]
- **What the AI produced:** [the rejected output]
- **My no:** [what the operator said]
- **Why it was wrong:** [the reasoning — the gold]
- **What right looks like:** [the standard]
- **Category:** copy / strategy / process / benchmark
- **Source:** [session/project where it happened]
```

Use the Edit tool to insert directly under the `<!-- newest at top -->` line so newest entries sit on top.

4. **Confirm briefly** — one line: "Logged. [topic] → [category]."

5. **Pattern check (the compounding move):** quickly scan the existing NO Log. If this same kind of NO has appeared 3+ times, flag it: "This is the 3rd time you've rejected [pattern] — want me to graduate it into a judgment-library principle (docs 01–04)?" That's how the log feeds the permanent library.

## Guardrails

- **Never fabricate the "why."** It's the most valuable field. Unclear → ask one question. One question max — keep the habit fast.
- **Always resolve paths from config** (see "Where your files live") — this skill must work from any session, any folder.
- **Don't editorialize the operator's judgment.** Capture it in their words; don't soften or "improve" the reasoning.
- **Speed over polish.** The entry can be terse. The point is it gets saved, every time.
- If a session scan ("log my NOs") finds no corrections, say so and append nothing — never invent entries to have something to log.
- If the NO Log file is missing, create it from the template header (`## Log` + `<!-- newest at top -->`), then append.
