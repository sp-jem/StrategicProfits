---
name: delivery-audit
description: Final QC gate before any AI deliverable ships. Source-verifies every claim (hard stop on fabrication), checks the work against YOUR Judgment Library, auto-loops with fixes until APPROVED. Never delivers without APPROVED status. Triggers: /delivery-audit, "run the audit", "audit before delivery", "QC this", "quality check".
version: 1.0.0
---

# Delivery Audit — Your Pre-Delivery QC Gate

## Purpose

This skill is the mandatory final gate before ANYTHING the AI produces gets shipped — to a client, a list, a team, or yourself. It:
1. Verifies all claims against a source of truth (HARD STOP if fabricated)
2. Checks the deliverable against **your own Judgment Library** — your filters, not generic best practice
3. Auto-loops with targeted fixes until ALL checks return APPROVED
4. Never exits by handing you REJECTED work — it fixes and re-audits until clean, or escalates with specifics

**Why this exists:** an AI that produces fast but unchecked work just moves the bottleneck to your review time. This gate is how your captured judgment (NO Log + library docs) gets *enforced*, not just collected.

---

## INTAKE — establish these before anything else

If not provided in the invocation, ask:

1. **Deliverable**: file path or pasted content
2. **Type**: email / sales copy / landing page / slides / plan / document / general
3. **Source of truth**: the brief, transcript, spec, or source material the work was built from (REQUIRED)
4. **Audience**: client-facing, public, team-internal, or personal
5. **Threshold**: Standard (internal/exploratory) / Elevated (default) / Critical (client-facing or public)

## Resolve paths

1. Read `~/.claude/skills/judgment-system-config.json` → `vault`, `judgment_library`.
2. If it doesn't exist, ask once for the vault path and offer to save it to `~/.claude/skills/judgment-system-config.json`.

---

## LAYER 0 — SOURCE GATE (HARD STOP)

Run before everything else.

### 0A — Load source
Read the source-of-truth file completely. If none is provided:
- Status: **BLOCKED**. Say: "Source of truth required — the brief, transcript, or source material this was built from. I cannot verify claims without it." Do NOT proceed.

### 0B — Extract claims from the deliverable
Every: factual claim (numbers, stats, dates, durations), quote, testimonial/case-study detail, story, credential, price/revenue figure or projection.

### 0C — Verify each claim against source
- ✅ **VERIFIED** — directly stated in source
- ⚠️ **INFERRED** — logically implied but not explicit (flag, don't block)
- ❌ **FABRICATED** — not in source; invented or assumed (HARD STOP)

### 0D — Verdict
- Any ❌ → **BLOCKED**. List every fabricated item with a `[SOURCE NEEDED: X]` placeholder. Do not proceed until the operator confirms or replaces each one.
- All ✅/⚠️ → proceed; carry all ⚠️ items into the final report.

---

## LAYER 1 — LOAD YOUR JUDGMENT

Read, in this order (skip gracefully anything not installed, and say so in the report):

1. **`<judgment_library>/03 - Process & Quality Standards.md`** — always, for every deliverable type.
2. The library doc matching the work: `01 - Copy & Taste Judgment.md` (copy/design/pages), `02 - Strategic Judgment.md` (offers/pricing/launches), `04 - The Benchmark.md` (anything where the operator's benchmark person sets the bar).
3. **`<judgment_library>/NO-Log.md`** — scan recent entries for corrections not yet graduated into the docs. The freshest judgment lives here; read it every time.
4. Any voice/brand DNA file the operator maintains for the audience in question.

Extract the **active filters** — the operator's actual principles from those files — into a short manifest. If the library is empty or missing, note it in the report and run the universal checks below only.

---

## LAYER 2 — JUDGMENT CHECK (isolated)

**Spawn this as an isolated sub-agent** (Agent tool, `subagent_type: "general-purpose"`) — never inline. Pass: the deliverable + the extracted filter manifest. Isolation keeps the check honest; an agent that wrote the work grades it soft.

The check reviews the deliverable through the operator's actual decision filters — NOT generic copy critique. Apply every filter found in their library. In addition, always run these universal checks (they ship as starter principles in the library template):

- **Specificity** — does it land on a specific lived moment, or gesture at a category?
- **Compelling test** — would this actually move the intended reader? Flat → flag + "think bigger."
- **No insider jargon** in anything customer-facing.
- **Proof-before-claim** — if the deliverable claims anything is "done / tested / working / live," does it state *how each component was verified*? A blanket "it's all set up" with no per-component evidence is a FLAG.
- **Continuity** — multi-part deliverables: are all opened loops paid off?

Returns: **PASS / FLAG** — each catch quoted at line level + which judgment principle (doc + #) it maps to.

**Optional critic routing:** if the operator has specialist critic agents installed (copy critics, design critics, etc.), spawn the relevant ones in parallel, each isolated, each receiving only the deliverable + manifest. If none are installed, the Judgment Check + source gate still run — that is the minimum viable gate.

---

## LAYER 3 — CONSOLIDATE & SCORE

| Threshold | Required to pass |
|-----------|------------------|
| Standard (70%) | No fabricated claims; no unresolved CRITICAL flags |
| Elevated (85%) | Above + all Judgment FLAGs resolved or consciously accepted by the operator |
| Critical (95%) | Above + zero unaddressed INFERRED claims + every FLAG fixed |

### Report format
```
=== DELIVERY AUDIT REPORT ===
Deliverable: [name] | Loop: [n] of 5 | Threshold: [level]

SOURCE VERIFICATION: CLEAN / FLAGGED / BLOCKED
Verified: [n] | Inferred: [n] | Fabricated: [n]

JUDGMENT CHECK: PASS / FLAG
[each catch + the principle it maps to, e.g. "opens on a category, not a lived moment — doc 01 #1"]

CRITICS (if any): [name]: [grade] — [summary]

OVERALL VERDICT: APPROVED ✅ / REJECTED ❌ / BLOCKED 🚫

ISSUES TO FIX (if not approved):
1. [CRITICAL] [exact issue] — [what to change]
2. [MAJOR] ...
```

---

## LAYER 4 — AUTO-FIX LOOP

```
LOOP:
  IF verdict == APPROVED: exit → deliver
  IF verdict == BLOCKED:  exit → wait for operator input on the listed items
  IF loop_count >= 5: ESCALATE — report what was tried, what changed or keeps
     failing, and what is needed. Never silently loop past 5.
  ELSE:
    1. Apply the ISSUES TO FIX directly to the deliverable (fix, don't ask)
    2. Use ONLY verified source material for fixes; gaps get
       [PLACEHOLDER: need X] — never invented content
    3. Re-run ONLY the checks that failed
    4. Re-consolidate, new report, back to top
```

When a FLAG is intentionally overruled by the operator, offer: "Want me to /log-no the reasoning so the filter self-corrects?" — that's the calibration loop.

## FINAL DELIVERY

On APPROVED: present the deliverable with "APPROVED — [n] loops, [n] issues fixed," a brief list of what changed, and any ⚠️ INFERRED claims flagged for awareness.

## WHAT THIS SKILL NEVER DOES

- Never delivers with REJECTED status — it fixes first
- Never invents content to fill a source gap — placeholders only
- Never skips the source gate, even for "quick" or "internal" work
- Never loops silently past 5 iterations — escalates with specifics
- Never says "looks good" without running every applicable layer
- Never accepts "it passed last time" — each version gets its own audit
