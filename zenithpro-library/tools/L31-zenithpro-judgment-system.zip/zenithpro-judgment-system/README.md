# The Judgment System

Capture how you decide — and make every AI session apply your judgment, even when you're not in the room.

---

## What This Does For You

Right now, your most valuable asset evaporates daily. Every time you tell your AI "no — do it this way, because…", you're teaching it your judgment. And the moment the session ends, that teaching is gone. Tomorrow's session makes the same mistake, and you correct it again. You stay the bottleneck.

This system ends that loop. Every correction gets banked **with your reasoning** the moment you give it, recurring corrections graduate into a Judgment Library that's yours alone, and a delivery-audit gate checks every AI deliverable against *your* captured standards before anything ships — so you stop being the QA layer for your own AI.

Do this for a year and you own a working record of how you decide — something nobody else can replicate, because it only exists in your corrections.

## How It Works

Three parts, one loop:

1. **`/log-no`** (capture) — the instant you reject or correct an AI output, say "log this NO." The correction, your reasoning, and what right looks like get appended to your NO Log. Say "log my NOs" at the end of a session and it scans the whole conversation for you.
2. **Judgment Library** (organization) — five library docs (00–04) plus the NO Log in your vault. A correction you've given 3+ times is a principle — it graduates into the numbered docs: Copy & Taste, Strategic, Process & Quality, The Benchmark.
3. **`/delivery-audit`** (enforcement) — the pre-delivery gate. It source-verifies every claim in a deliverable (hard stop on anything fabricated) and checks the work against your library, then fixes and re-audits until approved.

See `how-it-works.md` for diagrams.

---

## Installation

### Mac (Terminal)

```bash
cd ~/Downloads/zenithpro-judgment-system
chmod +x install.sh
./install.sh
```

### Windows (PowerShell)

```powershell
cd $env:USERPROFILE\Downloads\zenithpro-judgment-system
.\install.ps1
```

If PowerShell blocks the script: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then re-run.

The installer asks one question — where your Obsidian vault is — then sets up everything (on a re-run it will also ask before overwriting anything you already have). **Restart Claude Code afterward** so the new skills are picked up.

## What Gets Installed

| What | Where |
|------|-------|
| `log-no` skill | `~/.claude/skills/log-no/` |
| `delivery-audit` skill | `~/.claude/skills/delivery-audit/` |
| Judgment Library (docs 00–04 + NO Log) | `<your vault>/Judgment Library/` |
| Shared config | `~/.claude/skills/judgment-system-config.json` |

Nothing else is touched. If you already have a Judgment Library, the installer keeps your existing files and only adds what's missing.

## How to Use

**Day 1 — just work.** The first time your AI gets something wrong, correct it the way you already do — then say **"log this NO."** That's the whole habit. 3 minutes, and the reasoning is the part that matters.

**End of a session with several corrections:** say **"log my NOs"** — the AI scans the conversation and banks all of them.

**Before anything ships:** run **`/delivery-audit`** with the deliverable and its source material. It verifies every claim and checks the work against your library, then fixes and re-audits until approved.

**Quarterly (15 minutes):** read your NO Log. Any correction you've given 3+ times graduates into the numbered library docs — `/log-no` flags these for you automatically.

## Configuration

`~/.claude/skills/judgment-system-config.json`:
```json
{
  "vault": "/path/to/your/vault",
  "judgment_library": "/path/to/your/vault/Judgment Library"
}
```
Both skills read this to find your library. Edit it if you move your vault.

## Troubleshooting

- **A skill doesn't trigger.** Restart Claude Code after installing — skills are discovered at session start. Then say the trigger phrase exactly: "log this NO" or "/delivery-audit".
- **"Where is your Obsidian vault?" keeps being asked.** The config file is missing — re-run the installer, or create it by hand (see Configuration above).
- **The library docs feel empty.** They should — they're scaffolds. The starter principles are training wheels; the real library is built from *your* logged NOs. Give it two weeks of "log this NO" before judging it.

**Mac-specific:** if `./install.sh` says permission denied, run `chmod +x install.sh` first.

**Windows-specific:** if scripts are blocked, see the execution-policy fix under Installation.

## Requirements

- **Claude Code** installed
- **An Obsidian vault** (or any folder you treat as one — the library is plain Markdown)

---

*Packaged by Strategic Profits for ZenithPro.*
