# How the Judgment System Works

Three parts, one compounding loop.

## The Loop

```mermaid
flowchart LR
A[You correct the AI<br>with a reason] --> B[log-no banks it<br>in your NO Log]
B --> C[Recurring NOs graduate<br>into your Judgment Library]
C --> D[delivery-audit enforces<br>the library on every deliverable]
D --> E[Better first drafts]
E --> A
```

Every cycle, less correcting and better output — because the system remembers what you already taught it.

## Capture — from correction to principle

```mermaid
flowchart TD
A[You say: log this NO] --> B[Entry appended to NO Log<br>your words, your reasoning]
B --> C{Same NO<br>given 3+ times?}
C --> D[Yes — graduate it into<br>docs 01 to 04 as a principle]
C --> E[No — it waits in the log<br>and keeps watching]
```

The "why it was wrong" line is the gold — it's what teaches the system to think like you, not just fix one mistake.

## Enforcement — the delivery-audit gate

```mermaid
flowchart TD
A[Deliverable ready] --> B[Source gate<br>every claim verified]
B --> C[Judgment check<br>your filters applied]
C --> D{Verdict}
D --> E[APPROVED — ship it]
D --> F[Issues found<br>fix and re-audit<br>max 5 loops]
F --> C
```

Fabricated claims are a hard stop. Judgment flags loop until fixed. You only see APPROVED work.

## Where everything lives

```mermaid
flowchart TD
A[Your vault] --> B[Judgment Library folder<br>docs 00 to 04 plus NO Log]
C[Home .claude folder] --> D[skills: log-no<br>and delivery-audit]
C --> E[judgment-system-config.json<br>points the skills at your vault]
```
