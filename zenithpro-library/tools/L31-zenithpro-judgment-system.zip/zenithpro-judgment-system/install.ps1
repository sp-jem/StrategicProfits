# The Judgment System - installer (Windows PowerShell)
# Installs: log-no skill, delivery-audit skill, Judgment Library template.
#
# Usage:  .\install.ps1                    (prompts for vault path)
#         .\install.ps1 C:\path\to\vault   (vault path prefilled)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillsDir = Join-Path $env:USERPROFILE ".claude\skills"
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"

Write-Host "Installing the Judgment System..." -ForegroundColor Cyan
Write-Host ""

# -- 1. Vault path -------------------------------------------------
$Default = if ($args.Count -ge 1) { $args[0] } else { "" }
$Vault = Read-Host "Path to your Obsidian vault [$Default]"
if ([string]::IsNullOrWhiteSpace($Vault)) { $Vault = $Default }
$Vault = $Vault.Trim().Trim('"')
if ([string]::IsNullOrWhiteSpace($Vault)) {
    Write-Host "!! A vault path is required (your Judgment Library lives there). Re-run and provide one." -ForegroundColor Red
    exit 1
}
if (-not (Test-Path -LiteralPath $Vault)) {
    Write-Host "!! Vault not found at: $Vault" -ForegroundColor Red
    Write-Host "   Check the path and re-run."
    exit 1
}
$Library = Join-Path $Vault "Judgment Library"

# -- 2. Skills (backup any existing copy before overwrite) ---------
New-Item -ItemType Directory -Force -Path $SkillsDir | Out-Null
foreach ($skill in @("log-no", "delivery-audit")) {
    $dest = Join-Path $SkillsDir $skill
    $src = Join-Path $ScriptDir "skills\$skill"
    if (Test-Path -LiteralPath $dest) {
        $answer = Read-Host "  Skill '$skill' already exists. Overwrite (a backup is kept)? [y/N]"
        if ($answer -match "^[yY]$") {
            Move-Item -LiteralPath $dest -Destination "$dest.bak-$Stamp"
            Copy-Item -LiteralPath $src -Destination $dest -Recurse
            Write-Host "  OK   $skill -> $dest (backup: $skill.bak-$Stamp)"
        } else {
            Write-Host "  SKIP $skill (kept your existing version)"
        }
    } else {
        Copy-Item -LiteralPath $src -Destination $dest -Recurse
        Write-Host "  OK   $skill -> $dest"
    }
}

# -- 3. Judgment Library template (never clobbers a living library) --
New-Item -ItemType Directory -Force -Path $Library | Out-Null
$Added = 0
Get-ChildItem -LiteralPath (Join-Path $ScriptDir "judgment-library-template") -Filter "*.md" | ForEach-Object {
    $target = Join-Path $Library $_.Name
    if (Test-Path -LiteralPath $target) {
        Write-Host "  KEEP $($_.Name) (already in your library - not touched)"
    } else {
        Copy-Item -LiteralPath $_.FullName -Destination $target
        $script:Added++
    }
}
Write-Host "  OK   Judgment Library -> $Library ($Added new file(s))"

# -- 4. Shared config ----------------------------------------------
$Config = Join-Path $SkillsDir "judgment-system-config.json"
if (Test-Path -LiteralPath $Config) { Copy-Item -LiteralPath $Config -Destination "$Config.bak-$Stamp" }
@{ vault = $Vault; judgment_library = $Library } | ConvertTo-Json | Set-Content -LiteralPath $Config -Encoding UTF8
Write-Host "  OK   config -> $Config"

# -- 5. Verify ------------------------------------------------------
Write-Host ""
Write-Host "Verifying installation..."
$Fail = $false
@(
    (Join-Path $SkillsDir "log-no\SKILL.md"),
    (Join-Path $SkillsDir "delivery-audit\SKILL.md"),
    (Join-Path $Library "00 - Judgment Library README.md"),
    (Join-Path $Library "NO-Log.md"),
    $Config
) | ForEach-Object {
    if (Test-Path -LiteralPath $_) {
        Write-Host "  PASS  $_" -ForegroundColor Green
    } else {
        Write-Host "  FAIL  $_" -ForegroundColor Red
        $script:Fail = $true
    }
}

Write-Host ""
if (-not $Fail) {
    Write-Host "Judgment System installed." -ForegroundColor Green
    Write-Host ""
    Write-Host "Next steps:"
    Write-Host "  1. Restart Claude Code (so the new skills are picked up)."
    Write-Host "  2. The next time you correct your AI, say 'log this NO'."
    Write-Host "  3. Run /delivery-audit before anything ships."
} else {
    Write-Host "!! One or more components failed to install - see FAIL lines above." -ForegroundColor Red
    exit 1
}
