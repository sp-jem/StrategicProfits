#!/usr/bin/env bash
# The Judgment System — installer (Mac / Linux)
# Installs: log-no skill, delivery-audit skill, Judgment Library template.
#
# Usage:  ./install.sh                   (prompts for vault path)
#         ./install.sh /path/to/vault   (vault path prefilled)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILLS_DIR="${HOME}/.claude/skills"
STAMP="$(date +%Y%m%d-%H%M%S)"

echo "Installing the Judgment System..."
echo ""

# ── 1. Vault path ────────────────────────────────────────────────
DEFAULT_VAULT=""
if [ -n "$1" ]; then DEFAULT_VAULT="$1"; fi
read -r -p "Path to your Obsidian vault [${DEFAULT_VAULT}]: " VAULT
VAULT="${VAULT:-$DEFAULT_VAULT}"
if [ -z "$VAULT" ]; then
  echo "!! A vault path is required (your Judgment Library lives there). Re-run and provide one."
  exit 1
fi
VAULT="${VAULT/#\~/$HOME}"
case "$VAULT" in
  *\"*)
    echo "!! Vault path contains a double-quote character — unsupported. Re-run with a clean path."
    exit 1
    ;;
esac
if [ ! -d "$VAULT" ]; then
  echo "!! Vault not found at: $VAULT"
  echo "   Check the path and re-run."
  exit 1
fi
LIBRARY="${VAULT}/Judgment Library"

# ── 2. Skills (backup any existing copy before overwrite) ───────
mkdir -p "$SKILLS_DIR"
for skill in log-no delivery-audit; do
  if [ -d "${SKILLS_DIR}/${skill}" ]; then
    read -r -p "  Skill '${skill}' already exists. Overwrite (a backup is kept)? [y/N]: " ANSWER
    case "$ANSWER" in
      y|Y)
        mv "${SKILLS_DIR}/${skill}" "${SKILLS_DIR}/${skill}.bak-${STAMP}"
        cp -R "${SCRIPT_DIR}/skills/${skill}" "${SKILLS_DIR}/${skill}"
        echo "  OK   ${skill} -> ${SKILLS_DIR}/${skill} (backup: ${skill}.bak-${STAMP})"
        ;;
      *)
        echo "  SKIP ${skill} (kept your existing version)"
        ;;
    esac
  else
    cp -R "${SCRIPT_DIR}/skills/${skill}" "${SKILLS_DIR}/${skill}"
    echo "  OK   ${skill} -> ${SKILLS_DIR}/${skill}"
  fi
done

# ── 3. Judgment Library template (never clobbers a living library) ──
mkdir -p "$LIBRARY"
ADDED=0
for f in "${SCRIPT_DIR}/judgment-library-template/"*.md; do
  base="$(basename "$f")"
  if [ -e "${LIBRARY}/${base}" ]; then
    echo "  KEEP ${base} (already in your library — not touched)"
  else
    cp "$f" "${LIBRARY}/${base}"
    ADDED=$((ADDED+1))
  fi
done
echo "  OK   Judgment Library -> ${LIBRARY} (${ADDED} new file(s))"

# ── 4. Shared config ─────────────────────────────────────────────
CONFIG="${SKILLS_DIR}/judgment-system-config.json"
if [ -e "$CONFIG" ]; then cp "$CONFIG" "${CONFIG}.bak-${STAMP}"; fi
cat > "$CONFIG" <<JSON
{
  "vault": "${VAULT}",
  "judgment_library": "${LIBRARY}"
}
JSON
echo "  OK   config -> ${CONFIG}"

# ── 5. Verify ────────────────────────────────────────────────────
echo ""
echo "Verifying installation..."
FAIL=0
for path in \
  "${SKILLS_DIR}/log-no/SKILL.md" \
  "${SKILLS_DIR}/delivery-audit/SKILL.md" \
  "${LIBRARY}/00 - Judgment Library README.md" \
  "${LIBRARY}/NO-Log.md" \
  "$CONFIG"; do
  if [ -e "$path" ]; then
    echo "  PASS  $path"
  else
    echo "  FAIL  $path"
    FAIL=1
  fi
done

echo ""
if [ "$FAIL" -eq 0 ]; then
  echo "Judgment System installed."
  echo ""
  echo "Next steps:"
  echo "  1. Restart Claude Code (so the new skills are picked up)."
  echo "  2. The next time you correct your AI, say 'log this NO'."
  echo "  3. Run /delivery-audit before anything ships."
else
  echo "!! One or more components failed to install — see FAIL lines above."
  exit 1
fi
