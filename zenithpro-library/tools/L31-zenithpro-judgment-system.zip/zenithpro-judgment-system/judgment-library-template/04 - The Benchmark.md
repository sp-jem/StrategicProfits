# The Benchmark

> The person whose standard you measure work against — internalized, so the AI can apply their bar when they're not in the room.

**What belongs here:** Most operators have a benchmark person — a mentor, a founder, a partner, a market leader — whose reaction they mentally simulate before shipping ("would they sign off on this?"). This doc makes that simulation explicit so it can be applied consistently.

If you don't have a benchmark person, skip this doc — the other three carry the system.

---

## Who is your benchmark?

- **Name/role:** [who]
- **Why their bar matters:** [what they're the standard FOR — taste? strategy? naming? scale of thinking?]

## The benchmark's known components

Build this from **their actual words** — meeting notes, recordings, messages, feedback they've given you. Never from your impression of them.

```
### [Component name — e.g., "Thinks bigger", "Naming sensibility", "What they always reject"]
**The pattern:** [what they consistently do/demand]
**Evidence:** [dated quote or documented moment — theirs, verbatim]
**How to apply:** [the check an AI session runs against work]
```

## How to apply

Before any deliverable where this person's standard is the bar: run the work against each component above and ask "what would [benchmark] reject here?" Fix those things *before* they see it.

---

## ⚠️ Permission note (read before going deeper)

A richer version of this doc mines the benchmark person's *actual transcripts* (meetings, recordings) into their mental models and decision heuristics. That is powerful — and it is built from someone else's words. **Only do it with their knowledge and permission**, and only from material you legitimately have. Their thinking is their asset; treat it the way you'd want your own judgment library treated.

## Your components

<!-- Add evidence-backed components as you collect them -->
