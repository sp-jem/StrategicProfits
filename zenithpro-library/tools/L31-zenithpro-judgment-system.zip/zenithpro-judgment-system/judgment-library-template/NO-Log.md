# The NO Log

> Each time you reject an AI's work and say why, you bank an asset. A year of that, logged daily, becomes a record of how you decide — one nobody else can build.

This is where your judgment stops evaporating. **Every time you reject or correct an AI output, log it here.** 3 minutes. The reasoning matters more than the correction.

---

## How to log (the format)

Copy this block each time — or just say **"log this NO"** and the `/log-no` skill does it for you:

```
### [DATE] — [one-line what it was about]
- **What the AI produced:** [the thing you rejected — paste or summarize]
- **My no:** [what you said / what was wrong]
- **Why it was wrong:** [the reasoning — THIS is the gold]
- **What right looks like:** [the standard it should have hit]
- **Category:** copy / strategy / process / benchmark
- **Source:** [session/project where it happened]
```

The "why" and "what right looks like" are the two lines that teach the system to think like you. Don't skip them.

---

## Even faster (let the AI do it)

At the end of any session where you corrected something, just say:

> "Log my NOs from this session."

The AI will scan the session, extract your corrections with reasoning, and append them in the format above. Zero typing.

---

## Quarterly: fold into the library

Every ~quarter (or when the log gets long), re-read it and promote recurring patterns into the numbered judgment docs (01–04). A "no" you've given 3+ times is a principle — graduate it. The `/log-no` skill flags these automatically.

---

## Log

<!-- newest at top -->
