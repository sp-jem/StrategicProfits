# Your Strategic Judgment

> How you make offer, pricing, launch, and revenue decisions — and WHY.

**What belongs here:** the filters you run before committing money, calendar, or positioning — what makes an offer "ready," what kills a launch idea, how you choose between two valid plays. Not borrowed frameworks: the calls *you* actually make.

**How entries get here:** graduated from your NO Log when a pattern repeats. Each principle keeps its evidence.

---

## Entry format

```
## N. [Principle name]
**The rule:** [the filter, stated so an AI can apply it]
**Why:** [your actual reasoning]
**What right looks like:** [a concrete standard]
**Evidence:** [dated quote from your own session]
```

---

## Starter principles (universal — keep, edit, or replace with your own)

## 1. Check what already exists before building new
**The rule:** Before any new asset, offer, or system is proposed, inventory what's already built and working. New is the last resort, not the default.
**Why:** Most "build" requests are actually "find and reuse" requests — building duplicates burns the calendar twice.
**What right looks like:** Every build proposal opens with what was checked and why it doesn't cover the need.
**Evidence:** ⚠️ STARTER — replace with your own.

## 2. Lead with the belief shift
**The rule:** Every offer and campaign names the ONE belief the audience must change for the sale to make sense — before any asset gets written.
**Why:** Assets built without a named belief shift optimize sentences instead of minds.
**What right looks like:** You can state "they currently believe X; this makes them believe Y" in one breath.
**Evidence:** ⚠️ STARTER — replace with your own.

---

## Your principles

<!-- Graduate principles from your NO Log here -->
