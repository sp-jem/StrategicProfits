# Your Copy & Taste Judgment

> What you accept and reject in copy, design, and pages — and WHY.

**What belongs here:** the filters you apply when you look at a headline, an email, a page, an ad, a deck — the things that make you say "no, that's flat" or "yes, ship it." Not generic copywriting rules: *your* taste, in your words.

**How entries get here:** graduated from your NO Log when the same correction appears 3+ times. Each principle keeps its evidence.

---

## Entry format

```
## N. [Principle name]
**The rule:** [the filter, stated so an AI can apply it]
**Why:** [your actual reasoning — the gold]
**What right looks like:** [a concrete standard, not an adjective]
**Evidence:** [dated quote from your own session]
```

---

## Starter principles (universal — keep, edit, or replace with your own)

## 1. The specificity test
**The rule:** Copy must land on a specific lived moment, not gesture at a category. "Tuesday, 11pm, still answering client emails" beats "busy entrepreneurs struggle with time."
**Why:** Readers recognize themselves in moments, not demographics.
**What right looks like:** Every claim about the reader's life could only be written by someone who has watched it happen.
**Evidence:** ⚠️ STARTER — replace with your own dated quote when you first enforce this.

## 2. No insider jargon in customer-facing copy
**The rule:** Internal shorthand, framework names, and team language never appear in copy a customer reads.
**Why:** Jargon makes the reader do translation work — and signals the copy was written for the company, not for them.
**What right looks like:** A first-time reader understands every sentence without context.
**Evidence:** ⚠️ STARTER — replace with your own.

## 3. The compelling test
**The rule:** Before shipping, ask: would this actually move the intended reader to act? "Accurate but flat" fails. Flat → don't polish the sentences; think bigger about the idea.
**Why:** Copy that merely informs gets skimmed and forgotten — the cost of flat work is invisible because nothing happens.
**What right looks like:** You can name the specific feeling or decision the piece produces in the reader, and the opening earns it.
**Evidence:** ⚠️ STARTER — replace with your own.

## 4. Continuity — pay off every opened loop
**The rule:** In any multi-part deliverable (sequence, deck, funnel), every promise, tease, or open question gets explicitly paid off before the end.
**Why:** Unclosed loops read as carelessness to the one reader who noticed — and the engaged readers always notice.
**What right looks like:** A final pass lists each loop opened and where it closes.
**Evidence:** ⚠️ STARTER — replace with your own.

---

## Your principles

<!-- Graduate principles from your NO Log here, numbered, newest additions at the bottom -->
