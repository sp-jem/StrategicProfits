# Your Process & Quality Standards

> How work gets verified, sourced, and delivered in your world — and WHY.

**What belongs here:** your non-negotiables about data, sources, testing, and delivery — the standards you find yourself re-explaining when AI (or people) cut corners. This is the doc the `/delivery-audit` skill reads on *every* deliverable, regardless of type.

**How entries get here:** graduated from your NO Log. Each principle keeps its evidence.

---

## Entry format

```
## N. [Principle name]
**The rule:** [the standard, stated so an AI can apply it]
**Why:** [your actual reasoning]
**What right looks like:** [a concrete, checkable behavior]
**Evidence:** [dated quote from your own session]
```

---

## Starter principles (universal — keep, edit, or replace with your own)

## 1. Never assume without a source of truth
**The rule:** No factual claim ships without tracing to a specific source read in the current session. "Best practice" and memory are not sources.
**Why:** Unsourced claims are indistinguishable from fabricated ones — and they compound downstream.
**What right looks like:** Every number, quote, and named fact in a deliverable can be pointed to a file and line.
**Evidence:** ⚠️ STARTER — replace with your own.

## 2. Proof-before-claim
**The rule:** Nothing is reported as "done / tested / working / live" without stating how each component was verified. A blanket "it's all set up" is a flag, not a status.
**Why:** "Done" without evidence makes you the QA layer — which is the bottleneck this whole system exists to remove.
**What right looks like:** Status reports break work into components, each marked TESTED / BUILT-BUT-UNTESTED / NOT-BUILT with the evidence.
**Evidence:** ⚠️ STARTER — replace with your own.

## 3. An unsourced number is a fabricated number
**The rule:** A figure that exists only in the document citing it — with no persisted source file — is treated as fabrication until traced. Totals must sum to their own components.
**Why:** Carry-forward numbers silently inherit transcription errors no one re-checks.
**What right looks like:** Live-pulled data gets persisted to an evidence file first (with the pull date and method), then cited.
**Evidence:** ⚠️ STARTER — replace with your own.

---

## Your principles

<!-- Graduate principles from your NO Log here -->
