# Your Judgment Library

> The one thing no one else can build for you — *yours*.

---

## What this is

This is not voice DNA (how you *sound*). This is judgment DNA — **how you decide.**

The most valuable thing about an operator is the judgment that never made it into a manual — the calls you make in the moment, for reasons you rarely write down. For the first time, that judgment can be scaled — *if it's captured.* This library is that capture. It turns the calls you make once (and then lose) into reusable assets any AI session can apply.

Every principle that enters this library should be traceable to something you **actually said** in a real working session — not theory you agree with, not borrowed best practice. The evidence line on each principle is what keeps the library honest.

## Why it exists (the bottleneck → multiplier shift)

Your judgment is applied once per decision, then evaporates. That makes you the bottleneck of everything you run. This library turns each decision into a reusable asset, so any AI session can decide *the way you would* — even when you're not in the room.

## How it's used

**Every AI session doing strategic, copy, offer, or campaign work for you should read the relevant judgment doc BEFORE producing output** — and the `/delivery-audit` skill enforces it after, before anything ships.

| Doc | Read it before… |
|-----|-----------------|
| 01 - Copy & Taste Judgment | Writing/reviewing any copy, design, or page |
| 02 - Strategic Judgment | Offer, pricing, launch, lead-gen, or revenue decisions |
| 03 - Process & Quality Standards | Any task touching data, sources, or delivery |
| 04 - The Benchmark | Anything where a specific person's standard is the bar |

## How it grows (this is the moat)

The library is **living**, not a snapshot. It deepens two ways:

1. **The NO Log** — every time you reject or correct an AI output, say "log this NO" (the `/log-no` skill) and the correction gets banked with your reasoning. See `NO-Log.md`.
2. **Graduation** — a NO you've given 3+ times is a principle. Promote it into docs 01–04 (the `/log-no` skill flags these for you).

A year of this and the library holds something nobody else can replicate — because it only exists in how *you* decide.

## Honesty rules

- Every principle cites at least one dated quote from your own sessions.
- Don't write principles you *wish* you held. Capture the ones you actually enforce.
- Thin evidence → mark the principle `⚠️ THIN — needs more data` rather than guessing.

*Created: [date you installed this]. Last grown: [update as you graduate principles].*
