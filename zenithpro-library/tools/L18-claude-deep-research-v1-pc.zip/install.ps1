# Claude Deep Research Skill — Windows PowerShell Installer
# Installs the skill into ~/.claude/skills/claude-deep-research/
#
# If you get a script execution error, run first:
#   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

$ErrorActionPreference = "Stop"

$SkillName = "claude-deep-research"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$HomeDir = $env:USERPROFILE
$InstallDir = Join-Path $HomeDir ".claude\skills\$SkillName"
$ClaudeDir = Join-Path $HomeDir ".claude"

Write-Host ""
Write-Host "======================================" -ForegroundColor Cyan
Write-Host "  Claude Deep Research Skill Installer" -ForegroundColor Cyan
Write-Host "======================================" -ForegroundColor Cyan
Write-Host ""

# Check for Python
$PythonCmd = $null
if (Get-Command "python" -ErrorAction SilentlyContinue) {
    $PythonCmd = "python"
} elseif (Get-Command "python3" -ErrorAction SilentlyContinue) {
    $PythonCmd = "python3"
}

if ($null -eq $PythonCmd) {
    Write-Host "ERROR: Python is not installed." -ForegroundColor Red
    Write-Host "Download from: https://www.python.org/downloads/"
    Write-Host "Check 'Add Python to PATH' during installation."
    exit 1
}

$PythonVersion = & $PythonCmd --version 2>&1
Write-Host "Python found: $PythonVersion" -ForegroundColor Green
Write-Host ""

# Check for Claude Code directory
if (-not (Test-Path $ClaudeDir)) {
    Write-Host "ERROR: ~/.claude directory not found." -ForegroundColor Red
    Write-Host "Please install Claude Code first."
    exit 1
}

# Check for existing installation
if (Test-Path $InstallDir) {
    Write-Host "Existing installation found at: $InstallDir" -ForegroundColor Yellow
    $Confirm = Read-Host "Overwrite? (y/N)"
    if ($Confirm -notmatch "^[Yy]$") {
        Write-Host "Installation cancelled."
        exit 0
    }
    # Backup existing config if present
    $ExistingConfig = Join-Path $InstallDir "config.json"
    if (Test-Path $ExistingConfig) {
        Copy-Item $ExistingConfig "$ExistingConfig.bak" -Force
        Write-Host "  Backed up: config.json.bak" -ForegroundColor Yellow
    }
}

# Create install directory
New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null

# Copy skill files
Write-Host "Installing files to: $InstallDir"

Copy-Item (Join-Path $ScriptDir "SKILL.md")    (Join-Path $InstallDir "SKILL.md")    -Force
Copy-Item (Join-Path $ScriptDir "research.py") (Join-Path $InstallDir "research.py") -Force

$ExistingConfig = Join-Path $InstallDir "config.json"
$BackupConfig   = Join-Path $InstallDir "config.json.bak"

if (-not (Test-Path $ExistingConfig) -or (Test-Path $BackupConfig)) {
    Copy-Item (Join-Path $ScriptDir "config.json") $ExistingConfig -Force
    Write-Host "  Installed: config.json (template)" -ForegroundColor Green
} else {
    Write-Host "  Kept existing: config.json (preserved your session key)" -ForegroundColor Green
}

# Verify
$Verify = @("SKILL.md", "research.py", "config.json") | ForEach-Object {
    Test-Path (Join-Path $InstallDir $_)
}
if ($Verify -contains $false) {
    Write-Host "ERROR: Verification failed — some files were not installed." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "======================================" -ForegroundColor Green
Write-Host "  Installation Complete" -ForegroundColor Green
Write-Host "======================================" -ForegroundColor Green
Write-Host ""
Write-Host "Files installed:" -ForegroundColor White
Write-Host "  $InstallDir\SKILL.md"
Write-Host "  $InstallDir\research.py"
Write-Host "  $InstallDir\config.json"
Write-Host ""
Write-Host "======================================" -ForegroundColor Yellow
Write-Host "  NEXT STEP: Add Your Session Key" -ForegroundColor Yellow
Write-Host "======================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "1. Open claude.ai in Chrome (logged in)"
Write-Host "2. Press F12 to open DevTools"
Write-Host "3. Click: Application > Cookies > https://claude.ai"
Write-Host "4. Find 'sessionKey' and copy its value"
Write-Host "5. Open this file in Notepad:"
Write-Host "   $InstallDir\config.json"
Write-Host "6. Replace YOUR_SESSION_KEY_HERE with your copied value"
Write-Host ""
Write-Host "After that, restart Claude Code and say:"
Write-Host "  'claude deep research: [your topic]'"
Write-Host ""
Write-Host "Or run directly in PowerShell:"
Write-Host "  $PythonCmd `"$InstallDir\research.py`" `"your research question`""
Write-Host ""
