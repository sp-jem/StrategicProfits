# HeyGen Video Toolkit

Generate professional talking-head videos of yourself using AI -- without being on camera. Write a script (or have Claude write one), and your HeyGen avatar delivers it on video in minutes.

This toolkit is two Claude Code skills that work together:

---

## The Two Skills (and When to Use Each)

### heygen-avatar -- "Make me a video"
This is the core engine. It connects to HeyGen's API using YOUR trained avatar and voice clone to produce actual videos. You give it a script, it generates a video of "you" saying it, and downloads the finished .mp4 file.

**Use this when:** You need a specific video produced. Course content, social clips, marketing videos, client responses, announcements -- anything where you'd normally need to be on camera.

**Example prompts in Claude Code:**
```
"Generate an avatar video saying: Hey everyone, welcome to this week's update."
"Create a 30-second video announcing the new program launch"
"Make a video of me delivering this script: [paste your script]"
"Generate a video with a dark blue background saying: Three things you need to know..."
```

### ai-talking-head -- "Help me plan video content"
This is the strategy and workflow skill. It contains knowledge about presenter styles, script formulas, platform optimization, and multi-model video generation. Think of it as a video production consultant that lives inside Claude Code.

**Use this when:** You're planning a video content strategy, need help choosing the right presenter style, want platform-specific optimization (TikTok vs YouTube vs LinkedIn), or want to explore AI video models beyond HeyGen.

**Example prompts in Claude Code:**
```
"What presenter style should I use for LinkedIn thought leadership content?"
"Write me a 15-second TikTok hook script about [topic]"
"Help me plan a 5-video series for my course module on [topic]"
"What's the best script structure for a product demo video?"
```

**In short:** `heygen-avatar` makes the video. `ai-talking-head` helps you think about what to make and how to make it well.

---

## What You Need Before Installing

### Required

1. **Claude Code** installed and working on your computer
2. **Python 3** installed (check: run `python3 --version` in your terminal)
3. **A HeyGen account** with:
   - A trained avatar (you upload a video of yourself, HeyGen creates your digital twin)
   - A voice clone (HeyGen clones your voice from an audio sample)
   - An API key

### Optional

4. **A fal.ai account** -- This unlocks additional AI video models (Sora 2, Veo 3.1, Kling v2.5) used by the ai-talking-head skill. You do NOT need this to generate videos with your HeyGen avatar. Only get this if you want to experiment with other video generation models beyond HeyGen.

### HeyGen Plans

Any HeyGen plan that includes API access will work. The free tier gives limited credits. The Creator plan ($29/mo as of 2026) gives enough credits for regular use. Check HeyGen's current pricing at heygen.com.

---

## How to Find Your HeyGen Credentials

### API Key
1. Log into heygen.com
2. Click your profile icon (top right)
3. Go to **Settings**
4. Click the **API** tab
5. Copy your API key (starts with `sk_`)

### Avatar ID
1. Log into heygen.com
2. Go to **Avatars** in the left sidebar
3. Click on YOUR trained avatar (the one that looks like you)
4. The avatar ID is in the URL bar or in the avatar details panel
5. It looks like a long string: `88d2404a96e6440c81ee3a78cdde6a1b`

### Voice Clone ID
1. Log into heygen.com
2. Go to **Voices** in the left sidebar
3. Click on YOUR voice clone
4. The voice ID is in the details panel
5. It looks like: `8e48ea1d56644c1a9dd7bbb85ed504bf`

**Tip:** If you can't find the IDs in the HeyGen dashboard, ask Claude Code: "Check my HeyGen credits" after installing. If the API key works, you're connected. Then ask HeyGen support for your specific avatar and voice IDs.

---

## Installation

### Mac / Linux

Open Terminal and run:

```bash
cd /path/to/HeyGen-Video-Toolkit
chmod +x install.sh
./install.sh
```

### Windows

Open PowerShell and run:

```powershell
cd C:\path\to\HeyGen-Video-Toolkit
.\install.ps1
```

### What the Installer Does

1. Copies both skills to `~/.claude/skills/` (where Claude Code finds them)
2. Creates a video output folder at `~/Documents/heygen-avatar-output/`
3. Asks for your HeyGen API key, avatar ID, and voice ID
4. Optionally asks for a fal.ai key (for multi-model generation -- you can skip this)

If you don't have your credentials handy during install, just press Enter to skip. You can configure them later by editing:
`~/.claude/skills/heygen-avatar/references/config.json`

---

## Quick Start

After installing and configuring your API key, restart Claude Code and try:

```
"Check my HeyGen credits"
```

If it shows your credit balance, you're connected. Now generate your first video:

```
"Generate an avatar video saying: Hey, this is a test of my AI avatar. Pretty cool, right?"
```

The video takes ~5-8 minutes to generate. Claude will poll HeyGen and download the finished .mp4 to your output folder.

---

## What You Can Do

### Basic Video Generation
```
"Generate a video saying: [your script]"
"Make a 720p video saying: [shorter script for smaller file]"
```

### With Custom Backgrounds
```
"Generate a video with a dark background saying: [script]"
"Generate a video with this background image: /path/to/image.png"
```

### Script Writing Help
```
"Write a 30-second script for a YouTube ad about [product]"
"Write 5 different hook scripts for TikTok about [topic]"
"Help me write a course welcome video script"
```

### Video Strategy
```
"What's the best format for LinkedIn video content?"
"Plan a 3-video series introducing my new program"
"What presenter archetype should I use for my audience?"
```

### Account Management
```
"Check my HeyGen credits"
"List my configured avatars"
"List my configured voices"
```

---

## Adding More Avatars and Voices

As you train more avatars or clone more voice variations in HeyGen, add them to your config.

Edit `~/.claude/skills/heygen-avatar/references/config.json` and add entries under `avatars` or `voices`:

```json
"avatars": {
    "my_avatar": { "id": "abc123...", "description": "Primary avatar" },
    "casual": { "id": "def456...", "description": "Casual setting avatar" },
    "studio": { "id": "ghi789...", "description": "Studio background" }
}
```

Then use them by name:
```
"Generate a video using my casual avatar saying: [script]"
```

Or from the command line:
```bash
python3 ~/.claude/skills/heygen-avatar/references/generate.py "Script" --avatar casual
```

---

## Script Writing Tips

| Words | Duration | Best For |
|-------|----------|----------|
| 15 | ~5 sec | Social media hook |
| 45 | ~15 sec | Short clip / TikTok |
| 75 | ~30 sec | Social post |
| 150 | ~60 sec | Full testimonial / explainer |
| 300 | ~2 min | Course segment |

**Tips for better avatar videos:**
- Write conversationally -- these aren't blog posts. Use "you're", "don't", "let's"
- Short sentences sound better than long ones on avatar
- Use "..." in your script where you want natural pauses
- Spell out numbers ("three" not "3") for more natural speech
- Keep individual videos under 2 minutes -- quality degrades in longer takes

---

## Credit Costs

- Standard avatar: ~2 credits per minute of video
- Avatar IV (newest, highest quality): ~6 credits per minute
- Run `"Check my HeyGen credits"` in Claude Code to see your balance

---

## Command Line Reference

You can also use the generate.py script directly without Claude Code:

```bash
# Generate a video (waits for completion, downloads .mp4)
python3 ~/.claude/skills/heygen-avatar/references/generate.py "Your script here"

# Use a specific avatar and voice
python3 ~/.claude/skills/heygen-avatar/references/generate.py "Script" --avatar studio --voice energetic

# Lower resolution (faster, smaller file)
python3 ~/.claude/skills/heygen-avatar/references/generate.py "Script" --resolution 720

# Custom background
python3 ~/.claude/skills/heygen-avatar/references/generate.py "Script" --background /path/to/image.png
python3 ~/.claude/skills/heygen-avatar/references/generate.py "Script" --background-color '#1a1a2e'

# Submit without waiting (check status later)
python3 ~/.claude/skills/heygen-avatar/references/generate.py "Script" --submit-only

# Check video status
python3 ~/.claude/skills/heygen-avatar/references/generate.py --status VIDEO_ID

# List configured avatars and voices
python3 ~/.claude/skills/heygen-avatar/references/generate.py --list-avatars
python3 ~/.claude/skills/heygen-avatar/references/generate.py --list-voices

# Check remaining credits
python3 ~/.claude/skills/heygen-avatar/references/generate.py --credits
```

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| "ERROR: You haven't configured your HeyGen API key" | Edit `~/.claude/skills/heygen-avatar/references/config.json` and add your key |
| 403 error on generation | API key expired or HeyGen plan issue -- check your HeyGen dashboard |
| RESOLUTION_NOT_ALLOWED | Your HeyGen plan doesn't support 1080p -- use `--resolution 720` |
| Video stuck in processing | HeyGen is backed up -- wait or check heygen.com for status |
| Voice sounds wrong | Try a different voice clone, or re-clone your voice with a cleaner audio sample |
| "python3: command not found" | Install Python 3: visit python.org/downloads |
| Claude doesn't recognize the skill | Restart Claude Code after installing |

---

## File Locations After Install

| What | Where |
|------|-------|
| heygen-avatar skill | `~/.claude/skills/heygen-avatar/` |
| ai-talking-head skill | `~/.claude/skills/ai-talking-head/` |
| Your config (API key, avatars) | `~/.claude/skills/heygen-avatar/references/config.json` |
| Generated videos | `~/Documents/heygen-avatar-output/` |
