#!/bin/bash
# HeyGen Video Toolkit Installer (Mac/Linux)
# Installs: heygen-avatar + ai-talking-head skills

set -e

SKILLS_DIR="$HOME/.claude/skills"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "============================================"
echo "  HeyGen Video Toolkit Installer"
echo "============================================"
echo ""
echo "This installs two skills:"
echo "  1. heygen-avatar    - Generate videos with YOUR HeyGen avatar"
echo "  2. ai-talking-head  - General talking head video workflow"
echo ""

# Create skills directory if needed
mkdir -p "$SKILLS_DIR"

# ─── Install heygen-avatar ───────────────────────────────────────────

echo "Installing heygen-avatar skill..."

if [ -d "$SKILLS_DIR/heygen-avatar" ]; then
    echo "  WARNING: heygen-avatar already exists. Backing up..."
    mv "$SKILLS_DIR/heygen-avatar" "$SKILLS_DIR/heygen-avatar.backup.$(date +%Y%m%d%H%M%S)"
fi

cp -R "$SCRIPT_DIR/heygen-avatar" "$SKILLS_DIR/heygen-avatar"
echo "  Installed to $SKILLS_DIR/heygen-avatar"

# ─── Install ai-talking-head ─────────────────────────────────────────

echo "Installing ai-talking-head skill..."

if [ -d "$SKILLS_DIR/ai-talking-head" ]; then
    echo "  WARNING: ai-talking-head already exists. Backing up..."
    mv "$SKILLS_DIR/ai-talking-head" "$SKILLS_DIR/ai-talking-head.backup.$(date +%Y%m%d%H%M%S)"
fi

cp -R "$SCRIPT_DIR/ai-talking-head" "$SKILLS_DIR/ai-talking-head"
echo "  Installed to $SKILLS_DIR/ai-talking-head"

# ─── Create output directory ─────────────────────────────────────────

OUTPUT_DIR="$HOME/Documents/heygen-avatar-output"
mkdir -p "$OUTPUT_DIR"
echo "  Created output directory: $OUTPUT_DIR"

# ─── Configuration ───────────────────────────────────────────────────

echo ""
echo "============================================"
echo "  Configuration"
echo "============================================"
echo ""

CONFIG="$SKILLS_DIR/heygen-avatar/references/config.json"

echo "You need your HeyGen API key, avatar ID, and voice ID."
echo ""
echo "  API Key:   HeyGen Dashboard > Settings > API"
echo "  Avatar ID: HeyGen Dashboard > Avatars > click your avatar > copy ID"
echo "  Voice ID:  HeyGen Dashboard > Voices > click your voice > copy ID"
echo ""

read -p "Enter your HeyGen API key (or press Enter to configure later): " API_KEY

if [ -n "$API_KEY" ]; then
    # Use Python with sys.argv to safely inject values (avoids shell quoting issues)
    python3 - "$CONFIG" "$API_KEY" <<'PYEOF'
import json, sys
config_path, api_key = sys.argv[1], sys.argv[2]
with open(config_path) as f:
    config = json.load(f)
config['heygen']['api_key'] = api_key
with open(config_path, 'w') as f:
    json.dump(config, f, indent=2)
print('  API key saved.')
PYEOF

    read -p "Enter your default avatar ID (or press Enter to skip): " AVATAR_ID
    if [ -n "$AVATAR_ID" ]; then
        python3 - "$CONFIG" "$AVATAR_ID" <<'PYEOF'
import json, sys
config_path, avatar_id = sys.argv[1], sys.argv[2]
with open(config_path) as f:
    config = json.load(f)
config['defaults']['avatar_id'] = avatar_id
config['avatars']['my_avatar']['id'] = avatar_id
with open(config_path, 'w') as f:
    json.dump(config, f, indent=2)
print('  Avatar ID saved.')
PYEOF
    fi

    read -p "Enter your default voice ID (or press Enter to skip): " VOICE_ID
    if [ -n "$VOICE_ID" ]; then
        python3 - "$CONFIG" "$VOICE_ID" <<'PYEOF'
import json, sys
config_path, voice_id = sys.argv[1], sys.argv[2]
with open(config_path) as f:
    config = json.load(f)
config['defaults']['voice_id'] = voice_id
config['voices']['my_voice']['id'] = voice_id
with open(config_path, 'w') as f:
    json.dump(config, f, indent=2)
print('  Voice ID saved.')
PYEOF
    fi
else
    echo ""
    echo "  No problem. Configure later by editing:"
    echo "  $CONFIG"
fi

# ─── Optional: fal.ai key for ai-talking-head ────────────────────────

echo ""
echo "The ai-talking-head skill can also use fal.ai for Sora 2, Veo 3.1,"
echo "and Kling models. This is OPTIONAL -- the skill works without it."
echo ""

read -p "Enter your fal.ai API key (or press Enter to skip): " FAL_KEY

if [ -n "$FAL_KEY" ]; then
    FAL_CONFIG="$SKILLS_DIR/ai-talking-head/references/config.json"
    python3 - "$FAL_CONFIG" "$FAL_KEY" <<'PYEOF'
import json, sys
config_path, fal_key = sys.argv[1], sys.argv[2]
with open(config_path) as f:
    config = json.load(f)
config['fal']['api_key'] = fal_key
with open(config_path, 'w') as f:
    json.dump(config, f, indent=2)
print('  fal.ai key saved.')
PYEOF
fi

# ─── Done ────────────────────────────────────────────────────────────

echo ""
echo "============================================"
echo "  Installation Complete"
echo "============================================"
echo ""
echo "Skills installed:"
echo "  $SKILLS_DIR/heygen-avatar/"
echo "  $SKILLS_DIR/ai-talking-head/"
echo ""
echo "Output directory:"
echo "  $OUTPUT_DIR"
echo ""
echo "Quick test (after configuring API key):"
echo '  python3 ~/.claude/skills/heygen-avatar/references/generate.py --credits'
echo ""
echo "Generate a video:"
echo '  python3 ~/.claude/skills/heygen-avatar/references/generate.py "Hello world, this is a test"'
echo ""
echo "Or in Claude Code, just say:"
echo '  "Generate an avatar video saying: Hello world"'
echo ""

if [ "$API_KEY" = "" ]; then
    echo "REMINDER: You still need to configure your API key."
    echo "Edit: $CONFIG"
    echo ""
fi
