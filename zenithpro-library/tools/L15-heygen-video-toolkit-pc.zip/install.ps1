# HeyGen Video Toolkit Installer (Windows PowerShell)
# Installs: heygen-avatar + ai-talking-head skills

$ErrorActionPreference = "Stop"

$SKILLS_DIR = "$env:USERPROFILE\.claude\skills"
$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  HeyGen Video Toolkit Installer" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This installs two skills:"
Write-Host "  1. heygen-avatar    - Generate videos with YOUR HeyGen avatar"
Write-Host "  2. ai-talking-head  - General talking head video workflow"
Write-Host ""

# Create skills directory if needed
if (-not (Test-Path $SKILLS_DIR)) {
    New-Item -ItemType Directory -Path $SKILLS_DIR -Force | Out-Null
}

# --- Install heygen-avatar ---

Write-Host "Installing heygen-avatar skill..."

$avatarDest = "$SKILLS_DIR\heygen-avatar"
if (Test-Path $avatarDest) {
    $backup = "$avatarDest.backup.$(Get-Date -Format 'yyyyMMddHHmmss')"
    Write-Host "  WARNING: heygen-avatar already exists. Backing up to $backup"
    Move-Item $avatarDest $backup
}

Copy-Item -Recurse "$SCRIPT_DIR\heygen-avatar" $avatarDest
Write-Host "  Installed to $avatarDest"

# --- Install ai-talking-head ---

Write-Host "Installing ai-talking-head skill..."

$talkingDest = "$SKILLS_DIR\ai-talking-head"
if (Test-Path $talkingDest) {
    $backup = "$talkingDest.backup.$(Get-Date -Format 'yyyyMMddHHmmss')"
    Write-Host "  WARNING: ai-talking-head already exists. Backing up to $backup"
    Move-Item $talkingDest $backup
}

Copy-Item -Recurse "$SCRIPT_DIR\ai-talking-head" $talkingDest
Write-Host "  Installed to $talkingDest"

# --- Create output directory ---

$OUTPUT_DIR = "$env:USERPROFILE\Documents\heygen-avatar-output"
if (-not (Test-Path $OUTPUT_DIR)) {
    New-Item -ItemType Directory -Path $OUTPUT_DIR -Force | Out-Null
}
Write-Host "  Created output directory: $OUTPUT_DIR"

# --- Configuration ---

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Configuration" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

$CONFIG = "$SKILLS_DIR\heygen-avatar\references\config.json"

Write-Host "You need your HeyGen API key, avatar ID, and voice ID."
Write-Host ""
Write-Host "  API Key:   HeyGen Dashboard > Settings > API"
Write-Host "  Avatar ID: HeyGen Dashboard > Avatars > click your avatar > copy ID"
Write-Host "  Voice ID:  HeyGen Dashboard > Voices > click your voice > copy ID"
Write-Host ""

$API_KEY = Read-Host "Enter your HeyGen API key (or press Enter to configure later)"

if ($API_KEY) {
    $config = Get-Content $CONFIG | ConvertFrom-Json
    $config.heygen.api_key = $API_KEY
    $config | ConvertTo-Json -Depth 10 | Set-Content $CONFIG
    Write-Host "  API key saved."

    $AVATAR_ID = Read-Host "Enter your default avatar ID (or press Enter to skip)"
    if ($AVATAR_ID) {
        $config = Get-Content $CONFIG | ConvertFrom-Json
        $config.defaults.avatar_id = $AVATAR_ID
        $config.avatars.my_avatar.id = $AVATAR_ID
        $config | ConvertTo-Json -Depth 10 | Set-Content $CONFIG
        Write-Host "  Avatar ID saved."
    }

    $VOICE_ID = Read-Host "Enter your default voice ID (or press Enter to skip)"
    if ($VOICE_ID) {
        $config = Get-Content $CONFIG | ConvertFrom-Json
        $config.defaults.voice_id = $VOICE_ID
        $config.voices.my_voice.id = $VOICE_ID
        $config | ConvertTo-Json -Depth 10 | Set-Content $CONFIG
        Write-Host "  Voice ID saved."
    }
} else {
    Write-Host ""
    Write-Host "  No problem. Configure later by editing:"
    Write-Host "  $CONFIG"
}

# --- Optional: fal.ai key ---

Write-Host ""
Write-Host "The ai-talking-head skill can also use fal.ai for Sora 2, Veo 3.1,"
Write-Host "and Kling models. This is OPTIONAL -- the skill works without it."
Write-Host ""

$FAL_KEY = Read-Host "Enter your fal.ai API key (or press Enter to skip)"

if ($FAL_KEY) {
    $FAL_CONFIG = "$SKILLS_DIR\ai-talking-head\references\config.json"
    $falConfig = Get-Content $FAL_CONFIG | ConvertFrom-Json
    $falConfig.fal.api_key = $FAL_KEY
    $falConfig | ConvertTo-Json -Depth 10 | Set-Content $FAL_CONFIG
    Write-Host "  fal.ai key saved."
}

# --- Done ---

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  Installation Complete" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "Skills installed:"
Write-Host "  $SKILLS_DIR\heygen-avatar\"
Write-Host "  $SKILLS_DIR\ai-talking-head\"
Write-Host ""
Write-Host "Output directory:"
Write-Host "  $OUTPUT_DIR"
Write-Host ""
Write-Host "Quick test (after configuring API key):"
Write-Host '  python3 ~/.claude/skills/heygen-avatar/references/generate.py --credits'
Write-Host ""
Write-Host "Generate a video:"
Write-Host '  python3 ~/.claude/skills/heygen-avatar/references/generate.py "Hello world, this is a test"'
Write-Host ""
Write-Host "Or in Claude Code, just say:"
Write-Host '  "Generate an avatar video saying: Hello world"'
Write-Host ""

if (-not $API_KEY) {
    Write-Host "REMINDER: You still need to configure your API key." -ForegroundColor Yellow
    Write-Host "Edit: $CONFIG"
    Write-Host ""
}
