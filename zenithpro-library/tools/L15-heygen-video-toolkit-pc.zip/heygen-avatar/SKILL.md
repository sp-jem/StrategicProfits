---
name: heygen-avatar
description: "Generate talking-head videos using your HeyGen avatar and voice clone. Script in, video out. Triggers on: avatar video, heygen video, generate video, make avatar say, talking head. Use when you need a video of yourself saying something without being on camera."
---

# HeyGen Avatar Video Generator

Generate videos of YOUR avatar delivering any script via HeyGen.

**Use this skill when:** You need a video of yourself without filming. Social clips, course content, marketing videos, responses -- anything where "you on camera" is needed but you're not available.

---

## Prerequisites

You need a HeyGen account with:
1. **An API key** (Settings > API in your HeyGen dashboard)
2. **At least one trained avatar** (upload video of yourself in HeyGen)
3. **At least one voice clone** (clone your voice in HeyGen)

The installer will walk you through configuring these.

---

## How It Works

1. You write (or provide) a script
2. Skill submits to HeyGen API with your trained avatar + voice clone
3. Polls until video is ready (~5-8 minutes)
4. Downloads to output folder
5. Returns file path

---

## Quick Usage

### Generate a video (simplest)

```python
# Use the generate.py script
import subprocess, sys
from pathlib import Path
script = "Your script text here"
result = subprocess.run([
    sys.executable,
    str(Path("~/.claude/skills/heygen-avatar/references/generate.py").expanduser()),
    script
], capture_output=True, text=True)
print(result.stdout)
```

### Or call the functions directly

```python
import sys
from pathlib import Path
sys.path.insert(0, str(Path("~/.claude/skills/heygen-avatar/references").expanduser()))
from generate import generate_and_wait, submit_video, check_status, check_credits

# Full pipeline - submit, poll, download
output_path = generate_and_wait("Hey everyone, here's a quick update...")

# Submit only (when you'll poll separately)
video_id = submit_video("Script text here")

# Check status of a pending video
status = check_status(video_id)

# Check remaining credits
credits = check_credits()
```

---

## Parameters

### Avatar Selection

Your avatars are configured in `references/config.json`. The installer sets up your default avatar.

To add more avatars later:
1. Train a new avatar in HeyGen dashboard
2. Copy the avatar ID from HeyGen
3. Add to `config.json` under `avatars`

### Voice Selection

Your voice clones are configured in `references/config.json`. The installer sets up your default voice.

To add more voices:
1. Clone a new voice in HeyGen dashboard
2. Copy the voice ID from HeyGen
3. Add to `config.json` under `voices`

### Resolution

- `1080` (default) - 1920x1080, good for most uses
- `720` - 1280x720, faster generation, smaller files

---

## Workflow Integration

### With Copywriting Skills

```
1. Generate script using any copywriting skill
2. Pass script to heygen-avatar
3. Video of you delivering that copy is produced
```

### With Webinar Skills

```
1. Generate webinar script
2. Break into segments (~150 words = ~1 minute each)
3. Generate each segment as separate video
4. Concatenate for full presentation
```

### Social Media Clips

```
1. Write short hook scripts (15-45 words = 5-15 seconds)
2. Generate with heygen-avatar
3. Use for social posts, stories, reels
```

---

## Script Guidelines

| Words | Duration | Use Case |
|-------|----------|----------|
| 15 | ~5 sec | Social hook |
| 45 | ~15 sec | Short clip |
| 75 | ~30 sec | Social post |
| 150 | ~60 sec | Full clip |
| 300 | ~2 min | Course segment |

- Write conversationally -- these are avatar videos, not blog posts
- Use contractions: "you're", "don't", "let's"
- Short sentences work better than long ones
- Pause points: use "..." in script for natural pauses
- Numbers: spell out ("three" not "3") for better TTS

---

## Credit Costs

- Standard avatar: ~2 credits per minute of video
- Avatar IV: ~6 credits per minute
- Check balance: `check_credits()` or `python3 generate.py --credits`

---

## Output Location

Videos save to: `~/Documents/heygen-avatar-output/` (configurable in config.json)

Filename format: `avatar-YYYYMMDD-HHMMSS.mp4`

Override with `--output` flag or `output_path` parameter.

---

## CLI Reference

```bash
# Generate a video
python3 ~/.claude/skills/heygen-avatar/references/generate.py "Your script here"

# Use a specific avatar and voice
python3 generate.py "Script" --avatar my_avatar --voice my_voice

# Change resolution
python3 generate.py "Script" --resolution 720

# Custom background
python3 generate.py "Script" --background /path/to/image.png
python3 generate.py "Script" --background-color '#1a1a2e'

# Submit without waiting (check later)
python3 generate.py "Script" --submit-only

# Check video status
python3 generate.py --status VIDEO_ID

# List your configured avatars
python3 generate.py --list-avatars

# List your configured voices
python3 generate.py --list-voices

# Check credits
python3 generate.py --credits
```

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| 403 on generation | API key expired or plan issue -- check HeyGen dashboard |
| RESOLUTION_NOT_ALLOWED | Plan doesn't support that resolution -- try 720 |
| Video stuck processing | HeyGen queue backlog -- wait or check dashboard |
| Bad voice quality | Try a different voice clone |
| New avatar not appearing | Add it to config.json with its HeyGen ID |

---

## Config Location

`~/.claude/skills/heygen-avatar/references/config.json`

Contains: API key, avatar registry, voice registry, defaults, output path.
