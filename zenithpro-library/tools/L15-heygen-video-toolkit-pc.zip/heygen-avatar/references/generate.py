#!/usr/bin/env python3
"""
HeyGen Avatar Video Generator
Generates talking-head videos using your HeyGen avatar and voice clone.

Usage:
    python3 generate.py "Your script text here"
    python3 generate.py "Script" --avatar my_avatar --voice my_voice
    python3 generate.py "Script" --resolution 720
    python3 generate.py --status VIDEO_ID
    python3 generate.py --list-avatars
    python3 generate.py --list-voices
    python3 generate.py --credits
"""

import urllib.request
import json
import sys
import os
import time
import argparse
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
CONFIG_PATH = SCRIPT_DIR / "config.json"

def load_config():
    with open(CONFIG_PATH) as f:
        config = json.load(f)
    # Validate config
    if config["heygen"]["api_key"] == "YOUR_HEYGEN_API_KEY_HERE":
        print("ERROR: You haven't configured your HeyGen API key yet.")
        print(f"Edit: {CONFIG_PATH}")
        print("Get your API key from: HeyGen Dashboard > Settings > API")
        sys.exit(1)
    return config

def api_request(method, path, data=None, config=None):
    """Make authenticated HeyGen API request."""
    if config is None:
        config = load_config()

    url = f"{config['heygen']['api_base']}{path}"
    headers = {
        "X-Api-Key": config["heygen"]["api_key"],
        "Content-Type": "application/json"
    }

    if data:
        body = json.dumps(data).encode("utf-8")
        req = urllib.request.Request(url, data=body, headers=headers, method=method)
    else:
        req = urllib.request.Request(url, headers=headers, method=method)

    resp = urllib.request.urlopen(req)
    return json.loads(resp.read().decode("utf-8"))

def check_credits(config=None):
    """Check remaining HeyGen credits."""
    result = api_request("GET", "/v2/user/remaining_quota", config=config)
    data = result.get("data", {})
    remaining = data.get("remaining_quota", "unknown")
    details = data.get("details", {})
    return {
        "total": remaining,
        "api": details.get("api", "?"),
        "plan": details.get("plan_credit", "?"),
        "avatar_iv_free": details.get("avatar_iv_free_credit", 0)
    }

def resolve_avatar(name, config):
    """Resolve avatar name to ID."""
    avatars = config.get("avatars", {})
    if name in avatars:
        return avatars[name]["id"]
    for a in avatars.values():
        if a["id"] == name:
            return name
    return name  # Assume it's a raw ID

def resolve_voice(name, config):
    """Resolve voice name to ID."""
    voices = config.get("voices", {})
    if name in voices:
        return voices[name]["id"]
    for v in voices.values():
        if v["id"] == name:
            return name
    return name

def upload_asset(file_path, config=None):
    """Upload an image to HeyGen and return the asset_id."""
    if config is None:
        config = load_config()

    import mimetypes
    mime_type = mimetypes.guess_type(file_path)[0] or "image/png"

    with open(file_path, "rb") as f:
        file_data = f.read()

    url = "https://upload.heygen.com/v1/asset"
    headers = {
        "X-Api-Key": config["heygen"]["api_key"],
        "Content-Type": mime_type
    }

    req = urllib.request.Request(url, data=file_data, headers=headers, method="POST")
    resp = urllib.request.urlopen(req)
    result = json.loads(resp.read().decode("utf-8"))
    return result["data"]["id"]


def submit_video(script, avatar_name=None, voice_name=None, width=1920, height=1080,
                 background_image_path=None, background_asset_id=None, background_color=None,
                 config=None):
    """Submit video generation request. Returns video_id.

    Background options (mutually exclusive, checked in order):
      - background_image_path: local file path, will be uploaded first
      - background_asset_id: HeyGen asset ID from a previous upload
      - background_color: hex color string like '#1a1a2e'
    """
    if config is None:
        config = load_config()

    defaults = config.get("defaults", {})
    avatar_id = resolve_avatar(avatar_name or defaults["avatar_id"], config)
    voice_id = resolve_voice(voice_name or defaults["voice_id"], config)

    # Build background config
    background = None
    if background_image_path:
        print(f"  Uploading background image: {os.path.basename(background_image_path)}")
        asset_id = upload_asset(background_image_path, config)
        print(f"  Asset ID: {asset_id}")
        background = {"type": "image", "image_asset_id": asset_id}
    elif background_asset_id:
        background = {"type": "image", "image_asset_id": background_asset_id}
    elif background_color:
        background = {"type": "color", "value": background_color}

    video_input = {
        "character": {
            "type": "avatar",
            "avatar_id": avatar_id,
            "avatar_style": "normal"
        },
        "voice": {
            "type": "text",
            "input_text": script,
            "voice_id": voice_id
        }
    }
    if background:
        video_input["background"] = background

    payload = {
        "video_inputs": [video_input],
        "dimension": {"width": width, "height": height}
    }

    result = api_request("POST", "/v2/video/generate", payload, config)
    video_id = result["data"]["video_id"]
    return video_id

def check_status(video_id, config=None):
    """Check video generation status. Returns dict with status, video_url, duration."""
    result = api_request("GET", f"/v1/video_status.get?video_id={video_id}", config=config)
    data = result.get("data", {})
    return {
        "status": data.get("status"),
        "video_url": data.get("video_url"),
        "duration": data.get("duration"),
        "error": data.get("error"),
        "thumbnail_url": data.get("thumbnail_url")
    }

def download_video(video_url, output_path):
    """Download video from URL to local path."""
    req = urllib.request.Request(video_url)
    resp = urllib.request.urlopen(req)
    data = resp.read()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "wb") as f:
        f.write(data)
    return len(data)

def generate_and_wait(script, avatar_name=None, voice_name=None, width=1920, height=1080,
                       output_path=None, poll_interval=30, max_wait=600,
                       background_image_path=None, background_asset_id=None, background_color=None,
                       config=None):
    """Full pipeline: submit, poll, download. Returns output path."""
    if config is None:
        config = load_config()

    # Submit
    print(f"Submitting video generation...")
    print(f"  Script: {script[:80]}{'...' if len(script) > 80 else ''}")
    print(f"  Avatar: {avatar_name or 'default'}")
    print(f"  Voice: {voice_name or 'default'}")
    print(f"  Resolution: {width}x{height}")
    if background_image_path:
        print(f"  Background: {os.path.basename(background_image_path)}")

    video_id = submit_video(script, avatar_name, voice_name, width, height,
                            background_image_path, background_asset_id, background_color, config)
    print(f"  Video ID: {video_id}")

    # Poll
    elapsed = 0
    while elapsed < max_wait:
        time.sleep(poll_interval)
        elapsed += poll_interval
        status = check_status(video_id, config)
        print(f"  [{elapsed}s] Status: {status['status']}")

        if status["status"] == "completed":
            # Download
            if output_path is None:
                output_dir = config.get("output_dir", ".")
                output_dir = os.path.expanduser(output_dir)
                timestamp = time.strftime("%Y%m%d-%H%M%S")
                output_path = os.path.join(output_dir, f"avatar-{timestamp}.mp4")

            print(f"  Downloading to: {output_path}")
            size = download_video(status["video_url"], output_path)
            print(f"  Done! {size / 1024 / 1024:.1f} MB, {status['duration']:.1f}s duration")
            return output_path

        elif status["status"] == "failed":
            print(f"  FAILED: {status.get('error', 'Unknown error')}")
            return None

    print(f"  Timed out after {max_wait}s. Video ID: {video_id}")
    print(f"  Check manually: python3 {__file__} --status {video_id}")
    return None

def list_avatars(config=None):
    """List available avatars."""
    if config is None:
        config = load_config()
    print("\nAvailable Avatars:")
    print("-" * 60)
    for name, info in config.get("avatars", {}).items():
        desc = info.get("description", "")
        default = " (DEFAULT)" if info["id"] == config["defaults"]["avatar_id"] else ""
        print(f"  {name:25s} {desc}{default}")

def list_voices(config=None):
    """List available voice clones."""
    if config is None:
        config = load_config()
    print("\nAvailable Voice Clones:")
    print("-" * 60)
    for name, info in config.get("voices", {}).items():
        desc = info.get("description", "")
        default = " (DEFAULT)" if info["id"] == config["defaults"]["voice_id"] else ""
        print(f"  {name:25s} {desc}{default}")

def main():
    parser = argparse.ArgumentParser(description="Generate avatar videos via HeyGen")
    parser.add_argument("script", nargs="?", help="Script text for your avatar to say")
    parser.add_argument("--avatar", "-a", help="Avatar name (from config) or ID")
    parser.add_argument("--voice", "-v", help="Voice name (from config) or ID")
    parser.add_argument("--resolution", "-r", type=int, default=1080, choices=[720, 1080],
                       help="Video height (720 or 1080)")
    parser.add_argument("--output", "-o", help="Output file path")
    parser.add_argument("--status", "-s", help="Check status of a video ID")
    parser.add_argument("--list-avatars", action="store_true", help="List available avatars")
    parser.add_argument("--list-voices", action="store_true", help="List available voice clones")
    parser.add_argument("--credits", action="store_true", help="Check remaining credits")
    parser.add_argument("--background", "-b", help="Background image path (local file)")
    parser.add_argument("--background-color", help="Background color hex (e.g. '#1a1a2e')")
    parser.add_argument("--submit-only", action="store_true", help="Submit without waiting")
    parser.add_argument("--poll-interval", type=int, default=30, help="Seconds between polls")
    parser.add_argument("--max-wait", type=int, default=600, help="Max seconds to wait")

    args = parser.parse_args()
    config = load_config()

    if args.list_avatars:
        list_avatars(config)
        return

    if args.list_voices:
        list_voices(config)
        return

    if args.credits:
        credits = check_credits(config)
        print(f"\nHeyGen Credits:")
        print(f"  Total remaining: {credits['total']}")
        print(f"  API credits: {credits['api']}")
        print(f"  Plan credits: {credits['plan']}")
        print(f"  Avatar IV free: {credits['avatar_iv_free']}")
        return

    if args.status:
        status = check_status(args.status, config)
        print(f"\nVideo {args.status}:")
        print(f"  Status: {status['status']}")
        if status['duration']:
            print(f"  Duration: {status['duration']:.1f}s")
        if status['video_url']:
            print(f"  URL: {status['video_url'][:80]}...")
        if status['error']:
            print(f"  Error: {status['error']}")
        return

    if not args.script:
        parser.print_help()
        return

    width = 1920 if args.resolution == 1080 else 1280
    height = args.resolution

    if args.submit_only:
        video_id = submit_video(args.script, args.avatar, args.voice, width, height,
                                background_image_path=args.background,
                                background_color=args.background_color,
                                config=config)
        print(f"Submitted: {video_id}")
        print(f"Check status: python3 {__file__} --status {video_id}")
    else:
        result = generate_and_wait(
            args.script, args.avatar, args.voice, width, height,
            args.output, args.poll_interval, args.max_wait,
            background_image_path=args.background,
            background_color=args.background_color,
            config=config
        )
        if result:
            print(f"\nVideo saved to: {result}")
        else:
            print("\nGeneration failed or timed out.")

if __name__ == "__main__":
    main()
