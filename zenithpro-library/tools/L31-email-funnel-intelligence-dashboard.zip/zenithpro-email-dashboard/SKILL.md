---
name: email-funnel-intelligence
description: >
  TRIGGER when a user wants to turn their own email broadcast data into a
  self-contained Email Funnel Intelligence dashboard — an interactive HTML
  report covering engagement, subject-line patterns, send timing, CTA
  performance, deliverability, buyer segments, and prioritised action
  recommendations. Supports three input sources: a generic CSV export
  (any ESP), an ESP-native export (Mailchimp / Klaviyo / ActiveCampaign /
  ConvertKit), or GoHighLevel (CSV export or live API pull). Revenue, buyer
  buckets, and GA4 cards are gracefully stubbed when those sources are absent
  — the dashboard renders useful analysis from email data alone.
version: 1.0.0
---

# Email Funnel Intelligence

## What It Does

`generate.py` reads your email broadcast data and maps it to a 294-field
intelligence schema (engagement rates, subject-line NLP, CTA and format
breakdowns, send-timing distributions, deliverability flags, and resend lift).
From an email-only export it computes roughly 140 fields live; revenue, RFM
buyer buckets, and GA4 attribution stay PENDING until those sources are
connected. It then injects the computed data object into `templates/TEMPLATE.html`
and writes a finished, self-contained `dashboard.html` you open in any browser.
No server required. No sample or demo data is bundled — the output reflects your
numbers exclusively.

Cards that require data you have not yet connected (Stripe revenue, Mailgun
opens, GA4 attribution) display a PENDING state automatically; they do not
break the page or render placeholder figures.

---

## Quick Start — 60-Second Dry Run

Run this from the skill directory to see a working dashboard immediately:

```bash
cd /path/to/email-funnel-intelligence
python3 generate.py \
  --source csv \
  --input sample-input/sample.csv \
  --output sample-output/dashboard.html
```

(Windows: use `python` and put the command on a single line, e.g.)

```bat
python generate.py --source csv --input sample-input\sample.csv --output sample-output\dashboard.html
```

Open `sample-output/dashboard.html` in your browser. The dashboard will show
the 10-broadcast sample dataset so you can verify the layout before connecting
your own data.

---

## Usage by Source

### 1. Generic CSV Export (any ESP)

Use this path when you have exported a broadcast/campaign list from any
platform as a CSV.

```bash
python3 generate.py \
  --source csv \
  --input /path/to/your/export.csv \
  --output /path/to/dashboard.html
```

**Minimum required columns:** `subject`, `send_time`, `recipients` (`id` optional — auto-generated when absent)

**Recommended additional columns for richer analysis:**
`delivered`, `opens`, `clicks`, `replies`, `unsubscribed`, `email_format`,
`cta_type`, `cta_position`, `body_text` (or `word_count`)

Column names are flexible — the adapter recognises common aliases
(`sent_at`, `unique_opens`, `broadcast_id`, etc.). If your export uses
non-standard names, see `adapters/csv_adapter.py` → `DEFAULT_ALIASES` for the
full alias table, or pass a `column_map` dict if calling the adapter
programmatically.

**Timezone note:** `send_time` values are treated as UTC and displayed as ET (UTC-5,
no DST adjustment). If your export is in local time, expect hour-of-day metrics to
shift accordingly.

See `references/data-contract.md` for the complete field specification
(294 fields, with required / optional flags and UI consumer notes).

---

### 2. ESP-Native Export

Use this when your export comes from a supported platform with its own column
structure. Platform is auto-detected by default.

```bash
python3 generate.py \
  --source esp \
  --input /path/to/platform_export.csv \
  --output /path/to/dashboard.html
```

**Supported platforms:** Mailchimp, Klaviyo, ActiveCampaign, ConvertKit

To force a specific platform instead of auto-detection:

```bash
python3 generate.py \
  --source esp \
  --input /path/to/export.csv \
  --esp-platform klaviyo \
  --output /path/to/dashboard.html
```

Valid values for `--esp-platform`: `mailchimp` | `klaviyo` | `active_campaign`
| `convertkit` | `generic` | `auto` (default)

---

### 3. GoHighLevel (CSV Export)

Export your GHL email broadcasts as a CSV from the GHL dashboard, then run:

```bash
python3 generate.py \
  --source ghl \
  --input /path/to/ghl_export.csv \
  --output /path/to/dashboard.html
```

---

### 4. GoHighLevel (Live API Pull)

Pass `--input api` to pull data directly from your GHL sub-account via GHL's
legacy v1 REST API. If the v1 API is unavailable for your account, use the CSV
export path above — it always works.
Requires the `requests` library and GHL credentials (see Optional Setup below).

```bash
python3 generate.py \
  --source ghl \
  --input api \
  --output /path/to/dashboard.html
```

If credentials are not set as environment variables, the generator will prompt
for them interactively.

---

## Optional: Custom Template Path

By default the generator looks for `templates/TEMPLATE.html` in the same
directory as `generate.py`. Override with:

```bash
python3 generate.py \
  --source csv \
  --input export.csv \
  --output dashboard.html \
  --template /custom/path/TEMPLATE.html
```

---

## Required vs Optional Fields

| Field group | Status | Unlocks |
|---|---|---|
| `id`, `subject`, `send_time`, `recipients` | Required | All structural analysis (timing, subject, format, CTA, deliverability) |
| `delivered` | Recommended | Delivery rate and bounce calculations; defaults to `recipients` if absent |
| `opens`, `clicks` | Optional | Open rate, click rate, CTOR, feature-vs-engagement scoring, timing heatmaps |
| `replies`, `unsubscribed` | Optional | Campaign/workflow split in Engagement card |
| `email_format`, `cta_type`, `cta_position` | Optional | Format & CTA analysis; defaults applied when absent |
| `body_text` or `word_count` | Optional | Word-count distribution in Format card |
| Stripe data | Optional | Revenue card, Buyer Buckets RFM, Funnel client/repeat tiers |
| Mailgun API | Optional | Authoritative unique open/click counts, per-broadcast retention data |
| GA4 API | Optional | GA4 email-attribution card (sessions → conversions → revenue) |

Cards that depend on missing optional sources render a PENDING state; no cards
are hidden entirely on load unless they contain no computable data at all.

For the full field-by-field specification — dot-paths, types, UI consumers,
required/optional flags, raw vs derived flags — see:
`references/data-contract.md`

---

## Optional Setup — Credentials

**Never commit credentials to version control.** Set them as environment
variables in your shell profile or a local `.env` file that is listed in
`.gitignore`.

### GoHighLevel API (live pull only)

```bash
export GHL_API_KEY="your-location-api-key"
export GHL_LOCATION_ID="your-sub-account-location-id"
```

- `GHL_API_KEY` — your Location API key (GHL → Settings → Business Profile → API Key). The live pull targets GHL's legacy v1 REST API — if it errors for your account, use the CSV export path instead (always works).
- `GHL_LOCATION_ID` — Sub-account location ID (visible in GHL URL or API docs)

If either variable is absent when `--input api` is used, the generator prompts
interactively. CSV mode requires no credentials.

### Mailgun (opens/clicks enrichment)

Mailgun enrichment is not invoked by `generate.py` directly — connect it via
the ESP adapter or by pre-joining Mailgun data into your CSV export. If you
want live Mailgun pulls in a future workflow, you will need:

```bash
export MAILGUN_API_KEY="key-xxxxxxxxxxxxxxxxxxxx"
export MAILGUN_DOMAIN="mg.yourdomain.com"
```

### GA4 (attribution card)

The GA4 card requires a service-account JSON key or OAuth token authorised for
the Google Analytics Data API. Export the data and include it in your CSV, or
pass it through the adapter layer. To use the GA4 API directly:

```bash
export GOOGLE_APPLICATION_CREDENTIALS="/path/to/service-account.json"
export GA4_PROPERTY_ID="123456789"
```

---

## Dependencies

**Standard library only for the CSV path** — no `pip install` required.

The `requests` library is needed only for GHL live API mode:

```bash
pip install requests
```

All other analysis (subject NLP, timing, deliverability, format, CTA,
resend detection) runs on Python stdlib.

---

## Output Guarantee

The dashboard ships with **no sample numbers and no demo data**. The
`templates/TEMPLATE.html` contains only the UI skeleton and a single injection
token (`__EFI_DATA_INJECT__`). Every figure rendered in the final
`dashboard.html` is computed from your input file at generation time. If a
field cannot be computed from your data, the corresponding UI element shows a
PENDING state — it does not fall back to any bundled value.

---

## File Structure Reference

```
email-funnel-intelligence/
├── SKILL.md                      ← this file
├── generate.py                   ← CLI entry point
├── adapters/
│   ├── csv_adapter.py            ← generic CSV → EFI dict
│   ├── esp_adapter.py            ← Mailchimp / Klaviyo / ActiveCampaign / ConvertKit
│   └── ghl_adapter.py            ← GoHighLevel CSV + API
├── templates/
│   └── TEMPLATE.html             ← stripped UI skeleton with __EFI_DATA_INJECT__ token
├── references/
│   └── data-contract.md          ← full 294-field specification
└── sample-input/
    └── sample.csv                ← 10-broadcast dry-run dataset
```
