#!/usr/bin/env python3
"""
Email Funnel Intelligence — Dashboard Generator
================================================
Turns raw email metrics into a finished self-contained dashboard.html.

CLI:
    python generate.py --source csv  --input path/to/export.csv  --output dashboard.html
    python generate.py --source esp  --input path/to/esp_export.csv --output dashboard.html
    python generate.py --source ghl  --input path/to/ghl_export.csv --output dashboard.html
    python generate.py --source ghl  --input api --output dashboard.html   # live pull

Options:
    --source    csv | esp | ghl          (required)
    --input     path to CSV, or "api"    (required)
    --output    path for dashboard.html  (required)
    --template  path to TEMPLATE.html    (default: templates/TEMPLATE.html in same dir as script)
    --esp-platform  mailchimp|klaviyo|active_campaign|convertkit|auto  (ESP only, default auto)

Environment variables (optional, for live sources):
    GHL_LOCATION_ID   — GHL sub-account location ID (GHL API mode only)
    GHL_API_KEY       — GHL Location API key, legacy v1 (GHL API mode only)

stdlib-only for the basic CSV path. 'requests' is OPTIONAL (GHL API mode only).
"""

import argparse
import json
import os
import re
import sys
import unicodedata
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean, median

# ── locate project root (same dir as this script) ──────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

# ── imports from adapters ───────────────────────────────────────────────────
from adapters.csv_adapter import load_csv, _detect_subject_features, _length_band, _word_count_band
from adapters.esp_adapter import load_esp
from adapters.ghl_adapter import load_ghl


# ─────────────────────────────────────────────────────────────────────────────
# COMPUTATION HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _safe_div(num, den, default=None):
    if den and den > 0:
        return num / den
    return default


def _weighted_avg(items, value_key, weight_key):
    """Weighted average of value_key, weighted by weight_key."""
    total_w = sum(r.get(weight_key, 0) for r in items)
    if total_w == 0:
        return 0.0
    return sum(r.get(value_key, 0) * r.get(weight_key, 0) for r in items) / total_w


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ─────────────────────────────────────────────────────────────────────────────
# SUBJECT LINE ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

def compute_subject_analysis(broadcasts: list) -> dict:
    subjects = [b["subject"] for b in broadcasts if b.get("subject")]
    if not subjects:
        return {"status": "pending", "corpus": 0}

    lengths = [len(s) for s in subjects]
    length_band_counts = defaultdict(int)
    length_band_sent = defaultdict(int)
    length_band_clicks = defaultdict(list)

    feature_counts = defaultdict(int)
    feature_click_map = defaultdict(lambda: defaultdict(list))

    for b in broadcasts:
        s = b.get("subject", "")
        if not s:
            continue
        band = _length_band(len(s))
        length_band_counts[band] += 1
        length_band_sent[band] += b.get("recipients", 0)
        if b.get("click_rate") is not None:
            length_band_clicks[band].append(b["click_rate"])

        feats = _detect_subject_features(s)
        for feat, present in feats.items():
            if present:
                feature_counts[feat] += 1
            if b.get("click_rate") is not None:
                feature_click_map[feat][present].append(b["click_rate"])

    band_order = ["≤30", "31–50", "51–70", "71–90", "91+"]
    length_buckets = [
        {
            "length_band": band,
            "broadcasts": length_band_counts.get(band, 0),
            "total_sent": length_band_sent.get(band, 0),
            "avg_click_rate": round(mean(length_band_clicks[band]), 4) if length_band_clicks[band] else None,
        }
        for band in band_order if length_band_counts.get(band, 0) > 0
    ]

    # feature_vs_open — only populate if we have click data
    all_click_data = any(b.get("click_rate") is not None for b in broadcasts)
    if all_click_data:
        feature_vs_open = {}
        for feat, by_bool in feature_click_map.items():
            rows = []
            for val in (True, False):
                rates = by_bool.get(val, [])
                if rates:
                    rows.append({
                        "feature_value": val,
                        "broadcasts": len(rates),
                        "total_sent": sum(
                            b.get("recipients", 0) for b in broadcasts
                            if _detect_subject_features(b.get("subject", "")).get(feat) == val
                            and b.get("click_rate") is not None
                        ),
                        "avg_click_rate": round(mean(rates), 4),
                    })
            if rows:
                feature_vs_open[feat] = rows
    else:
        feature_vs_open = "Opens/clicks needed to score feature performance."

    return {
        "status": "complete",
        "corpus": len(subjects),
        "length": {
            "min": min(lengths),
            "avg": round(mean(lengths), 1),
            "median": int(median(lengths)),
            "max": max(lengths),
        },
        "length_buckets": length_buckets,
        "feature_distribution": dict(feature_counts),
        "feature_vs_open": feature_vs_open,
        "note": (
            f"Corpus of {len(subjects)} subject lines analysed. "
            "Feature-vs-click rates shown where Mailgun data present."
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# FORMAT & CTA ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

def compute_format_analysis(broadcasts: list) -> tuple:
    """Returns (format_dict, cta_dict)."""
    format_dist = defaultdict(int)
    cta_type_dist = defaultdict(int)
    cta_pos_dist = defaultdict(int)

    format_click = defaultdict(list)
    cta_type_click = defaultdict(list)
    cta_pos_click = defaultdict(list)
    wc_band_click = defaultdict(list)
    wc_band_count = defaultdict(int)

    for b in broadcasts:
        fmt = b.get("email_format", "plain-text")
        ct = b.get("cta_type", "none")
        cp = b.get("cta_position", "bottom")
        wc_band = _word_count_band(b.get("word_count", 0))

        format_dist[fmt] += 1
        cta_type_dist[ct] += 1
        cta_pos_dist[cp] += 1
        wc_band_count[wc_band] += 1

        cr = b.get("click_rate")
        if cr is not None:
            format_click[fmt].append(cr)
            cta_type_click[ct].append(cr)
            cta_pos_click[cp].append(cr)
            wc_band_click[wc_band].append(cr)

    has_click_data = any(b.get("click_rate") is not None for b in broadcasts)

    format_vs_response = [
        {
            "format": fmt,
            "broadcasts": format_dist[fmt],
            "total_sent": sum(b["recipients"] for b in broadcasts if b.get("email_format") == fmt),
            "avg_click_rate": round(mean(rates), 4) if rates else None,
        }
        for fmt, rates in format_click.items()
    ] if has_click_data else []

    length_vs_response = [
        {
            "length": band,
            "broadcasts": wc_band_count[band],
            "total_sent": sum(b["recipients"] for b in broadcasts if _word_count_band(b.get("word_count", 0)) == band),
            "avg_click_rate": round(mean(rates), 4) if rates else None,
        }
        for band, rates in wc_band_click.items()
    ] if has_click_data else []

    # Word count stats
    wcs = [b.get("word_count", 0) for b in broadcasts if b.get("word_count", 0) > 0]
    wc_stats = {}
    if wcs:
        wc_stats = {
            "min": min(wcs),
            "avg": round(mean(wcs), 1),
            "median": int(median(wcs)),
            "max": max(wcs),
        }

    format_dict = {
        "status": "complete",
        "format_distribution": dict(format_dist),
        "word_count": wc_stats,
        "format_vs_response": format_vs_response,
        "length_vs_response": length_vs_response,
    }

    # CTA
    type_vs_click = [
        {
            "cta_type": ct,
            "broadcasts": cta_type_dist[ct],
            "total_sent": sum(b["recipients"] for b in broadcasts if b.get("cta_type") == ct),
            "avg_click_rate": round(mean(rates), 4) if rates else None,
        }
        for ct, rates in cta_type_click.items()
    ] if has_click_data else (
        "Click data needed to score CTA type performance." if not has_click_data else []
    )

    pos_vs_click = [
        {
            "position": cp,
            "broadcasts": cta_pos_dist[cp],
            "total_sent": sum(b["recipients"] for b in broadcasts if b.get("cta_position") == cp),
            "avg_click_rate": round(mean(rates), 4) if rates else None,
        }
        for cp, rates in cta_pos_click.items()
    ] if has_click_data else (
        "Click data needed to score CTA position performance." if not has_click_data else []
    )

    reply_count = cta_type_dist.get("reply", 0)

    dominant_cta = max(cta_type_dist, key=cta_type_dist.get, default="none")
    dominant_pos = max(cta_pos_dist, key=cta_pos_dist.get, default="bottom")
    observation = (
        f"Dominant CTA type: {dominant_cta} ({cta_type_dist.get(dominant_cta, 0)} of {len(broadcasts)} broadcasts). "
        f"Most common position: {dominant_pos}."
    )

    cta_dict = {
        "status": "complete",
        "cta_type_distribution": dict(cta_type_dist),
        "cta_position_distribution": dict(cta_pos_dist),
        "reply_cta_count": reply_count,
        "position_vs_click": pos_vs_click,
        "type_vs_click": type_vs_click,
        "observation": observation,
    }

    return format_dict, cta_dict


# ─────────────────────────────────────────────────────────────────────────────
# SEND TIMING ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

def compute_timing_analysis(broadcasts: list) -> dict:
    day_order = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    day_count = defaultdict(int)
    day_sent = defaultdict(int)
    day_clicks = defaultdict(list)
    day_opens = defaultdict(list)

    hour_count = defaultdict(int)
    hour_sent = defaultdict(int)

    for b in broadcasts:
        dow = b.get("send_dow_et", "")
        hr = b.get("send_hour_et", -1)
        recipients = b.get("recipients", 0)
        cr = b.get("click_rate")
        or_ = b.get("open_rate")

        if dow:
            day_count[dow] += 1
            day_sent[dow] += recipients
            if cr is not None:
                day_clicks[dow].append(cr)
            if or_ is not None:
                day_opens[dow].append(or_)

        if hr >= 0:
            hour_count[hr] += 1
            hour_sent[hr] += recipients

    send_distribution_by_day = [
        {
            "day": d,
            "broadcasts": day_count.get(d, 0),
            "total_sent": day_sent.get(d, 0),
            "avg_click_rate": round(mean(day_clicks[d]), 4) if day_clicks[d] else None,
        }
        for d in day_order if day_count.get(d, 0) > 0
    ]

    send_distribution_by_hour = [
        {
            "hour": hr,
            "broadcasts": hour_count[hr],
            "total_sent": hour_sent[hr],
            "avg_click_rate": None,
        }
        for hr in sorted(hour_count.keys())
    ]

    # Open rate by day — only if open_rate data present
    open_rate_by_day = []
    best_day = None
    if any(day_opens.values()):
        for d in day_order:
            rates = day_opens.get(d, [])
            opens_count = sum(
                b.get("opens", 0) or 0 for b in broadcasts if b.get("send_dow_et") == d and b.get("opens") is not None
            )
            delivered_count = sum(
                b.get("delivered", 0) for b in broadcasts if b.get("send_dow_et") == d
            )
            avg_or = mean(rates) if rates else None
            if avg_or is not None:
                open_rate_by_day.append({
                    "day": d,
                    "delivered": delivered_count,
                    "open_rate": round(avg_or, 4),
                    "click_rate": round(mean(day_clicks[d]), 4) if day_clicks[d] else None,
                })
        if open_rate_by_day:
            best = max(open_rate_by_day, key=lambda x: x["open_rate"])
            best_day = {"day": best["day"], "open_rate": best["open_rate"]}

    actionable = ""
    caveat = ""
    if best_day:
        actionable = (
            f"Best open day in this dataset: {best_day['day']} "
            f"({best_day['open_rate']*100:.1f}% avg open rate). "
            "Consider concentrating high-value sends on this day."
        )
        caveat = (
            "Day-of-week open rates are computed from available per-broadcast data. "
            "Sample sizes per day may be small — treat as directional, not definitive."
        )

    # Best hour (narrative only)
    best_hour_str = ""
    if hour_count:
        bh = max(hour_count, key=hour_count.get)
        best_hour_str = f"{bh:02d}:00 ET ({hour_count[bh]} sends)"

    return {
        "status": "complete",
        "send_distribution_by_day": send_distribution_by_day,
        "send_distribution_by_hour": send_distribution_by_hour,
        "open_rate_by_day": open_rate_by_day,
        "best_day_for_opens": best_day,
        "best_hour_for_opens": best_hour_str,
        "caveat": caveat,
        "actionable": actionable,
        "note": f"Send timing based on {len(broadcasts)} broadcasts.",
    }


# ─────────────────────────────────────────────────────────────────────────────
# RESEND ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

def compute_resend_analysis(broadcasts: list) -> dict:
    import re as _re
    resend_pattern = _re.compile(r'\[RESEND\]', _re.IGNORECASE)

    resend_ids = {b["id"] for b in broadcasts if resend_pattern.search(b.get("subject", ""))}
    bracket_resends = len(resend_ids)
    total = len(broadcasts)

    # Check for workflow resend-to-unopened (heuristic: workflow type + timing)
    workflow_sends = [b for b in broadcasts if b.get("_email_type", "campaign") == "workflow"]
    resend_to_unopened_enabled = len(workflow_sends)

    # Resend lift — if click data available
    orig_rates = [b["click_rate"] for b in broadcasts
                  if b.get("click_rate") is not None and b["id"] not in resend_ids]
    resend_rates = [b["click_rate"] for b in broadcasts
                    if b.get("click_rate") is not None and b["id"] in resend_ids]

    if orig_rates and resend_rates:
        resend_lift = [
            {
                "kind": "original",
                "broadcasts": len(orig_rates),
                "total_sent": sum(b["recipients"] for b in broadcasts if b["id"] not in resend_ids),
                "avg_click_rate": round(sum(orig_rates) / len(orig_rates), 4),
            },
            {
                "kind": "resend",
                "broadcasts": len(resend_rates),
                "total_sent": sum(b["recipients"] for b in broadcasts if b["id"] in resend_ids),
                "avg_click_rate": round(sum(resend_rates) / len(resend_rates), 4),
            },
        ]
    else:
        resend_lift = "Click data needed to quantify resend lift vs. original sends."

    return {
        "status": "complete",
        "resend_broadcasts": bracket_resends,
        "resend_to_unopened_enabled": resend_to_unopened_enabled,
        "bracket_resends": bracket_resends,
        "resend_lift": resend_lift,
    }


# ─────────────────────────────────────────────────────────────────────────────
# DELIVERABILITY ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

def compute_deliverability_analysis(broadcasts: list) -> dict:
    if not broadcasts:
        return {"status": "pending", "avg_delivered_rate": 0, "avg_bounce_rate": 0, "worst_bounce": []}

    avg_delivered = _weighted_avg(broadcasts, "delivered_rate", "recipients")
    avg_bounce = _weighted_avg(broadcasts, "bounce_rate", "recipients")

    sorted_by_bounce = sorted(broadcasts, key=lambda b: b.get("bounce_rate", 0), reverse=True)
    worst_bounce = [
        {
            "subject": b.get("subject", "")[:40],
            "sent": b.get("recipients", 0),
            "bounce_rate": b.get("bounce_rate", 0),
            "date": b.get("send_date_et", ""),
        }
        for b in sorted_by_bounce[:10]
        if b.get("bounce_rate", 0) > 0
    ]

    return {
        "status": "complete",
        "avg_delivered_rate": round(avg_delivered, 4),
        "avg_bounce_rate": round(avg_bounce, 4),
        "worst_bounce": worst_bounce,
        "note": f"Deliverability computed from {len(broadcasts)} broadcasts.",
    }


# ─────────────────────────────────────────────────────────────────────────────
# EMAIL ENGAGEMENT ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

def compute_engagement_analysis(broadcasts: list, source_label: str = "CSV") -> dict:
    with_opens = [b for b in broadcasts if b.get("open_rate") is not None]
    with_clicks = [b for b in broadcasts if b.get("click_rate") is not None]

    if not with_opens and not with_clicks:
        return {"status": "pending"}

    # Aggregate across all broadcasts
    total_delivered = sum(b.get("delivered", 0) for b in broadcasts)
    total_opens = sum((b.get("opens") or 0) for b in broadcasts if b.get("opens") is not None)
    total_clicks = sum((b.get("clicks") or 0) for b in broadcasts if b.get("clicks") is not None)

    overall_open_rate = _safe_div(total_opens, total_delivered, 0.0)
    overall_click_rate = _safe_div(total_clicks, total_delivered, 0.0)
    ctor = _safe_div(total_clicks, total_opens)

    # Campaign vs Workflow split
    camp = [b for b in broadcasts if b.get("_email_type", "campaign") != "workflow"]
    work = [b for b in broadcasts if b.get("_email_type", "campaign") == "workflow"]

    def _agg(rows):
        if not rows:
            return None
        d = sum(b.get("delivered", 0) for b in rows)
        op = sum((b.get("opens") or 0) for b in rows)
        cl = sum((b.get("clicks") or 0) for b in rows)
        re_ = sum(b.get("_replies", 0) for b in rows)
        us = sum(b.get("_unsubscribed", 0) for b in rows)
        return {
            "delivered": d,
            "opened": op,
            "clicked": cl,
            "replied": re_,
            "unsubscribed": us,
            "open_rate": round(_safe_div(op, d, 0.0), 4),
            "click_rate": round(_safe_div(cl, d, 0.0), 4),
        }

    camp_agg = _agg(camp)
    work_agg = _agg(work)

    total_agg = {
        "delivered": total_delivered,
        "opened": total_opens,
        "clicked": total_clicks,
        "replied": sum(b.get("_replies", 0) for b in broadcasts),
        "unsubscribed": sum(b.get("_unsubscribed", 0) for b in broadcasts),
        "open_rate": round(overall_open_rate, 4),
        "click_rate": round(overall_click_rate, 4),
    }

    mailgun_block = {
        "delivered": total_delivered,
        "opened_unique": total_opens,
        "clicked_unique": total_clicks,
        "open_rate": round(overall_open_rate, 4),
        "click_rate": round(overall_click_rate, 4),
        "ctor": round(ctor, 4) if ctor is not None else None,
        "click_to_open_rate": round(ctor, 4) if ctor is not None else None,
    }

    return {
        "status": "complete",
        "overall_open_rate": round(overall_open_rate, 4),
        "overall_click_rate": round(overall_click_rate, 4),
        "source": source_label,
        "mailgun": mailgun_block,
        "campaign": camp_agg or {
            "delivered": 0, "opened": 0, "clicked": 0, "replied": 0,
            "open_rate": None, "click_rate": None,
        },
        "workflow": work_agg or {
            "delivered": 0, "opened": 0, "clicked": 0, "replied": 0,
            "open_rate": None, "click_rate": None,
        },
        "total": total_agg,
        "note": (
            f"Engagement computed from opens/clicks across {len(broadcasts)} broadcasts. "
            "Account-level figures (Mailgun block) reflect available per-broadcast data."
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# REVENUE STUBS (Stripe not present — graceful degradation)
# ─────────────────────────────────────────────────────────────────────────────

def _stub_revenue() -> dict:
    return {
        "status": "pending",
        "net_revenue_window": None,
        "by_product": {},
        "by_month": {},
        "unique_customers": None,
        "repeat_buyers": None,
        "repeat_rate": None,
        "total_emails_sent": None,
        "revenue_per_email_sent": None,
        "money_per_opener_blended": None,
        "money_per_clicker_blended": None,
        "ghl_attributed_email_revenue": None,
        "ghl_conversion_rate": None,
        "openers": None,
        "clickers": None,
        "note": "Connect a Stripe CSV or API to populate revenue analysis.",
        "ga4_attributed": "pending",
    }


def _stub_buyer_buckets() -> dict:
    return {
        "status": "pending",
        "buckets": [],
        "whale_threshold_$": None,
        "recommended_actions": {},
        "note": "Buyer bucket RFM analysis requires Stripe revenue data.",
    }


def _stub_funnel(recipients_total: int) -> dict:
    return {
        "status": "pending",
        "stages": [
            {"stage": "Suspect",  "size": None,             "source": "GA4 / ad data needed",        "confidence": "pending"},
            {"stage": "Prospect", "size": recipients_total, "source": "GHL total recipients",         "confidence": "medium"},
            {"stage": "Client",   "size": None,             "source": "Stripe unique customers needed","confidence": "pending"},
            {"stage": "Repeat",   "size": None,             "source": "Stripe repeat buyers needed",  "confidence": "pending"},
        ],
        "repeat_rate": None,
        "note": "Funnel fully populates once Stripe and GA4 sources are connected.",
    }


def _stub_buyer_intent() -> dict:
    return {
        "status": "pending",
        "top_signals": [
            {
                "rank": 1,
                "signal": "Multi-product purchaser recency",
                "available_now": False,
                "why": "Contacts who purchased twice in the last 60 days are 3–4× more likely to buy again.",
                "use": "Connect Stripe to identify and tag this segment for a priority nurture sequence.",
            },
            {
                "rank": 2,
                "signal": "Click-without-purchase sequence",
                "available_now": False,
                "why": "Contacts who clicked email CTAs but never converted are warm intent signals.",
                "use": "Connect Mailgun click data + Stripe to identify and retarget this cohort.",
            },
        ],
        "note": "Buyer intent signals activate with Stripe + Mailgun click data.",
    }


def _stub_ga4() -> dict:
    return {"status": "pending"}


def _stub_strategy() -> dict:
    return {
        "panels": [],
        "synthesis": {
            "master_priority": [],
            "quick_wins": [],
            "big_bets": [],
            "sequencing_note": (
                "Strategy panel populates after the 9-agent scoring workflow runs. "
                "Provide revenue + open/click data to unlock full recommendations."
            ),
        },
    }


def _build_top_level_revenue(broadcasts: list) -> dict:
    return {
        "generated_at": _now_iso(),
        "window_start": min(
            (b["send_date_et"] for b in broadcasts if b.get("send_date_et")),
            default=""
        ),
        "summary": {
            "charges": 0,
            "gross_revenue": 0.0,
            "refunds": 0.0,
            "net_revenue": 0.0,
            "unique_customers": 0,
            "repeat_buyers": 0,
            "repeat_rate": 0.0,
        },
        "by_month": {},
        "by_product": {},
        "by_customer": {},
    }


# ─────────────────────────────────────────────────────────────────────────────
# TOP-LEVEL KPI ASSEMBLY
# ─────────────────────────────────────────────────────────────────────────────

def compute_kpis(broadcasts: list, engagement: dict, revenue_net: float = None,
                 customers: int = None, repeat_buyers: int = None) -> dict:
    sorted_dates = sorted(
        b["send_date_et"] for b in broadcasts if b.get("send_date_et")
    )
    date_range = [sorted_dates[0], sorted_dates[-1]] if len(sorted_dates) >= 2 else (
        [sorted_dates[0], sorted_dates[0]] if sorted_dates else ["", ""]
    )

    total_recipients = sum(b.get("recipients", 0) for b in broadcasts)
    total_delivered = sum(b.get("delivered", 0) for b in broadcasts)
    avg_bounce = _weighted_avg(broadcasts, "bounce_rate", "recipients")

    # Open/click from engagement block
    mg = engagement.get("mailgun", {})
    open_rate = mg.get("open_rate")
    click_rate = mg.get("click_rate")
    opened_unique = mg.get("opened_unique")

    # Revenue-dependent KPIs
    rev_per_email = _safe_div(revenue_net, total_recipients) if revenue_net is not None else None
    per_opener = _safe_div(revenue_net, opened_unique) if (revenue_net is not None and opened_unique) else None
    repeat_rate = _safe_div(repeat_buyers, customers) if (repeat_buyers is not None and customers) else None

    return {
        "broadcasts": len(broadcasts),
        "recipients": total_recipients,
        "avg_delivered": round(_safe_div(total_delivered, total_recipients, 0.0), 4),
        "avg_bounce": round(avg_bounce, 4),
        "date_range": date_range,
        "net_revenue": revenue_net,
        "customers": customers,
        "repeat_rate": round(repeat_rate, 4) if repeat_rate is not None else None,
        "rev_per_email": round(rev_per_email, 4) if rev_per_email is not None else None,
        "open_rate": round(open_rate, 4) if open_rate is not None else None,
        "click_rate": round(click_rate, 4) if click_rate is not None else None,
        "per_opener": round(per_opener, 2) if per_opener is not None else None,
    }


# ─────────────────────────────────────────────────────────────────────────────
# DATA STATE FLAGS
# ─────────────────────────────────────────────────────────────────────────────

def compute_data_state(adapter_result: dict) -> dict:
    return {
        "emails": bool(adapter_result.get("broadcasts")),
        "revenue": adapter_result.get("_csv_has_revenue", False),
        "opens_clicks": adapter_result.get("_csv_has_opens", False) or adapter_result.get("_csv_has_clicks", False),
        "mailgun": adapter_result.get("_csv_has_opens", False),
        "ga4": adapter_result.get("_csv_has_ga4", False),
    }


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ASSEMBLY
# ─────────────────────────────────────────────────────────────────────────────

def assemble_efi_data(adapter_result: dict, source_label: str = "CSV") -> dict:
    broadcasts = adapter_result.get("broadcasts", [])
    data_state = compute_data_state(adapter_result)

    engagement = compute_engagement_analysis(broadcasts, source_label)
    subject = compute_subject_analysis(broadcasts)
    fmt, cta = compute_format_analysis(broadcasts)
    timing = compute_timing_analysis(broadcasts)
    resend = compute_resend_analysis(broadcasts)
    deliverability = compute_deliverability_analysis(broadcasts)

    total_recipients = sum(b.get("recipients", 0) for b in broadcasts)

    kpis = compute_kpis(broadcasts, engagement)

    now = _now_iso()

    efi_data = {
        "generated_at": now,
        "data_state": data_state,
        "kpis": kpis,
        "analysis": {
            "generated_at": now,
            "data_state": data_state,
            "email_engagement": engagement,
            "subject": subject,
            "format": fmt,
            "cta": cta,
            "timing": timing,
            "resend": resend,
            "deliverability": deliverability,
            "revenue": _stub_revenue(),
            "buyer_buckets": _stub_buyer_buckets(),
            "funnel": _stub_funnel(total_recipients),
            "buyer_intent": _stub_buyer_intent(),
            "per_recipient_send_time": {
                "status": "pending",
                "note": "Per-recipient send-time optimisation requires individual send timestamps.",
            },
            "ga4": _stub_ga4(),
        },
        "revenue": _build_top_level_revenue(broadcasts),
        "strategy": _stub_strategy(),
        "broadcasts": broadcasts,
    }
    return efi_data


# ─────────────────────────────────────────────────────────────────────────────
# INJECTION + OUTPUT
# ─────────────────────────────────────────────────────────────────────────────

def inject_and_write(efi_data: dict, template_path: Path, output_path: Path) -> None:
    """Replace __EFI_DATA_INJECT__ in the template with the computed data object."""
    template = template_path.read_text(encoding="utf-8")

    token = "__EFI_DATA_INJECT__"
    if token not in template:
        raise ValueError(
            f"Template at {template_path} does not contain the injection token '{token}'.\n"
            "Ensure templates/TEMPLATE.html is the unmodified shipped template."
        )

    # Serialize to JSON — no indent for smallest output, readable is optional
    json_str = json.dumps(efi_data, ensure_ascii=False, separators=(",", ":"))
    injection = f"window.__EFI_DATA__ = {json_str};"

    output_html = template.replace(token, injection)
    output_path.write_text(output_html, encoding="utf-8")
    print(f"[generate] Dashboard written → {output_path}")


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Email Funnel Intelligence — Dashboard Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python generate.py --source csv --input export.csv --output dashboard.html
  python generate.py --source esp --input klaviyo_export.csv --output dashboard.html
  python generate.py --source ghl --input ghl_campaigns.csv --output dashboard.html
  python generate.py --source ghl --input api --output dashboard.html

Environment variables (GHL API mode):
  GHL_LOCATION_ID  — your GHL sub-account location ID
  GHL_API_KEY      — your GHL Location API key (legacy v1 API)
""",
    )
    parser.add_argument(
        "--source", required=True, choices=["csv", "esp", "ghl"],
        help="Input data source type",
    )
    parser.add_argument(
        "--input", required=True,
        help="Path to input CSV file, or 'api' for live GHL pull",
    )
    parser.add_argument(
        "--output", required=True,
        help="Output path for the generated dashboard.html",
    )
    parser.add_argument(
        "--template", default=None,
        help="Path to TEMPLATE.html (default: templates/TEMPLATE.html next to this script)",
    )
    parser.add_argument(
        "--esp-platform", default="auto",
        choices=["auto", "mailchimp", "klaviyo", "active_campaign", "convertkit", "generic"],
        help="ESP platform (only used when --source esp)",
    )

    args = parser.parse_args()

    # Resolve template path
    if args.template:
        template_path = Path(args.template).resolve()
    else:
        template_path = SCRIPT_DIR / "templates" / "TEMPLATE.html"

    if not template_path.exists():
        print(f"[generate] ERROR: Template not found at {template_path}", file=sys.stderr)
        sys.exit(1)

    # Resolve output path
    output_path = Path(args.output).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Load data via adapter
    source = args.source
    input_path = args.input

    print(f"[generate] Loading data: source={source}, input={input_path}")

    try:
        if source == "csv":
            adapter_result = load_csv(input_path)
            source_label = "CSV export"
        elif source == "esp":
            adapter_result = load_esp(input_path, platform=args.esp_platform)
            platform = adapter_result.get("_esp_platform", "generic")
            source_label = f"{platform.title()} ESP export"
        elif source == "ghl":
            adapter_result = load_ghl(input_path)
            ghl_src = adapter_result.get("_ghl_source", "csv")
            source_label = f"GoHighLevel ({'API' if ghl_src == 'api' else 'CSV export'})"
        else:
            print(f"[generate] Unknown source: {source}", file=sys.stderr)
            sys.exit(1)
    except FileNotFoundError as e:
        print(f"[generate] ERROR: Input file not found — {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"[generate] ERROR: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"[generate] ERROR loading data: {e}", file=sys.stderr)
        raise

    broadcasts = adapter_result.get("broadcasts", [])
    if not broadcasts:
        print("[generate] ERROR: No broadcast rows loaded — refusing to write an empty dashboard. "
              "Check your input file's columns and values.", file=sys.stderr)
        sys.exit(1)

    print(f"[generate] Loaded {len(broadcasts)} broadcast rows from {source_label}")

    # Assemble EFI data object
    print("[generate] Computing derived fields…")
    efi_data = assemble_efi_data(adapter_result, source_label)

    # Inject into template and write output
    print(f"[generate] Injecting into template {template_path.name}…")
    inject_and_write(efi_data, template_path, output_path)

    # Summary report
    ds = efi_data["data_state"]
    kpis = efi_data["kpis"]
    print("\n── Summary ─────────────────────────────────────────")
    print(f"  Broadcasts  : {kpis['broadcasts']}")
    print(f"  Recipients  : {kpis['recipients']:,}")
    print(f"  Date range  : {kpis['date_range'][0]} → {kpis['date_range'][-1]}")
    or_val = kpis.get("open_rate")
    cr_val = kpis.get("click_rate")
    print(f"  Open rate   : {str(round(or_val*100, 1))+'%' if or_val is not None else '—'}")
    print(f"  Click rate  : {str(round(cr_val*100, 1))+'%' if cr_val is not None else '—'}")
    print(f"  Data states : emails={'✓' if ds['emails'] else '○'}  "
          f"revenue={'✓' if ds['revenue'] else '○'}  "
          f"opens_clicks={'✓' if ds['opens_clicks'] else '○'}  "
          f"ga4={'✓' if ds['ga4'] else '○'}")
    print(f"  Output      : {output_path}")
    print("─────────────────────────────────────────────────────\n")


if __name__ == "__main__":
    main()
