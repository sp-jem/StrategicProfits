# Email Funnel Intelligence — Data Contract

**Version:** 1.0  
**Derived from:** Email Funnel Intelligence Dashboard.html (Jun 3 2026)  
**Principle:** Every field the rendered UI consumes is listed here. No fabrication. Derived fields are flagged so the generator knows what to compute vs. what to source raw.

---

## Legend

| Column | Meaning |
|--------|---------|
| Field | Dot-path within `window.__EFI_DATA__` |
| Type | JS/JSON type (str, int, float, bool, list, dict, null) |
| UI Consumer | Which panel/element reads this field |
| Req | R = required, O = optional (UI gracefully degrades if absent/null) |
| Source | Where the raw value originates |
| Raw/Derived | RAW = pulled directly from source; DERIVED = computed from other fields |

---

## Top-Level Object

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `generated_at` | str (ISO-8601 UTC) | Header timestamp ("Updated …") | R | Generator runtime | DERIVED (timestamp at generation time) |
| `data_state.emails` | bool | Header pill "GHL emails ●/○" | R | Generator (True if GHL email data loaded) | DERIVED |
| `data_state.revenue` | bool | Header pill "Stripe ●/○" | R | Generator (True if Stripe data loaded) | DERIVED |
| `data_state.opens_clicks` | bool | Header pill "Opens/Clicks ●/○" | R | Generator (True if Mailgun opens/clicks loaded) | DERIVED |
| `data_state.mailgun` | bool | Badge gating (graceful-degradation) | R | Generator (True if Mailgun API data loaded) | DERIVED |
| `data_state.ga4` | bool | Header pill "GA4 ●/○"; GA4 card visibility | R | Generator (True if GA4 data loaded) | DERIVED |

---

## `kpis` Object

Displayed as the top-row KPI tiles across the dashboard header.

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `kpis.broadcasts` | int | KPI tile "Broadcasts" | R | GHL email export | RAW |
| `kpis.recipients` | int | KPI tile "Recipients" | R | GHL email export (sum of all broadcast `recipients`) | DERIVED (sum) |
| `kpis.avg_delivered` | float (0–1) | — (used in kpis card; avg_bounce shown instead) | O | Mailgun / GHL delivered counts | DERIVED (weighted avg delivered_rate) |
| `kpis.avg_bounce` | float (0–1) | KPI tile "Avg Bounce" | R | Mailgun / GHL bounce counts | DERIVED (weighted avg bounce_rate) |
| `kpis.date_range` | list[2] str (YYYY-MM-DD) | Header date range ("2025-09-24 → 2026-05-28") | R | GHL export min/max send dates | DERIVED |
| `kpis.net_revenue` | float | KPI tile "Net Revenue" | R | Stripe net revenue (window) | RAW |
| `kpis.customers` | int | KPI tile "Customers" | R | Stripe unique customer count | RAW |
| `kpis.repeat_rate` | float (0–1) | KPI tile "Repeat Rate" | R | Stripe repeat-buyer count / unique customers | DERIVED |
| `kpis.rev_per_email` | float | KPI tile "$ / Email Sent" | R | `net_revenue` / `recipients` | DERIVED |
| `kpis.open_rate` | float (0–1) | KPI tile "Open Rate" | R | Mailgun unique opens / delivered | DERIVED |
| `kpis.click_rate` | float (0–1) | KPI tile "Click Rate" | R | Mailgun unique clicks / delivered | DERIVED |
| `kpis.per_opener` | float or null | KPI tile "$ / Opener" | O | `net_revenue` / Mailgun `opened_unique` | DERIVED |

---

## `analysis` Object

### `analysis.generated_at`
| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.generated_at` | str (ISO-8601 UTC) | Not directly rendered (internal timestamp) | O | Generator runtime | DERIVED |

### `analysis.data_state`
Identical structure to top-level `data_state`; used internally for graceful-degradation gating within analysis sections. Same fields: `emails`, `revenue`, `opens_clicks`, `mailgun`, `ga4` (all bool).

---

### `analysis.email_engagement` — "Email Engagement" card

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.email_engagement.status` | str ("complete"\|other) | Card badge LIVE/PENDING; section render gate | R | Generator | DERIVED |
| `analysis.email_engagement.overall_open_rate` | float (0–1) | KPI sub-tile "Open rate (unique)" | R | Mailgun: `opened_unique` / `delivered` | DERIVED |
| `analysis.email_engagement.overall_click_rate` | float (0–1) | KPI sub-tile "Click rate (unique)" | R | Mailgun: `clicked_unique` / `delivered` | DERIVED |
| `analysis.email_engagement.source` | str | Sub-header "source: …" | O | Generator label | DERIVED (label) |
| `analysis.email_engagement.mailgun.delivered` | int | — (used for CTOR calc) | R | Mailgun API | RAW |
| `analysis.email_engagement.mailgun.opened_unique` | int | — (used for open_rate) | R | Mailgun API | RAW |
| `analysis.email_engagement.mailgun.clicked_unique` | int | — (used for click_rate) | R | Mailgun API | RAW |
| `analysis.email_engagement.mailgun.open_rate` | float (0–1) | — (used in CTOR display) | R | `opened_unique` / `delivered` | DERIVED |
| `analysis.email_engagement.mailgun.click_rate` | float (0–1) | — | R | `clicked_unique` / `delivered` | DERIVED |
| `analysis.email_engagement.mailgun.ctor` | float (0–1) | KPI sub-tile "Click-to-open" | R | `clicked_unique` / `opened_unique` | DERIVED |
| `analysis.email_engagement.mailgun.click_to_open_rate` | float (0–1) | KPI sub-tile "Click-to-open" (alias of ctor) | R | `clicked_unique` / `opened_unique` | DERIVED |
| `analysis.email_engagement.campaign.delivered` | int | Table row "Campaigns" / Delivered | R | GHL Campaign emails | RAW |
| `analysis.email_engagement.campaign.opened` | int | Table row "Campaigns" / Open% numerator | R | GHL Campaign emails | RAW |
| `analysis.email_engagement.campaign.clicked` | int | — | R | GHL Campaign emails | RAW |
| `analysis.email_engagement.campaign.replied` | int | Table row "Campaigns" / Replies | R | GHL Campaign emails | RAW |
| `analysis.email_engagement.campaign.unsubscribed` | int | — | O | GHL Campaign emails | RAW |
| `analysis.email_engagement.campaign.revenue` | float | — | O | GHL Campaign attribution | RAW |
| `analysis.email_engagement.campaign.ordered` | int | — | O | GHL Campaign emails | RAW |
| `analysis.email_engagement.campaign.open_rate` | float (0–1) | Table row "Campaigns" / Open% | R | `opened` / `delivered` | DERIVED |
| `analysis.email_engagement.campaign.click_rate` | float (0–1) | Table row "Campaigns" / Click% | R | `clicked` / `delivered` | DERIVED |
| `analysis.email_engagement.workflow.delivered` | int | Table row "Workflows" / Delivered | R | GHL Workflow emails | RAW |
| `analysis.email_engagement.workflow.opened` | int | Table row "Workflows" / Open% numerator | R | GHL Workflow emails | RAW |
| `analysis.email_engagement.workflow.clicked` | int | — | R | GHL Workflow emails | RAW |
| `analysis.email_engagement.workflow.replied` | int | Table row "Workflows" / Replies | R | GHL Workflow emails | RAW |
| `analysis.email_engagement.workflow.unsubscribed` | int | — | O | GHL Workflow emails | RAW |
| `analysis.email_engagement.workflow.revenue` | float | — | O | GHL Workflow attribution | RAW |
| `analysis.email_engagement.workflow.ordered` | int | — | O | GHL Workflow emails | RAW |
| `analysis.email_engagement.workflow.open_rate` | float (0–1) | Table row "Workflows" / Open% | R | `opened` / `delivered` | DERIVED |
| `analysis.email_engagement.workflow.click_rate` | float (0–1) | Table row "Workflows" / Click% | R | `clicked` / `delivered` | DERIVED |
| `analysis.email_engagement.total.delivered` | int | — | O | GHL total | DERIVED (sum campaign+workflow) |
| `analysis.email_engagement.total.opened` | int | — | O | GHL total | DERIVED |
| `analysis.email_engagement.total.clicked` | int | — | O | GHL total | DERIVED |
| `analysis.email_engagement.total.replied` | int | — | O | GHL total | DERIVED |
| `analysis.email_engagement.total.unsubscribed` | int | — | O | GHL total | DERIVED |
| `analysis.email_engagement.total.revenue` | float | — | O | GHL total | DERIVED |
| `analysis.email_engagement.total.ordered` | int | — | O | GHL total | DERIVED |
| `analysis.email_engagement.total.open_rate` | float | — | O | GHL total | DERIVED |
| `analysis.email_engagement.total.click_rate` | float | — | O | GHL total | DERIVED |
| `analysis.email_engagement.note` | str | Note paragraph below table | O | Generator | DERIVED (narrative) |

---

### `analysis.subject` — "Subject Lines" card

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.subject.status` | str | Card badge | R | Generator | DERIVED |
| `analysis.subject.corpus` | int | Sub-header "Corpus N" | R | Count of GHL broadcasts | DERIVED |
| `analysis.subject.length.min` | int | Sub-header "length min N" | R | GHL subject strings | DERIVED |
| `analysis.subject.length.avg` | float | Sub-header "avg N" | R | GHL subject strings | DERIVED |
| `analysis.subject.length.median` | int | — (present in data, not rendered in UI text but available) | O | GHL subject strings | DERIVED |
| `analysis.subject.length.max` | int | Sub-header "max N" | R | GHL subject strings | DERIVED |
| `analysis.subject.length_buckets` | list[N] of dict | Bar chart "By length band" | R | GHL subject strings, bucketed | DERIVED |
| `analysis.subject.length_buckets[].length_band` | str | Bar label | R | — | DERIVED |
| `analysis.subject.length_buckets[].broadcasts` | int | Bar value | R | Count of broadcasts in band | DERIVED |
| `analysis.subject.length_buckets[].total_sent` | int | — (present, not directly rendered in bar) | O | GHL | DERIVED |
| `analysis.subject.length_buckets[].avg_click_rate` | float or null | — (present, not rendered in bar) | O | Mailgun / GHL | DERIVED |
| `analysis.subject.feature_distribution` | dict {feature: int} | Bar chart "Feature usage" | R | GHL subject NLP parse | DERIVED |
| `analysis.subject.feature_distribution.question` | int | Bar "question" | R | — | DERIVED |
| `analysis.subject.feature_distribution.brackets` | int | Bar "brackets" | R | — | DERIVED |
| `analysis.subject.feature_distribution.emoji` | int | Bar "emoji" | R | — | DERIVED |
| `analysis.subject.feature_distribution.number` | int | Bar "number" | R | — | DERIVED |
| `analysis.subject.feature_distribution.personalized` | int | Bar "personalized" | R | — | DERIVED |
| `analysis.subject.feature_distribution.allcaps_word` | int | Bar "allcaps_word" | R | — | DERIVED |
| `analysis.subject.feature_distribution.urgency` | int | Bar "urgency" | R | — | DERIVED |
| `analysis.subject.feature_distribution.curiosity` | int | Bar "curiosity" | R | — | DERIVED |
| `analysis.subject.feature_distribution.benefit` | int | Bar "benefit" | R | — | DERIVED |
| `analysis.subject.feature_vs_open` | dict {feature: list[dict]} | Pending/comparison section (renders if dict, shows pending-pend if str) | O | Mailgun opens joined to GHL subjects | DERIVED |
| `analysis.subject.feature_vs_open[feature][].feature_value` | bool | — | O | — | DERIVED |
| `analysis.subject.feature_vs_open[feature][].broadcasts` | int | — | O | — | DERIVED |
| `analysis.subject.feature_vs_open[feature][].total_sent` | int | — | O | — | DERIVED |
| `analysis.subject.feature_vs_open[feature][].avg_click_rate` | float | — | O | — | DERIVED |
| `analysis.subject.note` | str | — | O | Generator | DERIVED |

---

### `analysis.format` — "Format & CTA" card (format sub-section)

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.format.status` | str | Card badge (shared with CTA) | R | Generator | DERIVED |
| `analysis.format.format_distribution` | dict {format: int} | Bar chart "Email format" | R | GHL email format field | RAW (counts) |
| `analysis.format.format_distribution.plain-text` | int | Bar | R | GHL | RAW |
| `analysis.format.format_distribution.designed` | int | Bar | R | GHL | RAW |
| `analysis.format.word_count.min` | int | — (present, not directly rendered) | O | Body text parse | DERIVED |
| `analysis.format.word_count.avg` | float | — | O | Body text parse | DERIVED |
| `analysis.format.word_count.median` | int | — | O | Body text parse | DERIVED |
| `analysis.format.word_count.max` | int | — | O | Body text parse | DERIVED |
| `analysis.format.format_vs_response` | list[N] of dict | Table "Click-through rate by format" (renders if list with non-null avg_click_rate) | O | GHL + Mailgun joined | DERIVED |
| `analysis.format.format_vs_response[].format` | str | Table row label | O | — | DERIVED |
| `analysis.format.format_vs_response[].broadcasts` | int | — (present, not in table display) | O | — | DERIVED |
| `analysis.format.format_vs_response[].total_sent` | int | — | O | — | DERIVED |
| `analysis.format.format_vs_response[].avg_click_rate` | float or null | Table CTR column | O | Mailgun / GHL | DERIVED |
| `analysis.format.length_vs_response` | list[N] of dict | — (present, not rendered in current UI) | O | GHL + Mailgun | DERIVED |
| `analysis.format.length_vs_response[].length` | str | — | O | — | DERIVED |
| `analysis.format.length_vs_response[].broadcasts` | int | — | O | — | DERIVED |
| `analysis.format.length_vs_response[].total_sent` | int | — | O | — | DERIVED |
| `analysis.format.length_vs_response[].avg_click_rate` | float or null | — | O | — | DERIVED |

---

### `analysis.cta` — "Format & CTA" card (CTA sub-section)

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.cta.status` | str | Card badge | R | Generator | DERIVED |
| `analysis.cta.cta_type_distribution` | dict {type: int} | Bar chart "CTA type" | R | GHL email parse | RAW (counts) |
| `analysis.cta.cta_type_distribution.bareurl` | int | Bar | R | GHL | RAW |
| `analysis.cta.cta_type_distribution.none` | int | Bar | R | GHL | RAW |
| `analysis.cta.cta_type_distribution.button` | int | Bar | R | GHL | RAW |
| `analysis.cta.cta_type_distribution.reply` | int | Bar | R | GHL | RAW |
| `analysis.cta.cta_type_distribution.textlink` | int | Bar | R | GHL | RAW |
| `analysis.cta.cta_position_distribution` | dict {position: int} | Bar chart "CTA position" | R | GHL email parse | RAW (counts) |
| `analysis.cta.cta_position_distribution.top` | int | Bar | R | GHL | RAW |
| `analysis.cta.cta_position_distribution.bottom` | int | Bar | R | GHL | RAW |
| `analysis.cta.cta_position_distribution.middle` | int | Bar | R | GHL | RAW |
| `analysis.cta.reply_cta_count` | int | — (present, not rendered directly) | O | GHL | RAW |
| `analysis.cta.position_vs_click` | list[N] of dict | Table "CTR by CTA position" (renders if non-null avg_click_rate present) | O | GHL + Mailgun | DERIVED |
| `analysis.cta.position_vs_click[].position` | str | Table row label | O | — | DERIVED |
| `analysis.cta.position_vs_click[].broadcasts` | int | Table column | O | — | DERIVED |
| `analysis.cta.position_vs_click[].total_sent` | int | — | O | — | DERIVED |
| `analysis.cta.position_vs_click[].avg_click_rate` | float or null | Table CTR column | O | Mailgun / GHL | DERIVED |
| `analysis.cta.type_vs_click` | list[N] of dict | Table "CTR by CTA type" (renders if non-null avg_click_rate present) | O | GHL + Mailgun | DERIVED |
| `analysis.cta.type_vs_click[].cta_type` | str | Table row label | O | — | DERIVED |
| `analysis.cta.type_vs_click[].broadcasts` | int | Table column | O | — | DERIVED |
| `analysis.cta.type_vs_click[].total_sent` | int | — | O | — | DERIVED |
| `analysis.cta.type_vs_click[].avg_click_rate` | float or null | Table CTR column | O | Mailgun / GHL | DERIVED |
| `analysis.cta.observation` | str | Observation text below bars | O | Generator | DERIVED (narrative) |

---

### `analysis.timing` — "Send Timing" card

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.timing.status` | str | Card badge | R | Generator | DERIVED |
| `analysis.timing.send_distribution_by_day` | list[7] of dict | Bar chart "By day of week (sends)" | R | GHL send dates | DERIVED (counts) |
| `analysis.timing.send_distribution_by_day[].day` | str | Bar label | R | — | DERIVED |
| `analysis.timing.send_distribution_by_day[].broadcasts` | int | Bar value | R | — | DERIVED |
| `analysis.timing.send_distribution_by_day[].total_sent` | int | — | O | — | DERIVED |
| `analysis.timing.send_distribution_by_day[].avg_click_rate` | float or null | — | O | — | DERIVED |
| `analysis.timing.send_distribution_by_hour` | list[N] of dict | Bar chart "By hour ET (sends)" | R | GHL send hours | DERIVED (counts) |
| `analysis.timing.send_distribution_by_hour[].hour` | int | Bar label | R | — | DERIVED |
| `analysis.timing.send_distribution_by_hour[].broadcasts` | int | Bar value | R | — | DERIVED |
| `analysis.timing.send_distribution_by_hour[].total_sent` | int | — | O | — | DERIVED |
| `analysis.timing.send_distribution_by_hour[].avg_click_rate` | float or null | — | O | — | DERIVED |
| `analysis.timing.open_rate_by_day` | list[7] of dict | Bar chart "Open activity by day" (renders if non-empty list; shows pending message if absent) | O | Mailgun opens + GHL send dates | DERIVED |
| `analysis.timing.open_rate_by_day[].day` | str | Bar label + best-day star ★ | O | — | DERIVED |
| `analysis.timing.open_rate_by_day[].delivered` | int | — | O | — | DERIVED |
| `analysis.timing.open_rate_by_day[].open_rate` | float | Bar fill width; pct display | O | Mailgun opens / delivered by day | DERIVED |
| `analysis.timing.open_rate_by_day[].click_rate` | float | — (present, not rendered in bar) | O | — | DERIVED |
| `analysis.timing.best_day_for_opens` | dict {day, open_rate} | Star ★ marker on best day bar | O | Computed from open_rate_by_day | DERIVED |
| `analysis.timing.best_day_for_opens.day` | str | Star matching | O | — | DERIVED |
| `analysis.timing.best_day_for_opens.open_rate` | float | — | O | — | DERIVED |
| `analysis.timing.best_hour_for_opens` | str | — (present, not rendered in current UI) | O | Computed from send_distribution_by_hour + opens | DERIVED |
| `analysis.timing.caveat` | str | Caveat text below open-rate bar | O | Generator | DERIVED (narrative) |
| `analysis.timing.actionable` | str | Green callout box "▶ …" | O | Generator | DERIVED (narrative) |
| `analysis.timing.note` | str | — | O | Generator | DERIVED (narrative) |

---

### `analysis.resend` — "Resend Strategy" card

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.resend.status` | str | Card badge | R | Generator | DERIVED |
| `analysis.resend.resend_broadcasts` | int | Bar "Resends" value and proportion | R | GHL subject [RESEND] tag | DERIVED (count) |
| `analysis.resend.resend_to_unopened_enabled` | int | Sub-note "resend-to-unopened enabled: N" | R | GHL workflow config detection | DERIVED |
| `analysis.resend.bracket_resends` | int | Sub-note "[RESEND] subject sends: N" | R | GHL subject bracket parse | DERIVED |
| `analysis.resend.resend_lift` | list[2] of dict OR str | Pending-pend if str; table if list with non-null avg_click_rate | O | Mailgun opens joined to resend flag | DERIVED |
| `analysis.resend.resend_lift[].kind` | str | Table row label ("original"\|"resend") | O | — | DERIVED |
| `analysis.resend.resend_lift[].broadcasts` | int | — | O | — | DERIVED |
| `analysis.resend.resend_lift[].total_sent` | int | — | O | — | DERIVED |
| `analysis.resend.resend_lift[].avg_click_rate` | float or null | — | O | — | DERIVED |

---

### `analysis.deliverability` — "Deliverability" card

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.deliverability.status` | str | Card badge | R | Generator | DERIVED |
| `analysis.deliverability.avg_delivered_rate` | float (0–1) | Sub-header "avg delivered N%" | R | GHL `delivered_rate` weighted avg | DERIVED |
| `analysis.deliverability.avg_bounce_rate` | float (0–1) | Sub-header "avg bounce N%" | R | GHL `bounce_rate` weighted avg | DERIVED |
| `analysis.deliverability.worst_bounce` | list[N] of dict | Table "Worst bounce (list-hygiene flags)" | R | GHL broadcast data, sorted by bounce_rate desc | DERIVED |
| `analysis.deliverability.worst_bounce[].subject` | str | Table col "Subject" (truncated to 40 chars) | R | GHL | RAW |
| `analysis.deliverability.worst_bounce[].sent` | int | Table col "Sent" | R | GHL | RAW |
| `analysis.deliverability.worst_bounce[].bounce_rate` | float (0–1) | Table col "Bounce" | R | GHL | DERIVED |
| `analysis.deliverability.worst_bounce[].date` | str | — (present, not rendered in table) | O | GHL | RAW |
| `analysis.deliverability.note` | str | — | O | Generator | DERIVED |

---

### `analysis.revenue` — "Revenue" card

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.revenue.status` | str | Card badge | R | Generator | DERIVED |
| `analysis.revenue.net_revenue_window` | float | KPI sub-tile "Net revenue (window)" | R | Stripe net (charges - refunds) | DERIVED |
| `analysis.revenue.by_product` | dict {product: float} | Bar chart "By product" | R | Stripe product/description mapping | DERIVED (aggregated) |
| `analysis.revenue.by_month` | dict {YYYY-MM: float} | Bar chart "By month" | R | Stripe charge dates | DERIVED (aggregated) |
| `analysis.revenue.unique_customers` | int | — (also in buyer_buckets) | R | Stripe | RAW |
| `analysis.revenue.repeat_buyers` | int | — | R | Stripe | DERIVED |
| `analysis.revenue.repeat_rate` | float (0–1) | — | R | `repeat_buyers` / `unique_customers` | DERIVED |
| `analysis.revenue.total_emails_sent` | int | — (used for rev_per_email_sent) | R | GHL | DERIVED (sum) |
| `analysis.revenue.revenue_per_email_sent` | float | KPI sub-tile "Per email sent" | R | `net_revenue_window` / `total_emails_sent` | DERIVED |
| `analysis.revenue.money_per_opener_blended` | float | — (also in kpis.per_opener) | O | `net_revenue_window` / Mailgun `opened_unique` | DERIVED |
| `analysis.revenue.money_per_clicker_blended` | float | — | O | `net_revenue_window` / Mailgun `clicked_unique` | DERIVED |
| `analysis.revenue.ghl_attributed_email_revenue` | float | — (in note) | O | GHL campaign email attribution | RAW |
| `analysis.revenue.ghl_conversion_rate` | float | — | O | GHL attributed / total sent | DERIVED |
| `analysis.revenue.openers` | int | — | O | Mailgun | RAW |
| `analysis.revenue.clickers` | int | — | O | Mailgun | RAW |
| `analysis.revenue.note` | str | — | O | Generator | DERIVED |
| `analysis.revenue.ga4_attributed` | str | — (reference pointer to ga4 section) | O | Generator | DERIVED |

---

### `analysis.buyer_buckets` — "Buyer Buckets — RFM" card

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.buyer_buckets.status` | str | Card badge | R | Generator | DERIVED |
| `analysis.buyer_buckets.buckets` | list[5] of dict | Table (Bucket / Customers / Revenue) | R | Stripe + RFM segmentation | DERIVED |
| `analysis.buyer_buckets.buckets[].bucket` | str | Table col "Bucket" | R | RFM label | DERIVED |
| `analysis.buyer_buckets.buckets[].customers` | int | Table col "Customers" | R | Stripe count | DERIVED |
| `analysis.buyer_buckets.buckets[].revenue` | float | Table col "Revenue" | R | Stripe net for bucket | DERIVED |
| `analysis.buyer_buckets.whale_threshold_$` | float | — (present, not rendered in UI) | O | Stripe percentile calc | DERIVED |
| `analysis.buyer_buckets.recommended_actions` | dict {bucket_label: str} | "Recommended action per bucket" section | R | Generator | DERIVED (narrative) |
| `analysis.buyer_buckets.note` | str | — | O | Generator | DERIVED |

---

### `analysis.funnel` — "Funnel: Suspect → Prospect → Client → Repeat" card

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.funnel.status` | str | — | R | Generator | DERIVED |
| `analysis.funnel.stages` | list[4] of dict | Table (Stage / Size / Source) | R | Multi-source | DERIVED |
| `analysis.funnel.stages[].stage` | str | Table col "Stage" | R | — | DERIVED (label) |
| `analysis.funnel.stages[].size` | int or null | Table col "Size" (null → "—") | R | GHL / Stripe / estimate | RAW or DERIVED |
| `analysis.funnel.stages[].source` | str | Table col "Source" text | R | — | DERIVED (label) |
| `analysis.funnel.stages[].confidence` | str | Tag badge in Source col | R | — | DERIVED (label) |
| `analysis.funnel.repeat_rate` | float | — (present, not rendered directly) | O | Stripe | DERIVED |
| `analysis.funnel.note` | str | Note paragraph | O | Generator | DERIVED |

---

### `analysis.buyer_intent` — "Buyer Intent — Top 2 Signals" card

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.buyer_intent.status` | str | — | R | Generator | DERIVED |
| `analysis.buyer_intent.top_signals` | list[N] of dict | Signal cards | R | Generator (Stripe + GHL analysis) | DERIVED |
| `analysis.buyer_intent.top_signals[].rank` | int | "#N" header | R | — | DERIVED |
| `analysis.buyer_intent.top_signals[].signal` | str | Signal name | R | — | DERIVED |
| `analysis.buyer_intent.top_signals[].available_now` | bool | Badge LIVE/PENDING | R | — | DERIVED |
| `analysis.buyer_intent.top_signals[].why` | str | "Why" sub-text | R | — | DERIVED |
| `analysis.buyer_intent.top_signals[].use` | str | "Use:" action text | R | — | DERIVED |
| `analysis.buyer_intent.note` | str | — | O | Generator | DERIVED |

---

### `analysis.per_recipient_send_time` — not rendered; data-quality flag only

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.per_recipient_send_time.status` | str | — (present, not rendered in current UI) | O | Generator | DERIVED |
| `analysis.per_recipient_send_time.note` | str | — | O | Generator | DERIVED |

---

### `analysis.ga4` — "GA4 — Email Traffic → Revenue" card

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `analysis.ga4.status` | str | Card render gate (skips if not "complete") | R | Generator | DERIVED |
| `analysis.ga4.email_sessions` | int | KPI sub-tile "Email sessions" | R | GA4 (utm_medium=email sessions) | RAW |
| `analysis.ga4.email_conversions` | int | KPI sub-tile "Conversions" | R | GA4 email-attributed conversions | RAW |
| `analysis.ga4.email_revenue` | float | KPI sub-tile "Email revenue (UTM)" | R | GA4 email-attributed revenue | RAW |
| `analysis.ga4.email_conversion_rate` | float (0–1) | KPI sub-tile "Session→conv rate" | R | `email_conversions` / `email_sessions` | DERIVED |
| `analysis.ga4.revenue_per_session` | float | — (present, not rendered in KPI tiles) | O | `email_revenue` / `email_sessions` | DERIVED |
| `analysis.ga4.top_email_campaigns` | list[N] of dict | Table "Top email campaigns by sessions" (first 10) | R | GA4 campaign dimension | RAW |
| `analysis.ga4.top_email_campaigns[].campaign` | str | Table col "Campaign" (truncated to 34 chars) | R | GA4 | RAW |
| `analysis.ga4.top_email_campaigns[].sessions` | int | Table col "Sessions" | R | GA4 | RAW |
| `analysis.ga4.top_email_campaigns[].conversions` | int | Table col "Conv" | R | GA4 | RAW |
| `analysis.ga4.top_email_campaigns[].revenue` | float | Table col "Revenue" | R | GA4 | RAW |
| `analysis.ga4.channels` | list[N] of dict | — (present, not rendered in current UI) | O | GA4 channel dimension | RAW |
| `analysis.ga4.channels[].channel` | str | — | O | GA4 | RAW |
| `analysis.ga4.channels[].sessions` | int | — | O | GA4 | RAW |
| `analysis.ga4.channels[].revenue` | float | — | O | GA4 | RAW |
| `analysis.ga4.note` | str | Note paragraph | O | Generator | DERIVED |

---

## `revenue` Object (top-level)

Separate from `analysis.revenue`. Contains the raw Stripe ledger used downstream but not directly rendered in KPI tiles — it feeds `analysis.revenue` computations.

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `revenue.generated_at` | str (ISO-8601 UTC) | — | O | Generator runtime | DERIVED |
| `revenue.window_start` | str (YYYY-MM-DD) | — | R | Configuration / Stripe window | RAW |
| `revenue.summary.charges` | int | — | R | Stripe | RAW |
| `revenue.summary.gross_revenue` | float | — | R | Stripe | RAW |
| `revenue.summary.refunds` | float | — | R | Stripe | RAW |
| `revenue.summary.net_revenue` | float | — (feeds analysis.revenue.net_revenue_window) | R | Stripe: gross - refunds | DERIVED |
| `revenue.summary.unique_customers` | int | — | R | Stripe | DERIVED |
| `revenue.summary.repeat_buyers` | int | — | R | Stripe | DERIVED |
| `revenue.summary.repeat_rate` | float | — | R | `repeat_buyers` / `unique_customers` | DERIVED |
| `revenue.by_month` | dict {YYYY-MM: float} | — (feeds analysis.revenue.by_month) | R | Stripe charge dates | DERIVED |
| `revenue.by_product` | dict {product: float} | — (feeds analysis.revenue.by_product) | R | Stripe product mapping | DERIVED |
| `revenue.by_customer` | dict {email: {revenue, charges, last_date, recency_days}} | — (not rendered in UI; used for buyer_buckets/RFM) | R | Stripe | RAW |
| `revenue.by_customer[email].revenue` | float | — | R | Stripe | DERIVED (sum) |
| `revenue.by_customer[email].charges` | int | — | R | Stripe | RAW |
| `revenue.by_customer[email].last_date` | str (YYYY-MM-DD) | — | R | Stripe | RAW |
| `revenue.by_customer[email].recency_days` | int | — | R | Computed from last_date | DERIVED |

---

## `strategy` Object (top-level)

Rendered as the "Action Plan" section at the top of the dashboard, above all analysis.

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `strategy.panels` | list[8] of dict | Per-panel scored-move tables | R | Generator (9-agent scoring workflow) | DERIVED |
| `strategy.panels[].panel` | str | Card heading | R | — | DERIVED |
| `strategy.panels[].funnel_stage` | str | — (present, not directly rendered in card) | O | — | DERIVED |
| `strategy.panels[].current_state` | str | Sub-text below panel heading | O | — | DERIVED |
| `strategy.panels[].moves` | list[N] of dict | Table rows (sorted by composite desc) | R | — | DERIVED |
| `strategy.panels[].moves[].title` | str | Table col "Move" (bold) | R | — | DERIVED |
| `strategy.panels[].moves[].action` | str | Table col "Move" (sub-text) | O | — | DERIVED |
| `strategy.panels[].moves[].why_it_works` | str | — (present, not in table columns) | O | — | DERIVED |
| `strategy.panels[].moves[].expected_result` | str | Table col "Expected result" | R | — | DERIVED |
| `strategy.panels[].moves[].money_impact` | str or int | Table col "$" | R | — | DERIVED |
| `strategy.panels[].moves[].speed` | str or int | Table col "Spd" | R | — | DERIVED |
| `strategy.panels[].moves[].effort` | str or int | Table col "Eff" | R | — | DERIVED |
| `strategy.panels[].moves[].confidence` | str or int | Table col "Conf" | R | — | DERIVED |
| `strategy.panels[].moves[].composite` | float or int | Table col "Score" (bold); sort key | R | Computed: f(money_impact, speed, confidence, effort) | DERIVED |
| `strategy.panels[].top_move` | str | — (present, not rendered separately; top move is first row after composite sort) | O | — | DERIVED |
| `strategy.synthesis.master_priority` | list[N] of dict | Master Priority table | R | — | DERIVED |
| `strategy.synthesis.master_priority[].rank` | int | Table col "#" | R | — | DERIVED |
| `strategy.synthesis.master_priority[].move` | str | Table col "Move" (bold) | R | — | DERIVED |
| `strategy.synthesis.master_priority[].panel` | str | Table col "Panel" (sub-text) | R | — | DERIVED |
| `strategy.synthesis.master_priority[].composite` | str or float | Table col "Score" | R | — | DERIVED |
| `strategy.synthesis.master_priority[].money_impact` | str | Table col "$" | R | — | DERIVED |
| `strategy.synthesis.master_priority[].speed` | str | Table col "Spd" | R | — | DERIVED |
| `strategy.synthesis.master_priority[].one_liner` | str | Table col "Why" | R | — | DERIVED |
| `strategy.synthesis.quick_wins` | list[N] str | "⚡ Quick Wins" bullet list | R | — | DERIVED |
| `strategy.synthesis.big_bets` | list[N] str | "🎯 Big Bets" bullet list | R | — | DERIVED |
| `strategy.synthesis.sequencing_note` | str | Green callout box "▶ …" | O | — | DERIVED |

---

## `broadcasts` Array (top-level)

Drives the sortable "All Broadcasts" table. One entry per GHL broadcast.

| Field | Type | UI Consumer | Req | Source | Raw/Derived |
|-------|------|-------------|-----|--------|-------------|
| `broadcasts[].id` | str | — (present, not rendered in table) | R | GHL broadcast ID | RAW |
| `broadcasts[].subject` | str | Table col "Subject" (truncated to 60 chars; full in title attr) | R | GHL | RAW |
| `broadcasts[].send_date_et` | str (YYYY-MM-DD) | Table col "Date" | R | GHL send_time → ET | DERIVED |
| `broadcasts[].send_dow_et` | str ("Mon"…"Sun") | Table col "Day" | R | GHL send_time → day-of-week | DERIVED |
| `broadcasts[].send_hour_et` | int (0–23) | Table col "Hr" | R | GHL send_time → ET hour | DERIVED |
| `broadcasts[].send_epoch_ms` | int | Sort key (default descending) | R | GHL send_time | DERIVED |
| `broadcasts[].recipients` | int | Table col "Sent" | R | GHL | RAW |
| `broadcasts[].delivered` | int | — | R | GHL | RAW |
| `broadcasts[].delivered_rate` | float (0–1) | Table col "Deliv%" | R | `delivered` / `recipients` | DERIVED |
| `broadcasts[].bounce_rate` | float (0–1) | Table col "Bounce%" | R | `1 - delivered_rate` or GHL bounce count / sent | DERIVED |
| `broadcasts[].cta_type` | str | Table col "CTA" | R | GHL email parse | DERIVED |
| `broadcasts[].cta_position` | str | Table col "Pos" | R | GHL email parse | DERIVED |
| `broadcasts[].email_format` | str | — (present, not in default table columns) | R | GHL | DERIVED |
| `broadcasts[].word_count` | int | — (present, not in default table columns) | R | Body text parse | DERIVED |
| `broadcasts[].subject_len` | int | — (present, not in default table columns) | R | Subject string length | DERIVED |
| `broadcasts[].open_rate` | float or null | Table col — (shown as "—" when null) | O | Mailgun per-broadcast (limited retention) | RAW or null |
| `broadcasts[].click_rate` | float or null | Table col "CTR" | O | Mailgun per-broadcast (limited retention) | RAW or null |
| `broadcasts[].opens` | int or null | — (present, not in default table columns) | O | Mailgun | RAW or null |
| `broadcasts[].clicks` | int | Table col "Clicks" | O | Mailgun | RAW or null |

---

## Graceful-Degradation Rules (as implemented in the UI)

The UI hides cards when data is unavailable. The generator must faithfully set `status` fields:

| Condition | Effect |
|-----------|--------|
| `analysis.email_engagement.status !== "complete"` | Engagement card shows PENDING placeholder |
| `analysis.ga4.status !== "complete"` | GA4 card skipped entirely |
| `analysis.cta.position_vs_click` is a string (not list) | CTA comparison tables show pending pend |
| `analysis.subject.feature_vs_open` is a string (not dict) | Feature-vs-open section shows pending pend |
| `analysis.resend.resend_lift` is a string | Resend lift section shows pending pend |
| `analysis.timing.open_rate_by_day` is empty list or absent | "Open activity by day" shows pending message |
| Card contains `.badge.pend` | Entire card hidden by cleanup script (350ms after load) |
| Card has no table/kpi/bar/tblwrap/img and text < 70 chars | Card hidden by cleanup script |
| `data_state.*` = false | Corresponding header pill shows ○ (grey) |

---

## Source Mapping Summary

| Data Source | Fields It Provides |
|-------------|-------------------|
| **GHL (GoHighLevel) Email Export** | `broadcasts[].*` (raw send metadata), campaign/workflow split in `email_engagement`, `format_distribution`, `cta_*_distribution`, `send_distribution_*`, `resend_*` |
| **Mailgun API** | `email_engagement.mailgun.*` (authoritative unique opens/clicks), per-broadcast `open_rate`/`click_rate`/`opens`/`clicks` (limited retention ~90d), `open_rate_by_day`, `deliverability.avg_*` |
| **Stripe API** | `revenue.*`, `analysis.revenue.*`, `buyer_buckets.*`, `funnel.stages` (client + repeat tiers), `buyer_intent.top_signals[0]` (RFM) |
| **GA4 API** | `analysis.ga4.*` (UTM-tagged email sessions, conversions, revenue, top campaigns, channels) |
| **Generator (computed)** | All rates, averages, derived aggregates, strategy panels/synthesis, narrative notes, `data_state.*`, `generated_at` timestamps |
