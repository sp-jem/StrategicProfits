"""
ESP Adapter — Generic ESP (Mailchimp, Klaviyo, ActiveCampaign, ConvertKit, etc.)
export CSV → EFI data dict.

Most ESPs export campaign/broadcast stats as a flat CSV. Column names vary widely
by platform. This adapter handles the most common ones via an alias table and
falls back to the csv_adapter for rows it can't map specifically.

Supported ESP export formats (auto-detected by column fingerprint):
  - Mailchimp  (campaign_title, unique_opens, unique_clicks, emails_sent …)
  - Klaviyo    (Subject Line, Unique Recipients, Opens, Clicks …)
  - ActiveCampaign (Campaign Name, Subject, Sent, Opens, Clicks …)
  - ConvertKit (subject, recipients, open_rate, click_rate …)
  - Generic    (falls back to csv_adapter column aliases)

Revenue data is NOT present in standard ESP exports. Pass --source esp for
engagement-only mode; pair with --stripe-csv for revenue enrichment.

Usage:
    from adapters.esp_adapter import load_esp
    result = load_esp("/path/to/export.csv")
"""

from adapters.csv_adapter import load_csv


# Per-platform column maps.  Keys = original ESP column, Values = EFI canonical.
MAILCHIMP_MAP = {
    "campaign_title": "subject",
    "send_time": "send_time",
    "emails_sent": "recipients",
    "total_opens": "opens",       # Mailchimp unique_opens preferred below
    "unique_opens": "opens",
    "unique_clicks": "clicks",
    "total_clicks": "clicks",
    "unsubscribed": "unsubscribed",
    "bounced": "bounce_count",
    "list_name": "_list_name",
    "subject_line": "subject",
}

KLAVIYO_MAP = {
    "subject line": "subject",
    "subject_line": "subject",
    "unique recipients": "recipients",
    "unique_recipients": "recipients",
    "delivered": "delivered",
    "opens": "opens",
    "unique opens": "opens",
    "unique_opens": "opens",
    "clicks": "clicks",
    "unique clicks": "clicks",
    "unique_clicks": "clicks",
    "unsubscribes": "unsubscribed",
    "bounces": "bounce_count",
    "send time": "send_time",
    "send_time": "send_time",
    "scheduled send time": "send_time",
}

ACTIVE_CAMPAIGN_MAP = {
    "campaign name": "subject",   # AC uses campaign name; no separate subject column
    "campaign_name": "subject",
    "subject": "subject",
    "sent": "recipients",
    "opens": "opens",
    "unique opens": "opens",
    "clicks": "clicks",
    "unique clicks": "clicks",
    "unsubscribes": "unsubscribed",
    "bounces": "bounce_count",
    "send date": "send_time",
    "send_date": "send_time",
    "date": "send_time",
}

CONVERTKIT_MAP = {
    "name": "id",
    "subject": "subject",
    "recipients": "recipients",
    "open rate": "open_rate",    # ConvertKit exports rates directly
    "open_rate": "open_rate",
    "click rate": "click_rate",
    "click_rate": "click_rate",
    "unsubscribes": "unsubscribed",
    "created at": "send_time",
    "sent at": "send_time",
    "send_time": "send_time",
}


def _detect_platform(headers: list) -> str:
    """
    Fingerprint the platform from the column header names.
    Returns one of: 'mailchimp', 'klaviyo', 'active_campaign', 'convertkit', 'generic'.
    """
    lower = {h.lower().strip() for h in headers}
    if "emails_sent" in lower or "campaign_title" in lower:
        return "mailchimp"
    if "unique recipients" in lower or "subject line" in lower:
        return "klaviyo"
    if "campaign name" in lower or "campaign_name" in lower:
        return "active_campaign"
    if "open rate" in lower or ("recipients" in lower and "subject" in lower):
        return "convertkit"
    return "generic"


def load_esp(path: str, platform: str = "auto", column_map: dict = None) -> dict:
    """
    Load an ESP export CSV and return a partial EFI data dict.

    Args:
        path:        Path to the ESP CSV export.
        platform:    'auto' (default) | 'mailchimp' | 'klaviyo' |
                     'active_campaign' | 'convertkit' | 'generic'
        column_map:  Optional extra overrides merged on top of platform map.

    Returns:
        Same structure as csv_adapter.load_csv() — broadcasts list + state flags.
    """
    import csv as _csv

    # Peek at headers for auto-detection
    with open(path, newline="", encoding="utf-8-sig") as fh:
        reader = _csv.reader(fh)
        try:
            headers = next(reader)
        except StopIteration:
            return {"broadcasts": [], "_csv_has_opens": False,
                    "_csv_has_clicks": False, "_csv_has_revenue": False,
                    "_csv_has_ga4": False}

    if platform == "auto":
        platform = _detect_platform(headers)

    platform_maps = {
        "mailchimp": MAILCHIMP_MAP,
        "klaviyo": KLAVIYO_MAP,
        "active_campaign": ACTIVE_CAMPAIGN_MAP,
        "convertkit": CONVERTKIT_MAP,
        "generic": {},
    }
    merged_map = dict(platform_maps.get(platform, {}))
    if column_map:
        merged_map.update(column_map)

    # Normalise alias keys the same way csv_adapter normalises CSV headers
    # (lowercase + spaces→underscores); otherwise space-form keys never match.
    merged_map = {k.lower().strip().replace(" ", "_"): v for k, v in merged_map.items()}

    result = load_csv(path, column_map=merged_map)
    result["_esp_platform"] = platform
    return result
