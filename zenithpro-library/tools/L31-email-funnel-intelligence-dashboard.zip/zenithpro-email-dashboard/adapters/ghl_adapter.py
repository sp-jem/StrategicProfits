"""
GoHighLevel (GHL) Adapter — two input modes:

MODE 1 — CSV (default when --input is a .csv file)
  GHL's Email Statistics export (Marketing > Emails > Export) produces a CSV
  with these columns (as of 2025 GHL exports):
    id, title (=subject), status, contact_count (=recipients),
    sent_count, delivered_count, open_count, click_count, reply_count,
    unsubscribed_count, bounce_count, email_type (campaign|workflow),
    created_at, scheduled_at, sent_at

MODE 2 — Live GHL API pull (optional; requires credentials)
  Set env vars (or respond to prompts):
    GHL_LOCATION_ID   — your GHL sub-account location ID
    GHL_API_KEY       — GHL Location API key (legacy v1 API)
  The adapter calls:
    GHL's legacy v1 REST API (rest.gohighlevel.com/v1), paginated
  Requires the 'requests' library in API mode (clear error if missing —
  use a GHL CSV export if you'd rather not install it).

NOTE: No credential is ever written to disk by this script. Env-var access only.
"""

import csv
import getpass
import os
import sys
from datetime import datetime, timezone
from adapters.csv_adapter import (
    _safe_int, _safe_float, _parse_datetime,
    _et_date, _et_dow, _et_hour,
    _infer_cta_type, _infer_cta_position, _word_count,
    _detect_subject_features, load_csv
)


# GHL CSV column → EFI canonical mapping
GHL_CSV_MAP = {
    "title": "subject",
    "name": "subject",
    "email_name": "subject",
    "contact_count": "recipients",
    "sent_count": "recipients",          # fallback
    "delivered_count": "delivered",
    "open_count": "opens",
    "click_count": "clicks",
    "reply_count": "replies",
    "unsubscribed_count": "unsubscribed",
    "bounce_count": "bounce_count",
    "created_at": "send_time",
    "scheduled_at": "send_time",         # fallback
    "sent_at": "send_time",              # preferred
    "email_type": "email_type",          # campaign | workflow — NOT mapped to email_format
    "type": "email_type",
    "format": "email_format",
}


def _ghl_csv_to_efi_row(raw: dict) -> dict:
    """Convert a single GHL CSV row to the EFI broadcast schema."""
    # Normalise keys
    row = {k.strip().lower().replace(" ", "_"): (v or "").strip()
           for k, v in raw.items()}

    # Apply GHL-specific column mappings
    normed = {}
    for k, v in row.items():
        canon = GHL_CSV_MAP.get(k, k)
        if canon not in normed:   # first canonical match wins for this normalizer (precedence follows the source's column order)
            normed[canon] = v

    bid = normed.get("id", "")
    subject = normed.get("subject", normed.get("name", ""))

    # Time — prefer sent_at, fallback to scheduled_at, then created_at
    dt = None
    for tf in ("send_time", "sent_at", "scheduled_at", "created_at"):
        dt = _parse_datetime(normed.get(tf, ""))
        if dt:
            break

    recipients = _safe_int(normed.get("recipients", 0))
    if recipients == 0:
        return None  # skip

    delivered_raw = _safe_int(normed.get("delivered", -1), default=-1)
    delivered = delivered_raw if delivered_raw >= 0 else recipients

    delivered_rate = delivered / recipients if recipients > 0 else 0.0
    bc = _safe_int(normed.get("bounce_count", 0))
    bounce_rate = bc / recipients if recipients > 0 else (1.0 - delivered_rate)

    opens_raw = _safe_int(normed.get("opens", -1), default=-1)
    clicks_raw = _safe_int(normed.get("clicks", -1), default=-1)
    opens = opens_raw if opens_raw >= 0 else None
    clicks = clicks_raw if clicks_raw >= 0 else None
    open_rate = (opens / delivered) if (opens is not None and delivered > 0) else None
    click_rate = (clicks / delivered) if (clicks is not None and delivered > 0) else None

    # GHL email_type = campaign | workflow (separate from email_format)
    email_type = normed.get("email_type", "campaign").lower()
    # email_format from a separate column, default plain-text
    fmt_raw = normed.get("email_format", "").lower()
    if "design" in fmt_raw or "html" in fmt_raw:
        email_format = "designed"
    else:
        email_format = "plain-text"

    body = normed.get("body_text", "")
    cta_type = normed.get("cta_type") or _infer_cta_type(body)
    pos_raw = normed.get("cta_position", "")
    cta_position = pos_raw if pos_raw in ("top", "middle", "bottom") else _infer_cta_position(body, cta_type)

    wc_raw = _safe_int(normed.get("word_count", -1), default=-1)
    wc = wc_raw if wc_raw >= 0 else _word_count(body)

    return {
        "id": bid,
        "subject": subject,
        "send_date_et": _et_date(dt),
        "send_dow_et": _et_dow(dt),
        "send_hour_et": _et_hour(dt),
        "send_epoch_ms": int(dt.timestamp() * 1000) if dt else 0,
        "recipients": recipients,
        "delivered": delivered,
        "delivered_rate": round(delivered_rate, 4),
        "bounce_rate": round(bounce_rate, 4),
        "cta_type": cta_type or "none",
        "cta_position": cta_position,
        "email_format": email_format,
        "word_count": wc,
        "subject_len": len(subject),
        "open_rate": round(open_rate, 4) if open_rate is not None else None,
        "click_rate": round(click_rate, 4) if click_rate is not None else None,
        "opens": opens,
        "clicks": clicks,
        "_replies": _safe_int(normed.get("replies", 0)),
        "_unsubscribed": _safe_int(normed.get("unsubscribed", 0)),
        "_email_type": email_type,   # "campaign" | "workflow" — used for engagement split
    }


def _load_from_ghl_api(location_id: str, api_key: str) -> list:
    """
    Pull email campaign stats from GHL's legacy v1 REST API.

    API mode requires: pip install requests
    Raises a clear error if requests is missing (use a GHL CSV export instead).

    Returns list of raw broadcast dicts in GHL API format.
    """
    try:
        import requests  # required for API mode only
    except ImportError:
        raise RuntimeError(
            "'requests' is required for --input api. Run: pip install requests — "
            "or use a GHL CSV export instead.")

    base_url = "https://rest.gohighlevel.com/v1"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    broadcasts = []
    skip = 0
    limit = 100
    while True:
        url = f"{base_url}/email-campaigns?locationId={location_id}&limit={limit}&skip={skip}"
        try:
            resp = requests.get(url, headers=headers, timeout=30)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            print(f"[ghl_adapter] API error at skip={skip}: {e}", file=sys.stderr)
            break

        items = data.get("campaigns", data.get("emails", data.get("results", [])))
        if not items:
            break
        for item in items:
            # Normalise API response to match CSV column names
            normed = {
                "id": item.get("id", ""),
                "subject": item.get("subject", item.get("name", item.get("title", ""))),
                "recipients": item.get("contactCount", item.get("sentCount", 0)),
                "delivered_count": item.get("deliveredCount", -1),
                "open_count": item.get("openCount", -1),
                "click_count": item.get("clickCount", -1),
                "reply_count": item.get("replyCount", 0),
                "unsubscribed_count": item.get("unsubscribedCount", 0),
                "bounce_count": item.get("bounceCount", 0),
                "sent_at": item.get("sentAt", item.get("scheduledAt", item.get("createdAt", ""))),
                "email_type": item.get("type", "campaign"),
            }
            broadcasts.append(normed)
        skip += limit
        if len(items) < limit:
            break

    return broadcasts


def load_ghl(path: str) -> dict:
    """
    Load GHL data from either a CSV file or the live GHL API.

    Decision logic:
      1. If path ends with .csv → load from file.
      2. If path == "api" → attempt live pull using env vars.
      3. If GHL_API_KEY and GHL_LOCATION_ID are set AND path == "api" → live pull.

    Credentials: read from env vars GHL_API_KEY and GHL_LOCATION_ID only.
    Never stored or written to disk.

    Returns:
      {
        broadcasts: [...],
        _csv_has_opens: bool,
        _csv_has_clicks: bool,
        _csv_has_revenue: bool,  # always False
        _csv_has_ga4: bool,      # always False
        _ghl_source: "csv"|"api"
      }
    """
    if path.lower().endswith(".csv"):
        # CSV path — delegate to load_csv with GHL-specific column map
        result = load_csv(path, column_map=GHL_CSV_MAP)
        result["_ghl_source"] = "csv"
        return result

    # API mode
    location_id = os.environ.get("GHL_LOCATION_ID", "").strip()
    api_key = os.environ.get("GHL_API_KEY", "").strip()

    if not location_id or not api_key:
        # Interactive prompt (only if running in a terminal)
        if sys.stdin.isatty():
            print("[ghl_adapter] GHL_LOCATION_ID and GHL_API_KEY not set in environment.")
            location_id = input("  Enter GHL Location ID: ").strip()
            api_key = getpass.getpass("  Enter GHL API Key (input hidden): ").strip()
        else:
            raise ValueError(
                "GHL API credentials not found. Set GHL_LOCATION_ID and GHL_API_KEY "
                "environment variables, or provide a CSV file path."
            )

    raw_items = _load_from_ghl_api(location_id, api_key)
    if not raw_items:
        raise RuntimeError(
            "GHL API returned no data. Check credentials and location ID."
        )

    broadcasts = []
    for raw in raw_items:
        row = _ghl_csv_to_efi_row(raw)
        if row:
            broadcasts.append(row)

    has_opens = any(b["open_rate"] is not None for b in broadcasts)
    has_clicks = any(b["click_rate"] is not None for b in broadcasts)

    return {
        "broadcasts": broadcasts,
        "_csv_has_opens": has_opens,
        "_csv_has_clicks": has_clicks,
        "_csv_has_revenue": False,
        "_csv_has_ga4": False,
        "_ghl_source": "api",
    }
