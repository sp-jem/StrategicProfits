# adapters package — email-funnel-intelligence
