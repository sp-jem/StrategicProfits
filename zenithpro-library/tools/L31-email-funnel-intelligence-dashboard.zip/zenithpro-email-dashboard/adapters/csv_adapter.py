"""
CSV Adapter — Generic email broadcast CSV → EFI data dict

Expected CSV columns (all optional unless marked required):
  id           (str)   — broadcast/email ID                  [required]
  subject      (str)   — email subject line                   [required]
  send_time    (str)   — ISO-8601 or any common datetime      [required]
  recipients   (int)   — total recipients                     [required]
  delivered    (int)   — delivered count; if absent, assumed = recipients
  opens        (int)   — unique opens (if available)
  clicks       (int)   — unique clicks (if available)
  replies      (int)   — reply count
  unsubscribed (int)   — unsubscribe count
  bounce_count (int)   — bounce count (alternative to bounce_rate)
  bounce_rate  (float) — bounce rate 0-1 (alternative to bounce_count)
  email_format (str)   — "plain-text" | "designed"
  cta_type     (str)   — "button" | "textlink" | "bareurl" | "reply" | "none"
  cta_position (str)   — "top" | "middle" | "bottom"
  body_text    (str)   — email body text (used for word count)
  word_count   (int)   — pre-computed word count (alternative to body_text)

Columns can be named differently if you pass a column_map dict:
  {"subject": "email_subject", "send_time": "sent_at", ...}

Returns a dict with keys: broadcasts, kpis, analysis_partial
  analysis_partial contains what we can compute from CSV alone.
  Higher-level sources (Stripe, Mailgun, GA4) fill the rest.
"""

import csv
import re
import unicodedata
from datetime import datetime, timezone
from collections import defaultdict
from typing import Optional


# --------------------------------------------------------------------------
# Column name aliases (normalise whatever the user's export calls things)
# --------------------------------------------------------------------------
DEFAULT_ALIASES = {
    # id variants
    "broadcast_id": "id", "email_id": "id", "campaign_id": "id",
    # subject variants
    "email_subject": "subject", "subject_line": "subject",
    # time variants
    "sent_at": "send_time", "send_date": "send_time", "date_sent": "send_time",
    "scheduled_time": "send_time", "timestamp": "send_time",
    # recipient variants
    "total_recipients": "recipients", "sent": "recipients", "total_sent": "recipients",
    # delivered variants
    "total_delivered": "delivered",
    # open variants
    "unique_opens": "opens", "total_opens": "opens", "open_count": "opens",
    # click variants
    "unique_clicks": "clicks", "total_clicks": "clicks", "click_count": "clicks",
    # reply variants
    "reply_count": "replies", "total_replies": "replies",
    # unsub variants
    "unsubscribes": "unsubscribed", "total_unsubscribes": "unsubscribed",
    # format variants
    "format": "email_format", "email_type": "email_format",
    # cta variants
    "cta": "cta_type", "call_to_action": "cta_type", "link_type": "cta_type",
    # position variants
    "cta_loc": "cta_position", "link_position": "cta_position",
    # body variants
    "body": "body_text", "content": "body_text", "email_body": "body_text",
}

# Subject feature detection patterns
URGENCY_WORDS = re.compile(
    r'\b(urgent|hurry|expires|last.?chance|deadline|today.?only|limited|act.?now|ending.?soon|don.?t.?miss|closing|final.?hours|24.?hour|48.?hour)\b',
    re.IGNORECASE
)
CURIOSITY_WORDS = re.compile(
    r'\b(secret|reveals?|uncover|discover|truth|nobody|surprising|unexpected|hidden|wonder|you.?won.?t|bet you|weird|strange|shocking)\b',
    re.IGNORECASE
)
BENEFIT_WORDS = re.compile(
    r'\b(how.?to|ways? to|tips?|steps?|guide|blueprint|system|formula|strategy|strategy|proven|results?|boost|increase|grow|save|earn|free)\b',
    re.IGNORECASE
)


def _safe_int(val, default=0):
    try:
        return int(str(val).strip().replace(",", ""))
    except (ValueError, TypeError):
        return default


def _safe_float(val, default=None):
    try:
        s = str(val).strip().replace(",", "").replace("%", "")
        return float(s)
    except (ValueError, TypeError):
        return default


def _parse_datetime(val: str) -> Optional[datetime]:
    """Try several common datetime formats, return UTC-aware datetime or None."""
    if not val or not val.strip():
        return None
    val = val.strip()
    formats = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d",
        "%m/%d/%Y %H:%M:%S",
        "%m/%d/%Y %H:%M",
        "%m/%d/%Y",
        "%d/%m/%Y %H:%M:%S",
        "%d/%m/%Y",
        "%B %d, %Y %H:%M",
        "%b %d, %Y %H:%M",
        "%B %d, %Y",
        "%b %d, %Y",
    ]
    for fmt in formats:
        try:
            dt = datetime.strptime(val, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue
    return None


def _et_hour(dt: Optional[datetime]) -> int:
    """Return ET hour (UTC-5 approximation; no DST correction without pytz)."""
    if dt is None:
        return 0
    return (dt.hour - 5) % 24


def _et_dow(dt: Optional[datetime]) -> str:
    if dt is None:
        return "Unknown"
    return dt.strftime("%a")


def _et_date(dt: Optional[datetime]) -> str:
    if dt is None:
        return ""
    return dt.strftime("%Y-%m-%d")


def _word_count(text: str) -> int:
    return len(text.split()) if text else 0


def _detect_subject_features(subject: str) -> dict:
    """Return feature flags for a single subject string."""
    return {
        "question": "?" in subject,
        "brackets": bool(re.search(r'\[.*?\]', subject)),
        "emoji": any(unicodedata.category(c).startswith("So") or
                     unicodedata.category(c) == "Sm" or
                     ord(c) > 0x1F300 for c in subject),
        "number": bool(re.search(r'\d', subject)),
        "personalized": bool(re.search(r'\{[^}]+\}|{{[^}]+}}|\bhi\b|\bhey\b', subject, re.IGNORECASE)),
        "allcaps_word": bool(re.search(r'\b[A-Z]{2,}\b', subject)),
        "urgency": bool(URGENCY_WORDS.search(subject)),
        "curiosity": bool(CURIOSITY_WORDS.search(subject)),
        "benefit": bool(BENEFIT_WORDS.search(subject)),
    }


def _infer_cta_type(body: str) -> str:
    """Very rough CTA type inference from body text when not supplied."""
    if not body:
        return "none"
    if re.search(r'<button|class=["\']btn', body, re.IGNORECASE):
        return "button"
    if re.search(r'hit reply|reply (to this|back|now)', body, re.IGNORECASE):
        return "reply"
    if re.search(r'https?://\S+', body):
        return "bareurl" if not re.search(r'<a\s', body, re.IGNORECASE) else "textlink"
    return "none"


def _infer_cta_position(body: str, cta_type: str) -> str:
    """Infer position by looking at where the first actionable link/button is."""
    if not body or cta_type == "none":
        return "bottom"
    words = body.split()
    n = len(words)
    if n == 0:
        return "bottom"
    # Find position of URL or reply prompt
    first_link = -1
    for i, w in enumerate(words):
        if re.search(r'https?://', w) or re.search(r'hit reply|reply to this', w, re.IGNORECASE):
            first_link = i
            break
    if first_link < 0:
        return "bottom"
    ratio = first_link / max(n, 1)
    if ratio < 0.33:
        return "top"
    elif ratio < 0.67:
        return "middle"
    return "bottom"


def _length_band(length: int) -> str:
    if length <= 30:
        return "≤30"
    elif length <= 50:
        return "31–50"
    elif length <= 70:
        return "51–70"
    elif length <= 90:
        return "71–90"
    else:
        return "91+"


def _word_count_band(wc: int) -> str:
    if wc <= 100:
        return "≤100"
    elif wc <= 200:
        return "101–200"
    elif wc <= 400:
        return "201–400"
    else:
        return "401+"


def load_csv(path: str, column_map: Optional[dict] = None) -> dict:
    """
    Load a CSV file and return a partial EFI data dict.

    Args:
        path: Path to the CSV file.
        column_map: Optional {original_col: canonical_col} overrides.

    Returns:
        dict with keys:
          - broadcasts: list of broadcast dicts (EFI schema)
          - _csv_has_opens: bool
          - _csv_has_clicks: bool
          - _csv_has_revenue: bool (always False for CSV)
          - _csv_has_ga4: bool (always False for CSV)
    """
    aliases = dict(DEFAULT_ALIASES)
    if column_map:
        aliases.update(column_map)

    broadcasts = []
    with open(path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        # Required-column validation (fail loud — silent row-skipping would ship an empty dashboard)
        canon_fields = {aliases.get(c.strip().lower().replace(" ", "_"), c.strip().lower().replace(" ", "_"))
                        for c in (reader.fieldnames or [])}
        _missing = [c for c in ("subject", "send_time", "recipients") if c not in canon_fields]
        if _missing:
            raise ValueError(
                "Missing required column(s): %s. Your export needs at least subject, "
                "send_time, recipients (aliases like sent_at, broadcast_id are recognized). "
                "An 'id' column is optional — a sequential id is generated when absent."
                % ", ".join(_missing))
        for _row_idx, raw_row in enumerate(reader, start=1):
            # Normalise column names
            row = {}
            for k, v in raw_row.items():
                canon = aliases.get(k.strip().lower().replace(" ", "_"), k.strip().lower().replace(" ", "_"))
                row[canon] = (v or "").strip()

            # --- Core send metadata ---
            bid = row.get("id", "") or f"row-{_row_idx}"
            subject = row.get("subject", "")
            send_dt = _parse_datetime(row.get("send_time", ""))
            recipients = _safe_int(row.get("recipients", 0))
            if recipients == 0:
                continue  # skip rows with no recipient count

            delivered_raw = _safe_int(row.get("delivered", -1), default=-1)
            if delivered_raw < 0:
                # If delivered not supplied, assume full delivery (conservative)
                delivered = recipients
            else:
                delivered = delivered_raw

            delivered_rate = delivered / recipients if recipients > 0 else 0.0
            bounce_rate_raw = _safe_float(row.get("bounce_rate"))
            if bounce_rate_raw is not None:
                bounce_rate = bounce_rate_raw if bounce_rate_raw <= 1 else bounce_rate_raw / 100
            elif "bounce_count" in row:
                bc = _safe_int(row.get("bounce_count", 0))
                bounce_rate = bc / recipients if recipients > 0 else 0.0
            else:
                bounce_rate = 1.0 - delivered_rate

            # --- Opens / Clicks ---
            opens_raw = _safe_int(row.get("opens", -1), default=-1)
            clicks_raw = _safe_int(row.get("clicks", -1), default=-1)
            has_opens = opens_raw >= 0
            has_clicks = clicks_raw >= 0
            opens = opens_raw if has_opens else None
            clicks = clicks_raw if has_clicks else None

            open_rate = (opens / delivered) if (has_opens and delivered > 0) else None
            click_rate = (clicks / delivered) if (has_clicks and delivered > 0) else None

            # Some exports (e.g. ConvertKit) supply rates directly instead of counts.
            # If counts were absent but a canonical rate column was provided, use it
            # (accepts 0–1 fractions or 0–100 percentages) and back-derive the counts.
            if open_rate is None:
                _or = _safe_float(row.get("open_rate"))
                if _or is not None:
                    open_rate = _or if _or <= 1 else _or / 100.0
                    if delivered > 0:
                        opens = round(open_rate * delivered)
                        has_opens = True
            if click_rate is None:
                _cr = _safe_float(row.get("click_rate"))
                if _cr is not None:
                    click_rate = _cr if _cr <= 1 else _cr / 100.0
                    if delivered > 0:
                        clicks = round(click_rate * delivered)
                        has_clicks = True

            # --- Format & CTA ---
            fmt_raw = row.get("email_format", "").lower().strip()
            if "design" in fmt_raw or "html" in fmt_raw or "rich" in fmt_raw:
                email_format = "designed"
            elif "plain" in fmt_raw or "text" in fmt_raw:
                email_format = "plain-text"
            else:
                email_format = "plain-text"  # default

            cta_raw = row.get("cta_type", "").lower().strip()
            if cta_raw in ("button", "textlink", "bareurl", "reply", "none", ""):
                cta_type = cta_raw if cta_raw else "none"
            else:
                cta_type = _infer_cta_type(row.get("body_text", ""))
            if not cta_type:
                cta_type = "none"

            pos_raw = row.get("cta_position", "").lower().strip()
            if pos_raw in ("top", "middle", "bottom"):
                cta_position = pos_raw
            else:
                cta_position = _infer_cta_position(row.get("body_text", ""), cta_type)

            # --- Word count ---
            wc_raw = _safe_int(row.get("word_count", -1), default=-1)
            if wc_raw >= 0:
                wc = wc_raw
            else:
                wc = _word_count(row.get("body_text", ""))

            # --- Derived temporal fields ---
            send_epoch_ms = int(send_dt.timestamp() * 1000) if send_dt else 0
            send_date_et = _et_date(send_dt)
            send_dow_et = _et_dow(send_dt)
            send_hour_et = _et_hour(send_dt)

            broadcasts.append({
                "id": bid,
                "subject": subject,
                "send_date_et": send_date_et,
                "send_dow_et": send_dow_et,
                "send_hour_et": send_hour_et,
                "send_epoch_ms": send_epoch_ms,
                "recipients": recipients,
                "delivered": delivered,
                "delivered_rate": round(delivered_rate, 4),
                "bounce_rate": round(bounce_rate, 4),
                "cta_type": cta_type,
                "cta_position": cta_position,
                "email_format": email_format,
                "word_count": wc,
                "subject_len": len(subject),
                "open_rate": round(open_rate, 4) if open_rate is not None else None,
                "click_rate": round(click_rate, 4) if click_rate is not None else None,
                "opens": opens,
                "clicks": clicks,
                # Carry through extra fields for downstream adapters
                "_replies": _safe_int(row.get("replies", 0)),
                "_unsubscribed": _safe_int(row.get("unsubscribed", 0)),
            })

    has_opens = any(b["open_rate"] is not None for b in broadcasts)
    has_clicks = any(b["click_rate"] is not None for b in broadcasts)

    return {
        "broadcasts": broadcasts,
        "_csv_has_opens": has_opens,
        "_csv_has_clicks": has_clicks,
        "_csv_has_revenue": False,
        "_csv_has_ga4": False,
    }
