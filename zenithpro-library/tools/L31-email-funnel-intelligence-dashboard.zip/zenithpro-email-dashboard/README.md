# Email Funnel Intelligence Dashboard

Turn your email broadcast data into a self-contained intelligence dashboard — engagement, subject-line patterns, send timing, CTA performance, deliverability, buyer segments, and prioritized recommendations. One HTML file, openable anywhere.

---

## What This Does For You

Your ESP shows you opens and clicks one campaign at a time. What it doesn't show you: which subject-line patterns *consistently* win across your whole list, which send times your audience actually responds to, where your deliverability is quietly eroding, and which broadcasts drove buyers rather than just readers.

This tool reads your full broadcast export and maps it to a 294-field intelligence schema — subject-line NLP, send-timing distributions, format and CTA breakdowns, deliverability flags, and resend lift. From an email-only export it computes roughly 140 fields live; revenue, RFM buyer buckets, and GA4 attribution show a PENDING state until you connect those sources. Everything it can compute renders into one self-contained `dashboard.html`. No server, no login, no subscription. Works with **any ESP** via generic CSV, with native column-mapping for Mailchimp, Klaviyo, ActiveCampaign, ConvertKit, and GoHighLevel (CSV or live API).

**Honest by design:** the template ships with zero sample numbers. Every figure on your dashboard is computed from *your* file at generation time; anything your data can't support shows a PENDING state instead of a made-up value.

## What's in the box

```
zenithpro-email-dashboard/
├── SKILL.md                  # the skill — full usage for every data source
├── README.md                 # this file
├── generate.py               # CLI entry point
├── install.sh                # installs the skill into ~/.claude/skills/
├── adapters/                 # csv / esp (Mailchimp, Klaviyo, AC, ConvertKit) / ghl
├── templates/TEMPLATE.html   # UI skeleton (no data inside)
├── references/data-contract.md  # all 294 fields documented
├── sample-input/sample.csv   # synthetic 10-broadcast dry-run dataset
└── sample-output/dashboard.html # the dry-run rendered — open this first
```

**Open `sample-output/dashboard.html` first** to see what you're building. It's rendered from the synthetic sample dataset — not real campaign data.

## Installation

### Mac (Terminal)
```bash
cd <the unzipped zenithpro-email-dashboard folder>
bash install.sh
```
Installs to `~/.claude/skills/email-funnel-intelligence/`. Restart Claude Code, then in any session: "build my email funnel intelligence dashboard" invokes it.

### Windows
No installer needed — use `generate.py` directly (see Quick start). To use it as a Claude Code skill, copy this folder to `%USERPROFILE%\.claude\skills\email-funnel-intelligence\` and restart Claude Code.

## Quick start (60-second dry run)

```bash
python3 generate.py --source csv --input sample-input/sample.csv --output sample-output/dashboard.html
#  (Windows: python instead of python3)
```
Open the output in your browser. Then point it at your own export:

```bash
python3 generate.py --source csv --input /path/to/your-export.csv --output my-dashboard.html
```

Minimum columns: `subject`, `send_time`, `recipients` (an `id` is auto-generated if your export doesn't include one) — the adapter recognizes common aliases, and more columns unlock more cards. Full per-source instructions (ESP-native, GoHighLevel CSV, GoHighLevel live API) are in `SKILL.md`.

## Credentials (only for GHL live API mode)

CSV mode needs no credentials. For a live GoHighLevel pull, set env vars (never hardcode):
```bash
export GHL_API_KEY="your-location-api-key"
export GHL_LOCATION_ID="your-sub-account-location-id"
```
If absent, the generator prompts interactively. The live pull uses GHL's legacy v1 API — if it errors for your account, just use the CSV export instead. Details for Mailgun/GA4 enrichment are in `SKILL.md`.

## Troubleshooting

- **`python3: command not found` (Mac):** `brew install python3`. The CSV path is standard library only — nothing to pip install.
- **Windows:** use `python` instead of `python3`.
- **"Missing required column":** your export needs at least `subject`, `send_time`, `recipients` (`id` is optional — auto-generated when absent; aliases like `sent_at`, `broadcast_id` are recognized — see `adapters/csv_adapter.py` → `DEFAULT_ALIASES`).
- **A card says PENDING:** that card needs a data source you haven't connected (Stripe revenue, Mailgun, GA4). It's honest, not broken.
- **Send-hour metrics look shifted:** `send_time` is treated as UTC and rendered as ET (UTC-5, no DST). If your export uses local time, the hour-of-day cards shift by your offset.
- **GHL live pull fails:** check `pip install requests` and your two env vars; or just export the CSV from GHL instead.

## Requirements

- **Python 3** (standard library only for CSV mode; `requests` only for GHL live API)
- **Claude Code** only if you want it as a skill; `generate.py` works standalone

---

*Packaged by Strategic Profits for ZenithPro.*
