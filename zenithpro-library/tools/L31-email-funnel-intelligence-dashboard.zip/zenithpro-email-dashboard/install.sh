#!/usr/bin/env bash
# Email Funnel Intelligence — installer (Mac / Linux)
# Installs the skill into ~/.claude/skills/email-funnel-intelligence/
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="$HOME/.claude/skills/email-funnel-intelligence"
STAMP="$(date +%Y%m%d-%H%M%S)"

echo "Installing email-funnel-intelligence ..."

if [ -d "$DEST" ]; then
  read -r -p "  Skill already exists at $DEST. Overwrite (a backup is kept)? [y/N]: " ANSWER
  case "$ANSWER" in
    y|Y) mv "$DEST" "$DEST.bak-$STAMP"; echo "  (backup: $DEST.bak-$STAMP)";;
    *)   echo "  Aborted — kept your existing version."; exit 0;;
  esac
fi

mkdir -p "$DEST"
if command -v rsync >/dev/null 2>&1; then
  rsync -a --exclude '__pycache__/' --exclude '*.pyc' --exclude 'install.sh' "$SRC"/ "$DEST"/
else
  cp -R "$SRC"/* "$DEST"/
  rm -rf "$DEST/__pycache__" "$DEST/install.sh" 2>/dev/null || true
fi

echo "Verifying installation..."
FAIL=0
for path in "$DEST/SKILL.md" "$DEST/generate.py" "$DEST/templates/TEMPLATE.html" "$DEST/adapters/csv_adapter.py" "$DEST/sample-input/sample.csv"; do
  if [ -s "$path" ]; then echo "  PASS  $path"; else echo "  FAIL  $path"; FAIL=1; fi
done

if [ "$FAIL" -eq 0 ]; then
  echo ""
  echo "Installed. Next steps:"
  echo "  1. Restart Claude Code (so the skill is picked up)."
  echo "  2. Dry run:  cd \"$DEST\" && python3 generate.py --source csv --input sample-input/sample.csv --output /tmp/efi-test.html && (open /tmp/efi-test.html 2>/dev/null || xdg-open /tmp/efi-test.html)"
  echo "  3. Then point it at your own ESP export (see SKILL.md)."
else
  echo "!! Install incomplete — see FAIL lines above." >&2
  exit 1
fi
