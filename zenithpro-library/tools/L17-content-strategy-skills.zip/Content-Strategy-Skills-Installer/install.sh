#!/bin/bash
#
# Content Strategy Skills — Installer
# Installs 3 skills into your Claude Code environment
#
# Usage: Open Terminal, navigate to this folder, run:
#   chmod +x install.sh && ./install.sh
#

set -e

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BOLD='\033[1m'

echo ""
echo -e "${BLUE}${BOLD}================================================${NC}"
echo -e "${BLUE}${BOLD}  Content Strategy Skills — Installer${NC}"
echo -e "${BLUE}${BOLD}================================================${NC}"
echo ""
echo "  This installs 3 skills into Claude Code:"
echo "  1. Content Brand Journey  (/content-brand-journey)"
echo "  2. Content Machine        (/hormozi-content-machine)"
echo "  3. Viral Readiness Gate   (/viral-readiness-gate)"
echo ""

# Check if Claude directory exists
CLAUDE_DIR="$HOME/.claude"
SKILLS_DIR="$CLAUDE_DIR/skills"

if [ ! -d "$CLAUDE_DIR" ]; then
    echo -e "${YELLOW}Creating ~/.claude directory...${NC}"
    mkdir -p "$CLAUDE_DIR"
fi

if [ ! -d "$SKILLS_DIR" ]; then
    echo -e "${YELLOW}Creating ~/.claude/skills directory...${NC}"
    mkdir -p "$SKILLS_DIR"
fi

# Get the directory where this script lives
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# --- Skill 1: Content Brand Journey ---
echo -e "${BLUE}[1/3]${NC} Installing Content Brand Journey..."
SKILL1_DIR="$SKILLS_DIR/content-brand-journey"
mkdir -p "$SKILL1_DIR"
cp "$SCRIPT_DIR/1-Content-Brand-Journey-SKILL.md" "$SKILL1_DIR/SKILL.md"
echo -e "  ${GREEN}✓${NC} Installed to $SKILL1_DIR/SKILL.md"

# --- Skill 2: Content Machine ---
echo -e "${BLUE}[2/3]${NC} Installing Content Machine..."
SKILL2_DIR="$SKILLS_DIR/hormozi-content-machine"
mkdir -p "$SKILL2_DIR"
cp "$SCRIPT_DIR/2-Hormozi-Content-Machine-SKILL.md" "$SKILL2_DIR/SKILL.md"
echo -e "  ${GREEN}✓${NC} Installed to $SKILL2_DIR/SKILL.md"

# --- Skill 3: Viral Readiness Gate ---
echo -e "${BLUE}[3/3]${NC} Installing Viral Readiness Gate..."
SKILL3_DIR="$SKILLS_DIR/viral-readiness-gate"
mkdir -p "$SKILL3_DIR"
cp "$SCRIPT_DIR/3-Viral-Readiness-Gate.md" "$SKILL3_DIR/SKILL.md"
echo -e "  ${GREEN}✓${NC} Installed to $SKILL3_DIR/SKILL.md"

# --- Done ---
echo ""
echo -e "${GREEN}${BOLD}================================================${NC}"
echo -e "${GREEN}${BOLD}  Installation Complete!${NC}"
echo -e "${GREEN}${BOLD}================================================${NC}"
echo ""
echo "  Skills installed:"
echo -e "  ${GREEN}✓${NC} /content-brand-journey   — The 4 strategic questions"
echo -e "  ${GREEN}✓${NC} /hormozi-content-machine — Full 7-phase content system"
echo -e "  ${GREEN}✓${NC} /viral-readiness-gate    — Pre-production scoring gate"
echo ""
echo -e "  ${BOLD}How to use:${NC}"
echo "  1. Open Claude Code"
echo "  2. Type: /content-brand-journey    (run this FIRST)"
echo "  3. Type: /hormozi-content-machine  (run this SECOND)"
echo "  4. Type: /viral-readiness-gate     (score your Width ideas)"
echo ""
echo -e "  ${YELLOW}Note:${NC} You may need to restart Claude Code for skills to appear."
echo ""
