# Content Strategy Skills — Student Guide

## What This Is

A 3-skill content strategy system based on Caleb Rolston's methodology (the strategist behind Alex Hormozi's growth from 1.2M to 11.5M followers). Viral criteria sourced from MrBeast (7 strategy transcripts) and Paddy Galloway (9 YouTube strategy analyses).

| Skill | What It Does | Command |
|-------|-------------|---------|
| **Brand Journey** | Defines your strategic foundation — what you should be known for | `/content-brand-journey` |
| **Content Machine** | Builds the full operational system — where to post, how much, idea generation, tracking, scaling | `/hormozi-content-machine` |
| **Viral Readiness Gate** | Scores your best ideas through 4 tests before you invest in production | `/viral-readiness-gate` |

---

## Installation

### Option A: Automatic (Recommended)

1. Open **Terminal** (Applications → Utilities → Terminal)
2. Navigate to this folder:
   ```
   cd ~/Desktop/Content\ Skills\ for\ Students
   ```
3. Run the installer:
   ```
   chmod +x install.sh && ./install.sh
   ```
4. Restart Claude Code

### Option B: Manual

Copy each file to the right location:

```
~/.claude/skills/content-brand-journey/SKILL.md    ← Copy 1-Content-Brand-Journey-SKILL.md
~/.claude/skills/hormozi-content-machine/SKILL.md  ← Copy 2-Hormozi-Content-Machine-SKILL.md
~/.claude/skills/viral-readiness-gate/SKILL.md     ← Copy 3-Viral-Readiness-Gate.md
```

Restart Claude Code after copying.

---

## How to Use (The Flow)

```
Step 1: /content-brand-journey         ← WHO you are (run first, always)
            ↓ produces brand-journey.md
Step 2: /hormozi-content-machine       ← WHAT to create (reads your brand journey)
            ↓ produces platform map, volume plan, 50+ ideas (Mondo List)
Step 3: /viral-readiness-gate          ← WHICH ideas to produce (scores your best Width ideas)
            ↓ produces hook scripts, pacing plans, thumbnail concepts
        → PRODUCE the winners
            ↓
        → TRACK with Outlier/Multiplier system (Content Machine Phase 5)
            ↓
        → ACCORDION — contract to what works, expand again
```

---

## Step 1: Brand Journey (Run This First)

Type into Claude Code:
```
/content-brand-journey
```

Claude walks you through 4 questions, one at a time:

1. **What outcome do you want?** — The business result (not "get followers")
2. **What would you have to be known for?** — The specific association people need to have with you
3. **What would you have to DO?** — Actions and proof that build that association
4. **What do you have to LEARN?** — The gap between now and executing #3

Then it helps you define your content pillars (80% core expertise / 20% human interest).

**Output:** A `brand-journey.md` file saved to your working directory.

**Take your time here.** These answers become the filter for everything you create. Vague answers = vague content strategy.

---

## Step 2: Content Machine (Run This Second)

After completing your Brand Journey, type:
```
/hormozi-content-machine
```

This reads your Brand Journey and builds 7 phases:

1. **Width vs. Depth Classification** — Every piece gets ONE job: new eyeballs (Width) OR deeper trust (Depth)
2. **Platform Priority Map** — Which platforms, what order (Eye of Sauron method — one at a time)
3. **Accordion Method** — The expand/contract volume cycle. Volume = data acquisition, not vanity.
4. **Mondo List** — 50+ content ideas organized by pillar, each labeled Width/Depth with hook angles
5. **Data Tracking** — Outlier/Multiplier system. Report results as multipliers of your benchmark, not raw numbers.
6. **Content-to-Offer Bridge** — How content connects to revenue without hard-selling
7. **Team Building Roadmap** — When and who to hire (only when ready)

**Output:** A complete content operating system document.

---

## Step 3: Viral Readiness Gate (Score Your Best Ideas)

After the Content Machine produces your Mondo List, take your top Width ideas and type:
```
/viral-readiness-gate
```

Tell Claude which ideas you want scored. It runs each through **4 tests**:

### Test 1: The Idea Test (Is It Worth Producing?)
5 elimination filters — title length, thumbnailability, reach potential, growth vs. maintenance, proven format

### Test 2: The Packaging Test (Will People Click?)
Title checklist (7 criteria) + Thumbnail checklist (9 criteria) + 3 different thumbnail concepts per idea

### Test 3: The Retention Test (Will People Stay?)
Hook script (first 5-10 seconds written out), beat-by-beat pacing plan with timestamps, short-form specific scoring

### Test 4: The Growth vs. Maintenance Check
4 growth traits + maintenance red flag scan

**Verdict per idea:** PRODUCE / REWORK / KILL

**Output:** Scored ideas with full pre-production blueprints — hook scripts, pacing plans, thumbnail concepts, and a prioritized production order.

---

## Key Principles

- **The idea is 80% of the formula.** Invest in pre-production (the Viral Readiness Gate), not just filming and editing.
- **Volume is data acquisition.** Post more to learn faster what your audience values.
- **Quality is subjective.** Only your audience decides what's "good." Volume teaches you what they think is good.
- **Demonstrate, don't just talk.** Show yourself doing the thing. Skepticism is at an all-time high.
- **Start with Depth, not Width.** Build credibility with your core audience before chasing virality.
- **80% core / 20% human.** Be an expert AND a person.
- **Eye of Sauron.** Focus on ONE platform at a time. Optimize it. Then move to the next.
- **Don't consume competitor content for format ideas.** Look at other niches for innovation.
- **Report metrics as multipliers.** A video with 500 views when your average is 200 = 2.5x outlier. That's a massive signal.

---

## Troubleshooting

**"I don't know what I want to be known for"**
That's exactly what Question 2 in the Brand Journey helps you figure out. Start with Question 1 (your desired business outcome) and work backward.

**"I'm just starting out and don't have results yet"**
Share your learning journey. Frame content as: "This is what I'm learning. I'll update you in 3 months." Authenticity beats fake expertise.

**"I don't have time for 300 pieces a week"**
Start with 1 long-form piece per week. The Content Multiplication System turns that into 50+ derivative pieces. The Accordion Method starts wherever you are.

**"Which platform should I start with?"**
The Eye of Sauron method in Phase 2 helps you pick. Short answer: wherever your audience already is + whichever medium you're strongest in.

**"How do I know if an idea is worth producing?"**
Run it through the Viral Readiness Gate. If it passes all 4 tests = PRODUCE. If it fails 1-2 = REWORK. If it fails 3+ = KILL and pick a stronger idea.

**"The Content Machine feels overwhelming"**
You don't have to do all 7 phases at once. Start with Phase 1 (Width/Depth) and Phase 4 (Mondo List). Those two alone give you a content plan. Add the other phases as you grow.

---

## File Reference

| File | What It Is |
|------|-----------|
| `1-Content-Brand-Journey-SKILL.md` | Skill 1 — The 4 strategic questions |
| `2-Hormozi-Content-Machine-SKILL.md` | Skill 2 — Full 7-phase operational system |
| `3-Viral-Readiness-Gate.md` | Skill 3 — Pre-production scoring gate (4 tests) |
| `install.sh` | Automatic installer script |
| `STUDENT-INSTRUCTIONS.md` | This file |
