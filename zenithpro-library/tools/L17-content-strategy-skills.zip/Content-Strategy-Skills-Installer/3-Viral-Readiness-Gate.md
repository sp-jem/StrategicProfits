---
name: viral-readiness-gate
description: |
  Score content ideas through the full Viral Readiness Gate before investing in production. Based on verified criteria from MrBeast (7 strategy transcripts) and Paddy Galloway (9 YouTube strategy analyses). Use when the user says "viral readiness," "score this idea," "viral gate," "will this go viral," "pre-production check," "should I produce this," or "viral score."

  This skill scores individual content ideas through 4 tests: The Idea Test (5 filters), The Packaging Test (title + thumbnail), The Retention Test (hook + pacing + short-form), and The Growth vs. Maintenance Check.

  PREREQUISITE: The user should have completed `/content-brand-journey` and ideally `/hormozi-content-machine` Phase 4 (Mondo List) first. However, this gate can be run on any content idea — even ones not from the Mondo List.

  BEST USED: After generating ideas in the Content Machine, pull your top Width ideas and run them through this gate for full pre-production scoring including hook scripts, pacing plans, and 3 thumbnail concepts per idea.
version: 1.0.0
source: MrBeast (7 strategy transcripts) + Paddy Galloway (9 YouTube strategy analyses)
---

# Viral Readiness Gate

**Sources:** MrBeast (7 strategy transcripts) + Paddy Galloway (9 YouTube strategy analyses). All criteria below are directly sourced from these experts' verified statements.

**Run this on every content idea BEFORE investing in production.** The idea is 80% of the formula (Caleb Rolston). A mediocre idea with perfect execution won't go viral. A great idea with decent execution can.

This gate applies to ALL content but is especially critical for **Width** pieces (designed for new eyeballs). Depth content doesn't need to go viral — it needs to build trust.

---

## Test 1: The Idea Test (Is This Worth Producing?)

MrBeast: *"The idea determines the ceiling... spending 24 hours in a corner is just not as entertaining as spending 24 hours in a jail cell. The only difference there is the idea."*

Run every idea through these 5 elimination filters (synthesized from Paddy Galloway's elimination criteria and MrBeast's outlier/packaging advice):

| # | Filter | Pass | Fail |
|---|--------|------|------|
| 1 | **Can I title it in <50 characters?** If you can't package it, it's not a YouTube/content idea. (MrBeast: "above 50 characters... it goes dot dot dot") | Clear, short, compelling title comes easily | Title is vague, long, or requires explanation |
| 2 | **Can I thumbnail it?** Can you picture a simple, emotional, instantly understandable image? (MrBeast: "You want them to instantly be able to understand what you're conveying") | You can describe a clear thumbnail in one sentence | Can't picture what the thumbnail would be |
| 3 | **Could this reach [your view target]?** (Paddy: "Can this video get X views? If it can't, why are we making it?") | Realistic path to your benchmark multiplied by 2x+ | Only your existing audience would care |
| 4 | **Is it a GROWTH video or a MAINTENANCE video?** (Paddy's CCN model: Core/Casual/New viewers) | The subject is the CONCEPT, not you personally — interesting to someone who's never seen you | "If you don't know [the creator], why would you click?" |
| 5 | **Has something like this worked before?** (MrBeast: study outliers across niches; Paddy: "What are the 5-6 best performing videos on my channel? Could I make them again?") | You can point to outlier examples in your niche or adjacent niches | No evidence this format/topic gets traction |

**Gate:** Width content must pass ALL 5 filters. Depth content must pass filters 1 and 2.

**Enforcement:** If a Width idea fails ANY of the 5 filters, you MUST either reclassify it to Depth, suggest specific rework to fix the failing filters, or recommend killing it. Never greenlight a Width idea that fails filters.

---

## Test 2: The Packaging Test (Will People Click?)

MrBeast: *"If people are clicking your video more than they click other videos and they're watching it longer than they watch other videos... that's what YouTube wants."*

Paddy: *"YouTube is not a video platform — it's a packaging and strategy platform."*

### Title Checklist

- [ ] Under 50 characters (MrBeast) / under 60 characters (Paddy) — no truncation on mobile
- [ ] Uses simple language — "what would an Uber driver describe this as?" (Paddy). Run through readability test: a 7-8 year old should understand it
- [ ] Uses specific/odd numbers if applicable — "$295/day" not "$300/day" (Paddy: "something about it just feels more real")
- [ ] Uses strong/aggressive language — "broke" not "solved," "smashed" not "beat" (Paddy)
- [ ] Not confusing — "confusion doesn't make people want to click... they just click the video below it" (MrBeast)
- [ ] Intrinsically interesting — "do they HAVE to watch it? Is it so intrinsically interesting that it's going to bug them if they don't click it?" (MrBeast)
- [ ] More extreme opinion = higher CTR — but you MUST deliver in the video (MrBeast: "the more extreme you are, the more extreme you have to be in the video")

### Thumbnail Checklist

- [ ] 3 focus areas maximum — "there shouldn't be more than three things the viewer has to focus on" (Paddy)
- [ ] 4-5 words max of text, ideally less (Paddy + MrBeast)
- [ ] Passes the Glance Test — "quickly click between your thumbnail and a white screen, give yourself one second. Can I process this?" (Paddy)
- [ ] Simple, instantly understandable at any size — "if we zoom out on this image, it's still very easy to work out what's happening" (Paddy on MrBeast)
- [ ] Creates emotion — "you want them to feel some type of emotion" (MrBeast)
- [ ] The "Can't Sleep" Test — "if they don't click it they'll wonder when they're before they go to bed like what happened" (MrBeast)
- [ ] Contrasting colors grab the eye (Paddy on Ryan Trahan: "the bright orange of the jumpsuit heavily contrasts against the black background")
- [ ] Shows action, not posing — "imagine how boring this thumbnail would be if it was Ryan smiling and pointing at the room" (Paddy)
- [ ] Make 3 different thumbnail CONCEPTS per video, not variations of the same one (Paddy: "I'm talking about three different concepts")

**Gate:** Title must check 5+ of 7 boxes. Thumbnail must check 6+ of 9 boxes. If either fails, rework packaging before production.

---

## Test 3: The Retention Test (Will People Stay?)

MrBeast: *"The higher both [CTR and watch time] are combined, exponentially more the views are."*

Paddy's viral threshold: *"4+ minutes watch time, 50%+ retention, 10-20% CTR — you have a really good chance of going viral."*

### Hook / First 5-10 Seconds (THE most critical moment)

- [ ] Reaffirms the click — "the first thing he does is instantly reaffirm the click — he shows you pretty much the exact image in the thumbnail right away" (Paddy on Ryan Trahan)
- [ ] Matches then EXCEEDS expectations — "your title and thumbnail set expectations... assure them those expectations are being met... then blow their mind" (MrBeast)
- [ ] No fluff — no "welcome back," no off-topic setup, no unnecessary context (Paddy: "if there's any part of the video where you shouldn't be personal, it's the intro")
- [ ] Front-loads value — "lose only 20% in the first 30 seconds (ideal) vs 35% (typical bad) — that 15% difference is the difference between 2 million views and 10 million" (MrBeast)

### Hook Structures (from verified expert examples)

| Pattern | Example | Source |
|---------|---------|--------|
| **Open fast + establish scale + first challenge** | "Visual change every 1.1 seconds in opening. First challenge starts after 17 seconds." | Paddy analyzing MrBeast |
| **Reaffirm the click** | Show the exact thumbnail image immediately, then set stakes, then say why it matters | Paddy analyzing Ryan Trahan |
| **Cold open** | Jump straight into action, one-line explanation, then show highlights with unanswered questions | Paddy analyzing Airrack |
| **What, Why, How** | Explain what the video is about, give context for why, tell how it's going to go down | Paddy analyzing Mark Rober |
| **Subvert expectations** | "If I told you this guy was a YouTube genius, you'd probably laugh in my face" (over goofy footage) | Paddy's own MrBeast video |
| **Punch first, context later** | "I started a $200 million business in one week" — not a slow buildup | Paddy rewriting Noah Kagan |

### Structure / Pacing

- [ ] No dull moments — "remove every dull moment" (MrBeast). "Do people really need to see it?" (Paddy on Mark Rober)
- [ ] Payoff at the end — "if there's a low moment halfway through you're going to watch to the end because you want to see who wins" (MrBeast)
- [ ] Contributing humor, not distracting humor — "humor tied into the overall story" not "trying to make a funny moment out of a scene in the airport" (Paddy on Ryan Trahan)
- [ ] Pacing with camera cuts — "having a B-cam and a C-cam... three seconds in cutting — now it's more interesting even though it's essentially the same thing" (MrBeast)
- [ ] Don't over-explain — "try not to over-explain things" (MrBeast)
- [ ] Constant tension built in — "every few minutes he creates tension in the storyline with his challenges. This makes it hard to skip forward or leave" (Paddy on MrBeast)

### Short-Form Specific (TikTok/Reels/Shorts)

- [ ] First frame = thumbnail + intro — "literally what do you see at 0 seconds of your short" (YouTube Masterclass host, featuring MrBeast)
- [ ] Not just a shorter YouTube video — "fundamentally different content, not just shorter" (MrBeast)
- [ ] Epic production nobody else does for short-form — "no one on short form is doing it" (MrBeast on his TikTok strategy)

---

## Test 4: The Growth vs. Maintenance Check

Paddy: *"The huge dip he experienced was during a period where he was uploading back-to-back maintenance videos... switching to only making growth videos made it easier for Ryan to build serious momentum."*

### Growth Video Traits (from Paddy's Ryan Trahan analysis)
1. The subject is the CONCEPT, not the personality
2. It has broad interest — designed to be interesting to new viewers
3. It's in a challenge/story format that creates intrigue
4. It has novelty and shock value

### Maintenance Video Red Flags
- Vlog format completely focused on your life
- Language tailored for returning viewers only
- "If you don't know [the creator], why would you click?"
- Only appeals to core audience

**The ratio:** Paddy recommends "5 for the audience, 1 for me" (growth-heavy). At minimum, your Width content must be growth videos. If you're only making maintenance videos, your content won't reach new people no matter how good it is.

MrBeast: *"Every video should be the best video possible so someone can just watch a video and then watch the next and the next... YouTube could just recommend any of them."*

---

## How to Use This Gate

### Before Production
Run your content ideas through all 4 tests. For each idea, the verdict is:
- **PRODUCE** — Passes all tests for its type (Width or Depth)
- **REWORK** — Fails 1-2 tests but the core idea is strong. Fix the weak areas using the checklists above.
- **KILL** — Fails 3+ tests. Pick a stronger idea.

### After Publishing (The Feedback Loop)
Cross-reference your outlier content (2x+ performers) against these 4 tests. You'll discover which packaging patterns, hook structures, and content types YOUR audience responds to most. Double down on those.

MrBeast: *"There's literally in your analytics audience retention — you can see where people click off. Just go through your last 50 videos, write down where everyone clicked off and then just don't do those things again."*

### Key Benchmarks (Verified)
| Metric | Target | Source |
|--------|--------|--------|
| AVP (15-min video) | 60%+ | MrBeast |
| First 30-second drop-off | Under 20% (ideal) | MrBeast |
| Overall retention | 40%+ is good; 50%+ is viral territory | Paddy Galloway |
| Watch time | 4+ minutes | Paddy Galloway |
| CTR | 10-20% for viral potential | Paddy Galloway |
| Title length | Under 50 characters | MrBeast + Paddy |
| Thumbnail text | 4-5 words max | Paddy + MrBeast |
| Thumbnail focus areas | 3 max | Paddy Galloway |

---

*Sourced from MrBeast (7 strategy transcripts) and Paddy Galloway (9 YouTube strategy analyses). Zero fabricated criteria.*
