---
name: hormozi-content-machine
description: |
  Build the full operational content system using Caleb Rolston's methodology (the strategist behind Alex Hormozi's growth from 1.2M to 11.5M followers and GaryVee's TikTok from 300K to 3.5M). Use when the user says "content machine," "scale content," "content calendar," "build my content system," "content plan," "platform strategy," or "accordion method."

  PREREQUISITE: The user must have completed `/content-brand-journey` first. This skill reads the Brand Journey output (brand-journey.md) as its strategic foundation. If no Brand Journey exists, tell the user to run `/content-brand-journey` first.

  Do NOT trigger for: the 4 Questions / brand positioning (use content-brand-journey), content multiplication/repurposing of existing pieces (use content-multiplier), SPCL influence scoring (use hormozi-spcl-content-audit), ZenithPro content sprints (use zenithpro-content-engine), or Rich/SP weekly content (use content-engine-rich).
version: 1.0.0
source: Caleb Rolston interview (Jay Clouse) — "Meet the Secret Strategist Behind Alex Hormozi and GaryVee"
---

# Content Machine

**Based on:** Caleb Rolston's methodology — content employee #1 at Acquisition.com, architect of Hormozi's content growth (1.2M to 11.5M followers), grew GaryVee's TikTok from 300K to 3.5M in 3 months.

**Source transcript:** `references/caleb-rolston-transcript.md`

**Prerequisite:** Brand Journey document (`brand-journey.md`) — produced by `/content-brand-journey`

---

## Step 0: Load the Brand Journey

**Before doing anything else**, search for and read the user's `brand-journey.md` file. Look in:
1. The current working directory
2. Common locations (Downloads, Desktop, Documents)
3. Ask the user for the path if not found

If no Brand Journey exists, STOP and say:

> "The Content Machine builds on your Brand Journey — that's the strategic foundation (what you want to be known for, your content pillars, your 80/20 mix). Run `/content-brand-journey` first, then come back here."

### Parse the YAML Frontmatter

The Brand Journey file contains structured YAML frontmatter. Extract and hold these fields for use in every phase:

```yaml
---
type: brand-journey
desired_outcome: ...    # What they want to achieve
known_for: ...          # What they want to be known for (Q2 answer)
must_demonstrate: ...   # What they must show to be seen as that
must_learn: ...         # What the audience must learn from them
core_pillars: [...]     # Their content pillars (topics)
human_pillars: [...]    # Their human/personal pillars (relatability)
---
```

**Field usage throughout phases:**
- `known_for` — anchor for ALL content recommendations. Every phase output must connect back to this.
- `core_pillars` — drive idea generation (Phase 4), content classification (Phase 1), and platform format choices (Phase 2).
- `human_pillars` — inform Depth content and behind-the-scenes recommendations.
- `must_demonstrate` — guide Width content strategy and proof-based content.
- `must_learn` — shape educational content and the content-to-offer bridge (Phase 6).
- `desired_outcome` — keep the entire system aligned to the business goal, not just content vanity metrics.

**In every phase output, connect recommendations back to the user's `known_for` and `core_pillars` values.** Do not produce generic advice — everything must be filtered through these fields.

### Post-Phase Brand Journey Audit (Run After EVERY Phase Output)

Before delivering any phase output, audit it against the Brand Journey:

1. Read through every recommendation/idea in your output
2. For each one, verify it specifically connects to the user's `known_for`, a `core_pillar`, or a `human_pillar`
3. Flag any recommendation that could apply to ANY brand, not specifically THIS brand — if it fails the "Could this have come from a generic content strategy template?" test, rewrite it
4. Replace generic recommendations with ones that reference the user's specific field, tools, audience, or expertise
5. Confirm the output uses the user's actual `known_for` language, not paraphrased versions

**This audit is mandatory. Do not deliver phase outputs that contain generic advice.**

---

## Purpose

Build the full operational content system from the user's Brand Journey. This is the HOW — platform selection, volume management, idea generation, data tracking, team building, and content-to-offer strategy.

**What this produces:**
1. Platform Priority Map (where to focus)
2. Content Operating Rhythm (the Accordion Method — volume/quality management)
3. Content Classification System (Width vs. Depth labeling)
4. Idea Generation System (the Mondo List + 80% rule)
5. Data Tracking System (Outlier/Multiplier method)
6. Cross-Platform Repackaging Strategy
7. Content-to-Offer Bridge
8. Team Building Roadmap (when ready)

---

## When to Use This Skill

- You've completed your Brand Journey and need the operational system
- Scaling content production systematically
- Deciding platform priorities
- Setting up data tracking and measurement
- Building a content team
- Bridging content to offers

**Prerequisite:** `/content-brand-journey` must be completed first.

---

## Phase 1: Width vs. Depth Classification

**Every piece of content should have ONE objective. Label it before production.**

| Type | Purpose | Audience | Success Metric |
|------|---------|----------|----------------|
| **Width** | Maximum awareness, new eyeballs | People who don't know you yet | Reach, impressions, new followers |
| **Depth** | Deeper trust and connection | Existing audience | Watch time, comments, saves, DMs |

**You cannot accomplish both in a single piece.** Trying to do both produces mediocre results on both dimensions.

**Critical sequencing:** Start with DEPTH content, not width.
- Establish yourself as a true subject matter expert first
- If you start with width (viral-bait content), you attract an audience that wants more of that, trapping yourself
- Build a strong foundation with your core audience first, then expand

**Vlogs and demonstrations = depth plays.** Won't get millions of views, but they establish a competitive moat because skepticism is at an all-time high. "A lot of people are sitting on their couch talking to a camera telling you about things" — demonstrating expertise is the differentiator.

### Output: Content Classification Table

After discussing with the user, produce this table for their first 10 content ideas (from existing content or brainstormed together). Connect each label back to their `known_for` and `core_pillars`.

```
## Width vs. Depth Classification

Known for: [from brand-journey.md]

| # | Content Idea | Type | Why | Pillar | Success Metric |
|---|-------------|------|-----|--------|----------------|
| 1 | [idea] | Width / Depth | [rationale] | [which core_pillar] | [specific metric] |
| 2 | ... | ... | ... | ... | ... |
| ... | ... | ... | ... | ... | ... |
| 10 | ... | ... | ... | ... | ... |

**Recommended starting mix:** [X] Depth / [Y] Width (start depth-heavy)
**Reasoning:** [Why this ratio fits their current stage and known_for]
```

---

## Phase 2: Platform Priority (Eye of Sauron)

### Step 1: Identify Your Best Medium

Four content mediums: **Video, Audio, Graphic/Visual, Written.** Pick the one you show up best in. Video is highest leverage if you can do it.

### Step 2: Pick Your Top 3 + Maintenance 3

| Tier | Platforms | Treatment |
|------|-----------|-----------|
| **Priority (Top 3)** | Dedicated, original content creation | Full effort |
| **Maintenance (Next 3)** | Repost/repackage from priority platforms | Minimal effort |

### Step 3: Eye of Sauron Sequencing

1. Focus on **ONE platform** at a time — optimize it
2. Don't allocate more than **15-20% of effort** to other platforms while optimizing
3. Once optimized, put it on **maintenance mode**
4. Move the Eye of Sauron to the **next platform**
5. Repeat

**If the user wants to focus on everything at once:** Push back directly. "I hear you — being everywhere feels safer. But the Eye of Sauron principle exists because splitting focus means you never optimize anywhere. Pick ONE to master first. Once it's working, we'll expand." Then produce the template which forces prioritization.

### Step 4: Cross-Platform Repackaging

**Show up contextually to the environment.** Don't repost the same content — repackage for the platform.

The escalation pattern:
1. A quote/idea performs well on one platform (e.g., Twitter)
2. Repackage it as a visual for another (e.g., print the quote, photograph it → Instagram)
3. Use it as a hook for short-form video where you expand on the story
4. If there's enough depth, create long-form (YouTube)

**Platform penalty warning:** Platforms actively penalize exact re-uploads. Either re-edit or refilm. Don't just repost the same video file.

### Platform Specificity Requirement

When recommending platforms, explain specifically WHY each platform serves this user's `known_for` — not just "good for tutorials" but connect to their actual expertise. Example: if `known_for` is "AI-powered productivity systems," then "YouTube long-form is ideal because AI workflow demonstrations require screen recordings and step-by-step walkthroughs, which is your core_pillar of AI automation" — not just "YouTube is good for educational content."

### Output: Platform Priority Map

After discussing the user's best medium, current platforms, and goals, fill in this map completely — no blanks. Connect platform choices to their `core_pillars` and `known_for`.

```
## Platform Priority Map

Known for: [from brand-journey.md]
Best medium: [Video / Audio / Visual / Written]

### Eye of Sauron Order
1. [Platform] — Optimizing NOW — [Why this is #1 for their known_for]
2. [Platform] — Next — [Why]
3. [Platform] — After that — [Why]

### Priority Platforms (Original Content)
1. [Platform] — [Format (e.g., long-form video, carousel, thread)] — [How it serves their core_pillars]
2. [Platform] — [Format] — [How it serves their core_pillars]
3. [Platform] — [Format] — [How it serves their core_pillars]

### Maintenance Platforms (Repackage)
4. [Platform] — Repackage from [source platform] — [format adaptation]
5. [Platform] — Repackage from [source platform] — [format adaptation]
6. [Platform] — Repackage from [source platform] — [format adaptation]

### Repackaging Flow
[Source format] on [Platform 1] → [Adapted format] on [Platform 4]
[Source format] on [Platform 2] → [Adapted format] on [Platform 5]
[Source format] on [Platform 3] → [Adapted format] on [Platform 6]
```

---

## Phase 3: The Accordion Method (Volume Management)

This is the core operational methodology. It replaces "post consistently" with a data-driven expand/contract cycle.

### The Cycle

**1. EXPAND — High Volume Output**
- Start with high volume (top creators do 300+ pieces/week across all platforms including tweets, stories, reels, shorts, long-form, LinkedIn posts)
- Volume is NOT about "showing up everywhere" — it is a **data acquisition strategy**
- The more you publish, the faster you learn what your audience deems quality
- Quality is subjective — only the audience determines it
- The beautiful byproduct of volume is omnipresence, but the INTENT is learning

**2. MEASURE — Identify Signals**
- Even small differences matter: if most videos get 199 views and one gets 413, that IS the signal
- Study top performers — what do they have in common?
- Use the Outlier/Multiplier tracking system (Phase 5)

**3. CONTRACT — Focus on What Works**
- After ~2 months of high volume, identify top performers
- Take the same effort you were putting into 14 posts and focus it into 7 posts that align with what worked
- **"Reduce the volume and increase the effort per piece"** (NOT "reduce volume, increase quality" — quality is subjective)

**4. MONITOR — Watch the Metrics**
- If volume goes up and engagement/impressions go DOWN → you're not doing it correctly
- Reduce volume and increase effort per piece
- The accordion should produce: fewer pieces, each getting more traction

**5. REPEAT**
- This expand/contract cycle continues indefinitely
- Each cycle refines your understanding of what your audience values

### Low-Capacity Adaptation (< 5 pieces/week)

If the user can produce fewer than 5 original pieces per week:
- The EXPAND phase means maximizing within their capacity, not matching 300+/week benchmarks. The 300+ number is the ceiling for top creators, not the floor.
- Focus the EXPAND phase on format/topic experimentation rather than raw volume
- Extend the measurement period from 4 weeks to 8-12 weeks (less data = longer to identify signals)
- Emphasize the Content Multiplication System below — their 1 original piece should generate 5-10 derivative pieces minimum
- Their Accordion cycle: maintain capacity for 8-12 weeks → identify what resonated → CONTRACT by shifting effort toward what worked (not necessarily reducing volume, since they're already low)

### The Content Multiplication System

Create once, distribute everywhere:

```
1 Long-Form Piece (Video/Podcast)
    ↓
5-10 Short-Form Clips
    ↓
10-20 Quote Graphics
    ↓
5-10 Text Posts (platform-native)
    ↓
1 Email / Newsletter
    ↓
1 Blog Post
```

| If You Create | You Get |
|---------------|---------|
| 1 long-form piece/week | 50+ content pieces |
| 2 long-form pieces/week | 100+ content pieces |
| 3 long-form pieces/week | 150+ content pieces |

### Output: Week 1-4 Volume Plan

After discussing the user's current capacity, schedule, and platforms, produce a specific volume plan for the first Accordion cycle. Numbers should be realistic for their situation, not aspirational.

```
## Week 1-4 Volume Plan (EXPAND Phase)

Known for: [from brand-journey.md]
Current capacity: [solo / with help / team of X]
Eye of Sauron platform: [from Phase 2]

### Weekly Production Targets
| Content Type | Platform | Qty/Week | Width or Depth | Pillar Focus |
|-------------|----------|----------|----------------|--------------|
| [e.g., Short-form video] | [e.g., YouTube Shorts] | [e.g., 5] | [Mix] | [which core_pillar(s)] |
| [e.g., Carousel] | [e.g., Instagram] | [e.g., 3] | [Mix] | [which core_pillar(s)] |
| [e.g., Thread/post] | [e.g., LinkedIn] | [e.g., 3] | [Mix] | [which core_pillar(s)] |
| ... | ... | ... | ... | ... |

**Total pieces/week:** [X]
**Total pieces across 4 weeks:** [Y]

### Recording Schedule
[Day/time blocks for batch creation]

### Week 5 Decision Point
After 4 weeks of EXPAND, review data (Phase 5) and CONTRACT:
- Cut bottom [X]% of content types
- Double down on top performers
- Reduce to [Y] pieces/week with higher effort per piece
```

---

## Phase 4: Idea Generation System

### The 80% Rule

**"The idea is a minimum of 80% of the formula. Ideas are where you win, not in the filming or editing."**

Most people don't put enough effort into the idea. Pre-production is where the emphasis should be.

### The Mondo List

Keep a running list of 200+ content ideas. Never run out.

**Idea Sources:**
- Questions you get asked
- Comments on your content
- Competitor content (do it better)
- Industry news
- Your own journey/stories
- Customer/client success stories
- Mistakes you've made
- Things you've learned

**Content Idea Categories:**

| Category | Example |
|----------|---------|
| How-to | Step-by-step tutorials |
| Mistakes | Common errors to avoid |
| Myths | Misconceptions to debunk |
| Stories | Personal experiences |
| Case studies | Customer transformations |
| Comparisons | X vs. Y |
| Lists | X things to do/know |
| Predictions | What's coming |
| Behind-the-scenes | How you work |
| Opinions | Hot takes |

### Repetition Strategy

You must be comfortable saying the same core concepts over and over in different ways. **Stories are the key** — they allow you to share the same concept in many different scenarios.

You're probably sharing 4-5 core principles, but how your audience/clients put those principles into action is totally different (especially cross-industry). Document those stories: client success stories, community member results, different applications of the same principle.

### "Document, Don't Create" (Properly Understood)

This doesn't just mean having a videographer follow you. It means documenting the stories you're living — client transformations, community wins, process demonstrations.

### Outside-the-Fishbowl Innovation

**Do NOT consume content from competitors in your space for format ideas.**
- Look at other niches for format innovation (e.g., video game creators for packaging formats)
- If you consume content in your industry, consume OLD content (books) for concepts, not current creators
- The people driving innovation ignore their own space and look elsewhere
- If you model after the top dog in your space, you'll always be #2 at best

### For Beginners Without Track Record

If you haven't done the thing yet but want to create content:
- Share your **unique perspective on how you are going about learning the thing**
- You're not the master yet, so share the journey of becoming the master
- Share mistakes and help others avoid them
- Share what works when you learn it
- Frame as: "This is what I'm learning. This is what I'm seeing right now. I'll update you in 3 months to let you know if it was effective"
- Less posturing as an expert, more being vulnerable as an expert learner

### Specificity Requirement

Every Mondo List idea must include at least one of:
- A specific tool, workflow, method, or system the user actually uses or teaches
- A specific aspect of the user's demonstrated expertise (not general category knowledge)
- A specific client/audience scenario surfaced during the conversational intake

Generic ideas like "5 tips for productivity" are NOT allowed — it must be specific to this person's `known_for`. Example: if `known_for` is "AI-powered productivity systems," then "5 AI Workflows I Built This Month That Save 20+ Hours" passes; "5 Productivity Tips" does not.

### Output: Mondo List (50+ Ideas)

After discussing the user's expertise, stories, and audience questions, produce an organized Mondo List. Every idea must map to a `core_pillar` or `human_pillar` from their Brand Journey.

```
## Mondo List — Content Ideas

Known for: [from brand-journey.md]
Core pillars: [list from brand-journey.md]
Human pillars: [list from brand-journey.md]

### [Core Pillar 1 Name]
| # | Idea | Category | Width/Depth | Hook Angle |
|---|------|----------|-------------|------------|
| 1 | [idea] | [How-to / Myth / Story / etc.] | [W/D] | [1-line hook] |
| 2 | ... | ... | ... | ... |
| ... (10-15 ideas per pillar) |

### [Core Pillar 2 Name]
| # | Idea | Category | Width/Depth | Hook Angle |
|---|------|----------|-------------|------------|
| ... |

### [Core Pillar 3 Name]
| ... |

### [Human Pillar Ideas] (Behind-the-scenes, journey, personality)
| # | Idea | Category | Width/Depth | Hook Angle |
|---|------|----------|-------------|------------|
| ... (5-10 ideas) |

### Outside-the-Fishbowl Format Ideas
[3-5 format innovations borrowed from OTHER niches, with specific examples]

**Total ideas:** [50+]
**Repetition strategy:** [2-3 core concepts that can be told through multiple stories]
```

---

## Viral Readiness Gate

**Sources:** MrBeast (7 strategy transcripts) + Paddy Galloway (9 YouTube strategy analyses). All criteria below are directly sourced from these experts' verified statements. Reference files: `references/viral-experts/mrbeast-frameworks-extracted.md` and `references/viral-experts/paddy-galloway-frameworks-extracted.md`

**Run this on every content idea BEFORE investing in production.** The idea is 80% of the formula (Caleb Rolston). A mediocre idea with perfect execution won't go viral. A great idea with decent execution can.

This gate applies to ALL content but is especially critical for **Width** pieces. Depth content doesn't need to go viral — it needs to build trust.

---

### Test 1: The Idea Test (Is This Worth Producing?)

MrBeast: *"The idea determines the ceiling... spending 24 hours in a corner is just not as entertaining as spending 24 hours in a jail cell. The only difference there is the idea."*

Run every idea through these 5 elimination filters (synthesized from Paddy Galloway's elimination criteria and MrBeast's outlier/packaging advice):

| # | Filter | Pass | Fail |
|---|--------|------|------|
| 1 | **Can I title it in <50 characters?** If you can't package it, it's not a YouTube/content idea. (MrBeast: "above 50 characters... it goes dot dot dot") | Clear, short, compelling title comes easily | Title is vague, long, or requires explanation |
| 2 | **Can I thumbnail it?** Can you picture a simple, emotional, instantly understandable image? (MrBeast: "You want them to instantly be able to understand what you're conveying") | You can describe a clear thumbnail in one sentence | Can't picture what the thumbnail would be |
| 3 | **Could this reach [your view target]?** (Paddy: "Can this video get X views? If it can't, why are we making it?") | Realistic path to your benchmark multiplied by 2x+ | Only your existing audience would care |
| 4 | **Is it a GROWTH video or a MAINTENANCE video?** (Paddy's CCN model: Core/Casual/New viewers) | The subject is the CONCEPT, not you personally — interesting to someone who's never seen you | "If you don't know [the creator], why would you click?" |
| 5 | **Has something like this worked before?** (MrBeast: study outliers across niches; Paddy: "What are the 5-6 best performing videos on my channel? Could I make them again?") | You can point to outlier examples in your niche or adjacent niches | No evidence this format/topic gets traction |

**Gate:** Width content must pass ALL 5 filters. Depth content must pass filters 1 and 2.

**Enforcement:** If a Width idea fails ANY of the 5 filters, you MUST either reclassify it to Depth, suggest specific rework to fix the failing filters, or recommend killing it. Never greenlight a Width idea that fails filters.

---

### Test 2: The Packaging Test (Will People Click?)

MrBeast: *"If people are clicking your video more than they click other videos and they're watching it longer than they watch other videos... that's what YouTube wants."*

Paddy: *"YouTube is not a video platform — it's a packaging and strategy platform."*

**Title Checklist:**

- [ ] Under 50 characters (MrBeast) / under 60 characters (Paddy) — no truncation on mobile
- [ ] Uses simple language — "what would an Uber driver describe this as?" (Paddy). Run through readability test: a 7-8 year old should understand it
- [ ] Uses specific/odd numbers if applicable — "$295/day" not "$300/day" (Paddy: "something about it just feels more real")
- [ ] Uses strong/aggressive language — "broke" not "solved," "smashed" not "beat" (Paddy)
- [ ] Not confusing — "confusion doesn't make people want to click... they just click the video below it" (MrBeast)
- [ ] Intrinsically interesting — "do they HAVE to watch it? Is it so intrinsically interesting that it's going to bug them if they don't click it?" (MrBeast)
- [ ] More extreme opinion = higher CTR — but you MUST deliver in the video (MrBeast: "the more extreme you are, the more extreme you have to be in the video")

**Thumbnail Checklist:**

- [ ] 3 focus areas maximum — "there shouldn't be more than three things the viewer has to focus on" (Paddy)
- [ ] 4-5 words max of text, ideally less (Paddy + MrBeast)
- [ ] Passes the Glance Test — "quickly click between your thumbnail and a white screen, give yourself one second. Can I process this?" (Paddy)
- [ ] Simple, instantly understandable at any size — "if we zoom out on this image, it's still very easy to work out what's happening" (Paddy on MrBeast)
- [ ] Creates emotion — "you want them to feel some type of emotion" (MrBeast)
- [ ] The "Can't Sleep" Test — "if they don't click it they'll wonder when they're before they go to bed like what happened" (MrBeast)
- [ ] Contrasting colors grab the eye (Paddy on Ryan Trahan: "the bright orange of the jumpsuit heavily contrasts against the black background")
- [ ] Shows action, not posing — "imagine how boring this thumbnail would be if it was Ryan smiling and pointing at the room" (Paddy)
- [ ] Make 3 different thumbnail CONCEPTS per video, not variations of the same one (Paddy: "I'm talking about three different concepts")

**Gate:** Title must check 5+ of 7 boxes. Thumbnail must check 6+ of 9 boxes. If either fails, rework packaging before production.

---

### Test 3: The Retention Test (Will People Stay?)

MrBeast: *"The higher both [CTR and watch time] are combined, exponentially more the views are."*

Paddy's viral threshold: *"4+ minutes watch time, 50%+ retention, 10-20% CTR — you have a really good chance of going viral."*

**Hook / First 5-10 Seconds (THE most critical moment):**

- [ ] Reaffirms the click — "the first thing he does is instantly reaffirm the click — he shows you pretty much the exact image in the thumbnail right away" (Paddy on Ryan Trahan)
- [ ] Matches then EXCEEDS expectations — "your title and thumbnail set expectations... assure them those expectations are being met... then blow their mind" (MrBeast)
- [ ] No fluff — no "welcome back," no off-topic setup, no unnecessary context (Paddy: "if there's any part of the video where you shouldn't be personal, it's the intro")
- [ ] Front-loads value — "lose only 20% in the first 30 seconds (ideal) vs 35% (typical bad) — that 15% difference is the difference between 2 million views and 10 million" (MrBeast)

**Hook Structures (from verified expert examples):**

| Pattern | Example | Source |
|---------|---------|--------|
| **Open fast + establish scale + first challenge** | "Visual change every 1.1 seconds in opening. First challenge starts after 17 seconds." | Paddy analyzing MrBeast |
| **Reaffirm the click** | Show the exact thumbnail image immediately, then set stakes, then say why it matters | Paddy analyzing Ryan Trahan |
| **Cold open** | Jump straight into action, one-line explanation, then show highlights with unanswered questions | Paddy analyzing Airrack |
| **What, Why, How** | Explain what the video is about, give context for why, tell how it's going to go down | Paddy analyzing Mark Rober |
| **Subvert expectations** | "If I told you this guy was a YouTube genius, you'd probably laugh in my face" (over goofy footage) | Paddy's own MrBeast video |
| **Punch first, context later** | "I started a $200 million business in one week" — not a slow buildup | Paddy rewriting Noah Kagan |

**Structure / Pacing:**

- [ ] No dull moments — "remove every dull moment" (MrBeast). "Do people really need to see it?" (Paddy on Mark Rober)
- [ ] Payoff at the end — "if there's a low moment halfway through you're going to watch to the end because you want to see who wins" (MrBeast)
- [ ] Contributing humor, not distracting humor — "humor tied into the overall story" not "trying to make a funny moment out of a scene in the airport" (Paddy on Ryan Trahan)
- [ ] Pacing with camera cuts — "having a B-cam and a C-cam... three seconds in cutting — now it's more interesting even though it's essentially the same thing" (MrBeast)
- [ ] Don't over-explain — "try not to over-explain things" (MrBeast)
- [ ] Constant tension built in — "every few minutes he creates tension in the storyline with his challenges. This makes it hard to skip forward or leave" (Paddy on MrBeast)

**Short-Form Specific (TikTok/Reels/Shorts):**

- [ ] First frame = thumbnail + intro — "literally what do you see at 0 seconds of your short" (YouTube Masterclass host, featuring MrBeast)
- [ ] Not just a shorter YouTube video — "fundamentally different content, not just shorter" (MrBeast)
- [ ] Epic production nobody else does for short-form — "no one on short form is doing it" (MrBeast on his TikTok strategy)

---

### Test 4: The Growth vs. Maintenance Check

Paddy: *"The huge dip he experienced was during a period where he was uploading back-to-back maintenance videos... switching to only making growth videos made it easier for Ryan to build serious momentum."*

**Growth Video Traits** (from Paddy's Ryan Trahan analysis):
1. The subject is the CONCEPT, not the personality
2. It has broad interest — designed to be interesting to new viewers
3. It's in a challenge/story format that creates intrigue
4. It has novelty and shock value

**Maintenance Video Red Flags:**
- Vlog format completely focused on your life
- Language tailored for returning viewers only
- "If you don't know [the creator], why would you click?"
- Only appeals to core audience

**The ratio:** Paddy recommends "5 for the audience, 1 for me" (growth-heavy). At minimum, your Width content must be growth videos. If you're only making maintenance videos, your content won't reach new people no matter how good it is.

MrBeast: *"Every video should be the best video possible so someone can just watch a video and then watch the next and the next... YouTube could just recommend any of them."*

---

### Output: Viral Readiness Scorecard

Run the top 10 ideas from the Mondo List (Phase 4) through all 4 tests. Width content that fails gets reworked or reclassified.

```
## Viral Readiness Scorecard

Known for: [from brand-journey.md]
Platform: [Eye of Sauron platform from Phase 2]

| # | Content Idea | W/D | Idea Test (5 filters) | Packaging Test (Title + Thumb) | Retention Test (Hook + Structure) | Growth Check | Verdict |
|---|-------------|-----|-----------------------|-------------------------------|----------------------------------|-------------|---------|
| 1 | [idea] | W | [X/5 pass] | Title: [X/7] Thumb: [X/9] | Hook: [Y/N] Structure: [Y/N] | Growth / Maint | PRODUCE / REWORK / KILL |
| 2 | [idea] | W | [X/5 pass] | Title: [X/7] Thumb: [X/9] | Hook: [Y/N] Structure: [Y/N] | Growth / Maint | PRODUCE / REWORK / KILL |
| 3 | [idea] | D | [X/5 pass] | Title: [X/7] Thumb: [X/9] | Hook: [Y/N] Structure: [Y/N] | N/A (depth) | PRODUCE / REWORK / KILL |
| ... |

### Thresholds
- **Width:** Must pass ALL 5 idea filters + Title 5/7 + Thumbnail 6/9 + Hook checks + Growth video
- **Depth:** Must pass Idea filters 1-2 + Title 5/7 + Thumbnail 6/9 + Hook checks

### Top 3 Ideas to Produce First
1. [Idea] — Passed all tests — Strongest signal: [what makes this undeniable]
2. [Idea] — Passed all tests — Strongest signal: [what makes this undeniable]
3. [Idea] — Passed all tests — Strongest signal: [what makes this undeniable]

### Ideas to Rework Before Production
- [Idea] — Failed: [which test] — Fix: [specific action from the checklists above]

### Ideas Reclassified to Depth
- [Idea] — Reason: [maintenance video traits / too narrow for new viewers]

### Ideas to Kill
- [Idea] — Reason: [can't title it / no evidence of traction / no clear thumbnail]
```

### After the Accordion MEASURE Phase

Cross-reference your outlier content (2x+ performers from Phase 5 tracking) against these 4 tests. You'll discover which packaging patterns, hook structures, and content types YOUR audience responds to most. Double down on those.

MrBeast: *"There's literally in your analytics audience retention — you can see where people click off. Just go through your last 50 videos, write down where everyone clicked off and then just don't do those things again."*

---

## Phase 5: Data Tracking (Outlier/Multiplier System)

**"Stop tracking everything. If it's not changing what you do, it's pointless to track."**

### The Problem with Standard Tracking
Most people get overwhelmed by 15-data-point spreadsheets they can't interpret. Only track metrics that would change your actions.

### The Outlier/Multiplier System

1. **Establish a benchmark** (e.g., 100K average views, or your last-90-day average)
2. **Report everything as multipliers:**
   - "This was a 1.5x outlier" (outperformed)
   - "This was a 0.5x underperformer"
3. **Benefits:**
   - Gets everyone (talent, team, marketing) on the same page
   - Makes it immediately obvious what to stop and what to continue
   - Simple enough that anyone can understand it

### Rules
- Look at the **last 90 days only** — platforms change too fast for historical data to be relevant
- If a metric wouldn't change what you do tomorrow, stop tracking it

### Output: Tracking Template with Benchmark

After discussing the user's current metrics (or establishing starting metrics), produce a tracking system they can actually use weekly.

```
## Outlier/Multiplier Tracking System

Known for: [from brand-journey.md]
Eye of Sauron platform: [from Phase 2]
Tracking start date: [date]

### Benchmark (Last 90 Days or Starting Point)
| Platform | Metric | Benchmark (Avg) | Source |
|----------|--------|-----------------|--------|
| [e.g., YouTube] | Views | [e.g., 2,400] | [Last 90 days / Starting estimate] |
| [e.g., Instagram] | Reach | [e.g., 850] | [Last 90 days / Starting estimate] |
| [e.g., LinkedIn] | Impressions | [e.g., 1,200] | [Last 90 days / Starting estimate] |

### Weekly Tracking (Copy this row each week)
| Week | Content Title | Platform | Type (W/D) | Pillar | Result | Multiplier | Notes |
|------|--------------|----------|------------|--------|--------|------------|-------|
| 1 | [title] | [platform] | [W/D] | [pillar] | [views/reach] | [X.Xx] | [what stood out] |

### Decision Rules
- **2.0x+ outlier:** Make more like this. What was the hook? Format? Topic?
- **1.5x-2.0x:** Good signal. Test the variable that made it work.
- **0.5x-1.0x:** Below average. Stop this format/topic unless strategic.
- **Below 0.5x:** Kill it. Don't repeat.

### Monthly Review Trigger
After 4 weeks: Which pillar is producing the most outliers? Shift volume toward it.
```

---

## Phase 6: Content-to-Offer Bridge

### The Philosophy

> "Trust is the currency that precedes the transaction."

Educational content's purpose is to **scale trust**:
1. Share educational content with success stories
2. Audience associates you with general success
3. They take action on your advice → get results
4. They associate you with THEIR success
5. They trust you immensely
6. When you present an offer, they believe the return will far exceed the investment

### Best Practice: Separate Organic from Selling

**Organic content:** Give, give, give, give, give. Never make a "right hook" (hard sell) in organic. Those posts always underperform, annoy the audience, and waste a posting slot.

**Paid ads:** Retarget viewers/engagers of your organic content with your offer.

**The rule:** "Share the knowledge, sell the execution."

### If You Can't Run Paid Ads

Provide overwhelming value in content. Soft CTA at the end: "If that seems overwhelming and like a nightmare to execute, that's what my team is here for."

### Email Capture Strategy

- Getting someone to leave an app, go to your website, and enter their email is a MASSIVE ask — the value must match
- Create **playbooks, checklists, SOPs, worksheets** that go deeper than your organic content
- Gate those behind email opt-in
- Only send emails when you have truly valuable content (not on a fixed cadence just to check a box)

### Collaboration as Distribution

- Appearing on others' podcasts IS a deliberate content strategy
- More reliable than hoping the algorithm pushes your content to new audiences
- **Be intentional about whose shows you appear on.** Audit: look at their other guests, listen to an episode, assess if the association benefits your brand
- "Branding is the intentional pairing of relevant things done consistently"

### Output: Content-to-Offer Flow

After discussing the user's offer, audience journey, and monetization strategy, produce a text-based flow diagram connecting their content pillars to their offer. Reference `must_learn` and `desired_outcome` from the Brand Journey.

```
## Content-to-Offer Bridge

Known for: [from brand-journey.md]
Desired outcome: [from brand-journey.md]
Must learn: [from brand-journey.md]
Primary offer: [user's offer]

### Trust Ladder
                    ┌─────────────────────────┐
                    │   OFFER                  │
                    │   [Their specific offer]  │
                    │   "Sell the execution"    │
                    └────────────┬─────────────┘
                                 │
                    ┌────────────┴─────────────┐
                    │   EMAIL LIST              │
                    │   Lead magnet: [specific] │
                    │   [playbook/checklist/SOP]│
                    └────────────┬─────────────┘
                                 │
          ┌──────────────────────┼──────────────────────┐
          │                      │                      │
   ┌──────┴──────┐      ┌───────┴──────┐      ┌───────┴──────┐
   │ DEPTH       │      │ DEPTH        │      │ WIDTH        │
   │ [Pillar 1]  │      │ [Pillar 2]   │      │ [Pillar 3]   │
   │ Builds:     │      │ Builds:      │      │ Attracts:    │
   │ [trust type]│      │ [trust type] │      │ [audience]   │
   └─────────────┘      └──────────────┘      └──────────────┘

### Monetization Path
- Organic content → [specific trust built] → [what audience learns] → [why they buy]
- Lead magnet idea: [specific gated resource that bridges content → offer]
- Retargeting strategy: [paid ads targeting content engagers / or soft CTA approach]

### Collaboration Targets
[3-5 specific podcast/show types to appear on, aligned with their known_for]
```

---

## Phase 7: Team Building Roadmap

**Only enter this phase when the user is ready to hire. Do not introduce team building prematurely.**

### Core Principle

> "We hire people to solve problems, not to fill an org chart."

Identify bottlenecks → hire to solve that specific bottleneck → a new bottleneck reveals itself → hire for that → repeat.

**Don't model after big creators.** Ronnie Coleman's routine on day one will injure you. Reverse-engineer YOUR strengths and build around that.

### Hiring Sequence

| Stage | Revenue | Hire |
|-------|---------|------|
| 1 | $0-$10K/mo | You do everything |
| 2 | $10K-$30K/mo | Video editor |
| 3 | $30K-$50K/mo | Add writer/repurposer |
| 4 | $50K-$100K/mo | Add scheduler/VA |
| 5 | $100K+/mo | Content manager/director |

### Three Hiring Models

| Model | Best For | Pros | Cons |
|-------|----------|------|------|
| **Agency** | Short-term platform expertise, expedited learning | No onboarding, immediate expertise | High creative turnover, notes don't carry over, expensive |
| **Contractor** | Experimenting with low investment | Low cost, trial period, flexible | Not their full-time priority, less discretionary effort |
| **Full-time** | Long-term brand alignment | Loyalty, discretionary effort, full investment | ~125-130% of salary with benefits |

**Key advice:** Use agencies SHORT-TERM to learn the platform, then build in-house. Hire specialized agencies (one platform), not generalist "social media agencies." Don't hire "social media managers" — they're generalists who can't keep up with any single platform.

**Always do paid trials.** Pay fairly (or even higher than the eventual rate since they lack benefits during the trial).

### Team Structure Principles

- Build bottom-up, not top-down
- Give individuals the environment to become experts on one specific platform
- Early stage: hire specialists with interest in other areas willing to wear multiple hats
- Final form: one creative per platform, 24/7 immersed in that platform

### Creative Feedback Rules

**Leave more comments about what you LIKE than what you want changed.** Editors spend energy wondering "what should I continue doing?" — eliminate that guessing.

**The 7-to-8 Rule (Short Form):** If a revision would take the video from a 7 to an 8, and it's not brand-detrimental: "Here's a note. Don't worry about it on this video. Do it on the next one." Momentum > marginal improvement.

**Default to the editor's creative call** unless it's brand-detrimental. Run A/B tests when you disagree. When you're wrong, be the FIRST to admit it publicly to the team. Overriding editors kills ownership and agency.

### Content Director Traits

1. **Curiosity** — they actually care about what you're talking about
2. **Minimal ego** — open to correction without taking it personally
3. **Fast learner** — never makes the same mistake twice
4. **Multidisciplinary** — can operate across multiple areas

### Output: Current Stage Assessment

After discussing the user's revenue, current team (if any), and bottlenecks, place them in the hiring sequence and give specific next steps.

```
## Team Building Assessment

Known for: [from brand-journey.md]
Current revenue: [user's revenue range]
Current team: [solo / editor / etc.]

### Your Stage
**Stage [X]:** [Stage name from hiring sequence]
You are here → [description of their current reality]

### Current Bottleneck
[The specific bottleneck holding them back — e.g., "You're editing your own videos, which takes 10+ hours/week that should go to idea generation"]

### Next Hire
- **Role:** [specific role]
- **Model:** [Agency / Contractor / Full-time] — [why this model for their stage]
- **What to look for:** [2-3 specific traits]
- **Budget range:** [realistic range for the role]
- **Trial structure:** [how to run a paid trial]

### NOT Yet
[What they should NOT hire for yet and why — prevent premature scaling]

### Feedback Framework for Current Team
[If they have anyone: specific feedback rules from the 7-to-8 principle, tailored to their situation]
```

---

## Execution Flow

**Step 0:** Load the Brand Journey document. If it doesn't exist, redirect to `/content-brand-journey`.

Then run these phases in order. Some phases can be combined in a single conversation; others may require the user to execute and return.

### Phase Dependency Enforcement

Before starting any phase, verify the prerequisites. If the user asks to jump to a phase whose prerequisites aren't met, explain what's missing and why it matters. Do not proceed with a phase that lacks its prerequisite inputs.

| Phase | Requires | Why |
|-------|----------|-----|
| **Phase 1** (Width vs. Depth) | Brand Journey only (Step 0) | Need pillars to classify content |
| **Phase 2** (Platform Priority) | Phase 1 | Need Width/Depth understanding to pick platforms |
| **Phase 3** (Accordion Method) | Phase 2 | Need platform selection to set volume targets |
| **Phase 4** (Idea Generation) | Phase 1 + Phase 2 | Ideas must map to pillars and platforms |
| **Phase 4b** (Viral Readiness Gate) | Phase 4 | Need Mondo List ideas to score |
| **Phase 5** (Data Tracking) | Phase 3 + at least 2 weeks of publishing | Need volume plan to track against |
| **Phase 6** (Content-to-Offer) | Phase 1 + user has an offer to bridge to | Need content strategy and a product/service |
| **Phase 7** (Team Building) | User is at revenue stage to hire | Premature hiring wastes money |

### Phase Sequence

**Phase 1** (Width vs. Depth): Run first. Label existing content if they have any.

**Phase 2** (Platform Priority): Run after reviewing their content pillars from the Brand Journey.

**Phase 3** (Accordion Method): Provide the framework. The user executes over weeks/months.

**Phase 4** (Idea Generation): Run to seed their Mondo List with 50+ ideas tied to their content pillars.

**Phase 4b** (Viral Readiness Gate): Run the top 10 Mondo List ideas through all 4 viral tests. Width content that fails gets reworked or reclassified to Depth.

**Phase 5** (Data Tracking): Set up after they've been publishing for 2+ weeks.

**Phase 6** (Content-to-Offer): Run when they have an offer to bridge content to.

**Phase 7** (Team Building): Only when they're at the revenue stage to hire.

---

## Interaction Style

Walk through phases **conversationally**, not as a data dump. The goal is a working session, not a lecture.

### Rules
1. **Ask before you produce.** At each phase, ask the user questions to personalize the output before generating it. Examples:
   - Before Phase 1: "What content are you currently creating? Walk me through your last 5-10 pieces."
   - Before Phase 2: "What platforms are you currently on? Which one feels most natural to you?"
   - Before Phase 3: "How much time per week can you realistically dedicate to content creation?"
   - Before Phase 4: "What questions do your clients/audience ask you most often?"
   - Before Phase 5: "Do you have any existing metrics? What does a 'good' post look like for you right now?"
   - Before Phase 6: "What's your primary offer? How does someone currently go from following you to buying?"
   - Before Phase 7: "What's your current revenue range? Who helps you with content right now?"

2. **Produce the phase output AFTER the conversation, not before.** The template exists so the output is structured — but the content inside must come from the user's answers, not generic fill-in-the-blank.

3. **Check understanding before moving on.** After each phase output, ask: "Does this land? Anything you'd adjust before we move to [next phase]?"

4. **Respect natural stopping points.** Phases 5-7 may not be relevant yet. Don't push through all 7 phases in one session if the user isn't ready. It's better to do 3 phases well than 7 phases superficially.

5. **Connect every recommendation back to Brand Journey fields.** If a suggestion doesn't tie back to their `known_for`, `core_pillars`, or `desired_outcome`, it doesn't belong.

### Common Difficult User Responses

| User Says | How to Handle |
|-----------|---------------|
| "I don't have any audience yet" | Normal — start with the Accordion EXPAND phase to build data. The Outlier/Multiplier system works even with small numbers (199 views vs. 413 IS the signal). Don't skip Phase 5, just set lower starting benchmarks. |
| "I want to be known for everything" | Push back. Redirect to `/content-brand-journey` — the Q2 question ("What do you want to be known for?") must produce a SPECIFIC answer. A Content Machine without focus produces noise. |
| "I don't want to do video" | That's fine — video is highest leverage but not required. Audio (podcasts) and written (newsletters, threads) work too. Adapt the platform priority map for their preferred medium. The Viral Readiness Gate's packaging tests apply to ALL formats (titles, thumbnails/covers still matter). |
| "I want to skip to [later phase]" | Check the Phase Dependency Enforcement table. Explain what's missing and why the earlier phase matters. Offer to do a quick version of the prerequisite phase if they're eager. |
| "300 pieces a week? That's insane" | Clarify: 300+ is the top-of-market ceiling, not your target. Use the Low-Capacity Adaptation for their actual capacity. Even 1 piece/week through the multiplication system can generate meaningful data. |

### Niche/Technical Brand Guidance for Viral Readiness

If the user's `known_for` is in a technical, niche, or B2B space (e.g., "enterprise data governance compliance"), the Viral Readiness Gate tests should be applied to the **PACKAGED version** of the idea, not the raw technical concept. Width content for niche brands means translating expertise into broadly accessible concepts:
- "Data governance compliance" → "This Company Lost $2.3 Billion Because of One Missing File"
- "Supply chain optimization" → "Why Your Amazon Package Took 3 Days Instead of 1"

The packaging is what goes viral. The expertise is what earns trust when they click.

---

## Final Output: Content Machine Blueprint

After completing all applicable phases, produce a single consolidated document saved as `content-machine-blueprint.md` in the same directory as the Brand Journey file. This is the user's reference document — everything they need in one place.

```markdown
---
type: content-machine-blueprint
brand_journey: brand-journey.md
created: [date]
phases_completed: [list of phase numbers completed]
---

# Content Machine Blueprint

## Brand Foundation (from Brand Journey)
- **Known for:** [known_for]
- **Desired outcome:** [desired_outcome]
- **Core pillars:** [core_pillars]
- **Human pillars:** [human_pillars]

---

## 1. Content Classification
[Phase 1 output — Width vs. Depth table]

## 2. Platform Priority Map
[Phase 2 output — filled-in platform map]

## 3. Volume Plan (Accordion Method)
[Phase 3 output — Week 1-4 plan]

## 4. Mondo List
[Phase 4 output — 50+ ideas organized by pillar]

## 5. Tracking System
[Phase 5 output — benchmarks and tracking template]

## 6. Content-to-Offer Bridge
[Phase 6 output — trust ladder and monetization path]

## 7. Team Roadmap
[Phase 7 output — current stage and next hire]

---

## Quick Reference
- **Eye of Sauron:** [current focus platform]
- **Weekly target:** [X pieces/week]
- **Primary content type:** [format]
- **Next accordion review:** [date — 4 weeks from start]
- **Lead magnet:** [specific asset]
- **Next hire (when ready):** [role]

---

*Built with the Content Machine skill (Caleb Rolston methodology)*
*Last updated: [date]*
```

Only include sections for phases that were actually completed. Do not fill in phases the user hasn't worked through yet.

---

## Key Quotes (Caleb Rolston)

> "Trust is the currency that precedes the transaction."

> "The idea is a minimum of 80% of the formula. Ideas are where you win, not in the filming or editing."

> "Stop tracking everything. If it's not changing what you do, it's pointless to track."

> "Reduce the volume and increase the effort per piece."

> "Branding is the intentional pairing of relevant things done consistently."

> "Share the knowledge, sell the execution."

> "We hire people to solve problems, not to fill an org chart."

---

*Skill based on Caleb Rolston's methodology (strategist behind Alex Hormozi & GaryVee content operations) as documented in Jay Clouse interview.*
