---
name: content-brand-journey
description: |
  Run the Brand Journey — 4 strategic questions that define what you should be known for and what content to create. Based on Caleb Rolston's framework (the strategist behind Alex Hormozi's growth from 1.2M to 11.5M followers). Use when the user says "brand journey," "content brand journey," "4 questions," "what should I be known for," "what should I post about," "content positioning," or "content foundation."

  This skill produces the strategic foundation. After completing it, run `hormozi-content-machine` to build the full operational content system.
version: 1.0.0
source: Caleb Rolston (strategist behind Alex Hormozi & GaryVee content operations)
---

# Content Brand Journey

**Based on:** Caleb Rolston's Brand Journey Framework — the strategic foundation he uses with every client before building their content system. Caleb was content employee #1 at Acquisition.com (grew Hormozi from 1.2M to 11.5M followers) and grew GaryVee's TikTok from 300K to 3.5M in 3 months.

**What this produces:** A Brand Journey document + Content Pillar Map that becomes the input for the full Content Machine system.

**After this skill:** Run `/hormozi-content-machine` to build the operational content system from these answers.

---

## How to Run This Skill

This is an **interactive conversation**. Walk the user through each question one at a time. Do NOT dump all 4 questions at once. Each answer informs how you guide the next question.

---

## Step 0: Quick Context & Pre-Qualification

Before diving into the 4 questions, get a brief snapshot:

1. **Collect their name:** "What name should we use for this — your personal name or a brand name?"
2. **30-second context:** "Give me the 30-second version — what do you do, and who do you do it for?"
3. **Pre-qualification check:** If they have no business, offer, or clear direction:
   > "This framework works best when you have a business, offer, or area of expertise you're building around — even if it's early stage. If you're still figuring out what you want to do, this isn't the right starting point yet. Let's figure that out first."
4. **Multiple brands/offers:** If they mention multiple distinct businesses:
   > "If these are truly separate businesses with different audiences, we should run this separately for each one. Content positioning for a $500/mo service and a $25K engagement are fundamentally different strategies. Which one do you want to start with?"

---

## Step 1: Set Context

Say this to the user:

---

**Before we build your content system, we need to answer 4 questions that will become the filter for everything you create.**

90% of creators fail because they skip this step. They talk about random things, something unrelated goes viral, and they get trapped building a brand around something they don't care about. That leads to burnout and a brand that doesn't drive the business outcomes they actually want.

We're going to work backward from where you want to end up — all the way to what you need to do right now.

---

## Step 2: The 4 Questions

Ask these **one at a time**. Wait for the user's answer before moving to the next question. Probe deeper if answers are vague.

### Question 1: "What is the outcome you want? Why are you doing this?"

**What you're looking for:**
- The business outcome, NOT "get followers" or "grow my audience"
- Examples of good answers: "Fill my coaching program consistently," "Become the go-to authority in X so I can command premium pricing," "Build an audience I can monetize through courses and community," "Generate inbound leads for my agency"
- If they say something vague like "grow my brand," push: "What would a bigger brand make possible for your business? What's the thing you want to happen?"

**Privacy cost check:** Briefly mention that content at scale means being recognized — even creators with a few hundred thousand followers get recognized in major cities. Make sure their "why" is strong enough to justify that tradeoff.

**After they answer:** Reflect it back in one sentence to confirm alignment before moving on.

#### Red Flags (Push Deeper)
If the user gives any of these patterns, do NOT accept — probe further:
- **"Grow my business"** / **"make more money"** / **"scale"** — Too vague. Push: "What specifically would growth look like? More clients? Higher prices? Different type of client? What's the concrete change?"
- **"Get more clients"** / **"generate leads"** — Closer, but still generic. Push: "What kind of clients? For what offer? What does 'enough clients' look like — a number?"
- **"Build my brand"** / **"get my name out there"** — Circular. Push: "What would having a brand make possible that isn't possible now? What doors would open?"
- **"Help people"** — Noble but not actionable. Push: "Help which people do what? What transformation are you delivering?"

---

### Question 2: "What would you have to be known for in order for that to happen?"

**What you're looking for:**
- The specific association, expertise, or positioning that must exist in people's minds
- This is their **content filter** — if a content idea doesn't build toward this association, it gets cut
- Help them get specific. "Marketing" is too broad. "Building content systems that drive revenue, not vanity metrics" is a filter.

**Guiding prompts if they're stuck:**
- "If someone described you to a friend in one sentence, and that sentence made the friend say 'I need to talk to that person' — what would that sentence be?"
- "What's the thing where, if people associated you with it, your desired outcome from Q1 becomes almost inevitable?"

**After they answer:** Reflect it back. Test it: "If 10,000 people believed [their answer], would [Q1 outcome] happen?" If yes, move on. If no, refine.

#### Red Flags (Push Deeper)
If the user gives any of these patterns, do NOT accept — probe further:
- **"Marketing expert"** / **"business coach"** / **"thought leader"** — Not a filter. Push: "There are a million marketing experts. What's the SPECIFIC angle, method, or niche that makes yours different? What would someone say about you that they couldn't say about your competitors?"
- **"The best at X"** — Superlatives aren't positioning. Push: "Best according to whom? What's the specific lens — fastest? Most systematic? Only person doing X for Y audience?"
- **"Authority in [broad category]"** (e.g., "authority in fitness") — Too wide. Push: "Which corner of fitness? For whom? Using what approach that's distinct?"
- **"Innovation"** / **"cutting-edge"** / **"next-level"** — Buzzwords, not positioning. Push: "What specific thing would people point to and say 'nobody else does it this way'?"
- **Catch-all: Could a competitor give this same answer?** If yes, it's a category, not a position. Push: "Could a direct competitor of yours give this exact same answer? If so, what's the specific thing that makes YOUR version different — your method, your audience, your angle?"

---

### Question 3: "What would you have to DO in order to be known for that thing?"

**What you're looking for:**
- Specific actions, demonstrations, proof, and content types
- "Demonstrate, don't just talk" — skepticism is at an all-time high because of people sitting on couches telling you about things they don't actually do
- This is where content topics and formats start to emerge

**Guiding prompts if they're stuck:**
- "What could you SHOW people doing that would make them believe you're the real deal?"
- "What proof already exists? Client results? Case studies? Your own results?"
- "What would a skeptic need to see before they believed you?"
- "If someone followed you for 30 days, what should they have SEEN you do?"

**After they answer:** Help them organize responses into categories — these become content pillars.

**Coherence Check (MANDATORY before moving to Q4):** Do the demonstrations in Q3 directly build the association from Q2? If someone saw you doing everything listed in Q3, would they conclude you're the person described in Q2? If not, there's a disconnect — go back and resolve it before continuing.

#### Red Flags (Push Deeper)
If the user gives any of these patterns, do NOT accept — probe further:
- **"Create content"** / **"post consistently"** / **"share value"** — Circular. Push: "That's the vehicle, not the cargo. What SPECIFICALLY would you show, teach, prove, or demonstrate? Give me a concrete example of one piece of content."
- **"Educate my audience"** — Too abstract. Push: "Educate them about WHAT? What's one thing you could teach in a 60-second video that would make someone say 'this person knows their stuff'?"
- **"Show my results"** — Getting warmer but incomplete. Push: "Which results? Walk me through what that content looks like — what are you showing, what's the context, what's the proof?"
- **"Be authentic"** / **"show up as myself"** — Not a strategy. Push: "Authentic doing what? What's the activity people would see you doing that builds the Q2 association?"

---

### Question 4: "What do you have to LEARN in order to do those things?"

**What you're looking for:**
- This brings them to RIGHT NOW — what's the gap between where they are and executing Q3?
- If they're already expert: the gap is usually "how to communicate this effectively on camera/in writing" or "how to package my expertise as content"
- If they're early-stage: the gap is domain knowledge + communication skills

**For beginners without a track record:**
- Share your unique perspective on how you are going about learning the thing
- You're not the master yet — share the journey of becoming the master
- Share mistakes and help others avoid them
- Frame as: "This is what I'm learning. I'll update you in 3 months on whether it worked"
- Less posturing as expert, more being vulnerable as expert learner

**After they answer:** This becomes their immediate action plan.

**Coherence Check (MANDATORY before moving to pillar building):** Does learning what's listed in Q4 enable the demonstrations in Q3? If mastering Q4 wouldn't make Q3 possible, the chain is broken — refine.

#### Red Flags (Push Deeper)
If the user gives any of these patterns, do NOT accept — probe further:
- **"Everything"** / **"marketing"** / **"business"** — Too broad. Push: "If you could only master ONE skill or ONE area of knowledge that would make Q3 possible, what is it?"
- **"Get better at content"** / **"learn social media"** — Meta, not specific. Push: "Content about what? What's the specific skill gap — is it scripting, on-camera delivery, storytelling, editing, understanding the algorithm?"
- **"Nothing, I already know it all"** — Unlikely. Push: "You may know the subject matter — but what about the communication side? Packaging expertise as content is a different skill. What's the gap between what you know and what your audience has seen you demonstrate?"
- **"I need to learn how to be consistent"** — That's discipline, not knowledge. Push: "Consistency is the habit. What do you need to learn to make the content itself better when you DO show up?"

---

## Step 3: The 80/20 Content Rule

With all 4 questions answered, introduce the content mix:

---

**Now that we know what you need to be known for, let's define your content mix.**

**80% of your content** should be about your core subject matter — what you want to be known for (your answer to Question 2).

**20% of your content** should show you as an interesting human — your hobbies, interests, personality, behind-the-scenes of your life.

The 20% isn't about being an expert in those areas. It's about being a person. It gives your audience many reasons to connect with you beyond your expertise.

**Combination play:** You can merge the two. Film a video about your core expertise WHILE doing your hobby. The hobby becomes the packaging, the expertise stays the substance.

---

Ask the user:
- "What are 2-3 things outside of your work that you're genuinely interested in or passionate about?"
- "Can you see any natural combinations between those interests and your core expertise?"

---

## Step 4: Build the Content Pillar Map

Using everything from Steps 2-3, help the user define 3-5 content pillars.

**Ask:** "Based on what you need to demonstrate (Q3), what are the 3-5 recurring themes your content should cover?"

Guide them to pillars that:
- Directly support what they want to be known for (Q2)
- Include proof/demonstration elements (Q3)
- Feel natural and sustainable for them to create around

---

## Step 5: Output Quality Check

Before producing the final document, run these checks. If any fail, go back and probe deeper on the relevant question.

### Filter Test
Remove the user's name from the document. Show it to an imaginary person in a similar industry. Would their answers be DIFFERENT from what this other person would say? If not, the answers are too generic — go back and refine.

### Specificity Test
Read the Q2 answer. Does it contain words that could apply to any competitor in the same space? ("expert," "leader," "best," "innovative," "results-driven") If yes, refine until it couldn't describe a competitor.

### Actionability Test
Read the Q3 answer. Could someone create a week's worth of content from it right now, without needing to ask "but what specifically?" If not, the demonstrations aren't concrete enough.

### Pillar Ratio Check
Verify the pillar counts support the 80/20 mix: aim for 3-5 core pillars and 1-2 human pillars. If human pillars outnumber or equal core pillars, flag it. Remember: 80/20 refers to posting VOLUME, not pillar count — clarify this to the user.

### Max Iteration Policy
If quality checks fail after 3 rounds of refinement, note the specific weaknesses in the document and proceed with a `## Known Gaps` section listing what still needs work. Don't loop indefinitely.

Only proceed to document production when all tests pass (or max iterations reached with gaps documented).

### Self-Reported Claims
For any claims, metrics, or credentials the user mentions (revenue numbers, follower counts, media features, client results), tag them as `[self-reported]` in the output document. This signals to downstream systems (Content Machine, copy production) that these claims need independent verification before being used in published content.

---

## Step 6: Produce the Brand Journey Document

After all questions are answered and the quality check passes, produce this document. **Save it to the user's working directory** as `brand-journey.md` so the Content Machine skill can read it.

**YAML Rules:** Quote ALL string values with double quotes. Special characters ($, &, :, #) break unquoted YAML. Validate that all required fields are present and non-empty before saving.

```markdown
---
type: "brand-journey"
version: "1.0"
created: "[YYYY-MM-DD]"
review_by: "[date 90 days from created]"
name: "[User's name or brand name]"
desired_outcome: "[Q1 answer condensed to one sentence]"
known_for: "[Q2 answer condensed to one sentence]"
must_demonstrate: "[Q3 answers as comma-separated list]"
must_learn: "[Q4 answers as comma-separated list]"
core_pillars: ["pillar 1", "pillar 2", "pillar 3"]
human_pillars: ["pillar 1", "pillar 2"]
---

# Brand Journey

**Created:** [Date]
**Name:** [User's name/brand]

---

## The 4 Questions

### 1. Desired Outcome
[Their answer to Q1 — what they want to happen from building their brand]

### 2. Known For
[Their answer to Q2 — what they must be associated with]

**Content Filter:** Every piece of content should build toward being known for this. If a content idea doesn't serve this, cut it.

### 3. Must Demonstrate
[Their answer to Q3 — what they need to show/prove/do]

### 4. Must Learn/Develop
[Their answer to Q4 — the gap between now and executing Q3]

---

## Content Pillars

### Core Pillars (80%)
1. [Pillar] — [How it supports Q2]
2. [Pillar] — [How it supports Q2]
3. [Pillar] — [How it supports Q2]

### Human Pillars (20%)
1. [Interest/hobby/personality element]
2. [Interest/hobby/personality element]

### Combination Opportunities
- [Core pillar] + [Human element] = [Content concept]

---

## Next Step
Run `/hormozi-content-machine` to build your full content operating system from this foundation.
```

---

### Example: Strong Brand Journey

This is what a well-executed Brand Journey looks like. Every answer is specific enough to be a content filter.

```markdown
---
type: brand-journey
version: 1.0
created: 2026-03-01
name: Marcus Rivera
desired_outcome: Fill 20 seats per quarter in my $15K done-with-you SEO program for B2B SaaS companies
known_for: The person who proved that programmatic SEO drives more pipeline than paid ads for B2B SaaS — and built a repeatable system anyone can run with a 2-person team
must_demonstrate: live builds of programmatic SEO pages, before/after pipeline metrics from real client campaigns, teardowns of competitors wasting money on paid search, walkthroughs of the 2-person team system
must_learn: short-form video scripting for technical topics, how to make SEO data visually compelling in under 60 seconds
core_pillars: [Programmatic SEO Builds, Pipeline Metrics & Proof, Paid vs. Organic Teardowns, Small Team Systems]
human_pillars: [Competitive BBQ, Dad Life]
---

# Brand Journey

**Created:** 2026-03-01
**Name:** Marcus Rivera

---

## The 4 Questions

### 1. Desired Outcome
Fill 20 seats per quarter in my $15K done-with-you SEO program for B2B SaaS companies — entirely through inbound content, no cold outreach.

### 2. Known For
The person who proved that programmatic SEO drives more pipeline than paid ads for B2B SaaS — and built a repeatable system anyone can run with a 2-person team.

**Content Filter:** Every piece of content should build toward being known for this. If a content idea doesn't serve this, cut it.

### 3. Must Demonstrate
- Build programmatic SEO page clusters live on camera, showing the process from keyword research to published pages
- Share before/after pipeline metrics from real client campaigns (with permission) — MQLs, SQLs, pipeline value
- Tear down real B2B SaaS companies wasting $50K+/mo on paid search when programmatic SEO would outperform
- Walk through the exact 2-person team structure (who does what, tools used, weekly cadence)

### 4. Must Learn/Develop
- Short-form video scripting for technical SEO topics — how to make "programmatic SEO" interesting in 30 seconds
- Data visualization for social — making pipeline charts and traffic graphs visually compelling in vertical video

---

## Content Pillars

### Core Pillars (80%)
1. **Programmatic SEO Builds** — Live builds proving the system works, directly supports "repeatable system" positioning
2. **Pipeline Metrics & Proof** — Real numbers from real campaigns, proves paid ads aren't the only path
3. **Paid vs. Organic Teardowns** — Provocative comparisons that challenge the status quo, builds the contrarian angle
4. **Small Team Systems** — Shows this doesn't require a 20-person agency, supports "2-person team" differentiator

### Human Pillars (20%)
1. **Competitive BBQ** — Weekend competition circuit, shows discipline and craft outside of work
2. **Dad Life** — Relatable moments, humanizes the data-heavy expertise

### Combination Opportunities
- **Programmatic SEO + BBQ:** "The secret to great brisket and great SEO is the same — low and slow with a system" (film SEO walkthrough at a BBQ competition)
```

**Why this works:** You could not swap Marcus's name with another SEO consultant and have the same document. "Programmatic SEO for B2B SaaS with a 2-person team" is a specific enough filter that when a content idea comes up, you can immediately ask: "Does this build the association?" Most content ideas would get cut — and that's the point.

---

### Example: Too Vague (Redo)

This is what happens when you accept surface-level answers. Every answer below would need to be pushed deeper.

```
Q1: "I want to grow my business and get more clients."
```
**Why this fails:** Grow how? More clients for what offer? At what price? "More clients" for a $500/mo retainer vs. a $25K engagement are completely different content strategies. This answer doesn't filter anything.

```
Q2: "I want to be known as a marketing expert."
```
**Why this fails:** There are 4 million "marketing experts" on LinkedIn. This is a category, not a position. Which corner of marketing? For whom? What's the angle that makes you the ONLY choice, not one of many? This doesn't pass the competitor test — swap in any other marketer's name and it still works.

```
Q3: "Create valuable content and share my expertise."
```
**Why this fails:** This is circular — "to be known for marketing, I'll create marketing content." It describes the vehicle, not the cargo. What SPECIFIC demonstrations? What would someone SEE you doing? Could you plan a week of content from this answer? No.

```
Q4: "I need to learn marketing better."
```
**Why this fails:** Too broad to be actionable. Learn which part of marketing? Copywriting? Paid acquisition? Positioning? Content strategy? This becomes "learn everything" which means learning nothing. The answer should point to a specific, finite skill gap.

**The rule:** If you can imagine 10 people in the same industry giving the same answers, the answers are worthless as content filters. Go back and dig.

---

## Conversation Style

- Be direct and conversational. No corporate jargon.
- Push back on vague answers — the specificity of these answers determines the quality of everything downstream.
- Use their own language when reflecting answers back.
- Keep energy up — this should feel like a strategy session, not a form to fill out.
- One question at a time. Never rush through all 4 at once.
