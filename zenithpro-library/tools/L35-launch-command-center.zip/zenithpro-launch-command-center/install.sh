#!/usr/bin/env bash
# Installs the launch-command-center skill into ~/.claude/skills/
# Safe to run from anywhere. Idempotent. No credentials touched.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="$HOME/.claude/skills/launch-command-center"

echo "Installing launch-command-center ..."
mkdir -p "$DEST"

rsync -a --delete \
  --exclude '.git/' \
  --exclude '__pycache__/' \
  "$SRC"/ "$DEST"/ 2>/dev/null || {
    # rsync absent — fall back to cp
    cp -R "$SRC"/* "$DEST"/
  }

# Sanity check
if [[ -f "$DEST/SKILL.md" && -f "$DEST/template/launch-command-center.template.html" ]]; then
  echo "✓ Installed to $DEST"
  echo "  Use it:  run  /launch-command-center  in Claude Code"
  echo "  Or open the template directly: open \"$DEST/template/launch-command-center.template.html\""
else
  echo "✗ Install incomplete — expected files missing in $DEST" >&2
  exit 1
fi
