# Launch Command Center — ZenithPro Skill

Build a single-file, shareable **Launch Command Center** for your own launch — every wave, date, budget number, story beat, and the path-to-your-goal math, all on one screen. Opens in any browser. No server, no build step, **no credentials.**

A reusable launch command center you run for *your* own product, report, or offer — your niche, your dates, your numbers. Nothing in it is tied to anyone else's launch.

## What you get
- A colour-coded **calendar** of the whole launch, day by day
- Four reach **waves** (early list · partners · house list · podcasts/seeding)
- **Ads & Budget** — the arithmetic that sets the number, not a guess
- A **Story Arc** tab — the six-beat narrative your launch rides on
- A **Proposals** tab — ideas that are *not yet agreed* (keeps you honest)
- **Path to {{your goal}}** — the offer-ladder LTV + funnel-cascade math

## Install
1. Download and unzip this package to your `~/Downloads` folder.
2. In Claude Code, run:
   ```
   ./install.sh
   ```
   (or just tell Claude: *"Install the launch-command-center skill from this folder."*)
3. Then run the skill:
   ```
   /launch-command-center
   ```
   Claude will interview you and build your dashboard.

## Use it without Claude Code
You don't need the skill to use it. Open `template/launch-command-center.template.html` in a browser, then edit the file directly — every field is wrapped in `{{double braces}}` and all example content is clearly marked `SAMPLE`. See `examples/` for a fully-worked version.

## The one rule
This file is meant to be **screenshotted and shown to partners**, so it must never contain an API key, token, account/location ID, private CDN link, or anyone's private customer data. If you want live auto-updating numbers, that's a separate local script that reads *your* keys from *your* `.env` on *your* machine — the numbers land in the dashboard, the keys never do.

## Files
```
zenithpro-launch-command-center/
├── SKILL.md                                  # the skill (how Claude builds yours)
├── README.md                                 # this file
├── install.sh                                # installs the skill
├── template/
│   └── launch-command-center.template.html   # the template (SAMPLE data + {{fields}})
└── examples/
    └── launch-command-center-EXAMPLE.html    # a fully-filled fictional launch
```
