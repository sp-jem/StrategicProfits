---
name: launch-command-center
description: Build a single-file, shareable "Launch Command Center" dashboard for your own product/report/offer launch — every wave, date, budget number, and the path-to-goal math in one visual place. Interview-driven; produces a self-contained HTML file with zero credentials. Use when a student says "build my launch command center", "I need a launch dashboard", "map out my whole launch", "put my launch plan in one place".
---

# Launch Command Center

You build the student a **single self-contained HTML dashboard** that holds their entire launch on one screen: a colour-coded calendar, four reach "waves", the ads/budget math, the story arc, an honest "proposals (nothing agreed)" tab, and a "path to your revenue goal" model. It opens in any browser — no server, no build step, **no credentials, ever**.

This is a *thinking* tool as much as a dashboard. Your job is to pull the plan out of the student's head and lay it out so they (and anyone they show it to) can see the whole launch at a glance and tell instantly what's built vs. still open.

## The one hard rule: this file must stay shareable

The command center is meant to be screenshotted and shown to partners. Therefore it must contain **NO**:
- API keys, tokens, OAuth secrets, passwords
- CRM/account/location IDs (e.g. GoHighLevel location IDs) or any URL that embeds one
- Private CDN links, signed URLs, or asset links that grant download access
- Real customer PII, and no third party's private quotes

If the student wants live data, that belongs in a **separate** local script that reads *their own* keys from *their own* `.env` on *their own* machine — it never gets pasted into this HTML. If you ever find yourself about to paste a key or an account-scoped URL into the dashboard, stop: hardcode the resulting *number* instead, or leave a `[FILL]` marker.

## How to run it

1. **Read the template** at `template/launch-command-center.template.html` so you know every field and section.
2. **Interview the student** to fill it. Ask in this order, one topic at a time (don't dump all questions at once):
   - **The launch, in a sentence.** What are they launching, to whom, and what's the one-line promise?
   - **The goal.** The revenue/units number this launch (and its monthly repeat) is meant to hit. This names the "Path to {{GOAL}}" tab.
   - **The four waves.** Which audiences carry reach, in what order? Common shape: (1) hottest/early-access list, (2) partners/affiliates, (3) house list / public, (4) podcasts/seeding/compounding. Rename them to fit — a wave is just "a distinct audience mailed distinctly."
   - **The calendar.** Real dates for: reach/ads build, early release, public release, page-live, live event(s), replay window, cart close, any second-month challenge/evergreen. Colour each day by wave.
   - **The scoreboard.** Their six live KPIs (readers, waitlist, new leads, partners, opt-in rate, + one of their choice). Use real numbers if they have them; otherwise mark them clearly as targets.
   - **The offer ladder** (for the model tab): core offer + price, upsell, continuity, high-ticket — with take-rates. Label every assumed rate "assumed"; only mark a rate "measured" if it came from a real past launch.
   - **The budget math.** Their real cost-per-lead (from a test, not a guess), their working ceiling, and how many people paid traffic needs to supply.
   - **The story arc.** The six beats (Stabilize → Release → Reaction → Event → Propagation → Conversion) in their own words + dates.
   - **Proposals.** Anything on the table but NOT agreed. This tab keeps "idea" from silently becoming "commitment."
3. **Fill the template.** Replace every `{{FIELD}}`, rebuild the two calendar months for their real dates, and replace all SAMPLE (Dana Rivera) content. Delete the yellow how-to banner. Keep any genuinely-unknown value as a visible `[FILL]` / `.fill` marker rather than inventing it.
4. **Honesty discipline** (this is what makes it good, per the source method):
   - Never invent a number. No source → mark it a target or leave `[FILL]`. Fabricating a metric, price, or date is a hard stop.
   - Label measured vs. assumed vs. target explicitly.
   - State whether the headline goal is gross or net, and this-year vs. over-12-months.
   - Keep a live "what's built vs. what's open" read — use the `.pill` states (done / building / gate / open).
5. **Save** as `launch-command-center-{{student-slug}}.html` and tell them to open it directly (double-click / `open` it) — confirm it renders and the tabs switch.
6. **Credential sweep before you hand it back.** Grep the final file for `api`, `key`, `token`, `secret`, `Bearer`, `location_id`, `filesafe`, `cdn`, and any `http` link that includes an account ID. If anything hits, remove it. Only ship when the sweep is clean.

## What "good" looks like
- Someone who has never seen the launch can read the whole plan in two minutes.
- Every claim is either measured (and labelled) or flagged as an assumption/target.
- The "Proposals" and "what's open" honesty is intact — it's a decision tool, not a hype poster.
- The file opens offline, contains no credentials, and is safe to screenshot to a partner.

## Notes
- Design system is brand-neutral cream/ink with one swappable accent (the two `--ox` lines in `:root`). Change the accent to the student's brand; leave the rest.
- The whole thing is ~1 HTML file. Don't add frameworks, CDNs, or external fonts — it must stay self-contained and offline-safe.
- If the student wants it *live* (auto-refreshing numbers), that's a separate follow-on: a small local script on their machine, their keys in their `.env`, writing a `data.json` the page reads locally — never keys in the HTML.
