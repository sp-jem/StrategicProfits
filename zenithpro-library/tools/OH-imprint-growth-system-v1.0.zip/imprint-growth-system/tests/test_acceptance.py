#!/usr/bin/env python3
"""
Acceptance tests for the Imprint Growth System — T1..T7 from BUILD-SPEC §5.

Run:  python3 tests/test_acceptance.py
Hermetic + repeatable: forces the deterministic 'script' backend and an
isolated temp IMPRINT_DIR per test, so it needs no API and no Rich-specific
path. (T7 separately proves the shipped code carries no hardcoded paths.)

The LLM agents are proven separately by a live `claude -p` demo (see
tests/live_demo.sh) — but the full pipeline WIRING + the deterministic writer,
dedup/BUMP, C3 gate, and C2 cold-start selection are proven here, every run.
"""

import json
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ENGINE = Path(__file__).resolve().parent.parent
LIB = ENGINE / "lib"
BIN = ENGINE / "bin"
FIX = Path(__file__).resolve().parent / "fixtures"
sys.path.insert(0, str(LIB))
sys.path.insert(0, str(BIN))

# Force deterministic backend for hermetic runs.
os.environ["IMPRINT_BACKEND"] = "script"
os.environ.pop("IMPRINT_CONFIG", None)

import imprintlib as L          # noqa: E402
import agents_api               # noqa: E402
import script_backend           # noqa: E402
import writer_core              # noqa: E402

# load the pipeline module (filename has a dash)
import importlib.util           # noqa: E402
_spec = importlib.util.spec_from_file_location("imprint_pipeline", str(BIN / "imprint-pipeline.py"))
pipeline = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(pipeline)

RESULTS = []


def fresh_dir():
    d = tempfile.mkdtemp(prefix="imprint-test-")
    os.environ["IMPRINT_DIR"] = d
    return Path(d)


def record(name, ok, detail):
    RESULTS.append((name, ok, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: {detail}")


def candidate(correction, rationale, principle, domain, quote, ref="t", typ="live"):
    return {"correction": correction, "rationale": rationale, "principle": principle,
            "domain": domain, "quote": quote,
            "source": {"type": typ, "ref": ref, "locator": "x"}}


# ---------------------------------------------------------------------------
# T1 — Hook fires; a turn with no correction -> filter no-op, recorder never spawned.
# ---------------------------------------------------------------------------
def t1():
    fresh_dir()
    moment = L.extract_last_exchange(str(FIX / "no-correction.jsonl"))
    passed, reason = L.cheap_filter(moment["human"])
    gate_ok = (passed is False)

    # End-to-end: run the actual Stop hook with the no-correction transcript and
    # confirm it produced NO side effects (no moment file, no bank, no ledger).
    payload = json.dumps({"transcript_path": str(FIX / "no-correction.jsonl"),
                          "session_id": "sess-noc"})
    subprocess.run([sys.executable, str(BIN / "imprint-capture.py")],
                   input=payload, text=True, capture_output=True,
                   env={**os.environ})
    time.sleep(0.4)
    d = L.imprint_dir()
    spawned = list(d.glob(".moment-*.json")) if d.exists() else []
    ledger_lines = L.ledger_path().read_text().splitlines() if L.ledger_path().exists() else []
    no_side_effects = (len(spawned) == 0 and len(ledger_lines) == 0)

    # positive control: a real correction DOES pass the gate
    cor_moment = L.extract_last_exchange(str(FIX / "correction.jsonl"))
    pos_ok, _ = L.cheap_filter(cor_moment["human"])

    ok = gate_ok and no_side_effects and pos_ok
    record("T1", ok, f"no-corr filter={passed}({reason}); side_effects={not no_side_effects}; "
                     f"pos-control passes={pos_ok}")


# ---------------------------------------------------------------------------
# T2 — A correction+rationale turn -> recorder emits a correctly-shaped candidate.
# ---------------------------------------------------------------------------
def t2():
    fresh_dir()
    moment = L.extract_last_exchange(str(FIX / "correction.jsonl"))
    cands = agents_api.recorder(moment)
    if not cands:
        return record("T2", False, "recorder emitted nothing on a correction+rationale turn")
    c = cands[0]
    ok_shape, problem = L.validate_candidate(c)
    fields_present = all(f in c for f in L.CANDIDATE_FIELDS)
    quote_verbatim = c["quote"].strip().strip('"') in moment["human"]
    has_why = bool(c["rationale"].strip())
    ok = ok_shape and fields_present and quote_verbatim and has_why
    record("T2", ok, f"shape_ok={ok_shape}({problem}); fields={fields_present}; "
                     f"quote_in_source={quote_verbatim}; has_why={has_why}; "
                     f"domain={c['domain']!r}")


# ---------------------------------------------------------------------------
# T3 — Judge REJECTS a candidate with no why; ACCEPTS one that carries it.
# ---------------------------------------------------------------------------
def t3():
    fresh_dir()
    no_why = candidate("use dollars not percent", "", "Use absolute figures over percentages",
                       "voice/communication", "use the dollar figure")
    with_why = candidate("use dollars not percent",
                         "because the absolute total is more visceral and equally accurate",
                         "Lead with the absolute figure, not the percentage",
                         "voice/communication", "use the dollar figure, the total is more visceral")
    verdicts = agents_api.judge([no_why, with_why], existing=[])
    rej_ok = verdicts[0]["verdict"] == "REJECT" and "why" in verdicts[0].get("reason", "").lower()
    acc_ok = verdicts[1]["verdict"] == "APPEND"
    record("T3", rej_ok and acc_ok,
           f"no-why -> {verdicts[0]['verdict']}({verdicts[0].get('reason','')}); "
           f"with-why -> {verdicts[1]['verdict']}")


# ---------------------------------------------------------------------------
# T4 — A near-duplicate of an existing principle -> BUMP (⭐ raised + quote added),
#       NOT a duplicate entry.
# ---------------------------------------------------------------------------
def t4():
    fresh_dir()
    a = candidate("always give the full date and place",
                  "because vague time references read as hedging and leak credibility",
                  "Always give the exact date and place; never write recently",
                  "voice/communication", "give the date, the time, the place — not recently")
    eid = writer_core.seed_entry(a)   # entry exists, count=1, ⭐
    before_idx = L.read_index()
    before_count = len(before_idx["entries"])

    b = candidate("don't write recently, give coordinates",
                  "because the specific date reads as being there; recently is a credibility leak",
                  "Cite the exact date and place; never write recently",   # near-duplicate of A
                  "voice/communication", "why recently? give the exact date and place")
    summary = pipeline.process_candidates([b])

    after_idx = L.read_index()
    entry = after_idx["entries"].get(eid, {})
    bank = L.read_bank_text()
    ledger = [json.loads(x) for x in L.ledger_path().read_text().splitlines()]
    actions = [l["action"] for l in ledger]

    no_dup = len(after_idx["entries"]) == before_count == 1
    bumped = entry.get("count") == 2 and L.stars_for_count(2) == "⭐⭐"
    quote_added = len(entry.get("quotes", [])) == 2
    stars_in_bank = "⭐⭐" in bank
    ledger_has_bump = "bump" in actions and "append" in actions
    ok = no_dup and bumped and quote_added and stars_in_bank and ledger_has_bump
    record("T4", ok, f"verdict={summary['bump'] and 'BUMP' or summary}; entries={len(after_idx['entries'])}; "
                     f"count={entry.get('count')}; quotes={len(entry.get('quotes', []))}; "
                     f"stars(⭐⭐)_in_bank={stars_in_bank}; ledger={actions}")


# ---------------------------------------------------------------------------
# T5 — An APPEND lands in the bank in house format AND writes a ledger line;
#       a REJECT lands in rejects.jsonl.
# ---------------------------------------------------------------------------
def t5():
    fresh_dir()
    good = candidate("open on the problem not the price",
                     "because opening on price trains buyers to wait for a coupon",
                     "Lead with the customer problem, never the discount",
                     "strategy", "lead with the problem the customer already feels")
    bad = candidate("do something", "", "Do the thing",
                    "process", "")   # no why + no quote -> must be parked
    summary = pipeline.process_candidates([good, bad])

    bank = L.read_bank_text()
    # house format: **<ID>. principle.** ⭐ *(YYYY-MM-DD)*  / *Why:* / > "quote"
    house = re.search(r"\*\*[A-Z]+\d+\. .+\.\*\* ⭐+ \*\(\d{4}-\d{2}-\d{2}\)\*", bank)
    why = "*Why:*" in bank
    quote = '> "lead with the problem' in bank
    ledger = [json.loads(x) for x in L.ledger_path().read_text().splitlines()] if L.ledger_path().exists() else []
    append_logged = any(l["action"] == "append" and l.get("entry_id") and l.get("source") for l in ledger)
    rejects = [json.loads(x) for x in L.rejects_path().read_text().splitlines()] if L.rejects_path().exists() else []
    reject_parked = len(rejects) >= 1 and "candidate" in rejects[0] and "reason" in rejects[0]

    ok = bool(house) and why and quote and append_logged and reject_parked
    record("T5", ok, f"house_format={bool(house)}; why={why}; quote={quote}; "
                     f"ledger_append={append_logged}; reject_parked={reject_parked} "
                     f"(reason={rejects[0]['reason'] if rejects else None})")


# ---------------------------------------------------------------------------
# T6 — Cold-start over a folder with one transcript (corrections) + one finished
#       report -> entries come ONLY from the transcript; the report is ignored.
#       (Proves C2.) Decision is content-based, NOT filename-based: both files
#       are .md, and the report even contains 'should ... because ...' which
#       trips the cheap filter — yet the recorder still emits nothing from it.
# ---------------------------------------------------------------------------
def t6():
    fresh_dir()
    src = FIX / "coldstart"
    out = subprocess.run(
        [sys.executable, str(BIN / "imprint-coldstart.py"), "--source", str(src), "--reset", "--json"],
        capture_output=True, text=True, env={**os.environ})
    try:
        report = json.loads(out.stdout)
    except json.JSONDecodeError:
        return record("T6", False, f"coldstart produced no JSON. stderr={out.stderr[:200]}")

    by_name = {Path(r["file"]).name: r for r in report}
    transcript = by_name.get("coaching-transcript.md", {})
    rpt = by_name.get("quarterly-report.md", {})
    sop = by_name.get("deploy-runbook.md", {})   # 2nd-person imperative SOP — the case that broke it

    transcript_harvested = transcript.get("append", 0) > 0
    report_ignored = (rpt.get("append", 0) == 0 and rpt.get("bump", 0) == 0)
    sop_ignored = (sop.get("append", 0) == 0 and sop.get("bump", 0) == 0)
    # the strongest C2 assertion: EVERY ledger source.ref points to the transcript, never a deliverable
    ledger = [json.loads(x) for x in L.ledger_path().read_text().splitlines()] if L.ledger_path().exists() else []
    refs = {Path(l.get("source", {}).get("ref", "")).name for l in ledger}
    only_from_transcript = (refs and "coaching-transcript.md" in refs
                            and "quarterly-report.md" not in refs
                            and "deploy-runbook.md" not in refs)
    # prove it wasn't the cheap filter that saved us: BOTH deliverables tripped the filter
    report_tripped_filter = rpt.get("signal", 0) > 0
    sop_tripped_filter = sop.get("signal", 0) > 0

    ok = transcript_harvested and report_ignored and sop_ignored and only_from_transcript
    record("T6", ok,
           f"transcript +{transcript.get('append')} ({transcript.get('verdict')}); "
           f"3rd-person report +{rpt.get('append')} (tripped_filter={report_tripped_filter}); "
           f"2nd-person SOP +{sop.get('append')} (tripped_filter={sop_tripped_filter}) -> recorder rejected BOTH on content; "
           f"ledger_refs={refs}")


# ---------------------------------------------------------------------------
# T7 — Runs clean with NO Rich-specific paths; nothing hardcoded to one machine.
# ---------------------------------------------------------------------------
def t7():
    # (a) static scan of shipped SOURCE/docs for operator-specific hardcoding.
    #     Build artifacts (__pycache__/*.pyc) are not source and are stripped at
    #     package time — exclude them so we scan only what ships.
    def is_source(p: Path) -> bool:
        return ("__pycache__" not in p.parts
                and p.suffix.lower() not in {".pyc", ".pyo"}
                and p.name != ".DS_Store")
    targets = []
    for sub in ("lib", "bin", "agents"):
        targets += [p for p in (ENGINE / sub).rglob("*") if p.is_file() and is_source(p)]
    targets += [ENGINE / f for f in ("install.sh", "install.ps1", "README.md",
                                     "manifest.json", "config.example.json", "CONTRACTS.md")
                if (ENGINE / f).exists()]
    banned = ["/Users/richardschefren", "richardschefren", "Obsidian/Active-Brain",
              "Strategic-Profits", "richonly@", "richschefren", "Rich-Manifesto"]
    hits = []
    for f in targets:
        try:
            txt = f.read_text(errors="replace")
        except OSError:
            continue
        for b in banned:
            if b in txt:
                hits.append(f"{f.relative_to(ENGINE)}::{b}")
    clean = not hits

    # (b) functional portability: full live capture in a brand-new temp 'vault'
    fresh_dir()
    moment = {"human": "No, never auto-publish without my review, because one bad "
                       "post in my voice does more damage than a day of silence.",
              "assistant": "ok", "source": {"type": "live", "ref": "portable", "locator": "1"}}
    summary = pipeline.process_moment(moment)
    works_anywhere = (len(summary["append"]) + len(summary["bump"])) >= 1 and L.bank_path().exists()

    ok = clean and works_anywhere
    record("T7", ok, f"hardcoded_path_hits={hits or 'NONE'}; "
                     f"captured_in_fresh_vault={works_anywhere} at {L.bank_path()}")


def main():
    for t in (t1, t2, t3, t4, t5, t6, t7):
        try:
            t()
        except Exception as e:
            import traceback
            record(t.__name__.upper(), False, f"EXCEPTION: {e}\n{traceback.format_exc()}")
    print("\n" + "=" * 60)
    passed = sum(1 for _, ok, _ in RESULTS if ok)
    print(f"RESULT: {passed}/{len(RESULTS)} acceptance tests passed")
    print("=" * 60)
    return 0 if passed == len(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())
