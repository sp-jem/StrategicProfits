#!/usr/bin/env python3
"""
Live proof: the REAL isolated `claude -p` Recorder + Judge agents (production
backend), not the deterministic fallback. Shows actual agent output for
T2 (recorder), T3 (judge), and T6 (cold-start C2) — the three that turn on the
agents' judgment.

Run: IMPRINT_BACKEND=claude python3 tests/live_demo.py
"""
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ENGINE = Path(__file__).resolve().parent.parent
FIX = Path(__file__).resolve().parent / "fixtures"
sys.path.insert(0, str(ENGINE / "lib"))
sys.path.insert(0, str(ENGINE / "bin"))

os.environ["IMPRINT_BACKEND"] = "claude"
os.environ["IMPRINT_DIR"] = tempfile.mkdtemp(prefix="imprint-live-")

import imprintlib as L          # noqa
import agents_api               # noqa
import importlib.util
_spec = importlib.util.spec_from_file_location("imprint_pipeline", str(ENGINE / "bin" / "imprint-pipeline.py"))
pipeline = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(pipeline)

print(f"backend = {L.agent_backend()}   (claude available: {L.claude_available()})")
print(f"imprint dir = {L.imprint_dir()}\n")

# ---- T2-live: recorder on a real correction+rationale moment ----
print("=== T2 (LIVE recorder) ===")
moment = L.extract_last_exchange(str(FIX / "correction.jsonl"))
cands = agents_api.recorder(moment)
print(json.dumps(cands, indent=2, ensure_ascii=False))

# ---- T3-live: judge rejects no-why, accepts with-why ----
print("\n=== T3 (LIVE judge) ===")
no_why = {"correction": "use dollars not percent", "rationale": "",
          "principle": "Use absolute figures over percentages", "domain": "voice/communication",
          "quote": "use the dollar figure", "source": {"type": "live", "ref": "d", "locator": "1"}}
with_why = {"correction": "use dollars not percent",
            "rationale": "because the absolute total is more visceral and equally accurate",
            "principle": "Lead with the absolute figure, not the percentage",
            "domain": "voice/communication",
            "quote": "use the dollar figure — the total is more visceral", "source": {"type": "live", "ref": "d", "locator": "2"}}
verdicts = agents_api.judge([no_why, with_why], existing=[])
print(json.dumps(verdicts, indent=2, ensure_ascii=False))

# ---- T6-live: cold-start with the REAL recorder over transcript + report ----
print("\n=== T6 (LIVE cold-start C2) ===")
out = subprocess.run(
    [sys.executable, str(ENGINE / "bin" / "imprint-coldstart.py"),
     "--source", str(FIX / "coldstart"), "--reset", "--json"],
    capture_output=True, text=True, env={**os.environ})
try:
    report = json.loads(out.stdout)
    for r in report:
        print(f"  {Path(r['file']).name:28s} signal={r['signal']} +{r['append']} ~{r['bump']}  {r['verdict']}")
    ledger = [json.loads(x) for x in L.ledger_path().read_text().splitlines()] if L.ledger_path().exists() else []
    refs = sorted({Path(l.get('source', {}).get('ref', '')).name for l in ledger})
    print(f"  ledger source files: {refs}")
    print(f"  C2 holds (report contributed nothing): {'quarterly-report.md' not in refs}")
except json.JSONDecodeError:
    print("coldstart stdout:", out.stdout[:500], "\nstderr:", out.stderr[:500])

print(f"\n--- resulting bank ---\n{L.read_bank_text()}")
