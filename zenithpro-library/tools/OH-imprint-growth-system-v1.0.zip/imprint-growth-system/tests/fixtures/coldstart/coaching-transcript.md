# Working session — operator reviewing the AI's draft (captured conversation)

Operator: No, don't lead the email with the discount. Lead with the problem the
customer is already feeling, because if you open on price you train them to wait
for the next coupon instead of buying on need.

AI: Understood — I'll restructure to open on the pain point.

Operator: Stop using "synergy" and "leverage" in customer-facing copy. The reason
is our buyers are tradespeople; corporate words make us sound like the big-box
store they're trying to avoid.

AI: Got it, I'll cut the corporate vocabulary.

Operator: You keep rounding the testimonial numbers. Never round a real result —
"saved 11.5 hours" is more believable than "saved ~12 hours" because the
oddly-specific number reads as true and the round one reads as marketing.

AI: I'll preserve exact figures from now on.

Operator: Actually, going forward, always put the guarantee ABOVE the buy button,
not below it, because the moment of hesitation is right before the click and that
is exactly when they need to be reminded the risk is on us.
