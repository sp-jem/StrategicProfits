# Q3 Performance Report — Finished Deliverable

## Executive Summary

Revenue grew 18% quarter over quarter, driven primarily by the email channel.
Customer acquisition cost fell to $42, and repeat-purchase rate reached 31%.

## Channel Performance

Email remained the strongest channel, contributing 44% of revenue. Paid social
underperformed against target and was scaled back in the final month.

## Recommendations

The business should consolidate spend into the email channel because that is
where the marginal return is currently highest. Inventory must be rebalanced
toward the three best-selling SKUs ahead of the holiday period.

## Outlook

Q4 is projected to continue the upward trend, assuming the email channel holds
and fulfillment capacity scales with demand.
