# Deployment Runbook — Standard Operating Procedure (finished deliverable)

## Before every deploy

You must always back up the production database before deploying, because a
failed migration can corrupt live data and a clean snapshot is the only fast
path back.

You must run the full test suite and wait for a green build, since shipping on
a red build is the most common cause of Friday incidents.

## During the deploy

Always deploy to staging first and smoke-test the checkout flow, because the
checkout path is where revenue-impacting regressions hide.

Never deploy after 4pm local time, because if something breaks there is not
enough of the day left for the on-call engineer to recover calmly.

## Rollback

If error rates exceed 2%, roll back immediately and page the on-call lead, so
that customer impact stays under the SLA window.
