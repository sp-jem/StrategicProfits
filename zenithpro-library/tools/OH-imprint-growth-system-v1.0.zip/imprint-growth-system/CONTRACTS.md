# Imprint Growth System — frozen contracts

Every contract below traces to a constraint in §2 of the BUILD SPEC. If a
change can't name the constraint it serves, it's the generic default the spec
warns about — stop and re-read §2.

## Data shapes (§4)

**Candidate** (Recorder → Judge):
```json
{ "correction": "...", "rationale": "...", "principle": "...",
  "domain": "...", "quote": "...",
  "source": { "type": "live|file", "ref": "session_id or path", "locator": "turn/line" } }
```
A candidate is valid only if `rationale`, `principle`, and `quote` are all
non-empty (C1/C3 — carries-the-why + verbatim quote).

**Verdict** (Judge → Writer): `{ "verdict": "APPEND|BUMP|REJECT", "entry_id"?: "...", "reason"?: "..." }`
- `entry_id` required for BUMP; `reason` required for REJECT.

**Bank entry** (house format, §4):
```
## <DOMAIN>

**<ID>. <generalized principle>.** <stars> *(<date>)*
*Why:* <rationale>
> "<verbatim quote>"
```
Stars (§4 legend): ⭐ = 1 · ⭐⭐ = 2–3 · ⭐⭐⭐ = 4+.

**Ledger line** (`imprint/ledger.jsonl`): `{ "ts", "action": "append|bump", "entry_id", "domain", "source" }`
**Reject line** (`imprint/rejects.jsonl`): `{ "ts", "candidate": {...}, "reason" }`

## Component boundaries

| # | Component | Kind | Constraints | Never does |
|---|-----------|------|-------------|------------|
| 1 | `imprint-capture.py` (Stop hook) | shell-invoked code | C4, C5, §3.1 | no LLM; never blocks the turn; never writes the bank |
| 2 | `recorder.md` (agent) | isolated `claude -p` | C1, C2, C3 | never invents a WHY; never writes anything |
| 3 | `judge.md` (agent) | isolated `claude -p` | C3, C7 | never writes the bank; never drops a reject silently |
| 4 | `writer_core.py` | deterministic code | C6, C7, C8 | never uses a model; acts only on a verdict |
| 5 | `imprint-coldstart.py` | deterministic orchestration | C2, §3.5 | never harvests finished output; same recorder+judge as live |

## The C2 line (the deciding test)
> Is there an actual **correction-with-reason** in this source?  YES → capture (live or recorded).  NO → skip.

Enforced by CONTENT, never by filename/extension:
1. cheap filter (C5) kills obvious non-feedback cheaply (high recall);
2. the recorder emits a candidate **only** when a real correction MOMENT with
   the operator's reasoning is present. Declarative deliverable prose — even
   "X should Y because Z" — is output, not feedback, so it yields nothing.

A finished report named `report.md` and a transcript named `transcript.md` are
distinguished by what's inside them, not by their names. (T6 proves it: the
report trips the cheap filter and is STILL rejected by the recorder.)

## Backends
- `claude` (default, production): each agent is a fresh isolated `claude -p`
  process — replaced system prompt, no MCP, neutral cwd, no inherited project
  context. That isolation IS "logger ≠ doer" (C4). It applies judgment to the
  hard C2 cases (a standard set in conversation = capture; the same sentence in
  an authored SOP = skip).
- `script` (fallback/test): deterministic recorder+judge. Used when the CLI is
  absent (C6 graceful degradation) and for hermetic acceptance tests. Set with
  `IMPRINT_BACKEND=script`.

### Known fallback limitations (by design — the `script` backend is NOT as
### capable as the LLM agents, and is deliberately C2-conservative)
- **Recorder recall.** The deterministic recorder captures only UNAMBIGUOUS
  conversational corrections (a dialogic rejection-of-prior-work marker + a
  rationale). It deliberately SKIPS bare imperative prose ("you must X because
  Y", "never X because Y") because a finished SOP/runbook uses that exact
  grammar and C2 forbids capturing from finished output. Consequence: pure
  standard-setting in conversation that carries no rejection marker (e.g. "from
  now on always cite the date, because…") is MISSED by the fallback. This errs
  toward skip (§3.5: "empty is acceptable; fabricated is not"); the LLM
  recorder captures these correctly.
- **Judge dedup.** The deterministic judge dedups LEXICALLY (token Jaccard ≥
  0.6 on the normalized principle). A synonym-reworded restatement of the same
  rule can score 0 and APPEND as a new entry instead of BUMP. The LLM judge
  catches semantic duplicates; the deterministic exact-key writer backstop
  catches byte-identical ones; synonymic ones can slip in degraded mode.
- **Degradation is logged, not silent.** When the `claude` backend fails and the
  pipeline falls back to `script`, it writes a line to `imprint/.imprint.log`.
- **Writer backstop.** Regardless of backend, the deterministic writer refuses
  to create a second entry with a byte-identical normalized key (converts the
  APPEND to a BUMP) — a hard floor under C7 that does not depend on the judge.
