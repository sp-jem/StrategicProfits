# Imprint Growth System — installer (Windows PowerShell)
# Universal infrastructure: identical for every operator. Drops into an existing
# Obsidian + Claude Code setup. No operator-specific paths are baked in.

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ClaudeDir = Join-Path $env:USERPROFILE ".claude"
$EngineDir = Join-Path $ClaudeDir "imprint-growth-system"

$Python = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $Python) { $Python = (Get-Command python3 -ErrorAction SilentlyContinue).Source }
if (-not $Python) { Write-Host "!! Python 3.8+ not found on PATH. Install it and re-run."; exit 1 }

Write-Host "Installing the Imprint Growth System..."
Write-Host ""

# 1. copy engine (strip build artifacts)
New-Item -ItemType Directory -Force -Path $EngineDir | Out-Null
foreach ($item in @("lib","bin","agents","tests","VERSION","README.md","CONTRACTS.md","manifest.json","config.example.json","install.sh","install.ps1")) {
    $src = Join-Path $ScriptDir $item
    if (Test-Path $src) { Copy-Item $src -Destination $EngineDir -Recurse -Force }
}
Get-ChildItem -Path $EngineDir -Recurse -Directory -Filter "__pycache__" | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "  OK   engine -> $EngineDir"

# 2. configure bank location
Write-Host ""
$Default = if ($args.Count -ge 1) { $args[0] } else { "" }
$Vault = Read-Host "Path to your Obsidian vault (bank will live at <vault>\imprint) [$Default]"
if ([string]::IsNullOrWhiteSpace($Vault)) { $Vault = $Default }
if ([string]::IsNullOrWhiteSpace($Vault)) {
    $ImprintDir = Join-Path $env:USERPROFILE "imprint"
    $cfg = @{ imprint_dir = $ImprintDir; agent_backend = "claude"; claude_bin = "claude" }
} else {
    $ImprintDir = Join-Path $Vault "imprint"
    $cfg = @{ vault = $Vault; imprint_dir = $ImprintDir; agent_backend = "claude"; claude_bin = "claude" }
}
$cfg | ConvertTo-Json | Set-Content (Join-Path $EngineDir "config.json")
New-Item -ItemType Directory -Force -Path $ImprintDir | Out-Null
Write-Host "  OK   bank -> $ImprintDir"

# 3. register the Stop hook (idempotent)
Write-Host ""
& $Python (Join-Path $EngineDir "lib\install_hook.py") register --python $Python --engine $EngineDir

# 4. verify
Write-Host ""
Write-Host "  Verifying (acceptance suite)..."
& $Python (Join-Path $EngineDir "tests\test_acceptance.py") | Select-Object -Last 1

Write-Host ""
Write-Host "Installation complete."
Write-Host ""
Write-Host "OPTIONAL — cold-start from stored feedback (opt-in, resumable):"
Write-Host "  $Python $EngineDir\bin\imprint-coldstart.py --source <folder>"
Write-Host ""
Write-Host "Next: restart Claude Code. Corrections-with-reason are now captured to:"
Write-Host "  $ImprintDir\Operator-Imprint.md"
