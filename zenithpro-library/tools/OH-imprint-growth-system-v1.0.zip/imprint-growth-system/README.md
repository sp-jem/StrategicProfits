# Imprint Growth System

**A separate, deterministically-triggered pipeline that captures your tacit
knowledge at the moment you teach it — a correction with the reason behind it —
and compounds it into your own imprint bank, automatically, without you policing
it.**

This is universal infrastructure: one identical package for every CTD cohort
client and Rich. It drops into the environment you already have — Claude Code +
an Obsidian vault — and grows **your own** bank from **your own** work. Nothing
is hardcoded to anyone's machine.

It is the manifesto's own thesis applied to the system that builds the
manifesto: it separates the **logger** from the **doer**, so capture stops
depending on the working agent's memory or your vigilance.

---

## What it captures (and what it refuses to)

It captures exactly one kind of thing: **feedback caught in the act** — a moment
where you corrected, rejected, or set a standard, *with your reasoning present*.

The deciding test:

> Is there an actual **correction-with-reason** here?  Yes → capture.  No → skip.

- ✅ A turn (or a stored transcript) where you said *"no, don't do X, do Y
  because Z"* → captured.
- ❌ A finished report / draft / SOP with no feedback moment in it → ignored.
  The artifact is the *output* of judgment; the *why* isn't in it.

That line is enforced by **content, not filenames** — see `CONTRACTS.md`.

---

## How it works (5 components)

```
  every turn ends
        │
        ▼
  ① Stop hook  ── cheap filter (no LLM, runs every turn) ──┐ no signal → stop
        │                                                   │
        │ signal (fire-and-forget, zero added latency)      │
        ▼                                                   │
  ② Recorder (isolated agent) ── correction+reason? ──► candidates  (else nothing)
        ▼
  ③ Judge (isolated agent) ──► APPEND · BUMP · REJECT
        ▼
  ④ Writer (deterministic code — never a model) ──► your bank + ledger + rejects
```

Plus **⑤ Cold-start seeder** — a one-time, opt-in, resumable batch that runs the
*same* recorder+judge backward over your stored transcripts. New operators get
an instant head start; it skips every finished deliverable.

Your bank lives in your vault:

```
<vault>/imprint/
  Operator-Imprint.md     # the bank, domain-grouped, house format with ⭐ recurrence
  ledger.jsonl            # every append/bump — review & revert anything
  rejects.jsonl           # parked rejects + reason — never silently dropped
```

---

## Install

```bash
# Mac / Linux
bash install.sh                 # or:  bash install.sh /path/to/your/vault

# Windows (PowerShell)
.\install.ps1                   # or:  .\install.ps1 C:\path\to\your\vault
```

The installer copies the engine to `~/.claude/imprint-growth-system/`, asks
where your bank should live, **registers the Stop hook** in your
`settings.json` (idempotent, with a backup), and runs the acceptance suite.
Restart Claude Code afterward.

**Optional cold-start** (opt-in; large histories are resumable):
```bash
python3 ~/.claude/imprint-growth-system/bin/imprint-coldstart.py --source /folder/of/transcripts
```

### Requirements
- **Claude Code** — so the Stop hook fires and the `claude` CLI is available for the agents.
- **Python 3.8+** — standard library only, no third-party packages.
- **An Obsidian vault** — where your bank lives.

---

## Proof — don't take our word for it

```bash
python3 ~/.claude/imprint-growth-system/tests/test_acceptance.py   # T1..T7, hermetic
IMPRINT_BACKEND=claude python3 ~/.claude/imprint-growth-system/tests/live_demo.py  # real agents
```

The 7 acceptance tests map 1:1 to BUILD-SPEC §5. T6 is the one that proves the
capture line: a folder with a transcript *and* a finished report yields entries
**only** from the transcript.

---

## Notes & tradeoffs

- **Cost.** Each captured signal-turn spends ~2 isolated `claude -p` calls
  (recorder + judge), ≈ $0.10–0.15 total at Sonnet. The cheap filter ensures
  most turns spend nothing. Cold-start cost scales with how much feedback your
  history contains.
- **Graceful degradation.** If the `claude` CLI isn't reachable, the pipeline
  falls back to a deterministic backend so capture never hard-fails. That
  fallback is intentionally C2-conservative: it captures only unambiguous
  conversational corrections and skips authored rule-prose (an SOP line is
  skipped, not harvested), so it misses some standard-setting the LLM would
  catch — it errs toward an empty bank over a fabricated one. The degradation
  is logged to `imprint/.imprint.log`. Set `IMPRINT_BACKEND=claude|script` to
  force one. See `CONTRACTS.md` → "Known fallback limitations."
- **Your asset is protected.** Only the deterministic writer ever changes the
  bank, and only on a judge's verdict. A model never freely rewrites it.
- **Tuning.** Filter markers, model, and the agent prompts live in `lib/` and
  `agents/`. Edit the prompts to sharpen extraction for your domain.

See `CONTRACTS.md` for the frozen data shapes and the constraint each component
is built to.
