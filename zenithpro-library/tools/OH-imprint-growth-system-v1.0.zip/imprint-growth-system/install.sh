#!/usr/bin/env bash
# Imprint Growth System — installer (Mac / Linux)
# Universal infrastructure: identical for every operator. Drops into an existing
# Obsidian + Claude Code setup. No operator-specific paths are baked in.
#
# What it does:
#   1. Copies the engine into ~/.claude/imprint-growth-system/
#   2. Asks where your imprint bank should live (defaults to <vault>/imprint)
#   3. Registers the deterministic Stop hook in ~/.claude/settings.json (idempotent)
#   4. Verifies with the acceptance suite
#   5. Offers an optional one-time cold-start over your stored transcripts

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLAUDE_DIR="${HOME}/.claude"
ENGINE_DIR="${CLAUDE_DIR}/imprint-growth-system"

# pick a python3
PYTHON="$(command -v python3 || true)"
if [ -z "$PYTHON" ]; then
  echo "!! python3 not found on PATH. Install Python 3.8+ and re-run." ; exit 1
fi

echo "Installing the Imprint Growth System..."
echo ""

# 1. copy engine (strip build artifacts; never overwrite an operator's config.json/bank)
mkdir -p "$ENGINE_DIR"
for item in lib bin agents tests VERSION README.md CONTRACTS.md manifest.json config.example.json install.sh install.ps1; do
  if [ -e "${SCRIPT_DIR}/${item}" ]; then
    cp -R "${SCRIPT_DIR}/${item}" "${ENGINE_DIR}/"
  fi
done
find "$ENGINE_DIR" -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find "$ENGINE_DIR" -name "*.pyc" -delete 2>/dev/null || true
echo "  OK   engine -> ${ENGINE_DIR}"

# 2. configure the bank location (portable: per-operator path, asked here)
echo ""
DEFAULT_VAULT=""
if [ -n "$1" ]; then DEFAULT_VAULT="$1"; fi
read -r -p "Path to your Obsidian vault (bank will live at <vault>/imprint) [${DEFAULT_VAULT}]: " VAULT
VAULT="${VAULT:-$DEFAULT_VAULT}"
if [ -z "$VAULT" ]; then
  echo "  (no vault given — bank will default to \$HOME/imprint; you can edit ${ENGINE_DIR}/config.json later)"
  IMPRINT_DIR_PATH="${HOME}/imprint"
  cat > "${ENGINE_DIR}/config.json" <<JSON
{
  "imprint_dir": "${IMPRINT_DIR_PATH}",
  "agent_backend": "claude",
  "claude_bin": "claude"
}
JSON
else
  VAULT="${VAULT/#\~/$HOME}"
  IMPRINT_DIR_PATH="${VAULT}/imprint"
  cat > "${ENGINE_DIR}/config.json" <<JSON
{
  "vault": "${VAULT}",
  "imprint_dir": "${IMPRINT_DIR_PATH}",
  "agent_backend": "claude",
  "claude_bin": "claude"
}
JSON
fi
mkdir -p "$IMPRINT_DIR_PATH"
echo "  OK   bank -> ${IMPRINT_DIR_PATH}"

# 3. register the Stop hook (idempotent; backs up settings.json)
echo ""
"$PYTHON" "${ENGINE_DIR}/lib/install_hook.py" register --python "$PYTHON" --engine "$ENGINE_DIR"

# 4. verify
echo ""
echo "  Verifying (acceptance suite)..."
if "$PYTHON" "${ENGINE_DIR}/tests/test_acceptance.py" >/tmp/imprint_accept.log 2>&1; then
  tail -1 /tmp/imprint_accept.log | sed 's/^/  /'
else
  echo "  !! acceptance suite did not fully pass — see /tmp/imprint_accept.log"
fi

# 5. optional cold-start
echo ""
echo "Installation complete."
echo ""
echo "OPTIONAL — cold-start your bank from stored feedback (opt-in, resumable):"
echo "  Point it at a folder of your saved AI transcripts / feedback docs. It"
echo "  harvests only real corrections-with-reason; finished reports are ignored."
echo "    $PYTHON ${ENGINE_DIR}/bin/imprint-coldstart.py --source <folder>"
echo ""
echo "Next: restart Claude Code. From now on, every turn where you correct your"
echo "AI with a reason is captured automatically to:"
echo "  ${IMPRINT_DIR_PATH}/Operator-Imprint.md   (ledger.jsonl + rejects.jsonl beside it)"
