#!/usr/bin/env python3
"""
script_backend — deterministic, offline recorder + judge.

This is the FALLBACK / TEST backend. Production uses the real isolated
`claude -p` agents (see agents_api + agents/*.md). This module exists so the
pipeline degrades gracefully when the CLI is unavailable (C6 autonomy) and so
the acceptance tests run hermetically and repeatably without API cost.

It honors the same I/O contract as the LLM agents and is deliberately
C2-CONSERVATIVE — it is NOT as capable as the LLM recorder, and does not claim
to be:
  - recorder emits NOTHING unless there is an UNAMBIGUOUS conversational
    correction (a dialogic rejection-of-prior-work marker) WITH a rationale
    (C1/C3). It refuses imperative deliverable prose — an SOP/runbook sentence
    like "you must always back up the DB because ..." has no rejection marker,
    so it is skipped (C2-FORBIDDEN). It errs toward SKIP on anything ambiguous
    (§3.5: "empty is acceptable; fabricated is not"). The LLM recorder, which
    has judgment, captures the standard-setting cases this backend skips.
  - it never invents a rationale (C1) — the WHY must be in the source text.
  - the fallback judge dedups LEXICALLY only (token Jaccard); semantic
    near-duplicates are caught by the LLM judge, not here.
"""

from __future__ import annotations

import re

import imprintlib as L

_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+|\n+")


def _sentences(text: str):
    return [s.strip() for s in _SENT_SPLIT.split(text or "") if s.strip()]


def _guess_domain(text: str) -> str:
    t = text.lower()
    table = [
        ("voice/communication", ["word", "voice", "tone", "phrase", "sentence", "paragraph", "read", "plain", "hype", "say it", "wording"]),
        ("process", ["instruction", "verify", "check", "diff", "deviat", "follow", "directions", "handoff", "ledger", "complete", "claim", "step"]),
        ("decision-making", ["decide", "decision", "judgment", "choose", "choice", "authoriz"]),
        ("strategy", ["strategy", "positioning", "brand", "own", "leverage", "market", "compound"]),
        ("risk", ["risk", "credibility", "safe", "danger", "fail", "skeptic"]),
        ("delegation", ["delegate", "hand off", "agent", "sub-agent", "spawn", "team"]),
        ("standards", ["always", "never", "must", "standard", "rule", "from now on", "going forward"]),
    ]
    for domain, kws in table:
        if any(k in t for k in kws):
            return domain
    if L.has_correction(t):
        return "what-they-reject"
    return "process"


def _principle_from(correction_sentence: str, rationale: str) -> str:
    """Crude but stable generalization for the offline backend. The LIVE
    recorder produces a real generalized principle; this just yields a
    non-empty, deduplicable rule so the pipeline + tests exercise correctly."""
    s = correction_sentence.strip()
    s = re.sub(r"^(no,?|nope,?|actually,?|stop,?)\s+", "", s, flags=re.I)
    s = re.sub(r"\bwhy (the fuck |)would you\b", "do not", s, flags=re.I)
    s = s[0].upper() + s[1:] if s else s
    return s.rstrip(".")


def _is_feedback_moment(text: str) -> bool:
    """C2 core (deterministic): a real correction MOMENT, not deliverable prose.

    Requires BOTH:
      - the WHY is present (rationale), and
      - a DIALOGIC-correction marker — one that presupposes the operator is
        rejecting/contrasting work just produced.

    Bare imperatives ("you must X because Y", "never X", "don't X") are NOT
    sufficient: a finished SOP / runbook / report uses that exact grammar, and
    C2 forbids capturing from finished output. So an imperative deliverable
    sentence trips the cheap filter but is rejected HERE — the rejection is by
    content (no rejection-of-prior signal), never by filename. (T6 / T6-SOP.)"""
    return L.has_rationale(text) and L.has_dialogic_correction(text)


def recorder(moment: dict):
    """Return a list of candidate dicts (possibly empty)."""
    human = moment.get("human", "") or ""
    src = dict(moment.get("source", {}))
    if not _is_feedback_moment(human):
        return []

    sents = _sentences(human)
    # rationale = the sentence carrying a rationale marker (prefer clause after 'because')
    rationale = ""
    corr_sentence = ""
    for s in sents:
        if not corr_sentence and L.has_dialogic_correction(s):
            corr_sentence = s
        if not rationale and L.has_rationale(s):
            rationale = s
    if not corr_sentence:
        corr_sentence = sents[0] if sents else human
    if not rationale:
        # rationale marker present in the whole text but split oddly — fall back to full text
        rationale = human.strip()

    # tighten rationale to the clause after 'because/since/so that' when present
    m = re.search(r"\b(because|since|so that|the reason(?:\s+\w+)? is|otherwise)\b(.*)",
                  rationale, flags=re.I | re.S)
    rationale_clean = (m.group(0).strip() if m else rationale).strip()

    quote = corr_sentence.strip()
    if rationale and rationale not in quote:
        quote = (corr_sentence + " " + rationale).strip()
    quote = quote.strip()

    candidate = {
        "correction": corr_sentence.strip().rstrip("."),
        "rationale": rationale_clean,
        "principle": _principle_from(corr_sentence, rationale_clean),
        "domain": _guess_domain(human),
        "quote": quote,
        "source": {"type": src.get("type", "live"),
                   "ref": src.get("ref", ""),
                   "locator": src.get("locator", "")},
    }
    ok, _ = L.validate_candidate(candidate)
    return [candidate] if ok else []


def _jaccard(a: str, b: str) -> float:
    ta, tb = set(a.split()), set(b.split())
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def judge(candidates, existing):
    """Return one verdict per candidate. existing = [{entry_id, principle, domain}]."""
    verdicts = []
    ex_keys = [(e["entry_id"], L.normalize_key(e.get("principle", ""))) for e in existing]
    for c in candidates:
        ok, problem = L.validate_candidate(c)
        if not ok:
            verdicts.append({"verdict": "REJECT", "reason": f"fails-C3:{problem}"})
            continue
        key = L.normalize_key(c["principle"])
        best_id, best_sim = None, 0.0
        for eid, ekey in ex_keys:
            sim = _jaccard(key, ekey)
            if sim > best_sim:
                best_id, best_sim = eid, sim
        if best_id and best_sim >= 0.6:
            verdicts.append({"verdict": "BUMP", "entry_id": best_id,
                             "reason": f"near-duplicate(sim={best_sim:.2f})"})
        else:
            verdicts.append({"verdict": "APPEND"})
    return verdicts
