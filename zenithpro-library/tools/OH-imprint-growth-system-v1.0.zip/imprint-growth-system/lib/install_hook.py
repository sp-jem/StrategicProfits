#!/usr/bin/env python3
"""
install_hook — idempotently register (or remove) the imprint Stop hook in an
operator's Claude Code settings.json.

This is the piece a plain skill/agent installer doesn't have: the system is a
deterministic-TRIGGER pipeline (C4), so it must wire a real Stop hook. The
cohort install.sh copies files; install.sh calls THIS to wire the trigger.

Idempotent: re-running never duplicates the hook. Always backs up settings.json
first. No operator-specific path is baked in — paths are passed at call time.

    python3 install_hook.py register   --python /path/python3 --engine /path/engine [--settings ~/.claude/settings.json]
    python3 install_hook.py unregister  [--settings ~/.claude/settings.json]
    python3 install_hook.py status      [--settings ~/.claude/settings.json]
"""

import argparse
import json
import shutil
import sys
import time
from pathlib import Path

MARK = "bin/imprint-capture.py"   # how we recognize our own hook entry


def default_settings() -> Path:
    return Path.home() / ".claude" / "settings.json"


def load(settings: Path) -> dict:
    if settings.exists():
        try:
            return json.loads(settings.read_text())
        except json.JSONDecodeError:
            print(f"!! {settings} is not valid JSON; refusing to edit.", file=sys.stderr)
            sys.exit(3)
    return {}


def backup(settings: Path) -> None:
    if settings.exists():
        b = settings.with_suffix(f".json.bak-{int(time.time())}")
        shutil.copy2(settings, b)
        print(f"   backed up settings -> {b.name}")


def is_ours(entry: dict) -> bool:
    for h in entry.get("hooks", []):
        if MARK in h.get("command", ""):
            return True
    return False


def cmd_register(args) -> int:
    settings = Path(args.settings).expanduser()
    cfg = load(settings)
    hooks = cfg.setdefault("hooks", {})
    stop = hooks.setdefault("Stop", [])
    if not isinstance(stop, list):
        print("!! hooks.Stop is not a list; refusing to edit.", file=sys.stderr)
        return 3

    command = f'{args.python} {Path(args.engine).expanduser()}/bin/imprint-capture.py'

    if any(is_ours(e) for e in stop):
        # update the command in place (engine/python may have moved) — still idempotent
        for e in stop:
            for h in e.get("hooks", []):
                if MARK in h.get("command", ""):
                    h["command"] = command
        backup(settings)
        settings.parent.mkdir(parents=True, exist_ok=True)
        settings.write_text(json.dumps(cfg, indent=2))
        print("   imprint Stop hook already present — command refreshed (idempotent).")
        return 0

    stop.append({"hooks": [{"type": "command", "command": command, "timeout": 15}]})
    backup(settings)
    settings.parent.mkdir(parents=True, exist_ok=True)
    settings.write_text(json.dumps(cfg, indent=2))
    print(f"   registered imprint Stop hook -> {command}")
    return 0


def cmd_unregister(args) -> int:
    settings = Path(args.settings).expanduser()
    cfg = load(settings)
    stop = cfg.get("hooks", {}).get("Stop", [])
    if not isinstance(stop, list):
        return 0
    kept = [e for e in stop if not is_ours(e)]
    if len(kept) != len(stop):
        cfg["hooks"]["Stop"] = kept
        backup(settings)
        settings.write_text(json.dumps(cfg, indent=2))
        print("   removed imprint Stop hook.")
    else:
        print("   no imprint Stop hook found.")
    return 0


def cmd_status(args) -> int:
    settings = Path(args.settings).expanduser()
    cfg = load(settings)
    stop = cfg.get("hooks", {}).get("Stop", [])
    present = isinstance(stop, list) and any(is_ours(e) for e in stop)
    print(f"imprint Stop hook registered: {present}")
    return 0 if present else 1


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("register")
    r.add_argument("--python", default="python3")
    r.add_argument("--engine", required=True)
    r.add_argument("--settings", default=str(default_settings()))
    u = sub.add_parser("unregister")
    u.add_argument("--settings", default=str(default_settings()))
    s = sub.add_parser("status")
    s.add_argument("--settings", default=str(default_settings()))
    args = ap.parse_args()
    return {"register": cmd_register, "unregister": cmd_unregister, "status": cmd_status}[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
