#!/usr/bin/env python3
"""
agents_api — the one place the pipeline + seeder call the Recorder and Judge.

Dispatches to either:
  - backend 'claude'  -> a fresh, isolated `claude -p` agent (production, C4)
  - backend 'script'  -> script_backend (offline fallback / hermetic tests)

Both backends honor the identical contract, so the pipeline code is
backend-agnostic. The recorder NEVER invents a rationale (C1); the judge
enforces C3 + C7.
"""

from __future__ import annotations

import json

import imprintlib as L
import script_backend


# --------------------------- Recorder (Component 2) ---------------------------

def _recorder_user_prompt(moment: dict) -> str:
    return (
        "Examine this single exchange for a correction-with-reason. "
        "Operator message and the assistant's reply follow.\n\n"
        f"=== OPERATOR ===\n{moment.get('human','')}\n\n"
        f"=== ASSISTANT (context) ===\n{moment.get('assistant','')[:4000]}\n\n"
        f"=== SOURCE ===\n{json.dumps(moment.get('source', {}))}\n\n"
        "Return ONLY a JSON array of candidate objects (or [] if there is no "
        "correction-with-reason). Each object: "
        '{"correction","rationale","principle","domain","quote","source"}. '
        "Copy the SOURCE object verbatim into each candidate's source field."
    )


def _normalize_candidates(raw, moment) -> list:
    if raw is None:
        return []
    if isinstance(raw, dict):
        raw = raw.get("candidates", [raw]) if "candidates" in raw else [raw]
    if not isinstance(raw, list):
        return []
    out = []
    src = moment.get("source", {})
    for c in raw:
        if not isinstance(c, dict):
            continue
        c.setdefault("source", src)
        if not isinstance(c.get("source"), dict) or not c["source"].get("type"):
            c["source"] = src
        ok, _ = L.validate_candidate(c)   # enforce C1/C3 shape at the boundary
        if ok:
            out.append(c)
    return out


def recorder(moment: dict) -> list:
    backend = L.agent_backend()
    if backend == "claude":
        sys_prompt = L.read_agent_prompt("recorder")
        raw = L.run_claude_agent(sys_prompt, _recorder_user_prompt(moment), timeout=120)
        cands = _normalize_candidates(raw, moment)
        if raw is None:  # CLI failed -> degrade to deterministic backend (C6)
            L.log("recorder: claude backend failed, falling back to script")
            return script_backend.recorder(moment)
        return cands
    return script_backend.recorder(moment)


# ----------------------------- Judge (Component 3) ----------------------------

def _judge_user_prompt(candidates, existing) -> str:
    return (
        "Candidate principles to judge (JSON array):\n"
        f"{json.dumps(candidates, ensure_ascii=False, indent=2)}\n\n"
        "Existing bank principles (for duplicate detection):\n"
        f"{json.dumps(existing, ensure_ascii=False, indent=2)}\n\n"
        "Return ONLY a JSON array with ONE verdict per candidate, in the same "
        'order. Each verdict: {"verdict":"APPEND"|"BUMP"|"REJECT", '
        '"entry_id":"<id, only for BUMP>", "reason":"<why, required for REJECT>"}.'
    )


def _normalize_verdicts(raw, n):
    if isinstance(raw, dict):
        raw = raw.get("verdicts", [raw])
    if not isinstance(raw, list):
        return None
    out = []
    for v in raw:
        if isinstance(v, dict) and v.get("verdict") in L.VALID_VERDICTS:
            out.append(v)
    if len(out) != n:
        return None
    return out


def judge(candidates, existing) -> list:
    if not candidates:
        return []
    backend = L.agent_backend()
    if backend == "claude":
        sys_prompt = L.read_agent_prompt("judge")
        raw = L.run_claude_agent(sys_prompt, _judge_user_prompt(candidates, existing), timeout=120)
        verdicts = _normalize_verdicts(raw, len(candidates))
        if verdicts is None:  # CLI failed / malformed -> deterministic backend (C6)
            L.log("judge: claude backend unusable, falling back to script")
            return script_backend.judge(candidates, existing)
        return verdicts
    return script_backend.judge(candidates, existing)
