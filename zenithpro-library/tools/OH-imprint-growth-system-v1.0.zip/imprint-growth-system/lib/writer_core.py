#!/usr/bin/env python3
"""
writer_core — the DETERMINISTIC writer (Component 4, C8).

A model never writes the bank. The judge emits a verdict; THIS code executes
it against the operator's files. Three actions:

  APPEND  -> new entry, house format, new id, ⭐, ledger line                §3.4 / C7
  BUMP    -> raise matched entry's recurrence + append the new quote, ledger  §3.4 / C7
  REJECT  -> a line in rejects.jsonl, with reason (parked, never dropped)     C6 / C7

The bank markdown is rendered as a pure projection of a structured index
(.imprint-index.json). That makes every write idempotent, house-format
guaranteed, and trivially auditable — and it means the asset can only be
changed through this one deterministic path (C8 protects the asset).
"""

from __future__ import annotations

import json
from pathlib import Path

import imprintlib as L


def _append_jsonl(path: Path, obj: dict) -> None:
    L.ensure_imprint_dir()
    with open(path, "a") as fh:
        fh.write(json.dumps(obj, ensure_ascii=False) + "\n")


def _domain_order(index: dict):
    present = [d for d in L.DEFAULT_DOMAINS if any(
        e.get("domain") == d for e in index["entries"].values())]
    extras = []
    for e in index["entries"].values():
        d = e.get("domain", "")
        if d and d not in present and d not in extras:
            extras.append(d)
    return present + extras


def render_bank(index: dict) -> str:
    out = [L.bank_preamble()]
    entries = index["entries"]
    for domain in _domain_order(index):
        members = [(eid, e) for eid, e in entries.items() if e.get("domain") == domain]
        members.sort(key=lambda kv: kv[1].get("seq", 0))
        if not members:
            continue
        out.append(f"## {domain}\n\n")
        for eid, e in members:
            out.append(L.render_entry(
                eid, e["principle"], e.get("count", 1), e.get("date", L.today()),
                e.get("rationale", ""), e.get("quotes", []),
            ))
            out.append("\n")
    return "".join(out)


def _flush(index: dict) -> None:
    L.write_index(index)
    L.bank_path().write_text(render_bank(index))


def _new_id(index: dict, domain: str) -> str:
    prefix = L.domain_prefix(domain)
    seq = index.setdefault("seq", {})
    seq[prefix] = seq.get(prefix, 0) + 1
    eid = f"{prefix}{seq[prefix]}"
    # guard against collision with any pre-existing id
    while eid in index["entries"]:
        seq[prefix] += 1
        eid = f"{prefix}{seq[prefix]}"
    return eid


def _find_by_key(index: dict, key: str):
    for eid, e in index["entries"].items():
        if e.get("key") == key:
            return eid
    return None


def do_append(candidate: dict, index: dict, _failsafe_from: str = None) -> str:
    key = L.normalize_key(candidate["principle"])
    domain = (candidate.get("domain") or "process").strip()
    eid = _new_id(index, domain)
    order = max([e.get("seq", 0) for e in index["entries"].values()] + [0]) + 1
    index["entries"][eid] = {
        "principle": candidate["principle"].strip(),
        "domain": domain,
        "count": 1,
        "date": L.today(),
        "rationale": candidate["rationale"].strip(),
        "quotes": [candidate["quote"].strip().strip('"')],
        "key": key,
        "seq": order,
    }
    line = {
        "ts": L.now_iso(), "action": "append", "entry_id": eid,
        "domain": domain, "source": candidate.get("source", {}),
    }
    if _failsafe_from:
        line["failsafe_from_bump"] = _failsafe_from   # faithful audit trail (C6)
    _append_jsonl(L.ledger_path(), line)
    return eid


def do_bump(candidate: dict, entry_id: str, index: dict) -> str:
    e = index["entries"].get(entry_id)
    if e is None:
        # Judge pointed at a non-existent entry → fail safe to APPEND (never lose the asset),
        # and record the divergence in the ledger so the audit trail stays faithful (C6).
        L.log(f"BUMP target {entry_id} missing; appending instead")
        return do_append(candidate, index, _failsafe_from=entry_id)
    e["count"] = e.get("count", 1) + 1
    q = candidate["quote"].strip().strip('"')
    if q and q not in e["quotes"]:
        e["quotes"].append(q)
    e["date"] = L.today()
    _append_jsonl(L.ledger_path(), {
        "ts": L.now_iso(), "action": "bump", "entry_id": entry_id,
        "domain": e["domain"], "source": candidate.get("source", {}),
    })
    return entry_id


def do_reject(candidate: dict, reason: str) -> None:
    _append_jsonl(L.rejects_path(), {
        "ts": L.now_iso(), "candidate": candidate, "reason": reason,
    })


def apply_verdicts(pairs) -> dict:
    """pairs: list of (candidate, verdict). Executes all of them. Returns a summary.

    verdict = {"verdict": "APPEND"|"BUMP"|"REJECT", "entry_id"?, "reason"?}
    """
    summary = {"append": [], "bump": [], "reject": []}
    with L.file_lock():
        index = L.read_index()
        if "entries" not in index:
            index = {"entries": {}, "seq": {}}
        for candidate, verdict in pairs:
            ok, problem = L.validate_verdict(verdict)
            if not ok:
                do_reject(candidate, f"invalid-verdict:{problem}")
                summary["reject"].append(problem)
                continue
            v = verdict["verdict"]
            if v == "APPEND":
                # Deterministic exact-duplicate backstop (hardens C7): the judge
                # owns semantic dedup, but the writer refuses to create a
                # byte-identical normalized-key duplicate even on an APPEND
                # verdict — protecting the asset (C8). Exact-key match → BUMP.
                dup = _find_by_key(index, L.normalize_key(candidate["principle"]))
                if dup is not None:
                    L.log(f"APPEND collided with existing key (entry {dup}); bumping instead")
                    eid = do_bump(candidate, dup, index)
                    summary["bump"].append(eid)
                else:
                    eid = do_append(candidate, index)
                    summary["append"].append(eid)
            elif v == "BUMP":
                eid = do_bump(candidate, verdict["entry_id"], index)
                summary["bump"].append(eid)
            elif v == "REJECT":
                do_reject(candidate, verdict.get("reason", "rejected"))
                summary["reject"].append(verdict.get("reason", "rejected"))
        _flush(index)
    return summary


def seed_entry(candidate: dict) -> str:
    """Test/utility helper: deterministically APPEND one candidate (no judge)."""
    index = L.read_index()
    if "entries" not in index:
        index = {"entries": {}, "seq": {}}
    eid = do_append(candidate, index)
    _flush(index)
    return eid
