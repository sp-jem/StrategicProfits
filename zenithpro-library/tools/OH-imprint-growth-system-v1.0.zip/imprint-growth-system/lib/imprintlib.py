#!/usr/bin/env python3
"""
imprintlib — shared core for the Imprint Growth System.

Single source of truth for every contract the five components share:
  - data schemas (candidate / verdict / ledger / reject)         §4
  - the cheap C5 filter (used by BOTH the hook and the seeder)   C5
  - transcript-tail parsing (Claude Code JSONL)                  §3.1
  - the bank house-format read/write + dedup index               §4 / C8
  - portable path resolution (NO operator-specific hardcoding)   §1 / T7
  - the agent adapter (recorder/judge run as isolated claude -p) C4

EVERY design choice here points at a constraint in §2 of the BUILD SPEC.
If a future edit can't name the constraint it serves, it is the generic
default the spec warns about — stop and re-read §2.

Pure standard-library. Python 3.8+. No third-party deps (portability, §1).
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# 0. Version / identity
# ---------------------------------------------------------------------------

PACKAGE = "imprint-growth-system"
ENGINE_DIR = Path(__file__).resolve().parent.parent  # ~/.claude/imprint-growth-system


def _read_version() -> str:
    try:
        return (ENGINE_DIR / "VERSION").read_text().strip()
    except OSError:
        return "0.0.0"


VERSION = _read_version()


# ---------------------------------------------------------------------------
# 1. Portable path resolution  (§1 portability rule, T7)
#    Nothing is hardcoded to any one operator's machine. Order of resolution:
#      1. explicit env overrides (used by tests + power users)
#      2. config.json next to the engine (written by the installer)
#      3. conservative portable defaults derived from $HOME
# ---------------------------------------------------------------------------

def _config_path() -> Path:
    return Path(os.environ.get("IMPRINT_CONFIG", str(ENGINE_DIR / "config.json")))


def load_config() -> dict:
    p = _config_path()
    if p.exists():
        try:
            return json.loads(p.read_text())
        except (OSError, json.JSONDecodeError):
            return {}
    return {}


def imprint_dir() -> Path:
    """The operator's bank directory: <vault>/imprint by default.

    Resolution (T7 — no operator-specific path baked into code):
      IMPRINT_DIR env  >  config.imprint_dir  >  config.vault/imprint  >  $HOME/imprint
    """
    env = os.environ.get("IMPRINT_DIR")
    if env:
        return Path(env).expanduser()
    cfg = load_config()
    if cfg.get("imprint_dir"):
        return Path(cfg["imprint_dir"]).expanduser()
    if cfg.get("vault"):
        return Path(cfg["vault"]).expanduser() / "imprint"
    return Path(os.environ.get("HOME", str(Path.home()))) / "imprint"


def bank_path() -> Path:
    # Default leaf name is the §6-decided convention; overridable for operators
    # with a naming/localization need (escape hatch — keeps the default frozen).
    name = os.environ.get("IMPRINT_BANK_NAME") or load_config().get("bank_filename") or "Operator-Imprint.md"
    return imprint_dir() / name


def ledger_path() -> Path:
    return imprint_dir() / "ledger.jsonl"


def rejects_path() -> Path:
    return imprint_dir() / "rejects.jsonl"


def index_path() -> Path:
    # Writer-owned sidecar: entry_id -> {count, principle, domain, key}.
    # Lets the deterministic writer compute stars + execute BUMPs (C7/C8)
    # without ever asking a model to re-parse the bank.
    return imprint_dir() / ".imprint-index.json"


def coldstart_progress_path() -> Path:
    return imprint_dir() / ".coldstart-progress.json"


def log_path() -> Path:
    return imprint_dir() / ".imprint.log"


def ensure_imprint_dir() -> Path:
    d = imprint_dir()
    d.mkdir(parents=True, exist_ok=True)
    return d


def agent_backend() -> str:
    """'claude' (production, real isolated agents) or 'script' (offline/test).

    Default is 'claude' when the CLI is reachable; falls back to 'script'
    so the pipeline degrades gracefully instead of failing (C6 autonomy).
    Tests pin this with IMPRINT_BACKEND=script for hermetic, repeatable runs.
    """
    env = os.environ.get("IMPRINT_BACKEND")
    if env:
        return env
    cfg = load_config()
    if cfg.get("agent_backend"):
        return cfg["agent_backend"]
    return "claude" if claude_available() else "script"


def claude_bin() -> str:
    return os.environ.get("IMPRINT_CLAUDE_BIN") or load_config().get("claude_bin") or "claude"


def claude_available() -> bool:
    from shutil import which
    return which(claude_bin()) is not None


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def log(msg: str) -> None:
    try:
        ensure_imprint_dir()
        with open(log_path(), "a") as fh:
            fh.write(f"{now_iso()}  {msg}\n")
    except OSError:
        pass


# ---------------------------------------------------------------------------
# 2. Domains (§4) — a SMALL general taxonomy; the judge may add new ones.
#    Any one operator's specialized domains are deliberately NOT hardcoded. (§1, §4)
# ---------------------------------------------------------------------------

DEFAULT_DOMAINS = [
    "decision-making",
    "standards",
    "voice/communication",
    "delegation",
    "risk",
    "process",
    "strategy",
    "what-they-reject",
]


def domain_prefix(domain: str) -> str:
    """Derive a short, stable ID prefix from a domain name (house style: V1, R1...).

    'voice/communication' -> 'VC' ; 'process' -> 'P' ; 'what-they-reject' -> 'WTR'.
    Deterministic so the writer can generate collision-free IDs.
    """
    words = re.split(r"[\s/_\-]+", domain.strip().lower())
    words = [w for w in words if w]
    if not words:
        return "X"
    if len(words) == 1:
        return words[0][0].upper()
    return "".join(w[0].upper() for w in words)


# ---------------------------------------------------------------------------
# 3. The cheap C5 filter  (C5 — runs on EVERY turn, must stay cheap)
#    High recall, low precision by design: a missed correction is a lost
#    asset (the whole point); a false positive only costs the recorder a
#    look and it will emit nothing. The recorder + judge are the precision
#    gates, NOT this filter.
#
#    Decision is content-based, never filename-based (this is the C2 guard:
#    a finished report named report.md vs transcript.md is distinguished by
#    whether its CONTENT contains a correction-with-reason, not by its name).
# ---------------------------------------------------------------------------

# A correction/rejection is inherently dialogic / 2nd-person — the operator
# pushing back on work. Declarative deliverable prose lacks these.
CORRECTION_MARKERS = [
    r"\bno,", r"\bnope\b", r"\bdon'?t\b", r"\bdo not\b", r"\bnever\b",
    r"\bstop\b", r"\bwrong\b", r"\bthat'?s not\b", r"\bnot (?:that|this|what)\b",
    r"\binstead\b", r"\bactually\b", r"\bwhy (?:would|the fuck|are|did|is|wouldn'?t) you\b",
    r"\byou (?:missed|keep|always|never|didn'?t|deviat|ignored|dropped|missed)",
    r"\bi told you\b", r"\bfix\b", r"\brevert\b", r"\bundo\b", r"\bredo\b",
    r"\bthat'?s wrong\b", r"\bkill(?:ed)? (?:the|that|this)\b", r"\bcut (?:the|that|this)\b",
    r"\bnot like (?:that|this)\b", r"\brather than\b", r"\bshould(?:'?ve| have) (?:been|done)\b",
]

# Standard-setting markers (the operator declaring a durable rule).
STANDARD_MARKERS = [
    r"\balways\b", r"\bnever\b", r"\bmust\b", r"\bfrom now on\b", r"\bgoing forward\b",
    r"\bthe rule is\b", r"\bmake sure\b", r"\bthe standard is\b",
    r"\bi (?:want|need) you to\b", r"\bevery time\b", r"\bby default\b",
]

# Rationale markers — the WHY must be present for a valid capture (C1/C3).
RATIONALE_MARKERS = [
    r"\bbecause\b", r"\bsince\b", r"\bthe reason\b", r"\bso that\b", r"\botherwise\b",
    r"\bthe point is\b", r"\bthat way\b", r"\bwhich is why\b", r"\bthe whole point\b",
    r"\bso (?:we|you|it|they|i)\b", r"\bto avoid\b", r"\belse\b", r"\bif (?:we|you) don'?t\b",
]

# 2nd-person directive markers — kept for the cheap filter's high-recall pass.
DIRECTIVE_MARKERS = [
    r"\byou\b", r"\bdon'?t\b", r"\bdo not\b", r"\bmake sure\b", r"\bi want\b",
    r"\bi need you\b", r"\bgoing forward\b", r"\bfrom now on\b", r"\bnever\b", r"\balways\b",
]

# DIALOGIC-CORRECTION markers — the ONLY thing the deterministic recorder trusts
# as proof of a real correction MOMENT (C2). Each presupposes that the operator
# is rejecting/contrasting work the AI just produced — a signal that a finished
# deliverable (report / draft / SOP / runbook) does NOT carry. Bare imperatives
# ("you must X", "never X", "don't X because Y") are deliberately EXCLUDED here:
# an SOP uses that exact grammar, so they cannot prove a correction moment. The
# fallback therefore errs toward SKIP on ambiguous imperative prose (§3.5:
# "empty is acceptable; fabricated is not"); the LLM recorder resolves those
# cases with judgment. This is the deterministic guard for C2-FORBIDDEN.
DIALOGIC_CORRECTION_MARKERS = [
    r"\bno,", r"\bnope\b", r"\bactually,?\b", r"\binstead\b", r"\brather than\b",
    r"\bthat'?s not\b", r"\bthat'?s wrong\b", r"\bnot like (?:that|this)\b",
    r"\bnot (?:that|this|what)\b",
    r"\byou (?:keep|missed|didn'?t|already|just|again|deviat|ignored|dropped|forgot|were supposed)\b",
    r"\bwhy (?:would|the fuck would|are|did|wouldn'?t) you\b",
    r"\bi told you\b", r"\brevert\b", r"\bundo\b", r"\bredo\b",
    r"\bstop (?:using|doing|saying|writing|adding|putting|making|calling|treating)\b",
    r"\bkill(?:ed)? (?:the|that|this)\b", r"\bcut (?:the|that|this)\b",
]

_NOISE_REPLIES = {
    "yes", "no", "ok", "okay", "thanks", "thank you", "sure", "yep", "yeah",
    "go", "do it", "proceed", "continue", "great", "perfect", "nice", "cool",
    "k", "y", "n", "good", "done",
}


def _any(patterns, text_lower: str) -> bool:
    return any(re.search(p, text_lower) for p in patterns)


def _matched(patterns, text_lower: str):
    return [p for p in patterns if re.search(p, text_lower)]


def has_rationale(text: str) -> bool:
    return _any(RATIONALE_MARKERS, (text or "").lower())


def has_correction(text: str) -> bool:
    return _any(CORRECTION_MARKERS, (text or "").lower())


def has_standard(text: str) -> bool:
    return _any(STANDARD_MARKERS, (text or "").lower())


def has_directive(text: str) -> bool:
    return _any(DIRECTIVE_MARKERS, (text or "").lower())


def has_dialogic_correction(text: str) -> bool:
    """True only if the text carries a marker that presupposes the operator is
    correcting work just produced — the deterministic proxy for a real
    correction moment (C2). Imperative SOP/runbook prose does not trip this."""
    return _any(DIALOGIC_CORRECTION_MARKERS, (text or "").lower())


def cheap_filter(text: str):
    """C5 gate. Returns (passed: bool, reason: str).

    Passes when a correction OR a standard marker is present and the message
    is not a trivial one-word ack. Deliberately high recall.
    """
    if not text or not text.strip():
        return False, "empty"
    norm = text.strip().lower()
    # kill the cheapest false positives: one-word acknowledgements
    if norm.strip(".!? ") in _NOISE_REPLIES:
        return False, "noise-reply"
    tl = norm
    corr = _matched(CORRECTION_MARKERS, tl)
    std = _matched(STANDARD_MARKERS, tl)
    if corr or std:
        kind = "correction" if corr else "standard"
        return True, f"{kind}:{(corr or std)[0]}"
    return False, "no-signal"


# ---------------------------------------------------------------------------
# 4. Transcript-tail parsing — the live capture path (§3.1)
#    Claude Code Stop-hook gives transcript_path (a .jsonl). We read the
#    LAST exchange only (§3.1): the operator's most recent real message +
#    the assistant text that followed it. The correction lives in the
#    operator's message; the assistant text is context for the recorder.
# ---------------------------------------------------------------------------

def _text_from_content(content) -> str:
    """Flatten a message.content (str OR list-of-blocks) to plain text.
    Tool-result blocks are NOT operator speech — they are skipped."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for b in content:
            if not isinstance(b, dict):
                continue
            t = b.get("type")
            if t == "text":
                parts.append(b.get("text", ""))
            # 'tool_result' / 'tool_use' / 'thinking' are not human speech
        return "\n".join(p for p in parts if p)
    return ""


def _is_human_message(obj: dict) -> bool:
    """A real operator prompt: a user-type line whose content is human text,
    not a tool_result envelope and not a slash-command meta line."""
    if obj.get("type") != "user":
        return False
    msg = obj.get("message")
    if not isinstance(msg, dict) or msg.get("role") != "user":
        return False
    content = msg.get("content")
    if isinstance(content, str):
        return bool(content.strip())
    if isinstance(content, list):
        # human iff it carries at least one text block and no tool_result-only payload
        has_text = any(isinstance(b, dict) and b.get("type") == "text" for b in content)
        only_tool = all(isinstance(b, dict) and b.get("type") == "tool_result" for b in content) and content
        return has_text and not only_tool
    return False


def extract_last_exchange(transcript_path: str) -> dict:
    """Return {'human': str, 'assistant': str, 'source': {...}} for the last
    operator turn in the transcript. Robust to partial/truncated JSONL."""
    p = Path(transcript_path)
    lines = []
    try:
        with open(p, "r", errors="replace") as fh:
            for ln in fh:
                ln = ln.strip()
                if not ln:
                    continue
                try:
                    lines.append(json.loads(ln))
                except json.JSONDecodeError:
                    continue
    except OSError:
        return {"human": "", "assistant": "", "source": {"type": "live", "ref": str(p), "locator": ""}}

    # find index of last human message
    last_human_idx = None
    for i in range(len(lines) - 1, -1, -1):
        if _is_human_message(lines[i]):
            last_human_idx = i
            break

    session_id = ""
    for o in reversed(lines):
        if o.get("sessionId"):
            session_id = o["sessionId"]
            break

    if last_human_idx is None:
        return {"human": "", "assistant": "",
                "source": {"type": "live", "ref": session_id or str(p), "locator": ""}}

    human = _text_from_content(lines[last_human_idx]["message"].get("content"))

    # assistant text AFTER the human message, up to the next human message
    assistant_parts = []
    for o in lines[last_human_idx + 1:]:
        if _is_human_message(o):
            break
        if o.get("type") == "assistant":
            msg = o.get("message", {})
            assistant_parts.append(_text_from_content(msg.get("content")))
    assistant = "\n".join(p for p in assistant_parts if p)

    locator = lines[last_human_idx].get("uuid", "") or f"line{last_human_idx}"
    return {
        "human": human,
        "assistant": assistant,
        "source": {"type": "live", "ref": session_id or str(p), "locator": locator},
    }


# ---------------------------------------------------------------------------
# 5. Candidate / verdict schema validation  (§4)
# ---------------------------------------------------------------------------

CANDIDATE_FIELDS = ["correction", "rationale", "principle", "domain", "quote", "source"]


def validate_candidate(c: dict):
    """Return (ok, problem). A candidate is structurally valid only if all
    fields are present AND it carries a non-empty rationale + quote (C1/C3)."""
    if not isinstance(c, dict):
        return False, "not-an-object"
    for f in CANDIDATE_FIELDS:
        if f not in c:
            return False, f"missing-field:{f}"
    if not str(c.get("rationale", "")).strip():
        return False, "no-why"          # C3: the WHY is mandatory
    if not str(c.get("principle", "")).strip():
        return False, "no-principle"
    if not str(c.get("quote", "")).strip():
        return False, "no-quote"        # C3: verbatim quote mandatory
    src = c.get("source")
    if not isinstance(src, dict) or "type" not in src:
        return False, "bad-source"
    return True, ""


VALID_VERDICTS = {"APPEND", "BUMP", "REJECT"}


def validate_verdict(v: dict):
    if not isinstance(v, dict):
        return False, "not-an-object"
    if v.get("verdict") not in VALID_VERDICTS:
        return False, "bad-verdict"
    if v["verdict"] == "BUMP" and not v.get("entry_id"):
        return False, "bump-without-entry_id"
    if v["verdict"] == "REJECT" and not str(v.get("reason", "")).strip():
        return False, "reject-without-reason"
    return True, ""


# ---------------------------------------------------------------------------
# 6. Bank house-format  (§4)  — read / render / index
#    Matches the house style fixed in BUILD-SPEC §4:
#
#      ## <DOMAIN>
#
#      **<ID>. <principle>.** <stars> *(<date>)*
#      *Why:* <rationale>
#      > "<verbatim quote>"
# ---------------------------------------------------------------------------

STARS = {1: "⭐", 2: "⭐⭐", 3: "⭐⭐⭐"}


def stars_for_count(count: int) -> str:
    """Recurrence legend (§4): 1->⭐  2-3->⭐⭐  4+->⭐⭐⭐."""
    if count >= 4:
        return "⭐⭐⭐"
    if count >= 2:
        return "⭐⭐"
    return "⭐"


def normalize_key(principle: str) -> str:
    """A stable comparison key for dedup-execution (the writer's index).
    The JUDGE owns the dedup decision (C7); this only helps the writer
    locate/store entries deterministically."""
    s = (principle or "").lower()
    s = re.sub(r"[^a-z0-9\s]", " ", s)
    tokens = [t for t in s.split() if len(t) > 2]
    return " ".join(sorted(set(tokens)))


def render_entry(entry_id: str, principle: str, count: int, date: str,
                 rationale: str, quotes) -> str:
    principle = principle.strip().rstrip(".")
    if isinstance(quotes, str):
        quotes = [quotes]
    qlines = "\n".join(f'> "{q.strip().strip(chr(34))}"' for q in quotes if q and q.strip())
    return (
        f"**{entry_id}. {principle}.** {stars_for_count(count)} *({date})*\n"
        f"*Why:* {rationale.strip()}\n"
        f"{qlines}\n"
    )


_BANK_HEADER = "# Operator Imprint — tacit-knowledge bank\n"


def bank_preamble() -> str:
    return (
        _BANK_HEADER
        + "\n"
        + "> Auto-grown by the Imprint Growth System: corrections you made — with the WHY —\n"
        + "> captured the moment you taught them. Every entry traces to a verbatim quote.\n"
        + "> Recurrence legend: ⭐ = 1 occurrence · ⭐⭐ = 2–3 · ⭐⭐⭐ = 4+ (hardest-won).\n"
        + f"> Every append/bump is logged in ledger.jsonl; every reject is parked in rejects.jsonl.\n"
        + "\n"
    )


def read_index() -> dict:
    p = index_path()
    if p.exists():
        try:
            return json.loads(p.read_text())
        except (OSError, json.JSONDecodeError):
            return {"entries": {}, "seq": {}}
    return {"entries": {}, "seq": {}}


def write_index(idx: dict) -> None:
    ensure_imprint_dir()
    index_path().write_text(json.dumps(idx, ensure_ascii=False, indent=2))


def existing_principles() -> list:
    """List of {entry_id, principle, domain} for the judge's dedup input (C7)."""
    idx = read_index()
    out = []
    for eid, rec in idx.get("entries", {}).items():
        out.append({"entry_id": eid, "principle": rec.get("principle", ""),
                    "domain": rec.get("domain", "")})
    return out


def read_bank_text() -> str:
    p = bank_path()
    if p.exists():
        try:
            return p.read_text()
        except OSError:
            return ""
    return ""


# ---------------------------------------------------------------------------
# 7. Agent adapter  (C4) — recorder/judge as ISOLATED main-thread agents.
#    Backend 'claude': a fresh `claude -p` process with a REPLACED system
#    prompt, no MCP, no inherited project context, no tools. That isolation
#    is exactly "logger ≠ doer": the capture agent shares nothing with the
#    working session. Backend 'script': deterministic offline fallback/test.
# ---------------------------------------------------------------------------

def _strip_fences(text: str) -> str:
    t = text.strip()
    if t.startswith("```"):
        t = re.sub(r"^```[a-zA-Z0-9]*\n", "", t)
        t = re.sub(r"\n```$", "", t.strip())
    return t.strip()


def _extract_json(text: str):
    """Pull the first top-level JSON value out of an agent's text reply."""
    t = _strip_fences(text)
    try:
        return json.loads(t)
    except json.JSONDecodeError:
        pass
    # find first balanced [ ... ] or { ... }
    for opener, closer in (("[", "]"), ("{", "}")):
        start = t.find(opener)
        if start == -1:
            continue
        depth = 0
        for i in range(start, len(t)):
            if t[i] == opener:
                depth += 1
            elif t[i] == closer:
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(t[start:i + 1])
                    except json.JSONDecodeError:
                        break
    return None


def run_claude_agent(system_prompt: str, user_prompt: str, timeout: int = 120):
    """Spawn one isolated, lean `claude -p` agent. Returns parsed JSON or None."""
    argv = [
        claude_bin(), "-p", user_prompt,
        "--system-prompt", system_prompt,
        "--model", os.environ.get("IMPRINT_MODEL", "sonnet"),
        "--output-format", "json",
        "--setting-sources", "project",          # don't inherit user/global CLAUDE.md
        "--strict-mcp-config",                    # no MCP servers (isolation, speed)
        "--exclude-dynamic-system-prompt-sections",
    ]
    try:
        proc = subprocess.run(
            argv, capture_output=True, text=True, timeout=timeout,
            cwd=str(ENGINE_DIR),                  # neutral cwd: no project CLAUDE.md
        )
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        log(f"claude agent error: {e}")
        return None
    if proc.returncode != 0:
        log(f"claude agent non-zero exit {proc.returncode}: {proc.stderr[:300]}")
        return None
    try:
        envelope = json.loads(proc.stdout)
        result_text = envelope.get("result", "")
    except json.JSONDecodeError:
        result_text = proc.stdout
    return _extract_json(result_text)


def read_agent_prompt(name: str) -> str:
    return (ENGINE_DIR / "agents" / f"{name}.md").read_text()


# ---------------------------------------------------------------------------
# 8. Best-effort cross-process write lock (fire-and-forget hooks may overlap).
#    Serializes the writer's read-modify-write of the bank/index. POSIX only;
#    a no-op where fcntl is unavailable (writes are sequential per session,
#    so collisions are rare regardless).
# ---------------------------------------------------------------------------

from contextlib import contextmanager


@contextmanager
def file_lock():
    ensure_imprint_dir()
    lock_file = imprint_dir() / ".lock"
    fh = None
    try:
        fh = open(lock_file, "w")
        try:
            import fcntl
            fcntl.flock(fh, fcntl.LOCK_EX)
        except Exception:
            pass
        yield
    finally:
        if fh is not None:
            try:
                import fcntl
                fcntl.flock(fh, fcntl.LOCK_UN)
            except Exception:
                pass
            fh.close()
