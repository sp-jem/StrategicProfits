# Webinar Launch Orchestrator — Student Guide

## What This Is

**This is a META-SKILL.** It does not write copy, build campaigns, or do research itself. It orchestrates 8 other skills in the correct sequence to take you from "I have an offer" to "my webinar campaign is live and running."

Think of it as a project manager that knows exactly which skill to call, in what order, what to pass between them, and when to pause for your review. You talk to Kai (the orchestrator persona), and Kai hands you off to the right specialist at each step — then connects the outputs so nothing falls through the cracks.

---

## The 8 Skills It Chains

| # | Skill | What It Does | Phase | Need Installed? |
|---|-------|-------------|-------|-----------------|
| 1 | `cpa-calculator-budget-planner` | Calculates your unit economics — break-even CPA, target CPA, budget tier | Pre-Flight | Yes |
| 2 | `pains-hopes-gap-analyzer` | Deep market research — 150+ pains/hopes, competitive gaps, 35+ ad angles | Phase 1 | Yes |
| 3 | `ad-prediction-machine` | Ranks your ad angles into S/A/B/C tiers with a budget-aware test plan | Phase 1 | Yes |
| 4 | `webinar-kern` | Builds the complete webinar system — pre-webinar funnel, 5-phase presentation, post-webinar conversion | Phase 2 | Yes |
| 5 | `landing-page-copy` | Writes registration page copy (and liquidator offer page if applicable) | Phase 3 | Yes |
| 6 | `email-sequence-architect` | Builds all 4 email sequences — confirmation, reminders, countdown, no-show | Phase 4 | Yes |
| 7 | `ad-copy-creator` | Produces platform-specific ad copy — 5-8 variations per platform | Phase 5 | Yes |
| 8 | `facebook-ad-setup-walkthrough` OR `youtube-campaign-setup` | Walks you through building the actual campaigns field by field | Phase 6 | Yes (one or both) |

**Important:** The orchestrator itself is what this installer provides. The 8 skills above must already be installed separately. If you are missing any, the orchestrator will tell you which one it needs when it reaches that phase.

---

## Prerequisites

Before you run this skill, you need:

1. **An offer to sell** — a product, service, program, or course. If you do not have one yet, the orchestrator will redirect you to the Offer Architect skill first.
2. **A price point** — what you are charging.
3. **Basic knowledge of your audience** — who they are, their primary problem, where they hang out online.

Optional (but speeds things up if you have them):
- Psychographic Excavation output
- Pains & Hopes Gap Analyzer output (from a previous run)
- Ad Prediction Machine output (from a previous run)
- Core Concept / validated positioning
- Existing webinar content or presentation

---

## The 6 Phases

The orchestrator walks you through 6 sequential phases. Each phase produces deliverables that feed into the next. You cannot skip phases or build out of order.

### Phase 1: Audience & Angles (30-60 min)
**Skills used:** `pains-hopes-gap-analyzer` + `ad-prediction-machine`

Deep market research, competitive gap analysis, 35+ ad angles generated, then ranked into S/A/B/C tiers with a test plan. These angles drive everything downstream — your webinar messaging, registration page, emails, and ads.

### Phase 2: Webinar Content (60-90 min)
**Skill used:** `webinar-kern`

Builds the complete webinar system: pre-webinar funnel (liquidator offer + indoctrination sequences), the 5-phase webinar presentation (Confirmation, Difference, Bond, Payoff, Offer), and post-webinar conversion system (objection videos, countdown emails, replay strategy).

### Phase 3: Registration System (20-30 min)
**Skill used:** `landing-page-copy`

Writes your webinar registration page copy — headline, benefits, social proof, CTA. If the webinar system recommended a liquidator offer, that page gets written too.

### Phase 4: Email Sequences (30-45 min)
**Skill used:** `email-sequence-architect`

Builds 4 email sequences (13-16 emails total): registration confirmation + indoctrination, day-of reminders, post-webinar countdown, and no-show recovery.

### Phase 5: Ad Copy (20-30 min)
**Skill used:** `ad-copy-creator`

Produces platform-specific ad copy using your top-ranked angles from Phase 1. 5-8 variations per platform, character-count validated, with recommended test order.

### Phase 6: Campaign Setup (30-45 min)
**Skill used:** `facebook-ad-setup-walkthrough` or `youtube-campaign-setup`

Walks you through building the actual ad campaigns on your chosen platform — every field, every setting, step by step.

---

## How to Trigger It

Type any of the following into Claude Code:

```
/webinar-launch-orchestrator
```

Or say:
- "launch my webinar"
- "webinar launch"
- "set up my webinar campaign"
- "I want to do a webinar"
- "webinar funnel"
- "end-to-end webinar"

---

## Time Estimate

**2-4 hours across multiple sessions.**

Each phase has a save point. You can pause after any phase and pick up exactly where you left off. The orchestrator maintains a Launch Brief and Launch Tracker that persist between sessions — just re-read them when you return.

A typical split:
- **Session 1:** Pre-Flight + Phase 1 + Phase 2 (~2 hours)
- **Session 2:** Phase 3 + Phase 4 + Phase 5 + Phase 6 (~1.5 hours)

Or do one phase per session if you prefer. The save points make it flexible.

---

## Installation

### Option A: Automatic (Recommended)

1. Open **Terminal** (Applications > Utilities > Terminal)
2. Navigate to this folder:
   ```
   cd ~/Desktop/Webinar-Launch-Orchestrator-Installer
   ```
3. Run the installer:
   ```
   chmod +x install.sh && ./install.sh
   ```
4. Restart Claude Code

### Option B: Manual

Copy the skill folder from `skills/` into your Claude skills directory:

```
~/.claude/skills/webinar-launch-orchestrator/    <- Copy entire folder
```

Restart Claude Code after copying.

---

## What You Get When It's Done

By the end of all 6 phases, the orchestrator will have produced:

1. **Market Research** — 150+ pains/hopes, competitive coverage matrix, gap analysis, 35+ ad angles
2. **Ranked Ad Angles** — S/A/B/C-tier scorecards with budget-aware test plan
3. **Complete Webinar System** — pre-webinar funnel, 5-phase presentation script, post-webinar conversion machine
4. **Registration Page Copy** — headline, benefits, proof, CTA (+ liquidator offer page if applicable)
5. **Email Sequences** — 13-16 emails across 4 sequences (confirmation, reminders, countdown, no-show)
6. **Ad Copy** — 5-8 platform-specific variations, character-count validated
7. **Configured Campaigns** — ready-to-launch ad campaigns on your platform(s)
8. **Launch Brief + Tracker** — single source of truth documenting every decision and deliverable

---

## Troubleshooting

**"Claude doesn't recognize the slash command"**
Make sure you restarted Claude Code after installation. Skills load on startup.

**"The orchestrator says I'm missing a skill"**
The orchestrator chains 8 other skills. If one is not installed, it will tell you which one at the start of the phase that needs it. Install it, restart Claude Code, and resume.

**"I already have some phases done"**
Tell the orchestrator what you have already built and where the files are. It will audit your existing work against its quality gates, identify gaps, and resume from the earliest incomplete phase.

**"I don't want to run ads — just organic"**
Tell the orchestrator during Pre-Flight. It will run a lighter version of Phase 1 (pains-hopes only, skip ad-prediction-machine) and skip Phases 5 and 6 entirely. You still get Phases 1-4: research, webinar content, registration page, and email sequences.

**"Can I do this in one sitting?"**
Yes, if you have 2-4 hours. But the save points exist so you do not have to. Most students split it across 2-3 sessions.

---

## File Reference

| File / Folder | What It Is |
|---------------|-----------|
| `skills/webinar-launch-orchestrator/SKILL.md` | The orchestrator skill (meta-skill that chains 8 others) |
| `install.sh` | Automatic installer script |
| `STUDENT-INSTRUCTIONS.md` | This file |
