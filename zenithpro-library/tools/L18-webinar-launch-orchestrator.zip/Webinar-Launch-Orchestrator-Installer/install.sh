#!/bin/bash
#
# Webinar Launch Orchestrator — Installer
# Installs 1 meta-skill into your Claude Code environment
#
# Usage: Open Terminal, navigate to this folder, run:
#   chmod +x install.sh && ./install.sh
#

set -e

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color
BOLD='\033[1m'

echo ""
echo -e "${BLUE}${BOLD}================================================${NC}"
echo -e "${BLUE}${BOLD}  Webinar Launch Orchestrator — Installer${NC}"
echo -e "${BLUE}${BOLD}================================================${NC}"
echo ""
echo "  This installs 1 meta-skill into Claude Code:"
echo "  1. Webinar Launch Orchestrator  (/webinar-launch-orchestrator)"
echo ""
echo "  This skill orchestrates 8 other skills in sequence."
echo "  Make sure you have the following skills installed:"
echo "    - cpa-calculator-budget-planner"
echo "    - pains-hopes-gap-analyzer"
echo "    - ad-prediction-machine"
echo "    - webinar-kern"
echo "    - landing-page-copy"
echo "    - email-sequence-architect"
echo "    - ad-copy-creator"
echo "    - facebook-ad-setup-walkthrough / youtube-campaign-setup"
echo ""

# Check if Claude directory exists
CLAUDE_DIR="$HOME/.claude"
SKILLS_DIR="$CLAUDE_DIR/skills"

if [ ! -d "$CLAUDE_DIR" ]; then
    echo -e "${YELLOW}Creating ~/.claude directory...${NC}"
    mkdir -p "$CLAUDE_DIR"
fi

if [ ! -d "$SKILLS_DIR" ]; then
    echo -e "${YELLOW}Creating ~/.claude/skills directory...${NC}"
    mkdir -p "$SKILLS_DIR"
fi

# Get the directory where this script lives
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# --- Skill 1: Webinar Launch Orchestrator ---
echo -e "${BLUE}[1/1]${NC} Installing Webinar Launch Orchestrator..."
SKILL1_DIR="$SKILLS_DIR/webinar-launch-orchestrator"
mkdir -p "$SKILL1_DIR"
cp "$SCRIPT_DIR/skills/webinar-launch-orchestrator/SKILL.md" "$SKILL1_DIR/SKILL.md"
echo -e "  ${GREEN}✓${NC} Installed to $SKILL1_DIR/SKILL.md"

# --- Done ---
echo ""
echo -e "${GREEN}${BOLD}================================================${NC}"
echo -e "${GREEN}${BOLD}  Installation Complete!${NC}"
echo -e "${GREEN}${BOLD}================================================${NC}"
echo ""
echo "  Skills installed:"
echo -e "  ${GREEN}✓${NC} /webinar-launch-orchestrator   — End-to-end webinar launch meta-skill"
echo ""
echo -e "  ${BOLD}How to use:${NC}"
echo "  1. Open Claude Code"
echo "  2. Type: /webinar-launch-orchestrator"
echo "     Or say: \"launch my webinar\""
echo ""
echo -e "  ${BOLD}Required downstream skills:${NC}"
echo "  - cpa-calculator-budget-planner"
echo "  - pains-hopes-gap-analyzer"
echo "  - ad-prediction-machine"
echo "  - webinar-kern"
echo "  - landing-page-copy"
echo "  - email-sequence-architect"
echo "  - ad-copy-creator"
echo "  - facebook-ad-setup-walkthrough / youtube-campaign-setup"
echo ""
echo -e "  ${YELLOW}Note:${NC} You may need to restart Claude Code for skills to appear."
echo ""
