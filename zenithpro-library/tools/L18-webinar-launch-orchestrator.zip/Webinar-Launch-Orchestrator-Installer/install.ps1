# Webinar Launch Orchestrator — Windows Installer
# Run: powershell -ExecutionPolicy Bypass -File install.ps1

$skillName = "webinar-launch-orchestrator"
$claudeDir = "$env:USERPROFILE\.claude\skills\$skillName"

Write-Host "`n=== Webinar Launch Orchestrator — Installer ===" -ForegroundColor Cyan
Write-Host "Installing skill: $skillName`n"
Write-Host "  This installs 1 meta-skill into Claude Code:"
Write-Host "  1. Webinar Launch Orchestrator  (/webinar-launch-orchestrator)`n"
Write-Host "  This skill orchestrates 8 other skills in sequence."
Write-Host "  Make sure you have the following skills installed:"
Write-Host "    - cpa-calculator-budget-planner"
Write-Host "    - pains-hopes-gap-analyzer"
Write-Host "    - ad-prediction-machine"
Write-Host "    - webinar-kern"
Write-Host "    - landing-page-copy"
Write-Host "    - email-sequence-architect"
Write-Host "    - ad-copy-creator"
Write-Host "    - facebook-ad-setup-walkthrough / youtube-campaign-setup`n"

# Check source file exists
$sourceFile = "$PSScriptRoot\skills\$skillName\SKILL.md"
if (-not (Test-Path $sourceFile)) {
    Write-Host "ERROR: Cannot find $sourceFile" -ForegroundColor Red
    Write-Host "Make sure you're running this from the installer folder." -ForegroundColor Yellow
    exit 1
}

# Create directory
if (-not (Test-Path $claudeDir)) {
    New-Item -ItemType Directory -Path $claudeDir -Force | Out-Null
    Write-Host "Created: $claudeDir" -ForegroundColor Green
} else {
    Write-Host "Directory exists: $claudeDir (will update)" -ForegroundColor Yellow
}

# Copy skill file
Copy-Item -Path $sourceFile -Destination "$claudeDir\SKILL.md" -Force
Write-Host "Installed: SKILL.md" -ForegroundColor Green

# Verify installation
if (Test-Path "$claudeDir\SKILL.md") {
    $lines = (Get-Content "$claudeDir\SKILL.md").Count
    Write-Host "`n=== Installation Complete! ===" -ForegroundColor Green
    Write-Host "`n SUCCESS - $skillName installed ($lines lines)" -ForegroundColor Green
    Write-Host "`n  Skills installed:"
    Write-Host "    /webinar-launch-orchestrator  - End-to-end webinar launch meta-skill" -ForegroundColor Green
    Write-Host "`n  Required downstream skills:"
    Write-Host "    - cpa-calculator-budget-planner"
    Write-Host "    - pains-hopes-gap-analyzer"
    Write-Host "    - ad-prediction-machine"
    Write-Host "    - webinar-kern"
    Write-Host "    - landing-page-copy"
    Write-Host "    - email-sequence-architect"
    Write-Host "    - ad-copy-creator"
    Write-Host "    - facebook-ad-setup-walkthrough / youtube-campaign-setup"
    Write-Host "`nIMPORTANT: Restart Claude Code for the skill to take effect." -ForegroundColor Yellow
    Write-Host "`nTest it by asking Claude:"
    Write-Host '  "I want to launch a webinar for my coaching program"' -ForegroundColor Cyan
    Write-Host '  "Help me set up a webinar funnel"' -ForegroundColor Cyan
    Write-Host ""
} else {
    Write-Host "`n FAILED - file not found after copy" -ForegroundColor Red
    exit 1
}
