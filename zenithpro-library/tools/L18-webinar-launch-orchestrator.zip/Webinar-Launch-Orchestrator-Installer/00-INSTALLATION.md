# Webinar Launch Orchestrator — Installation Guide

---

## Before You Start

You need **Claude Code** installed and working on your computer. If you can open Claude Code and have a conversation with it, you are ready.

You do NOT need any coding knowledge. The installers handle everything.

---

## Option A: Auto-Installer (Recommended)

The fastest way. One command copies the skill file to the right place.

### Mac / Linux

1. Open **Terminal** (Applications > Utilities > Terminal).
2. Navigate to the installer folder. If you saved it to your Desktop:
   ```bash
   cd ~/Desktop/Webinar-Launch-Orchestrator-Installer
   ```
   If you saved it somewhere else, adjust the path accordingly.
3. Run the installer:
   ```bash
   chmod +x install.sh && ./install.sh
   ```
4. You should see green checkmarks and "Installation Complete!"
5. **Restart Claude Code** (quit and reopen).

### Windows

1. Open **PowerShell** (search "PowerShell" in the Start menu, right-click, "Run as Administrator" if needed).
2. Navigate to the installer folder. If you saved it to your Desktop:
   ```powershell
   cd "$HOME\Desktop\Webinar-Launch-Orchestrator-Installer"
   ```
   If you saved it somewhere else, adjust the path accordingly.
3. Run the installer:
   ```powershell
   powershell -ExecutionPolicy Bypass -File install.ps1
   ```
4. You should see green text and "SUCCESS - webinar-launch-orchestrator installed."
5. **Restart Claude Code** (quit and reopen).

---

## Option B: Manual Install

If the auto-installer does not work, you can copy the file yourself.

### Step 1: Find the skill file

Inside this installer folder, locate:
```
skills/webinar-launch-orchestrator/SKILL.md
```

### Step 2: Copy it to your Claude skills directory

**Mac / Linux:**
```
~/.claude/skills/webinar-launch-orchestrator/SKILL.md
```

To do this in Terminal:
```bash
mkdir -p ~/.claude/skills/webinar-launch-orchestrator
cp skills/webinar-launch-orchestrator/SKILL.md ~/.claude/skills/webinar-launch-orchestrator/SKILL.md
```

**Windows:**
```
C:\Users\YourName\.claude\skills\webinar-launch-orchestrator\SKILL.md
```

To do this in PowerShell:
```powershell
$dest = "$env:USERPROFILE\.claude\skills\webinar-launch-orchestrator"
New-Item -ItemType Directory -Path $dest -Force | Out-Null
Copy-Item "skills\webinar-launch-orchestrator\SKILL.md" "$dest\SKILL.md" -Force
```

### Step 3: Restart Claude Code

Quit Claude Code completely and reopen it. Skills are loaded on startup.

---

## Option C: Ask Claude to Install It

If you prefer not to use Terminal or PowerShell at all, you can paste the skill directly into Claude.

1. Open the file `skills/webinar-launch-orchestrator/SKILL.md` in any text editor.
2. Select all the text and copy it.
3. Open Claude Code and say:

   ```
   Please save the following as a skill file at ~/.claude/skills/webinar-launch-orchestrator/SKILL.md:

   [paste the contents here]
   ```

4. Claude will create the file for you.
5. **Restart Claude Code** so it loads the new skill.

---

## Verify Installation

After restarting Claude Code, test that the skill is working by typing:

```
I want to launch a webinar for my coaching program
```

or

```
/webinar-launch-orchestrator
```

If the skill is installed correctly, you will meet **Kai** — the orchestrator persona — who will start by asking about your offer and walking you through the pre-flight checklist.

If Claude does not recognize the command, see Troubleshooting below.

---

## Troubleshooting

### 1. "Claude doesn't recognize the slash command or trigger phrase"

**Cause:** Claude Code was not restarted after installation, or the file is in the wrong location.

**Fix:**
- Quit Claude Code completely (not just close the window — fully quit).
- Reopen Claude Code.
- Try again with: `"Launch my webinar"`

If it still does not work, verify the file exists:
- **Mac:** Open Terminal, run `cat ~/.claude/skills/webinar-launch-orchestrator/SKILL.md | head -5`
- **Windows:** Open PowerShell, run `Get-Content "$env:USERPROFILE\.claude\skills\webinar-launch-orchestrator\SKILL.md" | Select-Object -First 5`

You should see the first few lines of the skill file. If you see an error, the file is not in the right place — re-run the installer or copy it manually.

### 2. "The installer says 'Cannot find SKILL.md'"

**Cause:** You are running the installer from the wrong directory.

**Fix:** Make sure you `cd` into the installer folder before running the script. The installer looks for `skills/webinar-launch-orchestrator/SKILL.md` relative to where you run it from.

### 3. "Permission denied" (Mac/Linux)

**Cause:** The install script does not have execute permission.

**Fix:** Run this first:
```bash
chmod +x install.sh
```
Then run `./install.sh` again.

### 4. "Execution policy" error (Windows)

**Cause:** Windows blocks PowerShell scripts by default.

**Fix:** Use the bypass flag:
```powershell
powershell -ExecutionPolicy Bypass -File install.ps1
```
Or open PowerShell as Administrator and run:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```
Then run `.\install.ps1` again.

### 5. "The orchestrator says I'm missing a downstream skill"

**Cause:** The Webinar Launch Orchestrator chains 8 other skills. If one is not installed, the orchestrator will pause at the phase that needs it.

**Fix:** Install the missing skill (use its own installer), restart Claude Code, and resume. The orchestrator will pick up where it left off. The required downstream skills are:
- `cpa-calculator-budget-planner`
- `pains-hopes-gap-analyzer`
- `ad-prediction-machine`
- `webinar-kern`
- `landing-page-copy`
- `email-sequence-architect`
- `ad-copy-creator`
- `facebook-ad-setup-walkthrough` and/or `youtube-campaign-setup`

---

## Still Stuck?

If none of the above fixes your issue, reach out in the ZenithPro community with:
1. What you tried (which option)
2. The exact error message you saw
3. Your operating system (Mac or Windows)

We will get you sorted out.
