# Webinar Launch Orchestrator

## What This Skill Does

The Webinar Launch Orchestrator is a **meta-skill** that orchestrates your end-to-end webinar launch across 6 phases, chaining up to 11 specialized skills into one seamless workflow. It takes you from "I have an offer" to "my webinar campaign is live and running."

You talk to Kai (the orchestrator persona), and Kai handles the sequencing — calling the right skill at the right time, passing outputs between phases, enforcing quality gates, and maintaining save points so you can pause and resume across sessions.

It does not write copy or build campaigns itself. It project-manages the entire launch by handing you off to the right specialist skill at each step.

---

## What You Need Before Starting

1. **An offer with a price** — a product, service, program, or course you are selling, and what you are charging for it.
2. **Knowledge of your audience** — who they are, their primary problem, and where they spend time online.

That is it. Everything else gets built during the process.

**Optional (speeds things up if you have them):**
- Psychographic Excavation output
- Pains & Hopes Gap Analyzer output (from a previous run)
- Ad Prediction Machine output (from a previous run)
- Core Concept / validated positioning
- Existing webinar content or presentation

---

## Installation

### Option A: Mac Auto-Installer (Recommended)

1. Open **Terminal** (Applications > Utilities > Terminal)
2. Navigate to this folder:
   ```
   cd ~/Desktop/Webinar-Launch-Orchestrator-Installer
   ```
   (Adjust the path if you saved it somewhere else.)
3. Run:
   ```
   chmod +x install.sh && ./install.sh
   ```
4. Restart Claude Code.

### Option B: Windows Installer

1. Open **PowerShell** (search "PowerShell" in Start menu)
2. Navigate to this folder:
   ```
   cd "$HOME\Desktop\Webinar-Launch-Orchestrator-Installer"
   ```
   (Adjust the path if you saved it somewhere else.)
3. Run:
   ```
   powershell -ExecutionPolicy Bypass -File install.ps1
   ```
4. Restart Claude Code.

### Option C: Manual Copy

1. Locate the file: `skills/webinar-launch-orchestrator/SKILL.md` inside this installer folder.
2. Copy it to:
   ```
   ~/.claude/skills/webinar-launch-orchestrator/SKILL.md
   ```
   - **Mac/Linux:** `~/.claude/skills/webinar-launch-orchestrator/SKILL.md`
   - **Windows:** `C:\Users\YourName\.claude\skills\webinar-launch-orchestrator\SKILL.md`
3. Create the folders if they do not exist.
4. Restart Claude Code.

---

## How to Use

After installation, open Claude Code and say any of the following:

- `"I want to launch a webinar for my $997 coaching program"`
- `"Help me set up a webinar funnel"`
- `"Launch my webinar"`
- `"Set up my webinar campaign"`
- `/webinar-launch-orchestrator`

Kai (the orchestrator) will start by collecting your offer details, checking which downstream skills you have installed, and then walking you through each phase in order.

---

## The 6 Phases

| Phase | Name | What Happens | Time |
|-------|------|-------------|------|
| 1 | **Audience & Angles** | Deep market research (150+ pains/hopes), competitive gaps, 35+ ad angles ranked into S/A/B/C tiers | 30-60 min |
| 2 | **Webinar Content** | Complete webinar system — pre-webinar funnel, 5-phase presentation, post-webinar conversion | 60-90 min |
| 3 | **Registration System** | Registration page copy (headline, benefits, proof, CTA) + liquidator offer page if applicable | 20-30 min |
| 4 | **Email Sequences** | 4 sequences (13-16 emails): confirmation, reminders, countdown, no-show recovery | 30-45 min |
| 5 | **Ad Copy & Creative** | Platform-specific ad copy, 5-8 variations per platform, character-count validated | 20-30 min |
| 6 | **Campaign Setup** | Step-by-step campaign build on your chosen platform (Facebook, YouTube, or both) | 30-45 min |

Each phase produces deliverables that feed into the next. The orchestrator enforces the correct sequence and connects outputs automatically.

---

## Time Estimate

**2-4 hours across multiple sessions.**

Each phase has a save point. You can pause after any phase and pick up exactly where you left off. The orchestrator maintains a Launch Brief and Launch Tracker that persist between sessions.

Typical split:
- **Session 1:** Pre-Flight + Phase 1 + Phase 2 (~2 hours)
- **Session 2:** Phase 3 + Phase 4 + Phase 5 + Phase 6 (~1.5 hours)

Or do one phase per session — the save points make it flexible.

---

## Prerequisites (Downstream Skills)

The orchestrator chains these skills in sequence. They must be installed separately:

| # | Skill | What It Does |
|---|-------|-------------|
| 1 | `cpa-calculator-budget-planner` | Unit economics — break-even CPA, target CPA, budget tiers |
| 2 | `pains-hopes-gap-analyzer` | Market research — 150+ pains/hopes, competitive gaps, 35+ angles |
| 3 | `ad-prediction-machine` | Ranks ad angles into S/A/B/C tiers with test plan |
| 4 | `webinar-kern` | Complete webinar system — funnel, presentation, conversion |
| 5 | `landing-page-copy` | Registration page copy and liquidator offer page |
| 6 | `email-sequence-architect` | 4 email sequences (13-16 emails total) |
| 7 | `ad-copy-creator` | Platform-specific ad copy, 5-8 variations |
| 8 | `facebook-ad-setup-walkthrough` | Facebook/Meta campaign setup (field by field) |
| 9 | `youtube-campaign-setup` | YouTube campaign setup (field by field) |

If a skill is missing when the orchestrator reaches that phase, it will tell you which one it needs and pause until you install it.

---

## File Reference

| File | Purpose |
|------|---------|
| `skills/webinar-launch-orchestrator/SKILL.md` | The orchestrator meta-skill |
| `install.sh` | Mac/Linux auto-installer |
| `install.ps1` | Windows PowerShell installer |
| `STUDENT-INSTRUCTIONS.md` | Detailed student guide |
| `00-INSTALLATION.md` | Step-by-step installation guide |
| `README.md` | This file |
