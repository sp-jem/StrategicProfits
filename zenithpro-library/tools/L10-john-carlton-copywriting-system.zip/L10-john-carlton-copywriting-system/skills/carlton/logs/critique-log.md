# Carlton Critic - Critique Log

This log tracks all critiques performed using the Carlton Critic agent. Use this to identify patterns and skill gaps.

## Pattern Detection Rules

When the same failure type appears 3+ times:
1. Flag as SKILL GAP
2. Propose update to relevant skill
3. Log proposal in skill-changelog.md
4. Await approval before implementing

---

## Critique Log Entries

### Template for Each Entry

```
### [DATE] - [PROJECT NAME]

**Grade:** [A-F]

**Key Failures:**
1. [Failure description] - Framework: [which Carlton framework]
2. [Failure description] - Framework: [which Carlton framework]

**Root Cause:** [Execution gap OR Skill gap]

**Fixes Applied:**
- [What was fixed]

**Pattern Notes:**
- [Any recurring issues to track]
```

---

### 2026-02-18 - ZMOS Challenge Final Push Posts (Feb 20-22, Carlton Draft)

**Grade:** Feb 20: C+ / Feb 21: B / Feb 22: B+

**Key Failures:**
1. A-Brain triggers absent across all three posts — Framework: One-Two Punch (Carlton Step 3)
2. Consultant-register language throughout — Framework: Voice/Bar Room Conversation (Step 9)
3. CTAs are bolted on, not earned by tension in middle — Framework: Turbulence + CTA Gravity
4. Final urgency posts don't deploy actual urgency tools — Framework: Turbulence (Step 15)

**Root Cause:** Execution gap. The writer understands the product and the audience but defaults to rational argument mode. The emotional activation layer was not built. Voice slips from Rich's casual-specific register into slightly elevated concept language across all three posts.

**Fixes Applied:**
- Identified specific language substitutions (consultant terms to bar-room equivalents)
- Named the A-Brain trigger available in each post (depletion fear, legacy fear, compounding greed)
- Specified exactly which lines to cut (defensive throat-clears) and which to expand (offsite proof point)
- Noted that final urgency posts require turbulence upgrade beyond standard CTA

**Pattern Notes:**
- RECURRENCE (2x): "Consultant-register language" appeared in Round 1 (Post 8 flagged) and appears again here. Now at 2 occurrences — flag if appears again.
- RECURRENCE (2x): "Middle sag" (explanation instead of escalation) appeared in Round 1 and is present here. At 2 occurrences — flag if appears again.
- NEW: Final urgency posts need specific turbulence protocol — standard CTA approach insufficient when event is days away.

---

### 2026-02-13 - ZMOS Challenge Social Media Posts Round 2 (8 Posts)

**Grade:** B+

**Key Failures Addressed From Round 1:**
1. Jarring transitions between ideas - Framework: Voice/Bar Room Conversation (Step 9)
2. Too "copywriter-y" voice, not enough genuine Rich Schefren - Framework: Voice (Step 9)
3. Posts sagging in the middle after strong hooks - Framework: The Chain / So What? Test

**Round 2 Self-Assessment:**

**Strengths:**
- Hook variety across 8 posts (contrast test, historical analogy, study debunk, question opener, physical analogy, social proof narrative, experiment result, competitive fear)
- Voice calibrated against 3 user-revised published posts
- Smooth transitions using bridge sentences instead of hard cuts
- Strong middles maintained through specific details and revelations
- CTA format kept minimal and non-salesy per Rich's voice
- Under 300 words per post
- Fear-first emotional sequence per brief (competitive urgency, blind spot cost, missing out)

**Remaining Concerns:**
1. Posts 1-3 closely mirror the revised posts user already published -- risk of feeling repetitive if audience saw both email AND social post
2. Post 8 (competitive fear) may lean slightly more "copywriter-y" than Rich's natural voice -- the "somebody in your niche" framing is more classic direct response than Rich's typical peer-to-peer tone
3. Posts 4 and 5 have similar emotional beats (blind spots, nobody knows you) -- may feel thematically repetitive when published back to back

**Root Cause:** Execution gap -- the source emails themselves share overlapping themes (blind spots, self-knowledge, nobody knows you), making differentiation between posts harder

**Fixes Applied (vs Round 1):**
- Replaced hard transitions with narrative bridges
- Stripped "sales letter" phrasing, kept bar-room conversational tone
- Compressed story middles to maintain energy
- Varied post structures across all 8
- Kept CTAs to 1-2 lines max, no hype language

**Pattern Notes:**
- WATCH: "Middle sag" appeared in Round 1 -- monitor if this recurs
- WATCH: "Copywriter-y voice" appeared in Round 1 -- Post 8 may still trigger this
- NEW: Thematic repetition across sequence when source material overlaps -- may need structural differentiation skill

---

### 2026-02-19 - AI Imprint Event Feb 23 Last-Chance Post

**Grade:** B+ (self-assessment on generation; no formal critique pass requested)

**Task:** Write "last chance" social media post for Feb 23 (event begins Feb 24). One final push post for the AI Imprint Event registration.

**Frameworks Deployed:**
1. Hook - Incongruous Juxtaposition: "registration page open three times this week and didn't pull the trigger" paired with calm consequence statement. Avoids repeating 800/zero juxtaposition from Feb 22.
2. Turbulence (Step 15): Consequence stated flatly, no cheerleading. "That gap doesn't pause while you get less busy. It compounds. Every week. Quietly. Without asking your permission."
3. Knock Em Off The Fence (Step 16): Named the specific last obstacle (believing they can catch up later via content). Dismantled in two sentences.
4. Bar Room Voice: Slightly impatient, straight, peer-to-peer. "I'm saying this straight, not to pressure you."
5. One-Two Punch CTA: Statement of availability plus consequence of inaction, then link. No begging.

**Key Risks:**
1. Opening "Tomorrow we start" is clean but does not create incongruous juxtaposition in the first line -- relies on second paragraph to establish tension. May be slightly soft on the Gate Check's immediate zombie-jolt requirement.
2. Middle section (the fence-knocking paragraph) is rational-dominant -- names the obstacle intellectually but does not deploy a strong A-Brain trigger. Depletion fear is implied, not felt.
3. Voice is accurate to Rich Schefren register but may be slightly more Carlton-aggressive than Rich's natural peer-to-peer tone in places ("I'm saying this straight").

**Root Cause of Risks:** Execution tension between Carlton's aggressive turbulence standards and Rich's softer peer-authority voice. The brief asked for both simultaneously -- Carlton frameworks deployed through Rich's register is inherently a compression challenge.

**Fixes Available if Needed:**
- Sharpen opening line to create stronger juxtaposition in line one (e.g., contrast between "free event" and "the gap it closes")
- Add one sensory/emotional beat to fence-knocking section to activate A-Brain alongside rational argument
- Soften "I'm saying this straight" to something more Rich-natural like "and I mean this" or remove qualifier entirely

**Pattern Notes:**
- RECURRENCE (3x): "Consultant-register language / slightly elevated tone" appeared Round 1 (Post 8), Round 2 (Feb 18 batch), and present here as minor risk. THIS IS NOW A SKILL GAP THRESHOLD. Flagging for review.
- WATCH: "A-Brain triggers weak in middle" -- appeared Feb 18 batch and present here. Now at 2 occurrences for this specific pattern.

**SKILL GAP FLAG:**
Pattern "consultant-register / elevated tone bleeding into Rich Schefren voice" has appeared 3 times across critiques. Proposed skill update: Add explicit "Rich Schefren voice calibration" section to carlton-voice SKILL.md with specific word-swap examples distinguishing Carlton aggression from Rich's peer-authority register. Log proposal in skill-changelog.md. Awaiting approval before implementing.

---

### 2026-02-24 - Connect the Dots Last-Chance Campaign (3 Posts, Carlton Draft)

**Grade:** Post 1: B / Post 2: A- / Post 3: B- / Overall: B

**Key Failures:**
1. Connective tissue gap — "I'm telling you this because..." / "Here's why I'm telling you this specifically." appears in Posts 1 and 2 as a pivot signpost instead of a pivot execution — Framework: The Chain / So What? Test (Voice Step 9)
2. A-Brain greed trigger absent in Post 1 — fear of missing the circle is present but no forward-looking desire for what the circle produces — Framework: One-Two Punch (A-Brain activation)
3. Cold reader failure in Post 3 — hook assumes sequence context; no incongruous juxtaposition for a reader encountering this post alone — Framework: Hook / Gate Check
4. Consultant-register language (SKILL GAP confirmed x4/x5): "That changes the conversation" (Post 1) and "practical upside" (Post 2) — Framework: Voice/Bar Room Conversation (Step 9)

**Root Cause:** Mixed. The connective tissue gap and A-Brain greed omission are execution gaps -- the copywriter defaulted to signposting pivots rather than executing them, and the emotional activation layer stopped at fear without adding desire. The cold reader failure in Post 3 is a strategic choice documented in the methodology note; it is defensible for email sequence but is a genuine vulnerability on social media. The consultant-register pattern is now confirmed as a recurring SKILL GAP.

**Fixes Applied to Output:**
- Specific deletion: "Here's why I'm telling you this specifically." (Post 1) — cut and bridge directly
- Specific deletion: "I'm telling you this because of a specific conversation I keep having." (Post 2) — cut and bridge via contrast
- Proposed hook addition for Post 3 cold reader: "The last two spots in a $10,000 event that sold out in 13 days are still open."
- Voice fix: "practical upside" → "one more thing" (Post 2)
- A-Brain fix: one forward-looking greed sentence added to Post 1 close guidance
- Post 2 close: authority frame before invitation line
- Post 3: "that's worth paying attention to" → "that feeling is your answer"

**Preserve (do not revise):**
- "It was real." (Post 1)
- "Not a consulting retainer. Not a strategy system. Not a course. A coffee chat." (Post 2)
- "He paid to have his patterns seen and redirected by someone who recognized where he was heading before he did." (Post 2)
- "The people who move when the door is almost closed are almost always the right people for the room." (Post 3)

**Pattern Notes:**
- RECURRENCE (2x): "Connective tissue gap / pivot signpost instead of pivot execution" appeared in Feb 18 arena run and confirmed in both Posts 1 and 2 here. At 2 occurrences. FLAG if appears in next arena run — would trigger SKILL GAP threshold.
- RECURRENCE (4x/5x): "Consultant-register language" -- "practical upside" and "That changes the conversation" are instances 4 and 5. SKILL GAP already flagged at 3x (Feb 19 entry). Confirmed active. Proposed fix from Feb 19 entry (Rich Schefren voice calibration section) should be approved and implemented.
- RECURRENCE (2x): "A-Brain triggers weak / greed absent" appeared in Feb 18 batch and confirmed in Post 1 here. At 2 occurrences. FLAG if appears again.

---

*Add new entries above this line*
