#!/bin/bash
SKILLS=("motivation-spectrum-analyzer" "hybrid-demand-architect")
echo "Installing ZenithPro: Hybrid Skills (2 skills)..."
SUCCESS=0; FAILED=0
for SKILL in "${SKILLS[@]}"; do
  mkdir -p "$HOME/.claude/skills/$SKILL"
  cp "$SKILL/SKILL.md" "$HOME/.claude/skills/$SKILL/SKILL.md"
  if [ -f "$HOME/.claude/skills/$SKILL/SKILL.md" ]; then
    echo "✅ $SKILL"; ((SUCCESS++))
  else
    echo "❌ $SKILL — FAILED"; ((FAILED++))
  fi
done
echo ""
echo "Installed: $SUCCESS / 2 skills"
echo "Run first: /motivation-spectrum-analyzer [your market]"
echo "Then run:  /hybrid-demand-architect [your market]"
