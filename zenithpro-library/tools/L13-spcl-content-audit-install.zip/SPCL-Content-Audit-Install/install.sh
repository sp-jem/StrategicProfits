#!/bin/bash
# Hormozi SPCL Content Audit - Mac/Linux Installer

echo "============================================"
echo "  Hormozi SPCL Content Audit Installer"
echo "  ZenithPro Session 14"
echo "============================================"
echo ""

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Define target directory
TARGET_DIR="$HOME/.claude/skills"

# Create target directory if it doesn't exist
if [ ! -d "$TARGET_DIR" ]; then
    echo "Creating skills directory at $TARGET_DIR..."
    mkdir -p "$TARGET_DIR"
fi

# Copy the skill
echo "Installing hormozi-spcl-content-audit skill..."
cp -r "$SCRIPT_DIR/skills/hormozi-spcl-content-audit" "$TARGET_DIR/"

# Verify installation
if [ -f "$TARGET_DIR/hormozi-spcl-content-audit/SKILL.md" ]; then
    echo ""
    echo "============================================"
    echo "  Installation Complete!"
    echo "============================================"
    echo ""
    echo "The SPCL Content Audit skill has been installed."
    echo ""
    echo "To use it:"
    echo "  1. Open Claude Code CLI"
    echo "  2. Type: /hormozi-spcl-content-audit"
    echo "  3. Provide your social media handles"
    echo ""
    echo "Installed to: $TARGET_DIR/hormozi-spcl-content-audit/"
    echo ""
else
    echo ""
    echo "ERROR: Installation may have failed."
    echo "Please check that the files were copied correctly."
    echo ""
fi
