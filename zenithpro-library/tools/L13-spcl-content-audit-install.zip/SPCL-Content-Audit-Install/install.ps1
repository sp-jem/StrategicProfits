# Hormozi SPCL Content Audit - Windows Installer

Write-Host "============================================"
Write-Host "  Hormozi SPCL Content Audit Installer"
Write-Host "  ZenithPro Session 14"
Write-Host "============================================"
Write-Host ""

# Get the directory where this script is located
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Define target directory
$TargetDir = "$env:USERPROFILE\.claude\skills"

# Create target directory if it doesn't exist
if (!(Test-Path $TargetDir)) {
    Write-Host "Creating skills directory at $TargetDir..."
    New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
}

# Copy the skill
Write-Host "Installing hormozi-spcl-content-audit skill..."
Copy-Item -Path "$ScriptDir\skills\hormozi-spcl-content-audit" -Destination $TargetDir -Recurse -Force

# Verify installation
if (Test-Path "$TargetDir\hormozi-spcl-content-audit\SKILL.md") {
    Write-Host ""
    Write-Host "============================================"
    Write-Host "  Installation Complete!"
    Write-Host "============================================"
    Write-Host ""
    Write-Host "The SPCL Content Audit skill has been installed."
    Write-Host ""
    Write-Host "To use it:"
    Write-Host "  1. Open Claude Code CLI"
    Write-Host "  2. Type: /hormozi-spcl-content-audit"
    Write-Host "  3. Provide your social media handles"
    Write-Host ""
    Write-Host "Installed to: $TargetDir\hormozi-spcl-content-audit\"
    Write-Host ""
} else {
    Write-Host ""
    Write-Host "ERROR: Installation may have failed."
    Write-Host "Please check that the files were copied correctly."
    Write-Host ""
}
