# Hormozi SPCL Content Audit
## Installation Guide

---

## What You're Installing

The SPCL Content Audit skill uses Alex Hormozi's influence framework to audit your content strategy and identify gaps. It analyzes your actual social media content against four elements:

| Element | What It Means |
|---------|---------------|
| **S** - Status | Control over scarce resources (money, access, connections) |
| **P** - Power | Say-do correspondence (you give advice → they follow → good happens) |
| **C** - Credibility | Third-party validation (testimonials, partnerships, media) |
| **L** - Likeness | Similarity to your audience (values, background, voice) |

**This skill will:**
- Fetch LIVE data from your social media platforms (Instagram, Facebook, LinkedIn, YouTube)
- Analyze your last 12-20 posts against the SPCL framework
- Identify your lowest-scoring element (your priority gap)
- Create a 90-day content plan to fix the gaps
- Provide content templates for each element

---

## Prerequisites

Before installing, ensure you have:

1. **Claude Code CLI installed and working**
   - You should be able to open a terminal and type `claude` to start a session
   - If not installed, visit: https://claude.ai/code

2. **Active social media accounts to audit**
   - Instagram (recommended)
   - Facebook
   - LinkedIn
   - YouTube (optional)

---

## Installation Instructions

### Option A: Simple Copy (Recommended)

1. Copy the `skills/hormozi-spcl-content-audit/` folder to your Claude skills directory:

   **Mac:**
   ```
   cp -r skills/hormozi-spcl-content-audit ~/.claude/skills/
   ```

   **Windows (PowerShell):**
   ```
   Copy-Item -Recurse skills\hormozi-spcl-content-audit $env:USERPROFILE\.claude\skills\
   ```

2. Restart Claude Code CLI

3. Verify by typing:
   ```
   /hormozi-spcl-content-audit
   ```

### Option B: Ask Claude to Install

1. Open Claude Code CLI

2. Navigate to this folder:
   ```
   cd /path/to/SPCL-Content-Audit-Install
   ```

3. Ask Claude:
   ```
   Install the SPCL content audit skill from this folder
   ```

4. Claude will copy the skill to the correct location

---

## What Gets Installed

```
~/.claude/
└── skills/
    └── hormozi-spcl-content-audit/
        └── SKILL.md    # The complete skill definition
```

---

## How to Use

### Running the Audit

1. Open Claude Code CLI

2. Type:
   ```
   /hormozi-spcl-content-audit
   ```

3. Provide your social media handles when asked:
   - Instagram: @yourhandle
   - Facebook: facebook.com/yourpage
   - LinkedIn: linkedin.com/in/yourprofile

4. Claude will:
   - Visit each platform and capture your recent content
   - Analyze each post against SPCL
   - Score you on all four elements
   - Identify your priority gap
   - Create a 90-day content plan

### What You'll Get

1. **SPCL Scorecard** - Your scores out of 10 for each element
2. **Content Gap Analysis** - What's missing from your content
3. **Post-by-Post Audit** - Each recent post scored against SPCL
4. **90-Day Content Plan** - Weekly content mix to fix gaps
5. **Content Templates** - Ideas for each SPCL element

---

## Example Output

See `EXAMPLE-SPCL-Content-Audit-Report.md` in the Lesson 14 folder for Ashley's actual audit, which shows:

- Instagram: @theashleyshaw (11.6K followers)
- Facebook: theashleymarieshaw (4.1K followers)
- **Finding:** Credibility was the gap (not Power as expected)
- **Lesson:** Live platform data reveals different gaps than Voice DNA files alone

---

## Important: Live Data Required

This skill MUST fetch live platform data before scoring. Voice DNA files alone are NOT sufficient.

**Why?**
- Voice DNA tells you what you SHOULD be posting
- Live platform data tells you what you're ACTUALLY posting
- They're often different (as Ashley discovered in her audit)

If the skill cannot access your platforms via browser:
- Provide screenshots of your last 20 posts
- Or paste your recent captions/content
- Or export your data from each platform

---

## Troubleshooting

### Skill not appearing after installation

1. Restart Claude Code CLI completely
2. Check that files exist in `~/.claude/skills/hormozi-spcl-content-audit/`
3. Try running `/skill list` to see available skills

### Browser can't access social media

If Claude can't browse your social media:
1. Make sure you're logged into the platforms in your browser
2. Provide screenshots or pasted content instead
3. The audit can still work with manual content input

### Audit says "Voice DNA only" warning

This means the skill tried to audit without live platform data. Either:
1. Provide your social media handles so it can fetch live data
2. Paste your last 20 posts manually
3. Provide screenshots

---

## Combining with Personal Brand DNA Extractor

For best results:
1. Run `/personal-brand-dna-extractor` FIRST to create your Voice DNA files
2. Run `/hormozi-spcl-content-audit` SECOND to audit against live content
3. Compare what your Voice DNA says vs. what you're actually posting
4. Use the gap analysis to align your content with your brand

---

## License

This skill is exclusively licensed to ZenithPro members.

**You may NOT:**
- Share this with anyone outside ZenithPro
- Redistribute in any form

---

*Hormozi SPCL Content Audit Skill*
*Based on Alex Hormozi's Influence Framework*
*Created for ZenithPro Members*
