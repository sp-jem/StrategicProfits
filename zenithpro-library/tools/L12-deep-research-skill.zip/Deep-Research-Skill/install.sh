#!/bin/bash
# Deep Research Skill Installer for Mac/Linux
# Installs the multi-source research orchestrator skill for Claude Code

set -e

SKILL_NAME="deep-research"
SKILL_DIR="$HOME/.claude/skills/$SKILL_NAME"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "=================================="
echo "Deep Research Skill Installer"
echo "=================================="
echo ""

# Check for Python 3
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is required but not installed."
    echo "Please install Python 3 first: https://www.python.org/downloads/"
    exit 1
fi

# Check Python version
PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "Found Python $PYTHON_VERSION"

# Check if skill already exists
if [ -d "$SKILL_DIR" ]; then
    echo ""
    echo "Warning: $SKILL_DIR already exists"
    read -p "Overwrite? (y/N) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Installation cancelled"
        exit 1
    fi
    rm -rf "$SKILL_DIR"
fi

# Create skill directory
echo "Creating skill directory..."
mkdir -p "$SKILL_DIR/references/scripts"

# Copy skill files
echo "Copying skill files..."
cp "$SCRIPT_DIR/SKILL.md" "$SKILL_DIR/"
cp "$SCRIPT_DIR/references/api-keys-template.json" "$SKILL_DIR/references/api-keys.json"
cp "$SCRIPT_DIR/references/browser-automation.md" "$SKILL_DIR/references/" 2>/dev/null || true
cp "$SCRIPT_DIR/references/scripts/"*.py "$SKILL_DIR/references/scripts/"

# Create virtual environment
echo "Creating Python virtual environment..."
python3 -m venv "$SKILL_DIR/venv"

# Activate and install dependencies
echo "Installing Python dependencies..."
source "$SKILL_DIR/venv/bin/activate"
pip install --quiet --upgrade pip
pip install --quiet requests

deactivate

# Make scripts executable
chmod +x "$SKILL_DIR/references/scripts/"*.py

echo ""
echo "=================================="
echo "Installation Complete!"
echo "=================================="
echo ""
echo "Skill installed to: $SKILL_DIR"
echo ""
echo "NEXT STEPS:"
echo ""
echo "1. Get your API keys from:"
echo "   - Perplexity: https://www.perplexity.ai/settings/api"
echo "   - Gemini: https://aistudio.google.com/apikey"
echo "   - Tavily: https://tavily.com/"
echo "   - Exa: https://exa.ai/"
echo ""
echo "2. Edit the API keys file:"
echo "   $SKILL_DIR/references/api-keys.json"
echo ""
echo "3. Test with Claude Code:"
echo "   'Deep research on AI agent architectures'"
echo ""
echo "=================================="
