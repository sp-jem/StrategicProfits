# Deep Research Skill

**Multi-source research orchestrator that queries Perplexity, Gemini, Tavily, and Exa.ai simultaneously for comprehensive research coverage.**

---

## What This Does

When you ask Claude Code to do "deep research" on any topic, this skill dispatches your query to 4 different AI research engines in parallel:

1. **Perplexity Sonar Deep Research** - Multi-step retrieval and synthesis
2. **Gemini API** - Google's AI with web grounding
3. **Tavily** - AI-native search API with structured results
4. **Exa.ai** - Semantic/neural search for conceptually related content

Instead of waiting 10+ minutes to run each source sequentially, all 4 run simultaneously and complete in 2-3 minutes total.

Results are saved as both JSON (for programmatic use) and Markdown (for reading) to a staging folder in your home directory.

---

## What You'll Get

- **Comprehensive coverage** - 4 different perspectives on any research topic
- **Time savings** - Parallel execution completes in 2-3 minutes vs 10+ minutes sequential
- **Source diversity** - Each engine has different strengths and data sources
- **Organized output** - All results saved to a staging folder automatically

---

## Requirements

Before installing, you'll need:

1. **Claude Code** installed and working
2. **Python 3.8+** installed
3. **API Keys** from each service (see API Setup section below)

---

## Installation

### Mac (Terminal)

```bash
cd ~/Downloads/Deep-Research-Skill
chmod +x install.sh
./install.sh
```

### Windows (PowerShell)

```powershell
cd ~/Downloads/Deep-Research-Skill
.\install.ps1
```

---

## API Setup

You'll need to get your own API keys from each service. Here's how:

### 1. Perplexity (Required - Best Results)

1. Go to https://www.perplexity.ai/settings/api
2. Create an API key
3. Note: Sonar Deep Research costs ~$0.15-0.50 per query

### 2. Gemini (Free Tier Available)

1. Go to https://aistudio.google.com/apikey
2. Create an API key
3. Free tier includes generous limits

### 3. Tavily (Free Credits)

1. Go to https://tavily.com/
2. Sign up and get API key
3. Free tier includes credits

### 4. Exa (Free Credits)

1. Go to https://exa.ai/
2. Sign up and get API key
3. Free tier includes credits

After getting your keys, edit `~/.claude/skills/deep-research/references/api-keys.json`:

```json
{
  "perplexity": {
    "api_key": "YOUR_PERPLEXITY_KEY",
    "base_url": "https://api.perplexity.ai",
    "model": "sonar-deep-research"
  },
  "gemini": {
    "api_key": "YOUR_GEMINI_KEY",
    "base_url": "https://generativelanguage.googleapis.com",
    "model": "gemini-2.0-flash"
  },
  "tavily": {
    "api_key": "YOUR_TAVILY_KEY",
    "base_url": "https://api.tavily.com"
  },
  "exa": {
    "api_key": "YOUR_EXA_KEY",
    "base_url": "https://api.exa.ai"
  }
}
```

---

## How to Use

After installation, simply tell Claude Code:

```
Deep research on "AI agent architectures for autonomous task completion"
```

Or use the command directly:

**Mac/Linux:**
```bash
source ~/.claude/skills/deep-research/venv/bin/activate && python3 ~/.claude/skills/deep-research/references/scripts/orchestrator.py "your research query"
```

**Windows (PowerShell):**
```powershell
& "$env:USERPROFILE\.claude\skills\deep-research\venv\Scripts\Activate.ps1"
python "$env:USERPROFILE\.claude\skills\deep-research\references\scripts\orchestrator.py" "your research query"
```

### Options

Run specific sources only:
```bash
# Mac/Linux
orchestrator.py "your query" perplexity,gemini

# Windows
python orchestrator.py "your query" perplexity,gemini
```

Run sequentially instead of parallel:
```bash
orchestrator.py "your query" --sequential
```

---

## Output Location

Results are saved to your home directory:
```
~/research-staging/
```

On Windows:
```
C:\Users\YourName\research-staging\
```

Files created:
- `{timestamp}_ORCHESTRATOR_{query}.json` - Raw combined data
- `{timestamp}_ORCHESTRATOR_{query}.md` - Readable markdown summary
- Individual source files for each API

---

## Cost Estimates

| Source | Cost per Query | Time |
|--------|---------------|------|
| Perplexity Deep | ~$0.15-0.50 | 2-3 min |
| Gemini API | Free tier | 10-20 sec |
| Tavily Advanced | ~$0.016 | 2-5 sec |
| Exa.ai | ~$0.005 | 2-5 sec |
| **Full Orchestration** | **~$0.20-0.55** | **2-3 min** |

---

## Troubleshooting

**"Module not found" error:**
Make sure you activated the virtual environment:

Mac/Linux:
```bash
source ~/.claude/skills/deep-research/venv/bin/activate
```

Windows (PowerShell):
```powershell
& "$env:USERPROFILE\.claude\skills\deep-research\venv\Scripts\Activate.ps1"
```

**API key errors:**
Check that your `api-keys.json` file has valid keys for each service.

**Permission denied (Mac):**
Run `chmod +x install.sh` first.

**"Execution policy" error (Windows):**
Run PowerShell as Administrator and execute:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**"source not recognized" error (Windows):**
You're using Mac commands on Windows. Use the PowerShell commands shown above instead.

---

## What's Installed

```
~/.claude/skills/deep-research/
├── SKILL.md                 # Skill definition for Claude
├── references/
│   ├── api-keys.json        # Your API keys (you fill in)
│   ├── browser-automation.md # Instructions for browser-based research
│   └── scripts/
│       ├── orchestrator.py   # Main parallel runner
│       ├── perplexity_research.py
│       ├── gemini_research.py
│       ├── tavily_research.py
│       └── exa_research.py
└── venv/                    # Python virtual environment
```

---

*Packaged by Rich Schefren - Strategic Profits*
