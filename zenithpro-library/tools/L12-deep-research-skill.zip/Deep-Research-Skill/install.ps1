# Deep Research Skill Installer for Windows
# Installs the multi-source research orchestrator skill for Claude Code

$ErrorActionPreference = "Stop"

$SKILL_NAME = "deep-research"
$SKILL_DIR = "$env:USERPROFILE\.claude\skills\$SKILL_NAME"
$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "==================================" -ForegroundColor Cyan
Write-Host "Deep Research Skill Installer" -ForegroundColor Cyan
Write-Host "==================================" -ForegroundColor Cyan
Write-Host ""

# Check for Python 3
try {
    $pythonVersion = python --version 2>&1
    if ($pythonVersion -notmatch "Python 3") {
        throw "Python 3 required"
    }
    Write-Host "Found $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Python 3 is required but not installed." -ForegroundColor Red
    Write-Host "Please install Python 3 first: https://www.python.org/downloads/"
    exit 1
}

# Check if skill already exists
if (Test-Path $SKILL_DIR) {
    Write-Host ""
    Write-Host "Warning: $SKILL_DIR already exists" -ForegroundColor Yellow
    $response = Read-Host "Overwrite? (y/N)"
    if ($response -ne "y" -and $response -ne "Y") {
        Write-Host "Installation cancelled"
        exit 1
    }
    Remove-Item -Recurse -Force $SKILL_DIR
}

# Create skill directory
Write-Host "Creating skill directory..."
New-Item -ItemType Directory -Force -Path "$SKILL_DIR\references\scripts" | Out-Null

# Copy skill files
Write-Host "Copying skill files..."
Copy-Item "$SCRIPT_DIR\SKILL.md" "$SKILL_DIR\"
Copy-Item "$SCRIPT_DIR\references\api-keys-template.json" "$SKILL_DIR\references\api-keys.json"
if (Test-Path "$SCRIPT_DIR\references\browser-automation.md") {
    Copy-Item "$SCRIPT_DIR\references\browser-automation.md" "$SKILL_DIR\references\"
}
Copy-Item "$SCRIPT_DIR\references\scripts\*.py" "$SKILL_DIR\references\scripts\"

# Create virtual environment
Write-Host "Creating Python virtual environment..."
python -m venv "$SKILL_DIR\venv"

# Activate and install dependencies
Write-Host "Installing Python dependencies..."
& "$SKILL_DIR\venv\Scripts\Activate.ps1"
pip install --quiet --upgrade pip
pip install --quiet requests
deactivate

Write-Host ""
Write-Host "==================================" -ForegroundColor Green
Write-Host "Installation Complete!" -ForegroundColor Green
Write-Host "==================================" -ForegroundColor Green
Write-Host ""
Write-Host "Skill installed to: $SKILL_DIR"
Write-Host ""
Write-Host "NEXT STEPS:" -ForegroundColor Yellow
Write-Host ""
Write-Host "1. Get your API keys from:"
Write-Host "   - Perplexity: https://www.perplexity.ai/settings/api"
Write-Host "   - Gemini: https://aistudio.google.com/apikey"
Write-Host "   - Tavily: https://tavily.com/"
Write-Host "   - Exa: https://exa.ai/"
Write-Host ""
Write-Host "2. Edit the API keys file:"
Write-Host "   $SKILL_DIR\references\api-keys.json"
Write-Host ""
Write-Host "3. Test with Claude Code:"
Write-Host "   'Deep research on AI agent architectures'"
Write-Host ""
Write-Host "==================================" -ForegroundColor Cyan
