# Browser-Based Deep Research Automation

## Overview

These are optional, manual research tasks (5-15+ minutes each) that provide deeper, more comprehensive research than the API-based sources. You use these platforms directly in your web browser alongside the automated API sources.

## Platform Details

### 1. Manus (manus.im)

**URL:** https://manus.im/app
**Best For:** Complex multi-step research tasks, web scraping, data gathering

**Manual Steps:**
1. Navigate to https://manus.im/app
2. Click on input field
3. Type research query
4. Click send button (arrow icon)
5. Monitor left sidebar for task progress
6. When complete, copy results

---

### 2. Claude Deep Research (claude.ai)

**URL:** https://claude.ai/new
**Best For:** Comprehensive analysis with citations, synthesized insights

**Manual Steps:**
1. Navigate to https://claude.ai/new
2. Click on input field
3. Type: "Please conduct deep research on: [QUERY]"
4. Click send button
5. Wait for research to complete
6. Copy the full response

---

### 3. Gemini Deep Research (gemini.google.com)

**URL:** https://gemini.google.com/app
**Best For:** Google's knowledge graph, real-time web data, structured reports

**Manual Steps:**
1. Navigate to https://gemini.google.com/app
2. Click "Tools" button in input area
3. Select "Deep Research" from dropdown
4. Type research query in input field
5. Click send
6. Wait for research plan, then full report
7. Copy the complete research document

---

## When to Use Browser Research

- **Complex topics** requiring 15+ sources
- **Recent events** needing real-time data
- **Multi-step analysis** requiring synthesis
- **When API sources** don't provide enough depth

## Combining with API Research

1. Start with orchestrator (API sources) - get quick results
2. Review findings and identify gaps
3. Run browser research for specific deep-dive topics
4. Combine all results into unified report
