#!/usr/bin/env python3
"""
Perplexity Deep Research API Integration
Dispatches research queries to Perplexity's sonar-deep-research model
"""

import json
import sys
import os
import requests
from datetime import datetime
from pathlib import Path

# Load config
CONFIG_PATH = Path(__file__).parent.parent / "api-keys.json"
OUTPUT_DIR = Path(os.path.expanduser("~/research-staging"))

def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)

def research(query: str, save_output: bool = True) -> dict:
    """Execute deep research query via Perplexity API"""
    config = load_config()
    api_key = config["perplexity"]["api_key"]

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": "sonar-deep-research",
        "messages": [
            {
                "role": "system",
                "content": "You are a thorough research assistant. Provide comprehensive, well-sourced answers with citations."
            },
            {
                "role": "user",
                "content": query
            }
        ]
    }

    print(f"[Perplexity] Sending query: {query[:100]}...")

    response = requests.post(
        "https://api.perplexity.ai/chat/completions",
        headers=headers,
        json=payload,
        timeout=300  # 5 min timeout for deep research
    )

    if response.status_code != 200:
        print(f"[Perplexity] Error: {response.status_code}")
        print(response.text)
        return {"error": response.text, "status_code": response.status_code}

    result = response.json()

    # Extract the response content
    content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
    citations = result.get("citations", [])

    output = {
        "source": "perplexity",
        "model": "sonar-deep-research",
        "query": query,
        "timestamp": datetime.now().isoformat(),
        "content": content,
        "citations": citations,
        "raw_response": result
    }

    if save_output:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        slug = query[:50].replace(" ", "_").replace("/", "-")
        filename = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_perplexity_{slug}.json"
        output_path = OUTPUT_DIR / filename

        with open(output_path, "w") as f:
            json.dump(output, f, indent=2)

        # Also save markdown version
        md_filename = filename.replace(".json", ".md")
        md_path = OUTPUT_DIR / md_filename

        md_content = f"""# Perplexity Deep Research Results

**Query:** {query}
**Timestamp:** {output['timestamp']}
**Model:** sonar-deep-research

---

## Findings

{content}

---

## Citations

"""
        for i, cite in enumerate(citations, 1):
            md_content += f"{i}. {cite}\n"

        with open(md_path, "w") as f:
            f.write(md_content)

        print(f"[Perplexity] Results saved to: {output_path}")
        print(f"[Perplexity] Markdown saved to: {md_path}")

    return output

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python perplexity_research.py 'your research query'")
        sys.exit(1)

    query = " ".join(sys.argv[1:])
    result = research(query)

    if "error" not in result:
        print("\n" + "="*60)
        print("RESEARCH COMPLETE")
        print("="*60)
        print(result["content"][:2000] + "..." if len(result["content"]) > 2000 else result["content"])
