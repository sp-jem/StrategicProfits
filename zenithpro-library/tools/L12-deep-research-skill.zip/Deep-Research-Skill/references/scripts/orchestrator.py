#!/usr/bin/env python3
"""
Deep Research Orchestrator
Dispatches queries to all available research APIs in parallel and collects results.
"""

import json
import sys
import os
import concurrent.futures
from datetime import datetime
from pathlib import Path
import importlib.util

# Script directory
SCRIPT_DIR = Path(__file__).parent
# Output to user's home directory (configurable)
OUTPUT_DIR = Path(os.path.expanduser("~/research-staging"))

def load_module(name):
    """Dynamically load a research module"""
    spec = importlib.util.spec_from_file_location(name, SCRIPT_DIR / f"{name}_research.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def run_perplexity(query):
    """Run Perplexity deep research"""
    try:
        module = load_module("perplexity")
        return {"source": "perplexity", "result": module.research(query), "error": None}
    except Exception as e:
        return {"source": "perplexity", "result": None, "error": str(e)}

def run_gemini(query):
    """Run Gemini research"""
    try:
        module = load_module("gemini")
        return {"source": "gemini", "result": module.research(query), "error": None}
    except Exception as e:
        return {"source": "gemini", "result": None, "error": str(e)}

def run_tavily(query):
    """Run Tavily search"""
    try:
        module = load_module("tavily")
        return {"source": "tavily", "result": module.research(query, search_depth="advanced"), "error": None}
    except Exception as e:
        return {"source": "tavily", "result": None, "error": str(e)}

def run_exa(query):
    """Run Exa semantic search"""
    try:
        module = load_module("exa")
        return {"source": "exa", "result": module.research(query, search_type="auto"), "error": None}
    except Exception as e:
        return {"source": "exa", "result": None, "error": str(e)}

def orchestrate(query: str, sources: list = None, parallel: bool = True) -> dict:
    """
    Run research across multiple sources

    Args:
        query: The research question
        sources: List of sources to use (default: all)
        parallel: Whether to run in parallel (default: True)

    Returns:
        Combined results from all sources
    """
    available_sources = {
        "perplexity": run_perplexity,
        "gemini": run_gemini,
        "tavily": run_tavily,
        "exa": run_exa
    }

    if sources is None:
        sources = list(available_sources.keys())

    sources_to_run = {k: v for k, v in available_sources.items() if k in sources}

    print(f"\n{'='*60}")
    print(f"DEEP RESEARCH ORCHESTRATOR")
    print(f"{'='*60}")
    print(f"Query: {query}")
    print(f"Sources: {', '.join(sources_to_run.keys())}")
    print(f"Mode: {'Parallel' if parallel else 'Sequential'}")
    print(f"{'='*60}\n")

    results = []
    start_time = datetime.now()

    if parallel:
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(sources_to_run)) as executor:
            futures = {executor.submit(func, query): name for name, func in sources_to_run.items()}
            for future in concurrent.futures.as_completed(futures):
                source_name = futures[future]
                try:
                    result = future.result()
                    results.append(result)
                    status = "OK" if result["error"] is None else "FAILED"
                    print(f"[{status}] {source_name} completed")
                except Exception as e:
                    results.append({"source": source_name, "result": None, "error": str(e)})
                    print(f"[FAILED] {source_name}: {e}")
    else:
        for name, func in sources_to_run.items():
            print(f"Running {name}...")
            result = func(query)
            results.append(result)
            status = "OK" if result["error"] is None else "FAILED"
            print(f"[{status}] {name} completed")

    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()

    # Create summary
    summary = {
        "query": query,
        "timestamp": start_time.isoformat(),
        "duration_seconds": duration,
        "sources_requested": sources,
        "sources_succeeded": [r["source"] for r in results if r["error"] is None],
        "sources_failed": [r["source"] for r in results if r["error"] is not None],
        "results": results
    }

    # Save summary
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    slug = query[:40].replace(" ", "_").replace("/", "-")
    summary_file = OUTPUT_DIR / f"{start_time.strftime('%Y%m%d_%H%M%S')}_ORCHESTRATOR_{slug}.json"

    with open(summary_file, "w") as f:
        json.dump(summary, f, indent=2, default=str)

    # Create markdown summary
    md_file = summary_file.with_suffix(".md")
    md_content = f"""# Deep Research Results

**Query:** {query}
**Timestamp:** {summary['timestamp']}
**Duration:** {duration:.1f} seconds
**Sources:** {len(summary['sources_succeeded'])}/{len(sources)} succeeded

---

## Summary by Source

"""

    for r in results:
        source = r["source"]
        if r["error"]:
            md_content += f"### [FAILED] {source.title()}\nError: {r['error']}\n\n"
        else:
            result_data = r["result"]
            if source == "perplexity":
                md_content += f"### [OK] Perplexity Deep Research\n\n{result_data.get('content', 'No content')[:2000]}...\n\n"
            elif source == "gemini":
                md_content += f"### [OK] Gemini Research\n\n{result_data.get('content', 'No content')[:2000]}...\n\n"
            elif source == "tavily":
                md_content += f"### [OK] Tavily Search\n\n{result_data.get('answer', 'No answer')[:1500]}\n\n**Sources:** {len(result_data.get('results', []))} found\n\n"
            elif source == "exa":
                exa_results = result_data.get('results', [])[:5]
                md_content += f"### [OK] Exa Semantic Search\n\n**Top Results:**\n"
                for i, er in enumerate(exa_results, 1):
                    md_content += f"{i}. [{er.get('title', 'Untitled')}]({er.get('url', '')})\n"
                md_content += "\n"

    md_content += f"""
---

## Individual Result Files

Check the research-staging folder for detailed results from each source.

**Orchestrator Summary:** `{summary_file.name}`
"""

    with open(md_file, "w") as f:
        f.write(md_content)

    print(f"\n{'='*60}")
    print(f"RESEARCH COMPLETE")
    print(f"{'='*60}")
    print(f"Duration: {duration:.1f} seconds")
    print(f"Succeeded: {len(summary['sources_succeeded'])}/{len(sources)}")
    print(f"Summary: {summary_file}")
    print(f"Markdown: {md_file}")
    print(f"{'='*60}\n")

    return summary

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("""
Deep Research Orchestrator
==========================
Usage: python orchestrator.py "your research query" [sources] [--sequential]

Examples:
  python orchestrator.py "AI agents in 2025"
  python orchestrator.py "quantum computing trends" perplexity,gemini
  python orchestrator.py "market analysis" --sequential

Sources: perplexity, gemini, tavily, exa (default: all)
        """)
        sys.exit(1)

    query = sys.argv[1]

    # Parse optional arguments
    sources = None
    parallel = True

    for arg in sys.argv[2:]:
        if arg == "--sequential":
            parallel = False
        elif "," in arg or arg in ["perplexity", "gemini", "tavily", "exa"]:
            sources = arg.split(",")

    orchestrate(query, sources=sources, parallel=parallel)
