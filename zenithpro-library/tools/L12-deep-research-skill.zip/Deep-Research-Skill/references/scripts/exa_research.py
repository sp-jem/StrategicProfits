#!/usr/bin/env python3
"""
Exa.ai Semantic Search Integration
Neural/semantic search for finding conceptually relevant content
"""

import json
import sys
import os
import requests
from datetime import datetime
from pathlib import Path

CONFIG_PATH = Path(__file__).parent.parent / "api-keys.json"
OUTPUT_DIR = Path(os.path.expanduser("~/research-staging"))

def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)

def research(query: str, search_type: str = "auto", num_results: int = 10, save_output: bool = True) -> dict:
    """
    Execute semantic search via Exa.ai API

    Args:
        query: Research question (can be natural language)
        search_type: "auto", "neural", or "keyword"
        num_results: Number of results to return
        save_output: Whether to save results to file
    """
    config = load_config()
    api_key = config["exa"]["api_key"]

    if not api_key:
        return {"error": "Exa.ai API key not configured. Get one at https://dashboard.exa.ai/api-keys"}

    headers = {
        "x-api-key": api_key,
        "Content-Type": "application/json"
    }

    payload = {
        "query": query,
        "type": search_type,
        "numResults": num_results,
        "contents": {
            "text": True,
            "highlights": True
        }
    }

    print(f"[Exa] Sending query ({search_type}): {query[:100]}...")

    response = requests.post(
        "https://api.exa.ai/search",
        headers=headers,
        json=payload,
        timeout=60
    )

    if response.status_code != 200:
        print(f"[Exa] Error: {response.status_code}")
        print(response.text)
        return {"error": response.text, "status_code": response.status_code}

    result = response.json()

    results = result.get("results", [])

    output = {
        "source": "exa",
        "search_type": search_type,
        "query": query,
        "timestamp": datetime.now().isoformat(),
        "results": results,
        "raw_response": result
    }

    if save_output:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        slug = query[:50].replace(" ", "_").replace("/", "-")
        filename = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_exa_{slug}.json"
        output_path = OUTPUT_DIR / filename

        with open(output_path, "w") as f:
            json.dump(output, f, indent=2)

        # Markdown version
        md_filename = filename.replace(".json", ".md")
        md_path = OUTPUT_DIR / md_filename

        md_content = f"""# Exa.ai Semantic Search Results

**Query:** {query}
**Timestamp:** {output['timestamp']}
**Search Type:** {search_type}

---

## Results

"""
        for i, r in enumerate(results, 1):
            highlights = r.get("highlights", [])
            highlight_text = "\n".join([f"> {h}" for h in highlights[:3]]) if highlights else ""

            md_content += f"""### {i}. {r.get('title', 'Untitled')}
**URL:** {r.get('url', 'N/A')}
**Score:** {r.get('score', 'N/A')}
**Published:** {r.get('publishedDate', 'Unknown')}

{highlight_text}

{r.get('text', 'No text available')[:500]}...

---

"""

        with open(md_path, "w") as f:
            f.write(md_content)

        print(f"[Exa] Results saved to: {output_path}")
        print(f"[Exa] Markdown saved to: {md_path}")

    return output

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python exa_research.py 'your research query' [auto|neural|keyword]")
        sys.exit(1)

    query = sys.argv[1]
    search_type = sys.argv[2] if len(sys.argv) > 2 else "auto"

    result = research(query, search_type=search_type)

    if "error" not in result:
        print("\n" + "="*60)
        print("RESEARCH COMPLETE")
        print("="*60)
        print(f"\nFound {len(result['results'])} semantically relevant results")
        for i, r in enumerate(result['results'][:5], 1):
            print(f"\n{i}. {r.get('title', 'Untitled')}")
            print(f"   {r.get('url', '')}")
