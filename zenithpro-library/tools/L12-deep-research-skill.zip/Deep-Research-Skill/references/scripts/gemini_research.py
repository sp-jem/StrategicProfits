#!/usr/bin/env python3
"""
Gemini API Research Integration
Uses Google's Gemini API for research with web grounding
"""

import json
import sys
import os
import requests
from datetime import datetime
from pathlib import Path

CONFIG_PATH = Path(__file__).parent.parent / "api-keys.json"
OUTPUT_DIR = Path(os.path.expanduser("~/research-staging"))

def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)

def research(query: str, save_output: bool = True) -> dict:
    """Execute research query via Gemini API with grounding"""
    config = load_config()
    api_key = config["gemini"]["api_key"]
    model = config["gemini"].get("model", "gemini-2.0-flash")

    # Gemini API endpoint
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"

    payload = {
        "contents": [
            {
                "parts": [
                    {
                        "text": f"Research the following topic thoroughly. Provide comprehensive information with sources where possible:\n\n{query}"
                    }
                ]
            }
        ],
        "generationConfig": {
            "temperature": 0.7,
            "maxOutputTokens": 8192
        },
        "tools": [
            {
                "googleSearch": {}
            }
        ]
    }

    print(f"[Gemini] Sending query: {query[:100]}...")

    response = requests.post(url, json=payload, timeout=120)

    if response.status_code != 200:
        print(f"[Gemini] Error: {response.status_code}")
        print(response.text)
        return {"error": response.text, "status_code": response.status_code}

    result = response.json()

    # Extract content from Gemini response
    content = ""
    grounding_sources = []

    if "candidates" in result:
        for candidate in result["candidates"]:
            if "content" in candidate and "parts" in candidate["content"]:
                for part in candidate["content"]["parts"]:
                    if "text" in part:
                        content += part["text"]

            # Extract grounding metadata if available
            if "groundingMetadata" in candidate:
                grounding = candidate["groundingMetadata"]
                if "webSearchQueries" in grounding:
                    grounding_sources.extend(grounding.get("groundingChunks", []))

    output = {
        "source": "gemini",
        "model": model,
        "query": query,
        "timestamp": datetime.now().isoformat(),
        "content": content,
        "grounding_sources": grounding_sources,
        "raw_response": result
    }

    if save_output:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        slug = query[:50].replace(" ", "_").replace("/", "-")
        filename = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_gemini_{slug}.json"
        output_path = OUTPUT_DIR / filename

        with open(output_path, "w") as f:
            json.dump(output, f, indent=2)

        # Markdown version
        md_filename = filename.replace(".json", ".md")
        md_path = OUTPUT_DIR / md_filename

        md_content = f"""# Gemini Research Results

**Query:** {query}
**Timestamp:** {output['timestamp']}
**Model:** {model}

---

## Findings

{content}

---

## Grounding Sources

"""
        for source in grounding_sources:
            if isinstance(source, dict):
                md_content += f"- {source.get('web', {}).get('uri', source)}\n"
            else:
                md_content += f"- {source}\n"

        with open(md_path, "w") as f:
            f.write(md_content)

        print(f"[Gemini] Results saved to: {output_path}")
        print(f"[Gemini] Markdown saved to: {md_path}")

    return output

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python gemini_research.py 'your research query'")
        sys.exit(1)

    query = " ".join(sys.argv[1:])
    result = research(query)

    if "error" not in result:
        print("\n" + "="*60)
        print("RESEARCH COMPLETE")
        print("="*60)
        print(result["content"][:2000] + "..." if len(result["content"]) > 2000 else result["content"])
