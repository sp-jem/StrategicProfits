#!/usr/bin/env python3
"""
Tavily API Research Integration
AI-native search API for comprehensive web research
"""

import json
import sys
import os
import requests
from datetime import datetime
from pathlib import Path

CONFIG_PATH = Path(__file__).parent.parent / "api-keys.json"
OUTPUT_DIR = Path(os.path.expanduser("~/research-staging"))

def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)

def research(query: str, search_depth: str = "advanced", save_output: bool = True) -> dict:
    """
    Execute research query via Tavily API

    Args:
        query: Research question
        search_depth: "basic" (1 credit) or "advanced" (2 credits)
        save_output: Whether to save results to file
    """
    config = load_config()
    api_key = config["tavily"]["api_key"]

    if not api_key:
        return {"error": "Tavily API key not configured"}

    headers = {
        "Content-Type": "application/json"
    }

    payload = {
        "api_key": api_key,
        "query": query,
        "search_depth": search_depth,
        "include_answer": True,
        "include_raw_content": False,
        "max_results": 10,
        "include_domains": [],
        "exclude_domains": []
    }

    print(f"[Tavily] Sending query ({search_depth}): {query[:100]}...")

    response = requests.post(
        "https://api.tavily.com/search",
        headers=headers,
        json=payload,
        timeout=60
    )

    if response.status_code != 200:
        print(f"[Tavily] Error: {response.status_code}")
        print(response.text)
        return {"error": response.text, "status_code": response.status_code}

    result = response.json()

    # Extract structured results
    answer = result.get("answer", "")
    results = result.get("results", [])

    output = {
        "source": "tavily",
        "search_depth": search_depth,
        "query": query,
        "timestamp": datetime.now().isoformat(),
        "answer": answer,
        "results": results,
        "raw_response": result
    }

    if save_output:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        slug = query[:50].replace(" ", "_").replace("/", "-")
        filename = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_tavily_{slug}.json"
        output_path = OUTPUT_DIR / filename

        with open(output_path, "w") as f:
            json.dump(output, f, indent=2)

        # Markdown version
        md_filename = filename.replace(".json", ".md")
        md_path = OUTPUT_DIR / md_filename

        md_content = f"""# Tavily Research Results

**Query:** {query}
**Timestamp:** {output['timestamp']}
**Search Depth:** {search_depth}

---

## Answer

{answer}

---

## Sources

"""
        for i, r in enumerate(results, 1):
            md_content += f"""### {i}. {r.get('title', 'Untitled')}
**URL:** {r.get('url', 'N/A')}
**Score:** {r.get('score', 'N/A')}

{r.get('content', 'No content available')[:500]}...

---

"""

        with open(md_path, "w") as f:
            f.write(md_content)

        print(f"[Tavily] Results saved to: {output_path}")
        print(f"[Tavily] Markdown saved to: {md_path}")

    return output

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python tavily_research.py 'your research query' [basic|advanced]")
        sys.exit(1)

    query = sys.argv[1]
    depth = sys.argv[2] if len(sys.argv) > 2 else "advanced"

    result = research(query, search_depth=depth)

    if "error" not in result:
        print("\n" + "="*60)
        print("RESEARCH COMPLETE")
        print("="*60)
        print(f"\nAnswer: {result['answer'][:1500]}...")
        print(f"\nFound {len(result['results'])} sources")
