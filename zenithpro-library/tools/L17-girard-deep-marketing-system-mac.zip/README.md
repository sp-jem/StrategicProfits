# The Girard Deep Marketing System — v1
## René Girard's Mimetic Desire Theory, Applied to AI-Powered Market Intelligence

**Created by:** Rich Schefren / Strategic Profits
**Distributed to:** ZenithPro Members
**Version:** 1.0 — March 2026

---

## What This Is

This package contains 8 Claude Code skills built on René Girard's mimetic desire theory — one of the most powerful and underused frameworks in marketing.

Girard's core insight: **people don't want things independently. They want what they see others wanting.** Desire is triangular — Subject, Model, Object. Whoever is the most visible, credible model for a desired identity wins — not because they have the best product, but because the market has latched onto them as the aspirational target.

These skills map competitive markets at the desire level, not the feature level.

---

## The 8 Skills

### The Intelligence Layer (run these first — they produce the raw data)

| Skill | What It Does | Run |
|-------|-------------|-----|
| `mimetic-market-intelligence` | The core skill. Maps what DESIRES every competitor mediates, where the market has converged into sameness, and where open positioning space exists. 6-document output. | `/mimetic-market-intelligence` |
| `girard-model-map` | Maps the specific 15-30 people your prospects are actually modeling themselves after — behavioral evidence, not self-report | `/girard-model-map {your market}` |
| `girard-desire-propagation` | Tracks which desires are currently spreading through your market, which are fading, and what desire gaps nobody is yet mediating | `/girard-desire-propagation {your market}` |
| `girard-rivalry-detector` | Identifies active peer rivalries in your market, what's being competed over, and where your product could become a contested object | `/girard-rivalry-detector {your market}` |
| `girard-scapegoat-radar` | Detects the common enemies your market is uniting against — and where to position as the alternative before competitors notice | `/girard-scapegoat-radar {your market}` |

### The Application Layer (run these after the intelligence layer)

| Skill | What It Does | Run |
|-------|-------------|-----|
| `girard-desire-autopsy` | Reverse-engineers why a specific launch succeeded or failed using mimetic desire analysis — model type, mediation type, model-market fit | `/girard-desire-autopsy {launch to analyze}` |
| `girard-mimetic-content-strategist` | Produces a quarterly content plan built on desire propagation — not SEO, not algorithms, not editorial calendars. Desire-first. | `/girard-mimetic-content-strategist {your market}` |

### The Synthesis Layer (runs on top of everything)

| Skill | What It Does | Run |
|-------|-------------|-----|
| `girard-field-intelligence` | The master synthesis. Reads all other reports simultaneously, finds cross-layer convergence zones none of the individual skills can see, and produces The Single Move — the one highest-leverage action available in your market right now | `/girard-field-intelligence` |

---

## How to Use This System

### For a New Market Analysis (first time)
1. Run `mimetic-market-intelligence` → gets the competitive desire map
2. Run `girard-model-map` → gets who's actually shaping desire
3. Run `girard-desire-propagation` → gets what desires are moving
4. Run `girard-rivalry-detector` → gets where desire is most intense
5. Run `girard-scapegoat-radar` → gets market cohesion dynamics
6. Run `girard-field-intelligence` → synthesizes everything into The Single Move

### For Launch Preparation
- Run `girard-desire-autopsy` on past launches to diagnose what worked/failed
- Run `girard-mimetic-content-strategist` to build the pre-launch content sequence
- Run `girard-field-intelligence` for the timing intelligence

### For Ongoing Intelligence (Monthly)
- `girard-field-intelligence` auto-refreshes all underlying reports and produces a new Desire Field Briefing
- Can be automated via launchd (setup instructions in the skill file)

---

## Installation

**Mac:** Double-click `install.sh` or run `bash install.sh` in Terminal
**PC:** Right-click `install.ps1` → Run with PowerShell

The installer copies all 8 skills to `~/.claude/skills/` where Claude Code can find them.

---

## Requirements

- Claude Code installed (`claude` command available in terminal)
- Claude Code subscription (Sonnet or Opus recommended for research-heavy skills)
- Skills will automatically use web search when available — this is required for the intelligence layer skills

---

## Key Concepts

**External Mediator:** A model who is aspirational and distant. Generates admiration but not intense purchase desire.

**Internal Mediator:** A model who is a near-peer or rival. Generates intense, rivalry-driven desire that converts at high ticket.

**Desire Triangle:** Subject (your prospect) → Model (the person they're imitating) → Object (the identity/outcome they desire)

**Convergence Zone:** Where multiple desire streams are independently pointing at the same positioning territory simultaneously. Being positioned there before everyone else is the highest-leverage marketing move available.

**Skandalon:** When a model simultaneously represents the dream AND blocks access to it — creates attraction + resentment. Common in high-ticket programs.

---

## Sample Outputs

See `sample-outputs/` for example documents produced by the system:
- `00 - OVERVIEW - Mimetic Market Intelligence.md` — explains the full 6-document methodology
- `01 - Deep Marketing Thinkers - Master List.md` — the broader library of thinkers this system is built from

---

## Questions

Bring questions to ZenithPro calls or the ZenithPro community.
