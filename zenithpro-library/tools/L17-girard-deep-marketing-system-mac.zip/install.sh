#!/bin/bash

# Girard Deep Marketing System — Mac Installer
# Installs all 8 skills to ~/.claude/skills/

echo "Installing Girard Deep Marketing System v1..."
echo ""

SKILLS_DIR="$HOME/.claude/skills"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILLS_SOURCE="$SCRIPT_DIR/skills"

# Create skills directory if it doesn't exist
mkdir -p "$SKILLS_DIR"

# Install each skill
INSTALLED=0
UPDATED=0

for skill_dir in "$SKILLS_SOURCE"/*/; do
    skill_name=$(basename "$skill_dir")
    dest="$SKILLS_DIR/$skill_name"

    if [ -d "$dest" ]; then
        echo "  Updating: $skill_name"
        rm -rf "$dest"
        UPDATED=$((UPDATED + 1))
    else
        echo "  Installing: $skill_name"
        INSTALLED=$((INSTALLED + 1))
    fi

    cp -r "$skill_dir" "$dest"
done

echo ""
echo "Done!"
echo "  Installed: $INSTALLED skills"
echo "  Updated: $UPDATED skills"
echo ""
echo "Skills are now available in Claude Code."
echo "Restart Claude Code if it's already open."
echo ""
echo "Start with: /mimetic-market-intelligence"
echo "Or run the full system: /girard-field-intelligence"
