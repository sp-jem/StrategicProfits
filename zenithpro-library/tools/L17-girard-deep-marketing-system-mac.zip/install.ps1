# Girard Deep Marketing System — Windows Installer
# Installs all 8 skills to ~/.claude/skills/

Write-Host "Installing Girard Deep Marketing System v1..." -ForegroundColor Cyan
Write-Host ""

$SkillsDir = "$env:USERPROFILE\.claude\skills"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillsSource = Join-Path $ScriptDir "skills"

# Create skills directory if it doesn't exist
New-Item -ItemType Directory -Force -Path $SkillsDir | Out-Null

$Installed = 0
$Updated = 0

# Install each skill
Get-ChildItem $SkillsSource -Directory | ForEach-Object {
    $skillName = $_.Name
    $dest = Join-Path $SkillsDir $skillName

    if (Test-Path $dest) {
        Write-Host "  Updating: $skillName"
        Remove-Item $dest -Recurse -Force
        $Updated++
    } else {
        Write-Host "  Installing: $skillName"
        $Installed++
    }

    Copy-Item $_.FullName $dest -Recurse -Force
}

Write-Host ""
Write-Host "Done!" -ForegroundColor Green
Write-Host "  Installed: $Installed skills"
Write-Host "  Updated: $Updated skills"
Write-Host ""
Write-Host "Skills are now available in Claude Code."
Write-Host "Restart Claude Code if it's already open."
Write-Host ""
Write-Host "Start with: /mimetic-market-intelligence"
Write-Host "Or run the full system: /girard-field-intelligence"
