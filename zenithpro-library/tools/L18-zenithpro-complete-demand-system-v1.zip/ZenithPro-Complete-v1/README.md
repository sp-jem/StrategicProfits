# ZenithPro Complete Demand Creation System
### Three Paths. Every Market. One Entry Point.

---

## How This Works

Every market has a motivation direction. People buy because they're moving **away** from something (pain, frustration, failure) or **toward** something (aspiration, identity, mastery) — or both.

ZenithPro now has a complete demand creation pipeline for each direction.

**Step 1: Run the Motivation Spectrum Analyzer** (top-level folder)
This tells you which path to use. It scores your market as a percentage — e.g., "82% Away / 18% Toward" — and tells you exactly which pipeline to run.

**Step 2: Run the appropriate path.**

---

## The Three Paths

### 01-Away-Path
**For markets where buyers move AWAY from pain, frustration, or failure.**

The original ZenithPro demand creation pipeline. Built for markets where:
- Buyers express frustration with past attempts ("I've tried everything")
- Pain is urgent and escalating
- Mechanism credibility ("why will THIS work?") is the primary gate
- The Core Concept explains why nothing worked before

**10 skills | Orchestrator: `/demand-architect`**

---

### 02-Toward-Path
**For markets where buyers move TOWARD aspiration, identity, or mastery.**

Built for markets where:
- Buyers aspire to become a certain kind of person
- Community and tribal belonging drive decisions
- Identity permission ("is this available to someone like me?") is the primary gate
- The Core Concept opens access to a desired identity

**11 skills | Orchestrator: `/toward-demand-architect`**

---

### 03-Hybrid-Path
**For markets where buyers are meaningfully motivated in BOTH directions.**

Built for markets where the motivation is mixed — e.g., 55% toward / 45% away. The hybrid pipeline:
- Maps both the pain and the aspiration simultaneously
- Builds Core Concepts that address structural reasons for the pain AND open the desired identity
- Uses Hybrid Copy Formulas: *"Become the kind of person who never has to deal with [pain] again"*
- Produces dual belief gap maps (mechanism credibility + identity permission)

**11 skills | Orchestrator: `/zenithpro`**

---

## Which Path Do I Use?

Run the Motivation Spectrum Analyzer first:
```
/motivation-spectrum-analyzer [your market description]
```

| Result | Path to Use |
|--------|-------------|
| 85%+ Away | Away Path → `/demand-architect` |
| 60-84% Away | Away Path (primary) or Hybrid Path |
| 45-59% either direction | Hybrid Path → `/zenithpro` |
| 60-84% Toward | Toward Path (primary) or Hybrid Path |
| 85%+ Toward | Toward Path → `/toward-demand-architect` |

---

## How to Install

### Option A: Install everything (all three paths + spectrum analyzer)

**Mac:**
```bash
# Install spectrum analyzer
cd motivation-spectrum-analyzer/unzipped && bash install.sh && cd ../..

# Install Away Path
cd 01-Away-Path && unzip Away-Path-mac.zip -d away-install && cd away-install && bash install-all.sh && cd ../..

# Install Toward Path
cd 02-Toward-Path && unzip Toward-Path-mac.zip -d toward-install && cd toward-install && bash install-all.sh && cd ../..

# Install Hybrid Path
cd 03-Hybrid-Path && unzip Hybrid-Path-mac.zip -d hybrid-install && cd hybrid-install && bash install-all.sh && cd ../..
```

**PC (PowerShell):**
Same structure using `install-all.ps1` from each path's zip.

### Option B: Install just one path

Unzip the relevant path zip and run `install-all.sh` (Mac) or `install-all.ps1` (PC). Always install the spectrum analyzer first.

### Option C: Install individual skills

Each skill has its own folder with `unzipped/install.sh` and `unzipped/install.ps1`.

---

## Running the Pipelines

```bash
# Step 1 — always run first
/motivation-spectrum-analyzer [describe your market]

# Step 2 — based on the result:
/demand-architect [market]              # Away Path
/toward-demand-architect full [market]  # Toward Path
/zenithpro [market]                     # Hybrid Path
```

---

## What Each Path Produces

All three paths produce the same set of demand creation intelligence:
- Desire hierarchy map
- Psychographic excavation
- Avatar profiles
- Pattern analysis (failure or progression)
- Core Concept candidates (validated + scored)
- Buying state definition
- Belief gap map
- USP
- Competitive intelligence
- Community architecture
- Integrated demand brief

The content differs based on market motivation. The structure is the same.

---

*ZenithPro Complete — v1.0*
*Away Path + Toward Path + Hybrid Path + Motivation Spectrum Analyzer*
