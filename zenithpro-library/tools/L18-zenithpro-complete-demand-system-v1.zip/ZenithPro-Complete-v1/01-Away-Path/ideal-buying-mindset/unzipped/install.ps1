$SkillName = "ideal-buying-mindset"
$InstallDir = "$env:USERPROFILE\.claude\skills\$SkillName"
Write-Host "Installing $SkillName..."
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item SKILL.md "$InstallDir\SKILL.md"
if (Test-Path "$InstallDir\SKILL.md") {
    Write-Host "✅ $SkillName installed to $InstallDir"
} else { Write-Host "❌ Installation failed."; exit 1 }
