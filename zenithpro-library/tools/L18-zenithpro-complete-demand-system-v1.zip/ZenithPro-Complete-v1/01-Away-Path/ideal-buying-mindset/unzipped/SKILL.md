---
name: ideal-buying-mindset
description: "Forensically defines the exact mental and emotional state prospects must reach for buying to become automatic and inevitable. Maps 4 dimensions: Logical Beliefs (rational), Emotional Feelings (limbic), Contextual Perceptions (worldview), and Identity Alignment (self-concept). Produces Point B — the complete buying-ready state that becomes the destination for all belief-gap work. Run this to define Point B before running belief-gap-analyzer."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/ideal-buying-mindset [market or avatar]"
  called_by: [user]
  outputs_to: [project folder]
---

# Ideal Buying Mindset

Blueprints the complete internal state where buying becomes automatic. Not a description of desire — a precise specification of the psychological state where selling becomes superfluous.

---

## LAYER 1: INVARIANTS

1. **Point B is a psychological state, not a marketing message.** You're mapping where their HEAD needs to be, not what you want to say to them.
2. **All four dimensions are mandatory.** A prospect who has the right logical beliefs but wrong emotional state won't buy. A prospect with right emotions but wrong identity alignment won't buy. All four must align.
3. **Point B must be purchaser-realistic.** If reaching Point B requires beliefs that real humans in this market couldn't hold, you've defined an impossible destination. Ground it in what actual buyers have reported thinking.
4. **Specificity over generality.** Not "they should feel confident" — "they should believe they can do X even though they failed at Y, because Z explains the difference."
5. **Save all outputs to files.** Never deliver in chat only.

---

## PURPOSE

Peter Drucker's vision realized: "The aim of marketing is to know and understand the customer so well the product or service fits him and sells itself. All that should be needed then is to make the product or service available."

This tool crystallizes that exact "ready to buy" state.

When a prospect is at Point B:
- They've already made the internal decision
- The purchase is simply execution of a decision already reached
- Objections have already been resolved internally
- Price is contextualized as investment, not expense
- Delay feels more painful than action

**Output use:** Point B becomes the destination for belief-gap-analyzer. Every marketing activity's purpose is to move prospects from Point A to Point B.

---

## INPUTS

Required:
1. **Market/avatar description** (who they are, what they want)
2. **Product/service being sold** (what you offer and what it delivers)
3. **Desire Hierarchy Map** (from demand-desire-mapper — which L1-L4 desires are active)
4. **Psychographic research** (from psychographic-excavation — especially Phase 7 rage points and Phase 8 buying behavior)
5. **Avatar excavation** (specifically Sections H and J — decision neuroscience and objection archaeology)
6. **Output folder path**

---

## THE FOUR DIMENSIONS OF BUYING READINESS

### DIMENSION 1: LOGICAL BELIEFS (The Rational Mind)

What they must intellectually internalize as irrefutable truth before purchase feels rational:

**Category A: Problem Beliefs**
They must believe with certainty:
1. The problem is REAL (not imagined or exaggerated)
2. The problem is URGENT (not "someday I'll deal with this")
3. The problem is SOLVABLE (not a permanent condition)
4. The problem is COSTLY (quantify the cost in money, time, opportunity, identity)
5. The problem WILL ESCALATE without intervention (delay gets more expensive)

For each belief: State the exact belief AND what evidence creates it.

**Category B: Solution Beliefs**
They must comprehend and embrace:
1. A solution EXISTS in this category (category-level trust)
2. Your specific solution is DIFFERENT from what they've tried (differentiation)
3. Your mechanism actually WORKS for the root cause (not just symptoms)
4. They've been failing because of the METHOD, not because of THEM (attribution shift)
5. The investment is JUSTIFIED by the return (ROI belief)

**Category C: Provider Beliefs**
They must trust:
1. You have relevant EXPERTISE and authority
2. You've delivered results for people LIKE THEM
3. Your motives are aligned with their SUCCESS (not just their payment)
4. You can DELIVER what you promise (track record)

**Category D: Timing Beliefs**
They must believe:
1. NOW is the optimal time (not later)
2. Waiting has a QUANTIFIABLE COST
3. The RISK of inaction exceeds the risk of action
4. They have everything REQUIRED to start

---

### DIMENSION 2: EMOTIONAL FEELINGS (The Limbic System)

What they must viscerally experience at cellular intensity:

**Positive States Required:**
- HOPE — genuine belief that change is possible for someone like them
- EXCITEMENT — energy around the transformation coming
- TRUST — felt sense that you're on their side
- READINESS — body feels prepared, not resistant

**Negative States Required (Productive Tension):**
- DISSATISFACTION — current situation is genuinely unacceptable
- URGENCY — can't wait any longer
- FRUSTRATION — tired of the old approach
- PAIN — the cost of the problem is felt, not just known

**States That Must Be ABSENT:**
- Shame (blocks purchase — they feel unworthy)
- Fear of being judged (blocks disclosure of real situation)
- Distrust (blocks commitment)
- Cynicism (blocks belief in possibility)
- Overwhelm (blocks decision)

For each required emotional state: What content/experience creates it? What destroys it?

---

### DIMENSION 3: CONTEXTUAL PERCEPTIONS (The Worldview)

How they must perceive and interpret their environment:

**Situation Perception:**
- They see their situation as FIXABLE, not hopeless
- They see the OPPORTUNITY in their situation (not just the problem)
- They perceive themselves as CLOSE to a breakthrough (not far from it)
- They see others in similar situations succeeding (possible, not theoretical)

**Timing Perception:**
- This moment is a TURNING POINT (not just another day)
- The AI/market/opportunity window is OPEN NOW (won't always be)
- They are at an INFLECTION POINT where the right move multiplies

**Social/Environmental Perception:**
- People they respect are making this kind of investment
- NOT making this move is the RISKIER choice
- Their peers who DON'T do this will fall behind

**Category Perception:**
- This solution category is LEGITIMATE (not another scam)
- Previous failures were due to WRONG APPROACH, not category failure
- The right solution in this category DOES exist

---

### DIMENSION 4: IDENTITY ALIGNMENT (The Self-Concept)

Who they must envision themselves becoming:

**The New Identity Label:**
What specific identity do they need to claim before purchase feels right?
- NOT: "I'm the kind of person who invests in courses"
- YES: "I'm the kind of entrepreneur who builds leverage through AI systems"

**Identity Bridges Required:**
What must shift in how they see themselves?

1. From [current limiting identity] to [enabling identity that makes purchase feel congruent]
2. From [role they're playing] to [role they're stepping into]

Example bridges:
- "From tactician to strategist" (stops them from saying "I don't need more strategy")
- "From solo operator to system architect" (stops them from saying "I work differently")
- "From learner to implementer" (stops them from saying "I need more information first")

**The Identity Permission:**
What do they need to give themselves permission to be/do?
- "I'm allowed to invest at this level"
- "I'm allowed to ask for help at this stage"
- "I'm allowed to be the person who has AI working for them"

**The Identity Cost of NOT Buying:**
What identity story do they tell if they DON'T buy?
- "I stayed stuck when I had the chance to change"
- "I let fear stop me again"
- "I'm the kind of person who talks about doing things but doesn't"

The Point B Identity must be MORE appealing than the non-buyer identity.

---

## THE IDEAL BUYING MINDSET STATE

After mapping all four dimensions, synthesize into:

**THE COMPLETE POINT B STATEMENT**

"A prospect is at Point B when they:

**Logically believe:** [5-7 specific belief statements that are true]

**Emotionally feel:** [3-5 specific emotional states present, 3-5 states absent]

**Contextually perceive:** [3-5 specific ways they see their situation and environment]

**Identify as:** [The specific identity they've claimed that makes purchase congruent]

When all of these are present simultaneously, purchase is not a selling situation — it's a logistics situation. The only remaining question is HOW to buy, not WHETHER to buy."

---

## THE OBJECTION RADAR

Map the objections that arise when ANY dimension is incomplete:

| Incomplete Dimension | Resulting Objection | Correction Required |
|---------------------|--------------------|--------------------|
| Missing logical belief about problem urgency | "I'll do this later" | Quantify the cost of delay |
| Missing logical belief about attribution | "I'm not sure this will work for me" | Address past failures specifically |
| Missing emotional hope | "I've tried this before" | Peer story with similar background |
| Missing emotional trust | "This sounds too good to be true" | Specific proof with details |
| Missing contextual urgency | "I need to think about it" | Time-bound opportunity framing |
| Missing identity permission | "This is a lot of money" | Reframe investment relative to identity claim |

---

## OUTPUT SPECIFICATION

**File: `Ideal-Buying-Mindset-[Market].md`**

Sections:
1. The Four Dimensions (all beliefs, feelings, perceptions, and identity elements specified)
2. The Complete Point B Statement
3. The Objection Radar (incomplete dimension → objection → correction)
4. Transition Guide (from Point A to Point B — what moves them through each dimension)
5. Calibration Notes (how to know when a prospect has reached Point B)

**Target length:** 1,500-2,500 words.

---

## CALIBRATION NOTES

Signs a prospect has reached Point B:
- They ask HOW questions, not WHETHER questions ("How does payment work?" not "Is this worth it?")
- They start visualizing themselves using the solution ("I would use this for...")
- They reference the cost of NOT buying ("I can't keep doing what I'm doing")
- Their objections become tactical, not existential
- They ask about start dates, next steps, or logistics

Signs they're NOT at Point B (and which dimension is missing):
- "I need to think about it" → Missing identity alignment or emotional permission
- "I can't afford it" → Missing logical ROI belief OR emotional readiness
- "Send me some more information" → Missing trust OR still processing emotionally
- "It worked for others but I'm different" → Missing self-efficacy belief (identity dimension)

---

## QUALITY GATE

- [ ] All four dimensions fully mapped (not just one or two)
- [ ] Specific belief statements written (not vague "they need to feel confident")
- [ ] Emotional states mapped (both required states AND states that must be absent)
- [ ] Identity labels specified (the exact identity claim that enables purchase)
- [ ] Objection Radar complete
- [ ] Complete Point B Statement written as a test (if you can't write it in one coherent paragraph, the mapping is incomplete)
- [ ] Saved to file

---

## HOW THIS CONNECTS DOWNSTREAM

- **belief-gap-analyzer** → Point B from this skill IS the destination for the belief gap analysis
- **core-concept-generator** → The Core Concept lands on the Logical and Contextual dimensions — check against this map
- **webinar structure** → Each section of a webinar moves prospects through a different dimension (intro = emotional, content = logical, transition = contextual, close = identity)
- **mimetic-market-intelligence Phase 2 (Doc 5)** → Desire Unification Strategy maps which products take the buyer to which level of the buying mindset
