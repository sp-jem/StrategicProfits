---
name: core-concept-generator
description: "Generates 5 Core Concepts — the paradigm-shifting one-sentence reframes that make purchasing inevitable. A Core Concept is NOT a tagline or benefit. It's a belief-level intervention that, once accepted, makes NOT buying irrational. Run failure-pattern-forensics FIRST and feed its output here. Uses 5 generation formulas: Invisible Pivot Point, False Enemy, Expertise Trap, Systemic Mismatch, and Success Paradox."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/core-concept-generator [market or avatar]"
  called_by: [user]
  outputs_to: [project folder]
---

# Core Concept Generator

Produces the paradigm shift that makes purchase inevitable. Not a positioning statement. Not a tagline. A single reframe that, once accepted, makes everything else obvious.

---

## LAYER 1: INVARIANTS

1. **A Core Concept is a BELIEF INTERVENTION, not a marketing claim.** If it sounds like something you'd put in an ad, it's not a Core Concept — it's a benefit statement.
2. **The "inevitability test" is mandatory.** For every concept generated: "If they accept this, is buying the logical next step? Does NOT buying become irrational?" If the answer is no, discard.
3. **Specificity is non-negotiable.** "You're losing $2,192 every day" beats "you're losing money." Real numbers, real stakes, real examples.
4. **Every concept must pass all four quality tests** before being included in the output.
5. **Save all outputs to files.** Never deliver in chat only.

---

## PURPOSE

The Core Concept is the highest-leverage piece of intellectual property in demand creation.

It's the point at which a prospect thinks: **"Oh my God. THAT'S why nothing has worked."**

When a Core Concept lands, it does four things simultaneously:
1. Explains every past failure
2. Creates urgent dissatisfaction with the current state
3. Frames the solution as the only logical response
4. Makes delay feel expensive

**The success formula:** If prospect accepts [Core Concept] → purchasing [your solution] becomes an IQ test they must pass.

**Output use:** The Core Concept drives: headline strategy, webinar structure, email sequences, ad creative, sales conversations, and offer presentation.

---

## INPUTS

Required before running:

1. **Failure Pattern Report** (paste output from failure-pattern-forensics — especially the Distinction Candidates section)
2. **Market/avatar description** (who they are, what they're trying to do)
3. **Product/solution description** (what you sell and how it works)
4. **Desire Hierarchy Map** (from demand-desire-mapper — which L1 desires are primary)
5. **Psychographic research** (from psychographic-excavation — especially rage points and failed solutions)
6. **Output folder path**

Optional but valuable:
- Existing testimonials or case studies (for proof architecture)
- Competitor positioning (what everyone else is claiming)

---

## PRELIMINARY ANALYSIS (Run Before Generation)

### Step 1: Extract the Market's Bleeding Neck

From the input documents, identify:

**The Daily Bleed (Quantified):**
- What are they losing every day/week/month?
- What opportunity cost compounds while they delay?
- What competitive ground are they surrendering?
- Assign a specific dollar or consequence figure

**The Identity Wound (Psychological):**
- Where do they feel fraudulent or split?
- What competence/incompetence paradox tortures them?
- What should work given their expertise but doesn't?

**The Failed Pattern (Historical):**
- What have they tried 5-10 times that should work but didn't?
- How much have they invested in solutions that failed?
- What approach does everyone default to that's fundamentally broken?

### Step 2: Find the Invisible Distinction

Look for the distinction hiding in plain sight:

**The Level Error:**
- What level are they operating at? (tactical vs. strategic, symptoms vs. root cause)
- What level does success actually require?
- Why does nobody see this level distinction?

**The Category Error:**
- What category do they think they're in?
- What category are they actually in?
- How does this misunderstanding guarantee failure?

**The Mechanism Error:**
- What mechanism do they think drives success?
- What mechanism actually drives success?
- Why is the real mechanism counter-intuitive?

### Step 3: The Master Question

Before generating any concepts, answer this:

> **"What would need to be true about their problem for my solution to be the ONLY logical response?"**

Write this out explicitly. All 5 concepts must point toward this truth from different angles.

---

## THE 5 GENERATION FORMULAS

Generate at least one concept using each formula.

---

### Formula 1: The Invisible Pivot Point

> **"It's not [Surface Problem]. It's [Invisible Pivot Point] that determines everything."**

**Process:**
1. List their top 3-5 visible struggles
2. Find the single invisible factor that controls ALL of them
3. Name this factor with unexpected precision
4. Show how fixing this pivot point cascades everything else

**Quality Test:** Would accepting this pivot point make them say "Oh my God, THAT'S why nothing has worked"?

**Example level (agency owner):** "You can't scale past $83K/month because you've built a consulting firm that cosplays as an agency. Every new client makes this worse, not better. You're not growing — you're inflating."

---

### Formula 2: The False Enemy

> **"You're not fighting [What You Think]. You're fighting [Real Enemy] and your current approach makes it stronger."**

**Process:**
1. Identify what they think their enemy is (from failure-pattern-forensics Part 6)
2. Reveal the actual enemy hiding behind it
3. Show how their current approach strengthens the real enemy
4. Position your solution as the only way to defeat the real enemy

**Quality Test:** Does this make them immediately stop what they're doing?

**Example level:** "Your marketing doesn't fail because you're bad at marketing. It fails because marketing tactics are designed for people selling TO desire. As a consultant, you must sell THROUGH desire. Until you understand this distinction, you'll keep bleeding $2,192 every single day."

---

### Formula 3: The Expertise Trap

> **"Your expertise in [Strength Area] is precisely what blinds you to [Critical Insight] in [Problem Area]."**

**Process:**
1. Identify their greatest strength/expertise
2. Show how this strength creates a specific blindness
3. Reveal what they can't see because of this strength
4. Position solution as "expertise translator" not replacement

**Quality Test:** Does this resolve their impostor syndrome while explaining their struggle?

**Example level:** "Your 15 years of industry knowledge is why your AI implementation keeps failing. You know too much about how things 'should' work to let AI rewrite the rules. The businesses winning with AI aren't the ones with deep expertise — they're the ones willing to let AI teach them what the experts missed."

---

### Formula 4: The Systemic Mismatch

> **"You're applying [System Type A] to a [System Type B] problem. That's like [Vivid Analogy]."**

**Process:**
1. Identify the type of system/thinking they're applying
2. Reveal the actual system type they're dealing with
3. Create a memorable analogy for the mismatch
4. Show why only proper system match works

**Quality Test:** Does the analogy make the problem immediately and viscerally obvious?

**Example level:** "You're solving an information problem with more information. But this isn't an information problem — it's a behavior change problem. More information to a behavior change problem is like adding more runway to a car that can't fly."

---

### Formula 5: The Success Paradox

> **"The very thing that got you to [Current Level] is what's preventing you from reaching [Next Level]."**

**Process:**
1. Identify what created their current success
2. Show how this becomes a liability at the next level
3. Reveal the painful identity shift required
4. Position solution as identity evolution tool

**Quality Test:** Does this explain why successful people struggle here?

**Example level:** "Your success at managing human teams is the exact thing making your AI team ineffective. Human management is about motivation and accountability. AI management is about architecture and precision. You're managing machines like people, and it's costing you 80% of the output you should be getting."

---

## FOUR QUALITY TESTS (All Required)

For each concept generated, verify all four tests pass:

### Test 1: The "Holy Shit" Test
- Does it create an instant paradigm shift?
- Would they immediately text this to a colleague?
- Does it make their past failures suddenly make sense?

### Test 2: The Inevitability Test
- If they accept this concept, is buying inevitable?
- Does NOT buying become irrational?
- Does delaying feel expensive (can you quantify the cost of waiting)?

### Test 3: The Memorability Test
- Can they explain it in one sentence?
- Would they remember it a week later without notes?
- Could they teach it to someone else?

### Test 4: The Differentiation Test
- Does it make competitors irrelevant (not just inferior)?
- Does it create a conversation competitors can't participate in?
- Does it own new vocabulary that you define?

Discard any concept that fails any test. Only present concepts that pass all four.

---

## OUTPUT FORMAT

For each Core Concept (target: 5 passing all four tests):

---

### CONCEPT #[X]: [Memorable Name]

**The Core Concept** (the single sentence):
> "[The concept that reframes everything]"

**The Four Tests:**
- Holy Shit Test: [Pass/Fail + brief note]
- Inevitability Test: [Pass/Fail + what buying decision it drives]
- Memorability Test: [Pass/Fail + one-sentence version]
- Differentiation Test: [Pass/Fail + what conversation this owns]

**The Breakdown:**
- Old Reality: [What they believe that's wrong]
- New Reality: [What's actually true]
- Why This Matters: [The cascading implications — what changes when they accept this]

**The ABC Reframe:**
- A (Surface Problem): [What they think is wrong]
- B (Failed Solution): [What they're trying that fails]
- C (Real Problem): [What your concept reveals — the actual root]

**The Vivid Enemy:**
[Give the real enemy a memorable name. Something they can now see and fight.]

**Proof Architecture:**
- Statistical proof: [Number or data point that supports this]
- Logical proof: [The reasoning that makes it obvious]
- Experiential proof: [Something they've already experienced that validates this]

**The Transformation Story** (2-3 sentences):
[How their world changes when they accept this concept]

**Implementation Triggers:**
- Opening hook: [Question or statement that triggers recognition]
- Educational sequence: [3 content pieces that install this belief]
- Resistance points: [2-3 objections and how the concept handles them]

**Market Response Prediction:**
- Early adopters will say: "[Their excited response]"
- Skeptics will ask: "[Their challenging question]"
- Success indicator: [Specific behavior change you'll see]

---

## CONCEPT RANKING

After generating all 5, rank them:

1. **Strongest for immediate conversion** (webinar/sales page use)
2. **Strongest for content/education** (building the belief over time)
3. **Strongest for differentiation** (owning category-level conversation)
4. **Strongest for virality** (most likely to be shared)
5. **Strongest for objection prevention** (addresses deepest skepticism)

Recommend the primary concept and explain the strategic reasoning.

---

## QUALITY GATE

- [ ] 5 concepts generated, each using a different formula
- [ ] All 4 quality tests passed for each concept included
- [ ] Each concept includes full proof architecture
- [ ] Concept ranking with strategic reasoning complete
- [ ] Output saved to file

---

## HOW THIS CONNECTS DOWNSTREAM

- **belief-gap-analyzer** → The Core Concept is often the "master bridge" — identify which L2/L3 beliefs it shifts
- **ideal-buying-mindset** → The Core Concept is what creates the Ideal Buying Mindset when it lands
- **mimetic-market-intelligence** → The Core Concept must mediate a desire competitors aren't already mediating (check Phase 1 Convergence Map)
- **usp-generator** → The USP is the Core Concept expressed as a deliverable promise
- **Copywriting skills** → The Core Concept drives the headline, lead, and body copy for all sales materials
