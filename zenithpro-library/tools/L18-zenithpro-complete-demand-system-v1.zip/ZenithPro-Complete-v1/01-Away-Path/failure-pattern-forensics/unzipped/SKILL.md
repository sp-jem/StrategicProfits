---
name: failure-pattern-forensics
description: "Forensic excavation of why a target market perpetually fails despite deploying multiple solutions. Produces a Failure Archaeology Report that identifies the hidden pattern behind all their attempts, the false beliefs they hold as truth, who transcends the pattern and why, the operational level gap, core paradoxes, and the false enemy they're fighting. Critical input for Core Concept development — this is the pre-prompt that makes the Core Concept generator devastating."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/failure-pattern-forensics [market or avatar description]"
  called_by: [user]
  outputs_to: [project folder]
---

# Failure Pattern Forensics

Illuminates the invisible architecture behind market struggles. Forensically dissects WHY the target market perpetually fails — not the surface symptoms, but the hidden structural pattern orchestrating all their failures.

---

## LAYER 1: INVARIANTS

1. **The pattern must explain ALL the failures, not just some.** If your identified pattern doesn't account for why approach A, B, and C all failed, you haven't found the real pattern yet.
2. **The false enemy diagnosis must be specific.** "They think their enemy is X but it's actually Y" — both X and Y must be named precisely.
3. **Success anomaly analysis is mandatory.** Someone in every market transcends the failure pattern. Studying those outliers reveals the hidden distinction.
4. **No consulting-speak.** Every insight must be expressed in language the prospect would actually recognize as true about themselves.
5. **Save all outputs to files.** Never deliver in chat only.

---

## PURPOSE

This is the pre-work that makes Core Concept development possible.

Rich's Core Concepts work because they illuminate the simple, hidden truth that explains why everything else has failed. To generate that truth, you must first excavate the complete failure archaeology.

When done correctly, this produces the raw material for the Core Concept that creates: **"Oh my God. THAT'S why nothing has worked."**

**Output use:** Direct input into core-concept-generator. Also feeds belief-gap-analyzer (which beliefs perpetuate the failure pattern) and psychographic-excavation (if not already run).

---

## INPUTS

1. **Market/avatar description** (who they are, what they're trying to accomplish)
2. **Known failure patterns** (if the user has observations, include them; the skill will add more)
3. **Psychographic research** (paste from psychographic-excavation if run — especially Phase 2: Solution Graveyard)
4. **Avatar profiles** (paste from avatar-excavation if run — especially purchase psychology and objections)
5. **Output folder path**

---

## THE SIX-PART FORENSIC EXCAVATION

### PART 1: THE GRAVEYARD ARCHAEOLOGICAL INVENTORY

Chronicle 10-20 specific interventions this avatar has deployed that should have catalyzed success but instead collapsed:

For each category, list specific examples:
- Courses/programs invested in
- Tactics deployed
- Strategies attempted
- Experts hired/consulted
- Tools integrated
- Methodologies systematized

**For each intervention, forensically document:**
- What they anticipated would happen
- What actually manifested
- How long they persisted with implementation
- Why they believe it collapsed
- What they pivoted to subsequently

**Critical question to answer:** Is there a pattern in WHAT they tried? Do all the approaches share a common assumption that turned out to be wrong?

---

### PART 2: THE ASSUMPTION FORENSIC AUDIT

Excavate and catalogue 10-15 fundamental assumptions this market harbors that are systematically false:

For each false assumption:
- State the assumption ("What everyone knows")
- State the reality (what's actually true)
- Explain why the assumption persists (it feels logical, it's what experts teach, it worked before but the conditions changed, etc.)
- Identify the damage it causes (how believing this guarantees failure)

Categories to investigate:
- "What everyone knows" that contradicts reality
- Common advice that actively sabotages progress
- Industry "best practices" that undermine their specific context
- Logical approaches that generate illogical outcomes
- "Obvious" solutions that amplify existing problems

---

### PART 3: THE SUCCESS ANOMALY ANALYSIS

Isolate and dissect 5-10 cases where someone in this market transcended the pattern:

For each success anomaly:
- What did they do differently?
- What conventional wisdom did they deliberately ignore?
- At what operational level were they thinking (tactical vs. strategic, symptoms vs. root cause)?
- What invisible advantage did they leverage?
- What critical distinction did they understand that others didn't?

**The critical question:** Is there a pattern in how outliers succeed? Do they all share a common understanding that most people in the market lack?

---

### PART 4: THE MULTI-LEVEL TRIANGULATION

Map where this market operates versus where success demands operating:

**Surface Level (What they fixate on):**
- Visible activities they execute
- Tactics they deploy
- Metrics they monitor
- What their effort looks like to an observer

**Hidden Level (What actually catalyzes outcomes):**
- Invisible factors orchestrating results
- Strategic elements governing success
- Real drivers determining trajectory
- What's happening underneath the activity

**The Level Gap:**
- They navigate at: [Diagnosis]
- Success demands operating at: [Requirement]
- The invisible gap: [What they cannot perceive because they're operating at the wrong level]
- Why this gap is hard to see: [The reason the wrong level feels like the right level]

---

### PART 5: THE PARADOX PATTERN RECOGNITION

Crystallize 5-10 paradoxes/contradictions embedded in this market:

Categories to investigate:
- **The Strength-Weakness Paradox:** What specific strength in this market metamorphoses into a weakness at the next level?
- **The Solution-Problem Paradox:** What solution creates a new problem worse than the original?
- **The Effort-Results Paradox:** How does intensified effort deteriorate results in this context?
- **The Expertise-Blindness Paradox:** What expertise in X prevents mastery in Y?
- **The Success-Ceiling Paradox:** What elevated them to here that now sabotages the next level?

For each paradox: State it precisely, explain why it's invisible to people inside it, and show how recognizing it creates an immediate reframe.

---

### PART 6: THE FALSE ENEMY DIAGNOSIS

Forensically contrast what this market perceives as the enemy versus the authentic adversary:

**What they believe they're combating:**
- [The stated problem — competition, lack of time, lack of money, wrong tools, etc.]

**What they're actually confronting:**
- [The real structural issue creating all the symptoms]

**How their current approach fortifies the real enemy:**
- [Why fighting the false enemy makes the real enemy stronger]

**Why they cannot discern the authentic threat:**
- [The mechanism that keeps the real enemy invisible — usually because confronting it requires confronting something uncomfortable about themselves or their assumptions]

---

## OUTPUT FORMAT

**File: `Failure-Pattern-Forensics-[Avatar/Market].md`**

Structure:

```
FAILURE ARCHAEOLOGY FORENSIC REPORT: [AVATAR NAME]

THE PATTERN DIAGNOSIS:
[One paragraph crystallizing the overarching pattern across all 6 parts]

THE GRAVEYARD INVENTORY (What They've Deployed):
1. [Approach]: Anticipated [X], Manifested [Y], Collapsed because [Z]
[Continue for 10-20 items]

FALSE BELIEF ARCHITECTURE (What They Perceive as Truth):
1. They harbor the belief [X] but reality demonstrates [Y]
[Continue for 10-15 items]

SUCCESS ANOMALY PATTERNS (Who Transcends and Why):
1. [Success case]: Transcended because they comprehended [distinction]
[Continue for 5-10 cases]

THE OPERATIONAL LEVEL GAP:
They navigate at: [Level diagnosis]
Success demands operating at: [Level requirement]
The invisible gap: [What they cannot perceive]

THE CORE PARADOXES:
1. [Paradox 1]
2. [Paradox 2]
[Continue for 5-10 paradoxes]

THE FALSE ENEMY DIAGNOSIS:
They perceive the enemy as: [X]
The authentic enemy is: [Y]
Why they cannot discern it: [Z]

HIDDEN DISTINCTION CANDIDATES:
Based on this forensic excavation, here are 5 simple distinctions
that could illuminate everything:
1. [A vs. B paradigm]
2. [X vs. Y framework]
[Continue for 5 distinctions]
```

---

## THE DISTINCTION CANDIDATES

The most important output of this entire exercise: 5 simple A vs. B distinctions that, if understood, would explain why everything else has failed.

These become the raw material for the Core Concept Generator.

A strong distinction:
- Is simple to state (one sentence)
- Is surprising (not what they currently believe)
- Explains multiple past failures simultaneously
- Makes the solution obvious once accepted
- Cannot be argued with (it's demonstrably true)

---

## QUALITY GATE

- [ ] Pattern Diagnosis explains ALL the graveyard items (not just some)
- [ ] At least 10 items in the Graveyard Inventory
- [ ] At least 5 False Beliefs identified (not just problems — beliefs that feel true but aren't)
- [ ] At least 3 Success Anomalies analyzed
- [ ] False Enemy Diagnosis includes WHY it's invisible (not just what it is)
- [ ] 5 Distinction Candidates produced
- [ ] Output saved to file

---

## HOW THIS CONNECTS DOWNSTREAM

- **core-concept-generator** → This is the DIRECT input. The distinction candidates feed straight into the Core Concept formulas.
- **belief-gap-analyzer** → The false beliefs become the Point A beliefs to overcome
- **demand-desire-mapper** → The false enemy often reveals which L2/L3 beliefs are broken
- **mimetic-market-intelligence** → The industry's shared false beliefs often come from competitors collectively mediating the wrong desire
