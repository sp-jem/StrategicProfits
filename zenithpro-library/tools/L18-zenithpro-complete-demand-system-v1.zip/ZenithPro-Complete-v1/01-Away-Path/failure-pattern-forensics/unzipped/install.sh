#!/bin/bash
SKILL_NAME="failure-pattern-forensics"
INSTALL_DIR="$HOME/.claude/skills/$SKILL_NAME"
echo "Installing $SKILL_NAME..."
mkdir -p "$INSTALL_DIR"
cp SKILL.md "$INSTALL_DIR/SKILL.md"
if [ -f "$INSTALL_DIR/SKILL.md" ]; then
  echo "✅ $SKILL_NAME installed to $INSTALL_DIR"
else
  echo "❌ Installation failed."
  exit 1
fi
