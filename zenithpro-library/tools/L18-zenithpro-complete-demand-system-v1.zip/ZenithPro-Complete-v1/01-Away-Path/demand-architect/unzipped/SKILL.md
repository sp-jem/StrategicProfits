---
name: demand-architect
description: "9-step orchestration skill that runs the full demand creation pipeline with Girard's mimetic desire theory woven in at three critical integration points. Synthesizes all 8 demand creation skills (demand-desire-mapper, psychographic-excavation, avatar-excavation, failure-pattern-forensics, core-concept-generator, ideal-buying-mindset, belief-gap-analyzer, usp-generator) with mimetic-market-intelligence into a unified system that simultaneously maps desire architecture AND competitive positioning. Produces three synthesis outputs: Strategic Desire Map, Demand Architecture Brief, and Anti-Mimetic Positioning Statement. Use when building positioning from scratch or when existing positioning is failing to differentiate in a crowded market."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/demand-architect {mode} [market or business]"
  modes: [full, quick, audit]
  called_by: [user]
  outputs_to: [project folder]
dependencies:
  - mimetic-market-intelligence
  - demand-desire-mapper
  - psychographic-excavation
  - avatar-excavation
  - failure-pattern-forensics
  - core-concept-generator
  - ideal-buying-mindset
  - belief-gap-analyzer
  - usp-generator
---

# Demand Architect

The full demand creation pipeline. Synthesizes Girard's mimetic desire theory with the complete 8-skill demand architecture system. Produces positioning that is simultaneously rooted in the deepest psychological architecture of the prospect AND occupies strategically uncontested competitive territory.

---

## LAYER 1: INVARIANTS (Never override. No exceptions.)

These are hard constraints. Violating any one of them makes the entire output invalid, regardless of quality elsewhere.

1. **Steps execute in sequence. No skipping.** In full mode, Steps 1-9 run in order. Step N+1 never begins before Step N is complete and saved to file. The output of Step N is a required input to Step N+1 — you cannot manufacture those outputs. If you skip steps, you are generating a simulation of this process, not running it.

2. **Live web research is required for Step 1.** The competitive desire landscape (Step 1) MUST be produced from live research, not training data. If web research tools are unavailable when Step 1 executes, HALT and notify the user. Do not substitute your knowledge of competitors for actual research.

3. **Step 1 outputs are carried into every downstream step.** The competitive desire landscape produced in Step 1 is not a standalone document — it is the competitive filter through which all downstream analysis is read. Every step that has a GIRARD INTEGRATION point MUST explicitly reference findings from Step 1 by name. Generic references to "competition" are not acceptable.

4. **Every claim about market psychology must be grounded in evidence.** "This market feels anxious" is not acceptable. "This market uses the phrase 'I'm drowning' to describe their situation, as evidenced by [source/quote]" is acceptable. Raw language from the market is required in Steps 2-5.

5. **The Anti-Mimetic Test (Step 6) is a hard gate.** No Core Concept passes to the synthesis outputs unless it has passed the Anti-Mimetic Test. A concept that fails — meaning it mediates the same desire the top 3 competitors mediate, in the same way — is discarded regardless of how compelling it sounds in isolation.

6. **The Competitive Belief Audit (Step 8) classifies every Point A belief.** Every belief identified at Point A must be classified as either (a) naturally held or (b) competitor-installed. This classification changes the bridge-building strategy. Skipping classification — treating all beliefs as equivalent — produces a bridge blueprint that will fail in market.

7. **The Anti-Mimetic Positioning Statement must specify uncontested territory.** The final positioning statement is invalid unless it explicitly names which competitor desires it is NOT mediating and why. "We're different because..." without reference to specific competitor positions is aspirational, not strategic.

8. **Save all step outputs to individual files before proceeding to the next step.** Chat-only delivery is never acceptable for any step. This is an orchestration system producing linked documents — if any step's output exists only in chat, the chain is broken.

9. **All three synthesis outputs are mandatory.** The pipeline is not complete until all three synthesis documents (Strategic Desire Map, Demand Architecture Brief, Anti-Mimetic Positioning Statement) are produced and saved. Delivering only the step outputs without synthesis leaves the work unintegrated.

10. **No synthesis output file may be opened before all 9 step outputs exist on disk.** If any step output file is missing, produce it before proceeding to synthesis. There is no partial synthesis — Synthesis-01, Synthesis-02, and Synthesis-03 require all 9 step outputs as prerequisite. Verify the output folder for all 9 files before starting any synthesis document.

11. **If all 5 Core Concepts fail the Anti-Mimetic Test, HALT and follow the defined failure path.** Do NOT proceed to Step 7 with no passing concept. Execute in order: (1) Document all five failures with specific Anti-Mimetic Test reasoning. (2) Re-run Step 1 with expanded competitor search — the all-fail result may indicate insufficient competitive coverage in Step 1. (3) Attempt one CONDITIONAL PASS reframe on the highest-scoring failed concept — sometimes one modification shifts the framing to uncontested territory. (4) If still no passing concept after two additional attempts, HALT and present the user with: the five failed concepts, the specific reason each failed, and a clear specification of what desire territory is available that a passing concept would need to mediate.

---

## LAYER 2: QUALITY GUIDANCE (Adapt to context — but default to following)

10. **Depth before breadth at every step.** One well-excavated avatar is worth more than three shallow ones. One precisely specified L1 desire is worth more than a list of six vague ones. At each step, resist the urge to produce volume — pursue precision instead.

11. **Competitive findings must be directional, not just descriptive.** Saying "Competitor A focuses on speed" is descriptive. Saying "Competitor A's speed messaging creates a desire-space gap around depth and lasting change — which this market also craves but cannot find mediated" is directional. Every competitive insight must answer: "So what does this mean for positioning?"

12. **Mimetic integration points are connective tissue, not appendices.** The GIRARD INTEGRATION language in each step is not a checkbox. It is where this skill produces its core value — the place where internal desire architecture meets external competitive reality. Treat these sections as equal in importance to the core analysis they modify.

13. **When evidence conflicts, surface the conflict.** If Step 2 desire analysis shows a strong L1 desire for independence, but Step 3 psychographic data shows this market constantly seeks external validation, do not reconcile artificially. Surface the paradox — it is the most important psychological finding.

14. **The pipeline must conclude with a specific recommendation, not a menu of options.** The Demand Architecture Brief (Synthesis Output 2) must recommend ONE primary Core Concept and ONE primary USP, with clear reasoning for the selection. Offering 3 Core Concepts without ranking is incomplete work.

15. **Produce analysis, not descriptions of analysis.** Never write "this section would benefit from examining the competitor landscape." Examine it. If the research shows insufficient data for a finding, state "Insufficient data" with a specific list of what would close the gap.

---

## PURPOSE

### What This Skill Is

The demand-architect orchestrates 9 skills into a unified system. Running the 8 constituent skills individually produces excellent analysis in 8 separate buckets. This skill produces something the individual skills cannot: a single integrated picture where the deepest psychological truths of the prospect are mapped against the competitive desire landscape — simultaneously revealing what to create at the desire level AND what will differentiate in the market.

### The Problem It Solves

Without mimetic integration:
- You build a psychographically perfect USP that occupies territory four competitors already own
- You generate a Core Concept that addresses a genuine failure pattern but uses the same framing as the market leader
- You map a desire hierarchy that shows strong L1 independence desire, while five competitors have already staked that territory with "freedom" and "autonomy" positioning

Without deep psychological architecture:
- You identify open competitive territory that no one occupies — because the desire it serves is actually weak in this market
- You find an uncontested positioning angle that's technically differentiated but doesn't connect to any powerful L1 desire
- You craft anti-mimetic positioning that feels original but doesn't move the prospect emotionally

The demand-architect integrates both dimensions simultaneously. Every psychological finding is filtered through competitive reality. Every competitive finding is filtered through psychological truth.

### What Makes It Different From Running the Skills Individually

| Individual Skills | Demand Architect |
|-------------------|-----------------|
| Produce separate documents | Produces linked, cross-referenced documents |
| Competitive analysis is one input among many | Competitive analysis permeates all 9 steps |
| Synthesized by the user after the fact | Synthesizes into 3 unified strategic documents |
| Generates many options | Recommends specific positioning |
| 8 hours minimum to run manually | Single orchestrated session |
| No mimetic integration | Girard's desire theory woven through 3 critical points |

### Non-Goals (Hard Boundaries)

- Does NOT produce marketing copy, ads, or email sequences — it produces positioning strategy that feeds those
- Does NOT replace professional copywriting — it produces the brief that makes professional copywriting possible
- Does NOT work without live web research for Step 1 — refuse to start Step 1 without web access
- Does NOT compress into fewer steps — the sequence exists because each step's output is a required input for subsequent steps

---

## REFUSAL TRIGGERS

IF asked to skip Step 1 and begin with Step 2:
> "Step 1 produces the competitive desire landscape that Step 2's GIRARD INTEGRATION point requires. Running Step 2 without Step 1 means the desire hierarchy has no competitive filter — which is what running demand-desire-mapper alone already produces. Run Step 1 first."

IF asked to run without web research tools available:
> "Step 1 requires live web research to identify the competitive desire landscape. Without web research, Step 1 would be generated from training data — which violates Invariant 2. The entire pipeline depends on Step 1 being accurate. Do not proceed without web access."

IF asked to skip the Anti-Mimetic Test in Step 6:
> "The Anti-Mimetic Test is Invariant 5 — it is a hard gate that determines whether the Core Concept differentiates in the market or reproduces existing positioning. Skipping it produces a Core Concept that may be psychologically accurate but competitively irrelevant."

IF asked to produce a Core Concept before completing Step 5 (Failure Pattern Forensics):
> "Core Concept generation requires failure archaeology as its primary input — the 'why nothing has worked' excavation is what makes Core Concepts land emotionally. Attempting to generate Core Concepts without Step 5 produces concepts that are intellectually interesting but emotionally inert."

IF asked to produce only the three synthesis outputs without running the steps:
> "The synthesis documents integrate step outputs that don't exist yet. They cannot be produced from brief/thin inputs — they require the depth produced by full execution of all 9 steps. Run the steps."

---

## PIPELINE DEPTH SPECIFICATION

When running demand-architect, constituent skills run at PIPELINE DEPTH — not their standalone maximum. This is defined per step:

| Step | Skill | Required Phases/Parts | Optional (time permitting) |
|------|-------|-----------------------|--------------------------|
| Step 2 | demand-desire-mapper | Phases 1-6 (all) | — |
| Step 3 | psychographic-excavation | Phases 0, 1, 2, 4, 7, 11, 14 + Girard additions | Phases 3, 5, 6, 8-10, 12, 13 |
| Step 4 | avatar-excavation | Sections A-C, G-J, L, M (all required) | Sections D-F (shadow/somatic — add if time allows) |
| Step 5 | failure-pattern-forensics | Parts 1-7 (all, Part 7 is Girard addition) | — |
| Step 6 | core-concept-generator | Preliminary analysis + all 5 formulas + Anti-Mimetic Test | — |
| Step 7 | ideal-buying-mindset | All 4 dimensions | — |
| Step 8 | belief-gap-analyzer | Full protocol + Competitive Belief Audit | — |
| Step 9 | usp-generator | Steps A-E + Competitive Desire Landscape Validation | — |

**Rule:** Do not run MORE than pipeline depth unless the user explicitly requests it and time allows. The pipeline's value is in the integration of 9 steps — depth at one step at the expense of completing the pipeline is the wrong trade.

---

## INPUTS

### Required Before Starting (Any Mode)

1. **Business/product name and URL** — for Step 1 competitor identification and client profile benchmarking
2. **Target market description** — who they are, what business they run, what problem they face (3-5 sentences minimum)
3. **Product/service description** — what is being sold, what it delivers, key deliverables/mechanism, price point
4. **Competitor list OR permission to identify** — list of 8-15 competitors, or authorization to identify through Step 1 research
5. **Output folder path** — where all files will be saved. If not specified, ask before proceeding.

### Optional but Quality-Improving

- Existing customer testimonials or reviews (improves Steps 2-5 evidence quality)
- Psychographic research already conducted (can inform but not replace Step 3)
- List of specific positioning angles already tested (improves Step 6 anti-mimetic analysis)
- Sales call recordings or transcripts (improves Step 5 failure archaeology)

---

## MODES

```
/demand-architect full [market]    # All 9 steps + 3 synthesis outputs (4-6 hours)
/demand-architect quick [market]   # Steps 5-8 only, for when Steps 1-4 research is done (1-2 hours)
/demand-architect audit [market]   # Analyze existing marketing against demand architecture framework
```

### Mode: quick

Prerequisites (must be provided before running):
- Completed competitive desire landscape (from mimetic-market-intelligence or prior Step 1 run)
- Completed desire hierarchy (from demand-desire-mapper or prior Step 2 run)
- Completed psychographic profile (from psychographic-excavation or prior Step 3 run)
- Completed avatar profiles (from avatar-excavation or prior Step 4 run)

Then runs: Steps 5-9 + produces all 3 synthesis outputs.

NEVER run quick mode with thin inputs and claim the synthesis outputs have the depth of a full run. If input quality is insufficient, flag it explicitly.

**Quick Mode Input Acceptance Criteria:**

| Input | Minimum Acceptable | Reject and Flag If |
|-------|-------------------|--------------------|
| Competitive landscape | 8+ competitors with desire mapping, live-sourced | Fewer than 8 competitors, or based on training data alone |
| Desire hierarchy | L1-L4 complete with Strategic Desire Gap analysis and GIRARD classification | Missing L4, or L1 desires not classified as Contested/Underserved/Latent/Suppressed |
| Psychographic profile | Phases 0, 1, 2, 4, 7, 11 present with 20+ market quotes | Fewer than 10 quotes, or missing Phase 11 mimetic conditioning analysis |
| Avatar profiles | 3+ avatars with Section M (Mimetic Model Profile) completed | Fewer than 3 avatars, or any avatar missing Section M |

If any input is below minimum: state exactly which input fails and which specific gap must be filled, then offer to run the missing steps before proceeding. Do NOT fill the gap from training data.

### Mode: audit

Input: Existing marketing materials (sales page, emails, webinar outline, ads — whatever exists)

Analyzes against the demand architecture framework:
- Which L1 desires does this marketing connect to? How strongly?
- Which beliefs does it attempt to shift? In what sequence? Is the sequence logically sound?
- What does the Anti-Mimetic Test reveal? (Compare to Step 1 landscape if available, or run Step 1 fresh)
- What Core Concept is implied? Does it pass the inevitability test?
- What is the current USP? Does it occupy uncontested territory?

Produces: **Demand Architecture Audit** — what is working, what is not, and what to change first (ranked by impact).

---

## EXECUTION PROTOCOL

### PRE-STEP: Gather and Confirm Inputs

Before starting Step 1, confirm:
- [ ] Business name and URL collected
- [ ] Target market description received (3+ sentences)
- [ ] Product description received
- [ ] Competitor list received OR authorization to identify
- [ ] Output folder confirmed

Save a `00-PROJECT-BRIEF.md` to the output folder containing these inputs. This becomes the reference document for all subsequent steps.

---

### STEP 1: Mimetic Phase 1 — External Competitive Landscape

**[GIRARD INTEGRATION POINT 1 — Primary competitive desire mapping]**

**Purpose:** Before mapping what the prospect wants internally, map what the market has already made available. The competitive landscape determines which desires are overcrowded (too many mediators fighting for the same territory) and which are underserved (desires that exist in the market but have no strong mediator).

**Execution:**

Run the competitive desire landscape analysis using the methodology from mimetic-market-intelligence. For each competitor identified:

1. Research using live web search: homepage, sales pages, about page, social media (last 30 days), any webinars or lead magnets currently running
2. Identify the PRIMARY DESIRE MEDIATED — not what they sell, but what identity/state the buyer is being invited to inhabit
3. Identify SECONDARY DESIRES — supporting desires that reinforce the primary
4. Identify THE MODEL PRESENTED — who is the aspirational figure?
5. Map to the 6 Convergence Dimensions:
   - Promise convergence (what everyone promises)
   - Narrative convergence (the story everyone tells)
   - Offer structure convergence (how everyone packages)
   - Proof convergence (what results everyone showcases)
   - Language convergence (specific words/phrases adopted market-wide)
   - Enemy convergence (what everyone positions against)

**PRODUCE: The Competitive Desire Landscape**

This is the Step 1 output that all downstream steps reference. It must contain:

**Section A: Contested Desires**
Desires where 5+ competitors are actively mediating the same territory. These are SATURATED — entering them means fighting for share of an already-crowded desire space.

For each contested desire:
- Name the desire (using Reese's 16 L1 desires framework)
- List the specific competitors mediating it (5+)
- Quote the specific language each uses
- Identify the CONVERGENCE PATTERN — what sameness has emerged
- Note what NONE of them are saying (the gap within the contested zone)

**Section B: Underserved Desires**
Desires that exist in the market (verifiable through comments, reviews, forums, sentiment) but have no strong mediator among the competitors. These are OPEN TERRITORY.

For each underserved desire:
- Name the desire
- Provide evidence it exists in the market — MINIMUM: at least 3 specific quotes from market sources (forums, reviews, comments, social media) expressing this desire
- Run a verification search specifically for competitors mediating this desire — if a strong mediator is found, reclassify as Contested, not Underserved
- Do NOT claim open territory without having run the verification search. An unverified open territory claim that is later found to be contested invalidates the downstream strategy that relied on it.

**Section C: Direction of Mimesis**
Who originated what? Which competitors are imitating whom? Apply Girard's framework: the originator and the imitator face different strategic problems. Record timeline findings.

**Save to:** `Step-01-Competitive-Desire-Landscape.md`

**Quality Gate (pre-save):**
- [ ] Minimum 8 competitors researched with live web sources
- [ ] Every competitor claim backed by a specific quote from current marketing
- [ ] All 6 convergence dimensions covered
- [ ] At least 3 contested desires mapped with 5+ competitor evidence each
- [ ] At least 2 underserved desires identified with market evidence
- [ ] Direction of mimesis investigated with timeline data

---

### STEP 2: Demand Desire Mapping — Internal Desire Architecture

**Purpose:** Map the complete desire hierarchy that drives purchase decisions. Synthesizes Reese's 16 Basic Desires, Schwartz's channeling insight, and the D3 belief-architecture methodology to produce the full L1-L4 map.

**GIRARD INTEGRATION — Cross-Reference with Step 1:**
After mapping the L1-L4 desire hierarchy, perform the Strategic Desire Gap Analysis:
- Cross-reference EACH L1 desire identified against the Step 1 competitive landscape
- For each L1 desire active in the prospect, check: Is this desire CONTESTED (5+ mediators) or UNDERSERVED (open territory)?
- Identify L1 desires that are BOTH: (a) active and strong in the prospect AND (b) underserved by competitors — these are STRATEGIC DESIRE GAPS
- A Strategic Desire Gap = a desire with demand-side pull AND supply-side vacuum

Mark each L1 desire in the hierarchy output as one of:
- **CONTESTED** — strong in market, many mediators
- **UNDERSERVED** — active in prospect, few/no strong mediators
- **LATENT** — exists but not strongly activated in this prospect segment
- **SUPPRESSED** — actively present but socially hidden

**Execution:**

Run the full demand-desire-mapper protocol:
- Phase 1: L1 Desire Identification (primary, secondary, suppressed desires — with market evidence)
- Phase 2: L2 Category Belief Mapping (what category of solution do they believe can satisfy it?)
- Phase 3: L3 Product Belief Mapping (what specific product beliefs are required for purchase?)
- Phase 4: L4 Self-Efficacy Belief Mapping (what must they believe about their own ability to succeed?)
- Phase 5: Channel Maps (visual L1 → L2 → L3 → L4 → Demand)
- Phase 6: Gap Analysis (where is the channel broken?)

Then add the GIRARD INTEGRATION section before saving.

**Save to:** `Step-02-Desire-Hierarchy-Map.md`

**Quality Gate (pre-save):**
- [ ] Minimum 2 primary L1 desires identified with market evidence
- [ ] Suppressed desires excavated (not just surface-level desires)
- [ ] Complete channel map from L1 through L4 to demand
- [ ] GIRARD INTEGRATION section present — every L1 desire classified as Contested/Underserved/Latent/Suppressed
- [ ] Strategic Desire Gaps explicitly identified and labeled

---

### STEP 3: Psychographic Excavation — Deep Market Psychology

**Purpose:** Psychological archaeology of the target market. Goes beyond demographics to extract what the market believes in their bones, what they'd never admit publicly, their rage points, failed solution history, and the exact language they use.

**GIRARD INTEGRATION — Mimetic Conditioning Audit:**
Standard psychographic excavation identifies how the market thinks. The mimetic layer identifies HOW competitors have shaped that thinking. Add the following after the standard 14 phases:

**Phase 0 Addition (run BEFORE Phase 1):** Mimetic Conditioning Inventory
- What competitor messaging has this market been SATURATED with? (Use Step 1 language convergence findings)
- What promises have they been trained to distrust because competitors overclaimed and underdelivered?
- What words and phrases now trigger skepticism because they've been worn out by competitor use?
- What aspirational identity offers have they heard so many times they've become cynical about them?

This inventory identifies the "mimetic residue" — the psychological sediment left by years of competitor marketing. It's the starting point of the Competitive Belief Audit in Step 8.

**Phase 11 Enhancement (Competitive Intelligence):**
Standard Phase 11 covers what the market knows about competitors. With mimetic integration, also excavate:
- Which competitor's MODEL (aspirational identity) has this market segment been most influenced by?
- Who did they buy from before? What did that purchase promise them? Did it deliver?
- What has competitor marketing trained them to expect from ANY solution in this category?
- What mimetic desire did their previous purchases mediate — and did that desire get satisfied?

**Execution:**

Run the full psychographic-excavation 14-phase protocol. Minimum research requirements:
- Raw market language: Reddit, YouTube comments, reviews, forums, social media (must include actual quotes, not paraphrases)
- Phase 2 (Solution Graveyard) requires 10-20 specific interventions the market has tried
- Phase 7 (Rage Points) requires actual quotes expressing frustration, not generalized descriptions
- Phase 11 (Competitive Intelligence) enhanced with mimetic conditioning analysis as above

**Save to:** `Step-03-Psychographic-Profile.md`

**Quality Gate (pre-save):**
- [ ] Minimum 20 raw market quotes included across all phases
- [ ] Phase 0 Mimetic Conditioning Inventory completed (4 questions answered with evidence)
- [ ] Phase 2 Solution Graveyard covers 10+ specific failed interventions
- [ ] Phase 7 Rage Points expressed in the market's actual language
- [ ] Phase 11 includes mimetic conditioning analysis
- [ ] Uncomfortable truths present — if findings are what everyone already knows, go deeper

---

### STEP 4: Avatar Excavation — Segment Construction with Mimetic Model Identification

**Purpose:** Multi-dimensional forensic psychological reconstruction of 3-5 distinct avatar segments. Goes beyond standard persona work to excavate unconscious drivers, shadow psychology, decision neuroscience, and somatic fear signatures for each segment.

**GIRARD INTEGRATION — Mimetic Model Identification:**
For each avatar segment, add Section M: The Mimetic Model Profile

The mimetic model is the person, brand, or figure this avatar is most trying to become — or most desires to emulate. Girard: desire is always mediated by a model. Identifying the model reveals what the avatar actually wants beneath their stated goals.

For each avatar:
- **Who is their aspirational model?** (Name specific people, brands, or archetypes)
- **Which competitor's positioning do they find most compelling, and why?** (Reference Step 1 findings)
- **What does that competitor's model offer them psychologically?** (The specific identity being mediated)
- **Which competitor's model have they already tried to become?** (Previous purchases, programs, coaching)
- **What did pursuing that model cost them?** (Time, money, identity investment — the mimetic wound)
- **What does this reveal about what they ACTUALLY want vs. what they're asking for?**

This analysis reveals the gap between stated wants and actual wants — which is often where the most powerful positioning lives.

**Execution:**

Run the full avatar-excavation protocol for 3-5 segments. Each segment must receive equal depth. Key sections:
- Section A: Demographic and situational context
- Section B: Identity archaeology and core beliefs
- Section C: The solution graveyard and current reality
- Section D-K: Standard avatar dimensions (desire architecture, shadow psychology, somatic signatures, temporal patterns, relational damage, decision neuroscience, purchase triggers, objection archaeology)
- Section L: Day-in-the-life narrative
- Section M: Mimetic Model Profile (GIRARD INTEGRATION — required for each avatar)

**Save to:** `Step-04-Avatar-Profiles.md`

**Quality Gate (pre-save):**
- [ ] 3-5 avatar segments produced with equal depth
- [ ] Each avatar includes shadow psychology (not just surface persona)
- [ ] Section M (Mimetic Model Profile) completed for every avatar
- [ ] Each avatar's mimetic model explicitly connected to Step 1 competitor profiles
- [ ] No avatar is simply a demographic description — each contains genuine psychological complexity

---

### STEP 5: Failure Pattern Forensics — Root Cause Analysis with Competitor Causation

**Purpose:** Forensic excavation of why this market perpetually fails despite deploying multiple solutions. Produces the raw material for the Core Concept — the hidden pattern that explains every failure.

**GIRARD INTEGRATION — The Mimetic Trap (Part 7):**
Standard failure forensics identifies failure patterns. The mimetic layer identifies which of those patterns were created or reinforced by competitor marketing that mediated the wrong desire or pointed the market toward a false model.

After completing the standard six-part forensic excavation, add:

**Part 7: The Mimetic Trap Analysis**

For each major failure pattern identified (Parts 1-6), classify it as one of:
- **ENDOGENOUS** — the failure pattern exists independent of competitor influence; it would occur regardless of marketing (e.g., lack of sustained execution, resource constraints, skill gaps)
- **COMPETITOR-INSTALLED** — the failure pattern was created or amplified by competitor marketing. The market pursued a desire that competitor X mediated, was pointed toward a model that didn't match their situation, invested in a solution that resolved a surface symptom rather than the root cause — because competitor marketing told them that symptom was the problem.

For each competitor-installed failure pattern:
- Name the specific competitor (or category of competitors) whose positioning installed it
- Identify the promise they made
- Identify the desire they appeared to mediate
- Identify what actually happened when the market bought in
- Identify the lasting belief damage from that failed attempt (the belief that is now broken and must be healed before this market will buy again)

**Why This Matters for Positioning:**
Competitor-installed failure patterns require a different intervention than endogenous ones. To address a competitor-installed failure pattern, you must first acknowledge that the failure was not the prospect's fault — it was the result of being pointed toward the wrong model. Only after that acknowledgment can you present a different model. Skipping the acknowledgment and jumping to "here's the real solution" means asking a burned prospect to trust again without addressing WHY they got burned.

**Execution:**

Run the full failure-pattern-forensics 6-part protocol:
- Part 1: Graveyard Archaeological Inventory (10-20 specific failed interventions)
- Part 2: The Pattern Recognition Excavation (the hidden pattern behind all failures)
- Part 3: The False Belief System (beliefs held as truth that perpetuate failure)
- Part 4: The Transcendent Minority (who succeeds and why — the anomaly analysis)
- Part 5: The Operational Level Gap (the gap between where they work and where the leverage is)
- Part 6: The False Enemy Diagnosis (what they're fighting vs. what's actually causing the problem)
- Part 7: The Mimetic Trap Analysis (GIRARD INTEGRATION — required)

**Save to:** `Step-05-Failure-Pattern-Forensics.md`

**Quality Gate (pre-save):**
- [ ] 10+ specific failed interventions catalogued in Part 1
- [ ] Pattern identified in Part 2 accounts for ALL failures, not just some
- [ ] False enemy in Part 6 names both the false enemy AND the real enemy precisely
- [ ] Part 7 Mimetic Trap Analysis classifies every major failure pattern as Endogenous or Competitor-Installed
- [ ] Every Competitor-Installed pattern traces to specific competitor messaging
- [ ] Belief damage from competitor-installed failures explicitly documented

---

### STEP 6: Core Concept Generation — The Paradigm Shift with Anti-Mimetic Filter

**[GIRARD INTEGRATION POINT 2 — Anti-Mimetic quality gate for all Core Concepts]**

**Purpose:** Generate 5 Core Concepts using the five generation formulas. Then apply the Anti-Mimetic Test as a mandatory quality gate. Only concepts that pass the test are included in the final output.

**Execution:**

Run the standard core-concept-generator preliminary analysis and all five formula phases:

**Preliminary Analysis (before generation):**
- The Daily Bleed (quantified consequence of inaction)
- The Identity Wound (psychological paradox)
- The Category Context (market sophistication level per Schwartz)
- The Inevitability Standard (what must be true for purchase to be automatic)

**Five Generation Formulas:**
1. **Invisible Pivot Point** — The hidden factor that makes everything else irrelevant
2. **False Enemy** — What they're fighting vs. what's actually causing their results
3. **Expertise Trap** — How their existing knowledge/skills are working against them
4. **Systemic Mismatch** — Why the standard approach is structurally incapable of producing the result
5. **Success Paradox** — Why the very thing that makes them successful is preventing the next level

For each formula, apply all four standard quality tests:
- Inevitability Test ("If they accept this, is buying the logical next step?")
- Specificity Test (real numbers, real stakes — not vague)
- Recognition Test ("They'll feel immediately: THAT'S why I haven't been able to...")
- Irreversibility Test (once understood, cannot be un-understood)

**GIRARD INTEGRATION — The Anti-Mimetic Test (5th quality test, mandatory):**

For every Core Concept that passes the four standard tests, run:

**Test A: Desire Differentiation Check**
Reference the Step 1 Competitive Desire Landscape.
- What is the PRIMARY DESIRE this Core Concept mediates?
- Is this desire CONTESTED in Step 1 (5+ competitors actively mediating it)?
- If CONTESTED: Does this concept mediate that desire in a meaningfully DIFFERENT WAY than the top 3 competitors? (Different mechanism, different obstacle framed, different protagonist in the story)
- If the concept mediates a contested desire in the same way as existing competitors → FAIL

**Test B: Open Territory Check**
- Does this concept mediate a desire that Step 1 identified as UNDERSERVED?
- If UNDERSERVED: Automatic pass on desire differentiation. Proceed to specificity check.

**Test C: Framing Differentiation Check**
Even if the concept addresses a contested desire, does it reframe the problem in a way NO competitor is using?
- Compare the specific framing of the concept against Step 1 language convergence findings
- If the framing uses phrases, analogies, or structures from the language convergence dimension → likely fail
- New framing of existing territory = possible pass. Same framing of existing territory = fail.

**Scoring:**
- **PASS**: Mediates underserved desire, OR mediates contested desire in a genuinely different way (confirmed against Step 1 evidence)
- **CONDITIONAL PASS**: Mediates contested desire with different framing — note risk (competitors could adopt same framing)
- **FAIL**: Mediates contested desire in same way as 3+ competitors — discard regardless of intrinsic quality

**On passing concepts, annotate:**
- What desire does it mediate?
- What is the competitive differentiation (specific comparison to Step 1 findings)?
- Risk level if competitor could adopt same positioning

**On failing concepts:**
- Note the failure reason
- Attempt to reframe before discarding — sometimes one modification shifts a failing concept to passing

**Rank surviving concepts** by: (1) Inevitability test strength, (2) Anti-Mimetic differentiation level, (3) Match to Strategic Desire Gaps identified in Step 2

**Save to:** `Step-06-Core-Concepts.md`

**Quality Gate (pre-save):**
- [ ] All five formulas attempted
- [ ] Every concept passed through all four standard quality tests
- [ ] Every concept that passed standard tests was also put through the Anti-Mimetic Test
- [ ] Anti-Mimetic Test results documented for every concept (Pass/Conditional Pass/Fail + reasoning)
- [ ] At least 1 concept received a Pass or Conditional Pass
- [ ] Concepts ranked with anti-mimetic differentiation as a ranking factor
- [ ] Failed concepts documented with failure reason (not just discarded silently)

---

### STEP 7: Ideal Buying Mindset — Point B Definition

**Purpose:** Forensically define the exact mental and emotional state prospects must reach for buying to become automatic. Maps 4 dimensions: Logical Beliefs, Emotional Feelings, Contextual Perceptions, and Identity Alignment.

**Execution:**

Run the full ideal-buying-mindset protocol for the primary avatar (or top 2 avatars if they diverge significantly):

**Dimension 1: Logical Beliefs (The Rational Mind)**
What must they believe factually/logically about:
- The problem (root cause, not symptom)
- The category of solution (does this type of thing work?)
- This specific solution (does this specific thing work for people like me?)
- The investment (is this the right value exchange?)
- The timing (is now the right moment?)

**Dimension 2: Emotional Feelings (The Limbic System)**
What must they feel:
- About their current situation (urgency but not hopelessness)
- About the possibility of change (genuine belief it's achievable)
- About this specific solution (trust, excitement, safety)
- About themselves (competence, readiness, worthiness)
- About the provider (credibility, alignment, respect)

**Dimension 3: Contextual Perceptions (The Worldview Layer)**
What must they believe about:
- The timing relative to external forces (market window, competitive pressure, life stage)
- The alternative cost (what happens if they don't act)
- Their current trajectory (where does staying on this path lead?)
- The broader landscape (the world has changed in ways that make this the right moment)

**Dimension 4: Identity Alignment (The Self-Concept)**
What must they believe about who they are:
- "I am someone who makes investments like this"
- "I am someone who can execute this"
- "I am someone who deserves this result"
- "This purchase is consistent with how I see myself"

Produce the complete Point B specification: the state where ALL four dimensions are aligned, purchase is the automatic next step, and selling becomes superfluous.

**Save to:** `Step-07-Ideal-Buying-Mindset.md`

**Quality Gate (pre-save):**
- [ ] All four dimensions mapped in full
- [ ] Point B is specific to this avatar — not generic buying psychology
- [ ] Point B is purchaser-realistic (grounded in what actual buyers have reported)
- [ ] Identity dimension addressed (the most frequently skipped)
- [ ] "Would someone at Point B buy?" test applied — if no, revise before saving

---

### STEP 8: Belief Gap Analysis — Bridge Blueprint with Competitive Belief Audit

**[GIRARD INTEGRATION POINT 3 — Competitor-installed belief identification]**

**Purpose:** Map the exact distance between Point A (current prospect beliefs from Steps 2-5) and Point B (from Step 7). Identify every belief gap, map their dependency chain, specify evidence types needed, and produce an optimally sequenced bridge-building plan.

**Execution:**

Compile Point A beliefs from previous steps:
- Identity beliefs (Step 4 Avatar Profiles — Section B)
- Causal beliefs (Step 5 Failure Pattern Forensics — Part 3)
- Solution beliefs (Step 3 Psychographic Profile — Phase 2 Solution Graveyard)
- Change beliefs (Step 4 — objection archaeology, Step 5 — false beliefs)
- Category beliefs (Step 3 — Phase 11, Phase 14 competitor relationship)

Run the standard belief-gap-analyzer protocol:
- Map all belief gaps (Point A → Point B for each belief dimension)
- Identify dependency chains (which beliefs must be established before others become possible)
- Specify evidence types needed for each gap (logical, emotional, social proof, authority, demonstration)
- Produce sequenced bridge-building plan (ordered by dependency, not by what's easiest to address)
- Identify the Master Bridge (the Core Concept — the belief that shortens or eliminates multiple other bridges)

**GIRARD INTEGRATION — Competitive Belief Audit:**

For every Point A belief identified, classify it as:

**NATURALLY HELD** — This belief would exist in the prospect regardless of competitor marketing. It arises from:
- Personal experience with the problem
- Observation of others with the same problem
- General life experience and cognitive patterns
- Industry-wide conditions that affect everyone

**COMPETITOR-INSTALLED** — This belief was created or reinforced by competitor marketing. Evidence of competitor installation includes:
- The belief uses specific language that traces to a competitor's messaging
- The belief emerged after a particular category of competitor became dominant
- The belief refers to a specific promise or mechanism a competitor marketed
- The belief represents the residue of a purchase that didn't deliver as promised

For each Competitor-Installed belief:
1. Identify the likely source competitor or category of competitors
2. Identify the original promise they made that installed this belief
3. Identify the failure experience that calcified it
4. Specify a modified bridge strategy: **Surface the installation BEFORE attempting to replace the belief**

**Modified Bridge Strategy for Competitor-Installed Beliefs:**

Standard belief bridging: Present evidence that challenges the belief → prospect updates belief.

Competitor-installed belief bridging:
1. Acknowledge that the belief is understandable given what they've experienced
2. Name the competitor promise that created it (without naming the competitor if legally sensitive)
3. Explain WHY that specific solution produced that specific disappointing result (mechanism-level, not dismissive)
4. ONLY THEN present the alternative framing

Skipping steps 1-3 asks a burned prospect to simply trust again — which their self-protective psychology will reject regardless of how strong your evidence is.

**Save to:** `Step-08-Belief-Gap-Blueprint.md`

**Quality Gate (pre-save):**
- [ ] Every Point A belief classified as Naturally Held or Competitor-Installed
- [ ] Every Competitor-Installed belief traced to a specific source (competitor or category)
- [ ] Modified bridge strategy specified for every Competitor-Installed belief
- [ ] Dependency chain for all belief gaps is logically sound
- [ ] Evidence types specified for each gap (not generic — specific to belief type and gap magnitude)
- [ ] Sequencing respects dependency (foundational beliefs before downstream beliefs)
- [ ] Master Bridge identified (the Core Concept's position in the sequence)

---

### STEP 9: USP Generation — Breakthrough Positioning with Desire Landscape Validation

**Purpose:** Transmute product features into breakthrough market positioning through the 5-step Feature → Benefit → Promise metamorphosis. Produce ranked USP candidates. Validate all candidates against the competitive desire landscape from Step 1.

**Execution:**

Run the full usp-generator 5-step protocol:

**Step A: Feature Excavation and Expansion**
Enumerate every product feature with forensic precision (target 20-30 features across physical, process, experiential, relational, outcome categories).

**Step B: Three-Level Transmutation**
For each significant feature cluster, transmute through:
- Feature (what it IS)
- Benefit (what it ENABLES)
- Promise (what it DELIVERS — the transformation)

**Step C: Market Sophistication Calibration**
Identify Schwartz sophistication level (1-5) and select the appropriate USP approach:
- Level 1-2: Bold new claim ("This is different from anything you've tried")
- Level 3: Mechanism claim ("Here's specifically WHY this works when others haven't")
- Level 4-5: Identification/crusade claim ("This is for a specific type of person with a specific worldview")

**Step D: Owability Analysis**
For each candidate promise/USP:
- Could a competitor say this tomorrow? (If yes: not ownable)
- Is there structural evidence ONLY we can deliver this? (Mechanism, credentials, access, track record)

**Step E: L1 Desire Connection**
For each USP candidate, explicitly connect to the primary L1 desire it addresses (from Step 2 hierarchy). A USP disconnected from L1 desire lacks emotional power regardless of logical precision.

**GIRARD INTEGRATION — Competitive Desire Landscape Validation:**

For every USP candidate that passes Steps A-E, validate against Step 1:

**Validation 1: Desire Territory Check**
- Which desire does this USP mediate?
- Is that desire Contested or Underserved in Step 1?
- CONTESTED desires: Does this USP mediate it differently than the top 3 competitors? How specifically?
- UNDERSERVED desires: Does this USP clearly claim this territory? Is it explicit enough that a prospect would instantly place it in the open space?

**Validation 2: Language Convergence Check**
- Compare USP language against Step 1 Language Convergence dimension
- Any USP that uses phrases from the language convergence map is DISQUALIFIED — it sounds like everyone else even if the underlying promise differs
- Propose alternative language if the underlying promise is strong but the expression is convergent

**Validation 3: Enemy Convergence Check**
- Does this USP implicitly or explicitly position against the same enemy that 5+ competitors use?
- Same enemy = same tribe = mimetic convergence
- Consider whether repositioning against a DIFFERENT enemy would differentiate more powerfully

**Final Ranking:**
Rank all surviving USP candidates by:
1. Anti-Mimetic differentiation (does it own uncontested territory or powerfully reframe contested territory?)
2. L1 desire alignment strength (does it connect to a primary desire with real psychological force?)
3. Owability (structural evidence that this promise can only be authentically made by this business)
4. Specificity (is it precise enough that a prospect knows exactly what they're getting?)

**Save to:** `Step-09-USP-Candidates.md`

**Quality Gate (pre-save):**
- [ ] 20+ features enumerated
- [ ] Three-level transmutation completed for all major feature clusters
- [ ] Market sophistication level determined and approach selected accordingly
- [ ] Owability analysis completed for every USP candidate
- [ ] Every candidate connected to a specific L1 desire
- [ ] Competitive Desire Landscape Validation applied to every candidate
- [ ] Language convergence check completed — no USP uses Step 1 language convergence phrases
- [ ] Final ranking includes anti-mimetic differentiation as primary criterion

---

## SYNTHESIS OUTPUTS

After completing all 9 steps, produce three synthesis documents. These integrate the step-level findings into unified strategic deliverables.

### Synthesis Output 1: The Strategic Desire Map

**Purpose:** The single visual/analytical document that shows which desires are contested vs. open, mapped against the L1-L4 hierarchy. The definitive picture of the desire landscape.

**Required Sections:**

**Section 1: The Desire Landscape Table**

| Desire (Reese L1) | Intensity in Market | Competitive Status | Primary Mediators | Strategic Implication |
|-------------------|--------------------|--------------------|-------------------|-----------------------|
| [Desire name] | High/Med/Low | Contested/Underserved/Open | [Top competitors] | [Action recommendation] |

Cover all L1 desires active in this market (minimum 5). Use Step 1 and Step 2 findings.

**Section 2: Strategic Desire Gap Analysis**
List each Strategic Desire Gap identified in Step 2 GIRARD INTEGRATION:
- The desire
- Evidence it's active in the market (Step 2-3 quotes)
- Evidence it's underserved by competitors (Step 1 findings)
- Strategic recommendation: which product feature/mechanism most authentically mediates this gap

**Section 3: The Mimetic Convergence Pattern**
What has this market converged toward? What does everyone in this market sound/look/promise like? Name the convergence clearly — this is the dominant narrative the positioning must escape.

**Section 4: The Open Territory Map**
What is genuinely available? Specific description of uncontested positioning territory — what a brand could claim that no current competitor authentically owns.

**Save to:** `Synthesis-01-Strategic-Desire-Map.md`

---

### Synthesis Output 2: The Demand Architecture Brief

**Purpose:** The complete positioning brief — the single document that tells a copywriter, strategist, or team everything they need to produce effective marketing. Integrates Core Concept, USP, belief sequence, and target psychology.

**Required Sections:**

**Section 1: Primary Avatar Profile (500 words)**
The single most important avatar segment — their situation, psychology, desires, failures, and the exact state they're in when they encounter this marketing. Written as a narrative, not a bullet list.

**Section 2: The Primary L1 Desire (one paragraph)**
The single most powerful desire driving purchase. Not a list. The ONE that, if properly mediated, makes everything else work. Why this one is primary (evidence from Steps 2-3).

**Section 3: Selected Core Concept (one sentence + rationale)**
The winning Core Concept from Step 6. The one that:
- Passed all four standard quality tests
- Passed the Anti-Mimetic Test
- Ranked highest overall
ONE concept. Not a shortlist. If presenting alternatives, rank them and make the recommendation explicit.

**Section 4: The Belief Sequence (ordered list)**
The exact order in which beliefs must be shifted, from Point A to Point B. Numbered, sequenced by dependency. Each belief includes:
- What they currently believe (Point A)
- What they need to believe (Point B)
- Classification: Naturally Held or Competitor-Installed
- Evidence type required to shift it

**Section 5: Primary USP (one statement + rationale)**
The winning USP from Step 9. One candidate. State it as a positioning sentence and explain why it owns uncontested territory (or powerfully reframes contested territory).

**Section 6: Point B Summary**
The complete buying mindset state — what the prospect believes, feels, and perceives when they are ready to buy. Distilled from Step 7 into 200 words maximum. Concrete enough that a copywriter can test their work against it.

**Section 7: Execution Implications**
Three to five specific implications for marketing execution:
- What to lead with (which Core Concept element to open)
- What to address first (the highest-priority competitor-installed belief)
- What language to avoid (Step 1 language convergence — phrases that will make this sound like everyone else)
- What evidence to deploy first (matching evidence type to the highest-priority belief gap)
- What NOT to promise (desires that are so contested that staking this territory will be credibility-draining)

**Save to:** `Synthesis-02-Demand-Architecture-Brief.md`

---

### Synthesis Output 3: The Anti-Mimetic Positioning Statement

**Purpose:** A one-page strategic positioning document that specifies WHAT desire to mediate, WHAT competitor desires to explicitly avoid mediating, and WHAT beliefs to shift first. The strategic north star for all marketing.

**Required Sections:**

**Section 1: Our Positioning Anchor**
In 2-3 sentences: What desire do we mediate? What identity do we offer the buyer? What model do we hold up?

This must be stated in terms of DESIRE (Reese language), not features or benefits. "We mediate the desire for [X] by offering buyers the identity of [Y] through the model of [Z]."

**Section 2: What We Are NOT Mediating (Explicit Avoidance List)**
Name 3-5 desires that competitors are actively mediating that we will NOT attempt to compete for. For each:
- Name the desire
- Name the top 2-3 competitors who own it
- State specifically why we are not competing for this territory (competitive density, authenticity gaps, or strategic choice)

This section is as important as the anchor. Positioning is as much about what you don't claim as what you do.

**Section 3: The Belief Sequence We Must Address First**
The top 3 beliefs to shift before the market will accept our positioning anchor:
- For each: Current belief (Point A), Target belief (Point B), Classification (Natural/Competitor-Installed), Why this must come first
- These are the beliefs that, if not addressed, will cause the prospect to reject the positioning anchor regardless of its quality

**Section 4: The Mimetic Trap We Are Escaping**
Name the specific mimetic convergence pattern this positioning deliberately breaks:
- What is the dominant desire that everyone in this market mediates?
- What is the dominant narrative convergence?
- What specific things will we NEVER say (language convergence avoidance list)?
- What will our positioning feel like to a prospect who has seen everything in this market? (The expected vs. the actual)

**Section 5: The Competitive Differentiation Statement**
One sentence: "While [category/competitors] mediate [desire X], we mediate [desire Y/X reframed], making us the only choice for prospects who [specific situation or worldview]."

This is the internal strategy sentence — not ad copy. It should be so clear that a new team member, reading it alone, could evaluate whether any piece of marketing is on-strategy.

**Save to:** `Synthesis-03-Anti-Mimetic-Positioning-Statement.md`

---

## MODE: AUDIT EXECUTION PROTOCOL

When running `/demand-architect audit [market]`:

**Step 1: Collect Existing Marketing Materials**
Request all available: sales pages, landing pages, email sequences, webinar outlines, ad creative, social media profile/bio, one-liner/tagline. Analyze what is available — do not request materials that don't exist.

**Step 2: Run Step 1 (Competitive Desire Landscape)**
Required even in audit mode — without the competitive map, you cannot assess whether the existing positioning is anti-mimetic or convergent.

**Step 3: Apply Demand Architecture Framework to Existing Materials**

For each major marketing element, assess:

| Element | Current State | Framework Assessment | Gap/Issue | Priority Fix |
|---------|--------------|---------------------|-----------|-------------|
| Primary USP | [Quote from materials] | [Which L1 desire? Contested or Underserved?] | [Specific gap] | [Specific fix] |
| Core Concept | [Quote or absence] | [Passes inevitability test? Anti-Mimetic test?] | [Failure mode] | [Fix] |
| Belief sequence | [Implied from structure] | [Logical? Respects dependency?] | [Where sequence breaks] | [Fix] |
| Language | [Key phrases used] | [On Step 1 convergence list?] | [Phrases to retire] | [Alternatives] |
| Point B | [What buying state is implied] | [Complete? All 4 dimensions?] | [Missing dimensions] | [Fix] |

**Step 4: Produce Audit Report**

Required sections:
1. Current positioning summary (what it is, what desire it mediates, what territory it occupies)
2. Anti-Mimetic Test result (does it differentiate or does it converge?)
3. Belief sequence analysis (what the existing marketing assumes vs. what the market actually needs)
4. Top 3 highest-impact improvements (ranked by expected impact, not difficulty)
5. Language retirement list (phrases to eliminate because they sound like competitors)
6. Recommended next steps (specific, sequenced)

**Save to:** `Demand-Architecture-Audit-[BusinessName]-[Date].md`

---

## QUALITY GATE CHECKLIST

Before declaring the demand-architect run complete, verify ALL of the following.

### Step Completion
- [ ] All 9 steps completed and saved to individual files
- [ ] No step skipped or compressed
- [ ] Each step's GIRARD INTEGRATION section present and substantive

### Girard Integration Verification
- [ ] Step 1: Competitive desire landscape produced with live research (not training data)
- [ ] Step 2: Every L1 desire classified as Contested/Underserved/Latent/Suppressed using Step 1 data
- [ ] Step 2: Strategic Desire Gaps explicitly named
- [ ] Step 3: Mimetic Conditioning Inventory completed with evidence
- [ ] Step 4: Every avatar has Section M (Mimetic Model Profile)
- [ ] Step 5: Every failure pattern classified as Endogenous or Competitor-Installed
- [ ] Step 6: Anti-Mimetic Test applied to every concept that passed standard quality tests
- [ ] Step 8: Every Point A belief classified as Naturally Held or Competitor-Installed
- [ ] Step 9: Every USP candidate validated against Step 1 desire landscape

### Synthesis Completion
- [ ] Synthesis 1 (Strategic Desire Map) produced and saved
- [ ] Synthesis 2 (Demand Architecture Brief) produced and saved — includes ONE selected Core Concept and ONE selected USP
- [ ] Synthesis 3 (Anti-Mimetic Positioning Statement) produced and saved — includes explicit avoidance list

### Evidence Standards
- [ ] Step 1: Every competitor claim backed by a specific quote from current marketing
- [ ] Steps 2-5: Market psychology claims backed by real market language (not paraphrases)
- [ ] No aspirational positioning presented as strategic fact
- [ ] Open territory claims verified — not assumed

### Anti-Patterns Avoided
- [ ] No step delivered as chat only — all outputs are saved files
- [ ] No synthesis documents produced before all step outputs existed
- [ ] No "sounds good in isolation" Core Concepts that fail the Anti-Mimetic Test
- [ ] No convergent USP language (language that mirrors the Step 1 convergence map)
- [ ] Competitor-installed beliefs addressed with modified bridge strategy, not standard bridging

---

## CONTEXT WINDOW MANAGEMENT

This pipeline requires sustained context across 9 steps. Manage actively:

1. **Save step outputs to file immediately** upon completion. Never hold 3+ completed step outputs in active context.
2. **Carry forward only summaries** between steps. After saving Step 2, the Step 2 summary (key findings — 200-300 words) carries forward; the full document does not.
3. **The Step 1 landscape is the exception** — key findings from Step 1 (contested desires, underserved desires, language convergence list) must remain accessible throughout. Save a `Step-01-SUMMARY.md` that is short enough to include in context at any point.
4. **At 70% context capacity:** Save an in-progress handoff document immediately. Do not continue.
5. **Handoff format:**
   - Steps completed (with file paths)
   - Steps remaining
   - Key findings that must carry forward
   - Next action (first thing to do in the next session)
   - Any in-progress analysis that needs to be completed

---

## OUTPUT FILE STRUCTURE

```
[output-folder]/
  00-PROJECT-BRIEF.md                             (inputs gathered before Step 1)
  Step-01-Competitive-Desire-Landscape.md
  Step-01-SUMMARY.md                              (short version for carrying forward)
  Step-02-Desire-Hierarchy-Map.md
  Step-03-Psychographic-Profile.md
  Step-04-Avatar-Profiles.md
  Step-05-Failure-Pattern-Forensics.md
  Step-06-Core-Concepts.md
  Step-07-Ideal-Buying-Mindset.md
  Step-08-Belief-Gap-Blueprint.md
  Step-09-USP-Candidates.md
  Synthesis-01-Strategic-Desire-Map.md
  Synthesis-02-Demand-Architecture-Brief.md
  Synthesis-03-Anti-Mimetic-Positioning-Statement.md
```

For audit mode:
```
[output-folder]/
  Step-01-Competitive-Desire-Landscape.md
  Demand-Architecture-Audit-[Business]-[Date].md
```

---

## VOICE AND TONE

All documents use forensic analyst voice. Not consultant. Not strategist. Not thought leader.

**ALWAYS:**
- Specific evidence first — quotes, data, named sources
- Direct declarative sentences: "This market mediates X" not "it appears this market may tend toward X"
- Comparison tables for side-by-side analysis
- Name the competitors, name the desires, name the beliefs
- Every sentence earns its place

**NEVER:**
- Consultant-speak: "we recommend exploring the possibility of..."
- Vague intensifiers: "very significant," "deeply powerful," "truly unique"
- Filler transitions: "It is worth noting that...", "Interestingly,...", "As we can see..."
- Framework jargon that sounds impressive but means nothing in execution
- Soft conclusions: "This suggests that possibly..." — if you found it, say it
- Marketing language about the methodology itself: describe what was FOUND, not how sophisticated the process was

---

## GIRARDIAN CONCEPTS QUICK REFERENCE

| Concept | Definition | Application in This Skill |
|---------|-----------|--------------------------|
| **Mimetic Desire** | People want what they see others wanting; desire is mediated by a MODEL | Step 1 maps what desires competitors mediate; Steps 2-9 tested against this map |
| **External vs. Internal Mediation** | Distant models create admiration; peer/close models create actionable desire | Step 4 Section M: which competitor's model has the avatar been trying to emulate? |
| **Mimetic Convergence** | Competitors unconsciously imitate each other until indistinguishable | Step 1: 6 convergence dimensions; Step 9: language convergence avoidance |
| **Contested vs. Uncontested Desires** | Blue ocean strategy at the DESIRE level | Step 2 classification; Synthesis 1 Strategic Desire Map |
| **The Skandalon** | Model is simultaneously source of desire AND obstacle to fulfillment | Step 4 mimetic wound analysis: cost of pursuing the previous model |
| **Direction of Mimesis** | Originator vs. imitator face different problems | Step 1 Section C: who originated what |
| **Competitor-Installed Beliefs** | Beliefs created by competitor marketing that burned the market | Step 5 Part 7 Mimetic Trap; Step 8 Competitive Belief Audit |
