---
name: zp-mimetic
description: "Unified ZenithPro mimetic market intelligence. Applies Girard's mimetic desire theory to competitive analysis, calibrated to the motivation spectrum. Away-heavy: maps what pains competitors address, where mechanism claims have saturated, where solution-fatigue creates openings. Toward-heavy: maps who buyers aspire to BE like, where aspirational creator desire is unserved, where identity positioning is underexplored. Hybrid: dual competitive map — both pain mediation gaps AND aspiration mediation gaps, revealing the full competitive landscape. Reads market-context.md automatically. Part of ZenithPro Unified System."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/zp-mimetic {mode} [market|client-name]"
  called_by: [user]
  outputs_to: [project folder]
---

# ZenithPro Mimetic Market Intelligence (Unified)

Applies Girard's mimetic desire theory to competitive markets — calibrated to the motivation spectrum. In away markets, desire is mediated through pain: people buy to escape what a MODEL shows them can be escaped. In toward markets, desire is mediated through aspiration: people buy to become what an ASPIRATIONAL CREATOR shows them they can become. In hybrid markets, both mechanisms are active simultaneously, and the rarest competitive territory is where NO competitor addresses both simultaneously.

---

## STEP 0: READ MARKET CONTEXT

Before running any analysis, locate and read `market-context.md` in the current project folder.

Extract:
- **Away %** and **Toward %**
- **Zone** (Pure Away / Away-Dominant / True Hybrid / Toward-Dominant / Pure Toward)

Display the spectrum badge at the top of every output file:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MARKET: [name] | [X]% Away / [Y]% Toward | [Zone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

If `market-context.md` is not found, prompt the user:
> "I need to know this market's motivation spectrum before running mimetic analysis. What is the Away % and Toward %? Or run `/zp-market-context` first."

---

## LAYER 1: INVARIANTS (Never override. No exceptions.)

1. **Evidence or silence.** Every claim MUST be backed by a specific quote from live web research. NEVER state a competitor's positioning, desire mediation, or market behavior without a cited source. If evidence cannot be found, state "Insufficient public data" — do not guess.

2. **Client depth >= competitor depth.** The client profile (Doc 3) MUST contain equal or greater evidence density than any single competitor profile. If any competitor has 8 quotes, the client MUST have 8+. NEVER deliver a client profile thinner than a competitor profile.

3. **Direction of mimesis investigated before framing.** NEVER frame convergence without first researching timeline. The originator and the imitator face different strategic problems. Getting this wrong invalidates the entire analysis.

4. **Phase 2 never produced without client conversation.** HALT after Phase 1 delivery. Present conversation questions. WAIT for answers. NEVER generate Docs 4-6 without client input, even if the user asks to "just draft something."

5. **Live web research required.** Training data alone is NEVER sufficient. EVERY profile MUST cite at least 3 distinct URLs fetched during this session. If web research tools are unavailable, REFUSE to run the skill.

6. **In toward markets: the mimetic model is an ASPIRATIONAL CREATOR, not a peer sharing a problem.** In away markets: the mimetic model is someone who successfully escaped the pain the buyer wants to escape. In hybrid: both model types are active — map them separately before analyzing convergence.

---

## LAYER 2: QUALITY GUIDANCE

7. **Originator framing.** When the client pioneered the category, NEVER say "you converged with competitors." Say: "Your competitors successfully imitated your positioning. Your original differentiation no longer SOUNDS original. Here's how to re-establish the gap."

8. **Run the analysis, don't describe it.** NEVER describe what this analysis COULD produce. Actually produce it with real research and real evidence.

9. **Forensic respect.** Deliver hard truths directly. Treat findings as data, not judgments.

10. **The gap in hybrid markets is almost always positional.** No competitor is simultaneously addressing the escape AND the arrival. When you find this hybrid gap, it is the highest-value positioning territory available.

---

## THE CRITICAL DISTINCTION FROM STANDARD COMPETITIVE ANALYSIS

Standard competitive analysis compares products, features, and pricing.

**Mimetic market intelligence compares what DESIRE each competitor mediates.**

**Away market question:** What PAIN do competitors claim to solve — and what identity of the escaped person do they promise?

**Toward market question:** Who do buyers aspire to BE LIKE — and which aspirational creators are competitors invoking to mediate that desire?

**Hybrid market question:** Both. And: which competitors (if any) address both directions? The answer is almost always "none" — which is the open territory.

---

## PURPOSE

Maps competitive markets at the desire level, not the feature level. Most powerful when competitors have converged into sameness — which is true in virtually every mature market, in both pain and aspiration categories.

**Who it serves:** Business owners in any competitive market. Especially powerful in crowded markets where competitors' positioning has collapsed into indistinguishable sameness.

**What problem it solves:** Business owners think their positioning problem is about features, pricing, or messaging. The real problem is almost always that they are mediating the same desires as everyone else — or that their genuine differentiation is invisible because their marketing language has converged with competitors.

---

## REFUSAL TRIGGERS

IF asked to produce copy, ads, or marketing content from this analysis:
> "This skill produces strategic analysis, not content. Use the analysis outputs as input to a content or copy skill."

IF asked to skip Phase 1 and go directly to Phase 2:
> "Phase 2 requires Phase 1 outputs as input. Run phase1 first."

IF asked to run analysis without web research:
> "This skill requires live web research. Analysis from training data alone violates Invariant 5. Provide web access or do not proceed."

IF asked to analyze fewer than 5 competitors:
> "Mimetic analysis requires sufficient market density to detect convergence patterns. Minimum 5 competitors. Provide more or authorize me to identify additional competitors through research."

IF the market zone is Pure Toward and the user asks for away-style analysis:
> "This market scores as Pure Toward. Running away-mode mimetic analysis would misframe the competitive landscape. Proceeding with full toward methodology. Confirm or provide a corrected spectrum score."

IF the market zone is Pure Away and the user asks for toward-style analysis:
> "This market scores as Pure Away. Running toward-mode mimetic analysis would misframe the competitive landscape. Proceeding with full away methodology. Confirm or provide a corrected spectrum score."

---

## CONFIDENCE PROTOCOL

- **CONFIRMED** (5+ sources, consistent pattern): State the finding directly. No hedging.
- **PROBABLE** (2-4 sources, consistent pattern): State with evidence citation.
- **LOW-CONFIDENCE** (1 source or conflicting data): Flag explicitly before proceeding.

---

## INPUTS

### Required for Phase 1
1. Client's brand/company name and website URL
2. List of 10-20 competitors (or permission to identify them)
3. Client's product suite with brief descriptions and price points
4. The market/niche (be specific)
5. **For toward-weighted markets:** The aspirational creators in this market if known — the practitioners, artists, or figures whose work creates the "I want to do that" response
6. **market-context.md** (must exist — see Step 0)

Proceed ONLY when items 1, 2, and 4 are confirmed.

### Optional but Valuable
- Links to client's sales pages, marketing materials
- Client's social media handles
- Historical context (founding date, concepts they originated, key milestones)

### Required for Phase 2
- Client's answers to ALL conversation questions (presented after Phase 1 delivery)

---

## MODES

```
/zp-mimetic phase1 [market]      # Phase 1: Docs 1-3 (research-driven)
/zp-mimetic phase2 [client]      # Phase 2: Docs 4-6 (requires Phase 1 + client input)
/zp-mimetic full [market]        # Both phases with mandatory pause between
```

---

## TOOL USAGE CONSTRAINTS

### WebSearch
- MUST run at minimum 3 distinct search queries per competitor
- For away markets: `[name + "sales page"]`, `[name + "about"]`, `[name + primary product name]`
- For toward markets: `[name + "program"]`, `[name + "about"]`, `[name + "learn" + market keyword]`
- For aspirational creators (toward markets): `[creator name + social]`, `[creator name + work samples]`, `[creator name + community]`

### WebFetch
- MUST attempt to fetch: homepage, about page, and at least one product/sales page per competitor
- For toward markets: MUST also fetch the aspirational creator's public presence pages
- NEVER cite a URL you did not actually fetch and read in this session

---

## CONTEXT WINDOW MANAGEMENT

For markets with 10+ competitors, research in batches of 5:
1. Complete full research for 5 entities, produce their profiles
2. Save each batch to file before starting the next
3. Build a running summary table (name, primary desire mediated, key evidence)
4. The convergence map builds incrementally — update after each batch

IF approaching context limits mid-batch:
- Save ALL work in progress to files immediately
- Produce a handoff note: completed entities, remaining, partial findings, where to resume

---

## SPECTRUM EXECUTION GUIDE

### Pure Away (85-100% Away)

Run full away methodology. All 3 documents focus on pain mediation, mechanism convergence, and anti-mimetic positioning in the problem space. No toward sections. The aspirational creator landscape section is omitted entirely.

### Away-Dominant (60-84% Away)

Primary = away competitive map (pain mediation, mechanism saturation, anti-mimetic opportunities). Add as secondary sections:
- Aspirational Creator Landscape (brief) — who do buyers in this market aspire to BE like, even though the market is primarily pain-driven? This is often an underexplored gap even in away markets.
- Aspirational Identity Convergence (brief) — what identity of the "escaped" person is every competitor promising? Where has that promised identity become generic?

Label toward additions: `[TOWARD INJECTION]`

### True Hybrid (45-59%)

**RUN THE DUAL COMPETITIVE MAP.** This is the full methodology for hybrid markets.

Doc 1 becomes two documents in one:
1. **Pain Mediation Convergence Map** — complete away methodology applied to competitor pain claims
2. **Aspiration Mediation Convergence Map** — complete toward methodology applied to competitor identity/aspiration claims
3. **Intersection Analysis** — "The Hybrid Positioning Gap" (mandatory — see below)

Doc 2 profiles each competitor on BOTH dimensions:
- What pain/problem they claim to solve and how they've mediated the escape identity
- What aspiration/identity they promise and what aspirational creators they invoke

Doc 3 profiles the client on BOTH dimensions.

**MANDATORY HYBRID SECTION: The Intersection Analysis**

Add to Doc 1 after both convergence maps:

```
## THE HYBRID POSITIONING GAP

The unclaimed territory where NO competitor is simultaneously addressing the escape AND the arrival.

Pain mediation gap: [The most underserved pain story — what problem no competitor is naming sharply]
Aspiration mediation gap: [The most underserved aspiration story — what identity no competitor is specifically promising]

The intersection: [One paragraph describing the positioning space where a competitor would simultaneously name the thing buyers are running FROM and the person they're running TOWARD — and why no current competitor occupies this space]

Evidence this gap exists:
- From pain side: [market evidence that this problem is unaddressed]
- From aspiration side: [market evidence that this identity is unserved]

The strategic implication: [Concrete positioning recommendation that occupies the intersection]
```

### Toward-Dominant (60-84% Toward)

Primary = aspirational creator landscape, identity convergence map, aspirational mediation gaps. Add as secondary sections:
- Brief Pain Gap Analysis — what problem language competitors use and where mechanism convergence has created fatigue
- Escaped Identity Audit — what version of the "after" person competitors promise and whether these have converged into sameness

Label away additions: `[AWAY INJECTION]`

### Pure Toward (85-100% Toward)

Run full toward methodology. All 3 documents focus on aspirational creator landscape, identity promise convergence, and mimetic whitespace in the aspiration/identity positioning space. No away sections. Pain mediation analysis is omitted entirely. Zero avoidance language anywhere in any document.

---

## MODE: phase1

Produces 3 documents from web research alone. No client conversation required.

---

### Step 1: Map the Aspirational Creator Landscape (Toward-weighted markets only)

*Skip this step in Pure Away. Reduce to brief survey in Away-Dominant.*

Before analyzing competitors, map the ASPIRATIONAL CREATORS in this market — the practitioners, artists, or figures whose work creates the "I want to do that" desire.

For each aspirational creator identified (aim for 5-10):
- Who are they? What do they create/do/practice?
- Where is their work visible? (Social platforms, galleries, publications, YouTube)
- What specifically creates the "I want to do that" moment in viewers?
- What identity do they embody that buyers want to claim?
- What is their relationship to instruction, if any? (Do they teach? Are they affiliated with any program?)
- Evidence: specific examples of their work, follower counts, engagement signals, comments expressing aspiration

**The aspiration origin question for each creator:** Does viewing their work make a prospect feel: (a) admiration at an impossible distance, or (b) "I could see myself doing that"? Only creators who produce (b) are functional mimetic models for purchase. Document which type each creator is.

---

### Step 2: Competitor Research

For EACH competitor, research using WebSearch and WebFetch. Minimum per competitor:
- Main website (homepage, about, product pages)
- Primary social media (last 30 days of public posts)
- Sales pages for current offers
- Course/program descriptions
- Any free content, challenges, or lead magnets currently running
- Student testimonials and transformation language

---

### Step 3: Document 1 — Convergence Analysis

**The 6 Convergence Dimensions — spectrum-calibrated:**

**Pure Away / Away-Dominant version:**
1. **Promise convergence** — what escape/solution everyone promises
2. **Narrative convergence** — the story everyone tells (usually: "here's why nothing else worked")
3. **Offer structure convergence** — how everyone packages (format, price tier, delivery)
4. **Proof convergence** — what results everyone showcases
5. **Language convergence** — specific words/phrases adopted market-wide
6. **Enemy convergence** — what everyone positions against (the villain, the false solution, the establishment)

**Pure Toward / Toward-Dominant version:**
1. **Identity Promise Convergence** — what identity everyone claims to deliver. Does everyone say "you'll become an artist"? Document the specific language used.
2. **Aspiration Language Convergence** — the vocabulary everyone uses to describe the transformation. Where has the language become market-wide noise?
3. **Aspirational Model Convergence** — which aspirational creators does everyone reference or emulate? Creates mimetic saturation.
4. **Offer Structure Convergence** — how everyone packages: course vs. community, self-paced vs. cohort, beginner-focused vs. skill-level-agnostic.
5. **WHO Specificity Convergence** — who everyone says they are designed for. The absence of specificity IS a convergence (on vagueness).
6. **Proof Type Convergence** — what transformation evidence everyone shows. Where has proof become formulaic?

**True Hybrid version:** Run both sets of 6 dimensions. This produces a 12-dimension convergence map — 6 for pain mediation, 6 for aspiration mediation. Then add the Intersection Analysis section (see Spectrum Execution Guide above).

Each dimension MUST include specific evidence quotes from multiple competitors showing the convergence pattern.

Then produce:
- Where the client has converged (with specific evidence from their marketing)
- Genuine differentiators (provable, structural — not aspirational)
- Open positioning space (genuinely unoccupied territory with evidence that no competitor occupies it)

---

### Step 4: Document 2 — Competitor Desire Analysis

**Away-weighted competitor profile:**
For each competitor, produce:
- **Primary desire mediated** — the core pain/problem the buyer wants to escape
- **Secondary desires** — supporting desires that reinforce the primary
- **The model presented** — who/what is the aspirational "escaped" figure
- **Evidence** — 5-10 specific quotes from actual marketing showing desire mediation

NEVER deliver a competitor profile with fewer than 5 evidence quotes. If fewer than 5 quotes can be found, mark as LOW-CONFIDENCE.

Then map:
- **Contested desire zones** — pains where 5+ competitors fight over the same territory (saturated mechanism claims, everyone naming the same villain)
- **Underserved desire zones** — pains that exist in the market but nobody explicitly names or owns, with evidence they exist

**Toward-weighted competitor profile:**
For each competitor, produce:
- **Primary identity promised** — the specific version of themselves the buyer is told they will become
- **Aspirational model used** — which creator(s) or practitioner(s) they invoke (explicitly or implicitly)
- **WHO they say they serve** — the specific person (if named) or the vague "anyone" claim
- **Aspiration level targeted** — Fresh Curious / Genuinely Interested / Returning After Stopping / Practicing But Plateaued
- **Evidence** — 5-10 specific quotes from actual marketing showing identity/aspiration language

Then map:
- **Contested Aspiration Zones** — identity promises where 5+ competitors fight with similar language
- **Underserved Aspiration Zones** — specific identities clearly existing in the market but no competitor explicitly promises to deliver
- **Aspirational Creator Saturation Map** — which creators are referenced by 3+ competitors (crowded), which are referenced by only 1 or 0 (open)

**Hybrid competitor profile:** Run both profile templates for each competitor. Note where a competitor's pain mediation and aspiration mediation are: (a) aligned and mutually reinforcing, (b) disconnected and diluting each other, or (c) in tension — the competitor promises escape from the thing they also promise the buyer will become.

---

### Step 5: Document 3 — Client Desire Profile

This document MUST be the most detailed of all profiles. Verify against Invariant 2 before saving.

**Required sections (all 7 mandatory):**

**Away-weighted version:**
1. **The Desire Profile** — Primary desire mediated, secondary desires, the model presented, 10+ evidence quotes from actual client marketing
2. **Desire Mediation Strengths** — where the client's pain-escape positioning is genuinely powerful (with evidence)
3. **Desire Mediation Gaps** — where the client's positioning is weak, invisible, or contradictory (with evidence)
4. **The Model Problem** — external vs. internal mediation analysis. Does the client function as distant guru (external mediator) or accessible peer who escaped the same problem (internal mediator)?
5. **The Desire Triangle** — Subject (prospect), Model (client/students), Object (what is desired — the escaped state) — is this clear and focused or fragmented?
6. **Side-by-Side Comparison** — table comparing client to top 4-5 competitors on: primary desire, escape identity label, model visibility, social proof type, emotional activation, desire clarity, mechanism specificity
7. **Where the Client Wins/Loses in Mimetic Terms** — specific structural advantages and disadvantages

**Toward-weighted version:**
1. **The Aspiration Profile** — What identity does the client's marketing promise? What aspirational model do they invoke? What specific WHO do they claim to serve? 10+ evidence quotes.
2. **Aspiration Mediation Strengths** — where is the client's aspiration positioning genuinely powerful? (With evidence) What identity language is distinctive vs. generic?
3. **Aspiration Mediation Gaps** — where is the client's positioning weak, vague, or identical to competitors? Where are they using technique language when identity language would be more powerful?
4. **The Model Problem** — Who is the client positioning as the aspirational figure? Is that figure Internal (the client themselves as aspirational practitioner), External (a famous distant master), or Student/Peer (graduates of the program who now embody the identity)?
5. **The Aspiration Triangle** — Subject (prospect who wants the identity), Model (aspirational figure who already has it), Object (the identity being desired). Is this triangle clear and tightly focused, or fragmented?
6. **Side-by-Side Comparison** — table comparing client to top 4-5 competitors:

| Dimension | Client | Comp 1 | Comp 2 | Comp 3 | Comp 4 |
|-----------|--------|--------|--------|--------|--------|
| Identity promised | | | | | |
| Aspirational model | | | | | |
| WHO specificity | | | | | |
| Aspiration level targeted | | | | | |
| Technique vs. identity language ratio | | | | | |
| Proof type | | | | | |

7. **Where the Client Wins/Loses in Mimetic Terms** — specific structural advantages and disadvantages

**Hybrid version:** Run both complete sets of 7 sections. The client is profiled on BOTH dimensions. Add an 8th section:

**8. The Client's Hybrid Positioning Coherence:** Does the client's pain mediation and aspiration mediation tell a coherent story together? Or are they sending mixed signals — promising escape from the thing the customer simultaneously aspires toward? Identify whether the client occupies any part of the Hybrid Positioning Gap identified in Doc 1.

---

### Step 6: Deliver Phase 1 + Present Phase 2 Questions

ALL 3 documents MUST be saved as individual markdown files. NEVER deliver in chat only.

After saving, present the conversation questions for Phase 2 verbatim. Do NOT paraphrase, reorder, or omit questions.

HALT. Do not proceed to Phase 2 without client answers.

---

## MODE: phase2

Requires: Phase 1 complete AND client answers to conversation questions.

NEVER proceed if either prerequisite is missing.

---

### Document 4: Model Strategy

**Away-weighted version (Visibility and Model Strategy):**
How to fix the model invisibility problem. MUST include:
- Respect for client's actual visibility preferences and constraints (from conversation)
- A "fast-execution visibility move" — something the client can do NOW
- A Manifesto equivalent — a single document or content piece that could position the entire brand
- Grounding in what the client is already doing or willing to do

**Toward-weighted version (Aspiration Model Strategy):**
How to optimize WHO the client positions as the aspirational figure and how that figure is made visible. MUST include:
- Respect for client's actual visibility preferences and constraints
- A "fast aspiration model move" — one thing the client can do NOW to strengthen the aspiration chain
- The optimal combination of model types (internal/external/peer) for this specific market
- Specific ways to make the aspirational model more visible across touchpoints
- How to close the gap between "admiration at a distance" and "I could see myself doing that"

**Hybrid version:** Both sections above, plus: how to deploy the model so it simultaneously signals escape (for the away-motivated segment) and aspiration (for the toward-motivated segment) — which is almost always the same person shown doing the thing, not just telling about doing the thing.

---

### Document 5: Desire/Identity Positioning Strategy

**Away-weighted version (Desire Unification Strategy):**
How to unify fragmented desires across products into one escalating arc. MUST include:
- Each product mapped to a level of the unified desire
- Peer-level pricing problems identified
- Founder energy mapping — position highest-energy activities at highest-proximity points
- Gaps between what was designed and what the market actually buys
- Any product misalignment the client flagged in conversation

**Toward-weighted version (Identity Positioning Strategy):**
How to sharpen the client's identity promise and differentiate it from competitors. MUST include:
- Specific rewrite recommendations for current identity language (before/after examples)
- WHO specificity recommendations — the exact person this offer should explicitly claim to serve
- Aspiration level targeting — which aspiration level represents the highest-value segment
- The single most differentiating identity claim available to this client (supported by Phase 1 evidence)
- Aspirational creators the client should explicitly align with

**Hybrid version:** Both above. Plus: how to position the product suite so early-stage products speak to escape desire (resolving pain) and later-stage products speak to aspiration desire (claiming identity) — creating a natural escalation arc where the same customer is served at both stages.

---

### Document 6: Internal Mediator / Desire Propagation Deployment Strategy

**Away-weighted version:**
Shift social proof from external mediation to internal mediation. MUST include:
- The 5-dimension scoring framework: Model Proximity, Achievement Relevance, Temporal Proximity, Specificity, Visibility
- Identification of existing proof that can be repositioned
- Specific deployment map (landing pages, email sequences, webinars, social, community)
- Ideal mediator profiles for EACH product
- "Fast content vehicles" — ways to deploy internal mediators through content the client is already creating

**Toward-weighted version (Mimetic Desire Propagation Strategy):**
How to deploy aspirational content that creates and sustains "I want to do that" desire. MUST include:
- Content vehicles that display the aspirational identity in action (not testimonials about technique acquired, but evidence of identity claimed)
- The 5-dimension aspiration proof scoring framework: Identity Proximity, Achievement Visibility, Temporal Proximity, Specificity, Demographic Match
- Identification of existing student/community content that can be repositioned as aspiration proof
- Specific deployment map: where aspiration content should appear and what it should show
- The "aspiration chain" content strategy: aspirational creator's work visible → proof identity is available to people like them → specific invitation for their type of person

**Hybrid version:** Both above. Deploy both types of proof — internal mediators who show escape (for the away-motivated) and peer transformation stories who show identity claimed (for the toward-motivated). The most powerful proof in a hybrid market shows BOTH: a real person who escaped the thing AND became the identity they were reaching for. This is the dually resonant testimonial that works across the full spectrum.

---

## VOICE AND TONE

All documents use the voice of a FORENSIC ANALYST. Not a consultant. Not a coach.

**ALWAYS:**
- Specific evidence first (quotes, data points, named sources)
- Direct declarative sentences: "X mediates Y" not "X appears to mediate Y"
- Comparison tables for side-by-side analysis
- Name names, cite sources, show receipts
- Every sentence earns its place

**NEVER:**
- Consultant-speak: "we recommend exploring the possibility of..."
- Vague intensifiers: "very significant," "extremely powerful," "truly unique"
- Filler transitions: "It is worth noting that...", "Interestingly..."
- Softened findings: deliver hard truths directly, not wrapped in compliments
- **In toward-weighted documents:** Avoidance language (pain, frustration, solve, fix, overcome, stuck) anywhere in the skill's own voice
- Marketing language about the methodology itself

---

## CONVERSATION QUESTIONS

Present verbatim after Phase 1 delivery.

### For Doc 4 (Model Strategy)

**Away-weighted:**
1. What content are you already planning or producing?
2. Which channels are you open to? Which are off-limits?
3. What's your content creation capacity (team, time, tools)?
4. Personal brand visibility vs. company brand — preference?
5. Formats you enjoy vs. formats you refuse?
6. Current audience size per platform?
7. How much personal time per week for visibility?
8. Have you tried increasing visibility before? What happened?
9. Any competitors whose visibility approach you admire?
10. Did the Phase 1 analysis spark any ideas?

**Toward-weighted:**
1. Who in your market do your students aspire to be like — which practitioner or creator generates the "I want to do that" response most powerfully?
2. Are you positioned as an aspirational model yourself, or primarily as a guide/teacher to other aspirational models?
3. What content are you already creating that shows the identity (not just the technique) in action?
4. Which channels are you open to? Which are off-limits?
5. How much personal content (showing your own practice/work) are you currently producing vs. teaching content?
6. Do you have students who now clearly embody the identity you promise?
7. Have you tried increasing aspiration visibility before? What happened?
8. Did the Phase 1 analysis surface any aspirational models you're not currently using?

**Hybrid:** Ask all questions from both lists. Flag which answers serve the away positioning strategy and which serve the toward positioning strategy.

### For Doc 5 (Positioning Strategy)

**Away-weighted:**
1. How do you see your products connecting? What's the intended journey?
2. Which product is your flagship — the ONE thing you want to be known for?
3. Any products you're considering retiring, merging, or repositioning?
4. What's the ONE transformation you want buyers to associate with your brand?
5. One-sentence answer to "what does [your brand] do?"
6. Same buyer at different stages, or different buyers with different needs?
7. Any product that feels misaligned with the others?
8. What emotional arc do you want from first contact to highest-tier product?
9. What are you most energized about right now?

**Toward-weighted:**
1. What is the single identity transformation you want to be known for delivering?
2. Which specific type of person do you MOST want to serve — and is that specificity currently visible in your marketing?
3. Any current products or positioning that feels misaligned with your actual identity promise?
4. What's the ONE sentence that should describe who someone becomes through working with you?
5. Are there aspirational creators in your market whose audience you are specifically well-positioned to serve?
6. What aspiration level are most of your current buyers at when they find you?
7. What are you most energized about in your own practice right now?

**Hybrid:** Ask all questions from both lists.

### For Doc 6 (Mediator/Propagation Strategy)

**Away-weighted:**
1. Do you have client success stories not currently in your marketing?
2. Confidentiality/NDA constraints on sharing results?
3. Current testimonial collection process?
4. Video testimonials or only written?
5. Clients whose transformation would be especially compelling?
6. Would successful clients participate in case studies?
7. What content are you already creating that could carry peer stories?

**Toward-weighted:**
1. Do you have student transformation stories that show identity claimed, not just skill acquired?
2. Are there confidentiality constraints on sharing specific student stories?
3. What does your current student community look like — and is that community visible to prospects?
4. Would successful students participate in case studies or content featuring their transformation?
5. What content are you already creating that could carry aspiration proof?
6. Are there practitioners in your community whose work is starting to generate its own "I want to do that" response?
7. What would a new student see if they looked at your community from the outside?

**Hybrid:** Ask all questions from both lists. Identify which success stories work as escape proof (away-motivated prospects), which work as identity proof (toward-motivated prospects), and which rare stories work as both.

---

## OUTPUT SPECIFICATION

**File naming:**

Away mode:
```
ZP-MMI Doc 1 - Pain Mediation Convergence Analysis.md
ZP-MMI Doc 2 - Competitor Desire Theft Analysis.md
ZP-MMI Doc 3 - Client Desire Profile.md
ZP-MMI Doc 4 - Visibility and Model Strategy.md
ZP-MMI Doc 5 - Desire Unification Strategy.md
ZP-MMI Doc 6 - Internal Mediator Deployment.md
```

Toward mode:
```
ZP-MMI Doc 1 - Aspiration Convergence Analysis.md
ZP-MMI Doc 2 - Competitor Aspiration Theft Analysis.md
ZP-MMI Doc 3 - Client Aspiration Profile.md
ZP-MMI Doc 4 - Aspiration Model Strategy.md
ZP-MMI Doc 5 - Identity Positioning Strategy.md
ZP-MMI Doc 6 - Mimetic Desire Propagation Strategy.md
```

Hybrid mode:
```
ZP-MMI Doc 1 - Dual Competitive Map.md          (pain + aspiration convergence + intersection analysis)
ZP-MMI Doc 2 - Competitor Dual Desire Analysis.md   (each competitor profiled on both dimensions)
ZP-MMI Doc 3 - Client Dual Desire Profile.md        (client on both dimensions + coherence audit)
ZP-MMI Doc 4 - Dual Model Strategy.md
ZP-MMI Doc 5 - Dual Positioning Strategy.md
ZP-MMI Doc 6 - Full Spectrum Proof Deployment.md
```

All files open with the Spectrum Badge.

---

## DOCUMENT SPECIFICATIONS

| Document | Required Sections | Min Evidence Quotes | Target Length |
|----------|------------------|--------------------:|--------------|
| Doc 1 | 6 convergence dimensions (×2 in hybrid) + intersection analysis (hybrid only) + 3 analysis sections | 3+ per dimension | 2,000-5,000 words |
| Doc 2 | 1 profile per competitor + 2-3 zone maps | 5-10 per competitor | 3,000-6,000 words |
| Doc 3 | 7 sections (all mandatory) + 8th in hybrid | 10+ client quotes | 2,000-4,000 words |
| Doc 4 | Model strategy + fast move + channel strategy | Grounded in client answers | 1,500-3,000 words |
| Doc 5 | Positioning rewrite + WHO specificity + desire arc | Before/after examples | 1,500-3,000 words |
| Doc 6 | 5-dim proof framework + deployment map + content vehicles | Existing proof inventory | 1,500-3,000 words |

---

## QUALITY GATE (mandatory pre-save check)

BEFORE saving any document, verify ALL of the following. If any item fails, FIX before saving.

- [ ] Spectrum badge present at top of every file
- [ ] market-context.md was read before execution
- [ ] Every competitor claim backed by a specific quote from current marketing (Invariant 1)
- [ ] Client profile has equal or greater depth than any competitor profile (Invariant 2)
- [ ] Direction of mimesis correctly identified with timeline evidence (Invariant 3)
- [ ] Phase 2 never produced without client conversation (Invariant 4)
- [ ] Live web research used — not training data alone (Invariant 5)
- [ ] Convergence dimensions all present (6 for single-mode, 12 for hybrid)
- [ ] Hybrid mode: Intersection Analysis section is present and specific — not generic
- [ ] No vague/aspirational language — every recommendation is concrete and actionable
- [ ] Contested/uncontested zones supported by market evidence, not just competitor count
- [ ] Open positioning space is genuinely unoccupied (verified, not assumed)
- [ ] Tone is forensic — no consultant-speak, no filler, no hedge words
- [ ] In toward-weighted documents: zero avoidance language in skill's own voice
- [ ] Phase 2 docs incorporate ALL client input from conversation
- [ ] Confidence labels applied where evidence is thin
- [ ] File saved to disk, not just delivered in chat

---

## GIRARDIAN CONCEPTS REFERENCE — SPECTRUM-CALIBRATED

| Concept | Away Market Application | Toward Market Application |
|---------|------------------------|--------------------------|
| **Mimetic Desire** | People buy to escape what models show can be escaped | People buy to become what aspirational creators embody |
| **External vs. Internal Mediation** | Distant "success stories" create distance; peer escapees create actionable desire | Distant aspirational creators create admiration; peer transformees create identity permission |
| **Mimetic Convergence** | Competitors converge on same villain, same mechanism claim, same escape identity | Competitors converge on same vague identity promise, same aspirational creator references, same technique language |
| **Contested vs. Uncontested Desires** | Blue ocean at the PAIN level — who names the problem most sharply | Blue ocean at the IDENTITY level — who promises the most specific, differentiated version of who the buyer becomes |
| **The Skandalon** | When the model's success creates more hopelessness than hope in prospects | When the aspirational creator is too skilled to create "I could do that" — only "I wish I could do that" |
| **Scapegoat Mechanism** | Doc 1 enemy convergence — same villains, same false solutions = positioning sameness | Approach markets have enemies too: the false belief (talent myth, age myth) that blocks identity permission |
| **Direction of Mimesis** | Who originated the pain framing and the escape story? | Who created demand for this identity in the market — the aspirational creator or a competitor? |
| **Hybrid Gap** | N/A | The unclaimed territory where both the escape story AND the identity story are told simultaneously — almost always unoccupied |

---

## HOW THIS CONNECTS DOWNSTREAM

- **zp-excavation** → Phase 11 from excavation (competitive intelligence) feeds into this skill as initial research
- **zp-avatar** → Avatar mirror specifications (toward) and avatar language matrix (away/toward) inform what kind of proof subjects to identify in Doc 6
- **usp-generator / toward-usp-generator** → Check USP claims against the convergence maps — is the positioning territory actually open?
- **core-concept-generator / permission-concept-generator** → What permission or paradigm shift is absent in the market (toward) or what villain has no one named (away)?
- **community-architect** → The aspirational creator landscape and WHO specificity findings (toward) + the tribal identity around shared enemy (away) both shape community design
- **copywriting-arena** → Phase 1 findings provide the competitive intelligence that informs headline direction, copy lead, and positioning strategy for all downstream copy production
