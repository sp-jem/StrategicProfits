---
name: zp-buying-state
description: "Unified ZenithPro buying state definition. Forensically defines the exact psychological state where buying becomes automatic for ANY market. Away-heavy markets: productive tension, mechanism belief, urgency, self-efficacy. Toward-heavy markets: identity readiness, anticipation, belonging, permission. Hybrid markets: dual activation state where both push and pull are present simultaneously. The four core dimensions (Logical Beliefs, Emotional State, Identity Alignment, Social Proof Needs) are preserved throughout — their content shifts by spectrum. Reads market-context.md automatically. Part of ZenithPro Unified System."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Unified, Force Multiplier, Connect the Dots]
interface:
  invoke: "/zp-buying-state [market or avatar]"
  called_by: [user, zp-demand-architect]
  outputs_to: [project folder]
---

# ZP Buying State

Blueprints the complete internal state where buying becomes automatic — calibrated to whether the market is pushed by pain, pulled by aspiration, or both simultaneously. Not a description of desire — a precise specification of the psychological state where selling becomes superfluous.

---

## LAYER 1: INVARIANTS

1. **Read market-context.md from the project folder before running.** If not found, prompt the user to run motivation-spectrum-analyzer first OR accept manual spectrum input: "Away: X% / Toward: Y%".
2. **Display the spectrum badge at the top of every output.** No exceptions.
3. **Point B is a psychological state, not a marketing message.** Map where their HEAD needs to be, not what to say to them.
4. **All four dimensions are mandatory regardless of zone.** Only the CONTENT of each dimension shifts by spectrum. The structure is universal.
5. **The direction of the buying state is zone-dependent.** Away markets: buying state is PUSH — relief, urgency, productive tension. Toward markets: buying state is PULL — anticipation, permission, identity readiness. Hybrid: BOTH vectors active simultaneously.
6. **True Hybrid markets have a Dual Activation State.** This is distinct from either pure state. Both the urgency of cost-of-inaction AND the excitement of identity aspiration fire together. Map both explicitly and map the interdependency.
7. **Point B must be purchaser-realistic.** Ground it in what actual buyers in this market have reported thinking and feeling. If reaching Point B requires states real humans couldn't hold, revise.
8. **Specificity over generality.** Not "they should feel confident" — "they should believe they can execute X even though they failed at Y, because Z explains the difference."
9. **Save all outputs to files.** Never deliver in chat only.

---

## PURPOSE

**Away markets (Drucker applied to avoidance):** "Know and understand the customer's problem so well that the solution fits and sells itself. All that should be needed then is to make the product available."

**Toward markets (Drucker inverted):** "Know and understand the aspiration so well that the product fits who they're becoming and sells itself."

**Hybrid markets:** Both simultaneously — the product resolves the pain AND catalyzes the becoming.

When a prospect is at Point B:

**Away market:** They've already made the internal decision that the status quo is unacceptable and this mechanism is their escape. The purchase is execution of a decision already reached. Delay feels more costly than action.

**Toward market:** They've already made the internal identity decision — they've accepted the new self-story. The purchase is the first act of their new identity. Delay feels like self-betrayal.

**Hybrid market:** Both are true simultaneously. The cost of inaction is real (away vector) AND the identity aspiration is ready to be claimed (toward vector). The buying state fires on both cylinders.

**Output use:** Point B from this skill IS the destination for zp-belief-gap. Every marketing activity's purpose is to move prospects from Point A to Point B.

---

## INPUTS

Required:
1. **Market/avatar description** — who they are, what they face or aspire to
2. **Product/service being sold** — what you offer and what it delivers
3. **Desire Hierarchy Map** — from zp-desire-mapper (which L1-L4 desires are active, what L4 gate type applies)
4. **Output folder path**

Optional (improve quality significantly):
- Psychographic research — especially rage points and buying behavior
- Avatar excavation — decision neuroscience and objection archaeology
- Testimonials from existing buyers describing their pre-purchase mental state

---

## SPECTRUM BADGE

Display this at the top of every output:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MARKET: [name] | [X]% Away / [Y]% Toward | [Zone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## THE FOUR UNIVERSAL DIMENSIONS

These four dimensions apply to every market at every spectrum position. Only the content within each dimension shifts by zone.

---

### DIMENSION 1: LOGICAL BELIEFS

What they must intellectually accept as irrefutable truth before purchase feels rational.

**Away-Weighted Content (Pure Away / Away-Dominant):**

*Category A: Problem Beliefs*
1. The problem is REAL (not imagined or exaggerated)
2. The problem is URGENT (not "someday I'll deal with this")
3. The problem is SOLVABLE (not a permanent condition)
4. The problem is COSTLY (quantify cost in money, time, opportunity, identity)
5. The problem WILL ESCALATE without intervention (delay gets more expensive)

*Category B: Solution Beliefs*
1. A solution EXISTS in this category (category-level trust)
2. This specific solution is DIFFERENT from what they've tried (differentiation)
3. The mechanism actually WORKS for the root cause (not just symptoms)
4. They've been failing because of the METHOD, not because of THEM (attribution shift)
5. The investment is JUSTIFIED by the return (ROI belief)

*Category C: Provider Beliefs*
1. Relevant EXPERTISE and authority
2. Results for people LIKE THEM
3. Motives aligned with their SUCCESS
4. Can DELIVER what promised (track record)

*Category D: Timing Beliefs*
1. NOW is optimal (not later)
2. Waiting has a QUANTIFIABLE COST
3. RISK of inaction exceeds risk of action
4. They have everything REQUIRED to start

**Toward-Weighted Content (Pure Toward / Toward-Dominant):**

*Category A: Aspiration Accessibility Beliefs*
1. This aspiration is GENUINELY AVAILABLE to someone who starts where they are
2. Age, background, starting point are NOT disqualifying — may even be advantages
3. The learning curve is real but NAVIGABLE — no mastery required to begin
4. This aspiration is worth serious investment — real transformation, not a hobby
5. The RIGHT guidance closes the gap between where they are and who they want to be

*Category B: Product Fit Beliefs*
1. This product was designed for people at THEIR starting point — not for the already-advanced
2. The method builds the real skill/identity — not a surface imitation
3. The instructor understands the experience of coming to this late/fresh
4. The community is composed of people they WANT TO BELONG WITH
5. The investment is proportionate to the transformation

*Category C: Provider Beliefs*
1. Genuine mastery — not just enthusiasm
2. Successfully guided people who started WHERE THEY'RE STARTING
3. Approach calibrated for approach-motivated learners (not performance-driven or shame-based)
4. Produced real transformations in people with similar backgrounds

*Category D: Timing Beliefs*
1. NOW is the right time — not because of external pressure but because THEY'RE READY
2. Starting later doesn't mean starting better — waiting postpones something they've decided they want
3. They have the prerequisites to begin (not mastery — just readiness)
4. This offer is right for where they are RIGHT NOW

**Hybrid Content (True Hybrid):**

Map BOTH sets of logical beliefs above. Where they overlap (timing, provider, fit), synthesize into dual-framed versions that carry both the urgency of the cost-of-inaction AND the readiness of "I'm prepared to become this person." Flag the 2-3 logical beliefs that are most important for closing both gaps simultaneously.

---

### DIMENSION 2: EMOTIONAL STATE

What they must viscerally experience for buying to feel natural.

**Away-Weighted States (Pure Away / Away-Dominant):**

*Positive States Required:*
- HOPE — genuine belief that change is possible for someone like them
- EXCITEMENT — energy around the transformation coming
- TRUST — felt sense that you're on their side
- READINESS — prepared, not resistant

*Negative States Required (Productive Tension):*
- DISSATISFACTION — current situation is genuinely unacceptable
- URGENCY — can't wait any longer
- FRUSTRATION — tired of the old approach
- PAIN — the cost of the problem is felt, not just known intellectually

*States That Must Be ABSENT:*
- Shame (blocks purchase — they feel unworthy)
- Fear of judgment (blocks disclosure of real situation)
- Distrust (blocks commitment)
- Cynicism (blocks belief in possibility)
- Overwhelm (blocks decision)

**Toward-Weighted States (Pure Toward / Toward-Dominant):**

*Positive States Required (all pull-based):*
- ANTICIPATION — forward-leaning excitement of something beginning; standing at a threshold knowing the door is about to open
- EXCITEMENT — genuine energy about who they're becoming; aliveness of moving toward something
- BELONGING — felt sense that the community inside is one they belong to; "my people are in there"
- IDENTITY READINESS — internal confirmation they're ready to be this person; "it's my turn"
- LIGHTNESS — the particular quality of approach motivation; addition, not correction
- TRUST — felt sense that teacher and community understand them and are invested in their becoming
- PERMISSION — past the internal objection that this is indulgent or premature

*States That Must Be ABSENT:*
- Shame (buying would feel like admission of failure)
- Urgency-as-pressure (feeling pushed rather than pulled)
- Anxiety about performance (fear they'll fail at this too)
- Self-doubt about worthiness (wondering if they deserve this)
- Overwhelm (commitment feels too large)
- Cynicism (protective skepticism of someone disappointed by aspiration before)

**Hybrid Emotional State (True Hybrid):**

The Dual Activation State. BOTH urgency from cost-of-inaction AND excitement from identity aspiration are present simultaneously. Neither cancels the other — they compound.

*Required positive states:* Hope (away vector) + Anticipation (toward vector) + Trust (universal) + Readiness (from both directions)

*Required productive tension:* Dissatisfaction with the current state (away vector) — held lightly enough that it doesn't crush the toward excitement

*States that must be ABSENT:* Shame, overwhelm, cynicism, distrust — these collapse both vectors simultaneously

The Dual Activation State is the rarest and most durable buying state. When it fires, both "I need to escape this" and "I'm ready to become that" are felt simultaneously, and each amplifies the other.

---

### DIMENSION 3: IDENTITY ALIGNMENT

Who they must envision themselves becoming — or already being — for purchase to feel congruent.

**Away-Weighted Content (Pure Away / Away-Dominant):**

*The New Identity Label:*
What identity must they claim before purchase feels right?
- NOT: "I'm the kind of person who invests in courses"
- YES: "I'm the kind of entrepreneur who builds leverage through systems"

*Identity Bridges Required:*
What must shift in how they see themselves?
- From [current limiting identity that defines them by the problem] → To [enabling identity that makes purchase feel congruent]
- Example: "From solo operator stuck in the weeds → to system architect who works ON the business"

*The Identity Permission (Away version):*
- "I'm allowed to invest at this level even though I've failed before"
- "I'm allowed to ask for help — that's not weakness, that's strategy"
- "I'm allowed to be the person who has systems working for them"

*The Identity Cost of NOT Buying:*
- "I stayed stuck when I had the chance to change"
- "I let fear stop me again"
- "I'm the kind of person who knows what to do but doesn't do it"

**Toward-Weighted Content (Pure Toward / Toward-Dominant):**

*The Identity Claim (present-tense):*
Before purchase feels congruent, they must have made a private identity claim. Not future tense — settled internally as present tense. "I AM this kind of person" — even if the skill or experience doesn't yet exist. The purchase is the first external act of an identity already formed internally.

*The New Identity Label (approach-market form):*
- NOT: "I'm someone who wants to sketch"
- YES: "I'm an urban sketcher" / "I'm someone who makes things"
- This is the label they'd use to describe themselves in this community

*Identity Bridges Required (approach-market form):*
- From [current identity that blocks purchase] → To [enabling identity that makes purchase congruent]
- Example: "From someone who appreciates art → to someone who makes art"
- Example: "From someone who wishes they had started younger → to someone for whom starting now is exactly right"

*The Identity Permission (Toward version):*
- Permission to invest in something that is FOR THEM (not their family, not their business)
- Permission to claim the identity BEFORE they've proven they deserve it
- Permission to start now rather than waiting until "more ready"
- Permission to pursue something for intrinsic pleasure without justifying it by outcomes

*The Identity Cost of NOT Buying (approach-market form):*
- "I'm still on the outside looking in"
- "I'm the person who thinks about doing this but doesn't"
- "I postponed something I've already decided I want"

**Hybrid Identity Alignment (True Hybrid):**

Map BOTH the away-market and toward-market identity bridges. The hybrid buying state requires that:

1. The limiting identity tied to the PROBLEM must shift (away vector — attribution shift, self-efficacy)
2. The aspired identity must be claimed as available (toward vector — identity permission)

Both must be present for purchase to feel congruent. The hybrid identity bridge: "From [person defined by the problem] → to [person who solved it AND became who they always wanted to be]." The resolution of the problem IS the beginning of the aspired identity.

---

### DIMENSION 4: SOCIAL PROOF NEEDS

What proof they must see — and how it functions — differs fundamentally by zone.

**Away-Weighted Proof (Pure Away / Away-Dominant):**

*Function:* Reduce risk. Establish that the mechanism works and that people like them have succeeded.

*Required proof types:*
- Peer-level results (not aspirational stars — people at their starting point who achieved the outcome)
- Attribution-shift proof (stories that make clear the old approach failed, not the person)
- Mechanism validation (demonstration that the specific method is different and works for the root cause)
- Provider credibility (track record, expertise, alignment of interests)

*The primary question social proof must answer:* "Will this work for me?"

**Toward-Weighted Proof (Pure Toward / Toward-Dominant):**

*Function:* Make the aspired identity VISIBLE and ACCESSIBLE — not reduce risk. Social proof in approach markets answers "Is there a place for someone like me in this world?"

*The Mirror Function:*
The highest-value proof is the demographic mirror: a person who looks exactly like the buyer (same age, same starting point, same background hesitations) who has crossed the threshold and is now living the identity.

The mirror communicates:
- "This world is for me too — not just for people who started young or had natural talent"
- "Someone exactly like me is already there — which means it's available, not just theoretical"
- "The community I'd be joining includes people like me"

*Required proof types:*
- Mirror testimony (nearly identical demographic who made the transformation)
- Community visibility (showing the community as populated by people like them at various levels)
- Progress evidence (showing the journey from their starting point — not the endpoint)

*The primary question social proof must answer:* "Is this available to someone like me?"

**Hybrid Social Proof (True Hybrid):**

The social proof must do double duty: answer both "Will this work for me?" AND "Is this for someone like me?"

The highest-value proof format in hybrid markets: a case study or testimonial that shows both (1) a person at the same starting point who escaped the problem using this specific mechanism, AND (2) that same person claiming a meaningful identity transformation through the process. The escape and the becoming documented together.

---

## THE BUYING STATE SYNTHESIS

After mapping all four dimensions, produce:

**THE COMPLETE POINT B STATEMENT**

**For Away-Weighted Zones:**
"A prospect is at Point B when they:

**Logically believe:** [5-7 specific belief statements — problem urgency, attribution shift, mechanism differentiation, provider credibility, ROI, timing]

**Emotionally feel:** [3-5 present states including productive tension; 3-5 absent states]

**Identify as:** [Specific identity they've claimed that makes purchase congruent — and the identity cost of not buying]

**See in social proof:** [Specific peer-level proof that confirms "this works for people like me"]

When all four are simultaneously present, purchase is not a selling situation — it's a logistics situation."

**For Toward-Weighted Zones:**
"A prospect is at Point B when they:

**Logically believe:** [5-7 specific rational readiness beliefs — aspiration accessibility, product fit, provider calibration, timing]

**Emotionally feel:** [3-5 positive pull-based states; 3-5 absent states — zero productive tension language]

**Identify as:** [The specific present-tense identity claim they've made privately]

**See in social proof:** [The specific mirror that made the aspired identity visible and available]

When all four are present simultaneously, purchase is not a selling situation — it's an enrollment situation."

**For True Hybrid Zone:**
"A prospect is at Point B in this hybrid market when they simultaneously experience:

**Logically believe (DUAL):** [Problem urgency AND aspiration accessibility — both sets present]

**Emotionally experience (DUAL ACTIVATION STATE):** Urgency from cost-of-inaction (away vector) PLUS anticipation of becoming (toward vector) — both active, neither canceling the other

**Identify as (DUAL BRIDGE):** Released from the identity defined by the problem (away vector) AND claiming the identity they aspire to (toward vector) — the resolution IS the beginning of the becoming

**See in social proof (DUAL FUNCTION):** Proof that answers 'Will this work for me?' AND 'Is this available to someone like me?' — ideally in a single case study or mirror testimony

The Dual Activation State is the most durable buying state. When both vectors fire simultaneously, urgency compounds excitement. The primary question — "Will this work AND can I become this person?" — must be answered simultaneously for purchase to be inevitable."

---

## THE OBJECTION RADAR

Map objections that arise when any dimension is incomplete:

**Away-Weighted Objections:**

| Incomplete Dimension | Resulting Objection | Correction Required |
|---------------------|--------------------|--------------------|
| Missing problem urgency belief | "I'll do this later" | Quantify the cost of delay |
| Missing attribution shift | "I'm not sure this will work for me" | Address past failures specifically — wrong method, not wrong person |
| Missing hope state | "I've tried this before" | Peer story with similar background and same failed approach |
| Missing trust state | "This sounds too good to be true" | Specific proof with granular details |
| Missing urgency state | "I need to think about it" | Time-bound opportunity framing |
| Missing identity permission | "This is a lot of money" | Reframe investment relative to identity claim |

**Toward-Weighted Objections:**

| Incomplete Dimension | Resulting Hesitation | Correction Required |
|---------------------|--------------------|--------------------|
| Missing accessibility belief | "I might be past the age for this" | Mirror testimony from same age/starting point |
| Missing product fit belief | "This might be designed for people ahead of me" | "Designed for your starting point" evidence |
| Missing anticipation state | "I'm interested but keep not pulling the trigger" | Demonstration that creates "I could do that" moment |
| Missing belonging state | "I'm not sure I'd fit in" | Community visibility showing people like them |
| Missing identity permission | "It feels like a lot for something just for me" | Reframe: identity investment, not discretionary spending |
| Missing identity claim | "I'll do it when I'm more ready" | Mirror: the claim comes before readiness, not after |

**Hybrid Objections:**

| Incomplete Dimension | Resulting Objection | Correction Required |
|---------------------|--------------------|--------------------|
| Missing dual activation | "I want this but I can't justify it" | Show both costs simultaneously: cost of staying stuck AND cost of postponing the becoming |
| Missing dual bridge | "I need this but I'm not sure I'm the right person" | Case study showing both escape AND identity claim in one story |
| Missing hybrid proof | "That's great but they seem different from me" | Proof that matches both their problem profile AND their aspiration profile |

---

## OUTPUT SPECIFICATION

**File: `Buying-State-[Market].md`**

Sections:
1. Spectrum Badge
2. The Four Dimensions (all beliefs, states, identity elements, social proof specifications — zone-calibrated)
3. The Complete Point B Statement (version appropriate to zone)
4. The Objection Radar (zone-appropriate objections and corrections)
5. Transition Guide (what moves prospects through each dimension from Point A to Point B)
6. Calibration Notes (how to know when a prospect has reached Point B in this zone)

**Target length:** 1,500-2,500 words.

---

## CALIBRATION NOTES

**Signs of Point B in Away-Weighted Markets:**
- They ask HOW questions ("How does payment work?") not WHETHER questions ("Is this worth it?")
- They start visualizing themselves using the solution ("I would use this for...")
- They reference the cost of NOT buying ("I can't keep doing what I'm doing")
- Their objections become tactical, not existential
- They ask about start dates, next steps, or logistics

**Signs of Point B in Toward-Weighted Markets:**
- They ask HOW questions ("How does the community work?") not WHETHER questions ("Is this for me?")
- They narrate their starting point to you — building context for their beginning
- They reference other community members or describe wanting to be part of what they've seen
- They use first-person future language: "I would use this for..." / "I've always wanted to..."
- They ask about start dates, next cohorts, or how quickly they'd see first results
- They mention the aspiration as something they've thought about for a long time

**Signs of Point B in True Hybrid Markets:**
- Both categories of signals above are present
- They're not asking whether it's worth it OR whether they belong — they're asking HOW
- They reference both the pain they want to escape AND the person they want to become

---

## QUALITY GATE

Before saving:
- [ ] Spectrum badge present
- [ ] market-context.md read (or manual input collected)
- [ ] Zone correctly identified and all four dimensions implemented for that zone
- [ ] Emotional state section matches zone (no productive tension in Pure Toward, no all-positive in Pure Away)
- [ ] Identity alignment maps the correct bridge type for zone (attribution/self-efficacy vs. identity claim/permission vs. dual bridge)
- [ ] Social proof needs specify the correct function (risk reduction vs. mirror/accessibility vs. dual function)
- [ ] Point B Statement written in zone-appropriate language
- [ ] Objection Radar covers zone-appropriate objections
- [ ] Saved to file

---

## HOW THIS CONNECTS DOWNSTREAM

- **zp-belief-gap** → Point B from this skill IS the destination for belief gap analysis. The complete Point B statement feeds directly into Gap Inventory Step 1.
- **zp-usp** → The USP must express Point B as a deliverable promise. Every USP candidate is tested: does it move prospects toward this buying state?
- **zp-desire-mapper** → This skill's inputs depend on the desire hierarchy map. Run zp-desire-mapper first.
- **Copywriting skills** → Each section of a webinar, sales page, or email sequence moves prospects through one dimension of the buying state
- **webinar structure** → Away markets: intro = emotional, content = logical, transition = contextual, close = identity. Toward markets: intro = belonging + anticipation, content = logical readiness + identity visibility, transition = identity claim, close = permission + enrollment. Hybrid: sequence both
- **community-architect** → Community design starts from Dimension 2 (belonging state) and Dimension 4 (social proof needs) defined here
