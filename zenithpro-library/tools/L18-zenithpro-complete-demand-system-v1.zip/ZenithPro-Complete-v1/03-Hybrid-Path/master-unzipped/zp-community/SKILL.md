---
name: zp-community
description: "Unified ZenithPro community architecture. Designs the community layer calibrated to the motivation spectrum. Toward-heavy: full tribal identity design — group name, mimetic desire flywheel, progression visibility, retention mechanics, membership economics. Away-heavy: support and accountability architecture — peer support structure, progress tracking, accountability mechanisms, milestone celebration. Hybrid: community that serves both escape and aspiration — provides accountability for the away journey AND tribal identity for the toward journey. Reads market-context.md automatically. Part of ZenithPro Unified System."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/zp-community [business or market]"
  called_by: [user, toward-demand-architect, hybrid-demand-architect, zp-pattern-analyzer]
  outputs_to: [project folder]
  reads: [market-context.md]
---

# ZP Community

Unified community architecture for the ZenithPro system. Auto-calibrates to the market's motivation spectrum — designing full tribal identity systems in toward-heavy markets, support and accountability infrastructure in away-heavy markets, and a dual-layer architecture that serves both when the market is hybrid.

---

## STEP 0: READ MARKET-CONTEXT.MD

Before any design work, locate and read market-context.md in the current project folder.

Extract:
- **Away%** — avoidance motivation intensity
- **Toward%** — approach motivation intensity
- **Zone** — Pure Away / Away-Dominant / True Hybrid / Toward-Dominant / Pure Toward

**Every output begins with the Spectrum Badge:**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MARKET: [name] | [X]% Away / [Y]% Toward | [Zone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

If market-context.md is not found, ask the user for Away%, Toward%, and Zone before proceeding.

---

## LAYER 1: INVARIANTS

These hold across all spectrum zones:

1. **Community IS optional in pure avoidance markets — flag this explicitly.** When people are primarily motivated to escape a problem, community is a support structure, not the product. When people are primarily motivated toward identity and mastery, community IS the product. Know the difference.
2. **The tribal identity name is NEVER the course or product name** in toward-heavy markets. Members claim "I'm an Urban Sketcher," not "I'm in Ian's course." This distinction determines whether you have a tribe or a customer list.
3. **The mimetic flywheel creates its own demand without marketing spend** — but only in markets where members produce shareable output. In away markets, there is no shareable output (solving a problem doesn't generate desire in others). Design accordingly.
4. **Progression visibility is how aspiration stays alive** in toward-heavy communities. Without visible role models at the next level, advancement feels hypothetical.
5. **Community cannot substitute for results.** In away markets, if the product doesn't solve the problem, no amount of community architecture saves retention. Community amplifies results; it doesn't replace them.
6. **The first win experience must arrive before the first doubt.** New members have a short window before buyer's remorse sets in. Design the path to a meaningful first milestone before the first week ends.
7. **Never design community as content delivery infrastructure.** Content serves the individual. Community serves belonging (toward) or accountability (away). Confusing the two produces a library with live chat — not a community.
8. **Save all outputs to files.** Never deliver community architecture only in chat.

---

## PURPOSE

Answers the community question calibrated to actual market motivation:

**In away-heavy markets:**
> "What support and accountability structure gives people the best chance of actually solving the problem — and makes them feel less alone in the struggle?"

**In toward-heavy markets:**
> "What is the tribal architecture — identity, language, rituals, progression, economics — that makes this community self-sustaining, self-recruiting, and more valuable than the content it surrounds?"

**In hybrid markets:**
> "What dual-layer architecture serves both the escape journey (accountability, progress, solidarity) AND the aspiration journey (identity, belonging, mimetic desire) — without conflating the two or making either feel inauthentic?"

---

## INPUTS

Gather from the user before running (beyond market-context.md):

1. **Business/market name** and brief description of what's being taught or solved
2. **Target market description** — who they are, what they're escaping and/or aspiring toward
3. **Existing product or offer** — what's already being sold, if anything
4. **Current community state** — nothing yet / small private group / existing Facebook group / active Discord / etc.
5. **Aspiration Hierarchy Map** — from zp-desire-mapper or toward-desire-mapper, if available (toward markets)
6. **Progression Landscape Map** — from zp-pattern-analyzer, if available (toward markets)
7. **Failure Archaeology Report** — from zp-pattern-analyzer, if available (away markets — informs the shared struggle architecture)
8. **Price point range** — approximate, helps calibrate membership economics
9. **Output folder path** — where to save the completed architecture document

---

## ZONE-CALIBRATED EXECUTION

---

### PURE AWAY (85%+ Away)

**Flag to the user at the top of the output:**

> **Community Note for Pure Avoidance Markets:** Community is optional at this spectrum position. The primary product must solve the problem — community alone cannot carry retention. If you add community, the architecture below frames it as support infrastructure, not tribal identity. Members are united by a shared struggle they want to escape, not a shared identity they want to claim. Do not try to force tribal dynamics into a pure avoidance market — it reads as tone-deaf and creates dissonance.

If the user confirms they want community architecture for a pure away market, run the Support & Accountability Architecture below.

---

#### Support & Accountability Architecture (Pure Away)

**Phase 1: Support Structure Design**

**1.1 — The Shared Struggle Frame**

Define how the community frames the problem members are facing together. This is not a tribal identity — it is a solidarity statement.

Rules:
- The frame must validate the struggle without pathologizing the member ("We're all navigating [X] — and it's genuinely hard, not because you're doing it wrong, but because [reason]")
- The language is solidarity language, not aspiration language
- The community name is functional, not identity-claiming ("The [Program] Community" or "[Program] Members" — not "The [Identity Label]s")

**Produce:**
- Community name (functional, not tribal)
- Solidarity statement (2-3 sentences defining what members share)
- The shared language for what they're working through

**1.2 — Peer Support Structure**

Design how members support each other through the difficult parts of the journey.

For each support mechanism:
- What it is (peer pairs, small groups, open forum, cohorts)
- How it's formed (opt-in, auto-assigned, skill-matched)
- What members do together (accountability check-ins, shared problem-solving, progress sharing)
- Frequency and format (weekly async, live calls, threaded discussion)

**Produce:** 2-3 peer support structures with formation method, activity, and frequency.

**Phase 2: Progress Tracking Architecture**

Members in away markets need to see they're moving. Progress visibility is the retention mechanism — not aspiration visibility (which is the mechanism in toward markets).

**2.1 — Milestone Definitions**

Define 4-6 observable milestones that mark genuine progress toward the escape goal. Each milestone must be:
- Concrete and observable (not "feels better" — a specific result or behavior)
- Achievable within a defined timeframe
- Based on outcome, not time invested

**Produce:** Milestone table with name, definition, typical timeframe, and celebration method.

**2.2 — Progress Visibility Mechanisms**

Design how members can see their own progress AND see that others are making progress (creating solidarity, not competition).

Options:
- Progress tracking boards or threads (visual milestones publicly checked off)
- "Win" posts — low-friction ways to share a result or breakthrough
- Regular "where are you?" check-ins (not performance review — solidarity and routing)
- Member spotlight for milestone completions

**Produce:** 2-3 progress visibility mechanisms with format and frequency.

**Phase 3: Accountability Mechanisms**

Design gentle social accountability that increases follow-through without creating shame.

Characteristics of effective away-market accountability:
- Progress-focused, not activity-focused ("Did you try [X]?" not "Did you do your homework?")
- Opt-in, but clearly valued and socially reinforced
- Creates a commitment paired with a check-in — not just monitoring
- Normalizes setbacks without making them the default conversation

**Produce:** 2-3 accountability structures with opt-in mechanism, commitment format, and check-in cadence.

**Phase 4: Milestone Celebration**

Design how the community marks genuine progress. In away markets, celebration is about validation, not identity elevation.

For each major milestone:
- What the celebration looks like (public acknowledgment, group recognition, certificate)
- Who delivers it (leader, peer group, automated)
- What the member receives

**Produce:** Celebration protocol for each of the 4-6 milestones defined in Phase 2.

**Phase 5: Retention Mechanics (Away Version)**

In away markets, retention is driven by results and support continuity — not belonging.

**5.1 — The Results-Retention Loop**

Design the mechanism that connects visible results to renewed commitment to the community:
- How does member progress become visible to the wider group? (Creates social proof that the program works)
- How does social proof of results reduce churn for members who haven't yet hit their milestone?

**5.2 — Support Continuity Events**

Design recurring events that maintain the support relationship:

| Event | Frequency | Format | Community role |
|-------|-----------|--------|---------------|
| [Name] | Weekly/Monthly | Live/Async | Accountability/Problem-solving/Celebration |

**Produce:** A recurring events calendar covering minimum 1 weekly and 2 monthly recurring events.

**Phase 6: Membership Economics (Away Version)**

In away markets, membership economics are driven by time-to-result and support intensity:

- Entry: Access to the core solution + basic community support
- Full access: Core + accountability structures + cohort membership
- Premium: Core + full accountability + direct expert access

**Produce:** 2-3 tier architecture with name (functional, not identity-based), price range, inclusions, and the result milestone each tier is designed to reach.

**Phase 7: Launch Architecture (Away Version)**

**7.1 — Early Adopter Cohort**

In away markets, the founding cohort is the first group of people with the problem who commit to the solution together. Design:
- Criteria for the early adopter cohort (disposition, not just demographics — motivated, willing to share results)
- What they receive (early access, direct support, lower price)
- What they're asked to provide (honest feedback, result documentation, early testimonials)

**Produce:** Early Adopter Protocol with criteria, benefits, obligations, and target size.

**7.2 — Minimum Viable Community Size**

In away markets, minimum viable is the number of members needed for peer support to feel real — enough that a member asking for help gets a response within 24 hours.

**Produce:** Estimated minimum viable size with reasoning.

**Output file:** `Community-Architecture-[Market].md`

---

### AWAY-DOMINANT (60-84% Away)

**Run the full Support & Accountability Architecture above (all 7 phases) as the primary design.**

**Secondary section (appended after):**

**Tribal Layer — Mild Identity Elements for Retention**

Even in away-dominant markets, members who stay long enough begin to form an identity around the journey. Design light tribal elements that support retention without overpromising the aspiration:

**Group Name Upgrade:**
Create a name that is more identity-adjacent than purely functional. Rules:
- Still accessible to people who haven't solved the problem (not an aspirational label they can't yet claim)
- Functional first, but slightly identity-claiming ("The [Result] Community" — where Result is the journey, not the arrival)
- Test: Would a member use this name to describe themselves to someone outside the community?

**Shared Vocabulary (4-6 terms):**
Identify insider language that signals belonging without overpromising transformation. These are terms for shared experiences in the journey — not advanced practitioner labels.

**One Ritual:**
Design one community ritual that creates shared experience and mild identity reinforcement. Examples:
- A weekly "progress post" format with a specific structure members recognize
- A naming ceremony for hitting a key milestone
- A signature phrase or question the community uses

**Produce:** Group name, 4-6 vocabulary terms, and one ritual — each with its retention function.

---

### TRUE HYBRID (45-55% each)

**Build both layers fully. Neither is abbreviated. The integration section is mandatory.**

**Part A: Support Layer (Away)**

Complete all components for the Support & Accountability Architecture. Members who are primarily escaping a problem need:
- Solidarity framing
- Peer support structure
- Progress tracking and milestone definitions
- Accountability mechanisms
- Milestone celebrations
- Results-retention loop

**Part B: Tribal Layer (Toward)**

Complete all components for the Tribal Identity Architecture below (same as Pure Toward). Members who are moving toward identity, mastery, and belonging need:
- Group name that claims an identity
- Tribal vocabulary
- Shared beliefs
- Shared rituals
- Mimetic desire flywheel
- Progression visibility
- Contribution pathways

**Part C: The Dual Architecture Integration**

This is the design work unique to hybrid markets. Both layers must coexist without creating dissonance.

**Integration principles:**

1. **Separate entry points, unified community.** A member who joins to escape a problem and a member who joins to become a practitioner should both find what they need — without the community forcing them to be something they're not yet.

2. **The community name must work for both motivations.** In hybrid markets, the community name should be identity-adjacent but not identity-demanding. It should be a name someone can claim whether they're in the struggle or in the aspiration.
   - Test 1 (away): "Would someone who hasn't solved the problem yet feel they belong in a group with this name?"
   - Test 2 (toward): "Would someone who has solved the problem and is now pursuing deeper mastery feel proud to be in a group with this name?"

3. **Progression visibility must not create shame.** In pure toward markets, showing advanced members creates aspiration. In hybrid markets, showing advanced members can create shame for those still in the escape phase. Design visibility layers so members at different stages see different things.

4. **Accountability and aspiration can amplify each other.** The support structure (away layer) and the progression architecture (toward layer) are not in conflict — they often accelerate the same journey. A member who gets accountability support AND sees a clear progression ladder ahead of them moves faster than one who gets either alone.

**Dual Architecture deliverables:**

**Community Name Options (test both):**
- Primary recommendation: [Name that passes both tests]
- Why it works for the away cohort
- Why it works for the toward cohort

**The Solidarity-Aspiration Stack:**
Map how the two layers interact across the member journey:
- New member (away-oriented): What layer do they enter? What do they experience first? How do they transition toward the aspiration layer as they progress?
- New member (toward-oriented): What layer do they enter? What do they experience first? How do they encounter the support layer?
- Shared touchpoints: What community events and rituals serve both motivations simultaneously?

**The Flywheel that Works in Both Directions:**
In toward markets, the flywheel runs: member produces output → shares publicly → creates desire in non-members. In hybrid markets, members who share results (escape journey) AND members who share work (aspiration journey) both fuel the flywheel — but through different mechanisms. Design both explicitly:
- Away flywheel: Member shares result (before/after, milestone reached) → creates proof-of-possibility → non-members investigate → join
- Toward flywheel: Member shares output (creation, skill demonstration) → creates aspiration → non-members want what they see → join

**Produce:** Community Name (with dual-test rationale), Solidarity-Aspiration Stack, and the dual flywheel design.

**Output file:** `Community-Architecture-[Market].md` (all three parts)

---

### TOWARD-DOMINANT (60-84% Toward)

**Run the full Tribal Identity Architecture below (all 7 phases) as the primary design.**

**Secondary section (brief, appended after):**

**Support Layer — Light Accountability for the Toward Journey**

Even in toward-dominant markets, members face hard moments (plateaus, The Dip, creative blocks). Design a light support layer that addresses these without shifting the community's primary register from aspiration to struggle:

- **One accountability structure** (opt-in, aspiration-framed: "What are you working toward this week?" not "Did you do your practice?")
- **One peer support mechanism** for members at The Dip (without naming it as a struggle — framed as "deep work partners" or "committed practitioner pairs")
- **One milestone that bridges both** — a community celebration that honors both results and identity claims simultaneously

**Produce:** One accountability structure, one peer support mechanism, and one bridging milestone ritual.

---

### PURE TOWARD (85%+ Toward)

Run the complete Tribal Identity Architecture. Nothing is abbreviated.

---

## TRIBAL IDENTITY ARCHITECTURE (for Toward and Toward-Dominant)

### Phase 1: Tribal Identity Design

**1.1 — The Group Name**

Determine the tribal identity label. Rules:
- It must be a noun phrase the member uses to describe themselves, not the program: "I'm an Urban Sketcher" not "I'm in Ian's Urban Sketching Mastery"
- It should be claimable at the beginner level — the identity is available from day one, not earned only by advanced members
- It should travel outside the community — members use this in bio lines, conversation, and social profiles
- It may already exist in the market (identify it) or need to be coined (create it)
- Test: "Would someone say this out loud at a party when asked what they do for fun?"

**Produce:** Primary tribal identity name, 2-3 alternatives, rationale for the chosen name.

**1.2 — The Tribal Vocabulary**

Identify or create insider language that signals belonging and separates members from outsiders.

Categories:
- **Activity terms** — what members call the things they do
- **Progression terms** — what members call the stages of advancement
- **Tools and methods** — named techniques or approaches unique to this community
- **Insider references** — recurring references, language, or shorthand only members know

**Produce:** Tribal Vocabulary table with 8-15 terms, definitions, and function (belonging signal / progression marker / activity label / insider reference).

**1.3 — The Shared Beliefs**

Identify the 3-5 beliefs that unite all members — beliefs outsiders don't hold, that differentiate this tribe and make belonging feel exclusive and meaningful.

Rules:
- These are beliefs, not facts — articles of faith the tribe holds
- They should be contestable — if everyone agrees, they're not beliefs, they're conventions
- They should make members feel slightly different from those who don't hold them

Examples for urban sketching: "Drawing from life is more alive than photography." / "The goal is presence, not perfection." / "The city is always your studio."

**Produce:** 3-5 core tribal beliefs, each with a one-sentence statement and explanation of its cohesion function.

**1.4 — The Shared Rituals**

Identify what members DO together that reinforces the identity. Rituals are repeated actions with community meaning beyond their function.

Categories:
- **Regular group activities** (sketch walks, jam sessions, group practice challenges)
- **Celebration rituals** (what happens when a member hits a milestone)
- **Onboarding rituals** (what new members do first that signals they've joined)
- **Recognition rituals** (how members publicly acknowledge each other's work)

**Produce:** 4-6 core rituals with description, frequency, and identity-reinforcement function.

**1.5 — The Social Signal**

Define what membership signals to the outside world.

**Produce:** A 2-3 sentence social signal statement describing what outsiders conclude about a member when they hear the tribal identity.

---

### Phase 2: Mimetic Desire Flywheel Design

**2.1 — The Mimetic Chain**

Map the complete causal chain for this specific market:

```
[Member creates output]
       ↓
[Member shares output publicly]
       ↓
[Non-member sees output and feels desire]
       ↓
[Non-member investigates the source]
       ↓
[Non-member encounters the community]
       ↓
[Non-member joins]
       ↓
[New member creates output]
       ↓ (cycle repeats)
```

For this market, specify at each node:
- What is the "output" members create? (The shareable artifact)
- What platform do they share it on?
- What desire does it trigger? (The specific aspiration the non-member feels)
- What is the bridge from "I want that" to "I can do that"? (The identity permission moment)

**Produce:** A completed mimetic chain diagram with market-specific details at each node.

**2.2 — The Sharing Mechanism**

Design the structural mechanism that makes member sharing automatic. Don't assume members will share on their own.

Options to consider:
- Community challenges with public output requirements
- Member showcase features (spotlight, gallery, "share your work" threads)
- Social-native outputs (designed to be screenshot-ready, share-ready)
- Cross-posting incentives or prompts built into the experience
- "Show your work" norms established from day one

**Produce:** 3-5 sharing mechanisms with description, trigger, and platform.

**2.3 — The Aspirational Anchors**

Identify the types of advanced members whose work creates "I want that" in beginners.

For each aspirational anchor type:
- What do they produce that creates desire?
- How visible are they inside the community?
- How visible are they outside the community?
- Are they accessible to beginners? (Too elevated = intimidation, not aspiration)

**Produce:** Description of 2-3 aspirational anchor types and how their visibility is engineered.

**2.4 — Progression Visibility Architecture**

Design how members at each stage can see what's possible at the next stage. Visibility must be:
- Proximate (the next stage, not 10 stages ahead)
- Credible (achieved by people who started where they are)
- Specific (concrete output, not vague "improvement")

**Produce:** A progression visibility map showing what each level sees, from whom, and through what mechanism.

---

### Phase 3: Progression Architecture

**3.1 — The Progression Ladder**

Define 4 levels using identity-based names (not ordinal ranks):

| Level | Name | Definition | What They Can Do | What They're Working Toward |
|-------|------|------------|-----------------|----------------------------|
| Beginner | [Identity name] | [Who this is] | [What they can produce] | [Next level milestone] |
| Intermediate | [Identity name] | [Who this is] | [What they can produce] | [Next level milestone] |
| Advanced | [Identity name] | [Who this is] | [What they can produce] | [Next level milestone] |
| Practitioner | [Identity name] | [Who this is] | [What they can produce] | [Identity they claim] |

Names should be aspirational — members want to reach the next level name. Names should connect to the tribal vocabulary from Phase 1.

**3.2 — Milestone Definitions**

For each transition between levels, define the specific observable milestone:
- Concrete (not "feels more confident")
- Achievable within a defined timeframe
- Based on output, not hours invested

**Produce:** 3 transition milestones (Beginner→Intermediate, Intermediate→Advanced, Advanced→Practitioner) with specific definitions.

**3.3 — Celebration Architecture**

Design how each transition is celebrated. Public celebration creates identity commitment.

For each transition:
- What is the celebration ritual?
- Who acknowledges it? (Community, leader, peers?)
- What is the public artifact? (Badge, post, feature, certificate?)
- What does the celebrated member receive?

**Produce:** Celebration protocol for each of the 3 transitions.

**3.4 — The First Win Experience**

Design the path to the earliest moment a new member can produce something worth sharing. This is the most important design decision in onboarding.

Requirements:
- Achievable within the first session or first week
- Produces an output that is genuinely shareable (not "good for a beginner" — actually good)
- Connects to the tribal identity (the output signals membership)
- Creates a "I didn't know I could do this" moment

**Produce:** A First Win Protocol — the specific sequence from joining to first shareable output, with estimated time and specific activity at each step.

---

### Phase 4: Retention Mechanics

**4.1 — Recurring Rituals Calendar**

Design standing weekly and monthly community events that create habit and expected participation.

For each ritual:
- Name and description
- Frequency
- Format (live / async / challenge / showcase)
- Community role (engagement / accountability / celebration / skill-building)
- Estimated participation rate

**Produce:** A recurring rituals calendar covering minimum 1 weekly and 2 monthly recurring events.

**4.2 — Challenge Structures**

Design time-boxed community events that spike engagement, create shared experience, and generate shareable output for the flywheel.

For each challenge:
- Name and theme
- Duration
- Input (what members commit to)
- Output (what they produce)
- Sharing mechanism
- Reward or recognition

**Produce:** 2-3 challenge archetypes. Minimum one 7-day and one 30-day format.

**4.3 — Contribution Pathways**

Design how members graduate from consumers to contributors to leaders.

| Stage | What Contribution Looks Like | Transition Trigger | Recognition |
|-------|-----------------------------|--------------------|-------------|
| Consumer | Takes from community | — | Welcome |
| Contributor | Answers questions, shares work, gives feedback | [Specific trigger] | [Public recognition] |
| Leader | Runs challenges, mentors beginners, moderates | [Specific trigger] | [Identity elevation] |

**Produce:** A Contribution Pathway with 3 stages, transition triggers, and recognition for each.

**4.4 — Accountability Structures**

Design aspiration-focused accountability that increases follow-through without shame.

Characteristics:
- "What are you working toward?" not "Did you do your homework?"
- Peer-based, not authority-based
- Optional but clearly valued
- Produces something (a commitment, a plan, a check-in)

**Produce:** 2-3 accountability structures with description, opt-in mechanism, and follow-through rate estimate.

**4.5 — Sticky Content Architecture**

Define recurring content types that keep members returning — community-native content that only exists inside the membership.

Categories:
- Social content — member spotlights, community news, behind-the-scenes
- Member showcase — curated member work that creates aspiration
- Live event content — calls, Q&As, group sessions that can't be replayed the same way
- Inside-knowledge content — content that only makes sense if you're in the community

**Produce:** A sticky content calendar with 4-6 recurring content types, frequency, and format.

---

### Phase 5: Membership Economics

**5.1 — Course vs. Community Model Comparison**

| Dimension | Course Model | Community Model | This Market |
|-----------|-------------|-----------------|-------------|
| Revenue type | One-time | Recurring | [Assessment] |
| LTV driver | Upsells | Retention | [Assessment] |
| Churn trigger | Completion | Boredom or isolation | [Assessment] |
| Content burden | Front-loaded | Distributed | [Assessment] |
| Referral mechanism | Manual | Mimetic | [Assessment] |
| Identity investment | Low | High | [Assessment] |
| Acquisition cost | High per unit | Decreasing over time | [Assessment] |

**5.2 — Membership Pricing Architecture**

Design 2-3 membership tiers based on identity depth, not just content access.

For each tier:
- Name (identity-based, not feature-based)
- Price point (monthly / annual)
- What it includes
- What identity it signals
- Who it's designed for
- Upgrade trigger to next tier

Rules:
- Entry tier: priced for low commitment — crossing the identity threshold, not maximizing initial revenue
- Mid tier: the primary recurring revenue engine — design this one with the most care
- Top tier: feels like a different category, not just more content

**Produce:** 3-tier membership architecture table.

**5.3 — Upgrade Triggers**

For each tier transition, design the specific experience that creates desire for the next tier. Upgrades should feel like identity claims, not purchases.

**Produce:** 2 upgrade trigger designs (Entry→Mid and Mid→Top) with the specific moment, mechanism, and copy direction.

**5.4 — Referral Mechanics**

Design the organic referral system. In toward markets, best referrals come from members sharing their work publicly (the flywheel from Phase 2) — not from formal affiliate programs. But structured mechanics amplify the natural mimetic effect:

- Member-get-member incentives
- Share prompts at peak emotional moments (immediately after a win, after a celebration)
- Community-native content designed to be shared publicly

**Produce:** 2-3 referral mechanics with trigger, incentive, and estimated referral rate.

**5.5 — LTV Calculation Framework**

```
COURSE BUYER LTV:
  Average purchase price: $[X]
  Upsell rate: [Y]%
  Average upsell value: $[Z]
  LTV = $[X] + ($[Z] × [Y]%) = $[total]

COMMUNITY MEMBER LTV:
  Monthly membership: $[X]/month
  Average retention: [N] months
  Upgrade rate to higher tier: [Y]%
  Average higher tier revenue: $[Z]/month
  Additional upgrade value: $[W]
  LTV = ($[X] × [N]) + ([Y]% × $[Z] × [N]) + [W] = $[total]
```

Fill in estimated values based on the market and pricing architecture from Phase 5.2.

**Produce:** Completed LTV comparison showing the economic case for the community model.

---

### Phase 6: Value Ladder Integration

**6.1 — Value Ladder Placement**

```
FREE: [Lead magnet / free content / first win preview]
       ↓
ENTRY: [Entry-level course or entry membership tier] — $[X]/month
       ↓
CORE: [Full community membership] — $[X]/month
       ↓
PREMIUM: [High-touch experiences: coaching, intensives, events] — $[X]
       ↓
ELITE: [Direct access, mastermind, inner circle] — $[X]
```

**6.2 — Community Conversion Effect**

Describe how community membership changes conversion rates for premium offers:
- Members who belong have higher trust
- Members who have advanced through the progression ladder have evidence of their own capability
- Members who have contributed have social stakes

**Produce:** 3 specific ways community membership improves conversion for the premium tier(s).

**6.3 — The Community Funnel**

Design the complete path from non-member to full membership:
1. Free taste — what non-members can experience that creates desire
2. Entry point — the lowest-friction way to join (minimal commitment that crosses the identity threshold)
3. Full membership — what changes at full membership
4. Premium experiences — what community members can access beyond membership

**Produce:** 4-stage community funnel with description and conversion mechanism at each stage.

---

### Phase 7: Launch Architecture

**7.1 — The Founding Member Strategy**

A new community needs a founding cohort that creates social proof and cultural DNA before general launch.

**Produce:**
- Ideal founding member criteria (disposition: creators, connectors, givers — not just demographics)
- Recruitment method (application / invitation / existing audience segment)
- What founding members receive (founding member identity, price lock, naming rights, direct access)
- What they're obligated to provide (active participation, feedback, content creation)
- Target founding cohort size and timeline

**7.2 — Minimum Viable Community Size**

Determine the minimum active member count for the community to feel self-sustaining — where new members arrive to activity, not an empty room.

Factors:
- Enough members to ensure daily activity without the leader generating it all
- Enough progression spread (some at each level) for the progression ladder to be visible
- Enough activity that new members see others doing the thing within their first hour

**Produce:** Estimated minimum viable size with reasoning, and a plan for reaching it before general launch.

**7.3 — Content Strategy for the Early Days**

Before members generate content, the leader must. Design the content strategy for the first 90 days:

Types of early-stage leader content:
- Seed questions (prompts that create thread activity)
- Member spotlights (aggressive early win spotlighting)
- Live presence (warmth that no recorded content replaces)
- Transparency content (showing the building process creates investment)

**Produce:** A 90-day content calendar structure (recurring types and frequencies, not specific posts) for the pre-momentum phase.

**7.4 — Manufacturing the "Thriving Community" Signal**

New members judge community health in the first 5 minutes. Design specific signals that communicate vitality:

- Welcome automation that simulates personal attention at scale
- First-post prompts that guarantee immediate response
- Activity visible to new members on first login
- Prominent display of early member wins

**Produce:** 4-6 "thriving community" signals with the specific mechanism for each.

---

## OUTPUT SPECIFICATION

**Output file naming:**
- Pure Away: `Community-Architecture-[Market].md` (with away flag and support architecture)
- Away-Dominant: `Community-Architecture-[Market].md` (support primary + mild tribal secondary)
- True Hybrid: `Community-Architecture-[Market].md` (both layers + integration section)
- Toward-Dominant: `Community-Architecture-[Market].md` (tribal primary + light support secondary)
- Pure Toward: `Community-Architecture-[Market].md` (full tribal identity architecture)

**Every file begins with the Spectrum Badge.**

**Target lengths:**
- Pure Away (if community built): 1,500-2,500 words
- Away-Dominant: 2,000-3,000 words
- True Hybrid: 4,000-6,000 words (both full architectures + integration)
- Toward-Dominant: 3,000-4,500 words
- Pure Toward: 3,000-5,000 words

**Language rules:**
- Away sections: solidarity language, not aspiration language; validating, not pathologizing
- Toward sections: tribe language, not customer language; members, not buyers; belonging, not enrollment; advancement, not completion
- True Hybrid: the tone shifts between sections, with an explicit integration layer that holds both

---

## QUALITY GATE

**For all zones:**
- [ ] Spectrum Badge is the first element in the output
- [ ] Architecture matches the zone
- [ ] Pure away flag is present if the zone is Pure Away

**For support architecture (away-heavy):**
- [ ] Community is framed as support infrastructure, not tribal identity
- [ ] Community name is functional, not identity-claiming
- [ ] Milestone definitions are concrete and observable
- [ ] Accountability structures are aspiration-focused, not shame-based
- [ ] Results-retention loop is explicitly designed (not assumed)

**For tribal architecture (toward-heavy):**
- [ ] Tribal identity name passes the "I'd say this at a party" test
- [ ] Tribal vocabulary table contains minimum 8 terms with functions specified
- [ ] Mimetic chain diagram is market-specific (not generic)
- [ ] First Win Protocol specifies a concrete output achievable in first session or first week
- [ ] Progression Ladder uses identity-based names, not ordinal ranks
- [ ] LTV comparison contains estimated numbers, not placeholders
- [ ] Launch Architecture specifies minimum viable community size with reasoning
- [ ] No language frames community as content delivery infrastructure

**For True Hybrid only:**
- [ ] Both layers run in full — neither abbreviated
- [ ] Community name is tested against both Away and Toward tests
- [ ] The Solidarity-Aspiration Stack explicitly maps how the two layers interact
- [ ] The dual flywheel is designed (not just one direction)
- [ ] The integration section does not force either layer to abandon its core function

---

## STRATEGIC IMPLICATIONS SECTION (required in all outputs)

**For away-heavy outputs, answer:**
1. Is community recommended as a core offer component, or optional support infrastructure? Why?
2. What is the single most important support mechanism — the one thing, if absent, that most increases churn?
3. What milestone definition most reliably predicts a member who stays vs. leaves?
4. What is the community name, and why is it functional rather than tribal?
5. What is the LTV difference between "member with community support" vs. "member without"?

**For toward-heavy outputs, answer:**
1. What is the single tribal identity name this community should adopt?
2. What is the primary mimetic mechanism — the one output that, shared publicly, does the most recruiting?
3. What is the First Win — the specific output new members must produce in their first session?
4. What is the entry-tier price and identity position?
5. What is the minimum viable community size and how long to reach it?
6. What is the single highest-leverage retention mechanic — the one recurring event that, if removed, would spike cancellations?

**For True Hybrid outputs, add:**
7. How does the community name pass both the away and toward identity tests?
8. What shared touchpoints serve both cohorts simultaneously?
9. Where in the member journey does someone typically transition from primarily away-motivated to primarily toward-motivated — and how does the community support that transition?

---

## HOW THIS CONNECTS DOWNSTREAM

**This community architecture becomes the operating brief for:**
- **Platform selection** — choosing Skool, Circle, Discord, Slack, Facebook Group based on the sharing requirements and community layer emphasis
- **Content strategy** — recurring calendar, member spotlight system, challenge calendar
- **Copy direction** — all membership sales copy uses the identity language (toward) or solidarity language (away) established here
- **Onboarding design** — the First Win Protocol (toward) or first milestone path (away) becomes the new member experience brief
- **Pricing and packaging** — tier names, prices, and upgrade triggers taken directly from Phase 5
- **Launch planning** — Founding Member Protocol and minimum viable size become the launch brief
- **toward-usp-generator** — tribal identity and mimetic mechanism inform USP language for the community offer
- **zp-pattern-analyzer** — Progression Landscape Map output feeds directly into community design; Failure Archaeology Report informs shared struggle architecture
