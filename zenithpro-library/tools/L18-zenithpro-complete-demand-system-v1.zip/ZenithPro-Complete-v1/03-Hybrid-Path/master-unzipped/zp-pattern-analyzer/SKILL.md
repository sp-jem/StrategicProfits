---
name: zp-pattern-analyzer
description: "Unified ZenithPro pattern analysis. Away-heavy: failure pattern forensics — why the market perpetually fails despite solutions, the hidden structural pattern behind all attempts, the real villain. Toward-heavy: progression pattern analysis — where practitioners plateau, what makes casual participants go deeper vs. quit, the identity adoption timeline. Hybrid: both patterns active simultaneously — a market where people are failing AND trying to progress, where failure archaeology and progression mapping both reveal necessary intelligence. Reads market-context.md automatically. Part of ZenithPro Unified System."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/zp-pattern-analyzer [market or avatar description]"
  called_by: [user, toward-demand-architect]
  outputs_to: [project folder]
  reads: [market-context.md]
---

# ZP Pattern Analyzer

Unified pattern analysis for the ZenithPro system. Auto-calibrates to the market's motivation spectrum — running failure pattern forensics in away-heavy markets, progression pattern analysis in toward-heavy markets, and the complete dual architecture when both drives are active.

---

## STEP 0: READ MARKET-CONTEXT.MD

Before any analysis, locate and read market-context.md in the current project folder.

Extract:
- **Away%** — avoidance motivation intensity
- **Toward%** — approach motivation intensity
- **Zone** — Pure Away / Away-Dominant / True Hybrid / Toward-Dominant / Pure Toward

**Every output begins with the Spectrum Badge:**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MARKET: [name] | [X]% Away / [Y]% Toward | [Zone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

If market-context.md is not found, ask the user for Away%, Toward%, and Zone before proceeding.

---

## LAYER 1: INVARIANTS

1. **The spectrum determines the analysis architecture — not the other way around.** Run what the market demands, not what is most familiar.
2. **Failure patterns must explain ALL failures, not just some.** If the identified pattern doesn't account for why approach A, B, and C all failed, the real pattern hasn't been found yet.
3. **Progression analysis is NOT failure analysis.** Plateaus and quit patterns describe a journey with hard moments — not a record of incompetence.
4. **In True Hybrid, both analyses run in full.** There is no shortcut. The synthesis section then identifies what single structural dynamic appears in both directions.
5. **False enemy diagnosis must be specific.** "They think their enemy is X but it's actually Y" — both X and Y must be named precisely.
6. **Identity adoption has a timeline and accelerants.** "Becoming a practitioner" is a specific behavioral shift — map what triggers it and what shortens the path.
7. **No consulting-speak.** Every insight must be expressed in language the prospect would recognize as true about themselves.
8. **Save all outputs to files.** Never deliver analysis only in chat.

---

## PURPOSE

Answers the foundational question that determines what intelligence is most needed before copy, positioning, or product design:

**In away-heavy markets:**
> "Why does this market perpetually fail despite deploying solution after solution — and what is the hidden structural pattern orchestrating all their failures?"

**In toward-heavy markets:**
> "What does the journey from 'curious about this' to 'this is part of who I am' actually look like — and where does it break down?"

**In hybrid markets:**
> "What is the single structural dynamic that explains BOTH why people fail AND where committed practitioners plateau?"

**Output use:**
- Failure Archaeology Report feeds core-concept-generator and belief-gap-analyzer
- Progression Landscape Map feeds permission-concept-generator, identity-belief-gap-analyzer, toward-usp-generator, and zp-community
- Hybrid synthesis feeds both pipelines simultaneously

---

## INPUTS

Gather from the user before running (beyond market-context.md):

1. **Market/avatar description** — who they are, what they're trying to accomplish or become
2. **Known patterns** — any observations the user already has about why people fail or where they plateau (optional; the skill will add more)
3. **Existing research** — psychographic data, testimonials, reviews, community posts, forum language (optional but significantly improves specificity)
4. **Avatar profiles** — from avatar-excavation or aspiration-avatar-excavation if already run
5. **Output folder path** — where to save the completed report

---

## ZONE-CALIBRATED EXECUTION

### PURE AWAY (85%+ Away)

Run the complete Failure Pattern Forensics methodology. Nothing is abbreviated.

**Output: Failure Archaeology Report**

#### Part 1: The Graveyard Archaeological Inventory

Chronicle 10-20 specific interventions this market has deployed that should have catalyzed success but instead collapsed.

For each intervention, forensically document:
- What they anticipated would happen
- What actually manifested
- How long they persisted with implementation
- Why they believe it collapsed
- What they pivoted to subsequently

**Critical question:** Is there a pattern in WHAT they tried? Do all the approaches share a common assumption that turned out to be wrong?

#### Part 2: The Assumption Forensic Audit

Excavate and catalogue 10-15 fundamental assumptions this market harbors that are systematically false.

For each false assumption:
- State the assumption ("What everyone knows")
- State the reality (what's actually true)
- Explain why the assumption persists (feels logical, experts teach it, worked before but conditions changed, etc.)
- Identify the damage it causes (how believing this guarantees failure)

Categories to investigate:
- "What everyone knows" that contradicts reality
- Common advice that actively sabotages progress
- Industry "best practices" that undermine their specific context
- Logical approaches that generate illogical outcomes
- "Obvious" solutions that amplify existing problems

#### Part 3: The Success Anomaly Analysis

Isolate and dissect 5-10 cases where someone in this market transcended the pattern.

For each success anomaly:
- What did they do differently?
- What conventional wisdom did they deliberately ignore?
- At what operational level were they thinking?
- What invisible advantage did they leverage?
- What critical distinction did they understand that others didn't?

**Critical question:** Is there a pattern in how outliers succeed — a common understanding the mass market lacks?

#### Part 4: The Multi-Level Triangulation

Map where this market operates versus where success demands operating.

**Surface Level (What they fixate on):** Visible activities, tactics, metrics they monitor
**Hidden Level (What actually catalyzes outcomes):** Invisible factors, strategic elements, real drivers

**The Level Gap:**
- They navigate at: [Diagnosis]
- Success demands operating at: [Requirement]
- The invisible gap: [What they cannot perceive]
- Why this gap is hard to see: [The reason the wrong level feels like the right level]

#### Part 5: The Paradox Pattern Recognition

Crystallize 5-10 paradoxes embedded in this market:

- **The Strength-Weakness Paradox:** What specific strength metamorphoses into a weakness at the next level?
- **The Solution-Problem Paradox:** What solution creates a new problem worse than the original?
- **The Effort-Results Paradox:** How does intensified effort deteriorate results in this context?
- **The Expertise-Blindness Paradox:** What expertise in X prevents mastery in Y?
- **The Success-Ceiling Paradox:** What elevated them to here that now sabotages the next level?

For each paradox: state it precisely, explain why it's invisible from inside, show how recognizing it creates an immediate reframe.

#### Part 6: The False Enemy Diagnosis

**What they believe they're combating:** [The stated problem]
**What they're actually confronting:** [The real structural issue]
**How their current approach fortifies the real enemy:** [Why fighting the false enemy makes the real enemy stronger]
**Why they cannot discern the authentic threat:** [The mechanism that keeps the real enemy invisible]

#### Hidden Distinction Candidates

5 simple A vs. B distinctions that, if understood, would explain why everything else has failed.

A strong distinction:
- Is simple to state (one sentence)
- Is surprising (not what they currently believe)
- Explains multiple past failures simultaneously
- Makes the solution obvious once accepted
- Cannot be argued with (it's demonstrably true)

---

### AWAY-DOMINANT (60-84% Away)

**Primary analysis:** Full failure pattern forensics — all six parts above.

**Secondary section (after the main report):**

**Progression Plateau Map — Where the Few Who Succeed Still Get Stuck**

Even in away-dominant markets, a subset of people do improve. Where do they plateau?

For each plateau identified (minimum 2):
- Where in the skill or improvement arc it occurs
- What it feels and looks like from the inside
- Why it is structurally inevitable at this point
- The Plateau Paradox — how the plateau is caused by something good, not something bad

**Output:** Failure Archaeology Report (primary) + Progression Plateau Map (secondary section)

---

### TRUE HYBRID (45-55% each)

**Run both analyses in full. Neither is abbreviated. The synthesis section is mandatory.**

**Part A — Full Failure Pattern Forensics**

Complete all six parts: Graveyard Inventory, Assumption Audit, Success Anomaly Analysis, Multi-Level Triangulation, Paradox Pattern Recognition, False Enemy Diagnosis. Minimum requirements as specified in Pure Away section above.

**Part B — Full Progression Pattern Analysis**

Complete all seven phases: Plateau Mapping, Quit Pattern Analysis, Commitment Trigger Analysis, Identity Adoption Timeline, Environmental Analysis, Progression Ladder, Dip Analysis. Full specifications for each phase follow in the Toward section below.

**Part C — The Pattern at the Center (Synthesis)**

This is the unique intelligence that only emerges from running both analyses simultaneously.

Answer: **What single structural dynamic explains BOTH why people fail AND where committed practitioners plateau?**

The same constraint often appears in two directions:
- The failure pattern shows people blocked from escaping a pain
- The progression plateau shows committed practitioners blocked from reaching the next level
- Both blockages frequently trace to the same root: the same false assumption, the same level gap, the same missing internal permission

**Synthesis deliverable:**

1. **The Central Constraint** — name the single dynamic operating in both directions (one precise paragraph)
2. **How it appears as failure** — for the away-oriented portion of the market
3. **How it appears as plateau** — for the toward-oriented portion of the market
4. **The double-leverage intervention** — one thing that, if changed, would simultaneously address both the failure archaeology and the progression plateau
5. **Copy direction** — how this synthesis shapes messaging that resonates with BOTH market motivations without being incoherent

**Output:** Failure Archaeology Report (Part A) + Progression Landscape Map (Part B) + The Pattern at the Center synthesis (Part C)

---

### TOWARD-DOMINANT (60-84% Toward)

**Primary analysis:** Full progression pattern analysis — all seven phases below.

**Secondary section (brief, at the end):**

**Failure Context — What Typically Brought Them to This Market**

Even in toward-dominant markets, people arrive from somewhere. Brief failure or frustration often precedes approach motivation.

- What prior context, frustration, or incomplete attempt typically precedes someone entering this market with approach motivation?
- What is the "enough of that, I want this instead" moment that flipped them from avoidance to aspiration?
- How does understanding this context shape onboarding language and early-stage credibility?

**Output:** Progression Landscape Map (primary) + Failure Context (secondary section)

---

### PURE TOWARD (85%+ Toward)

Run the complete Progression Pattern Analysis methodology. Nothing is abbreviated.

**Output: Progression Landscape Map**

#### Phase 1: Plateau Mapping

Map where practitioners consistently lose momentum, get stuck, or stall without quitting entirely.

A plateau is not a quit point. It is where progress feels invisible, energy drops, and the gap between "where I am" and "who I want to be" feels widest — but the person has not yet decided to leave.

For each significant plateau, document:

**The Plateau Profile:**
- Where in the learning arc it occurs (early: weeks 1-4; middle: months 2-6; advanced: ongoing)
- What it looks and feels like from the inside (specific internal language)
- What it looks like behaviorally (buying more materials but not practicing, watching tutorials instead of doing, long gaps between sessions)
- Why it is structurally inevitable at this point in the skill arc — not a character flaw, a natural feature of skill development
- What percentage of practitioners hit this plateau vs. skip through it

**The Plateau Paradox:**
Every significant plateau contains an internal contradiction — it is caused by something good, not something bad. Identify the specific paradox for each plateau. This is the raw material for Permission Concepts.

**Minimum:** 3 distinct plateaus, each specific enough that a practitioner would say "that is EXACTLY what happened to me."

#### Phase 2: Quit Pattern Analysis

Identify 3-5 most common reasons practitioners abandon the practice after starting.

**Critical distinction:** Quit patterns in approach markets are almost never about capability. They are almost always about identity permission, environmental mismatch, or community absence.

**Stated vs. Actual Reasons Matrix:**

| Quit Type | What They Say | What's Actually Happening | Prevention |
|-----------|--------------|--------------------------|------------|
| [Name] | [Stated reason] | [Real structural issue] | [Actual intervention] |

**The Quit-Prevention Insight:** For each pattern — what would a product/community need to provide to prevent this quit at the identity and environment level (not the skill level)?

Language rule: Frame quit patterns as inflection points where one path was available and another was taken — not as failures.

#### Phase 3: Commitment Trigger Analysis

Identify specific events, experiences, and moments that cause people to cross from casual to committed.

A commitment trigger is not a decision. It is a specific experience that makes the identity claim feel real and available.

**The Commitment Trigger Taxonomy:**

**1. The Visible Result Trigger** — specific work they produce that surprises them with its quality; someone else responds to it as if they were a practitioner
- What does this look like in this market?
- At what skill level does it typically occur?
- What conditions increase the likelihood of this trigger firing?

**2. The Community Belonging Trigger** — social moment where they feel seen as one of the practitioners, not just welcomed
- What specific interaction creates this?
- What community structures accelerate it?

**3. The Identity Claim Trigger** — first time they describe themselves using the practitioner identity to someone outside the practice, unprompted
- What provokes this?
- What makes it feel safe vs. risky?

**4. The Investment Escalation Trigger** — they spend money on something only a committed practitioner would buy
- What is the investment that marks the line between dabbler and committed practitioner in this market?
- What happened just before they decided to spend it?

**5. The Teaching Trigger** — they explain or demonstrate something to someone less advanced; the act of teaching reveals how far they've come
- When does this opportunity typically arise?
- What conditions create it?

For each trigger type present in this market: rate its power, identify conditions that produce it, specify what product architecture or community structure most reliably creates conditions for it to fire.

#### Phase 4: Identity Adoption Timeline

Map the typical timeline from first contact to identity claim, and what accelerates or delays it.

**Stage-by-stage map:**
- Week 1-2: [Orientation — what is happening, what is felt]
- Month 1-3: [Early — what is happening, what threatens to derail]
- Month 3-6: [Development — first plateaus]
- Month 6-12: [Consolidation — commitment or drift]
- Beyond 12 months: [Integration — for those who stay]

For each stage: dominant emotional state, dominant doubt or fear, most common quit risk, most powerful retention factor.

**Identity Claim Acceleration Factors (5-8 specific factors):**

Examples to test against the specific market:
- Having a dedicated space or portable kit (makes the identity portable)
- Being part of a named community (precedes the personal identity claim)
- Producing work that gets a real response from a real person
- Finding a teacher whose students look like them demographically
- A specific early win in the first 2-4 sessions
- Participating in a shared event early in the journey

**Identity Claim Delay Factors:**
- Comparison to advanced practitioners without demographically similar mirrors
- Practicing in isolation without community feedback
- Framing the practice as "something I'm trying" rather than "something I do"
- Gatekeeping language from experts
- The absence of a first public moment

**Product Implication:** For each acceleration factor — can a product, program, or community create this condition deliberately? If yes, how specifically?

#### Phase 5: Environmental Analysis

Map the conditions — physical, social, temporal, psychological — that correlate with continued practice vs. drift.

**Physical Environment Factors:** What conditions support vs. undermine sustained practice? Minimum viable environment?

**Social Environment Factors:** What social conditions accelerate deepening? Create drift? Minimum social baseline that predicts continuation?

**Temporal Factors:** Minimum practice frequency for continuation? Time-of-day or week patterns? Most common life-event disruptions and what gets people back?

**Psychological Environment Factors:** What internal permission does the practitioner need? What internal voices most commonly undermine continuation? What psychological anchors do sustained practitioners report?

**The Environmental Profile of a Sustained Practitioner:**
Synthesize into: "A person who stays with this practice for 12+ months typically has [X physical], [Y social], [Z temporal], and [W internal permissions]."

This profile tells the product what it must create or reinforce.

#### Phase 6: Progression Ladder

Map how skill and identity actually develop from complete beginner to advanced practitioner in this specific domain. This is an empirical map, not a curriculum.

| Level | Name | Definition | Skill Markers | Identity Markers | What They Want Most | What Threatens Them |
|-------|------|------------|---------------|------------------|--------------------|--------------------|
| Beginner | [Identity name] | [Who this is] | [What they can/can't do] | "I'm trying [practice]" | Permission to start | Comparison, early failure |
| Developing | [Identity name] | [Who this is] | [What they can/can't do] | "I do [practice]" | Progress they can see | Plateau, isolation |
| Committed | [Identity name] | [Who this is] | [What they can/can't do] | "I'm a [practitioner]" | Refinement, community | Stagnation, life disruption |
| Advanced | [Identity name] | [Who this is] | [What they can/can't do] | "I teach [practice]" | Mastery, legacy | Identity crisis if practice changes |

**Level Transition Points:** For each transition — what specific event marks the shift (not just "they got better")? What makes the transition risky? What support is most valuable at this juncture?

#### Phase 7: Dip Analysis

Every skill has a hardest moment. Map it precisely.

**The Dip Location:**
- At what skill level does the primary Dip occur?
- At what time point (weeks/months into the practice)?
- What does it feel like from the inside?
- What does it look like behaviorally?

**The Dip Anatomy:**
- What can they do at this point? (More than beginners, but feels inadequate)
- What can they NOT do yet? (The gap that makes progress feel invisible)
- What comparison typically triggers the Dip?
- What do people tell themselves inside the Dip?

**What Gets People Through:**
- A specific social structure (accountability, community, cohort)
- A specific reframe about the Dip itself (knowing it is normal, finite)
- A specific milestone or visible result that arrives just in time
- A specific teacher or guide who normalizes the experience
- A specific environmental condition (dedicated space, protected time)

**What Makes People Quit at the Dip:**
- The specific absence that makes quitting feel like the reasonable choice
- The specific comparison that makes continuing feel futile
- The specific narrative that frames quitting as wisdom rather than retreat

**The Product Dip Design Implication:** What should a product or program do at this specific moment in the student journey to ensure the highest percentage of students make it through?

---

## OUTPUT SPECIFICATION

**Output file naming:**
- Pure Away: `Failure-Archaeology-Report-[Market].md`
- Away-Dominant: `Failure-Archaeology-Report-[Market].md` (with appended Plateau Map section)
- True Hybrid: `Pattern-Analysis-[Market].md` (all three parts)
- Toward-Dominant: `Progression-Landscape-Map-[Market].md` (with appended Failure Context section)
- Pure Toward: `Progression-Landscape-Map-[Market].md`

**Every file begins with the Spectrum Badge.**

**Target lengths:**
- Pure Away or Pure Toward: 1,500-3,000 words
- Away-Dominant or Toward-Dominant: 2,000-3,500 words
- True Hybrid: 3,500-5,500 words (both full analyses + synthesis)

**Language rules:**
- Failure Archaeology sections: can use avoidance language to describe what the market experiences — but never to pathologize
- Progression sections: NEVER use avoidance language (pain, failure, broken, struggling) unless explicitly describing what practitioners experience from their own perspective
- True Hybrid: the tone shifts between sections — failure archaeology language in Part A, progression language in Part B, unified language in Part C

---

## QUALITY GATE

**For all zones:**
- [ ] Spectrum Badge is the first element in the output
- [ ] Analysis architecture matches the zone (away methodology for away-heavy, toward methodology for toward-heavy)
- [ ] Every insight is grounded in market evidence — not assumption

**For failure forensics sections:**
- [ ] Pattern Diagnosis explains ALL the graveyard items (not just some)
- [ ] At least 10 items in Graveyard Inventory
- [ ] At least 5 False Beliefs identified (beliefs that feel true but aren't — not just problems)
- [ ] At least 3 Success Anomalies analyzed
- [ ] False Enemy Diagnosis includes WHY it's invisible
- [ ] 5 Distinction Candidates produced

**For progression sections:**
- [ ] Every plateau specific enough that a practitioner would say "that is exactly what happened to me"
- [ ] Dip Analysis identifies a specific moment, not a general difficult period
- [ ] Quit Pattern Analysis distinguishes stated reasons from actual structural reasons for each pattern
- [ ] At least 3 Commitment Triggers identified with conditions and product implications
- [ ] Identity Adoption Timeline includes both acceleration AND delay factors
- [ ] Environmental Profile specific enough to inform product and community design
- [ ] Progression Ladder identifies transition triggers, not just level descriptions

**For True Hybrid only:**
- [ ] Both analyses run in full — neither abbreviated
- [ ] The Pattern at the Center synthesis is present and identifies ONE root dynamic operating in both directions
- [ ] Double-leverage intervention is specific and actionable

---

## STRATEGIC IMPLICATIONS SECTION (required in all outputs)

**For failure archaeology outputs, answer:**
1. What is the pattern that explains all failures — stated in one sentence a prospect would recognize?
2. What is the false enemy and what is the real one?
3. What are the 3 most powerful Distinction Candidates for core-concept-generator?
4. What false beliefs map to L2/L3 belief gaps in the demand architecture?
5. What does this forensic work suggest about positioning — what must the product NOT claim to be, given the graveyard?

**For progression outputs, answer:**
1. What is the primary Dip and what does a product need to do at that moment?
2. What is the highest-leverage commitment trigger and how can a product reliably create conditions for it?
3. What environmental conditions are most predictive of going deep — and which can a product create?
4. What is the single most powerful Permission Concept this landscape suggests is needed?
5. What does the community design need to provide at the critical transition points? (Feeds zp-community directly.)

**For True Hybrid outputs, add:**
6. What is the central constraint, stated as a single concept that speaks to both market motivations?
7. What copy direction serves both the away and toward segments without being incoherent?

---

## HOW THIS CONNECTS DOWNSTREAM

**Failure Archaeology output feeds:**
- **core-concept-generator** — Distinction Candidates are the direct input
- **belief-gap-analyzer** — false beliefs become Point A beliefs to overcome
- **zp-desire-mapper** — false enemy often reveals which L2/L3 beliefs are broken
- **mimetic-market-intelligence** — the industry's shared false beliefs often come from competitors mediating the wrong desire

**Progression Landscape output feeds:**
- **permission-concept-generator** — plateau paradoxes and Dip anatomy are the primary raw material for Permission Concepts
- **identity-belief-gap-analyzer** — progression plateaus map directly to belief gaps
- **toward-usp-generator** — USP must promise to shorten or smooth the progression journey
- **zp-community** — community design must be built around the social conditions that accelerate identity adoption and buffer against the Dip

**True Hybrid synthesis feeds both pipelines simultaneously.**
