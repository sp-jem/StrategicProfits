---
name: zp-avatar
description: "Unified ZenithPro avatar excavation. Multi-dimensional forensic reconstruction of avatar segments calibrated to the motivation spectrum. Away-heavy: pain stratigraphy, shadow work (suppressed fears), somatic fear signatures, temporal trauma, relational damage. Toward-heavy: aspiration stratigraphy, identity aspiration (who they want to become), flow state mapping, life stage dynamics, community needs. Hybrid: dual-dimensional avatar capturing both who they're running FROM and who they're running TOWARD. Reads market-context.md automatically. Part of ZenithPro Unified System."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/zp-avatar [market or business]"
  called_by: [user]
  outputs_to: [project folder]
---

# ZenithPro Avatar Excavation (Unified)

Forensic psychological reconstruction of complete human psyches — spectrum-calibrated. The away version builds avatars around who they're running FROM (pain, fear, damage, failure). The toward version builds avatars around who they're running TOWARD (aspiration, identity, belonging, flow). The hybrid version does both simultaneously, producing a dual-dimensional avatar — the same person captured from both directions.

---

## STEP 0: READ MARKET CONTEXT

Before building any avatar, locate and read `market-context.md` in the current project folder.

Extract:
- **Away %** and **Toward %**
- **Zone** (Pure Away / Away-Dominant / True Hybrid / Toward-Dominant / Pure Toward)

Display the spectrum badge at the top of every output file:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MARKET: [name] | [X]% Away / [Y]% Toward | [Zone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

If `market-context.md` is not found, prompt the user:
> "I need to know this market's motivation spectrum before building avatars. What is the Away % and Toward %? Or run `/zp-market-context` first."

---

## LAYER 1: INVARIANTS

1. **Psychological complexity over clean profiles.** Real humans are contradictory. Away avatars want things they're afraid to want. Toward avatars carry wounds and doubts. Never sanitize either.
2. **Specific over general.** Not "they feel stressed" — "at 2:30pm when their energy crashes, the specific thought that runs is..." Not "they want to create" — "at 7pm when the house is quiet and she sits down with her sketchbook, the specific thought that runs is..."
3. **Shadow and aspiration are both mandatory in their respective modes.** Shadow psychology is mandatory in away mode. Identity aspiration is mandatory in toward mode. Both are mandatory in hybrid.
4. **Equal depth across avatars.** Never shortchange the 3rd or 4th avatar.
5. **Save all outputs to files.** Never deliver in chat only.
6. **Language rule:** Zero avoidance language in the skill's own voice in toward-dominant or pure toward mode. Zero aspirational inflation in pure away mode. Hybrid mode uses both languages in their respective sections.

---

## PURPOSE

These avatars are so complete that you could:
- Ghost-write their private journal for 365 days
- Predict their response to 1,000 different scenarios
- Script their internal dialogue during a crisis or a breakthrough
- Design products that feel telepathically created for them
- Write sales copy that makes them feel professionally stalked (away) or professionally understood (toward)

**Output use:** The human foundation for all messaging, offers, positioning, and product design.

---

## INPUTS

1. **Website URL** (analyze the business offering first if available)
2. **Market/industry description** (2-3 sentences)
3. **Number of avatars to generate** (3-5 — specify or default to 3)
4. **Psychographic/aspiration research** (paste output from zp-excavation if already run)
5. **Desire hierarchy map** (paste output from zp-desire-mapper if already run)
6. **Output folder path**
7. **market-context.md** (must exist — see Step 0)

---

## SPECTRUM DIMENSION SELECTION

The 11 avatar sections are selected by spectrum:

| Zone | Away Sections | Toward Sections |
|------|---------------|-----------------|
| Pure Away | All 11 away sections | None |
| Away-Dominant | 7-8 away sections | 3-4 toward injections: Aspiration Stratigraphy, Life Stage Dynamics, Community Needs |
| True Hybrid | All 5 away + all 5 toward (paired) + Synthesis: The Avatar at the Crossroads | — (see below) |
| Toward-Dominant | 2-3 away injections: Pain Stratigraphy (light), Shadow Work (brief) | 7-8 toward sections |
| Pure Toward | None | All 11 toward sections |

---

## PHASE 1: MARKET ECOSYSTEM ANALYSIS

### Website Archaeology (if URL provided)

**Away framing:** Forensically analyze to decode the transformation promise, extract psychological contracts, identify identity shifts being sold, reveal the hidden emotional transactions beneath features, uncover the existential questions the business answers.

**Toward framing:** Forensically analyze to decode the identity transformation promise embedded in the offering, extract what psychological contracts are proposed (what identity will the student inhabit after?), identify what kind of person this business helps someone become, reveal the hidden aspiration transaction beneath course content.

**Hybrid framing:** Do both. Identify what the business promises away from AND what it promises toward. Note any tension or alignment between these two promises.

### Market Stratification

**Away:** Dissect into 3-5 distinct psychological segments — consciousness levels, tribal affiliations, collective trauma, unspoken rules, transformation archetypes.

**Toward:** Dissect into 3-5 distinct aspiration segments — aspiration intensity levels, life stage dynamics creating the aspiration window, shared aspirational mythology, identity permission hierarchy, transformation archetypes (late bloomer, returning creator, life-stage reinventor, identity seeker).

**Hybrid:** Map both simultaneously. The same market contains people at different points on the spectrum — identify which segments are more away-weighted vs. toward-weighted and adjust avatar depth accordingly.

---

## PHASE 2: AVATAR CONSTRUCTION PROTOCOL

For EACH of the 3-5 avatars, execute the full section excavation below, selecting sections by zone.

---

## AWAY SECTION LIBRARY

*Used in Pure Away and Away-Dominant modes. Reduced in hybrid.*

### AWAY SECTION A: DEMOGRAPHIC ARCHITECTURE

**Surface Demographics (with psychological depth):**
- Age range — include generational trauma markers and defining cultural moments
- Geographic psychology — how location shapes identity and limitations
- Income reality — the gap between current and required income for their dreams
- Education wounds — how education level creates impostor syndrome or superiority
- Occupational identity — the prestige/shame dynamics of their position

**Hidden Demographics:**
- Secret addictions (what they compulsively consume — information, validation, substances)
- Shadow career (the job they really wanted but never pursued)
- Financial skeletons (the money mistakes that still haunt them)
- Relationship status complexity (gap between public and private reality)

---

### AWAY SECTION B: PSYCHOGRAPHIC EXCAVATION

**Core Values Architecture** — not what they CLAIM to value, but:
- The CHILDHOOD WOUND that crystallized each core value
- The BETRAYAL that made this value non-negotiable
- The HYPOCRISIES where they violate their own values
- The SHADOW VALUE they despise but secretly embody
- The VALUE CONFLICTS creating daily internal warfare

**Identity Archaeology:**
- The story they tell themselves (the edited autobiography they've rehearsed)
- The story they can't tell (the version that includes all the failures)
- The identity they're protecting (who they must be to maintain their world)
- The identity they're suppressing (who they'd be if truly free)
- The identity they're becoming (the emergence trying to happen)

**Belief System Forensics:**
- Inherited beliefs (what they absorbed before age 7)
- Protective beliefs (what they created to survive trauma)
- Limiting beliefs (the invisible ceilings they don't see)
- Compensatory beliefs (superiority complexes masking insecurity)
- Emerging beliefs (the new truths trying to break through)

---

### AWAY SECTION C: PAIN STRATIGRAPHY

- Layer 1 — Surface Pain: What they'll admit to strangers
- Layer 2 — Social Pain: What they'll admit to friends
- Layer 3 — Private Pain: What they'll admit to themselves
- Layer 4 — Shadow Pain: What they can't admit exists
- Layer 5 — Primal Pain: The original wound everything stems from

**Fear Architecture:**

Existential Fears:
- The MEANINGLESSNESS that haunts quiet moments
- The WASTED LIFE terror that strikes at 3am
- The LEGACY VOID of leaving no mark

Identity Fears:
- EXPOSURE as a fraud/impostor/failure
- DISSOLUTION of the carefully constructed self
- BECOMING what they swore they'd never be

Somatic Fear Signatures:
- WHERE fear lives in their body (chest, throat, stomach)
- HOW fear moves through them (waves, pressure, numbness)
- WHEN fear peaks (time of day, triggers, seasons)

---

### AWAY SECTION D: SHADOW WORK EXCAVATION

**The Disowned Self:**
- The trait they despise in others because it's in them
- The desire they deny because they feel ashamed wanting it
- The power they reject because they're afraid to wield it
- The vulnerability they've armored because softness felt dangerous
- The joy they sabotage because they don't feel they deserve it

**Projection Patterns:**
- Who they vilify — and what it reveals about their shadow
- Who they idealize — and what they've disowned
- Who they envy — and what permission they won't give themselves

**Shadow Integration Points:**
- The crisis that forces shadow confrontation
- The moment they realize they've become what they hated
- The liberation that comes from shadow acceptance

---

### AWAY SECTION E: SOMATIC FEAR SIGNATURES

**Body Wisdom Archaeology:**
- WHERE success feels like in their body
- HOW failure registers somatically
- WHAT their body does when they're lying to themselves
- WHEN their body contracts vs. expands

**Nervous System Patterns:**
- Hypervigilance signatures (what keeps them scanning for threat)
- Freeze responses (where they go numb or dissociate)
- Fight activation (when aggression masks vulnerability)
- Fawn behaviors (where they sacrifice self for safety)

---

### AWAY SECTION F: TEMPORAL TRAUMA ANALYSIS

**Chronological Trauma Points:**
- Anniversary reactions (dates that reactivate old wounds)
- Age-related crises (birthdays that bring existential dread)
- Milestone anxiety (life markers that highlight what's missing)

**Daily Rhythm Dysfunction:**
- The hour of despair (when their problem feels insurmountable)
- The window of hope (when transformation seems possible)
- The danger zone (when they're most likely to self-sabotage)
- The void time (when numbing behaviors take over)

**Future Projection Patterns:**
- The catastrophic future they're desperately avoiding
- The mediocre future they're resigned to accepting
- The impossible future they won't let themselves want
- The emerging future that's trying to call them forward

---

### AWAY SECTION G: RELATIONAL DAMAGE ASSESSMENT

**Intimate Partnership Erosion:**
- The exact words that trigger shutdown with their partner
- The emotional labor imbalance destroying the relationship
- The unspoken resentments poisoning daily interaction

**Parental Relationship Archaeology:**
- The inherited patterns they're unconsciously repeating
- The approval seeking that still drives decisions
- The generational trauma they're afraid to pass on

**Social Circle Deterioration:**
- The friends they've lost to their problem
- The connections they avoid from shame
- The performances they maintain to hide truth

---

### AWAY SECTION H: DECISION NEUROSCIENCE DECODING (AWAY)

**Information Processing Style:**
- Deletion: What they literally cannot see/hear
- Distortion: How they warp reality to fit beliefs
- Generalization: The rules they've created from single events
- Meta-Programs: Toward/away, internal/external, possibility/necessity

**Purchase Psychology:**

Pre-Purchase State:
- The emotional condition required for purchase readiness
- The mental story they must tell themselves
- The social permission they need to proceed
- The identity shift that precedes transaction

Purchase Moment:
- The exact words that unlock their credit card
- The images that bypass logical resistance
- The stories that make buying inevitable
- The guarantees that dissolve final hesitation

Post-Purchase Psychology:
- The immediate doubt that must be addressed
- The validation need in the first 24 hours
- The implementation anxiety that causes abandonment
- The success milestones that create loyalty

---

### AWAY SECTION I: TRANSFORMATION ARCHITECTURE (AWAY)

**Current State: A Day in Their Dysfunction** (with specific times):
- Early morning: The anxiety before the alarm
- Morning: The mask they put on for the world
- Afternoon: The energy crash that reveals depletion
- Night: The promises they make to tomorrow

**The Mental Prison Architecture:**
- The thought loops playing 50+ times daily
- The inner critic script they've memorized
- The procrastination rituals they've automated

**Future State Vivification** (sensory detail):
- Their transformed morning — first thought, body sensation, mirror moment
- The liberation experience — breathing without weight, deciding without paralysis

---

### AWAY SECTION J: OBJECTION ARCHAEOLOGY (AWAY)

**Surface Objections:**
- "I don't have time" = I'm afraid of what I'll discover
- "I can't afford it" = I don't believe I deserve investment
- "I need to think" = I'm terrified of change

**Shadow Objections:**
- "If this works, I'll have no excuses left"
- "Success means I can't be a victim anymore"
- "People will expect more from the transformed me"

**Objection Dissolution:**
- The question that makes the objection irrelevant
- The story that reframes the objection as a gift
- The evidence that proves the objection false

---

### AWAY SECTION K: MARKETING INTEGRATION SYNTHESIS (AWAY)

**Power Words That Penetrate:**
- The verbs that activate their nervous system
- The metaphors that explain their unexplainable
- The questions that crack them open

**Content Architecture Blueprint:**

Awareness Stage: Pattern interrupt headlines, mirror neuron posts, Trojan horse teachings

Consideration Stage: Case studies matching their exact situation, mechanism reveals, objection prevention

Decision Stage: Urgency truths, guarantee language, bonus architecture that tips the scale

---

## TOWARD SECTION LIBRARY

*Used in Pure Toward and Toward-Dominant modes. Reduced in hybrid.*

### TOWARD SECTION A: DEMOGRAPHIC ARCHITECTURE (TOWARD)

**Surface Demographics (with life-stage depth):**
- Age range — include generational experiences and cultural moments that shaped this cohort's relationship with creativity, learning, and permission
- Geographic psychology — how location shapes access to community and legitimacy signals
- Income reality — the gap between what they can invest and what they believe they're worth investing in
- Education background — how formal education shaped their beliefs about whether they're "the kind of person" who does this
- Occupational identity — how their professional self-concept intersects with their aspiration

**Life Stage Context:**
- The specific life transition creating the aspiration window (empty nest, retirement, health shift, career change, loss, recovery, newfound time)
- What has opened up that wasn't available in previous chapters
- What they have NOW that younger learners don't (patience, perspective, financial stability, time intentionality)
- The relationship between this life stage and why the aspiration feels both urgent and accessible right now

**Hidden Demographics:**
- What they compulsively consume in this aspiration space (specific YouTube channels, Instagram accounts, books, podcasts)
- The version of this aspiration they tried before and abandoned — and why
- The "someday" fantasy they've carried for years that is finally getting space
- The identity they publicly claim vs. the identity they secretly aspire toward

---

### TOWARD SECTION B: PSYCHOGRAPHIC EXCAVATION (TOWARD)

**Core Values Architecture:**
- The LIFE EXPERIENCE that crystallized each core value
- The CHOICE that made this value a non-negotiable part of their identity
- The places where their values around creativity, learning, and community are FULLY EXPRESSED vs. suppressed
- The VALUE they claim (practicality, responsibility) that quietly wars with the VALUE they hunger for (expression, beauty, creation)
- The INTERNAL PERMISSION they need before they can act on the aspiration without guilt

**Identity Archaeology:**
- The story they tell themselves about who gets to pursue this aspiration (and whether that includes them)
- The story they can't tell — the version that includes the attempts, the doubts, the grief of the unlived aspiration
- The identity they're protecting (the responsible adult, the practical person, the one who puts others first)
- The identity they're becoming (the artist, the maker, the learner, the person with a practice)
- The specific identity claim they want to make but feel they haven't earned yet: "I'm an artist," "I'm a musician," "I paint"

**Belief System Forensics:**
- Inherited beliefs about who gets to claim this identity (talent myth, age myth, training myth)
- Protective beliefs created from early experiences with creative judgment
- The invisible ceiling they accept: "I can enjoy it, but I'll never be really good"
- The emerging belief trying to break through: "Maybe process matters more than output. Maybe it's not too late."

---

### TOWARD SECTION C: ASPIRATION STRATIGRAPHY

**Layer 1 — Surface Aspiration:** What they'll tell anyone when asked
- "I've always wanted to learn to draw / play piano / speak Italian"
- Low vulnerability, easy to say, doesn't require permission
- Surface aspiration language: "It looks fun," "I thought I'd try it," "I saw a class and signed up"

**Layer 2 — Identity Aspiration:** What they'll admit when there's trust
- "I want to be someone who makes things"
- "I want to actually be able to call myself a ___"
- "I want something that's just mine — that I'm building for myself"
- Identity aspiration language: "I've always considered myself creative but never had an outlet," "I want to prove to myself I can do this"

**Layer 3 — Deep Aspiration:** What drives the real purchase decision
- "I want to feel like I'm using this chapter of my life for something meaningful"
- "I want to create something that outlasts me"
- "I want to be part of something — a community of people who make things, where I belong"
- "I want to feel like the person I always thought I was — or could be"
- High vulnerability, rarely stated publicly, drives deepest buying motivation

For each avatar, identify all three layers with specific language and evidence. Content that reaches Layer 3 converts. Content that stays at Layer 1 collects browsers.

---

### TOWARD SECTION D: IDENTITY ASPIRATION

**The Identity They're Reaching Toward:**
- The specific self-concept they want to inhabit: "I'm someone who paints," "I'm a person with a creative practice," "I'm an artist"
- What that identity would enable them to say, do, or feel about themselves
- The people they most admire in this space — and what it is about their identity, not just their skill, that they're drawn to
- The social permission they want: to be someone others think of as creative, as someone who makes things

**The Permission Barriers:**
- The explicit self-prohibitions: "Real artists start young," "I don't have formal training," "I'm not talented enough to call myself that"
- The implicit wait conditions: "When I reach X level, THEN I can say it"
- The identity occupants they're comparing to: the person who went to art school, the natural talent, the person who's done it for decades
- What it would take for them to feel they'd genuinely earned the identity claim

**The Identity Expansion Story:**
- Who in this market has made the leap from "I'm someone who tries this" to "I'm someone who does this" — and what shifted?
- What was the specific moment, output, or community recognition that moved them?
- What would the same shift look like for THIS avatar?

**The Suppressed Aspiration:**
- The version of this identity they want but feel embarrassed to admit wanting (selling work, being known for something, having other people genuinely admire what they've made)
- The aspiration that feels too big or too pretentious to name out loud
- What permission would look like if someone genuinely granted it to them

---

### TOWARD SECTION E: FLOW STATE MAPPING

**Flow State Signatures:**
- WHERE absorption feels like in their body: the quality of attention, the loss of time, the specific physical sensation of being fully engaged
- HOW they describe the experience of being in flow — their own language for it
- WHEN flow happens: what conditions (time of day, physical environment, level of skill, mood) make deep absorption possible
- What they feel immediately AFTER a flow session: specific emotional and physical language

**Absorption Patterns:**
- The specific techniques, materials, or challenges that most reliably produce absorption for this avatar
- What pulls them OUT of flow — the internal critics, the comparisons, the perfectionism that interrupts
- How their flow state experience has changed as they've developed skill

**The Flow Promise:**
- For approach-motivated markets, flow state is often the real product — what they're buying is access to this experience reliably, repeatedly, skillfully
- What the teacher/program/community does that makes flow more accessible for this avatar specifically

**Body Intelligence in Learning:**
- WHERE success registers physically when they make something they're proud of
- HOW progress feels in their hands, their attention, their confidence
- WHAT their body does when they're in the zone vs. when they're trying to force it

---

### TOWARD SECTION F: LIFE STAGE DYNAMICS

**The Transition Creating the Window:**
- The specific life stage shift: empty nest, retirement, major health event, career completion or pivot, loss, relationship change
- What this transition has taken away (demands, obligations, the identity built around them)
- What it has opened up (time, permission to prioritize self, the "finally" feeling)
- How the transition changed their relationship to this aspiration — from someday to now

**Life Stage-Specific Assets:**
- What they bring to this aspiration at this life stage that younger starters don't have
- The specific advantages of starting NOW vs. starting earlier
- How their relationship to time has shifted: urgency (not enough left to waste) and abundance (fewer obligations competing for it)

**The Clock Dynamics:**
- The sense of urgency that makes NOW feel meaningful: "If not now, when?"
- The freedom from external validation that often comes with life stage maturity
- The window of opportunity this life stage opens — and what would close it

**Future Projection:**
- The version of themselves at 70 (or 80) who looked back and did this — what does that feel like?
- The version who didn't — what does that feel like?
- The aspiration they're building toward that will compound over the years ahead

**Daily Rhythm:**
- The specific time of day when the aspiration gets space: the quiet morning, the evening after the house empties
- The environment they create for this practice
- How the rhythm of this pursuit fits into the texture of their current life

---

### TOWARD SECTION G: COMMUNITY NEEDS

**The Tribe They're Hoping to Find:**
- What kind of people do they want to belong with? (Values, attitude toward learning, relationship to the craft, how they talk about their work)
- What would their ideal community sound like in conversation?
- What do they most want other members to understand about them and where they are in their journey?

**The Belonging They Haven't Had:**
- What community experiences in this space have felt wrong or alienating? (Too competitive, too advanced, too focused on output over process, too intimidating)
- The community they've witnessed from the outside that felt like "those people" — the ones they assumed weren't for them
- What would need to be different for them to feel they genuinely belong

**The Identity Mirror They Need:**
- The specific demographic, life stage, and starting point they need to see reflected in other community members
- Why this mirror is the most powerful proof in approach markets — it answers "Is this identity available to someone like me?" more powerfully than any testimonial about the course content
- What the "before" of that mirror needs to look like for it to work: specific enough to feel like seeing themselves

**What Belonging Would Give Them:**
- The specific permission that comes from being around others who are doing this without apology
- The accountability and momentum that comes from a community of practice
- The identity reinforcement: being around people who call themselves artists/musicians/writers makes it easier to claim that identity for yourself

**Community Red Lines:**
- What would immediately make them feel unwelcome, inferior, or like they'd made a mistake joining
- The dynamics they've experienced in other communities that made them leave or lurk without engaging

---

### TOWARD SECTION H: DECISION NEUROSCIENCE DECODING (TOWARD)

**Information Processing Style:**
- Deletion: What they literally screen out in marketing (jargon, prodigy stories, competitive framing, pain-focused language)
- Distortion: How they interpret teacher confidence as evidence that the teacher won't understand a true beginner
- Generalization: The rules they've created from past learning experiences
- Meta-Programs: How toward/away, internal/external reference, possibility/necessity manifest specifically in approach-motivated buying

**Purchase Psychology for Approach Markets:**

Pre-Purchase State:
- The emotional condition required: not desperation but genuine belief that this version of themselves is possible
- The mental story they must tell themselves: "I'm serious enough about this to invest. This teacher understands people like me. I can actually do this."
- The social permission they sometimes need: "Other people like me have done this. It's not irresponsible to spend on this."
- The identity shift that precedes transaction: moving from "someone who has always wanted to do this" to "someone who is actually doing this"

Purchase Moment:
- The specific proof that unlocks commitment: usually a mirror testimonial or a demonstration that makes "I could do that" feel viscerally real
- The emotional tone that creates safety: warmth, non-judgment, evidence that the teacher has taught true beginners successfully
- The guarantee or risk reversal framing that actually lands for this avatar specifically

Post-Purchase Psychology:
- The specific anxiety that surfaces immediately after buying: "Will I actually follow through? Have I wasted money again?"
- The validation they need in the first 24-48 hours
- The first win that creates the momentum to continue — what it needs to be (small, achievable, genuinely satisfying)
- The milestone that creates the identity shift from "I bought a course" to "I'm someone who does this"

---

### TOWARD SECTION I: TRANSFORMATION ARCHITECTURE (TOWARD)

**Current State: A Day in Their Aspiration Life** (with specific times):
- Morning: The moment when the aspiration surfaces — the Instagram post that catches their attention, the sketchbook on the shelf, the piano they walk past
- Afternoon: The space opening in their day that used to be filled with obligations
- Evening: The quiet hour that has always felt like it should belong to something — and what happens in that hour currently
- Night: The specific thought that runs when they imagine themselves having actually built this practice

**The Aspiration Architecture:**
- The version of themselves they most consistently return to imagining: what are they doing, where, what does the output look like, who sees it
- The internal conversation they have with themselves about whether to actually start or continue

**Future State Vivification** (sensory detail):
- Their transformed practice — what a routine Tuesday evening looks like when this aspiration is a real part of their life
- The identity experience: what it feels like to say "I paint" or "I play" or "I write" without the immediate internal qualifier
- The community experience: what it feels like to be around others who are doing this at the same level, same life stage, same spirit
- The specific output they imagine having made

---

### TOWARD SECTION J: OBJECTION ARCHAEOLOGY (TOWARD)

**Surface Objections:**
- "I don't have enough time" = I'm not sure I'm serious enough to prioritize this
- "I'm not talented enough to get real results" = I don't have identity permission to expect that outcome
- "I've bought courses before and never finished them" = I don't trust myself to follow through
- "I'm too old to really get good at this" = I'm not sure this identity is available to someone at my life stage

**Identity Permission Objections:**
- "What if I invest in this and it confirms I don't have what it takes?"
- "If I go all-in and still can't do it, I lose the dream version of myself"
- "People at my age don't become real artists/musicians/writers"
- "The real learners in this space are 30 years younger than me and I'll just feel embarrassed"

**Objection Architecture:**
- The mirror that makes the identity objection irrelevant (show them someone their age, their starting point, their life stage who made it)
- The reframe that dissolves the talent objection (it was never about talent — it's about process, which is teachable)
- The first-win design that dissolves the follow-through objection
- The community proof that dissolves the belonging objection

---

### TOWARD SECTION K: MARKETING INTEGRATION SYNTHESIS (TOWARD)

**Language That Lands:**
- The verbs that activate their aspiration (create, build, develop, explore, make, discover)
- The identity phrases that feel true before they've earned them
- The questions that crack them open without making them defensive
- The metaphors that explain their aspiration in terms they recognize: beginner's mind, late bloomer, practice over performance

**Content Architecture Blueprint:**

Awareness Stage: Content that makes the aspiration feel legitimate and available — not just in theory but for people who look like them. Mirror neuron content: watch someone their age, their demographic, making something beautiful with the teacher's guidance. The "I could do that" moment.

Consideration Stage: Process transparency that dissolves intimidation — seeing how the skill is built step by step, what it looks like to genuinely start from nothing. Community glimpses that answer "would I belong there?"

Decision Stage: The mirror testimonial so demographically specific it reads like the prospect's own future story. The demonstration that produces the visceral "I could do that" feeling. The guarantee that removes the identity risk. The community invitation that makes belonging feel possible.

---

## TRUE HYBRID MODE: DUAL-DIMENSIONAL AVATAR

In True Hybrid (45-59%), run ALL away sections AND all toward sections for each avatar, pairing them:

| Away Dimension | Toward Dimension | What the Pairing Reveals |
|---------------|-----------------|--------------------------|
| Pain Stratigraphy (Section C) | Aspiration Stratigraphy (Section C) | Both mapped — the layers of what they're fleeing AND the layers of what they're reaching for |
| Shadow Work (Section D) | Identity Aspiration (Section D) | What they fear AND who they want to become — often mirror images |
| Somatic Fear Signatures (Section E) | Flow State Mapping (Section E) | What terrifies them in their body AND what absorbs them in their body |
| Temporal Trauma (Section F) | Life Stage Dynamics (Section F) | Past wounds AND the current opportunity window created by life stage |
| Relational Damage (Section G) | Community Needs (Section G) | Relational wounds AND tribal belonging desires |

After all paired sections, add:

---

### THE AVATAR AT THE CROSSROADS (Hybrid Synthesis — Mandatory in True Hybrid)

```
## THE AVATAR AT THE CROSSROADS

[Avatar Name] is running simultaneously:
- AWAY from: [single sentence — the core thing they're fleeing]
- TOWARD: [single sentence — the core thing they're reaching for]

These are not two different people. They are the same person viewed from opposite directions.

The away face: "[their own language when they describe what they can't stand anymore]"
The toward face: "[their own language when they describe what they want to become]"

The crossroads moment: [The specific life stage, trigger event, or internal shift that made both the away force and the toward pull active at the same time]

The marketing implication: This avatar responds to both avoidance language (when it names what they're running from accurately) and aspiration language (when it names who they're running toward accurately). The highest conversion copy for this avatar holds both simultaneously — "You've spent years trying to escape X. Here's the real reason you couldn't: because the solution was never to escape at all. It was to build Y."
```

---

## PHASE 3: SYNTHESIS & ACTIVATION

After all avatars are built:

1. **Avatar Overlap Analysis:** Where all avatars share common wounds/desires (away), aspirations/identity permission gaps (toward), or both (hybrid) — universal messaging works here
2. **Avatar Distinction Map:** What makes each segment unique and requires different messaging, proof types, or mirror specifications
3. **Avatar Journey Intersections:** Where different avatars meet in the funnel (often at community)
4. **Avatar Language Matrix:** Specific words that resonate with each (and what to avoid)
5. **Avatar Conversion Architecture:** Unique pathways to purchase for each segment — including what proof type actually moves each avatar

**Hybrid-specific addition:**
6. **Spectrum Position per Avatar:** Some avatars within a hybrid market skew more away, others more toward. Map this explicitly. Messaging to the more-away avatar segments should lean on pain language; messaging to the more-toward avatar segments should lean on aspiration language.

---

## OUTPUT SPECIFICATION

**Away mode:** `ZP-Avatar-[Market]-[Avatar Name].md` (one per avatar) + `ZP-Avatar-Synthesis-[Market].md`

**Toward mode:** `ZP-Aspiration-Avatar-[Market]-[Avatar Name].md` (one per avatar) + `ZP-Aspiration-Avatar-Synthesis-[Market].md`

**Hybrid mode:** `ZP-Dual-Avatar-[Market]-[Avatar Name].md` (one per avatar) + `ZP-Dual-Avatar-Synthesis-[Market].md`

All files open with the Spectrum Badge.

**Target length per avatar:** 2,000-4,000 words. This is forensic reconstruction, not marketing copy.

---

## QUALITY GATE

- [ ] Spectrum badge present at top of every output file
- [ ] market-context.md was read before execution
- [ ] Section selection matches the zone (correct away vs. toward balance)
- [ ] Each avatar has all sections complete for their zone
- [ ] Away mode: Shadow psychology (Section D) is genuinely uncomfortable — not sanitized
- [ ] Toward mode: Aspiration Stratigraphy (Section C) shows meaningfully different content at surface/middle/deep — not three paraphrases of the same aspiration
- [ ] Toward mode: Flow State Mapping (Section E) includes embodied, sensory language
- [ ] Toward mode: Community Needs (Section G) specifies the exact mirror demographic for this avatar's identity permission shift
- [ ] Hybrid mode: The Avatar at the Crossroads section is present and non-generic
- [ ] Both surface AND shadow/identity-permission objections in Section J for all modes
- [ ] Avatar synthesis document created
- [ ] Zero avoidance language in the skill's own voice in toward/hybrid toward-sections
- [ ] Saved to files

---

## HOW THIS CONNECTS DOWNSTREAM

- **zp-mimetic** → Avatar mirror specifications feed the mimetic model search — finding real people whose stories would create permission for each segment
- **core-concept-generator / permission-concept-generator** → Each avatar's identity permission barriers (toward) or failure pattern (away) become Core Concept targets
- **belief-gap-analyzer / identity-belief-gap-analyzer** → Aspiration Stratigraphy + Identity Aspiration + Pain Stratigraphy + Shadow Work feed the full belief gap map
- **usp-generator / toward-usp-generator** → Avatar Language Matrix + suppressed aspirations + community needs feed USP development
- **community-architect** → Community Needs section (toward) directly feeds community design
- **content-strategy** → Transformation Architecture (Section I) feeds content that shows the before and the possible
