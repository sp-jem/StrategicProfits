#!/bin/bash
SKILLS=("zp-desire-mapper" "zp-excavation" "zp-avatar" "zp-pattern-analyzer" "zp-concept-generator" "zp-buying-state" "zp-belief-gap" "zp-usp" "zp-mimetic" "zp-community" "zenithpro")
echo "Installing ZenithPro Hybrid Path (11 skills)..."
SUCCESS=0; FAILED=0
for SKILL in "${SKILLS[@]}"; do
  mkdir -p "$HOME/.claude/skills/$SKILL"
  cp "$SKILL/SKILL.md" "$HOME/.claude/skills/$SKILL/SKILL.md"
  if [ -f "$HOME/.claude/skills/$SKILL/SKILL.md" ]; then echo "✅ $SKILL"; ((SUCCESS++))
  else echo "❌ $SKILL"; ((FAILED++)); fi
done
echo "Installed: $SUCCESS / 11 | Run: /zenithpro [your market]"
