$Skills = @("zp-desire-mapper","zp-excavation","zp-avatar","zp-pattern-analyzer","zp-concept-generator","zp-buying-state","zp-belief-gap","zp-usp","zp-mimetic","zp-community","zenithpro")
Write-Host "Installing ZenithPro Hybrid Path (11 skills)..."
$Success = 0; $Failed = 0
foreach ($Skill in $Skills) {
  $InstallDir = "$env:USERPROFILE\.claude\skills\$Skill"
  New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
  Copy-Item "$Skill\SKILL.md" "$InstallDir\SKILL.md"
  if (Test-Path "$InstallDir\SKILL.md") { Write-Host "✅ $Skill"; $Success++ }
  else { Write-Host "❌ $Skill"; $Failed++ }
}
Write-Host "Installed: $Success / 11 | Run: /zenithpro [your market]"
