---
name: zp-belief-gap
description: "Unified ZenithPro belief gap analyzer. Maps the complete belief journey from Point A to Point B for ANY market. Away-heavy: Point A = broken/failing, Point B = mechanism belief and self-efficacy. Toward-heavy: Point A = curious but doubting self, Point B = identity claim and permission. Hybrid: dual bridge where both mechanism credibility AND identity permission must be established simultaneously — and maps the dependency between them. Evidence requirements for each gap type are calibrated to the spectrum. Reads market-context.md automatically. Part of ZenithPro Unified System."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Unified, Force Multiplier, Connect the Dots]
interface:
  invoke: "/zp-belief-gap [market or avatar]"
  called_by: [user, zp-demand-architect]
  outputs_to: [project folder]
---

# ZP Belief Gap

Maps the exact path from Point A to Point B for ANY market — calibrated to whether the gaps are about mechanism credibility, identity permission, or both simultaneously. Shows not just WHAT beliefs to change, but in what ORDER and using what EVIDENCE.

---

## LAYER 1: INVARIANTS

1. **Read market-context.md from the project folder before running.** If not found, prompt the user to run motivation-spectrum-analyzer first OR accept manual spectrum input: "Away: X% / Toward: Y%".
2. **Display the spectrum badge at the top of every output.** No exceptions.
3. **Zone determines the nature of the gaps.** Away markets: gaps are primarily mechanism credibility and self-efficacy. Toward markets: gaps are primarily identity permission (category-level, self-level, temporal). Hybrid: BOTH types present — must map both and map the dependency between them.
4. **Order matters absolutely.** Some beliefs cannot be installed until prerequisite beliefs exist. Dependency logic is non-negotiable regardless of zone. Foundation before middle before upper.
5. **Evidence type is not interchangeable across zones.** Logical argument works for away-market mechanism gaps. Logic does NOT work for toward-market identity permission gaps. Mirror testimony (demographically identical person) is required for identity gaps. Match evidence to gap type.
6. **The Core Concept, if produced, is the Master Bridge.** In away markets: the belief that shortens or eliminates multiple mechanism gaps. In toward markets: the identity permission reframe that shortens or eliminates multiple identity gaps. In hybrid markets: the single reframe that serves as both a mechanism bridge AND an identity permission bridge.
7. **Point A differs by zone.** Away: "I've tried and failed. Nothing works for me." Toward: "I'm drawn to this but it's not for someone like me." Hybrid: "I need to escape this situation AND I'm not sure this version of me is available to me."
8. **Point B differs by zone.** Away: "This mechanism is different and I can execute it." Toward: "This identity is mine to claim." Hybrid: "I believe this works AND I am the kind of person it works for."
9. **Hybrid markets have a Dual Bridge Dependency section.** Map which gap must close first to unlock the other — mechanism belief or identity permission.
10. **Save all outputs to files.** Never deliver in chat only.

---

## PURPOSE

**The core formula across all zones: Desire + Belief = Demand**

Desire exists. That is not the problem. Between desire and purchase is a specific belief structure. This skill maps that structure — calibrated to the zone.

**The Bridge Metaphor (universal):** Point A and Point B are two positions separated by a chasm of doubt. You can't jump it in one leap. You build bridges — one belief at a time — that create a safe path from where prospects are to where they need to be.

**Critical Insight (universal):** ORDER matters. Some bridges enable others.

**Away market:**
- Can't believe "your solution works" until they believe "solutions in this category can work"
- Can't believe "I can do this" until they believe "it's not my fault I failed before"
- Can't believe "now is the right time" until they believe "waiting costs more than acting"

**Toward market:**
- Can't believe "I can become a [practitioner]" until they believe "[this identity] is available to people who start at my age/background"
- Can't believe "starting now is valid" until they believe "the journey, not just the destination, is the point"
- Can't believe "I'm ready to invest" until they believe "investing in this for me is legitimate and deserved"

**Hybrid market:**
- Both chains operate simultaneously
- The mechanism chain and the identity chain are interdependent
- Believing the mechanism works often unlocks identity permission (if the mechanism handles "people like me" then I can claim the identity)
- Believing the identity is available often makes the mechanism feel worth trying (I'm invested enough to give it a real shot)
- Map the dependency direction — which unlocks which?

**Output use:** Becomes the content strategy blueprint. Every piece of marketing content builds a specific bridge. This tells you which content to create first, why, and what proof it needs.

---

## INPUTS

Required:

1. **Point A Description** — the current state of the prospect:
   - Away: What specifically are they stuck on or failing at? What identity conclusions have they drawn from their failures?
   - Toward: What specifically are they drawn toward? What identity doubts are blocking access?
   - Hybrid: Both — what are they trying to escape AND what are they trying to become?

2. **Point B Description** — from zp-buying-state, or defined manually:
   - Away: What mechanism belief + self-efficacy belief must be true?
   - Toward: What identity claim must they make? What permission must they have given themselves?
   - Hybrid: Both sets — mechanism + self-efficacy AND identity claim + permission

3. **Desire Hierarchy Map** — from zp-desire-mapper (L4 gate type: Self-Efficacy / Identity Permission / Dual Gate)

4. **Failed Solution/Aspiration History:**
   - Away: Summarize key failed solutions and the limiting beliefs they created
   - Toward: Attempts to enter this world and what identity conclusions they drew
   - Hybrid: Both

5. **Market Sophistication Level** (Schwartz 1-5, adapted per zone):
   - Away: Unaware / Problem Aware / Solution Aware / Product Aware / Most Aware
   - Toward: Freshly Curious / Genuinely Interested / Returning After Stopping / Practicing But Plateaued / Already Committed

6. **Marketing Context** — where will you build these bridges? (Sales page / Webinar / Email sequence / Video series / Social media)

7. **Core Concept** (if generated — paste here for Master Bridge identification)

8. **Output folder path**

---

## SPECTRUM BADGE

Display this at the top of every output:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MARKET: [name] | [X]% Away / [Y]% Toward | [Zone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## THE GAP TYPES BY ZONE

### Away-Market Gap Types (Pure Away / Away-Dominant)

**1. CAUSE BELIEFS** (Why things have been failing)
- Example: "I failed because I used the wrong method" — NOT "because I'm incompetent"
- Importance: Must correct attribution BEFORE building confidence
- Hardest to change because they're rooted in lived experience

**2. MECHANISM BELIEFS** (Why this specific thing works when others didn't)
- Example: "This method works for the root cause, not just symptoms"
- Importance: Category trust must precede product trust
- Evidence: Logic + demonstration + differentiation proof

**3. SELF-EFFICACY BELIEFS** (Whether they can execute)
- Example: "I can do this despite my past failures — because the failure was method, not me"
- Importance: Must address AFTER attribution shift, not before
- Evidence: Peer-level social proof (similar starting point who succeeded)

**4. TIMING BELIEFS** (Why now is the right time)
- Example: "Waiting costs more than acting"
- Evidence: Quantified cost of delay

### Toward-Market Gap Types (Pure Toward / Toward-Dominant)

**1. CATEGORY-LEVEL PERMISSION GAPS** (Does this world exist for people like me?)
- Example: "Is [urban sketching / language learning / this craft] something people my age and background actually do?"
- Importance: Must resolve at category level BEFORE self-level permission becomes possible
- Evidence: Community visibility showing demographic diversity

**2. SELF-LEVEL PERMISSION GAPS** (Am I specifically allowed into this world?)
- Example: "Even if others my age do it, would someone like ME — with no natural talent — succeed?"
- Importance: Most personal and hardest to shift; requires mirror, not just category proof
- Evidence: Mirror testimony from person with nearly identical starting conditions

**3. TEMPORAL/DEVELOPMENTAL PERMISSION GAPS** (Is it too late / am I too early / is my moment right?)
- Example: "Real practitioners start young — I missed my window"
- Importance: Often the deepest prohibition; conviction that the access point has passed
- Evidence: Late-starter stories where life experience became genuine advantage

**4. WORTHINESS GAPS** (Do I deserve to invest in this for myself?)
- Example: "Investing at this level in something just for me feels indulgent"
- Importance: Investment congruence — without this the capstone bridge never closes
- Evidence: Permission story from someone who overcame this exact scruple

### Hybrid Gap Types (True Hybrid)

All away-market gap types AND all toward-market gap types apply. Additionally:

**5. DUAL ACTIVATION GAPS** (Does addressing one gap unlock the other?)
- Mechanism credibility may partially close identity permission ("if this works for people like me, then I belong")
- Identity permission may motivate mechanism engagement ("if I belong here, I'm willing to try the mechanism")
- Map which direction the dependency flows in this specific market

---

## STEP 1: GAP INVENTORY

For each gap between Point A and Point B, document:

**GAP #[X]: [Gap Category]** *(type: Cause / Mechanism / Self-Efficacy / Timing / Category-Permission / Self-Permission / Temporal / Worthiness)*

*Point A Belief (Current):* "[Exact current belief in their own language]"

*Point B Belief (Required):* "[Exact needed belief]"

Gap Analysis:
- **Type:** [From gap types above — zone-appropriate]
- **Size:** Small (reframe available) / Medium (evidence required) / Large (mirror + sustained exposure required)
- **Difficulty:** Easy / Moderate / Hard
- **Priority:** High / Medium / Low (based on how many other gaps depend on this one)

Why This Gap Exists:
[Root cause — failed experience / cultural messaging / demographic assumption / prior purchase disappointment / inference from role models]

Interference Factors:
- [Away] Past failure attribution / identity conflict / fear of being wrong about themselves again
- [Toward] Identity prohibition / temporal prohibition / demographic prohibition / gap-distance belief
- [Hybrid] Both types of interference present

**Target:** 8-15 gaps total (fewer = important gaps missed; more = over-splitting)

---

## STEP 2: DEPENDENCY CHAIN MAPPING

For each gap, map:
- What beliefs must exist BEFORE this one becomes accessible?
- What beliefs does this one ENABLE once established?
- Is this Foundation, Middle, Upper, or Capstone?

**Foundation Bridges** (no prerequisites — enable all others):
- *Away:* Attribution shift ("not your fault"), category trust ("solutions in this category can work")
- *Toward:* Category-level permission ("this world exists for people like me")
- *Hybrid:* Both types needed simultaneously — may be able to establish both in parallel if sequenced carefully

**Middle Bridges** (depend on foundation, enable upper):
- *Away:* Mechanism differentiation, self-efficacy (post-attribution)
- *Toward:* Self-level permission gaps, talent myth correction, age window reframe
- *Hybrid:* Interdependent — mechanism middle bridges and identity middle bridges feeding each other

**Upper Bridges** (require multiple prerequisites):
- *Away:* Product-specific confidence, ROI belief, fit belief
- *Toward:* Investment readiness, temporal permission, impostor fear correction
- *Hybrid:* Convergence bridges where mechanism and identity beliefs reinforce each other

**Capstone Bridges** (purchase readiness):
- *Away:* Urgency + timing + risk reversal
- *Toward:* Investment congruence + enrollment readiness + identity claim
- *Hybrid:* Dual activation confirmation — both "this works" AND "I'm the person it works for"

---

## STEP 3: DUAL BRIDGE DEPENDENCY (True Hybrid zone only)

**This section is mandatory for True Hybrid markets. Skip for Pure Away and Pure Toward.**

Map the interdependency between the mechanism belief journey (away vector) and the identity permission journey (toward vector):

**Question 1: Which gap must close first?**
- Does mechanism credibility need to be established before identity permission becomes relevant? (Market needs to believe the thing works before they care whether they belong)
- OR does identity permission need to be established before mechanism engagement is possible? (Market needs to believe they belong before they're willing to investigate the mechanism)
- OR can they be built simultaneously in parallel?

**Question 2: Where do the two chains converge?**
- Identify the specific bridge where mechanism belief and identity permission cross-reinforce
- Example: A mirror testimonial that shows someone with the same demographics BOTH succeeding with the mechanism AND claiming the identity simultaneously

**Question 3: What is the Master Dual Bridge?**
- The single evidence piece or content that advances BOTH the mechanism chain and the identity chain simultaneously
- Format: A case study or testimonial that documents (a) same starting point, (b) same doubts about the method working, (c) same doubts about belonging, (d) resolution of both through the mechanism, (e) identity claim as the outcome

**The Dual Bridge Dependency Map:**
```
MECHANISM CHAIN:                    IDENTITY CHAIN:
"Will this work?"                   "Is this for someone like me?"

Attribution shift         ←→        Category permission
(Foundation)                        (Foundation)
       ↓                                   ↓
Mechanism differentiation ←→        Self-level permission
(Middle)                            (Middle)
       ↓                                   ↓
Self-efficacy             ←→        Investment permission
(Upper)                             (Upper)
       ↓                                   ↓
Urgency/timing            ←→        Identity claim
(Capstone)                          (Capstone)
       ↓                                   ↓
                DUAL PURCHASE DECISION
         "It works AND I'm the right person for it"
```

Mark the ←→ connections where evidence can bridge BOTH chains simultaneously.

---

## STEP 4: EVIDENCE SPECIFICATION

For each bridge, specify the exact evidence type that creates the belief shift:

**Evidence Type Matching Rules:**

| Gap Type | Required Evidence | Why |
|----------|-----------------|-----|
| Cause/attribution | Logic + peer story (reframe, then prove with example) | Must explain why it wasn't them; then show someone like them who succeeded once blame was removed |
| Category trust | Mechanism explanation + third-party proof | "This type of thing can work" needs credible external validation |
| Mechanism differentiation | Side-by-side contrast + demonstration | Shows HOW this is different, not just claims it is |
| Self-efficacy (away) | Peer-level social proof (similar background who succeeded) | NOT aspirational — must match their starting point and failure history |
| Timing/urgency | Quantified cost of waiting | Makes delay expensive, not just unwise |
| Category-level permission | Community visibility (demographic diversity) | Must SEE the category populated by people like them |
| Self-level permission | Mirror testimony (nearly identical demographics) | Logic doesn't shift identity; seeing yourself in someone else does |
| Temporal prohibition | Late-starter stories highlighting advantages of starting now | Reframes the prohibition into a genuine permission |
| Worthiness gap | Permission story — someone who overcame this scruple and what followed | Permission is caught, not taught |
| Dual activation (hybrid) | Dual-function case study (mechanism success + identity claim in one story) | Only evidence type that advances both chains simultaneously |

**What Does NOT Work:**

*For away-market mechanism gaps:*
- Identity-only proof (showing who they become without proving the mechanism works)

*For toward-market identity gaps:*
- Logical argument for why they should be able to do this
- Statistics without demographic specificity
- Expert endorsement without peer-level mirror evidence
- Urgency tactics (the problem isn't that they haven't decided fast enough)

*For hybrid gaps:*
- Evidence that advances only one chain
- Assuming mechanism proof will automatically create identity permission
- Assuming identity proof will automatically create mechanism belief

---

## STEP 5: BRIDGE SEQUENCE OPTIMIZATION

Arrange all bridges in optimal order:
- Logical dependencies (foundation before middle before upper)
- Psychological readiness (can't absorb X until feeling Y)
- Momentum building (early wins enable later challenges)
- Natural narrative flow

**Away-Market Sequence:**
```
BRIDGE 1: [Attribution/Cause] — Foundation
Evidence: [Peer story + logic]
Installs: "[It's not your fault — the method was wrong]"
       ↓ enables
BRIDGE 2: [Category Trust] — Foundation
Evidence: [Mechanism explanation]
Installs: "[Solutions in this category can actually work]"
       ↓ enables
BRIDGE 3: [Mechanism Differentiation] — Middle
Evidence: [Contrast + demonstration]
Installs: "[This specific approach is different from what failed before]"
       ↓ enables
BRIDGE 4: [Self-Efficacy] — Middle
Evidence: [Peer-level proof — same starting point, succeeded]
Installs: "[I can execute this — the attribution is correct]"
       ↓ enables
BRIDGE 5: [Fit + Product] — Upper
...
       ↓ arrives at
MECHANISM + SELF-EFFICACY BELIEF: "[This works AND I can do it]"
       ↓ produces
PURCHASE DECISION
```

**Toward-Market Sequence:**
```
BRIDGE 1: [Category Permission] — Foundation
Evidence: [Community visibility — demographic range]
Installs: "[This world exists for people like me]"
       ↓ enables
BRIDGE 2: [Self-Level Permission] — Middle
Evidence: [Mirror testimony — nearly identical starting point]
Installs: "[Specifically someone like ME belongs here]"
       ↓ enables
BRIDGE 3: [Temporal Permission] — Middle/Upper
Evidence: [Late-starter story — advantage of starting now]
Installs: "[Starting now is not a disadvantage]"
       ↓ enables
BRIDGE 4: [Worthiness/Investment] — Upper
Evidence: [Permission story — overcame "just for me" scruple]
Installs: "[Investing in this for me is legitimate]"
       ↓ arrives at
IDENTITY CLAIM: "[I am this kind of person and I'm ready to invest]"
       ↓ produces
ENROLLMENT DECISION
```

**Hybrid Sequence:**
```
PARALLEL FOUNDATION LAYER:
BRIDGE 1A: [Attribution] — Foundation (Mechanism chain)
BRIDGE 1B: [Category Permission] — Foundation (Identity chain)
[These CAN run in parallel — neither depends on the other]
       ↓ both enable
CONVERGENCE BRIDGE 2: [Dual-Function Case Study]
Evidence: [Shows mechanism credibility + identity claim in one story]
Installs: "[Both 'this works' AND 'for someone like me' simultaneously]"
       ↓ enables
[Continue with remaining middle bridges from both chains]
       ↓ arrives at
DUAL ACTIVATION: "[This works AND I'm the right person for it]"
       ↓ produces
PURCHASE DECISION
```

---

## COMPLETE OUTPUT DOCUMENT

**File: `Belief-Gap-Analysis-[Market].md`**

---

### EXECUTIVE SUMMARY

**The Chasm:** [One paragraph describing the distance from Point A to Point B — framed in zone-appropriate language]

**Number of Bridges Required:** [X total]
- Foundation bridges: [Count]
- Middle bridges: [Count]
- Upper bridges: [Count]
- Capstone bridges: [Count]
- [Hybrid only] Dual-function bridges: [Count]

**Critical Path:** [Shortest viable sequence]
**Biggest Obstacle:** [The belief most resistant to change and why]
**Highest-Leverage Bridge:** [The belief that, if established, unblocks the most others — often the Core Concept]
**[Hybrid only] Dual Bridge Dependency Direction:** [Which chain must open first, or whether parallel is possible]

---

### SECTION 1: COMPLETE GAP INVENTORY
[All gaps per Step 1 — minimum 8, target 10-14]

---

### SECTION 2: DEPENDENCY CHAIN MAP
[Full bridge architecture — Foundation, Middle, Upper, Capstone]

[Hybrid only: Include the Dual Bridge Dependency section from Step 3]

---

### SECTION 3: OPTIMAL BRIDGE SEQUENCE
[The critical path with detailed guidance for each step]

For each step:

**STEP [N]: [Bridge Name]** ([Layer])
- Timing: [Where this appears in the sequence / what marketing context]
- Message Focus: "[Core message/idea/story that builds this bridge]"
- Proof Elements: [Specific proof #1, #2]
- Evidence Type: [Story / Demonstration / Logic / Mirror / Community visibility]
- Demographic Specificity: [How closely must the proof match the prospect's situation?]
- Transition to Next: "[How this naturally leads to the next bridge]"
- Success Indicator: Prospect thinks: "[Internal statement that signals this bridge has landed]"
- If This Fails: [What keeps them stuck / which dimension of the buying state is still incomplete]

---

### SECTION 4: EVIDENCE SPECIFICATION
[Evidence library — per Step 4]

**[Toward and Hybrid zones only] PRIORITY MIRROR BRIEF:**

The single most important piece of social proof for this market:

Person profile: [Exact demographics — age, background, prior experience, specific doubt they had]
What they need to share:
1. Where they were (starting point matching the prospect)
2. The specific doubt that almost stopped them
3. What shifted (the bridge that landed)
4. What they found on the other side
5. How they describe themselves now (the identity claim, or the mechanism they trust)

---

### SECTION 5: INTERFERENCE PATTERNS
[All blocking beliefs and fear-based resistance, with correction strategies]

For each major interference:
- The specific belief form it takes in this market
- What created it
- What zone-appropriate correction looks like

---

### SECTION 6: PARALLEL vs. SEQUENTIAL BRIDGES
- Which bridges can be built simultaneously (and why they don't create conflict)
- Which MUST be sequential (and what breaks if the sequence is violated)
- [Hybrid only] Which mechanism bridges and identity bridges can be built in parallel vs. which are sequential

---

### SECTION 7: CONTENT MAPPING
[Map each bridge to the specific marketing content needed for the specified context]

For each bridge:
- Content format: [Email / Video / Testimonial / Case study / Logic explanation / Demonstration / Community tour]
- Opening frame: [How to introduce it so it lands on the right type of doubt]
- Core evidence: [Specific proof to include]
- Belief installed: [The specific gap closed]
- Transition: [How this opens the door to the next bridge]

---

### SECTION 8: THE MASTER BRIDGE

**For Away Markets:** Identify which single mechanism reframe, if established, shortens or eliminates multiple other bridges. This is almost always the attribution shift + mechanism differentiation combined. Show which other bridges it shortens or replaces.

**For Toward Markets:** Identify which single identity permission shift, if established, shortens or eliminates multiple other bridges. This is almost always the category-level permission bridge. Show the downstream unlocking effect.

**For Hybrid Markets:** Identify the single evidence piece that advances BOTH chains simultaneously. Show which bridges in each chain it shortens or replaces. This is the highest-leverage asset in the entire content strategy.

---

## QUALITY GATE

Before saving:

- [ ] Spectrum badge present
- [ ] market-context.md read (or manual input collected)
- [ ] Gap inventory has 8-14 gaps (not 3-4 surface beliefs)
- [ ] Every gap is framed correctly for zone (away: mechanism/attribution; toward: identity permission — no "will this work?" framing in toward zones)
- [ ] Dependency chain is logically sound (foundation before middle before upper)
- [ ] Evidence types are zone-appropriate (mirrors for toward, peer proof for away, dual-function cases for hybrid)
- [ ] [Hybrid only] Dual Bridge Dependency section present and complete
- [ ] [Hybrid only] Direction of dependency mapped (which chain unlocks which)
- [ ] Critical path identified (minimum viable sequence)
- [ ] Master Bridge identified with downstream unlocking effect shown
- [ ] Language calibrated to zone (away: attribution, mechanism language; toward: identity permission language; hybrid: both)
- [ ] Content mapping exists for the specified marketing context
- [ ] Output saved to file

---

## TROUBLESHOOTING GUIDE

**"Prospects aren't crossing Bridge #X"**
- Is the prerequisite bridge solid? (Test it separately)
- Is the proof type wrong? (Logic when mirror needed, or vice versa)
- Is the bridge too big? (Break into 2-3 smaller bridges)
- [Hybrid] Are you trying to cross an identity bridge before mechanism foundation is laid, or vice versa?

**"Prospects cross bridges but still don't buy"**
- Is Point B definition complete? (Review — may have defined an incomplete Point B)
- Is there a hidden gap? (Look specifically for identity/worthiness gaps in away markets; look for timing/urgency gaps in toward markets)
- Are bridges solid or surface-accepted?

**"Toward: Prospects engage with content but don't buy"**
- Is category-level permission solid? (They may enjoy content without making the identity claim)
- Is the mirror demographic close enough?
- Is the capstone bridge missing? (Investment permission — not just aspiration)

**"Hybrid: Mechanism proof isn't helping conversion"**
- Check whether identity permission is established first
- If the prospect doesn't believe they belong, mechanism proof feels irrelevant — "that might work for someone, but not for someone like me"

**"Sequence feels too long"**
- Can any bridges be combined (parallel build)?
- Is there a Master Bridge / Core Concept that shortcuts multiple steps?
- [Hybrid] Is there a dual-function case study that advances both chains at once?

---

## HOW THIS CONNECTS DOWNSTREAM

- **zp-buying-state** → Point B from zp-buying-state IS the destination for this analysis. The gap inventory maps how to GET there.
- **zp-usp** → The USP is the Point B expressed as a promise. Every bridge must serve the USP's promise. If a bridge doesn't move toward the USP, question its priority.
- **zp-desire-mapper** → The L4 gate type (Self-Efficacy / Identity Permission / Dual Gate) from the desire map determines which gap types dominate this analysis.
- **Copywriting skills** → Each bridge = one section of a sales page, webinar, or email sequence
- **Webinar structure** → Foundation bridges appear in content sections; upper bridges in transition; capstone bridges in close
- **Testimonial acquisition** → Evidence specifications become briefs for collecting the right proof from existing customers
- **Core Concept** → If generated, identify which bridge it is and show its multiplier effect across the dependency chain
