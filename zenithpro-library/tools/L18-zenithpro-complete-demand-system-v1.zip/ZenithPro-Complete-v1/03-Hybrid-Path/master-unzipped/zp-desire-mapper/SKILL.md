---
name: zp-desire-mapper
description: "Unified ZenithPro desire mapping skill. Maps the complete desire hierarchy for ANY market — automatically calibrated to the market's motivation spectrum. Pure away markets get pain-weighted L1-L4 architecture. Pure toward markets get aspiration-weighted architecture. Hybrid markets get proportionally blended desire maps with both Away and Toward channel maps. Always includes Aspiration Stratigraphy (surface/middle/deep) alongside Pain Stratigraphy for full-spectrum intelligence. Reads market-context.md automatically. Part of ZenithPro Unified System."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Unified, Force Multiplier, Connect the Dots]
interface:
  invoke: "/zp-desire-mapper [business or market]"
  called_by: [user, zp-demand-architect, motivation-spectrum-analyzer]
  outputs_to: [project folder]
---

# ZP Desire Mapper

Maps the complete desire hierarchy for ANY market, automatically calibrated to the market's motivation spectrum. The L4 label, channel maps, and stratigraphy type all adapt based on spectrum zone.

---

## LAYER 1: INVARIANTS

1. **Read market-context.md from the project folder before running.** If not found, prompt the user to run motivation-spectrum-analyzer first OR accept manual spectrum input in this format: "Away: X% / Toward: Y%".
2. **Display the spectrum badge at the top of every output.** No exceptions.
3. **L1 desires are NEVER created — they are identified.** Reese's 16 desires are empirically established. Map which ones are active for this market, not which ones would be convenient.
4. **Each level of the hierarchy must logically connect to the next.** L2 channels L1. L3 channels L2. L4 produces demand. A gap at any level = a gap in the marketing.
5. **L4 label adapts to the spectrum:** "Self-Efficacy" for away-heavy markets (85%+ Away), "Identity Permission" for toward-heavy markets (85%+ Toward), "Dual Gate" for hybrid zones (45-84% either direction).
6. **Every claim about desire channeling must be grounded in actual market evidence** — not assumptions. Use reviews, testimonials, community posts, forum language.
7. **Aspiration Stratigraphy is always included** — even in Pure Away markets. Away markets have toward elements; mapping them adds intelligence. The weight and prominence of Stratigraphy shifts by zone.
8. **Save all outputs to files.** Never deliver analysis only in chat.

---

## PURPOSE

Answers the fundamental question that precedes all ZenithPro work:

> "Which of the 16 unchangeable human desires drives this market — and through what belief architecture does desire channel into demand — calibrated to whether they're moving AWAY from pain, TOWARD aspiration, or both simultaneously?"

The channeling mechanism changes by spectrum zone:

- **Pure Away:** Pain → Category → Product → Self-Efficacy → Buy
- **Pure Toward:** Aspiration → Category → Product → Identity Permission → Buy
- **Hybrid:** Both channels operate simultaneously. The Dual Gate asks "Can this work for me?" AND "Is this version of me available to me?" Both must open.

**Output use:** The completed desire map becomes the master brief for all downstream ZenithPro work — buying state definition, belief gap mapping, USP generation, avatar research, and messaging.

---

## INPUTS

Gather from the user before running:

1. **Business/product name** and brief description
2. **Target market description** (2-3 sentences — who they are, what they face or aspire to)
3. **Avatar type** (specific role/demographic — or "identify for me")
4. **Any existing customer research** — testimonials, reviews, community posts, survey data (optional but significantly improves quality)
5. **Output folder path** (ask if not specified)
6. **Spectrum** (auto-read from market-context.md — or prompt for manual input if file not found)

---

## SPECTRUM BADGE

Display this at the top of every output, populated from market-context.md:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MARKET: [name] | [X]% Away / [Y]% Toward | [Zone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## FRAMEWORK: THE THREE SYNTHESES

### Synthesis 1: Reese's 16 Basic Desires (Level 1)

Scientific L1 desires — each person has all 16 but at different intensities. UNCHANGEABLE.

| Desire | Core Drive | Away Expression | Toward Expression |
|--------|-----------|-----------------|------------------|
| Power | Influence, achievement, leadership | Escape powerlessness / reclaim control | Creative power — make something from nothing |
| Independence | Freedom, autonomy, self-reliance | Escape constraint / stop depending on others | Create on own terms, at own pace |
| Curiosity | Learning, truth-seeking, mental stimulation | Escape confusion / find the real answer | Drive to learn to SEE or think differently |
| Acceptance | Belonging, approval, social connection | Escape rejection / stop feeling excluded | Be seen as someone who creates; earn an identity |
| Order | Organization, certainty, predictability | Escape chaos / stop feeling overwhelmed | Mastery — satisfaction of skill becoming reliable |
| Saving | Wealth preservation, frugality | Escape financial fear / stop losing money | Not typically primary in approach markets |
| Honor | Integrity, loyalty, moral code | Escape shame / restore integrity | Creating as a way of honoring a tradition or craft |
| Idealism | Justice, equality, cause-driven meaning | Escape injustice / fix what's broken | Art/craft as a higher value; preserving beauty |
| Social Contact | Companionship, friendship, camaraderie | Escape isolation / stop going it alone | Communities of shared passion; belonging to a tribe |
| Family | Parenting, legacy, generational thinking | Escape inadequacy as a provider/parent | Creating something to pass down |
| Status | Prestige, reputation, recognition | Escape irrelevance / stop being overlooked | "I'm an artist" — the identity claim |
| Vengeance | Competition, victory | Escape defeat / prove doubters wrong | Not typically primary in approach markets |
| Romance | Beauty, partnership, attraction | Escape loneliness / stop feeling unattractive | Beauty-seeking; aesthetic experience of craft |
| Eating | Pleasure, comfort, sensory experience | Escape deprivation / stop suffering | Flow state pleasure; sensory experience of craft |
| Physical Activity | Health, strength, vitality | Escape deterioration / reclaim physical capacity | Not typically primary unless craft is physical |
| Tranquility | Safety, peace, freedom from anxiety | Escape anxiety and overwhelm | Flow state; meditative absorption; presence |

### Synthesis 2: Schwartz's Channeling Insight (the bridge)

Desires don't create demand on their own. Between L1 and purchase is a channeling process — a specific belief structure that directs desire toward a particular solution. The direction of the channel (away from pain vs. toward aspiration) is determined by the spectrum.

### Synthesis 3: D3 Belief Architecture (Levels 2-4) — Spectrum-Adaptive

- **L2: Category Beliefs** — "This type of solution can [help me fix this / help me become who I want to be]" — framing shifts by zone
- **L3: Product Beliefs** — "This specific product is right for someone in my situation"
- **L4: [Self-Efficacy / Identity Permission / Dual Gate]** — gate label and content adapt to spectrum zone (see Zone Behavior section)

**The unified formula: Desire + Belief = Demand** (direction calibrated to spectrum)

---

## ZONE BEHAVIOR

### Zone: Pure Away (85-100% Away)

**Primary architecture:** Run the full away-market desire hierarchy.

- L1 identification: Pain-weighted desires — which desires are being violated, suppressed, or frustrated
- L4 label: **Self-Efficacy** — "Can I execute this despite past failures?"
- Channel maps: Away-direction maps (pain → category → product → self-belief → buy)
- Pain Stratigraphy: Full three-layer mapping (surface complaint / middle frustration / deep wound)
- Aspiration Stratigraphy: **Brief section** — even away markets have toward elements. Map the suppressed aspirations that exist underneath the pain. These are not primary drivers but add depth to messaging.
- L4 question: "Will this work for me?"

### Zone: Away-Dominant (60-84% Away)

**Primary architecture:** Pain desire hierarchy with toward injections.

- L1: Pain-weighted primary desires + identify which secondary desires have approach orientation
- L4 label: **Self-Efficacy** (primary) with identity permission noted as secondary gate
- Channel maps: Full away channel maps (minimum 2) + ONE toward channel map alongside them
- Pain Stratigraphy: Full three-layer mapping
- Aspiration Stratigraphy: Moderate section — show the toward thread that runs beneath the away motivation
- Toward injections at 3-4 points: (1) in L1 secondary desires, (2) in one channel map, (3) in the aspiration stratigraphy section, (4) in strategic implications

### Zone: True Hybrid (45-59% either)

**Primary architecture:** Equal weight to both pain AND aspiration desire hierarchies.

- L1: Full identification of both pain-weighted and approach-weighted desires for the same desires (the same desire can be felt in both directions — map both)
- L4 label: **Dual Gate** — "Can this work for me AND is this version of me actually available to me?" Both questions must be answered.
- Channel maps: Full away channel maps AND full toward channel maps — equal representation
- Pain Stratigraphy: Full mapping
- Aspiration Stratigraphy: Full mapping — equal weight to Pain Stratigraphy
- Hybrid note in each channel map: show how the away and toward channels converge at L4 into the Dual Gate

### Zone: Toward-Dominant (60-84% Toward)

**Primary architecture:** Aspiration desire hierarchy with away injections.

- L1: Aspiration-weighted primary desires + identify which secondary desires carry pain orientation
- L4 label: **Identity Permission** (primary) with self-efficacy noted as secondary gate
- Channel maps: Full toward channel maps (minimum 2) + ONE away channel map
- Aspiration Stratigraphy: Full three-layer mapping (surface interest / middle identity desire / deep existential layer)
- Pain Stratigraphy: Brief section — acknowledge the away elements without centering them
- Away injections at 2-3 points: (1) brief pain acknowledgment in executive summary, (2) one away channel map, (3) pain stratigraphy brief section

### Zone: Pure Toward (85-100% Toward)

**Primary architecture:** Run the full toward-market aspiration hierarchy.

- L1 identification: Approach-weighted desires — which desires are being moved toward, what is being sought
- L4 label: **Identity Permission** — "Is this version of me actually available to me?"
- Channel maps: Toward-direction maps (aspiration → category → product → identity permission → buy)
- Aspiration Stratigraphy: Full three-layer mapping (surface / middle / deep)
- Pain Stratigraphy: **Brief section** — even toward markets have away elements. Map the pain acknowledgment briefly. These are not primary drivers.
- L4 question: "Is the person I want to become available to someone like me?"

---

## EXECUTION PROTOCOL

### Phase 1: Spectrum Read

Read market-context.md. Extract: Market name, Away%, Toward%, Zone, Confidence, Primary Evidence. If not found: prompt for manual input or run motivation-spectrum-analyzer.

Display spectrum badge.

### Phase 2: L1 Desire Identification

Based on zone, weight the identification toward pain expression, approach expression, or both:

1. **Primary L1 desires** — top 2-3 that drive this market most powerfully
2. **Secondary L1 desires** — supporting desires that amplify the primary
3. **Suppressed desires** — desires the market holds but won't state publicly (often most powerful)

For each primary desire:
- How does this desire manifest in THIS market at its current spectrum position?
- Away expression: What violation/suppression is felt?
- Toward expression: What aspiration/pull is present?
- What would they sacrifice to satisfy this desire?
- Evidence: Ground in specific market language, reviews, testimonials, forum posts

### Phase 3: Stratigraphy Mapping

**Pain Stratigraphy** (weighted by zone — full for Pure Away, brief for Pure Toward):

| Layer | What It Sounds Like | What It Actually Means |
|-------|--------------------|-----------------------|
| Surface | "I need to fix this problem" | Visible complaint, low emotional weight |
| Middle | "I've tried everything and nothing works" | Frustrated, starting to doubt themselves |
| Deep | "I wonder if I'm just not capable of this" | Identity wound, highest purchase motivation |

**Aspiration Stratigraphy** (weighted by zone — full for Pure Toward, brief for Pure Away):

| Layer | What It Sounds Like | What It Actually Means |
|-------|--------------------|-----------------------|
| Surface | "That looks interesting, I'd like to try it" | Curiosity, low commitment |
| Middle | "I want to be someone who does/has this" | Identity desire, moderate investment |
| Deep | "I want purpose, expression, meaning" | Existential need, highest purchase motivation |

For each stratigraphy layer appropriate to zone: Identify the specific language this market uses, what content reaches them at this depth, how far below the surface most category marketing operates.

### Phase 4: L2 Category Belief Mapping

For each primary L1 desire:

1. What category of solution does this market believe can address their away-from/toward-to drive?
2. What limiting L2 beliefs block this? (skepticism, prior disappointment, category distrust)
3. What enabling L2 beliefs must exist for demand to flow?
4. Market sophistication level — how many times have they tried something in this category?

### Phase 5: L3 Product Belief Mapping

1. What specific product beliefs are required for purchase?
   - *Fit belief:* "This was designed for someone in my exact situation"
   - *Method/approach belief:* "This methodology is different from what I've tried"
   - *Community belief:* "The people in this program are people I want to be around"
2. What L3 beliefs are blocking purchase right now?
   - Prior abandonment / past failures in category
   - Skepticism about differentiation
   - Doubt about fit for their specific situation

### Phase 6: L4 Gate Mapping

**Map according to zone label:**

**Self-Efficacy (Pure Away / Away-Dominant):**
- What do they believe about their ability to implement?
- What past failure patterns undermine self-efficacy?
- What attribution shift must occur (from "I'm broken" to "I used the wrong method")?

**Identity Permission (Pure Toward / Toward-Dominant):**
- What identity prohibitions block them? ("I'm not creative" / "Real [X] start young" / "I'm too old")
- What gap prohibitions exist? ("The distance between me and who I want to be is uncrossable")
- Required identity permission: what must become true for the aspired identity to feel available?
- What creates this shift: NOT a better explanation — a MIRROR (demographically identical person who now lives the identity)

**Dual Gate (True Hybrid):**
- Map BOTH the self-efficacy gate AND the identity permission gate
- Which gate is harder to open for this market? Which must open first?
- What single piece of evidence addresses both gates simultaneously?

### Phase 7: Channel Maps

Produce visual channel maps — quantity and direction based on zone (see Zone Behavior):

**Away Channel Map:**
```
L1 PAIN DESIRE: [Desire name — what they're moving AWAY from]
       ↓ channels through
L2 CATEGORY BELIEF: "[This type of solution can fix/escape X]"
       ↓ channels through
L3 PRODUCT BELIEF: "[This specific product is right for someone like me]"
       ↓ channels through
L4 SELF-EFFICACY: "[I can execute this despite my past failures]"
       ↓ produces
DEMAND: [Purchase becomes inevitable when all 4 align]
```

**Toward Channel Map:**
```
L1 ASPIRATION: [Desire name — what they're moving TOWARD]
       ↓ channels through
L2 CATEGORY BELIEF: "[This type of solution can help me become X]"
       ↓ channels through
L3 PRODUCT BELIEF: "[This specific product is right for someone like me]"
       ↓ channels through
L4 IDENTITY PERMISSION: "[The person I want to become is available to me]"
       ↓ produces
DEMAND: [Purchase becomes inevitable when all 4 align]
```

**Hybrid Channel Map (True Hybrid zone only):**
```
L1 DUAL DESIRE: [Desire felt in both directions — escaping X AND becoming Y]
       ↓ channels through
L2 CATEGORY BELIEF: "[This can both fix X AND help me become Y]"
       ↓ channels through
L3 PRODUCT BELIEF: "[This specific product fits my situation from both angles]"
       ↓ channels through
L4 DUAL GATE: "Can this work for me? [Self-Efficacy] AND Is this version of me available? [Identity Permission]"
       ↓ produces
DEMAND: [Both gates open simultaneously — the rarest and most durable buying state]
```

For each map: identify which level is the STRONGEST existing belief and which level is the WEAKEST LINK where demand is being blocked.

### Phase 8: Gap Analysis

For each channel:
- Where is the channel STRONG? (Existing beliefs already supporting purchase)
- Where is the channel BROKEN? (Missing or blocking beliefs interrupting demand)
- Highest-leverage intervention: the single belief/proof that, if created, would unblock the most demand
- Intervention type: specify exactly what content/proof creates the shift

---

## OUTPUT SPECIFICATION

Save to the specified output folder:

**File: `Desire-Hierarchy-Map-[Market].md`**

Structure:
1. Spectrum Badge
2. Executive Summary (3 sentences: dominant desires, zone-appropriate L4 gate, highest-leverage intervention)
3. L1 Primary Desire Analysis with evidence (weighted by zone)
4. Pain Stratigraphy (depth weighted by zone — full or brief)
5. Aspiration Stratigraphy (depth weighted by zone — full or brief)
6. L2 Category Belief Map (blocking + enabling beliefs)
7. L3 Product Belief Map (blocking + enabling beliefs)
8. L4 Gate Map (labeled correctly for zone — Self-Efficacy / Identity Permission / Dual Gate)
9. Complete Channel Maps (quantity and direction per zone)
10. Gap Analysis with priority interventions
11. Strategic Implications for downstream work

**Target length:** 1,500-3,000 words. Depth on 2-3 most powerful desires beats breadth on all 16.

**Language rule:** Calibrate language to spectrum zone. Pure Away: avoidance language is appropriate. Pure Toward: never use avoidance language. Hybrid: mirror the split — away language for the away channel, aspiration language for the toward channel.

---

## QUALITY GATE

Before saving, verify:

- [ ] Spectrum badge present at top of output
- [ ] market-context.md was read (or manual input collected)
- [ ] Zone correctly identified and behavior implemented (not default Pure Away behavior applied to all)
- [ ] Every L1 desire grounded in real market evidence
- [ ] L4 label correct for zone (Self-Efficacy / Identity Permission / Dual Gate)
- [ ] Pain Stratigraphy present (full or brief per zone)
- [ ] Aspiration Stratigraphy present (full or brief per zone)
- [ ] Channel maps correct in direction and quantity for zone
- [ ] Gap Analysis identifies highest-leverage intervention
- [ ] Output saved to file

---

## STRATEGIC IMPLICATIONS TEMPLATE

The final section must answer these questions, calibrated to zone:

**Away-weighted zones:**
1. What is the deepest wound (Pain Stratigraphy deep layer) that the market needs to see reflected back at them?
2. What is the attribution shift that unblocks self-efficacy? (From "I'm broken" to "I used the wrong method")
3. What social proof (peer-level, not aspirational) would create "that person is like me" recognition?
4. What copy direction does this suggest? ("Are you tired of X?" / "Here's why X keeps happening")

**Toward-weighted zones:**
1. What is the dominant aspiration this market needs to see reflected? (Deep layer of Stratigraphy)
2. What is the identity permission gap blocking the most demand?
3. What is the single most powerful mirror that would unblock it? (Specific demographic + transformation)
4. What copy direction does this suggest? ("Watch this..." / "She learned in 6 weeks...")

**Hybrid zones:**
1. Which direction (away or toward) is dominant in this market's self-narrative?
2. What single piece of messaging addresses both the escape motivation AND the arrival aspiration?
3. How does the Dual Gate dependency chain work — which gate must open first?

---

## HOW THIS CONNECTS DOWNSTREAM

This map becomes the master input for:
- **zp-buying-state** → The desire hierarchy defines what psychological state must be reached for purchase to be automatic
- **zp-belief-gap** → Uses the L4 gate type and desire structure to map the exact belief journey
- **zp-usp** → USP must connect to dominant L1 desire and resolve the primary L4 gate
- **motivation-spectrum-analyzer** → Confirms or refines the spectrum reading for this market
- **avatar-excavation / aspiration-avatar-excavation** → Which avatar has which desire intensities and gate types
- **mimetic-market-intelligence** → Compare desire map to what competitors are mediating
