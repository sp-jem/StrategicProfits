---
name: zp-concept-generator
description: "Unified ZenithPro Core Concept generator. Produces the paradigm-level reframe that makes buying the obvious choice, calibrated to the motivation spectrum. Away-heavy: 'THAT'S why nothing worked' structural insight that explains failures and restores hope. Toward-heavy: 'You CAN do this' permission concept that opens identity access and removes gatekeeping. Hybrid: the new Hybrid Core Concept that addresses both the structural reason for the pain AND the identity that resolves it — the path OUT of the pain IS the transformation. 5 formula types for each zone. Validation scoring adapts to spectrum. Reads market-context.md automatically. Part of ZenithPro Unified System."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, ZenithPro-Hybrid-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/zp-concept-generator [market or avatar]"
  called_by: [user, hybrid-demand-architect, toward-demand-architect, demand-architect]
  outputs_to: [project folder]
dependencies:
  - motivation-spectrum-analyzer (required — must provide market-context.md)
  - failure-pattern-forensics (required for away-heavy zones)
  - progression-pattern-analysis (required for toward-heavy zones)
  - toward-desire-mapper (required for toward-heavy zones)
  - demand-desire-mapper (required for away-heavy zones)
---

# ZenithPro Concept Generator

The Core Concept is the highest-leverage intellectual property in demand creation. It is the single belief that, once accepted, makes buying the obvious choice. This skill is the unified generator — producing that belief calibrated to where the market actually sits on the human motivation spectrum.

---

## LAYER 1: INVARIANTS

1. **A Core Concept is a belief intervention, not a marketing claim.** If it sounds like something you would put in an ad headline, it is not a Core Concept — it is a benefit statement. Discard and regenerate.
2. **The master test is non-negotiable.** For every concept generated: "If a prospect believed this, would buying become the obvious choice?" If the answer is no, discard before scoring.
3. **The zone determines the TYPE of belief intervention, not its quality.** An away-zone concept is not better than a toward-zone concept. They are different psychological mechanisms targeting different buyer states. Both must be equally precise and powerful.
4. **Specificity is mandatory.** Vague reframes do not land. "You've been playing the wrong game" is incomplete without the specific game and the specific reason it's wrong for this market.
5. **Read market-context.md before generating anything.** The spectrum score is not optional context — it is the architectural decision that determines which formulas to run and how to score.
6. **Save all outputs to files.** Never deliver only in chat.

---

## PURPOSE

### What a Core Concept Does

In away-motivated markets, the Core Concept creates the moment: **"Oh my God. THAT'S why nothing has worked."**

In toward-motivated markets, the Core Concept (as Permission Concept) creates: **"Oh my God. I CAN actually do this."**

In hybrid markets, the Hybrid Core Concept creates both simultaneously: **"THAT'S why it hasn't worked — and the path out is exactly who I've wanted to become."**

These are three fundamentally different psychological mechanisms. The away shift is about the solution architecture the market has been missing. The toward shift is about the self — specifically, whether a desired identity is genuinely available. The hybrid shift addresses both the structural reason for the pain AND the identity that resolves it — revealing them as the same underlying dynamic.

### The Output Use

The Core Concept from this skill drives:
- Headline strategy and webinar opening
- Email subject lines and hook architecture
- Sales page lead and structural argument
- Offer presentation framing
- Ad creative direction
- Every downstream skill in the ZenithPro pipeline

Get this right, and everything downstream becomes coherent. Get it wrong, and technically correct downstream work will still fail to convert.

---

## STEP 0: SPECTRUM CONTEXT LOADING

**Before generating any concept, read and confirm the spectrum context.**

### 0a. Locate market-context.md

Look for `market-context.md` in the current project folder. It follows this format:

```
**Away:** [X]%
**Toward:** [Y]%
**Zone:** [Pure Away / Away-Dominant / True Hybrid / Toward-Dominant / Pure Toward]
```

If market-context.md is not present, stop and run `/motivation-spectrum-analyzer` first. Do not proceed without a spectrum score.

### 0b. Set Generation Mode

Based on the zone, set the mode:

| Zone | Away % | Generation Mode | Primary Formula Set |
|------|--------|-----------------|---------------------|
| Pure Away | 85-100% | Away-Only | 5 Away formulas |
| Away-Dominant | 60-84% | Away-Primary | 5 Away formulas + aspiration addendum |
| True Hybrid | 45-59% either | Full Hybrid | 5 Hybrid formulas |
| Toward-Dominant | 60-84% Toward | Toward-Primary | 5 Toward formulas + pain acknowledgment |
| Pure Toward | 85-100% Toward | Toward-Only | 5 Toward formulas |

### 0c. Display Spectrum Badge

Every output header must display:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MARKET: [name] | [X]% Away / [Y]% Toward | [Zone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## STEP 1: PRELIMINARY ANALYSIS

Run the analysis appropriate to the zone before generating concepts. This is not optional — concepts generated without this analysis will be generic and will not pass the master test.

### For Away-Heavy Zones (Pure Away, Away-Dominant)

Answer these three questions explicitly. The quality of the concepts depends entirely on the quality of these answers.

**The Structural Villain:**
What is the actual structural reason for this market's failures? Not the surface problem they complain about — the underlying architecture that makes their approach structurally incapable of working. Name it with unexpected precision.

**The Failed Pattern:**
What have they tried repeatedly that should work but doesn't? How much have they invested? What approach does everyone default to that the structural villain makes futile?

**The Master Question (away):**
> "What would need to be true about their problem for this solution to be the ONLY logical response?"

Write this out explicitly. All 5 concepts must point toward this truth from different angles.

---

### For Toward-Heavy Zones (Toward-Dominant, Pure Toward)

**The Identity Prohibitions:**
List the specific beliefs that block identity adoption in this market. Write them in first-person market language:
- "I'm not [X] enough to [aspiration]"
- "People like me don't do [aspiration]"
- "I'd need [gatekeeping requirement] first"

For each prohibition, identify: the demographic assumption embedded in it, the gatekeeping belief it encodes, what inversion would dissolve it.

**The Inversion:**
For each prohibition, find the factual truth that inverts the causality — not an argument against the prohibition, but a revelation that the prohibition has it backwards.

**The Master Question (toward):**
> "What would need to become true about WHO THEY ARE — not about what they can learn — for the aspiration to feel genuinely available?"

Write this out. All 5 concepts must create that shift from different angles.

---

### For True Hybrid Zone

Run both analyses above. Then find:

**The Overlap Point:**
What is the SAME underlying L1 desire expressing itself as both pain (away) and aspiration (toward)? This overlap is the core of the hybrid concept.

Format it as: "The desire for [L1 desire] is expressing as both [away: pain description] and [toward: aspiration description]."

**The Master Question (hybrid):**
> "What structural insight about this market would simultaneously explain why the pain persists AND reveal that the path out is exactly the identity they've been wanting to claim?"

---

## STEP 2: CONCEPT GENERATION BY ZONE

Generate 5 candidates using the appropriate formula set for the zone.

---

### AWAY FORMULAS (Pure Away and Away-Dominant)

Generate one concept using each formula.

---

**Formula A1: The Villain Reveal**
> "The real reason [pain] isn't [assumed cause] — it's [structural villain] that makes [assumed cause] structurally incapable of working."

Process:
1. Name what they think is causing their pain (surface-level assumed cause)
2. Reveal the actual structural villain hiding beneath it
3. Show how the assumed cause is actually a symptom, not the source
4. Name the villain with unexpected precision — give it a label they'll repeat

Quality check: Would accepting this make them immediately stop blaming themselves or their effort?

---

**Formula A2: False Solution Exposure**
> "Every [category of solution] you've tried addresses [surface issue]. None of them address [structural root] — which means every attempt makes [hidden dynamic] worse, not better."

Process:
1. Identify the category of solutions they've defaulted to
2. Name what those solutions actually address (the surface)
3. Reveal what none of them address (the structural root)
4. Show the counterintuitive dynamic: trying harder at the wrong thing compounds the problem

Quality check: Does this explain why smart, motivated people in this market keep failing?

---

**Formula A3: Game Reframe**
> "You've been playing [wrong game] — which was designed for [a different player, a different era, or different conditions]. The game that actually wins is [new game], and it has completely different rules."

Process:
1. Name the game they think they're playing (specific and recognizable)
2. Show why that game is wrong — designed for someone or something other than them
3. Name the game that actually wins with unexpected specificity
4. Show why the rules of the winning game are counter to everything they've been doing

Quality check: Does this make every past effort suddenly make sense as the wrong game? Does it make the new game feel genuinely learnable?

---

**Formula A4: Permission Restoration**
> "The reason [shame-inducing failure] happened isn't proof that you can't — it's proof that [structural reason] made success structurally impossible from the start. You were set up to fail by the approach, not by your capability."

Process:
1. Name the failure that creates the most shame or self-blame in this market
2. Identify the structural reason that made that failure inevitable regardless of effort or capability
3. Reframe: the failure is evidence of the broken approach, not broken capability
4. Restore: what becomes possible once the structural flaw is corrected

Quality check: Does this move a prospect from shame to hope without them feeling patronized? Does it honor their intelligence while redirecting their self-blame?

---

**Formula A5: The Real Problem**
> "What you've been calling [their label for the problem] is actually a symptom of [structural issue]. Until you address [structural issue], solving [their label] will always be temporary — like refilling a leaking bucket."

Process:
1. Name the label they use for their problem (their exact language)
2. Reveal it as a symptom of something deeper and structural
3. Show why addressing the symptom will always be temporary
4. Name the structural issue with precision — not vague, not abstract

Quality check: Does the vivid analogy make the structural insight immediately obvious? Would they repeat this analogy to explain their own situation?

---

**Away-Dominant Addendum (Away-Dominant zone only):**
After generating 5 away concepts, add this to the strongest 2-3:

> "And here's what becomes possible once [structural villain] is no longer in your way: [specific identity aspiration]. [Structural insight] and [aspiration] are two expressions of the same thing. Fixing one unlocks the other."

This is not a separate concept — it's an amplifier. The away concept explains the past. The addendum opens the future.

---

### TOWARD FORMULAS (Pure Toward and Toward-Dominant)

Generate one concept using each formula.

---

**Formula T1: Hidden Unlock**
> "The reason [aspiration] is MORE accessible to [specific demographic] than [gatekeeping assumption] suggests is [surprising factual truth that inverts the assumed barrier]."

Process:
1. Name the most powerful gatekeeping assumption in this market (what people believe makes them unqualified)
2. Find the factual truth that inverts it — not reassurance, but revelation: the assumed barrier is actually irrelevant or the assumed advantage is actually a disadvantage
3. Make the inversion specific to the demographic of this market
4. State it as a revelation, not an argument — something they can immediately verify against their own experience

Quality check: Does this make someone feel SEEN and invited, not just reassured? The difference is: reassurance argues with the prohibition; revelation shows that the prohibition was never accurate.

---

**Formula T2: Permission Shift**
> "[Assumed prerequisite] isn't what you need to start [aspiration] — it's what you develop BY starting. The permission to begin is unconditional."

Process:
1. Identify the most common prerequisite belief in this market ("I need talent / training / confidence / experience / a certain kind of mind first")
2. Show that this prerequisite is an OUTPUT of the practice, not an input required before starting
3. Name who gets to start without it — specifically, people exactly like this market
4. Make the permission feel like a fact, not an encouragement

Quality check: Does this remove the waiting condition — the "I'll start when I have X" — and make starting now feel immediately valid and honest?

---

**Formula T3: Mastery Bridge**
> "The gap between [where they are] and [who they want to be] is actually [specific dimension] shorter than you think — because [structural reason that makes the gap genuinely shorter, not just more manageable]."

Process:
1. Name the specific gap they perceive — not general inadequacy, but the specific skill or capacity they believe they lack
2. Find the specific, empirically supportable truth about how short a particular dimension of that gap actually is
3. Explain the structural mechanism that makes it shorter — a real reason, not "with the right training"
4. Frame so that starting now becomes the logical response to this shorter gap

Quality check: Does this make the aspiration feel concretely achievable without minimizing it? The distinction: minimizing says "it's not that hard." This formula says "the specific thing you're afraid of is specifically shorter than you believe."

---

**Formula T4: Right Path**
> "Most [category] is designed for [different person — different age, background, aspiration type, or life stage]. [This] is designed specifically for [people in their situation] — and that's not a consolation. It's the right fit."

Process:
1. Identify what most offerings in this category are implicitly designed for — and who that excludes
2. Show that the exclusion is real, not imagined: most instruction in this category does assume things about the student that this market doesn't have or doesn't want
3. Position this approach as explicitly designed for people in their exact situation — with their specific starting point, life context, and aspiration type
4. Make "designed for people like them" feel like a genuine advantage, not a lowered standard

Quality check: Does this make them feel like they've finally found something built for them — not a fallback, but the right fit for who they actually are?

---

**Formula T5: Identity Invitation**
> "The identity of [specific aspiration identity] doesn't require [gatekeeping requirement]. You claim it with [first accessible action]. Everything after that is just being a more experienced [identity]."

Process:
1. Name the practitioner identity they want to claim — specific, not generic ("urban sketcher" not "creative person")
2. Identify the gatekeeping requirement they believe stands between them and that identity
3. Dissolve the requirement — not by arguing, but by revealing the more accurate and immediate earning condition
4. State the first action that earns the identity — something they could do today, or with this program

Quality check: Does this make the identity feel immediately claimable — not someday, but now or with the very next action they take?

---

**Toward-Dominant Pain Acknowledgment (Toward-Dominant zone only):**
After generating 5 toward concepts, add this bridge to the strongest 2-3:

> "The fact that [mild away context — what brought them here] doesn't mean you've missed your window. It means you've arrived at exactly the right moment to become [aspiration identity]."

This is not a full away concept. It's a single sentence that honors the pain signal without dwelling on it — then pivots immediately to aspiration.

---

### HYBRID FORMULAS (True Hybrid zone only)

The Hybrid Core Concept is net-new. It does not come from either pure track. These formulas activate both motivational directions simultaneously within a single reframe.

Generate one concept using each formula.

---

**Formula H1: Structural-Identity Reveal**
> "The reason [pain] persists is [structural explanation]. But the path out isn't just fixing that — it's becoming [identity]. [Pain] and [aspiration] are two expressions of the same thing: the moment you address the structure, the identity follows. And the identity is what makes the fix permanent."

Process:
1. Name the structural reason for the pain with precision (away element)
2. Reveal that the solution is not a fix but a transformation — from current identity to desired identity (toward element)
3. Show that these are not two separate goals — they are the same underlying dynamic seen from two directions
4. Make the insight feel inevitable: once they see this, both the pain explanation AND the aspiration invitation are obvious

Quality check: Read it aloud. Does it speak to both the person in pain AND the person with an aspiration? If it only addresses one direction, rewrite.

---

**Formula H2: Transformation-Through**
> "What you've been experiencing as [pain/problem] is actually [structural dynamic viewed differently]. The solution isn't a fix you apply — it's a transformation from [current identity] to [desired identity]. When the transformation happens, [pain] becomes structurally impossible."

Process:
1. Take the pain they describe and reframe what it structurally IS (not what causes it, but what it actually represents)
2. Show that a fix applied to the current identity will always be temporary — because the current identity regenerates the problem
3. Reveal the transformation as the actual solution: becoming a different kind of person who doesn't create this problem
4. Make the aspiration feel like the escape route, not a separate goal

Quality check: Does the transformation feel like it resolves the pain without requiring the person to first admit the pain is all their fault? The hybrid reframe should restore hope AND open identity permission simultaneously.

---

**Formula H3: Same Dynamic**
> "[Pain experience] and [aspiration] feel like opposites. They're actually the same thing: [underlying desire] expressing itself in two directions. Escape the pain direction, step into the aspiration direction. They're the same movement — you just need to know which direction you're facing."

Process:
1. Name the pain experience in their language
2. Name the aspiration in their language
3. Identify the L1 desire that is active in BOTH directions — the same underlying human want expressing as both pain and aspiration
4. Frame the movement as a single change of direction, not two separate goals to achieve

Quality check: Does the concept make both the pain and the aspiration feel deeply understood? Does it make the solution feel obvious rather than complicated?

---

**Formula H4: The Hidden Bridge**
> "The only reason [pain] continues is the same reason [aspiration] feels impossible: [structural insight that explains both simultaneously]. Address that one thing, and both sides shift at once."

Process:
1. Identify the single structural factor that is causing the pain AND blocking the aspiration — they must be genuinely the same factor
2. Name it with precision — vague structural insights do not land
3. Show how fixing this one thing resolves both the away motivation (pain stops) and the toward motivation (aspiration becomes accessible) simultaneously
4. Make the insight feel like a key that unlocks two doors with one turn

Quality check: Is the structural insight genuinely the same factor for both the pain and the aspiration? If you have to stretch to connect them, it is not a true Hidden Bridge — regenerate.

---

**Formula H5: The Arrival Frame**
> "Solving [problem] and becoming [aspiration identity] aren't two goals. They're one transformation. You don't solve your way to [identity] — you become it, and [problem] dissolves. The person [aspiration identity] describes doesn't have [problem]. That's not a coincidence — it's the whole point."

Process:
1. Name the problem the market is trying to solve (their away motivation)
2. Name the identity they secretly aspire to (their toward motivation)
3. Reveal that these are not sequential — solve problem, THEN become identity — but simultaneous: the identity eliminates the problem because it operates from fundamentally different premises
4. Make the logic feel inevitable: of course [aspiration identity] doesn't have [problem] — the whole architecture is different

Quality check: Does this make the product feel like the most efficient path to BOTH goals simultaneously — not a trade-off between solving a problem and pursuing an aspiration?

---

## STEP 3: VALIDATION SCORING

For each of the 5 generated concepts, score on these six dimensions. Apply them AFTER confirming the concept passes the master test.

**Master test (non-negotiable prerequisite):** "If a prospect believed this, would buying become the obvious choice?" If no — do not score. Rewrite or discard.

---

**Zone-specific pre-scoring test (apply before scoring):**

For away-heavy zones: Does it explain past failures without making the prospect feel stupid? Does it identify a structural villain rather than blaming capability or effort? Does it move the prospect from shame to hope?

For toward-heavy zones: Does it shift a belief about the SELF — not about the solution? Does it create recognition (I've always felt this) rather than persuasion (I'm being argued into this)? Does it make the identity feel immediately claimable?

For hybrid zone: Does it address BOTH the structural reason for the pain AND the identity that resolves it? Does someone nodding at the away insight simultaneously feel pulled toward the identity claim? Do both shifts happen in the same sentence or paragraph?

---

### The Six Scoring Dimensions

**1. Clarity (1-5)**
Can a prospect in this market understand this immediately, on first reading, without prior context?
- 5: Instantly obvious. No explanation needed.
- 4: Understood on first read with minimal mental effort.
- 3: Requires a second read or brief elaboration.
- 2: Confusing to someone unfamiliar with the framing.
- 1: Requires significant explanation before it lands.

**2. Provability (1-5)**
Can the insight be demonstrated with evidence the prospect already has access to or can verify?
- 5: The prospect's own experience proves it before you say another word.
- 4: Can be proven with one strong example or data point.
- 3: Requires a case study or testimonial to make it real.
- 2: Requires significant evidence-building before it feels credible.
- 1: Feels like an assertion that requires faith to accept.

**3. Belief-Shift Power (1-5)**
If believed, does buying become the obvious next action — not just a logical option?
- 5: Not buying becomes irrational. The concept creates urgency on its own.
- 4: Buying feels like the clear next step. The concept makes delay feel expensive.
- 3: Buying feels sensible. The concept creates interest but not urgency.
- 2: The concept is interesting but doesn't clearly point to a specific action.
- 1: Accepting the concept doesn't particularly drive toward any action.

**4. Zone-Appropriate (1-5)**
Does the concept activate the right psychological driver for this zone's motivation profile?
- 5: Precisely calibrated. Could not be more right for this zone.
- 4: Well-calibrated with minor elements from the wrong direction.
- 3: Mostly correct zone but missing the primary psychological driver.
- 2: Partially calibrated — activates the right zone but also creates friction against it.
- 1: Wrong zone. An away concept in a toward market or vice versa.

**5. Surprise Factor (1-5)**
Does it run counter to the existing assumptions this market holds — not just different, but inverted?
- 5: Completely counter-intuitive. Everything they assumed was backwards.
- 4: Meaningfully surprising with a specific inversion that lands.
- 3: Somewhat unexpected. Contains one element they hadn't considered.
- 2: Familiar enough that they've heard something like this before.
- 1: What they already think, restated. No surprise.

**6. Uniqueness (1-5)**
Could this concept, as stated, come from a competitor? Or does it own vocabulary and framing that only this offer can deliver?
- 5: Completely unique. Owns specific language that becomes associated with this brand.
- 4: Mostly unique with one phrase or element that competitors could parallel.
- 3: The structural insight is unique but the language is generic.
- 2: Similar to competitor positioning — could be said by others in this category.
- 1: Generic category positioning. Any competitor could claim this.

**Scoring totals:**
- Maximum: 30
- Recommend: 24 and above
- Revise: 18-23
- Discard: below 18

---

## STEP 4: WINNER SELECTION AND APPLICATION

After scoring all 5 concepts, select the winner and produce the application brief.

### Winner Analysis

State:
1. **The winning concept** (full text)
2. **Why it wins** (which dimensions scored highest and why that matters for this specific market)
3. **How it handles the master test** (if believed, exactly how buying becomes obvious — walk through the logic)

### USP Connection

The Core Concept and the USP are related but different:
- Core Concept = the belief intervention ("if they believe this...")
- USP = the deliverable promise ("...then this product is the only logical response because...")

State explicitly how the winning concept connects to the USP. What does the concept make the USP feel like an inevitable consequence of?

### Marketing Application

**Headline direction:** What kind of headline does this concept suggest? (Question, revelation, contrast, identity claim, villain reveal — be specific)

**Webinar/content hook:** How does this concept open a presentation? Give the opening line or premise.

**Email sequence:** What is the first content piece that installs this belief? Name the subject line and the one-paragraph premise.

**Ad creative direction:** What image/visual represents this concept? What is the hook line that would stop the scroll?

**Objection prevention:** What are the 2-3 objections this concept pre-handles before they're raised? Show how the concept makes each objection irrelevant.

### Concept Ranking

After selecting the winner, rank all 5 by use case:

1. **Strongest for immediate conversion** — which concept would work best in a webinar or sales page close?
2. **Strongest for content and education** — which concept builds the belief best over time through content?
3. **Strongest for virality and sharing** — which concept articulates something the market has always felt but couldn't say?
4. **Strongest for objection prevention** — which concept addresses the deepest skepticism before it's raised?
5. **Strongest for differentiation** — which concept creates a conversation competitors cannot participate in?

---

## OUTPUT FORMAT

**File:** `Core-Concept-[Market].md`

Save to the specified project folder. Use the following structure:

---

```markdown
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MARKET: [name] | [X]% Away / [Y]% Toward | [Zone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# ZenithPro Core Concept — [Market Name]

## PRELIMINARY ANALYSIS

### Structural Villain / Identity Prohibition / Overlap Point
[Zone-appropriate analysis from Step 1]

### Master Question Answer
[The explicit statement of what must be true for this solution to be the only logical response]

---

## THE 5 CONCEPT CANDIDATES

---

### CONCEPT #1: [Memorable Name]
**Formula:** [A1/A2/A3/A4/A5 / T1/T2/T3/T4/T5 / H1/H2/H3/H4/H5]

**The Core Concept:**
> "[Full concept text]"

**Master Test:** [Pass/Fail + one-sentence explanation of why buying becomes obvious if believed]

**Zone-Specific Pre-Score Test:** [Pass/Fail + one-sentence explanation]

**Scoring:**
| Dimension | Score | Note |
|-----------|-------|------|
| Clarity | /5 | |
| Provability | /5 | |
| Belief-Shift Power | /5 | |
| Zone-Appropriate | /5 | |
| Surprise Factor | /5 | |
| Uniqueness | /5 | |
| **TOTAL** | **/30** | |

**Recommendation:** [Recommend / Revise / Discard]

**The Breakdown:**
- Old Reality: [What they believe that this concept displaces]
- New Reality: [What becomes true when they accept the concept]
- Why This Matters: [The cascading implications — what changes when they accept this]

**Proof Architecture:**
- Statistical proof: [Number or data point that supports this]
- Logical proof: [The reasoning that makes it obvious]
- Experiential proof: [Something they've already experienced that validates this]

---

[Repeat for Concepts #2-5]

---

## WINNER

### [Concept Name] — SELECTED

**Full concept text:**
> "[Winning concept]"

**Why it wins:**
[2-3 sentences on which dimensions scored highest and why that matters for this specific market]

**Master test walkthrough:**
[Explicit walk-through: if they believe this → these specific thoughts follow → buying becomes obvious because...]

### USP Connection
[How the winning concept connects to the USP — what does it make the USP feel like an inevitable consequence of?]

### Marketing Application

**Headline direction:**
[Type of headline and suggested direction]

**Webinar/content opening:**
[The opening line or premise for a presentation built on this concept]

**Email sequence hook:**
[Subject line + one-paragraph premise for the first belief-installation email]

**Ad creative direction:**
[Visual concept + hook line]

**Objection prevention:**
- [Objection 1] → [How the concept pre-handles it]
- [Objection 2] → [How the concept pre-handles it]
- [Objection 3] → [How the concept pre-handles it]

### Concept Ranking
1. Strongest for immediate conversion: [Concept name + brief reason]
2. Strongest for content and education: [Concept name + brief reason]
3. Strongest for virality: [Concept name + brief reason]
4. Strongest for objection prevention: [Concept name + brief reason]
5. Strongest for differentiation: [Concept name + brief reason]

---

## QUALITY GATE VERIFICATION

- [ ] market-context.md read — spectrum score confirmed
- [ ] Spectrum badge displayed in header
- [ ] Preliminary analysis completed (zone-appropriate)
- [ ] 5 concepts generated using correct formula set for zone
- [ ] Master test passed for all 5 before scoring
- [ ] Zone-specific pre-score test applied
- [ ] All 6 scoring dimensions completed for each concept
- [ ] Only concepts scoring 24+ recommended
- [ ] Winner selected with explicit USP connection
- [ ] Marketing application brief complete
- [ ] Concept ranking complete
- [ ] Output saved to file
```

---

## QUALITY GATE

Before saving output, confirm all the following:

- [ ] market-context.md was read — spectrum score was not assumed or invented
- [ ] Spectrum badge appears at the top of every output section
- [ ] Preliminary analysis was completed in full for the zone
- [ ] Exactly 5 concepts generated using the correct formula set
- [ ] Every concept passed the master test before being scored
- [ ] Zone-specific pre-score test was applied to every concept
- [ ] All 6 scoring dimensions completed for every concept
- [ ] No concept scoring below 24 was recommended without explicit note about revision path
- [ ] Winner selected with explicit reasoning
- [ ] USP connection stated explicitly
- [ ] Marketing application brief addresses all five categories
- [ ] Concept ranking covers all five use cases
- [ ] Output saved to file (not chat only)

---

## HOW THIS CONNECTS TO THE SYSTEM

**Before this skill:**
- `/motivation-spectrum-analyzer` — provides the market-context.md this skill reads
- `/failure-pattern-forensics` — for away-heavy zones: provides the structural villain and failed pattern analysis
- `/progression-pattern-analysis` — for toward-heavy zones: provides the identity prohibitions and plateau paradoxes
- `/toward-desire-mapper` or `/demand-desire-mapper` — provides desire architecture that the concept must activate

**After this skill:**
- `/zp-usp` — the Core Concept becomes the belief architecture from which the USP is expressed as a deliverable promise
- `/zp-belief-gap` — the winning concept is often the "master bridge" — identify which L2/L3 beliefs it must shift to land
- `/zp-buying-state` — the concept defines the buying state that must be created; the buying state skill builds the path to it
- `/ideal-buying-mindset` (away) or `/ideal-aspiration-mindset` (toward) — the concept is what creates the target mindset when it lands
- **Copywriting skills** — the concept drives the headline, lead, and body copy for all sales materials
- **Webinar skills** — the concept is the paradigm shift moment; the webinar is structured around installing and proving it

**The concept's role in the full pipeline:**
```
motivation-spectrum-analyzer
    → zp-concept-generator     ← THIS SKILL
        → zp-usp
        → zp-belief-gap
        → zp-buying-state
        → [copywriting / webinar skills]
```

The Core Concept is the intellectual center of gravity. Every downstream skill orbits it. Get it wrong, and everything downstream is technically correct but strategically hollow. Get it right, and the entire pipeline coheres.
