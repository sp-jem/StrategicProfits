---
name: zenithpro
description: "The unified ZenithPro demand creation orchestrator. Runs the complete pipeline for ANY market — automatically diagnosing the motivation spectrum and calibrating every output accordingly. Step 0 diagnoses your market (toward/away/hybrid). Steps 1-10 run the full demand creation pipeline with every skill self-adjusting to your market's exact psychology. One command. One pipeline. Every market. Replaces demand-architect, toward-demand-architect, and hybrid-demand-architect. The spectrum score is visible throughout every output."
version: 2.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro]
interface:
  invoke: "/zenithpro [market description]"
  modes: [full, quick, audit, test]
  called_by: [user]
  outputs_to: [project folder]
dependencies:
  - motivation-spectrum-analyzer
  - zp-desire-mapper
  - zp-excavation
  - zp-avatar
  - zp-pattern-analyzer
  - zp-concept-generator
  - zp-buying-state
  - zp-belief-gap
  - zp-usp
  - zp-mimetic
  - zp-community
---

# ZenithPro

The complete demand creation pipeline — for any market, any motivation direction.

One pipeline. The system reads your market, scores its motivation spectrum, and every output from that point forward is calibrated to that exact psychology. You never choose a track. You never decide if you're running an "away" or "toward" methodology. The system handles it.

---

## LAYER 1: INVARIANTS

1. **Step 0 is mandatory.** Always run `motivation-spectrum-analyzer` first. The spectrum score drives everything that follows.
2. **market-context.md is the backbone.** The spectrum analyzer writes it. Every skill reads it. If it doesn't exist, run the analyzer.
3. **The spectrum badge appears on every output.** Members always know their market's motivation profile.
4. **No manual track selection.** The system routes automatically. Members don't choose away/toward/hybrid — the score determines the blend.
5. **All outputs go to the project folder.** Never only in chat.
6. **Connect the Dots is the first real-world test case** — estimated True Hybrid (~55% Toward / 45% Away).

---

## THE SPECTRUM

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MARKET: [name] | [X]% Away / [Y]% Toward | [Zone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

| Zone | Score | What the Pipeline Does |
|------|-------|----------------------|
| Pure Away | 85-100% Away | Full avoidance methodology. Toward elements minimal. |
| Away-Dominant | 60-84% Away | Primary avoidance + toward injections at key points |
| True Hybrid | 45-59% either | Equal weight both directions. Hybrid formulas. |
| Toward-Dominant | 60-84% Toward | Primary aspiration + away injections at key points |
| Pure Toward | 85-100% Toward | Full aspiration methodology. Away elements minimal. |

---

## MODES

### FULL MODE `/zenithpro [market]`
Runs all 11 steps. Complete intelligence package. Use for:
- Any new market or client
- Building demand creation from scratch
- The ZenithPro package deliverable

### QUICK MODE `/zenithpro quick [market]`
Runs Steps 0, 1, 5, 7, 8 (spectrum + desire map + concept + belief gap + USP).
5 most critical outputs. Use for:
- Time-constrained work
- Clients with existing research
- Getting to Core Concept fast

### AUDIT MODE `/zenithpro audit [existing copy or positioning]`
Analyzes existing marketing assets against the spectrum framework.
Flags: avoidance language in toward markets, missed aspiration in away markets, hybrid opportunities left on the table. Use for:
- Existing campaigns underperforming
- Marketing that "feels off"
- Identifying the toward/away gap in current positioning

### TEST MODE `/zenithpro test [market]`
Runs Step 0 + Step 5 (spectrum + Core Concept only). Quick validation of concept direction. Use for:
- Rapid concept testing
- Checking if a market is toward or away before committing to full pipeline

---

## EXECUTION PROTOCOL

### Step 0: Spectrum Diagnosis
**Skill:** `motivation-spectrum-analyzer`
**Output:** `market-context.md` + `Motivation-Spectrum-[Market].md`

Run the spectrum analyzer. Get the score. Write market-context.md.

From this point, every skill reads market-context.md and self-adjusts.

---

### Step 1: Desire Hierarchy
**Skill:** `zp-desire-mapper`
**Output:** `Desire-Hierarchy-[Market].md`
**Input:** market-context.md

Spectrum-weighted desire mapping:
- Pure Away: Pain desires dominant. L4 = Self-Efficacy.
- True Hybrid: Both desire hierarchies. L4 = Dual Gate (Self-Efficacy AND Identity Permission).
- Pure Toward: Aspiration desires dominant. L4 = Identity Permission.

---

### Step 2: Psychographic Excavation
**Skill:** `zp-excavation`
**Output:** `Psychographic-[Market].md`
**Input:** market-context.md + Step 1 output

14 phases weighted to spectrum:
- Pure Away: Rage points, failure history, solution graveyard
- True Hybrid: Both failure archaeology AND passion triggers
- Pure Toward: Passion triggers, skill progression history, identity aspirations

---

### Step 3: Avatar Excavation
**Skill:** `zp-avatar`
**Output:** `Avatar-[Market].md`
**Input:** market-context.md + Steps 1-2

Avatar dimensions adapt to spectrum:
- Pure Away: Pain stratigraphy, shadow work, somatic fear
- True Hybrid: Full dual-dimensional avatar — who they're running FROM and TOWARD simultaneously
- Pure Toward: Aspiration stratigraphy, identity aspiration, flow state mapping

---

### Step 4: Pattern Analysis
**Skill:** `zp-pattern-analyzer`
**Output:** `Pattern-Analysis-[Market].md`
**Input:** market-context.md + Steps 1-3

- Pure Away: Failure pattern forensics (why they keep failing)
- True Hybrid: Both — failure archaeology AND progression plateau map
- Pure Toward: Progression pattern analysis (where they plateau, commitment triggers)

---

### Step 5: Core Concept Generation
**Skill:** `zp-concept-generator`
**Output:** `Core-Concept-[Market].md`
**Input:** market-context.md + Steps 1-4

The heart of ZenithPro. The belief that makes buying inevitable.
- Pure Away: "THAT'S why nothing worked" — structural insight that explains failures
- True Hybrid: The Hybrid Core Concept — explains the structural reason AND opens the identity transformation
- Pure Toward: "You CAN do this" — permission concept that opens identity access

5 formula candidates generated. Validated against spectrum-appropriate criteria. Winner selected.

---

### Step 6: Buying State Definition
**Skill:** `zp-buying-state`
**Output:** `Buying-State-[Market].md`
**Input:** market-context.md + Steps 1-5

- Pure Away: Productive tension, mechanism belief, urgency
- True Hybrid: Dual activation state — both urgency AND anticipation present
- Pure Toward: Identity readiness, anticipation, belonging

---

### Step 7: Belief Gap Mapping
**Skill:** `zp-belief-gap`
**Output:** `Belief-Gap-[Market].md`
**Input:** market-context.md + Steps 1-6

- Pure Away: Mechanism belief bridge (Point A: failing → Point B: believes mechanism works)
- True Hybrid: Dual bridge — mechanism AND identity (dependency mapping between the two)
- Pure Toward: Identity permission bridge (Point A: doubting → Point B: identity claim)

---

### Step 8: USP Development
**Skill:** `zp-usp`
**Output:** `USP-[Market].md`
**Input:** All prior outputs

- Pure Away: "Finally solve / eliminate / fix" promise language
- True Hybrid: Hybrid Copy Formulas (Escape-Into, Transformation-Through, Identity-Solution, Before-After-Identity)
- Pure Toward: "Become the kind of person who" promise language

---

### Step 9: Mimetic Intelligence
**Skill:** `zp-mimetic`
**Output:** `Mimetic-[Market].md`
**Input:** market-context.md + Steps 1-8

- Pure Away: Pain mediation competitive map — mechanism gaps
- True Hybrid: Dual competitive map + intersection analysis (hybrid positioning gap)
- Pure Toward: Aspirational creator landscape + identity positioning gaps

---

### Step 10: Community Architecture
**Skill:** `zp-community`
**Output:** `Community-[Market].md`
**Input:** All prior outputs

- Pure Away: Support/accountability architecture (community is optional)
- True Hybrid: Dual architecture — support layer AND tribal layer
- Pure Toward: Full tribal identity design — mimetic flywheel, retention mechanics

---

### Synthesis: Three Deliverables

After all 10 steps, produce:

**1. Demand Creation Brief** (`Demand-Brief-[Market].md`)
One-page strategic overview:
- Spectrum score + zone
- Core Concept (winning candidate)
- Buying state definition
- USP promise statement
- Top 3 belief gaps to close
- Competitive positioning angle

**2. Implementation Guide** (`Implementation-Guide-[Market].md`)
Tactical execution:
- Belief gap journey with evidence requirements
- Content sequence for each gap
- Copy direction for each channel
- Urgency mechanism for this market's zone

**3. Campaign Intelligence Package** (`Campaign-Intelligence-[Market].md`)
Full integrated package:
- All 10 skill outputs referenced
- Competitive positioning summary
- Community design overview
- Traffic translation notes (feeds into ZenithPro Lesson 7 workflow)

---

## OUTPUT FOLDER STRUCTURE

```
[Project Folder]/ZenithPro-[Market]/
├── market-context.md                    ← Step 0 writes this
├── 00-Motivation-Spectrum.md
├── 01-Desire-Hierarchy.md
├── 02-Psychographic-Excavation.md
├── 03-Avatar.md
├── 04-Pattern-Analysis.md
├── 05-Core-Concept.md
├── 06-Buying-State.md
├── 07-Belief-Gap-Map.md
├── 08-USP.md
├── 09-Mimetic-Intelligence.md
├── 10-Community-Architecture.md
├── SYNTHESIS-Demand-Brief.md
├── SYNTHESIS-Implementation-Guide.md
└── SYNTHESIS-Campaign-Intelligence.md
```

---

## QUALITY GATE

Before delivering synthesis:
- [ ] Spectrum badge appears on every output
- [ ] market-context.md exists and was used by all skills
- [ ] Core Concept passes the master test: "If believed, does buying become obvious?"
- [ ] USP uses zone-appropriate promise language
- [ ] Belief gap map addresses the correct belief types for this zone
- [ ] Community architecture matches spectrum (tribal vs. support)
- [ ] No avoidance language contamination in toward-heavy outputs
- [ ] No aspiration language gaps in away-heavy outputs

---

## FIRST TEST CASE

**Connect the Dots (CTD)** — Rich Schefren's in-person AI weekend intensive

Estimated zone: True Hybrid (~55% Toward / 45% Away)
- Toward: People want to BECOME AI-forward operators (identity aspiration)
- Away: FOMO about being left behind, frustration with AI not sticking (mild avoidance)

Run `/zenithpro "Connect the Dots — in-person AI weekend intensive for business owners"` to generate the full CTD demand creation package. Review with Rich to validate hybrid framework.

---

## HOW THIS REPLACED THREE SYSTEMS

**Before:** demand-architect (away) + toward-demand-architect (toward) + hybrid-demand-architect (hybrid)
**After:** zenithpro (all three, unified)

Members never choose. The spectrum does.
