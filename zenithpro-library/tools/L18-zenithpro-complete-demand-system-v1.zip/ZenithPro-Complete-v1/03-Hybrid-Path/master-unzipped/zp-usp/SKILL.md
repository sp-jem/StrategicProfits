---
name: zp-usp
description: "Unified ZenithPro USP generator. Transmutes product features into market positioning calibrated to the motivation spectrum. Away-heavy: 'finally solve / eliminate / fix' language. Toward-heavy: 'become the kind of person who' language. Hybrid: four Hybrid Copy Formulas that activate both directions simultaneously — Escape-Into, Transformation-Through, Identity-Solution, Before-After-Identity. The Feature→Benefit→Promise ladder is preserved throughout; only Level 3 (Promise) changes based on spectrum. Reads market-context.md automatically. Part of ZenithPro Unified System."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Unified, Force Multiplier, Connect the Dots]
interface:
  invoke: "/zp-usp [product or service]"
  called_by: [user, zp-demand-architect]
  outputs_to: [project folder]
---

# ZP USP Generator

Transmutes features into promises calibrated to the motivation spectrum. Away markets: features become solutions. Toward markets: features become identities. Hybrid markets: features become escapes AND arrivals simultaneously.

---

## LAYER 1: INVARIANTS

1. **Read market-context.md from the project folder before running.** If not found, prompt the user to run motivation-spectrum-analyzer first OR accept manual spectrum input: "Away: X% / Toward: Y%".
2. **Display the spectrum badge at the top of every output.** No exceptions.
3. **The Feature→Benefit→Promise ladder is universal.** Features → what it enables → what it delivers. Only Level 3 (Promise) content changes by spectrum zone.
4. **USP differentiation happens at the PROMISE level, never features.** Features are replicable. Promises are not — because promises connect to desires that competitors either can't authentically claim or haven't yet occupied.
5. **Every USP candidate must connect to a Level 1 desire.** A USP disconnected from core human desire is positioning without power.
6. **The USP must be OWNABLE** — competitors can't credibly claim it even if they wanted to. If they could say the same thing, it's not differentiated.
7. **Zone determines the DIRECTION of the Promise:** Away: relief, solution, elimination. Toward: identity, belonging, becoming. Hybrid: both vectors activated in a single statement.
8. **True Hybrid markets get all four Hybrid Copy Formulas produced and ranked.** Output all four; recommend the strongest for this market.
9. **Away differentiation:** primarily mechanism differentiation — why this approach is different from everything that has failed before.
10. **Toward differentiation:** primarily "who it's specifically for" — identity specificity is the differentiator, not mechanism superiority.
11. **Hybrid differentiation:** both mechanism AND identity specificity — the mechanism exists for this specific person's journey.
12. **NEVER use avoidance language in Pure Toward outputs.** No: pain, frustration, failure, broken, stuck, struggling, overcome, eliminate, fix, finally solve.
13. **Save all outputs to files.** Never deliver analysis only in chat.

---

## PURPOSE

The USP is the Point B expressed as a deliverable promise — calibrated to which direction Point B runs.

**Away USP logic:**
Feature → What it eliminates → Why this solution is better than everything else → Buy

**Toward USP logic:**
Feature → What it enables → Who you become by using it → Buy

**Hybrid USP logic:**
Feature → What it eliminates (escape vector) AND who you become (arrival vector) → A single statement that fires both → Buy

**The Three-Level Hierarchy (Universal):**

**Level 1: FEATURES** — What it IS
- Tangible components: modules, sessions, calls, tools, demonstrations, community, access
- Proprietary methodology or process elements
- Unique delivery mechanisms
- Hidden infrastructure (support, accountability, updates)

**Level 2: BENEFITS** — What it ENABLES
- Capabilities unlocked and possibilities created
- What becomes accessible and achievable through the feature
- What the feature removes, opens, or accelerates

**Level 3: PROMISES** — Calibrated to zone:
- *Pure Away:* What it DELIVERS in terms of relief, resolution, escape — "finally eliminate the problem"
- *Away-Dominant:* Primarily relief/solution + secondary identity aspiration — "solve this and step into someone who..."
- *True Hybrid:* One of the four Hybrid Copy Formulas — both directions activated simultaneously
- *Toward-Dominant:* Primarily identity transformation + secondary pain escape — "become [identity] and leave [problem] behind"
- *Pure Toward:* Who you BECOME by using it — "become the kind of person who..."

**Output use:** The USP drives: headline, lead, offer presentation, and competitive positioning across all marketing.

---

## INPUTS

Required:
1. **Product/service description** (features, deliverables, process — whatever they do or sell)
2. **Target market/avatar** (who buys this — be specific about demographics, situation, aspiration)
3. **Desire Hierarchy Map** (from zp-desire-mapper — which L1 desires are primary, L4 gate type)
4. **Market sophistication level** (see Step 4 for zone-specific interpretation)
5. **Competitive landscape** (what others claim — even briefly)
6. **Output folder path**

Optional:
- Testimonials from existing customers (real language they use about transformation)
- Core Concept if generated — USP should express it as a promise
- Buying State map — USP should move prospects toward Point B

---

## SPECTRUM BADGE

Display this at the top of every output:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MARKET: [name] | [X]% Away / [Y]% Toward | [Zone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## STEP 1: FEATURE EXCAVATION AND EXPANSION

Enumerate every feature with precision. Target 20-30 features total.

Categories to investigate:
- Visible deliverables (modules, sessions, demonstrations, calls, templates, projects)
- Hidden infrastructure (community, support, accountability, access, updates)
- Proprietary methodology or process elements
- The instructor/expert themselves (who they are, how they teach, what they embody)
- Unique delivery mechanisms
- Community and social features (who else is in the room, what that belonging confers)
- Progress architecture (how the program produces results at each stage)
- Access to aspirational models or peer networks
- Speed/timeline advantages
- Risk reversal features (guarantees, trial periods)

For each feature:
- Name it precisely
- Note if it is unique (no one else has it) or parity (standard in category)
- Identify the implicit promise it suggests — zone-calibrated:
  - Away: What problem does this remove or prevent?
  - Toward: What identity transformation does this suggest?
  - Hybrid: Both

---

## STEP 2: FEATURE-TO-BENEFIT TRANSMUTATION

For each feature, articulate:

**Away-weighted benefit chain:**
1. Immediate benefit — what it immediately fixes, removes, or enables
2. Secondary benefit — what that removal makes possible downstream
3. Emotional benefit — how it feels to have this no longer be a problem
4. Social benefit — how it changes how others perceive them
5. Strategic benefit — the competitive advantage it creates

**Toward-weighted benefit chain:**
1. Immediate benefit — what it immediately enables (skill, perception, capability)
2. Secondary benefit — what that enablement makes possible in practice
3. Experiential benefit — how it feels to have this capability while doing the thing
4. Social benefit — how having this capability changes how you are seen, or who you can now be around
5. Identity benefit — the version of yourself this enables you to claim

**Hybrid benefit chain:** Map both chains for each feature and identify where they converge — the benefit point that can be stated as both an escape AND an arrival.

---

## STEP 3: BENEFIT-TO-PROMISE METAMORPHOSIS

For the apex benefits, excavate:

**Away-weighted Promise construction:**
1. What endemic problem does this permanently dissolve?
2. What is the transformative result delivered — relief from the pain, not just management of it?
3. What attribution shift does it imply? (They failed before because of the METHOD, not because of them)
4. What unprecedented possibility does it create now that the problem is gone?

Transform benefit statements into away-market promise statements:
- NOT: "Learn marketing strategies" (benefit)
- INTO: "Finally become the marketer your competitors can't keep up with — without the grinding trial-and-error that's been wasting your time" (promise)

**Toward-weighted Promise construction:**
1. What fundamental identity transformation does this orchestrate?
2. What community does this qualify them to belong to?
3. What future self does it crystallize — not just what they can do, but who they ARE?
4. What suppressed aspiration does it validate?
5. What do people who have done this say about who they became?

Transform benefit statements into toward-market promise statements:
- WRONG: "Finally master the skill that's eluded you"
- RIGHT: "Become someone who sees the world differently — and can show others what you see"

**Produce 10-15 distinct promise statements calibrated to zone.** Each must answer the zone's primary question:
- Away: "What does this fix / eliminate / finally resolve?"
- Toward: "Who do you become?"
- Hybrid: "What do you escape AND who do you arrive as?"

---

## STEP 4: COMPETITIVE DIFFERENTIATION ARCHITECTURE

For each promise candidate, run:

1. **Ownership test:** Can competitors credibly claim this promise? If yes — eliminate or sharpen.
2. **Desire alignment:** Which primary L1 desire does this channel? (From zp-desire-mapper — reference directly)
3. **Believability test:** Can this platform/person credibly produce this result/transformation? What proof is required?
4. **Zone-specific differentiation test:**
   - *Away:* Mechanism differentiation — why is this approach different from every other solution that failed?
   - *Toward:* WHO specificity — does this USP name an exact type of person? Vague toward-USPs are avoidance-oriented in disguise.
   - *Hybrid:* Both — mechanism AND identity specificity. The mechanism exists specifically for this person's journey.

5. **Market sophistication match** (Schwartz levels — zone-adapted):

**Away market sophistication:**
- Level 1 (Unaware): Lead with the result/promise directly — the big claim
- Level 2 (Problem Aware): Lead with the problem — they know something's wrong
- Level 3 (Solution Aware): Lead with the mechanism — show how/why this way works
- Level 4 (Product Aware): Lead with differentiation — why this over alternatives
- Level 5 (Most Aware): Lead with the offer — they know what they want, show the deal

**Toward market sophistication (aspiration depth):**
- Level 1 (Freshly Curious): Lead with the transformation promise directly — the most inspiring "who you could become" claim
- Level 2 (Genuinely Interested): Lead with what specifically gets them from dabbler to someone who actually does this
- Level 3 (Returning After Stopping): Lead with identity permission reframe — not a better technique, proof this identity is genuinely available to someone like them
- Level 4 (Practicing But Plateaued): Lead with differentiation — why THIS is the specific path to the next level of belonging or mastery
- Level 5 (Already Committed): Lead with the specific offer — they know they want this category, show why this version is right

**Hybrid market sophistication:** Apply away-market sophistication for the mechanism positioning AND toward-market sophistication for the identity positioning. The hybrid USP serves both simultaneously.

---

## STEP 5: USP CANDIDATE SYNTHESIS

Produce 5-10 USP candidates using formulas calibrated to zone.

---

### AWAY-MARKET USP FORMULAS (Pure Away / Away-Dominant)

**The Result USP:** "[Specific measurable result] in [specific timeframe] or [guarantee]"

**The Mechanism USP:** "The only [category] that uses [specific mechanism] to [specific result]"

**The Anti-USP:** "The [category] for people who are tired of [what everyone else promises]"

**The Paradox USP:** "Achieve [desired result] without [unwanted cost/sacrifice]"

**The Attribution USP:** "Finally [achieve result] — not because you weren't trying hard enough, but because you were using the wrong [mechanism]"

**The Category Creator:** "The first [category name you own] that [specific capability]"

---

### TOWARD-MARKET USP FORMULAS (Pure Toward / Toward-Dominant)

**The Identity Transformation USP:** "The [most direct / only / fastest] path to becoming [specific identity] — for [specific who]"

**The Belonging USP:** "Join the [specific community] — designed for [specific person] who [specific aspiration]"

**The Specificity USP:** "Not for everyone who wants [aspiration]. Specifically built for [exact who] who want [exact identity]"

**The Demonstration USP:** "Watch [aspirational figure] [do the thing] — then do it yourself, guided step by step"

**The Permission USP:** "The [category] that starts from the belief that [identity permission statement]"

**The Anti-Category USP:** "Not [what the category usually promises]. [What this actually delivers — the identity]"

**The Time-Honest USP:** "In [honest timeframe], you'll [specific identity milestone]"

---

### HYBRID COPY FORMULAS (True Hybrid — produce ALL FOUR, recommend strongest)

The four Hybrid Copy Formulas activate both the escape vector (away motivation) and the arrival vector (toward motivation) in a single statement:

**Formula 1: Escape-Into**
"Stop being [pain identity]. Start being [aspiration identity]."

The simplest dual-activation statement. Names what they're escaping (away vector) and what they're arriving at (toward vector) in a two-clause construction.

*Example:* "Stop being the consultant who knows what to do but can't seem to make it happen. Start being the strategist clients call first."

**Formula 2: Transformation-Through**
"The path out of [pain] is becoming [identity]."

Reframes the escape as requiring — not just enabling — an identity transformation. The away motivation and the toward motivation are causally linked: you don't escape the pain by solving it, you escape it by becoming someone for whom that pain no longer applies.

*Example:* "The path out of perpetual busyness is becoming the kind of leader who builds systems instead of fires."

**Formula 3: Identity-Solution**
"Become the kind of person who never has to deal with [pain] again."

The escape is the logical consequence of the identity transformation. The away motivation is framed as what naturally disappears when the toward motivation is fulfilled.

*Example:* "Become the kind of marketer who generates demand — and never has to chase clients again."

**Formula 4: Before-After-Identity**
"[Struggling identity] → [mechanism] → [aspirational identity]. [Pain] stops being part of your story."

The most complete dual-activation statement. Names the before-state (away), the vehicle (mechanism), the after-state (toward), and makes the escape from pain a natural consequence of the identity transformation.

*Example:* "Overwhelmed entrepreneur → ZenithPro System → Strategic Profits architect. The feast-or-famine cycle stops being part of your story."

**Hybrid Formula Selection:** After producing all four, select the strongest based on:
- Which formula best matches the balance of the spectrum (closer to 50/50 = Formula 4; away-leaning hybrid = Formula 1 or 3; toward-leaning hybrid = Formula 2)
- Which formula most clearly names an exact identity (specificity test)
- Which formula competitors could NOT credibly claim

---

## STEP 6: USP ARCHITECTURE DOCUMENT

For the top 3 USP candidates (across all zones), build the complete architecture:

```
TOP USP: "[Statement]"

Zone: [Which zone this serves]
Formula: [Which formula type]
Direction: [Away / Toward / Hybrid]

Level 3 Promise (explicit):
[Away: What it finally resolves]
[Toward: Who they become]
[Hybrid: What they escape AND who they arrive as]

Supporting Promises (top 5):
1. [Promise] — Proven by: [Specific proof]
2. [Promise] — Proven by: [Specific proof]
3. [Promise] — Proven by: [Specific proof]
4. [Promise] — Proven by: [Specific proof]
5. [Promise] — Proven by: [Specific proof]

[Away zones] Reason Why (Hopkins):
The specific, credible reason why this result is achievable through this product.

[Toward zones] Identity Permission Statement:
The single sentence that unlocks the belief that this identity is available to someone like them.

[Hybrid zones] Both: Reason Why + Identity Permission Statement

Proof Architecture:
[Away] - Demonstration: What you can show
       - Peer testimonials: Results from similar people at same starting point
       - Logic: Why the mechanism works
       - Authority: Who/what validates this
       - Guarantee: Risk reversal

[Toward] - Demonstration: The aspirational model doing the thing
          - Mirrors: Demographically identical people who made the transformation
          - Permission: Evidence that identity is available at this age/background
          - Community: What the group looks like — belonging visible
          - Guarantee: Risk reversal framed as identity access

[Hybrid] - Dual-function case studies: Both escape AND identity claim documented together
          - Mechanism proof + mirror testimony
          - Both guarantee framings
```

---

## USP RANKING AND RECOMMENDATION

Rank the top 5 candidates across four dimensions:

**Away/Away-Dominant markets:**

| Candidate | Ownable | Believable | L1 Desire Strength | Competitive Gap |
|-----------|---------|------------|--------------------| ----------------|
| USP #1 | H/M/L | H/M/L | H/M/L | H/M/L |
| USP #2 | H/M/L | H/M/L | H/M/L | H/M/L |
| USP #3 | H/M/L | H/M/L | H/M/L | H/M/L |
| USP #4 | H/M/L | H/M/L | H/M/L | H/M/L |
| USP #5 | H/M/L | H/M/L | H/M/L | H/M/L |

**Toward/Toward-Dominant markets:**

| Candidate | Identity Ownable | Believable | L1 Desire Strength | WHO Specificity |
|-----------|-----------------|------------|--------------------| ----------------|
| USP #1 | H/M/L | H/M/L | H/M/L | H/M/L |
| USP #2 | H/M/L | H/M/L | H/M/L | H/M/L |
| USP #3 | H/M/L | H/M/L | H/M/L | H/M/L |
| USP #4 | H/M/L | H/M/L | H/M/L | H/M/L |
| USP #5 | H/M/L | H/M/L | H/M/L | H/M/L |

**True Hybrid markets:**

| Candidate | Formula | Dual Activation | Identity Specificity | Mechanism Ownable |
|-----------|---------|-----------------|---------------------|-------------------|
| Formula 1 | Escape-Into | H/M/L | H/M/L | H/M/L |
| Formula 2 | Transformation-Through | H/M/L | H/M/L | H/M/L |
| Formula 3 | Identity-Solution | H/M/L | H/M/L | H/M/L |
| Formula 4 | Before-After-Identity | H/M/L | H/M/L | H/M/L |
| [Other] | [Other formulas] | H/M/L | H/M/L | H/M/L |

**Recommended Primary USP:** [Which one and why — grounded in desire alignment, sophistication match, and zone]

**Recommended Secondary Positioning:** [Supporting claims that amplify the primary]

**[Away and Hybrid] Reason Why (standalone):** [The specific, credible reason why this result is achievable]

**[Toward and Hybrid] Identity Permission Statement (standalone):** [The single sentence that unlocks the belief that this transformation is available to someone like them — goes in headline area or sub-headline]

---

## OUTPUT SPECIFICATION

**File: `USP-Analysis-[Market-Product].md`**

Sections:
1. Spectrum Badge
2. Feature Inventory (all features with uniqueness assessment and zone-calibrated implicit promise)
3. Benefit Architecture (feature → benefit chains for top 20 features, zone-calibrated)
4. Promise Inventory (10-15 distinct promise statements calibrated to zone)
5. USP Candidates (5-10 with full analysis using zone-appropriate formulas)
6. [Hybrid only] All four Hybrid Copy Formulas with ranking
7. Top 3 USP Architecture Documents
8. Ranking Matrix and Recommendation
9. [Away/Hybrid] Reason Why (Hopkins standalone)
10. [Toward/Hybrid] Identity Permission Statement (standalone)

**Target length:** 2,500-4,000 words.

---

## QUALITY GATE

Before saving:

- [ ] Spectrum badge present
- [ ] market-context.md read (or manual input collected)
- [ ] At least 20 features identified (including hidden/infrastructure features)
- [ ] Complete feature→benefit→promise chain for top features
- [ ] Promises calibrated to zone (away: solution/relief framing; toward: identity/becoming framing; hybrid: dual activation)
- [ ] 5-10 USP candidates using zone-appropriate formulas
- [ ] [Away] Every candidate tested for mechanism ownership and believability
- [ ] [Toward] Every candidate tested for identity ownership AND WHO specificity
- [ ] [Hybrid] All four Hybrid Copy Formulas produced and ranked; one recommended
- [ ] Every candidate evaluated for desire alignment, sophistication match, ownership
- [ ] Ranking matrix complete with recommendation and reasoning
- [ ] [Away/Hybrid] Reason Why present as standalone
- [ ] [Toward/Hybrid] Identity Permission Statement present as standalone
- [ ] [Toward] Zero avoidance language anywhere in the document
- [ ] [Toward] Proof architecture specifies mirrors, not generic testimonials
- [ ] Saved to file

---

## HOW THIS CONNECTS DOWNSTREAM

- **zp-belief-gap** → The USP IS Point B. The belief gap analysis traces the exact journey from Point A to where this USP feels credible and inevitable.
- **zp-buying-state** → Every dimension of Point B should be expressed in the USP. Check: does the USP move prospects toward the buying state?
- **zp-desire-mapper** → The USP must connect to the dominant L1 desire and resolve the primary L4 gate. Check against the desire map.
- **Copywriting skills** → The USP drives the headline for all copy. It is the single most important input.
- **Core Concept** → The Core Concept is the philosophical reframe; the USP is the deliverable expression of it.
- **webinar close** → The USP becomes the center of the offer stack and the promise the close delivers on.
- **mimetic-market-intelligence / aspiration-mimetic-intelligence** → Check USP candidates against competitor positioning to ensure the territory is actually open.
- **community-architect** → Community design starts from the belonging promise embedded in the toward-weighted USP.
