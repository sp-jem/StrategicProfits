---
name: zp-excavation
description: "Unified ZenithPro psychographic excavation. 14-phase deep psychological archaeology calibrated to the motivation spectrum. Away-heavy phases: rage points, failure history, corruption/gaslighting, solution graveyard — surfaces why they've failed and who/what they blame. Toward-heavy phases: passion triggers, skill progression history, identity aspirations, community needs — surfaces what they're moving toward and what's blocked them from claiming it. Hybrid: proportionally weighted blend of both phase types. Reads market-context.md automatically. Part of ZenithPro Unified System."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/zp-excavation [market description]"
  called_by: [user]
  outputs_to: [project folder]
---

# ZenithPro Excavation (Unified)

14-phase deep psychological archaeology of a target market, spectrum-calibrated. Phases are selected and weighted based on the market's motivation score in `market-context.md`. The excavation language, framing, and synthesis shift accordingly — from pure pain archaeology at one pole to pure aspiration archaeology at the other, with blended operation in between.

---

## STEP 0: READ MARKET CONTEXT

Before running any phase, locate and read `market-context.md` in the current project folder.

Extract:
- **Away %** and **Toward %**
- **Zone** (Pure Away / Away-Dominant / True Hybrid / Toward-Dominant / Pure Toward)

Display the spectrum badge at the top of every output file:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MARKET: [name] | [X]% Away / [Y]% Toward | [Zone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

If `market-context.md` is not found, prompt the user:
> "I need to know this market's motivation spectrum before running excavation. What is the Away % and Toward %? Or run `/zp-market-context` first."

---

## LAYER 1: INVARIANTS

1. **Raw language over sanitized summaries.** Every section requires actual quotes from the market — Reddit, YouTube comments, reviews, forums, social media. Real words. Typos, caps lock, and all.
2. **Uncomfortable truths over comfortable fictions.** If what you're finding is what everyone already knows, you're not going deep enough.
3. **Save all outputs to files.** Never deliver in chat only.
4. **Web research required.** Training data alone is insufficient. Run live searches for each phase that requires quotes.
5. **Spectrum integrity.** In Pure Toward mode, delete Corruption/Gaslighting entirely. Do not soften it — delete it. In Pure Away mode, delete Passion Triggers, Skill Progression History, Community Needs — replace with the full away equivalents.

---

## PURPOSE

This is psychological archaeology. The goal: understand this market better than they understand themselves.

The spectrum determines WHAT you're excavating:

- **Away markets:** What they're fleeing — rage, blame, failed solutions, the corruption making it worse
- **Toward markets:** What they're reaching for — passion, identity aspiration, community belonging, the progression they want
- **Hybrid markets:** Both simultaneously, with explicit attention to the intersection point where fleeing and reaching are two expressions of the same underlying force

**Output use:** Feeds everything — Core Concept development, copywriting, avatar work, positioning, offer architecture.

---

## INPUTS

Gather before running:

1. **Target market description** (who they are, what they do or aspire to)
2. **Business/website URL** (optional — analyze the website first if provided)
3. **Avatar type** (if already identified)
4. **Specific focus area** (optional — for second-pass depth work)
5. **Output folder path**
6. **market-context.md** (must exist before running — see Step 0)

---

## SPECTRUM PHASE SELECTION

The 14 phases are populated from the away and toward phase libraries below, weighted by zone:

| Zone | Away Phases | Toward Phases |
|------|-------------|---------------|
| Pure Away (85-100% Away) | All 14 away phases | None |
| Away-Dominant (60-84% Away) | ~10 away phases | ~4 toward phases (Passion Triggers, Identity Aspiration, Community Needs, Skill Progression History) |
| True Hybrid (45-59%) | 7 away phases | 7 toward phases — equal split |
| Toward-Dominant (60-84% Toward) | ~4 away phases | ~10 toward phases |
| Pure Toward (85-100% Toward) | None | All 14 toward phases |

---

## THE AWAY PHASE LIBRARY

*Used fully in Pure Away. Proportionally reduced in hybrid and toward modes.*

### AWAY PHASE 0: BUSINESS FOUNDATION ANALYSIS
*(Only if analyzing for a specific business website)*

Analyze the provided URL to understand:
- Core product/service offering and primary value proposition
- Industry positioning and unique differentiation
- Pricing tier and sales process
- Competitive advantages that matter to the avatar
- The hidden emotional transaction beneath the features

---

### AWAY PHASE 1: IDENTITY ARCHAEOLOGY & CORE BELIEFS

**Research mandate:** Find actual quotes from this demographic — Reddit posts, YouTube comments, Amazon reviews, support group conversations, Twitter rants, Facebook group posts, TikTok comments. Raw language. Typos, caps lock, and all.

Excavate:
- What do they whisper to themselves at 3am when they can't sleep?
- What would they NEVER admit they struggle with, even anonymously online?
- What beliefs do they hold that they know are "wrong" but believe anyway?
- **Find 3-5 actual quotes revealing private beliefs**
- Their core worldview in 1-3 sentences — so accurate they'd think you read their diary
- Life stage context: who else is in their world? What's happening when this problem surfaces?

---

### AWAY PHASE 2: THE SOLUTION GRAVEYARD & CURRENT REALITY

What they're currently using/trying:
- Official solutions (products, services, professionals)
- "Dirty little secret" solutions they'd never admit
- Band-aid fixes and workarounds
- **Pull 10+ quotes showing frustration with current solutions — the angrier the better**

Their experience with existing solutions:
- What promises were broken?
- How much money/time has been wasted?
- **Find reviews, complaints, rants about existing solutions**

Why they think nothing works:
- Is it rigged against them? Are they missing some secret?
- **Find quotes expressing their theories about why solutions fail**

---

### AWAY PHASE 3: THE HIDDEN HISTORY PATTERNS

Dig for patterns that provide counter-narrative ammunition:

**The Suppressed Solution Story:** What solution was dismissed by the establishment but actually works? (Like Semmelweis and handwashing — right answer, rejected because it offended those in power)

**The Lost Wisdom Pattern:** What traditional/ancestral approach was dismissed then "rediscovered" when profitable? (Like willow bark → aspirin)

**The Profitable Suppression:** Who gets rich from their problem continuing? Name names. Follow the money.

**The Geographic Secret:** What works in another geography/context that this market doesn't know about?

**The Pre-1960s Solution:** What worked before modern times that's been memory-holed?

Find at least 3 of these patterns with specific examples from this market.

---

### AWAY PHASE 4: THE WHISPER NETWORK & TRIBAL KNOWLEDGE

**The Emperor's New Clothes Truth:** What's blindingly obvious but no one will say because it threatens someone powerful?

**The Insider's Confession:** What would an industry insider say after three drinks?
- Find whistleblower quotes
- Deleted posts, "I'll probably get fired for this but..." confessions

**The Generation Gap Secret:** What did people who did this 20 years ago know that's been forgotten?

**Veteran vs. Newbie Knowledge:** What do 5-year veterans know that 1-year newbies don't? What's only shared in DMs?

**Find 5+ quotes of people speaking when they think no one important is listening.**

---

### AWAY PHASE 5: THE CORRUPTION & GASLIGHTING CHRONICLES

*Deleted entirely in Pure Toward mode. Significantly reduced in Toward-Dominant mode.*

How The Problem Got Worse:
- Did this problem exist 20 years ago? When did it explode? Who made it worse?

How They're Being Gaslit:
- What are they experiencing that they're told isn't real?
- When do they say "Is it just me or...?" — **Find these exact phrases**
- Where's the gap between lived experience and "expert" opinion?

The Money Trail (surgical precision):
- Who gets rich from their problem existing?
- What industry would collapse if solved?
- Which "solution" has suspicious pricing or artificial scarcity?
- **Find evidence of price manipulation or profit protection**

---

### AWAY PHASE 6: THE OVERCORRECTION DISASTER & PARADIGM FLIPS

When The Cure Became Worse Than The Disease:
- What started as help but created worse problems?
- **Find quotes: "I wish we could go back to..."**

Complete Wisdom Reversals:
- What were they taught that's now "wrong"?
- What did they believe 5 years ago they're embarrassed about now?
- **Find: "I can't believe I used to think..."**

---

### AWAY PHASE 7: THE RAGE POINTS & EMOTIONAL TRIGGERS

What Makes Them FURIOUS:
- What injustice do they see that others ignore?
- What double standard makes their blood boil?
- What lie are they most tired of hearing?
- **Find their ANGRIEST quotes — with caps lock and exclamation points**

Their Deepest Fears:
- What keeps them awake at night?
- What would destroy their identity?
- **Find their most vulnerable admissions of fear**

Secret Desires They'd Never Admit:
- What do they really want but feel ashamed wanting?
- What success would they feel guilty achieving?
- What do they fantasize about but think is impossible?

---

### AWAY PHASE 8: DECISION PSYCHOLOGY & BUYING BEHAVIOR

How They Research & Decide:
- How long do they research before buying?
- What sources do they trust vs. distrust?
- **Find examples of their actual research processes**

What Stops Them:
- Most common objections — **find actual objection quotes**
- Past negative experiences that created skepticism
- The excuse they always use — **find their exact objection language**

What Makes Them Buy:
- What finally pushes them over the edge?
- What urgency naturally exists?
- **Find quotes about what made them finally buy something**

---

### AWAY PHASE 9: LANGUAGE HARVESTING & PAIN/DESIRE ARTICULATION

How They Describe Their Pain:
- **Pull 20+ different ways they describe their pain** — their actual words, metaphors, descriptions
- Physical sensations, emotional experiences, daily life impact

How They Describe Their Desired State:
- **Pull 20+ different ways they describe what they want** — their exact language
- How life would be different, what success looks like

The Words That Make Them Stop Scrolling:
- What headlines grab them?
- What terminology do they use vs. what experts use?
- **Find actual examples of content they engaged with heavily**

---

### AWAY PHASE 10: MEDIA, INFLUENCE & ATTENTION PATTERNS

Where They Hang Out:
- Specific subreddits, Facebook groups, Discord servers, offline locations
- **Find evidence of where they actually spend time**

Who They Trust:
- Specific influencers, thought leaders, publications
- What gives someone credibility to THEM specifically
- **Find who they actually mention and follow**

Content Patterns:
- What makes them stop scrolling vs. skip
- Preferred format (video, text, audio)
- **Find examples of content that got massive engagement from them**

---

### AWAY PHASE 11: COMPETITIVE INTELLIGENCE & POSITIONING OPPORTUNITIES

Competitor Analysis Through Their Eyes:
- What competitor messages have actually worked on them?
- What positioning immediately turns them off?
- What industry jargon are they numb to?

The Unique Angle:
- What contrarian stance would intrigue them?
- What truth has no one told them?
- What enemy has no one named yet?

---

### AWAY PHASE 12: OFFER ARCHITECTURE & CONVERSION OPTIMIZATION

The Perfect Offer Structure (based on everything above):
- Ideal price point and payment terms
- Essential guarantees and risk reversals
- Urgency that feels real, not manufactured
- Social proof that actually matters to THEM specifically
- **Find examples of offers they've actually responded to**

---

### AWAY PHASE 13: LIFETIME VALUE & RELATIONSHIP EVOLUTION

The Customer Journey:
- What happens after they solve problem #1?
- Natural progression of needs
- When they're most likely to buy again
- What makes them refer others vs. churn silently

---

### AWAY PHASE 14: SEGMENTATION & ADVANCED PATTERNS

Micro-Segments That Matter:
- How behavior changes by specific variables
- Early adopters vs. mainstream differences
- Trigger events that activate buying
- **Find patterns in different sub-groups**

---

## THE TOWARD PHASE LIBRARY

*Used fully in Pure Toward. Proportionally reduced in hybrid and away modes.*

### TOWARD PHASE 0: BUSINESS FOUNDATION ANALYSIS
*(Only if analyzing for a specific business website)*

Analyze the provided URL to understand:
- Core product/service offering and primary value proposition
- How the business positions around aspiration vs. pain avoidance
- The identity transformation being promised (explicitly and implicitly)
- What kind of person this business helps someone become
- The community or belonging dimension embedded in the offer

---

### TOWARD PHASE 1: IDENTITY ARCHAEOLOGY & CORE ASPIRATIONS

**Research mandate:** Find actual quotes from this demographic — Reddit posts, YouTube comments, Amazon reviews, Facebook group posts, forum threads, TikTok comments. Raw language.

Excavate:
- What do they imagine when they picture themselves fully living this aspiration?
- What identity claim do they secretly want to make but haven't earned yet in their own mind?
- What beliefs do they hold about who gets to have this identity — and whether that includes someone like them?
- **Find 3-5 actual quotes revealing private aspirations, identity desires, or permission questions**
- Their core aspiration worldview in 1-3 sentences — so accurate they'd think you read their journal
- Life stage context: what chapter of life are they in? What's opening up?

---

### TOWARD PHASE 2: SKILL PROGRESSION HISTORY & CURRENT REALITY

*Replaces Solution Graveyard in toward mode. The history is about learning attempts, not failure history.*

What they're currently doing/trying in pursuit of this aspiration:
- Official learning paths (courses, books, instructors, programs)
- Self-directed attempts (YouTube, free resources, trial and error)
- Community-based learning (classes, workshops, local groups)
- **Pull 10+ quotes showing their experience with learning journeys — what excited them, what made them stop**

Their experience with existing learning resources:
- What promises excited them but weren't fulfilled?
- What made them feel like the resource wasn't designed for someone like them?
- What did they wish existed that didn't?
- **Find reviews, comments, and forum posts about courses and teachers in this space**

Why they think they haven't progressed further:
- Do they blame lack of natural talent? Wrong method? Starting too late?
- **Find quotes expressing their theories about why they haven't arrived yet**

---

### TOWARD PHASE 3: THE ASPIRATION HISTORY PATTERNS

*Replaces Hidden History Patterns — traces aspiration origin, not problem origin.*

**The Permission Story:** Who in this market has made the identity claim and been validated publicly? What did their journey look like?

**The Rediscovery Pattern:** What traditional or ancestral form of this skill/craft/practice has been revived in a way that makes it feel accessible again?

**The Community Origin:** What online spaces or in-person communities created the first critical mass of people sharing this aspiration openly?

**The Teacher Who Changed Everything:** Who is the instructor, creator, or guide who made this aspiration feel achievable for people who'd been told (or believed) they couldn't do it?

**The Transformation Story That Spread:** What specific story — a video, a before/after, a testimonial — became widely shared because it gave others permission to want this?

Find at least 3 of these patterns with specific examples from this market.

---

### TOWARD PHASE 4: THE COMMUNITY WISDOM & INSIDER KNOWLEDGE

*Replaces Whisper Network — insider knowledge here is encouraging, not exposé.*

**The Tribe's Open Secret:** What do people inside the community know that makes the learning process far easier/faster than outsiders assume?

**The Advanced Practitioner's Confession:** What would someone who's been doing this for 5+ years tell a beginner that no course teaches?

**The Beginner Advantage:** What does this market have — life experience, patience, perspective — that younger or less experienced starters don't?

**The Shortcut Consensus:** What technique, approach, or resource do experienced practitioners most consistently recommend to accelerate progress?

**Find 5+ quotes of people sharing insider encouragement, hard-won wisdom, or community-specific knowledge.**

---

### TOWARD PHASE 5: THE PASSION TRIGGERS

*Replaces Corruption & Gaslighting — ignition energy, not suppressed rage.*

What activates obsessive interest in this market:

**What They Talk About for Hours:**
- What subtopics generate the most passionate conversation?
- What debates never get old in this community?
- What discoveries make them immediately want to share with someone?
- **Find their most engaged, enthusiastic quotes — with exclamation points and "this changed everything"**

**What Content They Consume Compulsively:**
- What YouTube channels, Instagram accounts, or teachers do they watch every video of?
- What format (tutorial, process video, time-lapse, interview) captures them most?
- **Find quotes describing binge-watching or obsessive consumption behavior**

**What Ignites the "I HAVE to try that" Response:**
- Specific techniques, tools, materials, or approaches that create an immediate compulsion to experiment
- **Find quotes about what made them buy something immediately without overthinking**

**Their Deepest Aspirational Desires:**
- What would they create if they knew they had the skill?
- What do they quietly bookmark and come back to?

---

### TOWARD PHASE 6: THE ASPIRATION EVOLUTION & PARADIGM EXPANSION

*Replaces Overcorrection Disaster — evolution here deepens aspiration rather than correcting mistake.*

When the Aspiration Deepens:
- What happens to this market's aspiration over time as they develop skill?
- **Find quotes: "I started just wanting to X, now I realize it's really about Y"**

Complete Belief Reversals:
- What did they believe about this skill/craft before starting that they now know is false?
- **Find: "I can't believe I used to think you had to be born with it"**

The Unexpected Benefits They Discovered:
- What did they gain from pursuing this aspiration that they didn't expect?
- **Find: "I never thought it would also give me..."**

---

### TOWARD PHASE 7: THE PASSION TRIGGERS & ASPIRATION ARCHITECTURE

*Replaces Rage Points — deep engagement replaces deep anger.*

What Makes Them DEEPLY ENGAGED:
- What aspects of this skill/pursuit produce genuine absorption?
- What small wins create the most disproportionate satisfaction?
- What does progress feel like to this market — specifically, somatically, emotionally?
- **Find their most enthusiastic descriptions of being in flow with this activity**

Their Deepest Identity Aspirations:
- What version of themselves are they reaching toward through this pursuit?
- What would they be able to say about themselves if they achieved mastery?
- **Find their most vulnerable admissions of who they want to become**

The Permission Questions They Wrestle With:
- "Is it too late for me to actually get good at this?"
- "Am I the kind of person who gets to call themselves an artist/musician/writer?"
- **Find these exact permission-question phrases in their own words**

---

### TOWARD PHASE 8: DECISION PSYCHOLOGY & BUYING BEHAVIOR

How They Research & Decide on Learning Resources:
- How long do they research before investing in a course or program?
- What sources do they trust vs. distrust?
- What makes them skeptical of a teacher or program?
- **Find examples of their actual research processes**

What Stops Them from Investing:
- Most common objections — **find actual objection quotes**
- Past learning experiences that created skepticism
- The identity doubt that surfaces: "Am I serious enough about this to spend money?"
- **Find their exact objection language**

What Makes Them Buy:
- What finally gives them permission to invest?
- What proof specifically matters to them — someone their age, someone with their background?
- **Find quotes about what made them finally commit**

---

### TOWARD PHASE 9: LANGUAGE HARVESTING & ASPIRATION ARTICULATION

*Language harvesting for aspiration — desire descriptors replace pain descriptors.*

How They Describe Their Aspiration:
- **Pull 20+ different ways they describe what they want** — their actual words, metaphors, descriptions
- Physical sensations, emotional experiences, identity claims, life vision language

How They Describe the Skill They Want to Develop:
- **Pull 20+ different ways they describe mastery or progress** — their exact language
- What skill milestones matter to them, what outputs represent arrival

The Words That Make Them Stop Scrolling:
- What headlines grab them?
- What language signals "this teacher gets people like me"?
- **Find actual examples of content they engaged with heavily**

---

### TOWARD PHASE 10: MEDIA, INFLUENCE & ATTENTION PATTERNS

Where They Hang Out:
- Specific subreddits, Facebook groups, Discord servers, YouTube channels, offline classes, local groups
- **Find evidence of where they actually spend time**

Who They Trust:
- Specific teachers, creators, practitioners — who has genuine authority in this market
- What gives someone credibility to THIS market specifically
- **Find who they actually mention, tag, and recommend**

Content Patterns:
- What makes them stop scrolling vs. skip
- Preferred format (tutorial, process video, finished work showcase, interview)
- **Find examples of content that got massive engagement from them**

---

### TOWARD PHASE 11: COMPETITIVE INTELLIGENCE & POSITIONING OPPORTUNITIES

What Market Messages Have Actually Worked On Them:
- What positioning has caused them to pay attention, buy, or recommend?
- What makes them immediately trust or dismiss a teacher?
- What industry-specific clichés have they grown numb to?

The Underserved Aspiration:
- What does this market want that nothing in the current landscape gives them?
- What kind of teacher, community, or approach do they describe in an ideal world that doesn't seem to exist?
- What identity permission is no one currently providing?

---

### TOWARD PHASE 12: OFFER ARCHITECTURE & CONVERSION FOR APPROACH MARKETS

The Ideal Investment Structure:
- Ideal price point and payment terms for this aspiration level and life stage
- Essential guarantees and risk reversals for an approach-motivated buyer (fear is "will it work for someone LIKE ME", not just "will it work")
- Social proof that actually matters: demographically matched mirrors, not generic testimonials
- **Find examples of offers they've actually responded to**

---

### TOWARD PHASE 13: ASPIRATION DEEPENING & RELATIONSHIP EVOLUTION

The Customer Journey After First Investment:
- What happens after they experience their first real win?
- What new aspiration emerges once the first one starts to materialize?
- When they're most likely to deepen their investment
- What makes them evangelize — bring others in — vs. consume privately
- **Find quotes about people who went deeper after starting**

---

### TOWARD PHASE 14: SEGMENTATION & ASPIRATION PATTERNS

Micro-Segments That Matter:
- How aspiration intensity and identity readiness vary across sub-groups
- Early adopters (self-identifying in the aspiration space) vs. aspiration-curious (still asking "could I be the kind of person who does this?")
- Life stage trigger events that activate aspiration and buying
- **Find patterns in different sub-groups**

---

## SPECTRUM EXECUTION GUIDE

### Pure Away (85-100% Away)

Run all 14 Away phases in sequence. No toward phases. Language is pain-forward throughout. The synthesis is entirely away-framed.

### Away-Dominant (60-84% Away)

Run Away Phases 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 as primary (10-11 phases). Append 4 Toward phases as secondary sections:
- Toward Phase 5 (Passion Triggers) — added after Away Phase 7
- Toward Phase 2 (Skill Progression History) — added after Away Phase 2
- Toward Phase 1 (Identity Archaeology) — incorporated into Away Phase 1 as an additional layer
- Toward Phase 4 (Community Wisdom/Insider Knowledge) — added after Away Phase 4

Label added toward sections clearly: `[TOWARD INJECTION]`

### True Hybrid (45-59%)

Run 7 Away phases + 7 Toward phases in alternating or paired sequence:

| Pair | Away Phase | Toward Phase |
|------|-----------|--------------|
| 1 | Identity Archaeology & Core Beliefs | Identity Archaeology & Core Aspirations |
| 2 | Solution Graveyard | Skill Progression History |
| 3 | Whisper Network | Community Wisdom & Insider Knowledge |
| 4 | Corruption & Gaslighting | Passion Triggers |
| 5 | Rage Points & Emotional Triggers | Passion Triggers & Aspiration Architecture |
| 6 | Decision Psychology (away framing) | Decision Psychology (toward framing) |
| 7 | Language Harvesting (pain) | Language Harvesting (aspiration) |

**MANDATORY HYBRID ADDITION — The Intersection Point:**

After all 14 paired phases, add a synthesis section:

```
## THE INTERSECTION POINT

Where the away pain and the toward aspiration are two expressions of the same underlying desire.

The [market] is simultaneously fleeing [X] and reaching for [Y].
These are not separate forces. They are the same human need viewed from opposite directions:
- The away face: "[pain statement in their language]"
- The toward face: "[aspiration statement in their language]"
- The unified desire: "[single sentence that captures what both are really about]"

This intersection point is where the most powerful positioning lives — not in the problem, not in the aspiration, but in the gap between who they are and who they know they're supposed to become.
```

### Toward-Dominant (60-84% Toward)

Run Toward Phases 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 as primary (10-12 phases). Append 4 Away phases as secondary sections:
- Away Phase 2 (Solution Graveyard) — brief version, reframed as "what hasn't worked in their learning journey"
- Away Phase 7 (Rage Points) — reframed as "frustrations and obstacles in the aspiration path"
- Away Phase 8 (Decision Psychology) — away framing on objections
- Away Phase 9 (Language Harvesting) — pain descriptors added to complement aspiration descriptors

Label added away sections clearly: `[AWAY INJECTION]`

### Pure Toward (85-100% Toward)

Run all 14 Toward phases. **Corruption/Gaslighting (Away Phase 5) is deleted entirely — no softened version, no mention.** Zero avoidance language in the skill's own voice (market quotes may contain whatever language the market uses).

---

## THE SYNTHESIS

After all phases, produce:

**For Away-weighted synthesis:**
1. The ONE belief they hold that they think no one else understands
2. The story that would make them say "THIS PERSON GETS IT"
3. The enemy they didn't know they were fighting
4. The solution they never thought was possible
5. The exact words that would make them stop scrolling and read every word
6. The offer they literally couldn't refuse
7. The guarantee that eliminates all risk in their mind
8. The urgency that feels real, not manufactured
9. The social proof that actually matters to them
10. The transformation they're really buying (not the product)

**For Toward-weighted synthesis:**
1. The ONE aspiration this market holds that they think no one else understands at the depth they feel it
2. The story that would make them say "THIS TEACHER/BRAND GETS IT"
3. The identity permission they need that the market hasn't given them yet
4. The transformation they didn't know was available to someone like them
5. The exact words that would make them stop scrolling and feel completely seen
6. The offer they couldn't say no to — and why it works for THIS market
7. The proof structure that actually moves them (hint: it's a mirror, not a mechanism)
8. The community belonging they're hoping exists on the other side of purchase
9. The social proof that actually matters to them (specific demographic + transformation details)
10. The identity they're really buying (not the product — the VERSION OF THEMSELVES)

**For True Hybrid synthesis:** Produce BOTH synthesis lists above, then add The Intersection Point section (defined above).

---

## OUTPUT SPECIFICATION

**File: `ZP-Excavation-[Market].md`**

Open with the Spectrum Badge. Then all selected phases clearly labeled. No sanitized summaries — actual quotes verbatim. If web research didn't yield quotes for a specific sub-question, note that explicitly.

**Target length:** 4,000-8,000 words. This is raw intelligence, not a polished report.

**Language rule:**
- Pure Away: pain-forward language throughout
- Pure Toward: NEVER use pain, frustration, failure, broken, stuck, struggling in the skill's own voice (quotes may contain it)
- Hybrid: use the language that matches the zone. Toward sections use aspiration language. Away sections use away language. The intersection section uses both.

---

## QUALITY GATE

- [ ] Spectrum badge present at top of output file
- [ ] market-context.md was read before execution
- [ ] Phase selection matches the zone exactly (correct count of away vs. toward phases)
- [ ] At least 30 distinct market quotes included across all phases
- [ ] Language Harvesting phase has 20+ descriptors (pain descriptors in away, aspiration descriptors in toward, both in hybrid)
- [ ] Rage Points / Passion Triggers includes actual emotional language (not paraphrase)
- [ ] True Hybrid includes The Intersection Point section
- [ ] Pure Toward has no Corruption/Gaslighting phase — not softened, deleted
- [ ] The Synthesis section has all 10 items answered (correct list for the zone)
- [ ] Web research used — not training data alone
- [ ] Saved to file

---

## HOW THIS CONNECTS DOWNSTREAM

- **zp-avatar** → This excavation feeds the avatar construction; avatar skill structures findings per segment with identity depth
- **zp-mimetic** → Phase 11 (competitive intelligence) feeds mimetic desire research in both directions
- **core-concept-generator** → Phases 2/5/7 (away) or Phases 2/5/7 (toward) directly feed failure pattern/passion trigger inputs
- **belief-gap-analyzer** → Phases 1, 8 feed the Point A belief mapping for the relevant motivation direction
- **usp-generator / toward-usp-generator** → Phase 11 positioning opportunities + Phase 9 language
- **community-architect** → Phase 4 insider knowledge + Phase 13 relationship evolution feeds community design
