$SkillName = "zp-concept-generator"
$InstallDir = "$env:USERPROFILE\.claude\skills\zp-concept-generator"
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item SKILL.md "$InstallDir\SKILL.md"
if (Test-Path "$InstallDir\SKILL.md") { Write-Host "✅ $SkillName installed" } else { Write-Host "❌ Failed"; exit 1 }
