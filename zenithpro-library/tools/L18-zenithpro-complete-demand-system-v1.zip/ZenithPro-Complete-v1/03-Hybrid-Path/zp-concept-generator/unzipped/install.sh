#!/bin/bash
SKILL_NAME="zp-concept-generator"
INSTALL_DIR="$HOME/.claude/skills/$SKILL_NAME"
echo "Installing $SKILL_NAME..."
mkdir -p "$INSTALL_DIR"
cp SKILL.md "$INSTALL_DIR/SKILL.md"
if [ -f "$INSTALL_DIR/SKILL.md" ]; then echo "✅ $SKILL_NAME installed"; else echo "❌ Failed"; exit 1; fi
