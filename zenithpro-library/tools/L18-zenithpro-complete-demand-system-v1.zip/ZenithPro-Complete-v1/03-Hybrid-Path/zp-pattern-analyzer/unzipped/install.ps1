$SkillName = "zp-pattern-analyzer"
$InstallDir = "$env:USERPROFILE\.claude\skills\zp-pattern-analyzer"
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item SKILL.md "$InstallDir\SKILL.md"
if (Test-Path "$InstallDir\SKILL.md") { Write-Host "✅ $SkillName installed" } else { Write-Host "❌ Failed"; exit 1 }
