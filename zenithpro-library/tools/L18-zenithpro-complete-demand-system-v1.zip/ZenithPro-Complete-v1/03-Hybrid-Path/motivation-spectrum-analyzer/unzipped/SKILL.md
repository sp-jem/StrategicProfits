---
name: motivation-spectrum-analyzer
description: "Diagnoses where any market sits on the toward/away motivation spectrum — producing a percentage score, zone classification, and specific pipeline recommendation. Run this FIRST, before any other ZenithPro pipeline. Determines whether to run demand-architect (away), toward-demand-architect (toward), or hybrid-demand-architect (mixed). Part of the ZenithPro three-track demand creation system."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, ZenithPro-Hybrid-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/motivation-spectrum-analyzer [market or business]"
  called_by: [user, hybrid-demand-architect]
  outputs_to: [project folder]
---

# Motivation Spectrum Analyzer

Diagnoses where any market sits on the toward/away motivation spectrum. The entry point for the entire ZenithPro three-track demand creation system.

Every market has a dominant motivation direction — people moving AWAY from pain, or moving TOWARD aspiration. Most markets have both, in varying proportions. This skill measures that proportion and routes you to the right pipeline.

---

## LAYER 1: INVARIANTS

1. **The spectrum is empirical — measure it, don't assume it.** Industry positioning often misrepresents buyer psychology. Competitors saying "away" language doesn't mean buyers ARE away-motivated. Always ground scores in actual customer language.
2. **Entry motivation and sustaining motivation can differ.** Someone enters CrossFit to escape being out of shape (away). They stay because of community and identity (toward). Both matter. Flag when they diverge.
3. **Score the buyers, not the industry.** How competitors market is evidence about their strategy, not buyer psychology. Use it for gap analysis, not spectrum scoring.
4. **Five zones, not two.** Pure away and pure toward are the edges. Most markets land somewhere in the middle — that's where the most important positioning decisions live.
5. **Save all outputs to files.** Never deliver analysis only in chat.

---

## WHY THIS EXISTS

Until now, demand creation operated as if all markets were the same direction. ZenithPro was built for away-motivated markets. Toward Markets was built for approach-motivated markets. Both are complete. But:

- Most markets aren't pure either direction
- Running the wrong track produces technically correct but psychologically misaligned output
- The gap between industry positioning and buyer psychology is often the biggest untapped positioning opportunity in any market

This skill is the router. It reads the market, scores the spectrum, and tells you exactly which track — or which blend — to run.

---

## PURPOSE

Answers the question that precedes all ZenithPro work:

> "Is this market primarily moving toward something or away from something — and in what proportion?"

**Three-track system:**

```
motivation-spectrum-analyzer
         │
         ├── 85%+ Away ──────────── demand-architect
         │                          (original ZenithPro)
         │
         ├── 60-84% Away ─────────── demand-architect
         │                           + Toward supplements
         │
         ├── 45-59% either ──────── hybrid-demand-architect
         │                          (full blend)
         │
         ├── 60-84% Toward ───────── toward-demand-architect
         │                           + Away supplements
         │
         └── 85%+ Toward ─────────── toward-demand-architect
                                     (Toward Markets)
```

---

## INPUTS

Gather before running:

1. **Market description** (required) — who they are, what they want, what they're dealing with
2. **Customer language samples** (optional, high value) — testimonials, reviews, community posts, forum threads, survey verbatims. Use exact quotes. The more the better.
3. **Competitor positioning overview** (optional) — how do successful competitors in this market position? What language do they use?
4. **Behavioral signals** (optional) — do customers share progress/wins or share complaints/frustrations? Communities that celebrate milestones vs. communities that vent about problems.
5. **Output folder path** (ask if not specified)

If only market description provided: proceed with reasoning, flag outputs as "inferred — validate with real customer language" and note that accuracy improves significantly with actual customer language.

---

## THE SIGNAL TAXONOMY

### Away Signals (5 categories)

**Category A1 — Active Pain Language** *(weight: 1.5x)*
Direct expressions of current suffering, frustration, or dissatisfaction.
- "I'm sick of...", "I can't stand...", "I'm tired of..."
- "This is ruining my...", "I hate how..."
- Present-tense suffering that demands relief

**Category A2 — Failure History** *(weight: 1.5x)*
References to past attempts that didn't work. Solution graveyard behavior.
- "I've tried everything", "nothing has worked for me"
- Listing products/programs/methods that failed
- "I've spent thousands on..." with implied disappointment
- "I keep starting and stopping..."

**Category A3 — Cost-of-Inaction** *(weight: 1.5x)*
Explicit acknowledgment of what not solving the problem is costing.
- "Every day I wait, I'm losing..."
- "This is costing me money/relationships/health"
- "I can't keep living like this"
- Escalating urgency language

**Category A4 — Fear of Future State** *(weight: 1.0x)*
Anxiety about what happens if nothing changes.
- "I'm afraid I'll never...", "I'm terrified that..."
- "If I don't fix this, I..."
- "I don't know how much longer I can..."

**Category A5 — Mild Regret** *(weight: 0.5x)*
Wistful reference to what didn't happen — the weakest away signal, often blends with toward.
- "I always wanted to but never did"
- "I wish I had started earlier"
- Note: This signal frequently appears in approach-motivated markets as the entry trigger. Don't over-weight it.

---

### Toward Signals (5 categories)

**Category T1 — Identity Aspiration** *(weight: 1.5x)*
Explicit desire to become a different kind of person.
- "I want to be someone who...", "I want to be the kind of person who..."
- "I want to think of myself as...", "I want to BE a..."
- Present-tense identity claiming: "I'm becoming...", "I'm learning to..."

**Category T2 — Mimetic Desire** *(weight: 1.5x)*
Seeing someone else do/have/be something and wanting it.
- "I saw [person] do X and I wanted that"
- "Watching them made me realize I want to..."
- "I was inspired by..." (combined with specific aspiration)
- Social media inspiration behavior — saving/sharing aspirational content

**Category T3 — Tribal Belonging** *(weight: 1.5x)*
Desire to be part of a community of people who do/are this thing.
- "I want to find people who...", "I want to belong to..."
- Community-seeking language around the activity/identity
- "I want to meet other people who..."
- Attraction to in-group vocabulary and culture

**Category T4 — Life-Stage Opportunity** *(weight: 1.0x)*
Recognition that this is their moment — the window is open.
- "Now that I [retired/the kids left/I have time]..."
- "This feels like my chapter", "If not now, when?"
- "I finally have the time/freedom/resources to..."
- Transitional life events creating aspiration windows

**Category T5 — Progress-Sharing Behavior** *(weight: 1.0x)*
Behavior of sharing progress, wins, and milestones (not complaints).
- Posting completed work, milestones, PRs
- "Look what I made / built / learned"
- Celebrating small wins in community contexts
- Before/after sharing (toward version: "look how far I've come")
- Contrast: away markets share complaints; toward markets share progress

---

## EXECUTION PROTOCOL

### Phase 1: Evidence Collection & Cataloguing

Review all provided inputs and catalogue every signal found:

```
SIGNAL LOG
----------
[A1] "I'm sick of being self-conscious at the gym" — testimonial, July 2024
[T1] "I want to be someone who is athletic" — forum post
[A2] "I've tried three different programs and nothing sticks" — review
[T3] "The community is what keeps me coming back" — testimonial
... (continue for all signals found)
```

Note source type for each: testimonial / review / forum / survey / behavioral / competitor language.

If evidence is limited: reason from market knowledge, flag as inferred.

---

### Phase 2: Entry vs. Sustaining Motivation Analysis

Separate signals by when they occur in the customer journey:

**Entry signals** — what motivates the initial purchase decision
**Sustaining signals** — what keeps customers engaged and drives upsells/renewals

These often differ. Identify which signals are entry-stage (usually present in initial marketing) vs. sustaining-stage (usually present in community/retention contexts).

Flag when they differ significantly — this is architecturally important for value ladder design.

---

### Phase 3: Industry vs. Buyer Gap Analysis

Compare:
- **What competitors are saying** (their positioning language direction)
- **What buyers are actually expressing** (customer language direction)

If competitors are 80% away but buyers are 65/35 — that gap is a positioning opportunity. Flag explicitly:

> **Industry/Buyer Gap Detected:** Industry positions at [X]% away. Buyer language suggests [Y]% away. The gap represents an underserved positioning opportunity — toward-oriented messaging would differentiate from all competitors while resonating more accurately with buyers.

---

### Phase 4: Spectrum Scoring

**Weighted Signal Count:**

1. Count signals in each category
2. Apply weights: A1/A2/A3/T1/T2/T3 = 1.5x, A4/T4/T5 = 1.0x, A5 = 0.5x
3. Calculate weighted Away total and weighted Toward total
4. Convert to percentages

```
SCORING WORKSHEET
-----------------
Away signals:
  A1 (1.5x): [count] × 1.5 = [weighted]
  A2 (1.5x): [count] × 1.5 = [weighted]
  A3 (1.5x): [count] × 1.5 = [weighted]
  A4 (1.0x): [count] × 1.0 = [weighted]
  A5 (0.5x): [count] × 0.5 = [weighted]
  AWAY TOTAL: [sum]

Toward signals:
  T1 (1.5x): [count] × 1.5 = [weighted]
  T2 (1.5x): [count] × 1.5 = [weighted]
  T3 (1.5x): [count] × 1.5 = [weighted]
  T4 (1.0x): [count] × 1.0 = [weighted]
  T5 (1.0x): [count] × 1.0 = [weighted]
  TOWARD TOTAL: [sum]

GRAND TOTAL: [away + toward]
% Away: [away/total × 100]
% Toward: [toward/total × 100]
```

**Confidence Rating:**
- **HIGH:** 10+ distinct customer language samples across 3+ sources
- **MEDIUM:** 4-9 samples or 1-2 sources
- **LOW:** Market description only, minimal customer language

---

### Phase 5: Zone Classification & Pipeline Recommendation

Assign to one of five zones:

| Zone | Score | Pipeline | What It Means |
|------|-------|----------|---------------|
| **Pure Away** | 85-100% Away | `demand-architect` | Run original ZenithPro. Toward elements are peripheral. |
| **Away-Dominant** | 60-84% Away | `demand-architect` + Toward supplements | Primary: pain/mechanism/belief. Inject: aspiration layer, identity permission frame, light community architecture in the close. |
| **True Hybrid** | 45-59% either | `hybrid-demand-architect` | Full integration of both pipelines. Neither direction dominates. Run the hybrid. |
| **Toward-Dominant** | 60-84% Toward | `toward-demand-architect` + Away supplements | Primary: aspiration/identity/community. Inject: pain acknowledgment, cost-of-inaction urgency, consequence framing in close. |
| **Pure Toward** | 85-100% Toward | `toward-demand-architect` | Run Toward Markets pipeline. Away elements are peripheral. |

---

### Phase 6: Value Ladder Spectrum Notes

Note if the spectrum shifts across the funnel:

- **Entry point:** What brings them in? (Often the more immediate/emotional motivation)
- **Mid-funnel:** What maintains engagement?
- **Close:** What drives the purchase decision?
- **Retention:** What keeps them subscribed/returning?

Example: "Entry = 70% Away (pain drove initial search). Close = 50/50 (identity aspiration activated during content). Retention = 70% Toward (community/mastery). Recommendation: Lead with away, activate toward in content, retain with community."

---

## OUTPUT SPECIFICATION

**File:** `Motivation-Spectrum-[Market].md`

**Structure:**
1. **Spectrum Score** — headline number prominently displayed
2. **Zone Classification** — which of the 5 zones
3. **Pipeline Recommendation** — specific skill(s) to run, in order
4. **Evidence Summary** — top 5-7 signals (with quotes) that drove the score
5. **Entry vs. Sustaining Analysis** — if they differ
6. **Industry/Buyer Gap** — if detected (and what it means strategically)
7. **Value Ladder Notes** — how the spectrum shifts across funnel stages
8. **Confidence Rating** — with note on what additional evidence would improve it

---

## QUALITY GATE

Before saving:
- [ ] Score grounded in specific evidence (not assumed)
- [ ] Entry and sustaining motivation addressed separately if different
- [ ] Industry/buyer gap assessed
- [ ] Zone classification correct for the score
- [ ] Pipeline recommendation is specific (names the skill, not just the direction)
- [ ] Value ladder notes present
- [ ] Confidence rating included with honest assessment

---

## SAMPLE OUTPUT FORMAT

```markdown
# Motivation Spectrum Analysis — [Market Name]

## SPECTRUM SCORE: [X]% Away / [Y]% Toward
**Zone:** [Zone Name]
**Confidence:** [High / Medium / Low]
**Pipeline Recommendation:** Run [skill-name]

---

## Pipeline Recommendation: [Full Explanation]

[Why this zone, what to run, and any supplements to inject from the other track]

---

## Evidence That Drove This Score

**Top Away Signals:**
- [Quote] — [source] — Category [A#]
- [Quote] — [source] — Category [A#]

**Top Toward Signals:**
- [Quote] — [source] — Category [T#]
- [Quote] — [source] — Category [T#]

---

## Entry vs. Sustaining Motivation

[If they differ — explain both and what it means for pipeline selection]

---

## Industry/Buyer Gap

[If detected — what competitors are doing vs. what buyers actually express, and what the opportunity is]

---

## Value Ladder Notes

[How the spectrum shifts from entry → mid-funnel → close → retention]
```

---

## HOW THIS CONNECTS TO THE THREE TRACKS

**After running this skill:**
- Pure Away → run `/demand-architect`
- Away-Dominant → run `/demand-architect`, then inject aspiration elements at close
- True Hybrid → run `/hybrid-demand-architect` (coming)
- Toward-Dominant → run `/toward-demand-architect`, then inject cost-of-inaction at close
- Pure Toward → run `/toward-demand-architect`

**The Motivation Spectrum score also feeds:**
- Copywriting: determines the primary emotional register and copy direction
- Offer design: determines whether urgency is pain-escalation or life-stage-window
- Community design: toward-heavy markets need full tribal architecture; away-heavy markets need lighter community elements
