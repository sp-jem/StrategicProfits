---
name: toward-usp-generator
description: "Transmutes product features into breakthrough market positioning using identity-transformation language — 'become the kind of person who' not 'finally solve.' The approach-motivated equivalent of usp-generator. Feature→Benefit→Promise ladder reoriented around identity promise. Schwartz sophistication levels applied to aspiration depth. Part of the ZenithPro: Toward Markets pipeline."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/toward-usp-generator [product or service]"
  called_by: [user, toward-demand-architect]
  outputs_to: [project folder]
---

# Toward USP Generator

Transmutes features into identity promises. Produces breakthrough market positioning that answers not "What does this solve?" but "Who do I become?"

---

## LAYER 1: INVARIANTS

1. **The USP is an identity promise, not a solution promise.** The test for every candidate: Does it describe who they BECOME, or a problem they SOLVE? If the latter, rewrite it before proceeding.
2. **"Become" is not enough. It must be specific.** "Become more creative" fails the test. "Become someone who sees the world as raw material and can render what she sees" passes. Specificity is what makes the promise ownable.
3. **Differentiation in approach markets is almost never about a better mechanism.** It is about WHO the offer is specifically for. A USP that explains how the teaching method works is avoidance-oriented. A USP that names the exact person and transformation it was built for is approach-oriented.
4. **Schwartz sophistication measures aspiration depth, not solution awareness.** In approach markets, sophistication is about how many times they have TRIED the aspiration and returned to the starting line — not how many solutions they have tried for a problem.
5. **NEVER use avoidance language anywhere in this document.** No: pain, frustration, failure, broken, stuck, struggling, overcome, eliminate, fix, finally solve. These words belong to a different architecture. If a promise requires these words, it is not an approach-market USP.
6. **Save all outputs to files.** Never deliver analysis only in chat.

---

## PURPOSE

The USP is the identity promise made visible.

In avoidance markets, the USP drives toward: "The best way to solve [problem] once and for all."

In approach markets, the USP drives toward: "The most direct path to becoming [identity]."

This is not a semantic difference. The entire logic chain reverses.

**Avoidance USP logic:**
Feature → What it eliminates → Why this solution is better than others → Buy

**Approach USP logic:**
Feature → What it enables → Who you become by using it → Buy

**The Three-Level Hierarchy (Approach-Oriented):**

**Level 1: FEATURES** (What it IS)
- Tangible components: modules, sessions, demonstrations, tools, community access
- Unique delivery mechanisms and methodology elements
- What someone receives or accesses

**Level 2: BENEFITS** (What it ENABLES)
- Capabilities unlocked and possibilities created
- What becomes accessible and achievable
- The new perceptions, skills, and experiences the feature opens
- Example (sketching): "You learn to see and render exactly what you're observing"

**Level 3: PROMISES** (Who you BECOME by using it)
- The identity transformation delivered — not the technique acquired
- How you will be seen, how you will see yourself, who you now are in the world
- The community you belong to, the life that becomes available
- Example (sketching): "Become someone who sees the world differently — and can show others what you see"

**The Key Test:** Read the Level 3 promise aloud. Does it describe who they BECOME? Or does it still describe a problem they solve or a skill they acquire? If skill acquisition is the final statement, go one level deeper: who does a person with that skill get to be?

**Output use:** The USP drives: headline, lead, offer presentation, and competitive positioning across all Toward Markets work.

---

## INPUTS

Required:
1. **Product/service description** (features, deliverables, methodology — whatever they do or sell)
2. **Target market/avatar** (who buys this — be specific about demographics and aspiration)
3. **Aspiration Hierarchy Map** (from toward-desire-mapper — which L1 desires are primary and what identity permission gaps exist)
4. **Market sophistication level** (Schwartz 1-5 — adapted to aspiration depth; see Step 4)
5. **Competitive landscape** (what others claim, especially what identity they implicitly or explicitly promise)
6. **Output folder path**

Optional:
- Testimonials and case studies from current students/customers (real transformation language)
- Aspirational models in this market (the creators/practitioners the buyer aspires to be like)
- Core Concept if generated — the USP should express it as an identity promise

---

## STEP 1: FEATURE EXCAVATION & EXPANSION

Enumerate every feature with precision. Target 20-30 features total.

Categories to investigate:
- Visible deliverables (modules, sessions, demonstrations, calls, templates, projects)
- Hidden infrastructure (community, support, access, live feedback, accountability)
- Proprietary methodology or process elements
- The instructor/expert themselves (who they are, how they teach, what they embody)
- Unique delivery mechanisms (live demonstration, real-time rendering, critiqued work, etc.)
- Community and social features (who else is in the room, what that belonging confers)
- Progress architecture (how the program is structured to produce visible results quickly)
- Access to aspirational models (proximity to the person who already lives the identity)

For each feature:
- Name it precisely
- Note if it is unique (no one else has it) or parity (standard in category)
- Identify the implicit identity transformation it suggests

**Sketching example:**
- Feature: Ian Fennelly's real-time demonstration with verbal narration of his perceptual process
- Unique or parity: Unique — most instruction shows finished technique, not live perceptual unfolding
- Implicit identity transformation: "The gap between how an artist sees and how I see closes in real time"

---

## STEP 2: FEATURE-TO-BENEFIT TRANSMUTATION

For each feature, articulate:
1. **Immediate benefit** — what it immediately enables (skill, perception, capability)
2. **Secondary benefit** — what that enablement makes possible in practice
3. **Experiential benefit** — how it feels to have this capability while doing the thing
4. **Social benefit** — how having this capability changes how you are seen, or who you can now be around
5. **Identity benefit** — the version of yourself this enables you to claim

**Example chain (urban sketching):**
- Feature: Weekly live sketch-along with Ian in real urban environments
- Immediate benefit: You practice alongside a master and get real-time feedback, not retrospective critique
- Secondary benefit: Your speed and confidence in public sketching accelerates dramatically faster than solo practice
- Experiential benefit: The meditative focus of sketching in public becomes something you return to rather than avoid
- Social benefit: You become someone who can say "I sketch" with evidence, not aspiration
- Identity benefit: You are now a person who documents the world through her own eyes

---

## STEP 3: BENEFIT-TO-PROMISE METAMORPHOSIS

For the apex benefits (identity benefits from Step 2), excavate:
1. What fundamental identity transformation does this orchestrate?
2. What community does this qualify them to belong to?
3. What future self does it crystallize — not just what they can do, but who they are?
4. What suppressed aspiration (from the deep layer of Aspiration Stratigraphy) does it validate?
5. What do people who have done this say about who they became, in their own words?

Transform benefit statements into promise statements using this rewrite rule:

**WRONG (avoidance framing):**
- "Finally master the skill that's eluded you"
- "Stop struggling with [technique]"
- "Overcome the beginner's intimidation"

**RIGHT (identity framing):**
- "Become someone who sees the world differently — and can show others what you see"
- "Become the kind of person who pulls out a sketchbook in a café, at a harbor, on a train — and fills it"
- "Join the community of people who move through the world as observers and translators of what they see"

Produce 10-15 distinct promise statements. Each must answer "who do you become?" not "what do you solve?"

---

## STEP 4: COMPETITIVE DIFFERENTIATION ARCHITECTURE

For each promise candidate, run:

1. **Identity ownership test:** Can competitors credibly claim this identity promise? If yes — eliminate or sharpen. The test: could a competitor's existing customer read this USP and think it describes them?
2. **Desire alignment:** Which primary L1 desire does this channel? (From toward-desire-mapper output — reference it directly)
3. **Believability test:** Can this platform/person credibly produce this transformation? What proof supports it?
4. **Specificity of WHO:** Does this USP name an exact type of person? Vague USPs ("for anyone who wants to sketch") are avoidance-oriented disguised as approach. Specific USPs ("for women who've never drawn but want to make travel and everyday life feel more meaningful") own their niche.
5. **Aspiration sophistication match:** (Schwartz adapted — see below)

**Schwartz Sophistication — Approach Markets Adaptation:**

In approach markets, sophistication is NOT about how many solutions they have tried. It is about the depth of their aspiration journey:

- **Aspiration Level 1 (Freshly Curious):** They just discovered this identity exists. Lead with the transformation promise directly — the most inspiring "who you could become" claim.
- **Aspiration Level 2 (Genuinely Interested):** They have explored the aspiration — watched videos, bought one beginner resource, dabbled. Lead with what specifically gets them from dabbler to someone who actually does this.
- **Aspiration Level 3 (Returning After Stopping):** They tried it, fell off, blame themselves or the method. Lead with the identity permission reframe — not a better technique, but proof this identity is genuinely available to someone like them.
- **Aspiration Level 4 (Practicing But Plateaued):** They do the thing but don't feel like they've claimed the identity. Lead with differentiation — what makes THIS the specific path to the next level of belonging or mastery.
- **Aspiration Level 5 (Already Committed):** They identify with the aspiration, are active practitioners. Lead with the specific offer — they know they want this category, show why this version is the one.

For each USP candidate, identify which aspiration level it most powerfully serves.

**In approach markets, differentiation is often WHO, not HOW:**

The most powerful approach-market USP is frequently not "a better method" — it is specificity about EXACTLY who this is designed for. This is a complete sentence:

> "This isn't for everyone who wants to sketch — it's specifically designed for people who've never drawn but want to make travel and everyday life feel more meaningful."

That sentence is a USP. It differentiates by identity specificity, not by mechanism superiority. The mechanism is irrelevant until identity fit is established.

---

## STEP 5: USP CANDIDATE SYNTHESIS

Produce 5-10 USP candidates across different formulas — all reoriented toward identity language.

**USP Formula Types (Approach-Market Versions):**

**The Identity Transformation USP:** "The [most direct / only / fastest] path to becoming [specific identity] — for [specific who]"
*Example:* "The most direct path to becoming someone who sees the world through an artist's eyes — for women who have never drawn but have always wanted to."

**The Belonging USP:** "Join the [specific community] — designed for [specific person] who [specific aspiration]"
*Example:* "Join a community of everyday people who document their world through sketching — specifically designed for complete beginners over 50."

**The Specificity USP:** "Not for everyone who wants [aspiration]. Specifically built for [exact who] who want [exact identity]"
*Example:* "Not for art school graduates. Built for people who want to fill sketchbooks in Paris, not produce gallery work — and who are starting from zero."

**The Demonstration USP:** "Watch [aspirational figure] [do the thing] — then do it yourself, guided step by step"
*Example:* "Watch Ian Fennelly sketch a cathedral in real time, narrating every perceptual decision as he makes it — then sketch alongside him."

**The Permission USP:** "The [category] that starts from the belief that [identity permission statement]"
*Example:* "The urban sketching program that starts from the belief that seeing like an artist is a learnable skill — not a talent you're born with."

**The Anti-Category USP:** "Not [what the category usually promises]. [What this actually delivers]"
*Example:* "Not a technique course. A practice you'll return to for the rest of your life."

**The Time-Honest USP:** "In [honest timeframe], you'll [specific identity milestone]"
*Example:* "In six weeks, you'll fill your first sketchbook — and never see a city the same way again."

For each USP candidate:

**USP CANDIDATE #[X]:**

*The Statement:* "[One-sentence USP]"

*The Formula Used:* [Which formula type]

*Identity Promise (state it explicitly):* [Who does the buyer BECOME]

*L1 Desire Connected:* [Which primary desire from toward-desire-mapper this channels]

*Aspiration Level Match:* [Which Schwartz aspiration level this serves and why]

*Ownership Analysis:* [Can competitors claim this? Why/why not? What makes it ownable?]

*WHO Specificity:* [Does it name an exact type of person? If vague, flag it.]

*Proof Requirements:* [What evidence validates this identity transformation promise?]

*Strengths:* [What makes this compelling in this market]
*Weaknesses:* [What makes this risky or where it falls short]

---

## STEP 6: IDENTITY ARCHITECTURE DOCUMENT

For the top 3 USP candidates, build the complete feature-benefit-identity architecture:

```
TOP USP: "[Statement]"

Identity Promise (explicit): "[Who they become]"

Supporting Identity Promises (top 5):
1. [Identity transformation] — Enabled by: [Feature] — Proven by: [Specific proof]
2. [Identity transformation] — Enabled by: [Feature] — Proven by: [Specific proof]
3. [Identity transformation] — Enabled by: [Feature] — Proven by: [Specific proof]
4. [Identity transformation] — Enabled by: [Feature] — Proven by: [Specific proof]
5. [Identity transformation] — Enabled by: [Feature] — Proven by: [Specific proof]

Identity Permission Statement:
[The single sentence that unlocks the belief that this identity is available to someone like them]

Reason It Works (Hopkins adapted):
[The specific, credible reason why this identity transformation is achievable through this product]

Proof Architecture:
- Demonstration: [What you can show — the aspirational model at work]
- Mirrors: [Testimonials from demographically identical people who made this transformation]
- Permission: [Evidence that the identity is genuinely available at this age/background/starting point]
- Community: [What the group of people who do this looks like — belonging visible]
- Guarantee: [Risk reversal framed as identity access, not money back]
```

---

## USP RANKING & RECOMMENDATION

Rank the top 5 candidates across four dimensions using H/M/L:

| Candidate | Identity Ownable | Believable | L1 Desire Strength | WHO Specificity |
|-----------|-----------------|------------|--------------------| ----------------|
| USP #1 | H/M/L | H/M/L | H/M/L | H/M/L |
| USP #2 | H/M/L | H/M/L | H/M/L | H/M/L |
| USP #3 | H/M/L | H/M/L | H/M/L | H/M/L |
| USP #4 | H/M/L | H/M/L | H/M/L | H/M/L |
| USP #5 | H/M/L | H/M/L | H/M/L | H/M/L |

**Recommended Primary USP:** [Which one and why — grounded in aspiration level match and desire connection]

**Recommended Secondary Positioning:** [Supporting identity claims that amplify the primary]

**Identity Permission Statement (standalone):** [The single sentence that unlocks the belief that this transformation is available to someone like them — this goes in the headline area or sub-headline]

---

## OUTPUT SPECIFICATION

**File: `Toward-USP-Analysis-[Market-Product].md`**

Sections:
1. Feature Inventory (all features with uniqueness assessment and implicit identity transformation)
2. Identity Benefit Architecture (feature → benefit → identity chain for top 20 features)
3. Promise Inventory (10-15 distinct identity promise statements)
4. USP Candidates (5-10 with full analysis)
5. Top 3 USP Identity Architecture Documents
6. Ranking Matrix and Recommendation
7. Identity Permission Statement

**Target length:** 2,500-4,000 words.

**Language rule:** NEVER use avoidance language anywhere in this document. Every sentence points toward identity, aspiration, becoming, belonging, mastery, community, self-expression. If a sentence uses pain language, rewrite it or delete it.

---

## QUALITY GATE

Before saving, verify:

- [ ] Every Level 3 promise describes who the buyer BECOMES — not a problem they solve, not a skill they acquire in isolation
- [ ] At least 5 of the 10-15 promise statements name a specific type of person (not just a transformation in the abstract)
- [ ] Every USP candidate has been tested against "Can competitors claim this?" with a specific answer
- [ ] Schwartz aspiration level matched to at least 3 of the USP candidates
- [ ] At least one USP candidate uses WHO specificity as its primary differentiator (not mechanism)
- [ ] Identity Permission Statement is present and standalone
- [ ] Zero avoidance language anywhere in the document
- [ ] Proof architecture for top candidates specifies mirrors (demographically identical people who made the transformation) — not just generic testimonials
- [ ] Saved to file

---

## HOW THIS CONNECTS DOWNSTREAM

This skill outputs feed:
- **toward-demand-architect** → USP becomes the headline direction for all Toward Markets copy
- **aspiration-mimetic-intelligence** → Check USP identity promises against what competitors mediate — is the territory actually open?
- **permission-concept-generator** → Core Concept must resolve the identity permission gap; USP expresses it as a deliverable promise
- **community-architect** → Community design starts from the belonging promise embedded in the USP
- **identity-belief-gap-analyzer** → The USP is Point B; belief gap analysis traces the exact journey from "curious" to "I can claim this identity"
- **Copywriting skills** → The USP is the single most important input to the headline and lead
- **toward-desire-mapper** → The USP must connect back to the dominant L1 aspiration and resolve the primary identity permission gap identified in Phase 4
