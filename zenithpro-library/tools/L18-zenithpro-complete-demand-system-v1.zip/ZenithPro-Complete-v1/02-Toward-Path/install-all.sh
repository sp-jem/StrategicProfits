#!/bin/bash
SKILLS=("toward-desire-mapper" "aspiration-excavation" "aspiration-avatar-excavation" "progression-pattern-analysis" "permission-concept-generator" "ideal-aspiration-mindset" "identity-belief-gap-analyzer" "toward-usp-generator" "aspiration-mimetic-intelligence" "community-architect" "toward-demand-architect")
echo "Installing ZenithPro Toward Path (11 skills)..."
SUCCESS=0; FAILED=0
for SKILL in "${SKILLS[@]}"; do
  mkdir -p "$HOME/.claude/skills/$SKILL"
  cp "$SKILL/SKILL.md" "$HOME/.claude/skills/$SKILL/SKILL.md"
  if [ -f "$HOME/.claude/skills/$SKILL/SKILL.md" ]; then echo "✅ $SKILL"; ((SUCCESS++))
  else echo "❌ $SKILL"; ((FAILED++)); fi
done
echo "Installed: $SUCCESS / 11 | Run: /toward-demand-architect full [your market]"
