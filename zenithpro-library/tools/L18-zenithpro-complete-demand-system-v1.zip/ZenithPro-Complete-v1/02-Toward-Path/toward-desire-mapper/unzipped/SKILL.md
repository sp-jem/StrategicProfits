---
name: toward-desire-mapper
description: "Maps the complete aspiration hierarchy that drives purchase decisions in approach-motivated markets — markets where buyers move TOWARD identity, mastery, community, and self-expression rather than AWAY from pain. Synthesizes Reese's 16 Basic Desires (approach-weighted), Schwartz's desire-channeling insight, and the D3 belief architecture — with L4 reframed as Identity Permission (not self-efficacy). Produces a full L1-L4 aspiration map plus Aspiration Stratigraphy. Use this FIRST in any Toward Markets demand creation project. Part of the ZenithPro: Toward Markets pipeline."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/toward-desire-mapper [business or market]"
  called_by: [user, toward-demand-architect]
  outputs_to: [project folder]
---

# Toward Desire Mapper

Maps the complete aspiration hierarchy for approach-motivated markets — desire architecture from L1 core desires through the belief layers that channel them into demand for people moving TOWARD something.

---

## LAYER 1: INVARIANTS

1. **L1 desires are NEVER created — they are identified.** Reese's 16 desires are empirically established. You map which ones are active and approach-weighted for this market, not which ones would be convenient.
2. **Each level of the hierarchy must logically connect to the next.** L2 channels L1. L3 channels L2. L4 produces demand. A gap at any level = a gap in the marketing.
3. **L4 is IDENTITY PERMISSION — not self-efficacy.** The question is never "Can they implement this?" The question is "Is this identity available to someone like them?" This is the single most important difference from avoidance-motivated desire mapping.
4. **Every claim about desire channeling must be grounded in actual market evidence** — not assumptions. Use reviews, testimonials, community posts, and forum language as evidence.
5. **Suppressed aspirations are often the most powerful.** Surface them explicitly.
6. **Save all outputs to files.** Never deliver analysis only in chat.

---

## PURPOSE

Answers the fundamental question that precedes all Toward Markets work:

> "Which of the 16 unchangeable human desires is my market approaching — and through what identity-permission architecture does aspiration channel into demand?"

In avoidance markets, Schwartz's channeling mechanism runs: Pain → Category → Product → Self-efficacy → Buy.

In approach markets, the mechanism runs: **Aspiration → Category → Product → Identity Permission → Buy.**

The desire is the same (Reese's L1 list is universal). The direction is reversed. And L4 is completely different — the final gate is not "Can I do this?" but "Is this version of me actually possible?"

**Output use:** The completed aspiration hierarchy becomes the master brief for all downstream Toward Markets work — aspiration excavation, avatar building, progression pattern analysis, permission concept generation, belief gap mapping, USP, community architecture.

---

## INPUTS

Gather from the user before running:

1. **Business/product name** and brief description
2. **Target market description** (2-3 sentences — who they are, what they're drawn to, what they aspire to become or experience)
3. **Avatar type** (e.g., women 55+ learning to sketch, adult beginners learning piano, retirees learning a language — or "identify for me")
4. **Any existing customer research** — testimonials, reviews, community posts, survey data (optional but significantly improves quality)
5. **Output folder path** (ask if not specified — default: project folder for this client/business)

---

## FRAMEWORK: THE THREE SYNTHESES

### Synthesis 1: Reese's 16 Basic Desires (Level 1)

Scientific L1 desires — each person has all 16 but at different intensities. UNCHANGEABLE. The approach-motivated version identifies which desires your market is moving TOWARD at high intensity:

| Desire | Core Drive | Approach Expression |
|--------|-----------|-------------------|
| Power | Influence, achievement, leadership | Creative power — the ability to make something from nothing |
| Independence | Freedom, autonomy, self-reliance | Creating on your own terms, at your own pace |
| Curiosity | Learning, truth-seeking, mental stimulation | The drive to learn to SEE, think, or perceive differently |
| Acceptance | Belonging, approval, social connection | Being seen as someone who creates; earning an identity |
| Order | Organization, certainty, predictability | Mastery — the satisfaction of a skill becoming reliable |
| Saving | Wealth preservation, frugality | Not typically primary in approach markets |
| Honor | Integrity, loyalty, moral code | Creating as a way of honoring something — a place, a tradition, a craft |
| Idealism | Justice, equality, cause-driven meaning | Art/music/craft as a higher value; preserving beauty |
| Social Contact | Companionship, friendship, camaraderie | Communities of shared passion; belonging to a tribe |
| Family | Parenting, legacy, generational thinking | Creating something to pass down; shared activity with family |
| Status | Prestige, reputation, recognition | "I'm an artist" — the identity claim (often suppressed) |
| Vengeance | Competition, victory | Not typically primary in approach markets |
| Romance | Beauty, partnership, attraction | Beauty-seeking; the aesthetic experience of creating |
| Eating | Pleasure, comfort, sensory experience | Flow state pleasure; the sensory experience of craft |
| Physical Activity | Health, strength, vitality | Not typically primary unless the craft is physical |
| Tranquility | Safety, peace, freedom from anxiety | Flow state; meditative absorption; presence |

### Synthesis 2: Schwartz's Channeling Insight (the bridge)

Desires don't create demand on their own. Between L1 and purchase is a channeling process — a specific belief structure that directs aspiration toward a particular solution. In approach markets, this channel runs through identity transformation, not problem resolution.

### Synthesis 3: D3 Belief Architecture (Levels 2-4) — Approach-Motivated Version

- **L2: Category Beliefs** — "This type of learning/experience can help me BECOME the kind of person I want to be"
- **L3: Product Beliefs** — "This specific product is designed for someone LIKE ME to make that transformation"
- **L4: Identity Permission Beliefs** — "The person I want to become is actually available to someone like me — at my age, with my background, starting now"

**The Toward Markets formula: Aspiration + Identity Permission = Demand**

---

## EXECUTION PROTOCOL

### Phase 1: L1 Desire Identification

Analyze the market and identify:

1. **Primary L1 desires** (top 2-3 that pull this market most powerfully toward the aspiration)
2. **Secondary L1 desires** (supporting desires that amplify the primary)
3. **Suppressed desires** (aspirations the market holds but won't state publicly — often the most powerful purchase drivers)

For each primary desire, answer:
- How does this desire manifest as APPROACH motivation in this specific market?
- What does a person with high intensity of this desire look like when they're pursuing it?
- What would they invest (money, time, identity risk) to move toward having this desire satisfied?

**Evidence requirement:** Ground each desire in specific language from the market — reviews, community posts, testimonials, forum threads. Not assumed.

---

### Phase 1b: Aspiration Stratigraphy

For the dominant L1 desire(s), map the three aspiration layers:

| Layer | What It Sounds Like | What It Actually Means |
|-------|--------------------|-----------------------|
| **Surface** | "That looks fun, I'd like to try it" | Curiosity, low commitment |
| **Middle** | "I want to be someone who creates things" | Identity desire, moderate investment |
| **Deep** | "I want purpose, expression, meaning in this chapter of my life" | Existential need, highest purchase motivation |

The deep layer is where the real purchase decision lives. Surface-layer messaging produces browsers. Deep-layer messaging produces buyers.

For each layer, identify:
- The specific language this market uses at this depth
- What content/proof reaches them at this depth
- How far below the surface most marketing in this category operates (usually surface only)

---

### Phase 2: L2 Category Belief Mapping

For each primary L1 desire, map:

1. **What category of solution does this market believe can help them BECOME who they want to be?**
   - Frame: "This type of [course/community/program] can transform someone into a person who [does/creates/belongs to X]"
2. **What limiting L2 beliefs block this?**
   - Identity limits: "That transformation isn't really possible through a course"
   - Category skepticism: "Online learning can teach technique but not the real thing"
3. **What enabling L2 beliefs must exist for demand to flow?**
4. **Market sophistication level** (how many times have they tried something in this category and quit?)

---

### Phase 3: L3 Product Belief Mapping

1. **What specific product beliefs are required for purchase?**
   - *Fit belief:* "This was designed for someone in my exact situation — my age, my background, my starting point"
   - *Method belief:* "This approach specifically builds the real skill/identity, not a surface imitation"
   - *Community belief:* "The people in this program are people I want to belong with"

2. **What L3 beliefs are blocking purchase right now?**
   - Prior abandonment: "I've bought courses before and they all sit unwatched"
   - Intimidation: "The teacher is so advanced I'll feel inadequate, not capable"
   - Skepticism about fit: "This seems designed for people already ahead of me"

---

### Phase 4: L4 Identity Permission Mapping

**This is the most critical phase. The question is never "Can they implement this?" It is always: "Is this identity available to someone like them?"**

Map the current identity permission barriers:

1. **Identity prohibitions** — explicit beliefs that this identity isn't for them
   - Common forms: "I'm not creative," "Real artists start young," "I'm too old for this"
   - Age-based: "That identity belongs to a different chapter of life"
   - Background-based: "You need natural talent/formal training/a different kind of mind"

2. **Gap prohibitions** — beliefs that the distance is uncrossable
   - "I could never produce anything like [expert] does"
   - "The gap between where I am and where I want to be is too large"

3. **Required identity permission** — what must become true for them to buy:
   - "Learning this is not about talent — it's about process, and process is available to anyone"
   - "I don't need to become [expert] — I need to become the version of ME who does this"
   - "Starting now, at this age, is not a disadvantage — it comes with things younger starters don't have"

4. **What creates this shift:**
   - NOT: a better explanation of the mechanism
   - YES: a mirror — social proof from people demographically identical to them who now live the identity

For each identity permission barrier, specify:
- The exact belief that must shift
- The type of evidence that shifts it (testimonial, demonstration, before/after story, etc.)
- The demographic specifics of the "mirror" required

---

### Phase 5: Channel Maps

Produce a visual representation for each primary desire showing:

```
L1 ASPIRATION: [Desire name — what they're moving TOWARD]
       ↓ channels through
L2 CATEGORY BELIEF: "[This type of solution can help me become X]"
       ↓ channels through
L3 PRODUCT BELIEF: "[This specific product is right for someone like me]"
       ↓ channels through
L4 IDENTITY PERMISSION: "[The person I want to become is available to me]"
       ↓ produces
DEMAND: [Purchase becomes inevitable when all 4 align]
```

Produce this map for each primary L1 desire. Minimum 2 maps.

For each map, note:
- Which level is strongest (existing belief that already supports purchase)
- Which level is the weakest link (where demand is being blocked)

---

### Phase 6: Gap Analysis

For each channel:

1. **Where is the channel STRONG?** Existing beliefs that already pull toward purchase
2. **Where is the channel BROKEN?** The specific level where aspiration stops converting to demand
3. **Highest-leverage intervention:** Almost always at L4 (identity permission) in approach markets — identify the single mirror that, if shown, would unblock the most demand
4. **Intervention type:** Specify exactly what content/proof creates the shift
   - Mirror testimony (demographically identical person who made the transformation)
   - Demonstration (watching the expert do it makes "I could do that" feel real)
   - Small win (a quick partial experience of the skill creates identity claim)
   - Community visibility (seeing the tribe makes belonging feel available)

---

## OUTPUT SPECIFICATION

Save to the specified output folder:

**File: `Aspiration-Hierarchy-Map-[Market].md`**

Structure:
1. Executive Summary (3 sentences: dominant desire, identity permission gap, highest-leverage intervention)
2. L1 Primary Desire Analysis with evidence
3. Aspiration Stratigraphy (surface/middle/deep for dominant desire)
4. L2 Category Belief Map (current blocking beliefs + required enabling beliefs)
5. L3 Product Belief Map (current blocking beliefs + required enabling beliefs)
6. L4 Identity Permission Map (barriers + required permissions + mirror specifications)
7. Complete Channel Maps (minimum 2, one per primary desire)
8. Gap Analysis with priority interventions
9. Strategic Implications for downstream work

**Target length:** 1,500-3,000 words. Depth on the 2-3 most powerful desires beats breadth on all 16.

**Language rule:** NEVER use avoidance language (pain, frustration, failure, broken, stuck, struggling) unless explicitly contrasting with aspiration. This document is written in the language of approach.

---

## QUALITY GATE

Before saving, verify:

- [ ] Every L1 desire is grounded in real market evidence (not assumed)
- [ ] Aspiration Stratigraphy shows meaningfully different content at surface/middle/deep
- [ ] L4 section is framed as Identity Permission — no self-efficacy language anywhere
- [ ] At least 2 complete Channel Maps from L1 → demand
- [ ] Gap Analysis identifies a "mirror" intervention, not a mechanism explanation
- [ ] Strategic Implications point toward demonstration, identity mirrors, and community content — NOT toward paradigm shifts about why previous solutions failed
- [ ] Output reads as structurally different from an avoidance-motivated desire map — no pain language, no failure language, no mechanism language

---

## STRATEGIC IMPLICATIONS TEMPLATE

The final section must answer these questions:

1. **What is the dominant aspiration this market needs to see reflected back at them?** (The deep-layer aspiration from Stratigraphy)
2. **What is the identity permission gap blocking the most demand?** (From L4 analysis)
3. **What is the single most powerful mirror that would unblock it?** (Specific demographic + transformation)
4. **What demonstration content would create the "I could do that" moment?** (From L2/L3 analysis)
5. **What does the community need to look like for belonging to feel available?** (Feeds community-architect)
6. **What copy direction does this suggest?** (Not "Are you tired of X?" — but "Watch this..." / "She learned in 6 weeks...")

---

## HOW THIS CONNECTS DOWNSTREAM

This map becomes the master input for:
- **aspiration-excavation** → deepens understanding of HOW aspirations manifest psychographically
- **aspiration-avatar-excavation** → shows which avatar has which aspiration intensities and identity permission gaps
- **progression-pattern-analysis** → uses aspiration stratigraphy to understand what moves people from surface to deep commitment
- **permission-concept-generator** → Core Concepts must create the specific identity permission shifts identified in L4
- **identity-belief-gap-analyzer** → uses this map to trace the exact belief journey from "curious" to "I can become this"
- **toward-usp-generator** → USP must connect to dominant L1 aspiration and resolve the primary identity permission gap
- **aspiration-mimetic-intelligence** → compare your aspiration map to what competitors are mediating
- **community-architect** → community design starts from the social desire structure and identity permission gaps mapped here
