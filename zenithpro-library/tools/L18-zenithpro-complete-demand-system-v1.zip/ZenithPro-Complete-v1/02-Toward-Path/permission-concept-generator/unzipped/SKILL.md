---
name: permission-concept-generator
description: "Generates Core Concepts that shift identity permission — paradigm-level reframes that make 'I CAN do this' feel true and inevitable. Five formula types: Hidden Unlock, Permission Shift, Mastery Bridge, Right Path, Identity Invitation. The approach-motivated equivalent of core-concept-generator — paradigm shifts about the SELF, not the solution. Part of the ZenithPro: Toward Markets pipeline."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/permission-concept-generator [market or avatar]"
  called_by: [user, toward-demand-architect]
  outputs_to: [project folder]
---

# Permission Concept Generator

Generates the paradigm-level reframes that make "I CAN do this" feel true and inevitable. Not a positioning statement. Not a benefit. A single belief intervention about the SELF that, once accepted, makes the aspiration feel genuinely available — and makes not pursuing it feel like a loss.

---

## LAYER 1: INVARIANTS

1. **A Permission Concept is a belief intervention about the SELF, not about the solution.** If the concept is about why the method works, why previous approaches failed, or what mechanism drives results — that is a Core Concept for an avoidance market. Discard it and regenerate.
2. **The identity permission test is mandatory.** Every concept must pass this test before proceeding: "Does this shift a belief about whether this identity is available to someone like them — or does it shift a belief about how the solution works?" If the answer is the solution, rewrite.
3. **Permission Concepts do not argue.** They reveal. The prospect does not need to be convinced by logic — they need to SEE something about themselves that makes the aspiration feel real and accessible. Every concept must create that seeing, not that reasoning.
4. **Demographic specificity is non-negotiable.** "Anyone can do this" is not a Permission Concept — it is a platitude. A Permission Concept names who the person is and makes the permission specific to them. "Women who have never considered themselves creative can produce work that moves people" is stronger than "creativity is available to everyone."
5. **Every concept must pass all four quality tests** before being included in the output.
6. **Save all outputs to files.** Never deliver in chat only.

---

## PURPOSE

The Permission Concept is the highest-leverage intellectual property in Toward Markets demand creation.

In avoidance markets, the Core Concept creates: **"Oh my God. THAT'S why nothing has worked."**

In approach markets, the Permission Concept creates: **"Oh my God. I CAN actually do this."**

These are not the same shift. The avoidance shift is about the solution. The approach shift is about the self. Both are paradigm-level. Both are one-sentence reframes. The content is completely different.

When a Permission Concept lands, it does four things simultaneously:
1. Dissolves the identity prohibition that has kept them from claiming the aspiration
2. Makes the person feel seen at a deeper level than any marketing they have encountered
3. Makes the aspiration feel genuinely available — not aspirationally distant, but concretely accessible
4. Makes the product feel like the natural next step toward a self they now believe is possible

**The success formula:** If prospect accepts [Permission Concept] → pursuing [your solution] becomes the obvious expression of who they already are or are becoming.

**Output use:** The Permission Concept drives headline strategy, webinar structure, lead content, testimonial selection, demonstration design, and all copy that operates at the identity level — which in approach-motivated markets is almost all of it.

---

## INPUTS

Required before running:

1. **Progression Landscape Map** (from progression-pattern-analysis — especially the Plateau Paradoxes, Dip Anatomy, and Commitment Trigger Analysis)
2. **Aspiration Hierarchy Map** (from toward-desire-mapper — especially the L4 Identity Permission section: what specific identity prohibitions are blocking purchase)
3. **Market/avatar description** (who they are, what they aspire to become, where they are in the progression arc)
4. **Product/solution description** (what specifically it offers and who it is designed for)
5. **Output folder path**

Optional but significantly improves quality:
- Testimonials and before/after stories from existing students (especially first-person language about the identity shift)
- Community posts where practitioners describe their own journey in their own words
- Competitor positioning (what identity claims competitors are and are not making)

---

## PRELIMINARY ANALYSIS

Before generating concepts, answer these three questions explicitly. The quality of your Permission Concepts depends on the quality of these answers.

### Step 1: Name the Identity Prohibitions

From the L4 analysis in the Aspiration Hierarchy Map, extract the specific beliefs that block identity adoption. These are the beliefs your Permission Concepts must dissolve.

List them in first-person market language (how the prospect actually says them internally):

Examples:
- "Real artists start young. I missed that window."
- "I don't have a creative bone in my body."
- "I could never produce anything worth sharing."
- "People like me don't do things like this."
- "I'd need formal training first."

For each prohibition, identify:
- The specific demographic assumption embedded in it (age, background, prior history, personality type)
- The gatekeeping belief it encodes (what you apparently need that they don't have)
- What would need to become true for this prohibition to dissolve

---

### Step 2: Find the Inversion

For each identity prohibition, find the factual or empirical inversion — the truth that makes the prohibition seem not just wrong but backwards.

The strongest Permission Concepts don't argue against the prohibition. They reveal that the prohibition has the causality exactly reversed.

Examples:
- Prohibition: "Real artists start young."
  Inversion: "Artists who start later produce work with more emotional depth, not less — because they're drawing from a life already lived."

- Prohibition: "I don't have a creative bone in my body."
  Inversion: "Creativity in this domain is not a trait you have — it is a capacity that the act of practice builds. The people who start without it often develop it more deliberately than people who assumed they already had it."

- Prohibition: "I could never produce anything worth sharing."
  Inversion: "The impulse to share comes from caring about what you made. That caring arrives before the skill does. The people whose first works move others are almost always people who cared deeply — not people who were already skilled."

For each prohibition: Write the inversion in one or two sentences. This becomes the core of the Permission Concept.

---

### Step 3: The Master Question

Before generating concepts, answer this:

> **"What would need to become true about who they are — not about what they can learn — for the aspiration to feel genuinely available to them?"**

Write this out explicitly. All five concepts must create that shift from different angles.

---

## THE FIVE GENERATION FORMULAS

Generate at least one concept using each formula. Every formula targets a different type of identity prohibition. Use all five — then select and refine the strongest.

---

### Formula 1: The Hidden Unlock

**Structure:** "The reason [aspiration is accessible] is [surprising truth that inverts the gatekeeping assumption]."

This formula reveals a hidden reason why the aspiration is MORE available to this specific person than conventional wisdom suggests. The inversion must be genuine and factual — not reassurance, but revelation.

**Process:**
1. Identify the most powerful gatekeeping assumption in this market (the thing that makes people feel excluded)
2. Find the factual truth that inverts it — the reason why the assumed barrier is actually neutral or irrelevant, or why the assumed advantage is actually a disadvantage
3. Make the inversion specific to the demographic of your market
4. State it as a revelation, not an argument

**Example (urban sketching market, women 55+):**
"The reason sketchers who start in their 50s and 60s often produce more emotionally resonant work than people who trained for years is that they draw from a fully lived life — and a fully lived life is the only thing that makes a drawing mean something to another person."

**Quality Test:** Does this make someone feel seen and invited — not just reassured?

---

### Formula 2: The Permission Shift

**Structure:** "[Assumed prerequisite] isn't what you need to start — it's what you develop by starting."

This formula takes the thing the market believes is a prerequisite for claiming the identity and reveals that it is actually an output of the practice, not an input. The permission is immediate and unconditional.

**Process:**
1. Identify the most common prerequisite belief ("I need talent / training / confidence / time / a certain type of mind")
2. Show that this prerequisite is actually what the practice builds — not what you need to begin
3. Name who gets to start without it (i.e., everyone, or specifically people like them)
4. Make the permission feel like a fact, not an encouragement

**Example:**
"Artistic talent isn't a prerequisite for urban sketching — it's an outcome of it. You don't need to arrive with it. You develop it by showing up."

**Quality Test:** Does this remove the waiting condition — the "I'll start when I have X" — and make starting now feel immediately valid?

---

### Formula 3: The Mastery Bridge

**Structure:** "The gap between [where they are] and [who they want to be] is actually [much smaller than they believe] because [reason]."

This formula addresses the distance prohibition — the belief that mastery is so far away it is effectively out of reach. It does not minimize the gap. It reveals that a specific, achievable part of the gap is shorter than they think, which changes the emotional math of the decision.

**Process:**
1. Identify the specific gap they perceive (not general "I'm not good enough" — the specific skill or capacity they believe they lack)
2. Find the specific, empirically supportable claim about how short that particular gap actually is
3. Explain the mechanism that makes it shorter than they believe (not "with the right training" — a real structural reason)
4. Frame it so that "starting now" becomes the logical response to this shorter gap

**Example:**
"Most people believe learning to draw what you see requires years of training. But the specific skill of visual observation — learning to really see what's in front of you rather than what you expect to be there — can be meaningfully developed in six weeks of consistent practice. The years are for refinement. The foundation is much closer than it looks."

**Quality Test:** Does this make the aspiration feel concretely achievable without minimizing the aspiration itself?

---

### Formula 4: The Right Path

**Structure:** "Most [category] is designed for [different type of person]. [This approach] is designed specifically for [people like them]."

This formula addresses the fit prohibition — the belief that the existing solutions are for people who are already different from them (younger, more trained, more talented, more certain). It positions this specific approach as the one designed for people exactly like them — not as a consolation, but as a superior fit.

**Process:**
1. Identify what most offerings in this category are implicitly designed for (and who that excludes)
2. Show that the exclusion is real — most instruction in this category does assume things about the student that this market doesn't have
3. Position this approach as explicitly designed for people in their specific situation — with their specific starting point, life context, and aspiration type
4. Make "designed for people like them" feel like an advantage, not a lowered standard

**Example:**
"Most art instruction is designed for people who want to become fine artists. Urban sketching is designed for people who want to fall back in love with the world — to see it differently, record it, carry it with them. Those are not the same aspiration, and they don't need the same path."

**Quality Test:** Does this make them feel like they've finally found something built for them — not a fallback, but the right fit for who they actually are?

---

### Formula 5: The Identity Invitation

**Structure:** "The identity of [who they want to be] doesn't require [gatekeeping requirement]. You earn it by [first accessible action]."

This formula explicitly extends the identity to them — now, not after they've earned it through some distant achievement. It names the identity, dissolves the earning condition, and replaces it with a first step that is immediately within reach.

**Process:**
1. Name the practitioner identity they want to claim (be specific — not "artist" but "sketcher," not "musician" but "someone who plays piano")
2. Identify the gatekeeping requirement they believe stands between them and that identity (talent, training, years of practice, a certain level of quality, public recognition)
3. Dissolve that requirement — not by arguing against it, but by replacing it with a more accurate and immediate earning condition
4. State the first action that earns the identity — something they could do today

**Example:**
"You don't need permission to call yourself a sketcher. You become a sketcher the first time you put pen to paper with intention. That's it. That's the full requirement. Everything else is just being a more experienced sketcher."

**Quality Test:** Does this make the identity feel immediately claimable — not someday, but now or with the very next action?

---

## FOUR QUALITY TESTS (All Required)

For every concept generated, verify all four tests pass before including it in the output:

### Test 1: The Self-Check Test (most important)
- Is this a shift about the SELF — about whether the identity is available to them?
- Or is it actually a shift about the solution — about why this method works, why previous methods failed, or what mechanism drives results?
- If it is about the solution: discard and regenerate. It belongs in core-concept-generator, not here.
- **A concept that passes this test:** Could not come from an avoidance-motivated market without complete rewriting.

### Test 2: The Recognition Test
- When they hear this, do they feel SEEN — like someone finally articulated something true about them?
- Or do they feel PERSUADED — like they're being argued into something?
- Permission Concepts create recognition, not persuasion. If it feels like an argument, rewrite it as a revelation.

### Test 3: The Inevitability Test
- If they accept this concept, does pursuing the practice (and the product) feel like the natural next step?
- Does NOT pursuing it feel like a small loss — like ignoring something that just became possible?
- If acceptance doesn't create forward pull: rewrite.

### Test 4: The Memorability Test
- Can they explain this to someone else in one sentence?
- Would they remember it a week later without notes?
- Is the specific insight quotable — something they'd actually repeat?

Discard any concept that fails any test. Only present concepts that pass all four.

---

## OUTPUT FORMAT

For each Permission Concept (target: 5, one per formula, all passing all four tests):

---

### PERMISSION CONCEPT #[X]: [Memorable Name]

**The Permission Concept** (the single sentence or two sentences):
> "[The concept that makes the identity feel available]"

**Formula Used:** [Hidden Unlock / Permission Shift / Mastery Bridge / Right Path / Identity Invitation]

**The Four Tests:**
- Self-Check Test: [Pass — this is about the self / Fail — rewrite reason]
- Recognition Test: [Pass — creates recognition / Fail — rewrite reason]
- Inevitability Test: [Pass + what forward pull it creates]
- Memorability Test: [Pass + the quotable version]

**The Prohibition Dissolved:**
- The belief that was blocking them: "[Their actual internal voice]"
- Why this concept dissolves it: [One sentence — the mechanism of the shift]

**The Inversion:**
- What they believed: [The prohibition in their words]
- What is actually true: [The factual inversion]
- Why this inversion is surprising: [What makes it non-obvious]

**Demographic Specificity:**
[Name specifically who this permission is being extended to — age, background, starting point. The more specific, the more powerful. "Someone who has never touched a sketchbook and believes they have no creative ability" is stronger than "beginners."]

**Proof Architecture:**
- Empirical proof: [A specific fact, study, or data point that makes the inversion credible]
- Social proof: [The type of testimonial or before/after story that makes it real — specifically: what demographic, what transformation, what the person says now]
- Experiential proof: [Something the prospect has already experienced that, once framed this way, validates the concept]

**The Mirror Required:**
[Describe the specific demographic and transformation of the social proof that most powerfully validates this concept. "A 62-year-old woman with no art background who now leads sketching walks in her city" is a specification, not a demographic.]

**The Transformation Story** (2-3 sentences):
[How their relationship to the aspiration changes when they accept this concept — not what they do, but how they experience themselves in relation to the aspiration.]

**Where This Appears in the Funnel:**
- Where it lands hardest: [Webinar opening / demonstration video / testimonial framing / email subject line / sales page headline]
- Content that installs this belief: [2-3 specific content pieces that create this shift before the pitch]
- How it connects to purchase: [The specific bridge from this belief to the product as the next step]

---

## CONCEPT RANKING

After generating all five, rank them:

1. **Strongest for immediate conversion** (sales page / webinar moment of truth use)
2. **Strongest for content and demonstration** (building the belief over time before the pitch)
3. **Strongest for testimonial framing** (how to frame social proof to maximize identity permission transfer)
4. **Strongest for virality** (most likely to be shared because it articulates something the market has always felt but couldn't say)
5. **Strongest for objection prevention** (addresses the deepest identity prohibition before it becomes an objection)

Recommend the primary concept and explain the strategic reasoning in 2-3 sentences.

---

## QUALITY GATE

Before saving, verify:

- [ ] 5 concepts generated, one per formula
- [ ] Every concept passed the Self-Check Test (about the SELF, not the solution)
- [ ] No avoidance language anywhere in the concepts themselves (pain, failure, frustration, broken, stuck — unless in the "What They Believed" section, accurately quoting their internal voice)
- [ ] Every concept includes a Mirror Required specification (not a vague "social proof" but a demographic + transformation specification)
- [ ] Proof Architecture for each concept includes at least empirical AND social proof types
- [ ] All four quality tests passed for each concept included in output
- [ ] Concept ranking with strategic reasoning complete
- [ ] Output saved to file

---

## HOW THIS CONNECTS DOWNSTREAM

- **identity-belief-gap-analyzer** → The prohibitions dissolved by each concept map directly to the belief gaps that must be bridged. This output gives the gap-analyzer its primary raw material.
- **toward-usp-generator** → The USP must express the Permission Concept as a deliverable promise — "the program that makes [the permission] real" rather than "the program that teaches [the mechanism]."
- **community-architect** → The Mirror Required specifications in each concept tell the community architect exactly what social proof architecture to build — what demographics must be visible, what stories must be featured.
- **copywriting skills** → The Permission Concept drives the opening hook, the lead, the demonstration structure, and the identity-level proof elements. For approach-motivated markets, this replaces the Core Concept as the primary belief lever.
- **toward-desire-mapper** → These concepts should resolve the L4 identity permission gaps identified in the Aspiration Hierarchy Map. Cross-check: does each concept dissolve one of the L4 prohibitions mapped there?
- **progression-pattern-analysis** → Plateau paradoxes and Dip anatomy from the Progression Landscape Map should be visible in the Permission Concepts. If they're not, the concepts are operating at the surface level — deepen them.
