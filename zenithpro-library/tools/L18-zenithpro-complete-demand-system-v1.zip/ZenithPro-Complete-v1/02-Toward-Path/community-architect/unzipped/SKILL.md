---
name: community-architect
description: "Designs the complete tribal identity and community architecture for approach-motivated markets. Covers: tribal identity naming, mimetic desire flywheel, progression visibility, retention mechanics, membership economics, and value ladder integration. The one skill in the Toward Markets pipeline with no ZenithPro equivalent — community IS the product in approach markets. Part of the ZenithPro: Toward Markets pipeline."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/community-architect [business or market]"
  called_by: [user, toward-demand-architect, aspiration-avatar-excavation]
  outputs_to: [project folder]
---

# Community Architect

Designs the complete tribal identity and community architecture for approach-motivated markets — where community is not a nice-to-have feature but the primary retention and demand-creation mechanism.

---

## LAYER 1: INVARIANTS

1. **Community is not optional in approach markets — it IS the product.** Content creates initial purchase. Community creates retention, referrals, and LTV. A market where people are moving TOWARD identity, mastery, or belonging cannot be served by content alone.
2. **The tribal identity name is NEVER the course or product name.** Members claim an identity ("I'm an Urban Sketcher"), not a product ("I'm in Ian's course"). This distinction is foundational. Get it wrong and the community remains a customer list, not a tribe.
3. **The mimetic flywheel creates its own demand without marketing spend.** Members who share their work generate desire in others. Design this mechanism explicitly — don't assume it happens naturally.
4. **Progression visibility is how aspiration stays alive inside existing members.** Without visible role models at the next level, advancement feels hypothetical. Beginners must be able to see what's possible.
5. **Never design community as content delivery infrastructure.** Content serves the individual. Community serves belonging. Confusing the two produces a "library with live chat" — not a tribe.
6. **The first win experience must arrive before the first doubt.** New members have a short window before buyer's remorse sets in. Design the path to first shareable output as if it were the most important product feature — because it is.
7. **Save all outputs to files.** Never deliver community architecture only in chat.

---

## PURPOSE

Answers the fundamental community question for approach-motivated markets:

> "What is the tribal architecture — identity, language, rituals, progression, economics — that makes this community self-sustaining, self-recruiting, and more valuable than the content it surrounds?"

In avoidance markets, the product IS the solution. The customer relationship ends when the problem is solved.

In approach markets, the journey never ends. There is always a next level, a next challenge, a deeper belonging. **This means the community architecture is the business model, not a support structure for it.**

The output of this skill is the complete blueprint for that architecture — what the tribe is called, how members recognize each other, what they do together, how they advance, how they recruit organically, and how the economics of belonging are structured.

**Output use:** The completed Community Architecture document becomes the operating brief for platform decisions, content strategy, membership tier design, launch planning, and ongoing community management. It also feeds the value ladder integration and informs all conversion copy for community-based offers.

---

## INPUTS

Gather from the user before running:

1. **Business/market name** and brief description of what's being taught or experienced
2. **Target market description** (who they are, what they aspire to become or experience, what stage of life/career they're in)
3. **Existing product or offer** (what's already being sold, if anything — course, membership, coaching, events)
4. **Current community state** (nothing yet / small private group / existing Facebook group / active Discord / etc.)
5. **Aspiration Hierarchy Map** (output from toward-desire-mapper, if available — significantly deepens tribal identity design)
6. **Price point range** (approximate — helps calibrate membership economics)
7. **Output folder path** (ask if not specified — default: project folder for this client/business)

---

## FRAMEWORK: THE THREE PRINCIPLES OF TRIBAL ARCHITECTURE

### Principle 1: Identity Before Infrastructure

The community platform (Facebook, Discord, Skool, Circle) is irrelevant until the tribal identity is clear. Members join platforms. They stay for identities. Design the identity first, choose the platform second.

### Principle 2: Mimetic Contagion is the Marketing

In approach markets, the best marketing is a member sharing their work publicly. A sketch posted to Instagram. A song played for friends. A sentence written in a new language. Every member output that reaches non-members is a referral with an emotional signature no ad can replicate. Design for this.

### Principle 3: The Progression Architecture is the Retention Mechanism

Members leave when they can't see what's next. They stay — and recruit — when the next level is visible, desirable, and feels reachable. The progression ladder is not a curriculum design decision. It is a retention design decision.

---

## EXECUTION PROTOCOL

### Phase 1: Tribal Identity Design

The goal of this phase is to name and define the identity that members will claim — publicly, proudly — as a result of belonging to this community.

**1.1 — The Group Name**

Determine the tribal identity label. Rules:
- It must be a noun phrase the member uses to describe themselves, not the program: "I'm an Urban Sketcher" not "I'm in Ian's Urban Sketching Mastery"
- It should be claimable at the beginner level — the identity is available from day one, not earned only by advanced members
- It should travel outside the community — members should use this identity in bio lines, conversation, and social profiles
- It may already exist in the market (identify it) or need to be coined (create it)
- Test: "Would someone say this out loud at a party when asked what they do for fun?"

**Produce:**
- Primary tribal identity name (e.g., "Urban Sketcher," "Jazz Improviser," "Sourdough Baker")
- 2-3 alternatives if primary is not distinct enough
- Rationale for the chosen name

**1.2 — The Tribal Vocabulary**

Identify or create the insider language that signals belonging. This vocabulary separates members from outsiders.

Categories:
- **Activity terms** — what members call the things they do (e.g., "sketch walk," "plein air," "jam session")
- **Progression terms** — what members call the stages of advancement (e.g., "newbie sketcher," "urban sketcher," "street artist")
- **Tools and methods** — named techniques or approaches unique to this community (e.g., a named method, a trademarked approach, a community shorthand)
- **Insider references** — recurring jokes, references, or language that only members understand

**Produce:** A Tribal Vocabulary table with 8-15 terms, their definitions, and their function (belonging signal, progression marker, activity label, etc.)

**1.3 — The Shared Beliefs**

Identify the 3-5 beliefs that unite all members — beliefs that outsiders don't hold, that differentiate this tribe from the general population, and that make belonging feel exclusive and meaningful.

Rules:
- These are beliefs, not facts. They are articles of faith the tribe holds.
- They should be contestable — if everyone agrees, they're not beliefs, they're conventions.
- They should make members feel slightly superior to those who don't hold them.

Examples for urban sketching: "Drawing from life is more alive than photography." / "The goal is presence, not perfection." / "The city is always your studio."

**Produce:** 3-5 core tribal beliefs, each with a one-sentence statement and a brief explanation of why it creates tribal cohesion.

**1.4 — The Shared Rituals**

Identify what members DO together that reinforces the identity. Rituals are repeated actions that have community meaning beyond their function.

Categories:
- **Regular group activities** (sketch walks, jam sessions, group practice challenges)
- **Celebration rituals** (what happens when a member hits a milestone)
- **Onboarding rituals** (what new members do first that signals they've joined)
- **Recognition rituals** (how members publicly acknowledge each other's work)

**Produce:** 4-6 core rituals with description, frequency, and identity-reinforcement function.

**1.5 — The Social Signal**

Define what membership signals to the outside world. What does saying "I'm an [Tribal Identity]" communicate about someone's values, lifestyle, and taste?

**Produce:** A 2-3 sentence "social signal statement" describing what outsiders conclude about a member when they hear the tribal identity.

---

### Phase 2: Mimetic Desire Flywheel Design

The mimetic flywheel is the mechanism by which existing members create new demand without any marketing. Map it completely.

**2.1 — The Mimetic Chain**

Map the complete causal chain:

```
[Member creates output]
       ↓
[Member shares output publicly]
       ↓
[Non-member sees output and feels desire]
       ↓
[Non-member investigates the source]
       ↓
[Non-member encounters the community]
       ↓
[Non-member joins]
       ↓
[New member creates output]
       ↓ (cycle repeats)
```

For this specific market, specify:
- What is the "output" members create? (The shareable artifact — a sketch, a recording, a photo, a piece of writing)
- What platform do they share it on? (Where does the non-member encounter it?)
- What desire does it trigger? (The specific aspiration the non-member feels)
- What is the bridge from "I want that" to "I can do that"? (The identity permission moment)

**Produce:** A completed mimetic chain diagram with market-specific specifics at each node.

**2.2 — The Sharing Mechanism**

Design the structural mechanism that makes member sharing automatic. Don't assume members will share on their own.

Options to consider:
- Community challenges with public output requirements
- Member showcase features (spotlight, gallery, "share your work" threads)
- Social-native outputs (designed to be screenshot-ready, share-ready)
- Cross-posting incentives or prompts built into the experience
- "Show your work" norms established from day one

**Produce:** 3-5 sharing mechanisms with description, trigger, and platform.

**2.3 — The Aspirational Anchors**

Identify who the advanced members are whose work creates "I want that" in beginners. These are the role models whose output fuels the flywheel at the top.

For each aspirational anchor type:
- What do they produce that creates desire?
- How visible are they inside the community?
- How visible are they outside the community?
- Are they accessible to beginners? (Accessibility matters — if they're too elevated, they create intimidation, not aspiration)

**Produce:** A description of 2-3 aspirational anchor types (not individuals — types) and how their visibility is engineered.

**2.4 — Progression Visibility Architecture**

Design how members at each stage can see what's possible at the next stage. This is the mechanism that keeps aspiration alive inside the community.

Visibility must be:
- Proximate (the next stage, not 10 stages ahead)
- Credible (achieved by people who started where they are)
- Specific (concrete output, not vague "improvement")

**Produce:** A progression visibility map showing what each level sees, from whom, and through what mechanism.

---

### Phase 3: Progression Architecture

Design the complete ladder from new member to advanced practitioner. This ladder is both a retention mechanism and a content architecture.

**3.1 — The Progression Ladder**

Define 4 levels:

| Level | Name | Definition | What They Can Do | What They're Working Toward |
|-------|------|------------|-----------------|----------------------------|
| Beginner | [Name] | [Who this is] | [What they can produce] | [Next level milestone] |
| Intermediate | [Name] | [Who this is] | [What they can produce] | [Next level milestone] |
| Advanced | [Name] | [Who this is] | [What they can produce] | [Next level milestone] |
| Practitioner | [Name] | [Who this is] | [What they can produce] | [Identity they claim] |

Rules for naming levels:
- Names should be identity labels, not just ordinal ranks (not "Level 1, Level 2")
- Names should be aspirational — members want to reach the next level name
- Names should connect to the tribal vocabulary established in Phase 1

**3.2 — Milestone Definitions**

For each transition between levels, define the specific milestone that marks the transition. Milestones must be:
- Concrete and observable (not "feels more confident")
- Achievable within a reasonable timeframe
- Based on output, not hours invested

**Produce:** 3 transition milestones (Beginner→Intermediate, Intermediate→Advanced, Advanced→Practitioner) with specific, observable definitions.

**3.3 — Celebration Architecture**

Design how transitions are celebrated. Public celebration creates identity commitment — members who are publicly recognized at a new level are far more likely to remain at that level.

For each transition:
- What is the celebration ritual?
- Who acknowledges it? (Community, leader, peers?)
- What is the public artifact of the celebration? (Badge, post, feature, certificate?)
- What does the celebrated member receive?

**Produce:** A celebration protocol for each of the 3 transitions.

**3.4 — The First Win Experience**

Design the path to the earliest moment a new member can produce something worth sharing. This is the most important design decision in onboarding.

Requirements:
- Must be achievable within the first session or first week
- Must produce an output that is genuinely shareable (not "good for a beginner" — actually good)
- Must connect to the tribal identity (the output should signal membership)
- Must create a "I didn't know I could do this" moment

**Produce:** A First Win Protocol — the specific sequence from joining to first shareable output, with estimated time and specific activity at each step.

---

### Phase 4: Retention Mechanics

Design the mechanisms that keep members active, engaged, and resistant to cancellation.

**4.1 — Recurring Rituals Calendar**

Design the standing weekly and monthly community events that create habit and expected participation.

For each ritual:
- Name and description
- Frequency (daily / weekly / monthly)
- Format (live / async / challenge / showcase)
- Community role (engagement / accountability / celebration / skill-building)
- Estimated participation rate (what % of members will engage)

**Produce:** A recurring rituals calendar covering at minimum 1 weekly and 2 monthly recurring events.

**4.2 — Challenge Structures**

Design time-boxed community events that spike engagement, create shared experience, and generate shareable output for the mimetic flywheel.

For each challenge:
- Name and theme
- Duration (7 days / 30 days / etc.)
- Input (what members commit to)
- Output (what they produce)
- Sharing mechanism (how it reaches non-members)
- Reward or recognition for completion

**Produce:** 2-3 challenge archetypes that can be repeated with varying themes. At minimum one 7-day and one 30-day format.

**4.3 — Contribution Pathways**

Design how members graduate from consumers to contributors to leaders. Contribution is the deepest form of retention — members who help others leave almost never.

Pathway stages:
1. **Consumer** — takes from the community (content, feedback, connection)
2. **Contributor** — gives to the community (answers questions, shares work, gives feedback)
3. **Leader** — shapes the community (runs challenges, mentors beginners, moderates)

For each stage, specify:
- What the contribution looks like
- What prompts the transition to the next stage
- What recognition the contributor receives

**Produce:** A Contribution Pathway with 3 stages, transition triggers, and recognition for each.

**4.4 — Accountability Structures**

Design gentle social accountability mechanisms that increase follow-through without creating shame or pressure.

Characteristics of effective approach-market accountability:
- Aspiration-focused, not failure-focused ("What are you working toward?" not "Did you do your homework?")
- Peer-based, not authority-based
- Optional but clearly valued
- Produces something (a commitment, a plan, a check-in) rather than just monitoring

**Produce:** 2-3 accountability structures with description, opt-in mechanism, and follow-through rate estimate.

**4.5 — Sticky Content Architecture**

Define the recurring content types that keep members returning — not more instruction, but the community-native content that only exists inside the membership.

Categories:
- **Social content** — member spotlights, community news, behind-the-scenes
- **Member showcase content** — curated member work that creates aspiration
- **Live event content** — calls, Q&As, group sessions that can't be replayed the same way
- **Inside-knowledge content** — content that only makes sense if you're in the community (callbacks, references, inside jokes)

**Produce:** A sticky content calendar showing 4-6 recurring content types, frequency, and format.

---

### Phase 5: Membership Economics

Design the business model that corresponds to the community architecture.

**5.1 — Course vs. Community Model Comparison**

Produce a head-to-head comparison for this specific market:

| Dimension | Course Model | Community Model |
|-----------|-------------|-----------------|
| Revenue type | One-time | Recurring |
| LTV driver | Upsells | Retention |
| Churn trigger | Completion | Boredom or isolation |
| Content burden | Front-loaded | Distributed |
| Referral mechanism | Manual | Mimetic |
| Identity investment | Low | High |
| Acquisition cost | High per unit | Decreasing over time |

Add market-specific notes for each dimension.

**5.2 — Membership Pricing Architecture**

Design 2-3 membership tiers that correspond to identity depth — not just content access.

For each tier:
- Name (identity-based, not feature-based)
- Price point (monthly / annual)
- What it includes
- What identity it signals
- Who it's designed for
- Upgrade trigger to next tier

Rules:
- Entry tier must be priced for low commitment — the goal is crossing the identity threshold, not maximizing initial revenue
- Mid tier is the primary recurring revenue engine — design this one with the most care
- Top tier should feel like a different category, not just more content

**Produce:** A 3-tier membership architecture table with name, price, inclusions, identity signal, and upgrade trigger.

**5.3 — Upgrade Triggers**

For each tier transition, design the specific experience that creates desire for the next tier. Upgrades should feel like identity claims, not purchases.

**Produce:** 2 upgrade trigger designs (Entry→Mid and Mid→Top) with the specific moment, the mechanism, and the copy direction.

**5.4 — Referral Mechanics**

Design the organic referral system. In approach markets, the best referrals come from members sharing their work publicly (Phase 2 flywheel) — not from formal affiliate programs.

However, structured referral mechanics amplify the natural mimetic effect:
- Member-get-member incentives (what does the referring member receive?)
- Share prompts at peak emotional moments (immediately after a win, after a celebration)
- Community-native content that is designed to be shared publicly

**Produce:** 2-3 referral mechanics with trigger, incentive, and estimated referral rate.

**5.5 — LTV Calculation Framework**

Produce a comparative LTV model:

```
COURSE BUYER LTV:
  Average purchase price: $[X]
  Upsell rate: [Y]%
  Average upsell value: $[Z]
  LTV = $[X] + ($[Z] × [Y]%) = $[total]

COMMUNITY MEMBER LTV:
  Monthly membership: $[X]/month
  Average retention: [N] months
  Upgrade rate to higher tier: [Y]%
  Average higher tier revenue: $[Z]/month
  Additional upgrade value: $[W]
  LTV = ($[X] × [N]) + ([Y]% × $[Z] × [N]) + [W] = $[total]
```

Fill in estimated values based on the market and pricing architecture designed in 5.2.

**Produce:** A completed LTV comparison showing the economic case for the community model vs. course-only.

---

### Phase 6: Integration with Value Ladder

Place the community architecture within the complete offer ecosystem.

**6.1 — Value Ladder Placement**

Map where community membership sits in the value ladder:

```
FREE: [Lead magnet / free content / first win preview]
       ↓
ENTRY: [Entry-level course or entry membership tier] — $[X]/month
       ↓
CORE: [Full community membership] — $[X]/month
       ↓
PREMIUM: [High-touch experiences: coaching, intensives, events] — $[X]
       ↓
ELITE: [Direct access, mastermind, inner circle] — $[X]
```

For each rung, specify what the community membership adds to the overall funnel.

**6.2 — Community Conversion Effect**

Describe how community membership changes conversion rates for premium offers:

- Members who belong have higher trust — they convert to premium at higher rates
- Members who have advanced through the progression ladder have evidence of their own capability — they believe more is possible
- Members who have contributed (Contribution Pathway stage 2-3) have social stakes — they're invested

**Produce:** A brief description of 3 ways community membership specifically improves conversion for the premium tier(s).

**6.3 — The Community Funnel**

Design the complete path from non-member to full membership:

1. **Free taste** — what non-members can experience that creates desire without requiring purchase
2. **Entry point** — the lowest-friction way to join (what is the minimal commitment that crosses the identity threshold?)
3. **Full membership** — what changes when they go from entry to full
4. **Premium experiences** — what community members can access that goes beyond membership

**Produce:** A 4-stage community funnel with description of experience and conversion mechanism at each stage.

---

### Phase 7: Launch Architecture

Design the strategy for launching a community from zero to self-sustaining momentum.

**7.1 — The Founding Member Strategy**

A new community needs a founding cohort that creates the social proof and cultural DNA before general launch. Design this:

- Who are the ideal founding members? (Criteria — not demographics, but disposition: creators, connectors, givers)
- How are they recruited? (Application, invitation, existing audience segment)
- What do they receive that general members don't? (Founding member identity, price lock, naming rights, direct access)
- What is their obligation? (Active participation, feedback, content creation)
- Target founding cohort size and timeline

**Produce:** A Founding Member Protocol with criteria, recruitment method, benefits, obligations, and target size.

**7.2 — Minimum Viable Community Size**

Determine the minimum number of active members required for the community to feel self-sustaining — where new members arrive to an active community rather than an empty room.

Factors:
- Enough members to ensure daily activity without the leader having to generate it all
- Enough progression spread (some at each level) to make the progression ladder visible
- Enough activity that new members see others doing the thing within their first hour

**Produce:** An estimate of minimum viable community size with reasoning, and a plan for reaching it before general launch.

**7.3 — Content Strategy for the Early Days**

Before members generate content, the leader must. Design the content strategy for the first 90 days:

- What does the leader post daily/weekly to simulate community activity?
- What content creates the illusion of an active community until it becomes real?
- At what point does member-generated content exceed leader-generated content?

Types of early-stage leader content:
- Seed questions (questions that prompt member responses and create thread activity)
- Member spotlights (even small early wins are spotlighted aggressively)
- Live presence (showing up live creates warmth that no recorded content replaces)
- Transparency content (showing the community building process itself creates investment)

**Produce:** A 90-day content calendar structure (not specific posts — the recurring types and frequencies) for the pre-momentum phase.

**7.4 — Manufacturing the "Thriving Community" Signal**

New members judge community health in the first 5 minutes. Design the specific signals that communicate vitality even when the community is new:

- Welcome automation that simulates personal attention at scale
- First-post prompts that guarantee immediate response
- Activity that is visible to new members (what they see on their first login)
- Social proof display (how early member wins are featured prominently)

**Produce:** A list of 4-6 "thriving community" signals with the specific mechanism for each.

---

## OUTPUT SPECIFICATION

Save to the specified output folder:

**File: `Community-Architecture-[Market].md`**

Structure:
1. Executive Summary (3 sentences: tribal identity, primary mimetic mechanism, membership economics case)
2. Phase 1: Tribal Identity Design (full output from all Phase 1 sections)
3. Phase 2: Mimetic Desire Flywheel (full output from all Phase 2 sections)
4. Phase 3: Progression Architecture (full output from all Phase 3 sections)
5. Phase 4: Retention Mechanics (full output from all Phase 4 sections)
6. Phase 5: Membership Economics (full output from all Phase 5 sections, including LTV comparison)
7. Phase 6: Value Ladder Integration (full output from all Phase 6 sections)
8. Phase 7: Launch Architecture (full output from all Phase 7 sections)
9. Strategic Implications and Immediate Next Steps

**Target length:** 3,000-5,000 words. Depth on tribal identity and mimetic flywheel beats breadth on any single mechanics section.

**Language rule:** Write as if designing for a tribe, not for customers. Members, not buyers. Belonging, not enrollment. Community, not audience. Advancement, not completion.

---

## QUALITY GATE

Before saving, verify:

- [ ] Tribal identity name passes the "I'd say this at a party" test — it is a claimable personal identity, not a product name
- [ ] Tribal vocabulary table contains at minimum 8 terms with functions specified
- [ ] Mimetic chain diagram is specific to this market — not generic ("members share things")
- [ ] First Win Protocol specifies a concrete output achievable in the first session or first week
- [ ] Progression Ladder uses identity-based names, not ordinal ranks
- [ ] LTV comparison contains actual estimated numbers, not placeholders
- [ ] Launch Architecture specifies minimum viable community size with reasoning
- [ ] No language in the document frames community as content delivery infrastructure
- [ ] No avoidance language (pain, failure, frustration) unless explicitly contrasting with aspiration
- [ ] Output reads as structurally different from a course curriculum or content plan — this is a belonging architecture, not a learning architecture

---

## STRATEGIC IMPLICATIONS TEMPLATE

The final section must answer these questions:

1. **What is the single tribal identity name this community should adopt?** (From Phase 1 — the definitive recommendation, not a list of options)
2. **What is the primary mimetic mechanism — the one output that, shared publicly, does the most recruiting?** (From Phase 2)
3. **What is the First Win — the specific output that new members must produce in their first session?** (From Phase 3.4)
4. **What is the entry-tier price and identity position?** (From Phase 5.2 — the minimum threshold for claiming the tribal identity)
5. **What is the minimum viable community size and how long will it take to reach it?** (From Phase 7.2)
6. **What is the single highest-leverage retention mechanic — the one recurring event that, if removed, would spike cancellations?** (From Phase 4)

---

## HOW THIS CONNECTS DOWNSTREAM

This community architecture becomes the operating brief for:
- **Platform selection** — choosing Skool, Circle, Discord, Slack, Facebook Group based on the mimetic mechanism and sharing requirements
- **Content strategy** — recurring community content calendar, member spotlight system, challenge calendar
- **Copy direction** — all membership sales copy must use tribal identity language and feature mimetic proof (member-shared output), not testimonials alone
- **Onboarding design** — the First Win Protocol becomes the literal product design brief for the new member experience
- **Pricing and packaging** — tier names, prices, and upgrade triggers are taken directly from Phase 5
- **Launch planning** — the Founding Member Protocol and minimum viable community size become the launch brief
- **toward-usp-generator** — the tribal identity and mimetic mechanism inform USP language for the community offer
- **aspiration-avatar-excavation** — community architecture decisions should be checked against the avatar's social desire structure and identity permission gaps
