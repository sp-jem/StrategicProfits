---
name: aspiration-excavation
description: "14-phase deep psychological archaeology of an approach-motivated market. Maps passion triggers, identity aspirations, skill progression history, community needs, and buying behavior for markets where people move TOWARD something. Replaces Rage Points with Passion Triggers, Solution Graveyard with Skill Progression History. Part of the ZenithPro: Toward Markets pipeline."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/aspiration-excavation [market description]"
  called_by: [user, toward-demand-architect]
  outputs_to: [project folder]
---

# Aspiration Excavation

14-phase deep market intelligence framework built for approach-motivated markets. Extracts the authentic, layered, emotionally rich human truth of what a market wants to BECOME — not what they're fleeing.

---

## LAYER 1: INVARIANTS

1. **Raw language over sanitized summaries.** Every section requires actual quotes from this market — YouTube comments, Reddit posts, Amazon reviews, community forums, social media. Real words. Typos, caps lock, and all.
2. **Aspiration over assumption.** If what you're finding is what everyone already says about this market, you're not going deep enough. The real purchase drivers are always below the surface.
3. **Save all outputs to files.** Never deliver in chat only.
4. **Web research required.** Training data alone is insufficient. Run live searches for each phase that requires quotes.
5. **NEVER use avoidance language.** Pain, frustration, failure, broken, stuck, struggling — none of these belong here unless explicitly contrasting with aspiration. This excavation is written in the language of approach.

---

## PURPOSE

This is psychological archaeology for people who are moving TOWARD something — not away from something.

The goal: understand what this market is reaching for at the deepest level. Uncover what they want to become but haven't given themselves full permission to want. Identify the hidden aspirational patterns driving their behavior. Extract the exact language that would make them feel completely seen.

**Output use:** Feeds everything downstream — permission concept development, identity-belief gap analysis, avatar excavation, aspiration mimetic intelligence, community architecture, USP generation, and all content strategy.

**Mental test case throughout:** Women 55+ learning urban sketching (the Neil Maxwell-Keys / Ian Fennelly market). Would your output make sense for this market? If yes, proceed. If not, recheck your framing.

---

## INPUTS

Gather before running:

1. **Target market description** (who they are, what they aspire to, what they're moving toward)
2. **Business/website URL** (optional — if analyzing for a specific business, analyze the website first)
3. **Avatar type** (if already identified from toward-desire-mapper)
4. **Specific focus area** (optional — "focus especially on Phase 4 and 7" for second passes)
5. **Output folder path**

---

## THE 14-PHASE ASPIRATION EXCAVATION

### PHASE 0: BUSINESS FOUNDATION ANALYSIS
*(Only if analyzing for a specific business website)*

Analyze the provided URL to understand:
- Core product/service offering and primary value proposition
- How the business positions around aspiration vs. pain avoidance
- The identity transformation being promised (explicitly and implicitly)
- What kind of person this business helps someone become
- The community or belonging dimension embedded in the offer

---

### PHASE 1: IDENTITY ARCHAEOLOGY & CORE ASPIRATIONS

**Research mandate:** Find actual quotes from this demographic — Reddit posts, YouTube comments, Amazon reviews, Facebook group posts, forum threads, TikTok comments. Raw language. Typos, caps lock, and all.

Excavate:
- What do they imagine when they picture themselves fully living this aspiration?
- What identity claim do they secretly want to make but haven't earned yet in their own mind?
- What beliefs do they hold about who gets to have this identity — and whether that includes someone like them?
- **Find 3-5 actual quotes revealing private aspirations, identity desires, or permission questions**
- Their core aspiration worldview in 1-3 sentences — so accurate they'd think you read their journal
- Life stage context: what chapter of life are they in? What's opening up? What space exists now that didn't before?

---

### PHASE 2: SKILL PROGRESSION HISTORY & CURRENT REALITY

What they're currently doing/trying in pursuit of this aspiration:
- Official learning paths (courses, books, instructors, programs)
- Self-directed attempts (YouTube, free resources, trial and error)
- Community-based learning (classes, workshops, local groups)
- **Pull 10+ quotes showing their experience with learning journeys — what excited them, what made them stop**

Their experience with existing learning resources:
- What promises excited them but weren't fulfilled?
- What made them feel like the resource wasn't designed for someone like them?
- What did they wish existed that didn't?
- **Find reviews, comments, and forum posts about courses and teachers in this space**

Why they think they haven't progressed further:
- Do they blame lack of natural talent? Wrong method? Lack of time? Starting too late?
- **Find quotes expressing their theories about why they haven't arrived yet**

---

### PHASE 3: THE ASPIRATION HISTORY PATTERNS

Dig for patterns that reveal the deep architecture of this aspiration:

**The Permission Story:** Who in this market has made the identity claim and been validated publicly? What did their journey look like? (Like the 60-year-old who sells their first painting — what does that story unlock for others?)

**The Rediscovery Pattern:** What traditional or ancestral form of this skill/art/craft has been revived in a way that makes it feel accessible again? What gave permission to a new generation of beginners?

**The Community Origin:** What online spaces or in-person communities created the first critical mass of people sharing this aspiration openly? What changed when they found each other?

**The Teacher Who Changed Everything:** Who is the instructor, creator, or guide who made this aspiration feel achievable for people who'd been told (or believed) they couldn't do it?

**The Transformation Story That Spread:** What specific story — a video, a before/after, a testimonial — became widely shared in this market because it gave others permission to want this?

Find at least 3 of these patterns with specific examples from this market.

---

### PHASE 4: THE COMMUNITY WISDOM & INSIDER KNOWLEDGE

**The Tribe's Open Secret:** What do people inside the community know that makes the learning process far easier/faster than outsiders assume?

**The Advanced Practitioner's Confession:** What would someone who's been doing this for 5+ years tell a beginner that no course teaches? What do they wish someone had told them at the start?

**The Beginner Advantage:** What does this market have — life experience, patience, perspective, intention — that younger or less experienced starters don't? What do insiders openly celebrate about late-start learners?

**The Shortcut Consensus:** What technique, approach, or resource do experienced practitioners most consistently recommend to accelerate progress?

**Find 5+ quotes of people sharing insider encouragement, hard-won wisdom, or community-specific knowledge.**

---

### PHASE 5: THE PASSION TRIGGERS

What activates obsessive interest in this market — the moments, content, and experiences that create genuine ignition:

**What They Talk About for Hours:**
- What subtopics within this aspiration space generate the most passionate conversation?
- What debates never get old in this community?
- What discoveries make them immediately want to share with someone?
- **Find their most engaged, enthusiastic quotes — with exclamation points and "omg" and "this changed everything"**

**What Content They Consume Compulsively:**
- What YouTube channels, Instagram accounts, or teachers do they watch every single video of?
- What makes them recommend a creator to every person they know?
- What format (tutorial, process video, time-lapse, interview, documentary) captures them most?
- **Find quotes describing binge-watching or obsessive consumption behavior**

**What Ignites the "I HAVE to try that" Response:**
- Specific techniques, tools, materials, or approaches that create an immediate compulsion to experiment
- The moment of seeing an output and thinking "I want to make something like that"
- **Find quotes about what made them buy something immediately without overthinking**

**Their Deepest Aspirational Desires:**
- What would they create if they knew they had the skill?
- What subject matter or output style do they return to fantasizing about?
- What do they quietly bookmark and come back to?

---

### PHASE 6: THE ASPIRATION EVOLUTION & PARADIGM EXPANSION

When the Aspiration Deepens:
- What happens to this market's aspiration over time as they develop skill? How does it expand?
- **Find quotes: "I started just wanting to X, now I realize it's really about Y"**

Complete Belief Reversals:
- What did they believe about this skill/art/craft before starting that they now know is false?
- What assumption did they hold that limited their progress — and when did it fall away?
- **Find: "I can't believe I used to think you had to be born with it"**

The Unexpected Benefits They Discovered:
- What did they gain from pursuing this aspiration that they didn't expect? (Community, mindfulness, identity confidence, cognitive benefits)
- **Find: "I never thought it would also give me..."**

---

### PHASE 7: THE PASSION TRIGGERS & ASPIRATION ARCHITECTURE

What Makes Them DEEPLY ENGAGED:
- What aspects of this skill/pursuit produce genuine absorption?
- What small wins create the most disproportionate satisfaction?
- What does progress feel like to this market — specifically, somatically, emotionally?
- **Find their most enthusiastic descriptions of being in flow with this activity**

Their Deepest Identity Aspirations:
- What version of themselves are they reaching toward through this pursuit?
- What would they be able to say about themselves — publicly or privately — if they achieved mastery?
- **Find their most vulnerable admissions of who they want to become**

The Permission Questions They Wrestle With:
- "Is it too late for me to actually get good at this?"
- "Am I the kind of person who gets to call themselves an artist/musician/writer?"
- "Do I have what it takes, or is this something you either have or you don't?"
- **Find these exact permission-question phrases in their own words**

---

### PHASE 8: DECISION PSYCHOLOGY & BUYING BEHAVIOR

How They Research & Decide on Learning Resources:
- How long do they research before investing in a course, program, or tool?
- What sources do they trust vs. distrust?
- What makes them skeptical of a teacher or program?
- **Find examples of their actual research processes in forums and communities**

What Stops Them from Investing:
- Most common objections — **find actual objection quotes**
- Past learning experiences that created skepticism
- The identity doubt that surfaces before purchasing: "Am I serious enough about this to spend money?"
- **Find their exact objection language**

What Makes Them Buy:
- What finally gives them permission to invest?
- What proof specifically matters to them — is it someone their age, someone with their background, someone who started where they started?
- What urgency naturally exists in their aspiration journey?
- **Find quotes about what made them finally commit**

---

### PHASE 9: LANGUAGE HARVESTING & ASPIRATION ARTICULATION

How They Describe Their Aspiration:
- **Pull 20+ different ways they describe what they want** — their actual words, metaphors, descriptions
- Physical sensations, emotional experiences, identity claims, life vision language

How They Describe the Skill They Want to Develop:
- **Pull 20+ different ways they describe mastery or progress** — their exact language
- What skill milestones matter to them, what outputs represent arrival, what moments signal real progress

The Words That Make Them Stop Scrolling:
- What headlines grab them?
- What terminology do they use vs. what experts/teachers use?
- What language signals "this teacher gets people like me"?
- **Find actual examples of content they engaged with heavily**

---

### PHASE 10: MEDIA, INFLUENCE & ATTENTION PATTERNS

Where They Hang Out:
- Specific subreddits, Facebook groups, Discord servers, YouTube channels, offline classes, local groups
- **Find evidence of where they actually spend time** (not where you assume)

Who They Trust:
- Specific teachers, creators, practitioners — who has genuine authority in this market
- What gives someone credibility to THIS market specifically (lived experience? demographic match? output quality? approachability?)
- **Find who they actually mention, tag, and recommend**

Content Patterns:
- What makes them stop scrolling vs. skip
- Preferred format (tutorial, process video, finished work showcase, interview, community post)
- **Find examples of content that got massive engagement from them**

---

### PHASE 11: COMPETITIVE INTELLIGENCE & POSITIONING OPPORTUNITIES

What Market Messages Have Actually Worked On Them:
- What positioning has caused them to pay attention, buy, or recommend?
- What makes them immediately trust or dismiss a teacher?
- What industry-specific clichés or jargon have they grown numb to?

The Underserved Aspiration:
- What does this market want that nothing in the current landscape gives them?
- What kind of teacher, community, or approach do they describe in an ideal world that doesn't seem to exist yet?
- What identity permission or demonstration is no one currently providing?

---

### PHASE 12: OFFER ARCHITECTURE & CONVERSION FOR APPROACH MARKETS

The Ideal Investment Structure (based on everything above):
- Ideal price point and payment terms for this aspiration level and life stage
- Essential guarantees and risk reversals that matter to an approach-motivated buyer (these are different from avoidance markets — the fear isn't "will it work" but "will it work for someone like ME")
- Social proof that actually matters to THEM: demographically matched mirrors, not generic testimonials
- **Find examples of offers they've actually responded to — what made it feel like a yes**

---

### PHASE 13: ASPIRATION DEEPENING & RELATIONSHIP EVOLUTION

The Customer Journey After First Investment:
- What happens after they experience their first real win?
- What new aspiration emerges once the first one starts to materialize?
- When they're most likely to deepen their investment
- What makes them evangelize — bring others in — vs. consume privately
- **Find quotes about people who went deeper after starting**

---

### PHASE 14: SEGMENTATION & ASPIRATION PATTERNS

Micro-Segments That Matter:
- How aspiration intensity and identity readiness vary across sub-groups
- Early adopters (those already self-identifying in the aspiration space) vs. aspiration-curious (those still asking "could I be the kind of person who does this?")
- Life stage trigger events that activate aspiration and buying
- **Find patterns in different sub-groups — what makes the retired-and-ready avatar different from the career-transition avatar**

---

## THE SYNTHESIS

After all 14 phases, produce:

1. The ONE aspiration this market holds that they think no one else understands at the depth they feel it
2. The story that would make them say "THIS TEACHER/BRAND GETS IT"
3. The identity permission they need that the market hasn't given them yet
4. The transformation they didn't know was available to someone like them
5. The exact words that would make them stop scrolling and feel completely seen
6. The offer they couldn't say no to — and why it works for THIS market
7. The proof structure that actually moves them (hint: it's a mirror, not a mechanism)
8. The community belonging they're hoping exists on the other side of purchase
9. The social proof that actually matters to them (specific demographic + transformation details)
10. The identity they're really buying (not the product — the VERSION OF THEMSELVES)

---

## OUTPUT SPECIFICATION

**File: `Aspiration-Excavation-[Market].md`**

One file with all 14 phases + synthesis. Each phase clearly labeled. No sanitized summaries — if a phase has actual quotes, they appear verbatim. If web research didn't yield quotes for a specific sub-question, note that explicitly.

**Target length:** 4,000-8,000 words. This is raw intelligence for approach-motivated markets, not a polished report.

**Language rule:** NEVER use pain, frustration, failure, broken, stuck, struggling unless explicitly contrasting with aspiration. Every section is written in the language of approach. The word "problem" appears only when the market uses it themselves in a quote.

---

## QUALITY GATE

- [ ] At least 30 distinct market quotes included across all phases
- [ ] Phase 9 Language Harvest has 20+ aspiration descriptors AND 20+ mastery/progress descriptors
- [ ] Phase 5 Passion Triggers includes actual enthusiastic language (not paraphrase)
- [ ] Phase 7 includes specific permission-question phrases in the market's own words
- [ ] The Synthesis section has all 10 items answered
- [ ] Web research used — not training data alone
- [ ] Zero avoidance language in the skill's own voice (quotes may contain it if the market uses it)
- [ ] Saved to file

---

## HOW THIS CONNECTS DOWNSTREAM

- **aspiration-avatar-excavation** → This provides the raw market intelligence; avatar skill structures it per segment with full identity depth
- **identity-belief-gap-analyzer** → Phases 1, 8 feed the Point A belief mapping for approach-motivated prospects
- **permission-concept-generator** → Phases 5, 7 directly feed the passion trigger and permission gap inputs
- **toward-usp-generator** → Phase 11 positioning opportunities + Phase 9 language
- **aspiration-mimetic-intelligence** → Phase 11 competitive analysis feeds mimetic desire research
- **community-architect** → Phase 4 insider knowledge + Phase 13 relationship evolution feeds community design
- **toward-demand-architect** → This excavation is a core input to the full demand creation pipeline
