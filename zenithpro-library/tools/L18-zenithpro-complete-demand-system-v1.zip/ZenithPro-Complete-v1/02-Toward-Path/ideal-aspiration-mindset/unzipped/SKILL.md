---
name: ideal-aspiration-mindset
description: "Forensically defines the exact psychological state where buying becomes automatic for approach-motivated markets. Maps 4 dimensions: Logical Beliefs (rational readiness), Emotional Feeling State (anticipation/excitement/belonging), Identity Alignment (seeing themselves as this person), Social Proof Needs (people like me are already there). Replaces productive tension with identity readiness. Part of the ZenithPro: Toward Markets pipeline."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/ideal-aspiration-mindset [market or avatar]"
  called_by: [user, toward-demand-architect]
  outputs_to: [project folder]
---

# Ideal Aspiration Mindset

Blueprints the complete internal state where buying becomes automatic for someone in an approach-motivated market. Not a description of desire — a precise specification of the psychological state where the offer feels like the obvious next step toward who they're becoming.

---

## LAYER 1: INVARIANTS

1. **Point B is a psychological state, not a marketing message.** You're mapping where their HEAD needs to be, not what to say to them.
2. **All four dimensions are mandatory.** A prospect with the right logical beliefs but without emotional excitement won't buy. A prospect with excitement but no identity alignment won't buy. All four must align simultaneously.
3. **The buying state is PULL, not PUSH.** In approach markets, the ideal buying state feels like excitement, readiness, and "my turn" — not urgency, pressure, or "I need to fix this." Any Point B description that sounds like avoidance motivation is wrong.
4. **Point B must be purchaser-realistic.** Ground it in what actual buyers in this market report feeling and believing. If reaching Point B requires states real humans couldn't hold, revise before mapping.
5. **Specificity over generality.** Not "they should feel excited" — "they should feel the anticipation of beginning something they've wanted for themselves for a long time, with the particular excitement of having found a path that feels designed for someone exactly like them."
6. **Save all outputs to files.** Never deliver in chat only.

---

## PURPOSE

In approach-motivated markets, Drucker's ideal is inverted: "The aim of marketing is to know and understand the aspiration so well that the product fits who they're becoming and sells itself."

When a prospect is at Point B in an approach market:
- They've already made the internal identity decision — they've accepted the new self-story
- The purchase is simply the first act of their new identity
- Hesitation has been replaced by anticipation
- The investment feels congruent with who they're becoming — not a risk, a declaration
- Delay feels like postponing something they've already decided they deserve

**Critical distinction from avoidance markets:** In avoidance markets, delay feels painful because the problem keeps costing them. In approach markets, delay feels like self-betrayal — postponing something they've already said yes to internally. This is a fundamentally different motivation structure.

**Output use:** Point B becomes the destination for identity-belief-gap-analyzer. Every marketing activity's purpose is to move prospects from Point A (curious but doubting themselves) to Point B (I can become this person and I'm ready to invest).

---

## INPUTS

Required:
1. **Market/avatar description** — who they are, what they're drawn to, what they aspire to become or experience
2. **Product/service being offered** — what you provide and what transformation it enables
3. **Aspiration Hierarchy Map** — from toward-desire-mapper (which L1-L4 aspirations are active, what identity permission gaps exist)
4. **Avatar research** — psychographic data, community language, testimonials from existing buyers
5. **Output folder path**

---

## THE FOUR DIMENSIONS OF BUYING READINESS (APPROACH MARKETS)

### DIMENSION 1: LOGICAL BELIEFS (Rational Readiness)

What they must intellectually accept as true before purchase feels rational.

In approach markets, logical readiness is NOT about proving the problem is urgent. It's about establishing that the aspiration is accessible — that the category can deliver what they're reaching for, and that this specific product is built for someone exactly like them.

**Category A: Aspiration Accessibility Beliefs**

They must believe with clarity:
1. This aspiration is GENUINELY available to someone who starts where they are (not just theoretically possible but practically accessible)
2. Age, background, and starting point are NOT disqualifying factors — they may even be advantages
3. The learning curve is real but navigable — they don't need to know everything before they start
4. The aspiration is worth serious investment — not a hobby category but a real transformation
5. The RIGHT guidance closes the gap between where they are and where they want to be

For each belief: State the exact belief AND the evidence type that creates it.

**Category B: Product Fit Beliefs**

They must logically accept:
1. This product was designed for people at their starting point — not for the already-advanced
2. The method builds the real skill/identity, not a surface imitation or beginner's approximation
3. The instructor understands the experience of coming to this late (or fresh) — they're not speaking past the beginner
4. The community inside is composed of people they want to belong with — not intimidating, but inspiring
5. The investment is proportionate to the transformation — not casual, but justified

**Category C: Provider Beliefs**

They must trust:
1. The teacher has genuine mastery — not just enthusiasm
2. The teacher has successfully guided people who started where they're starting
3. The teacher's approach is specifically calibrated for approach-motivated learners (not performance-driven, shame-based, or rushed)
4. The program has produced real transformations in people with similar backgrounds

**Category D: Timing Beliefs**

They must believe:
1. NOW is the right time — not because of external pressure but because they're ready
2. Starting later doesn't mean starting better — the longer they wait, the more they're postponing something they've already decided they want
3. They have the prerequisites to begin (not mastery — just readiness)
4. This particular offer is right for where they are right now

---

### DIMENSION 2: EMOTIONAL FEELING STATE (Anticipation/Excitement/Belonging)

What they must viscerally experience in order for purchase to feel natural and right.

**Critical invariant:** There are NO "productive tension" states in approach market Point B. No dissatisfaction, no urgency-as-pressure, no frustration with the current situation. The buying state is entirely pull-based.

**Positive States Required:**

- **ANTICIPATION** — the forward-leaning excitement of something beginning; the feeling of standing at a threshold and knowing the door is about to open
- **EXCITEMENT** — genuine energy about who they're becoming; not the anxiety of a new commitment but the aliveness of moving toward something
- **BELONGING** — a felt sense that the community inside is one they belong to; that "my people are in there"
- **IDENTITY READINESS** — the internal confirmation that they're ready to be this person; "it's my turn" rather than "someday"
- **LIGHTNESS** — the particular quality of approach motivation: the absence of heaviness; the feeling that this is addition, not correction
- **TRUST** — a felt sense that the teacher and community understand them and are genuinely invested in their becoming
- **PERMISSION** — having given themselves permission to invest in this aspiration; past the internal objection that it's indulgent or premature

**States That Must Be ABSENT:**

- Shame (buying would feel like an admission of failure)
- Urgency-as-pressure (feeling pushed rather than pulled)
- Anxiety about performance (fear they'll fail at this too)
- Self-doubt about worthiness (wondering if they deserve to pursue this)
- Overwhelm (feeling the commitment is too large to take on)
- Cynicism (the protective skepticism of someone who's been disappointed by aspiration before)

For each required state: What content or experience creates it? What content destroys it?

---

### DIMENSION 3: IDENTITY ALIGNMENT (Seeing Themselves as This Person)

This is the most critical dimension in approach markets. Unlike avoidance markets where identity alignment is one factor among several, in approach markets it is the central gate.

**The Identity Claim**

Before purchase feels congruent, they must have made a private identity claim. Not necessarily stated aloud — but settled internally. The form of this claim is:

"I am the kind of person who does [this thing] / belongs to [this community] / pursues [this aspiration]."

This is not aspirational in the future tense. It's a present-tense identity claim. "I AM this kind of person" — even if the skill or experience doesn't yet exist. The purchase is the first external act of an identity that has already formed internally.

**The New Identity Label**

Specify the exact identity label they need to claim before purchase feels right.

- NOT: "I'm the kind of person who invests in online courses"
- YES: "I'm an urban sketcher" / "I'm a painter" / "I'm someone who makes things"
- The label should be how they'd describe themselves to someone else in this community — what they'd put in their Instagram bio once they've made the commitment

**Identity Bridges Required**

What must shift in how they see themselves?

Map each required bridge in this format:
- From [current identity story that blocks purchase] → To [enabling identity that makes purchase congruent]

Example bridges for approach markets:
- "From someone who appreciates art → to someone who makes art"
- "From someone who wishes they had started younger → to someone for whom starting now is exactly right"
- "From observer of this community → to member of this community"
- "From person who thinks about doing this → to person who actually does this"

**The Identity Permission**

What specific permission must they give themselves?

In approach markets, this is usually:
- Permission to invest at this level in something that is for them (not their family, not their business)
- Permission to claim the identity before they've proven they deserve it
- Permission to start now rather than waiting until they're somehow more ready
- Permission to pursue something for the intrinsic pleasure of it — without needing to justify it by outcomes

**The Identity Cost of NOT Buying**

What identity story do they tell themselves if they don't buy?

In approach markets, this is usually:
- "I'm still on the outside looking in"
- "I'm the person who thinks about doing this but doesn't actually do it"
- "I postponed something I've already decided I want"

This is different from avoidance market non-purchase identity cost ("I stayed stuck"). The approach market version is about postponing a becoming, not failing to escape a pain.

---

### DIMENSION 4: SOCIAL PROOF NEEDS (People Like Me Are Already There)

In approach markets, social proof does not function to reduce risk. It functions to make the aspired identity VISIBLE and ACCESSIBLE.

The question social proof must answer is not "Will this work?" — it's "Is there a place for someone like me in this world?"

**The Mirror Function**

The highest-value social proof in an approach market is the demographic mirror: a person who looks exactly like the buyer (same age, same starting point, same background hesitations) who has crossed the threshold and is now living the identity.

The mirror communicates:
- "This world is for me too — not just for people who started young / had natural talent / had the right background"
- "Someone exactly like me is already there — which means it's available, not just theoretical"
- "The community I'd be joining includes people like me, not just people who intimidate me"

Specify the exact demographic profile of the highest-leverage mirror for this market.

**Community Visibility**

They need to SEE the community — not just know it exists.

What they need to see:
- People at various skill levels who are all clearly welcome and engaged
- The emotional experience of participation (joy, pride, playfulness, belonging — not performance pressure)
- Community members referencing their own starting points (making it safe to begin where they are)
- The texture of belonging: people who obviously found their people here

**Progress Evidence**

Unlike mechanism proof (avoidance markets), approach markets need progress evidence: real examples of people moving from starting point to meaningful skill/identity milestone.

The proof must show:
- The specific starting point (not advanced — their starting point)
- The realistic timeline (not "3 months to mastery" — honest about what develops and when)
- The quality of the experience along the way — not just the destination

---

## THE IDEAL ASPIRATION MINDSET STATE

After mapping all four dimensions, synthesize into:

**THE COMPLETE POINT B STATEMENT**

"A prospect is at Point B in this approach market when they:

**Logically believe:** [5-7 specific rational readiness beliefs — all framed as aspiration accessibility, product fit, and provider trust]

**Emotionally feel:** [3-5 specific positive states present — all pull-based; followed by 3-5 states that are absent]

**Identify as:** [The specific identity claim they've made privately — the present-tense version of who they are, not who they want to become]

**See in social proof:** [The specific mirror that made the aspired identity visible and available to someone exactly like them]

When all four of these are simultaneously present, purchase is not a selling situation — it's an enrollment situation. The prospect has already decided. The only remaining question is HOW to begin, not WHETHER to begin."

---

## THE ASPIRATION OBJECTION RADAR

Map the hesitations that arise when any dimension is incomplete. Note: in approach markets, hesitations rarely sound like "Will this work?" They sound like permission questions.

| Incomplete Dimension | Resulting Hesitation | Correction Required |
|---------------------|--------------------|--------------------|
| Missing accessibility belief | "I think I might be past the age for this" | Mirror testimony from same age/starting point |
| Missing product fit belief | "This might be designed for people already ahead of me" | Explicit "designed for your starting point" evidence |
| Missing provider trust | "I'm not sure the teacher understands where I'm starting from" | Specific teacher story about guiding late starters |
| Missing anticipation state | "I'm interested but I keep not pulling the trigger" | Demonstration that creates "I could do that" moment |
| Missing belonging state | "I'm not sure I'd fit in with that group" | Community visibility showing people like them |
| Missing identity permission | "It feels like a lot of money for something just for me" | Reframe: this is identity investment, not discretionary spending |
| Missing identity claim | "I'll do it when I'm more ready" | Mirror: the claim comes before the readiness, not after |
| Missing mirror proof | "That's great but they seem different from me" | Demographic-specific mirror testimony |

---

## OUTPUT SPECIFICATION

**File: `Ideal-Aspiration-Mindset-[Market].md`**

Sections:
1. The Four Dimensions (all beliefs, feeling states, identity elements, and social proof specifications)
2. The Complete Point B Statement
3. The Aspiration Objection Radar (incomplete dimension → hesitation → correction)
4. Transition Guide (from Point A "curious but doubting myself" to Point B — what moves them through each dimension)
5. Calibration Notes (how to know when a prospect has reached Point B in an approach market)

**Target length:** 1,500-2,500 words.

**Language rule:** NEVER use avoidance language anywhere in this document. If a hesitation must be named, name it as a permission question, not a pain statement. If a problem must be named, frame it as an aspiration temporarily blocked, not a wound to heal.

---

## CALIBRATION NOTES

Signs a prospect has reached Point B in an approach market:
- They ask HOW questions, not WHETHER questions ("How does the community work?" not "Is this for me?")
- They start narrating their starting point to you — describing where they are now, as if building the context for their beginning
- They reference other community members by name or describe wanting to be part of what they've seen
- They use first-person future language: "I would use this for..." / "I've been wanting to..."
- They ask about start dates, next cohorts, or how quickly they'd see their first results
- They mention the aspiration as something they've been thinking about for a long time — "I've always wanted to..."

Signs they're NOT at Point B (and which dimension is missing):
- "I need to think about it" → Missing identity permission or identity claim (they haven't yet given themselves the yes)
- "It's a lot of money for something just for me" → Missing identity permission (they don't yet see this as identity investment)
- "I'm not sure I'd keep up with everyone else" → Missing belonging state or mirror proof (no demographic match visible)
- "Maybe when things slow down" → Missing anticipation state (the pull isn't strong enough yet to overcome inertia)
- "That looks great for [someone else]" → Missing mirror (they can't see themselves in the proof)

---

## QUALITY GATE

Before saving, verify:

- [ ] All four dimensions fully mapped (not just one or two)
- [ ] Emotional Feeling State contains ONLY pull-based states — no productive tension, no urgency-as-pressure, no dissatisfaction language
- [ ] Identity Alignment specifies the exact present-tense identity claim (not future aspiration)
- [ ] Social Proof Needs describes the demographic mirror specifically enough to brief a testimonial request
- [ ] Point B Statement passes the approach market test: does it sound like PULL (toward aspiration) or PUSH (away from pain)? Any push = revise
- [ ] Aspiration Objection Radar covers the most common permission questions for this specific market
- [ ] Language throughout is approach-only — no pain, failure, frustration, stuck, broken, struggling unless explicitly contrasting with aspiration
- [ ] Saved to file

---

## HOW THIS CONNECTS DOWNSTREAM

- **identity-belief-gap-analyzer** → Point B from this skill IS the destination for the identity gap analysis. The identity claim and social proof needs defined here specify exactly what gaps need closing.
- **permission-concept-generator** → The Core Concept for approach markets must resolve the primary identity permission gap named in Dimension 3. Check all concepts against this map.
- **toward-usp-generator** → The USP must create the identity permission shift (Dimension 3) while triggering the anticipation state (Dimension 2).
- **community-architect** → Community design starts from the belonging state (Dimension 2) and community visibility needs (Dimension 4) mapped here.
- **aspiration-avatar-excavation** → The identity bridges and mirror specifications here feed directly into avatar segment differentiation.
- **webinar structure (Toward Markets)** → Each section of an approach-market webinar moves prospects through a different dimension: intro = belonging + anticipation, content = logical readiness + identity visibility, transition = identity claim, close = permission + enrollment.
