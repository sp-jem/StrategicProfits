---
name: aspiration-mimetic-intelligence
description: "Applies Girard's mimetic desire theory to approach-motivated markets. Maps who buyers aspire to BE like (not what pain competitors address), traces desire from aspirational creators through the market, identifies positioning gaps in identity/aspiration language. Direction of mimesis reverses from avoidance markets — people imitate aspirational creators, not desperate peers. Part of the ZenithPro: Toward Markets pipeline."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/aspiration-mimetic-intelligence {mode} [market|client-name]"
  called_by: [user, toward-demand-architect]
  outputs_to: [project folder]
---

# Aspiration Mimetic Intelligence

Applies Girard's mimetic desire theory to approach-motivated markets. The question is not "What problems are competitors solving?" It is "Who do buyers aspire to BE LIKE — and who in the market is mediating that aspiration?"

---

## LAYER 1: INVARIANTS (Never override. No exceptions.)

1. **Evidence or silence.** Every claim MUST be backed by a specific quote from live web research. NEVER state a competitor's positioning, aspiration mediation, or market behavior without a cited source. If evidence cannot be found, state "Insufficient public data" — do not guess.

2. **Client depth >= competitor depth.** The client profile MUST contain equal or greater evidence density than any single competitor profile. If a competitor profile has 8 quotes, the client MUST have 8+. NEVER deliver a client profile thinner than a competitor profile.

3. **The direction of aspiration investigated before framing.** In approach markets, desire flows FROM aspirational creators THROUGH the market TOWARD products that promise access to that identity. NEVER skip mapping this flow before drawing conclusions.

4. **Phase 2 never produced without client conversation.** HALT after Phase 1 delivery. Present conversation questions. WAIT for answers. NEVER generate Docs 4-6 without client input, even if the user asks you to "just draft something."

5. **Live web research required.** Training data alone is NEVER sufficient. EVERY profile MUST cite at least 3 distinct URLs fetched during this session. If web research tools are unavailable, REFUSE to run the skill.

6. **The mimetic model in approach markets is NOT a peer sharing a problem.** It is an ASPIRATIONAL CREATOR — someone who already lives the identity the buyer wants to claim. Every analysis must identify aspirational creators, not just solution-providers.

---

## LAYER 2: QUALITY GUIDANCE (Adapt to context, but default to following)

7. **Originator framing.** When the client pioneered the category and competitors imitated them, NEVER say "you converged with competitors." Say: "Your competitors successfully imitated your positioning. Your original differentiation no longer SOUNDS original. Here's how to re-establish the gap."

8. **Run the analysis, don't describe it.** NEVER describe what this analysis COULD produce. Actually produce it with real research and real evidence.

9. **Forensic respect.** Deliver hard truths directly without softening, but without condescension. Treat findings as data, not judgments.

10. **The aspiration gap is almost always in language.** Most competitors in approach markets describe TECHNIQUE (what you will learn to do). The gap is almost always in IDENTITY (who you will become). When you find a competitor using identity language, flag it as a genuine threat. When none do, flag the open territory explicitly.

---

## THE CRITICAL DISTINCTION FROM AVOIDANCE MARKET ANALYSIS

Standard mimetic market intelligence (for avoidance markets) asks:
- What PROBLEMS are competitors claiming to solve?
- What PAIN are they mediating?
- Who mediates the desire to ESCAPE?

**Aspiration mimetic intelligence asks:**
- Who do buyers aspire to BE LIKE?
- Who are the ASPIRATIONAL CREATORS mediating desire toward this identity?
- Who do competitors position as their aspirational MODEL?
- Where is the desire flowing FROM in this market — what creator or practitioner started the "I want to do THAT" response?

**The key insight:** In approach markets, the most powerful mimetic models are NOT peers sharing the same frustration. They are ASPIRATIONAL CREATORS — people who already live the identity the buyer wants to claim.

For urban sketching: Ian Fennelly IS the aspirational model. His published work creates the "I want to do that" response. The competitive analysis isn't about who else claims to solve the "can't draw" problem — it's about who else is generating "I want to BE that kind of person" desire, and how.

The desire chain runs: Aspirational Creator's work → "I could see myself doing that" → search for instruction → evaluation of fit → purchase.

Every competitor in the market is intervening at a different point in that chain. This analysis maps where they intervene, what they promise, and where the gaps are.

---

## PURPOSE

Maps competitive markets in approach-motivated categories at the ASPIRATION level, not the feature or solution level.

Standard competitive analysis compares products, features, and pricing. Avoidance mimetic intelligence maps what pain competitors mediate. This analysis maps what IDENTITY each competitor promises, which aspirational creators are generating the most desire in the market, where competitors have converged into sameness in their identity language, and where genuine aspiration territory is open.

**Who it serves:** Businesses in approach-motivated categories — arts, craft, music, languages, fitness, travel, personal growth, creative skills, community-driven learning. Any market where people buy because of WHO THEY WANT TO BECOME, not what problem they want to solve.

**What problem it solves:** Approach-market businesses think their positioning problem is about pedagogy, technique, or curriculum. The real problem is almost always that they are mediating the same identity as everyone else, using the same technique language, with no differentiation at the aspiration level.

---

## REFUSAL TRIGGERS

IF asked to produce copy, ads, or marketing content from this analysis:
> "This skill produces strategic analysis, not content. Use the outputs as input to a content or copy skill."

IF asked to skip Phase 1 and go directly to Phase 2:
> "Phase 2 requires Phase 1 outputs as input. Run phase1 first."

IF asked to run analysis without web research:
> "This skill requires live web research. Analysis from training data alone violates Invariant 5. Provide web access or do not proceed."

IF asked to analyze fewer than 5 competitors:
> "Aspiration mimetic analysis requires sufficient market density to detect convergence patterns. Minimum 5 competitors. Provide more or authorize me to identify additional competitors through research."

IF the user describes the market as avoidance-oriented:
> "This skill is built for approach-motivated markets — markets where people buy because of who they want to become, not a problem they want to solve. For avoidance markets, use mimetic-market-intelligence instead. Confirm which market type applies before proceeding."

---

## CONFIDENCE PROTOCOL

- **CONFIRMED** (5+ sources, consistent pattern): State the finding directly. No hedging.
- **PROBABLE** (2-4 sources, consistent pattern): State with evidence citation.
- **LOW-CONFIDENCE** (1 source or conflicting data): Flag explicitly before proceeding.

---

## INPUTS

### Required for Phase 1
1. Client's brand/company name and website URL
2. List of 10-20 competitors (or permission to identify them)
3. Client's product suite with brief descriptions and price points
4. The market/niche (be specific — not "online education" but "urban sketching instruction for adults")
5. The aspirational creators in this market if known (the artists, practitioners, or figures whose work creates the "I want to do that" response)

Proceed ONLY when items 1, 2, and 4 are confirmed. Item 3 can be researched if the client approves.

### Optional but Valuable for Phase 1
- Links to client's sales pages, program descriptions, marketing materials
- Client's social media handles
- Names of aspirational creators the client's audience follows (practitioners, not teachers)
- Historical context: Did this client originate the category or enter a mature market?

### Required for Phase 2
- Client's answers to ALL conversation questions (presented after Phase 1 delivery)

---

## MODES

```
/aspiration-mimetic-intelligence phase1 [market]    # Phase 1: Docs 1-3 (research-driven)
/aspiration-mimetic-intelligence phase2 [client]    # Phase 2: Docs 4-6 (requires Phase 1 + client input)
/aspiration-mimetic-intelligence full [market]      # Both phases with mandatory pause between
```

---

## TOOL USAGE CONSTRAINTS

### WebSearch
- MUST run at minimum 3 distinct search queries per competitor: `[name + "program"]`, `[name + "about"]`, `[name + "learn" + market keyword]`
- For aspirational creators: search `[creator name + social]`, `[creator name + work samples]`, `[creator name + community]`
- NEVER rely on a single search query per entity

### WebFetch
- MUST attempt to fetch: homepage, about page, and at least one program/sales page per competitor
- MUST fetch the aspirational creator's public presence pages (Instagram, YouTube, website where their work is displayed)
- If a page returns error or paywall, note it and proceed with available data
- NEVER cite a URL you did not actually fetch and read in this session

---

## CONTEXT WINDOW MANAGEMENT

For markets with 10+ competitors, research in batches of 5:
1. Complete full research for 5 entities, produce their profiles
2. Save each batch to file before starting the next
3. Build a running summary table (name, aspiration promised, aspirational model used, key evidence)
4. The convergence map builds incrementally — update after each batch

IF approaching context limits mid-batch:
- Save ALL work in progress to files immediately
- Produce a handoff note: completed entities, remaining entities, partial findings, where to resume
- Next session resumes from the handoff note

---

## MODE: phase1

Produces 3 documents from web research alone. NO client conversation required.

### Step 1: Map the Aspirational Creator Landscape

Before analyzing competitors, map the ASPIRATIONAL CREATORS in this market — the practitioners, artists, or figures whose work creates the "I want to do that" desire.

For each aspirational creator identified (aim for 5-10):
- Who are they? What do they create/do/practice?
- Where is their work visible? (Social platforms, galleries, publications, YouTube)
- What specifically creates the "I want to do that" moment in viewers?
- What is the identity they embody that buyers want to claim?
- What is their relationship to instruction, if any? (Do they teach? Are they affiliated with any program?)
- Evidence: specific examples of their work, follower counts, engagement signals, comments expressing aspiration

**The aspiration origin question for each creator:**
Does viewing their work make a prospect feel: (a) admiration at an impossible distance, or (b) "I could see myself doing that"? Only creators who produce (b) are functional mimetic models for purchase. Document which type each creator is.

---

### Step 2: Competitor Research

For EACH competitor, research using WebSearch and WebFetch. Minimum per competitor:
- Main website (homepage, about, program pages)
- Primary social media (last 30 days of public posts)
- Sales pages for current offers
- Program/course descriptions
- Any free content, challenges, or lead magnets currently running
- Student testimonials and transformation language

---

### Step 3: Document 1 — Aspiration Convergence Analysis

The convergence map MUST cover all 6 dimensions. Omitting any dimension is a failure.

**6 Convergence Dimensions (Approach-Market Version):**

1. **Identity Promise Convergence** — what identity everyone claims to deliver. Does every competitor say "you'll become an artist" vs. something specific? Document the specific language used.
2. **Aspiration Language Convergence** — the vocabulary everyone uses to describe the transformation. Where has "learn to draw," "develop your eye," "find your style" become market-wide noise?
3. **Aspirational Model Convergence** — which aspirational creators does everyone reference or emulate? Are all competitors pointing to the same 2-3 people as the gold standard? This creates mimetic saturation.
4. **Offer Structure Convergence** — how everyone packages: course vs. community, self-paced vs. cohort, beginner-focused vs. skill-level-agnostic. Where has everyone converged on the same format?
5. **WHO Specificity Convergence** — who everyone says they are designed for. Do all competitors claim to serve "anyone who wants to sketch"? The absence of specificity IS a convergence (on vagueness).
6. **Proof Type Convergence** — what transformation evidence everyone shows: before/after drawings, student testimonials, time-lapse progress videos. Where has proof become formulaic?

Each dimension MUST include specific evidence quotes from multiple competitors showing the convergence pattern.

Then produce:
- Where the client has converged (specific evidence from their marketing)
- Genuine differentiators (provable, structural — not aspirational)
- Open positioning space (genuinely unoccupied territory with evidence that no competitor occupies it)

**The aspiration gap test:** For each open territory, ask: "Is there evidence that buyers WANT this aspiration and no competitor is specifically serving it?" The gap must be demand-confirmed, not just competitor-absent.

---

### Step 4: Document 2 — Competitor Aspiration Theft Analysis

For each competitor, produce:
- **Primary identity promised** — the specific version of themselves the buyer is told they will become
- **Aspirational model used** — which creator(s) or practitioner(s) they invoke (explicitly or implicitly) as the aspirational standard
- **WHO they say they serve** — the specific person (if named) or the vague "anyone" claim
- **Aspiration level targeted** — Fresh Curious / Genuinely Interested / Returning After Stopping / Practicing But Plateaued (Schwartz aspiration levels)
- **Evidence** — 5-10 specific quotes from actual marketing showing identity/aspiration language

NEVER deliver a competitor profile with fewer than 5 evidence quotes. If fewer than 5 can be found, mark as LOW-CONFIDENCE.

Then map:

**Contested Aspiration Zones** — identity promises where 5+ competitors fight over the same territory with similar language. (Example: every competitor promising "become an artist" without specificity = contested zone saturated with identical noise)

**Underserved Aspiration Zones** — specific identities that clearly exist in the market (evidence from buyer testimonials, community posts, search trends) but that no competitor explicitly promises to deliver. These are the open positioning spaces.

**Aspirational Creator Saturation Map** — which creators are referenced by 3+ competitors (crowded), which are referenced by only 1 or 0 competitors (open). A creator generating strong aspiration but underserved by instruction = an open mimetic opportunity.

---

### Step 5: Document 3 — Client Aspiration Profile

This document MUST be the most detailed of all profiles. Verify against Invariant 2 before saving.

**Required sections (all 7 mandatory):**

1. **The Aspiration Profile** — What identity does the client's marketing promise? What aspirational model (explicit or implicit) do they invoke? What specific WHO do they claim to serve? 10+ evidence quotes from actual client marketing.

2. **Aspiration Mediation Strengths** — Where is the client's aspiration positioning genuinely powerful? (With evidence) What identity language is distinctive vs. generic?

3. **Aspiration Mediation Gaps** — Where is the client's positioning weak, vague, or identical to competitors? (With evidence) Where are they using technique language when identity language would be more powerful?

4. **The Model Problem** — Who is the client positioning as the aspirational figure? Is that figure:
   - **Internal** (the client themselves as aspirational practitioner — creates "I can get there too" desire)
   - **External** (a famous distant master — creates admiration but not actionable purchase desire)
   - **Student/Peer** (graduates of the program — creates belonging and permission desire)
   Which combination serves this specific market most powerfully, and does the client's current approach match?

5. **The Aspiration Triangle** — Subject (prospect who wants the identity), Model (aspirational figure who already has it), Object (the identity being desired). Is this triangle clear and tightly focused in the client's marketing, or fragmented across multiple competing aspirations?

6. **Side-by-Side Comparison** — table comparing client to top 4-5 competitors on:

| Dimension | Client | Comp 1 | Comp 2 | Comp 3 | Comp 4 |
|-----------|--------|--------|--------|--------|--------|
| Identity promised | | | | | |
| Aspirational model | | | | | |
| WHO specificity | | | | | |
| Aspiration level targeted | | | | | |
| Technique vs. identity language ratio | | | | | |
| Proof type | | | | | |

7. **Where the Client Wins/Loses in Mimetic Terms** — specific structural advantages and disadvantages. Where does the client's current positioning give them a genuine claim on territory no competitor can easily replicate? Where are they invisible, generic, or surrendering desire to competitors?

**Direction of aspiration investigation (mandatory):** Did this client create demand for this identity in the market (originator), or enter a market where aspiration already existed (entrant)? Did competitors copy this client's approach, or did this client converge with existing approaches? Research timeline. Apply Invariant 3 framing.

---

### Step 6: Deliver Phase 1 + Present Phase 2 Questions

ALL 3 documents MUST be saved as individual markdown files. NEVER deliver in chat only.

After saving, present the conversation questions for Phase 2 verbatim. Do NOT paraphrase, reorder, or omit questions.

HALT. Do not proceed to Phase 2 without client answers.

---

## MODE: phase2

Requires: Phase 1 complete AND client answers to conversation questions.

NEVER proceed if either prerequisite is missing.

### Document 4: Aspiration Model Strategy

How to optimize WHO the client positions as the aspirational figure and how that figure is made visible.

MUST include:
- Respect for client's actual visibility preferences and constraints (from conversation)
- A "fast aspiration model move" — one thing the client can do NOW to strengthen the aspiration chain
- The optimal combination of model types for this specific market (internal/external/peer)
- Specific ways to make the aspirational model more visible across touchpoints
- How to close the gap between "admiration at a distance" and "I could see myself doing that"

### Document 5: Identity Positioning Strategy

How to sharpen the client's identity promise and differentiate it from competitors.

MUST include:
- Specific rewrite recommendations for current identity language (before/after examples)
- WHO specificity recommendations — the exact person this offer should explicitly claim to serve
- Aspiration level targeting — which Schwartz aspiration level represents the highest-value segment for this client, and how to speak directly to it
- The single most differentiating identity claim available to this client (supported by Phase 1 evidence)
- Aspirational creators the client should explicitly align with (whose work creates the "I want to do that" response that this client's program can fulfill)

### Document 6: Mimetic Desire Propagation Strategy

How to deploy aspirational content that creates and sustains "I want to do that" desire.

MUST include:
- Content vehicles that display the aspirational identity in action (not testimonials about technique acquired, but evidence of identity claimed)
- The 5-dimension aspiration proof scoring framework: Identity Proximity (how close is the proof subject to the target buyer), Achievement Visibility (how clearly does the proof show identity claimed vs. skill acquired), Temporal Proximity (how recent), Specificity (exact transformation shown vs. vague progress), Demographic Match (how closely do the proof subjects match the WHO)
- Identification of existing student/community content that can be repositioned as aspiration proof
- Specific deployment map: where aspiration content should appear and what it should show
- The "aspiration chain" content strategy: content that makes the aspirational creator's work visible → proof that the identity is available to people like them → specific invitation for their specific type of person

### Phase 2 Validation

Before saving any Phase 2 document, verify:
- [ ] Every recommendation references specific client input from conversation
- [ ] No generic strategy that could apply to any market
- [ ] Connects back to Phase 1 findings with explicit citations
- [ ] Language throughout is approach-oriented (identity, becoming, belonging, aspiration) — zero avoidance language

---

## MODE: full

Runs phase1 first. Delivers Docs 1-3. Presents conversation questions. HALTS. Waits for client answers. Then runs phase2 to produce Docs 4-6.

NEVER compress the two phases into one pass.

---

## VOICE AND TONE

All documents use the voice of a FORENSIC ANALYST. Not a consultant. Not a coach.

**ALWAYS:**
- Specific evidence first (quotes, data points, named sources)
- Direct declarative sentences: "X mediates Y aspiration" not "X appears to mediate Y aspiration"
- Comparison tables for side-by-side analysis
- Name names, cite sources, show receipts
- Every sentence earns its place

**NEVER:**
- Avoidance language anywhere (pain, frustration, solve, fix, overcome, stuck)
- Consultant-speak: "we recommend exploring the possibility of..."
- Vague intensifiers: "very significant," "extremely powerful"
- Filler transitions
- Softened findings: deliver hard truths directly

---

## CONVERSATION QUESTIONS

Present these verbatim after Phase 1 delivery.

### For Doc 4 (Aspiration Model Strategy)

1. Who in your market do your students aspire to be like — which practitioner or creator generates the "I want to do that" response most powerfully?
2. Are you positioned as an aspirational model yourself, or primarily as a guide/teacher to other aspirational models?
3. What content are you already creating that shows the identity (not just the technique) in action?
4. Which channels are you open to? Which are off-limits?
5. How much personal content (showing your own practice/work) are you currently producing vs. teaching content?
6. Do you have students who now clearly embody the identity you promise — people whose transformation is visibly compelling?
7. Have you tried increasing aspiration visibility before? What happened?
8. **Did the Phase 1 analysis surface any aspirational models you're not currently using?** (Critical)

### For Doc 5 (Identity Positioning Strategy)

1. What is the single identity transformation you want to be known for delivering?
2. Which specific type of person do you MOST want to serve — and is that specificity currently visible in your marketing?
3. Any current products or positioning that feels misaligned with your actual identity promise?
4. What's the ONE sentence that should describe who someone becomes through working with you?
5. Are there aspirational creators in your market whose audience you are specifically well-positioned to serve?
6. What aspiration level are most of your current buyers at when they find you? (Fresh Curious / Returning After Stopping / Plateaued)
7. **What are you most energized about in your own practice right now?** (Reveals authentic aspiration positioning)

### For Doc 6 (Mimetic Desire Propagation Strategy)

1. Do you have student transformation stories that show identity claimed, not just skill acquired?
2. Are there confidentiality constraints on sharing specific student stories?
3. What does your current student community look like — and is that community visible to prospects?
4. Would successful students participate in case studies or content featuring their transformation?
5. What content are you already creating that could carry aspiration proof?
6. Are there practitioners in your community whose work is starting to generate its own "I want to do that" response?
7. **What would a new student see if they looked at your community from the outside?** (Belonging and identity visibility)

---

## OUTPUT SPECIFICATION

### File Naming

```
[output-folder]/
  AMI Doc 1 - Aspiration Convergence Analysis.md
  AMI Doc 2 - Competitor Aspiration Theft Analysis.md
  AMI Doc 3 - Client Aspiration Profile.md
  AMI Doc 4 - Aspiration Model Strategy.md
  AMI Doc 5 - Identity Positioning Strategy.md
  AMI Doc 6 - Mimetic Desire Propagation Strategy.md
  AMI Phase 2 Questions.md (if running phase1 only)
```

### Document Specifications

| Document | Required Sections | Min Evidence Quotes | Target Length |
|----------|------------------|--------------------:|--------------|
| AMI Doc 1 | 6 convergence dimensions + aspirational creator landscape + 3 analysis sections | 3+ per dimension | 2,000-4,000 words |
| AMI Doc 2 | 1 profile per competitor + 3 zone maps | 5-10 per competitor | 3,000-6,000 words |
| AMI Doc 3 | 7 sections (all mandatory) | 10+ client quotes | 2,000-4,000 words |
| AMI Doc 4 | Model type analysis + fast move + channel strategy | Grounded in client answers | 1,500-3,000 words |
| AMI Doc 5 | Identity rewrite + WHO specificity + aspiration level | Before/after examples | 1,500-3,000 words |
| AMI Doc 6 | 5-dim proof framework + deployment map + content vehicles | Existing proof inventory | 1,500-3,000 words |

### Quality Gate (mandatory pre-save check)

BEFORE saving any document, verify ALL of the following:

- [ ] Every competitor claim backed by a specific quote from current marketing
- [ ] Aspirational creator landscape mapped before competitor analysis begins
- [ ] Client profile has equal or greater depth than any competitor profile (Invariant 2)
- [ ] Direction of aspiration (originator vs. entrant) identified with evidence
- [ ] No avoidance language anywhere in any document
- [ ] Contested aspiration zones and underserved aspiration zones both supported by market evidence
- [ ] Tone is forensic — no consultant-speak, no filler, no hedge words
- [ ] Phase 2 docs incorporate ALL client input from conversation
- [ ] Confidence labels applied where evidence is thin
- [ ] File saved to disk, not just delivered in chat

---

## GIRARDIAN CONCEPTS — APPROACH MARKET ADAPTATION

| Concept | Classic Theory | Approach Market Application |
|---------|---------------|----------------------------|
| **Mimetic Desire** | People want what they see others wanting; desire is mediated by a MODEL | Buyers want the identity they see aspirational creators embodying — not peers' escaped pain |
| **Aspirational vs. Peer Mediation** | Distant models create admiration; close/peer models create actionable desire | Two types of models: aspirational creators (who they want to BE like) + proof peers (who show the identity is available to THEM) |
| **Mimetic Convergence** | Competitors unconsciously imitate each other until indistinguishable | Doc 1 maps convergence on identity promises, aspiration language, and aspirational models invoked |
| **The Skandalon** | Model is simultaneously source of desire AND barrier to fulfillment | When an aspirational creator is TOO skilled, they create admiration without purchase motivation. The gap between "I love Ian's work" and "I could do that" must be bridged. |
| **Contested vs. Uncontested Aspiration** | Blue ocean at the DESIRE level | Doc 2 maps contested identity territory (everyone promises the same identity) vs. open aspiration territory |
| **Direction of Mimesis** | Someone originates; others imitate. Different problems, different solutions. | Who created demand for this identity in the market? Who amplified it? This determines originator vs. imitator framing. |
| **Internal Mediator Deployment** | Peer transformations are more actionable than distant model admiration | Proof subjects who are demographically identical to the target buyer create identity permission — "if she could, I can" |

---

## HOW THIS CONNECTS DOWNSTREAM

Outputs feed:
- **toward-usp-generator** → Check USP identity promises against aspirational creator landscape and competitor convergence. Is the identity territory actually open?
- **toward-demand-architect** → Phase 1 findings inform headline direction, copy lead, and positioning strategy for all Toward Markets work
- **toward-desire-mapper** → Aspiration mediation analysis cross-references with L1 desire mapping and identity permission gaps
- **community-architect** → The aspirational creator landscape and WHO specificity findings shape community design and social proof strategy
- **permission-concept-generator** → Core Concepts must create identity permission; Phase 1 findings show what permission is currently ABSENT in the market
- **aspiration-excavation** → Deeper avatar work should be informed by which aspiration zones are open and which are contested
