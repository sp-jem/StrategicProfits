---
name: identity-belief-gap-analyzer
description: "Maps the exact distance between Point A (curious but doubting myself) and Point B (I can become this person and I'm ready to invest). Identifies every identity permission gap, maps their dependency chain, and specifies what evidence creates each shift. The approach-motivated equivalent of belief-gap-analyzer — gaps are about identity access, not mechanism credibility. Part of the ZenithPro: Toward Markets pipeline."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/identity-belief-gap-analyzer [market or avatar]"
  called_by: [user, toward-demand-architect]
  outputs_to: [project folder]
---

# Identity Belief Gap Analyzer

Maps the exact path from where approach-motivated prospects ARE (curious but doubting themselves) to where they need to BE (I can become this person and I'm ready to invest). Shows not just WHAT identity beliefs must shift, but in what ORDER and using what EVIDENCE.

---

## LAYER 1: INVARIANTS

1. **The gap is always about identity permission, never mechanism credibility.** If a gap sounds like "Will this work?", that's a mechanism question reframed. The correct version is "Will this work for someone like ME?" — which is an identity permission question. Reclassify all mechanism gaps into identity gaps before proceeding.
2. **Order matters absolutely.** Category-level identity permission must precede self-level identity permission. You cannot install "I can learn to draw" before installing "people like me can learn to draw." Dependency logic is non-negotiable.
3. **Evidence type is not interchangeable.** Mirror testimony (demographically identical person) doesn't fix a category belief. Logic doesn't fix identity prohibition. Match evidence to gap type precisely.
4. **Point A is curious, not broken.** The emotional starting point is positive engagement — interest, draw toward, even longing — blocked by identity doubt. This is not avoidance of pain. Do not import avoidance-market language.
5. **Point B is identity claim, not mechanism belief.** The destination is "I can become this person and I'm ready to invest" — not "I believe this system will work." The purchase is the first act of the new identity.
6. **Save all outputs to files.** Never deliver in chat only.

---

## PURPOSE

The formula for approach markets: **Aspiration + Identity Permission = Demand**

Aspiration exists. That is not the problem. Between aspiration and purchase is a specific identity permission structure. This skill maps that structure.

**The Bridge Metaphor:** Point A and Point B are separated by a chasm of identity doubt. You can't jump it in one leap. You build bridges — one identity permission shift at a time — that create a safe, psychologically sound path from "I'm drawn to this but it's not for someone like me" to "this is for me and I'm ready to begin."

**Critical Insight:** The ORDER matters. Some identity bridges enable others:
- Can't believe "I can become a sketcher" until they believe "sketching is available to people who start at my age"
- Can't believe "starting now is valid" until they believe "the journey, not just the destination, is the point"
- Can't believe "I'm ready to invest" until they believe "investing in myself for this is legitimate and deserved"

**Output use:** Becomes the content strategy blueprint for approach-market demand creation. Every marketing piece builds a specific identity bridge. This tells you which identity shift to create first, why, and what proof it requires.

---

## THE THREE TYPES OF IDENTITY GAPS

**1. CATEGORY-LEVEL PERMISSION GAPS** (Does this world exist for people like me?)
- Example: "Is urban sketching something people my age and background actually do?"
- Importance: Must resolve at the category level BEFORE self-level permission becomes possible
- Evidence: Community visibility showing demographic diversity; statistics on who actually participates

**2. SELF-LEVEL PERMISSION GAPS** (Am I specifically allowed into this world?)
- Example: "Even if others my age do it, would someone like ME — with no natural talent — succeed?"
- Importance: Most personal and hardest to shift; requires demographic mirror, not just category proof
- Evidence: Mirror testimony from a person with nearly identical starting conditions

**3. TEMPORAL/DEVELOPMENTAL PERMISSION GAPS** (Is it too late / am I too early / is my moment right?)
- Example: "Real practitioners start when they're young — I missed my window"
- Importance: A conviction that the access point has passed; often the deepest prohibition
- Evidence: Stories of late starters who found their development actually benefited from life experience

---

## INPUTS

Required:

1. **Point A Description** — the current state: curious but doubting themselves
   - What specifically are they drawn toward? What is the aspiration?
   - What specific identity doubts are blocking access? ("I'm not..." / "people like me don't..." / "it's too late for...")
   - What is the emotional quality of Point A? (interest, longing, tentative curiosity, inspired-but-hesitant)
   - What have they tried before in this space, and what identity conclusions did they draw?

2. **Point B Description** — from ideal-aspiration-mindset skill, or describe manually:
   - What is the specific identity claim they must make before purchase feels congruent?
   - What present-tense identity statement must be true? ("I AM this kind of person")
   - What permission must they have given themselves?

3. **Aspiration Hierarchy Map** — from toward-desire-mapper:
   - Primary L1 desires active in this market
   - L4 identity permission barriers already identified
   - Aspiration Stratigraphy (surface/middle/deep)

4. **Avatar Research** — community language, testimonials, forum posts, reviews:
   - What specific identity prohibitions come up repeatedly?
   - What language do people use when describing why they almost didn't start?
   - What did existing buyers say shifted for them before they committed?

5. **Market's History with This Aspiration** — prior attempts to enter this world:
   - What caused people to walk away before? What conclusion did they draw about themselves?
   - What previous offers did they encounter, and what identity conclusions did those create?

6. **Output folder path**

---

## STEP 1: IDENTITY GAP INVENTORY

For each gap between Point A and Point B, document:

**IDENTITY GAP #[X]: [Gap Category]**

*Point A Identity Belief (Current):* "[The exact belief that blocks them — in their own words / language]"

*Point B Identity Belief (Required):* "[The exact belief they need to hold — the permission that enables purchase]"

Gap Analysis:
- **Type:** Category-Level / Self-Level / Temporal-Developmental
- **Size:** Small (reframe available) / Medium (evidence required) / Large (mirror + experience required)
- **Emotional Weight:** How much identity threat is bound up in this gap?
- **Priority:** High / Medium / Low (based on how many other gaps depend on this one)

Why This Gap Exists:
[What created this identity prohibition — inference from role models, failed early attempts, cultural messaging, demographic assumption, or prior purchase experience]

Interference Factors:
- **Identity prohibition:** "[The exact 'I'm not / I can't / it's not for me' belief]"
- **Temporal prohibition:** [Any "I missed my window / I'm too old / I should have started sooner" belief]
- **Demographic prohibition:** [Any "people from my background / age / experience level don't do this" belief]
- **Gap distance belief:** "[Any belief that the distance between them and the aspirational model is uncrossable]"

Target length for full gap inventory: 8-14 gaps total. Fewer means important gaps were missed; more usually means over-splitting.

---

## STEP 2: DEPENDENCY CHAIN MAPPING

For each identity gap, map:
- What permissions must exist BEFORE this one becomes accessible?
- What permissions does this one ENABLE once established?
- Is this a Foundation, Middle, Upper, or Capstone bridge?

**Foundation Bridges** (must come first — enable all others):
- No prerequisites
- Establish that the world is genuinely accessible to people like them at the category level
- Examples: "People my age are actively doing this and thriving" / "Starting fresh is not a disadvantage in this field"
- Usually: Category-level permission gaps

**Middle Bridges** (depend on foundation, enable upper):
- Prerequisites: specific foundation bridges must be established
- Build the specific self-permission that this person can enter this world
- Usually: Self-level permission gaps grounded in the foundation established above

**Upper Bridges** (advanced — require multiple middle prerequisites):
- Build investment readiness and temporal permission
- Address "am I ready NOW and is this investment worthy of who I'm becoming?"
- Usually: Combination of self-level and temporal-developmental gaps

**Capstone Bridges** (purchase readiness):
- The final identity claim: present-tense, first-person
- Investment congruence: "This investment matches who I am"
- Enrollment readiness: "The question is how to begin, not whether"

---

## STEP 3: IDENTITY OBSTACLE ANALYSIS

For each bridge, identify the specific interference that must be navigated:

**Common Identity Obstacles in Approach Markets:**

1. **The Talent Myth** — "Natural talent is the prerequisite. I don't have it."
   - Origin: Cultural messaging about innate ability vs. developed skill
   - Correction: Evidence that the skill is systematically learnable; testimony from people who had no background

2. **The Age Window** — "The right time to start was years ago. That window has closed."
   - Origin: Stories of prodigies and early starters; assumption that identity formation is age-limited
   - Correction: Late-starter stories where life experience became a genuine advantage; community visibility of mature practitioners

3. **The Background Gap** — "This is for people who grew up differently / were educated differently / had access I didn't have."
   - Origin: Perception that the community is composed of demographically different people
   - Correction: Community visibility showing demographic diversity; mirror testimony from the exact background

4. **The Distance Prohibition** — "The gap between me and [admired practitioners] is too large to cross."
   - Origin: Comparing their starting point to someone else's advanced state
   - Correction: Not showing the expert's destination — showing a person at THEIR starting point who made meaningful progress

5. **The Worthiness Gap** — "Investing at this level in something for myself feels indulgent / premature / not yet earned."
   - Origin: Cultural conditioning around productivity, obligation, and delayed gratification
   - Correction: Reframing investment in aspiration as identity declaration, not discretionary spending; permission stories from people who made this shift

6. **The Impostor Fear** — "If I join this community, they'll see I don't really belong."
   - Origin: Anticipatory identity threat; fear of being exposed as someone who doesn't deserve to be there
   - Correction: Community culture evidence (welcoming of beginners); testimony from people who feared this and found the opposite

---

## STEP 4: EVIDENCE SPECIFICATION FOR APPROACH MARKETS

For each bridge, specify the exact evidence type that creates the identity shift:

**Evidence Type Matching Rules (Approach Markets):**

| Gap Type | Required Evidence | Why |
|----------|-----------------|-----|
| Category-level permission | Community visibility (photos, demos, testimonials showing demographic range) | Must SEE the category is populated by people like them |
| Self-level permission | Mirror testimony (nearly identical person who made the crossing) | Logic doesn't shift identity; seeing yourself in someone else does |
| Talent myth | Demonstration of skill development (before/after from verifiable starting point) | Shows the skill is a function of method, not talent |
| Age window | Late-starter testimony highlighting specific advantages of starting now | Reframes temporal prohibition as temporal permission |
| Background gap | Demographic-specific mirror testimony + community demographic evidence | Specific, not general — must match their specific background concern |
| Distance prohibition | Journey documentation (not endpoint) — showing the progression, not the destination | The expert's endpoint is irrelevant; the journey from their starting point is what creates permission |
| Worthiness gap | Permission story — someone who overcame this exact scruple and the identity shift that followed | Permission is caught, not taught |
| Impostor fear | Community culture evidence (how beginners are actually treated) + first-person testimony of welcome | Must show the reality, not just assert it |

**What Does NOT Work in Approach Markets:**

- Logical argument for why they should be able to do this ("Here's why it's not too late...")
- Statistics without demographic specificity ("Thousands of people learn this every year")
- Expert endorsement without peer-level evidence ("Even [famous expert] says anyone can learn")
- Feature lists of the curriculum (what's being taught doesn't answer the identity question)
- Urgency tactics (the problem isn't that they haven't decided fast enough — it's that they haven't given themselves permission)

---

## STEP 5: BRIDGE SEQUENCE OPTIMIZATION

Arrange all bridges in the optimal order considering:
- Logical dependencies (category permission before self permission)
- Psychological readiness (can't absorb a mirror if the category belief hasn't been established first)
- Momentum building (small identity permissions enable larger ones)
- Natural narrative flow (tells a coherent story of a world opening up to them)

Produce:

```
BRIDGE 1: [Name] — [Type: Foundation/Middle/Upper/Capstone]
Evidence: [Specific proof type]
Installs: "[Permission created]"
       ↓ enables
BRIDGE 2: [Name] — [Type]
Evidence: [Specific proof type]
Installs: "[Permission created]"
       ↓ enables
BRIDGE 3: [Name] — [Type]
Evidence: [Specific proof type]
Installs: "[Permission created]"
       [continues...]
       ↓ arrives at
IDENTITY CLAIM: "[Present-tense first-person statement]"
       ↓ produces
PURCHASE ENROLLMENT
```

---

## COMPLETE OUTPUT DOCUMENT

**File: `Identity-Belief-Gap-Analysis-[Market].md`**

---

### EXECUTIVE SUMMARY

**The Identity Chasm:** [One paragraph describing Point A, Point B, and the nature of the gap between them — language of identity, not pain]

**Number of Bridges Required:** [X total]
- Foundation bridges: [Count]
- Middle bridges: [Count]
- Upper bridges: [Count]
- Capstone bridges: [Count]

**Critical Path:** [Shortest viable sequence for this market]
**Biggest Identity Obstacle:** [The permission belief most resistant to change and why]
**Highest-Leverage Mirror:** [The single mirror testimony that, if produced, unblocks the most demand — with exact demographic specifications]
**Master Bridge:** [The one identity shift that, once made, shortens or eliminates multiple others]

---

### SECTION 1: COMPLETE IDENTITY GAP INVENTORY
[All gaps documented per Step 1 above — minimum 8, target 10-12]

---

### SECTION 2: DEPENDENCY CHAIN MAP

[Full bridge architecture — Foundation, Middle, Upper, Capstone layers, with arrows showing which bridges enable which]

**Foundation Layer** — [Category-level permissions that must come first]
**Middle Layer** — [Self-level permissions that build on the foundation]
**Upper Layer** — [Investment readiness and temporal permissions]
**Capstone Layer** — [The identity claim and enrollment readiness]

---

### SECTION 3: OPTIMAL BRIDGE SEQUENCE

The critical path from "curious but doubting myself" to "I can become this person":

For each step:

**STEP [N]: [Bridge Name]** ([Layer])
- Timing: [Where this appears in the sequence / what marketing context]
- Core Message: "[The central identity permission this step creates]"
- Evidence Required: [Mirror type / community visibility / demonstration / permission story]
- Demographic Specificity: [How closely must the proof match the prospect's demographics?]
- Transition to Next: "[How this permission naturally opens the door to the next]"
- Success Indicator: Prospect thinks: "[The internal statement that signals this bridge has landed]"
- If This Fails: [What keeps them stuck / which dimension of the ideal-aspiration-mindset is still missing]

---

### SECTION 4: EVIDENCE SPECIFICATION

[Mirror library — exactly what proof is needed for each bridge]

For each bridge:
- Evidence type and format
- Exact demographic profile of mirror needed
- What the mirror testimony must include (starting point, specific identity doubt, what shifted, current experience)
- What NOT to include (aspirational endpoint far beyond prospect's horizon; language of overcoming pain rather than crossing into belonging)

**PRIORITY TESTIMONIAL BRIEF:**

The single most important piece of evidence for this market:

Person profile: [Exact demographics — age, background, prior experience level, specific identity doubt they had]
What they need to share:
1. Where they were (their starting point — must match your prospect closely)
2. The specific doubt that almost stopped them ("I almost didn't because I thought...")
3. What shifted (the identity permission moment)
4. What they found on the other side (the experience of belonging, not just the skill)
5. How they describe themselves now (the identity label they claim)

---

### SECTION 5: IDENTITY INTERFERENCE PATTERNS

[All identity prohibitions, cultural conditioning, and prior-experience conclusions that actively block bridges, with correction strategies]

For each major interference:
- The specific belief form it takes in this market
- What created it (inference from prior experience / cultural messaging / demographic assumption)
- What approach-market correction looks like (NOT: "that's wrong, here's the truth" — YES: "here's someone exactly like you who had that exact doubt, here's what happened")

---

### SECTION 6: PARALLEL vs. SEQUENTIAL BRIDGES

**Bridges that can be built simultaneously:**
[Which identity permissions can be established in parallel, and why they don't create conflict]

**Bridges that MUST be sequential:**
[Which permissions require a predecessor, with an explicit note on what breaks if the sequence is violated]

Example: Community visibility (category permission) can be built in parallel with talent myth correction, but self-level mirror testimony MUST come after both — otherwise the mirror has no context to land in.

---

### SECTION 7: CONTENT MAPPING

[Map each bridge to specific marketing content]

For each bridge, in the marketing context specified:

**[Bridge Name]**
- Content format: [Video demo / testimonial story / community tour / permission story / demonstration]
- Opening frame: [How to introduce this content so it lands on the identity question, not a mechanism question]
- Core evidence: [Specific proof to include]
- Identity permission installed: [The belief that gets established]
- Transition to next content piece: [The natural opening created]

---

### SECTION 8: THE MASTER BRIDGE

Identify which single identity shift, if established, shortens or eliminates the need for multiple other bridges.

In approach markets, this is almost always the CATEGORY-LEVEL PERMISSION BRIDGE — the first time someone with this demographic profile truly sees that this world is populated by people like them.

Show:
- Which foundation bridges the master bridge shortens or replaces
- How it simultaneously addresses multiple gap types
- Where in the sequence it creates maximum leverage
- The exact form it should take in this market (community tour video? Single testimonial? Live demonstration with demographic representation visible?)

---

## QUALITY GATE

Before saving, verify:

- [ ] Gap inventory has 8-14 gaps (3-4 is surface level; 15+ is usually over-splitting)
- [ ] Every gap is framed as identity permission, not mechanism credibility (no "Will this work?" — only "Is this for someone like me?")
- [ ] Dependency chain is logically sound: category before self-level, self-level before investment readiness
- [ ] Evidence types are approach-market appropriate — mirror testimony, community visibility, demonstration, permission stories (NOT: stats, logic, urgency)
- [ ] Critical path identifies minimum viable sequence
- [ ] Demographic mirror specification is specific enough to brief a testimonial collection campaign
- [ ] Master Bridge identified
- [ ] Language throughout is approach-market only: no pain, frustration, broken, stuck, struggling
- [ ] Output saved to file

---

## TROUBLESHOOTING GUIDE

**"Prospects engage with content but don't buy"**
- Is category-level permission solid? (They may enjoy content without having made the identity claim)
- Is the mirror demographic close enough? (People see "someone like them" in a general sense but not their specific barriers)
- Is the capstone bridge missing? (The permission to invest — not just to aspire)

**"Prospects say 'I'll start when I'm more ready'"**
- This is a temporal permission gap (Bridge type: Upper layer)
- Missing bridge: the shift from "readiness comes before starting" to "starting IS how readiness develops"
- Evidence needed: testimony from people who thought this and found the starting was what created the readiness

**"Prospects love the vision but say 'maybe someday'"**
- Aspiration is present; identity permission is absent
- Check for worthiness gap or impostor fear specifically
- Missing: the permission story from someone who overcame "someday" thinking and what shifted

**"Sequence feels too long / prospects drop off"**
- Identify the Master Bridge — does it exist in the sequence?
- Look for places where category permission and self permission have been combined (they must be separated)
- Check if any bridges are attempting to build permission through logic rather than mirror — logic extends the sequence

---

## HOW THIS CONNECTS DOWNSTREAM

- **ideal-aspiration-mindset** → Point B defined there IS the destination for this skill's analysis. The identity claim and social proof specifications from that skill specify exactly which gaps need closing and what evidence is required.
- **toward-usp-generator** → The USP for approach markets must resolve the Master Bridge (usually category-level permission) while creating anticipation for the aspired identity.
- **permission-concept-generator** → The Core Concept for approach markets is the Master Bridge stated as a one-sentence identity permission reframe. This analysis shows exactly what it must accomplish.
- **community-architect** → Community design starts from the belonging and impostor-fear gaps mapped here. The community must visibly embody the proof that addresses the demographic prohibition.
- **content strategy** → Each bridge = one piece of content. This map is the content calendar in strategic sequence.
- **testimonial acquisition** → The evidence specifications in Section 4 become the brief for collecting the right testimonials from existing students.
- **toward-desire-mapper** → The identity permission gaps mapped here connect directly back to the L4 layer of the aspiration hierarchy. Misalignments between the two analyses signal missed gaps.
