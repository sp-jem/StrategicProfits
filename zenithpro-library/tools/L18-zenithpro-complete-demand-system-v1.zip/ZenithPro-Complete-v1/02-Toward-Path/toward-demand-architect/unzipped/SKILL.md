---
name: toward-demand-architect
description: "10-step orchestration skill that runs the complete ZenithPro: Toward Markets pipeline for approach-motivated markets. Synthesizes all 10 Toward Markets skills (toward-desire-mapper, aspiration-excavation, aspiration-avatar-excavation, progression-pattern-analysis, permission-concept-generator, ideal-aspiration-mindset, identity-belief-gap-analyzer, toward-usp-generator, aspiration-mimetic-intelligence, community-architect) into a unified demand creation system for markets where buyers move TOWARD aspiration, identity, mastery, and community. Produces three synthesis outputs: Aspiration Architecture Map, Identity Permission Brief, and Community Demand Strategy. Use when building demand creation for any approach-motivated market from scratch."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/toward-demand-architect {mode} [market or business]"
  modes: [full, quick, audit]
  called_by: [user]
  outputs_to: [project folder]
dependencies:
  - toward-desire-mapper
  - aspiration-excavation
  - aspiration-avatar-excavation
  - progression-pattern-analysis
  - permission-concept-generator
  - ideal-aspiration-mindset
  - identity-belief-gap-analyzer
  - toward-usp-generator
  - aspiration-mimetic-intelligence
  - community-architect
---

# Toward Demand Architect

The complete demand creation pipeline for approach-motivated markets. Runs all 10 Toward Markets skills in sequence, passing context between each, and synthesizes the outputs into an integrated demand creation intelligence package.

The difference from demand-architect (avoidance track):
- **demand-architect** excavates pain, diagnoses failure, builds mechanism credibility, closes with urgency
- **toward-demand-architect** maps aspiration, demonstrates possibility, builds identity permission, closes with belonging and life-stage urgency

Same structural sophistication. Completely different emotional architecture.

---

## LAYER 1: INVARIANTS

1. **This pipeline is for approach-motivated markets.** Before running, confirm: are your buyers moving TOWARD something (aspiration, identity, mastery, community) or AWAY from something (pain, failure, frustration)? If primarily avoidance — run demand-architect instead. Mixed markets — note the blend, run this, flag hybrid elements.
2. **The sequence is non-negotiable.** Each skill builds on the previous. Desire mapping before excavation. Excavation before avatar. Avatar before progression patterns. Do not skip steps.
3. **Context carries forward.** The output of each skill is the primary input for the next. Every step refines understanding of the same market — it's one continuous intelligence-building exercise, not 10 separate reports.
4. **Identity Permission is the master constraint.** Everything in this pipeline ultimately serves one question: "What does this market need to believe about THEMSELVES (not the product) for purchase to become inevitable?"
5. **Community Architecture is the culmination, not an afterthought.** After 9 skills building intelligence, Skill 10 synthesizes it all into the product-as-community design. This is where approach-motivated markets reach their full potential.
6. **Save everything to files.** No deliverable exists only in chat.

---

## THE SELLING SEQUENCE

This pipeline maps to the Toward Markets selling sequence:

```
Aspiration       → toward-desire-mapper + aspiration-excavation
                   (What are they moving toward? What's the desire hierarchy?)

Demonstration    → aspiration-avatar-excavation + progression-pattern-analysis
                   (Who is moving toward it? What path do they take?)

Permission       → permission-concept-generator + ideal-aspiration-mindset
                              + identity-belief-gap-analyzer
                   (What do they need to believe about themselves?)

Community        → aspiration-mimetic-intelligence + community-architect
                   (Who are they aspiring to join? How do we design belonging?)

Deepen           → toward-usp-generator (synthesis)
                   (What's the identity promise that pulls them deeper?)
```

---

## MODES

### FULL MODE `/toward-demand-architect full [market]`
Runs all 10 skills sequentially. Complete intelligence package. Use for:
- New market entry
- ZenithPro members building demand creation for a new approach-motivated client
- Neil Maxwell-Keys style analysis where the methodology fit needs to be established

**Time:** 90-120 minutes of focused work. Worth every minute.

### QUICK MODE `/toward-demand-architect quick [market]`
Runs Skills 1, 5, 7, 8, 10 only (desire map → permission concepts → belief gaps → USP → community architecture). Use for:
- Markets already partially researched
- Checking if an existing approach needs Toward Markets calibration
- Time-constrained client work

### AUDIT MODE `/toward-demand-architect audit [existing copy or positioning]`
Reviews existing marketing assets against Toward Markets criteria. Flags where avoidance language has contaminated approach-motivated marketing. Use for:
- Reviewing copy for a client whose market is approach-motivated
- Checking if existing ZenithPro work needs recalibration
- Neil Maxwell-Keys use case: audit existing marketing against Toward Markets framework

---

## EXECUTION PROTOCOL

### Step 0: Market Qualification

Before running any skills, establish:

1. **Motivation direction:** Is this market primarily approach-motivated, avoidance-motivated, or mixed?
   - Approach signals: people talk about who they want to BECOME, share progress/aspiration, community-driven behavior
   - Avoidance signals: people talk about what they want to STOP or FIX, frustrated with past attempts, seeking solutions
   - Mixed: flag the blend ratio (e.g., "70% approach / 30% avoidance") and proceed with Toward Markets, noting where avoidance elements exist

2. **Gather market inputs:**
   - Business/product name and description
   - Target market (demographics + what they're moving toward)
   - Any existing customer research (testimonials, community posts, reviews)
   - Output folder path

3. **Confirm:** "This is an approach-motivated market. Running Toward Markets pipeline."

---

### Step 1: Aspiration Hierarchy Mapping
**Skill:** toward-desire-mapper
**Output:** `Aspiration-Hierarchy-Map-[Market].md`

Run the complete aspiration hierarchy:
- L1 primary desires (approach-weighted)
- Aspiration Stratigraphy (surface/middle/deep)
- L2-L4 belief architecture
- Channel maps
- Gap analysis

**Context to carry forward:** The dominant L1 desire(s), the deep aspiration layer, and the primary identity permission gap.

---

### Step 2: Psychographic Archaeology
**Skill:** aspiration-excavation
**Output:** `Aspiration-Excavation-[Market].md`
**Input:** Aspiration Hierarchy Map from Step 1

Run the 14-phase aspiration excavation:
- Passion triggers
- Identity aspiration landscape
- Skill progression history
- Community needs
- Buying behavior phases

**Context to carry forward:** Passion triggers, skill progression history plateaus, community aspiration profile.

---

### Step 3: Avatar Construction
**Skill:** aspiration-avatar-excavation
**Output:** `Aspiration-Avatar-[Market].md`
**Input:** Steps 1-2 outputs

Build the approach-motivated avatar:
- Aspiration Stratigraphy by avatar
- Identity Aspiration (who they want to become)
- Life Stage Dynamics
- Flow State Mapping
- Community Needs profile

**Context to carry forward:** The 2-3 most distinct avatar segments, their life stage contexts, and their specific identity permission gaps.

---

### Step 4: Progression Pattern Analysis
**Skill:** progression-pattern-analysis
**Output:** `Progression-Landscape-[Market].md`
**Input:** Steps 1-3 outputs

Map the progression architecture:
- Plateau points
- Quit patterns
- Commitment triggers
- Identity adoption timeline
- The Dip analysis

**Context to carry forward:** The primary plateau (where most people get stuck), the primary commitment trigger (what moves people from casual to committed), and the identity adoption timeline.

---

### Step 5: Permission Concept Generation
**Skill:** permission-concept-generator
**Output:** `Permission-Concepts-[Market].md`
**Input:** Steps 1-4 outputs (especially identity permission gaps from Step 1 and progression patterns from Step 4)

Generate 5 Core Concepts across formula types:
- Hidden Unlock
- Permission Shift
- Mastery Bridge
- Right Path
- Identity Invitation

**Context to carry forward:** The 1-2 strongest Permission Concepts (judge by: does it directly address the primary identity permission gap from Step 1?).

---

### Step 6: Ideal Aspiration Mindset Definition
**Skill:** ideal-aspiration-mindset
**Output:** `Ideal-Aspiration-Mindset-[Market].md`
**Input:** Steps 1-5 outputs

Define the buying-ready psychological state:
- Logical Beliefs required
- Emotional Feeling State (anticipation/excitement/belonging)
- Identity Alignment required
- Social Proof Needs

**Context to carry forward:** The complete buying-ready state description. This becomes the target state for Step 7.

---

### Step 7: Identity Belief Gap Mapping
**Skill:** identity-belief-gap-analyzer
**Output:** `Identity-Belief-Gap-Map-[Market].md`
**Input:** Steps 1-6 outputs

Map the complete belief journey:
- Point A: Curious but doubting myself (specific to this market)
- Point B: Ideal Aspiration Mindset from Step 6
- All identity permission gaps in the journey
- Dependency chain (which beliefs must shift first)
- Evidence required for each shift

**Context to carry forward:** The belief gap map and the highest-leverage intervention (the single belief shift that unblocks the most demand).

---

### Step 8: USP Development
**Skill:** toward-usp-generator
**Output:** `Toward-USP-[Market].md`
**Input:** All prior outputs (this is the synthesis point for identity language)

Develop the identity-transformation USP:
- The Feature→Benefit→Promise ladder (identity language)
- Positioning statement ("become the kind of person who")
- Differentiation from solution-language competitors
- Copy applications

**Context to carry forward:** The USP promise statement and the positioning angle.

---

### Step 9: Aspiration Mimetic Intelligence
**Skill:** aspiration-mimetic-intelligence
**Output:** `Aspiration-Mimetic-Map-[Market].md`
**Input:** Steps 1-8 outputs

Map the competitive aspiration landscape:
- Aspirational model mapping (who buyers aspire to BE like)
- Desire chain analysis
- Positioning gap analysis
- Mimetic whitespace

**Context to carry forward:** The aspirational models, the positioning gap (usually: everyone speaks technique, nobody speaks identity), and the mimetic whitespace opportunity.

---

### Step 10: Community Architecture
**Skill:** community-architect
**Output:** `Community-Architecture-[Market].md`
**Input:** All prior outputs (community architect synthesizes everything)

Design the complete tribal architecture:
- Tribal identity design
- Mimetic desire flywheel
- Progression architecture
- Retention mechanics
- Membership economics
- Integration with value ladder

---

### Synthesis: Three Deliverables

After all 10 steps, produce three synthesis documents:

**1. Aspiration Architecture Map** (`Aspiration-Architecture-Map-[Market].md`)
The 1-page strategic overview:
- Dominant aspiration (deep layer)
- Primary identity permission gap
- Strongest Permission Concept
- The buying-ready state definition
- USP promise statement
- Community identity name

**2. Identity Permission Brief** (`Identity-Permission-Brief-[Market].md`)
The tactical execution guide:
- Complete belief gap journey (Point A → Point B)
- Dependency-sequenced belief shifts
- Evidence requirements for each
- Recommended content types and sequence
- Mirror specifications (who to recruit for social proof)

**3. Community Demand Strategy** (`Community-Demand-Strategy-[Market].md`)
The business model document:
- Community architecture overview
- Mimetic flywheel design
- Value ladder integration
- Membership economics projection
- Launch sequence

---

## OUTPUT FOLDER STRUCTURE

All outputs save to the specified project folder:

```
[Project Folder]/Toward-Markets-[Market]/
├── 01-Aspiration-Hierarchy-Map.md
├── 02-Aspiration-Excavation.md
├── 03-Aspiration-Avatar.md
├── 04-Progression-Landscape.md
├── 05-Permission-Concepts.md
├── 06-Ideal-Aspiration-Mindset.md
├── 07-Identity-Belief-Gap-Map.md
├── 08-Toward-USP.md
├── 09-Aspiration-Mimetic-Map.md
├── 10-Community-Architecture.md
├── SYNTHESIS-Aspiration-Architecture-Map.md
├── SYNTHESIS-Identity-Permission-Brief.md
└── SYNTHESIS-Community-Demand-Strategy.md
```

---

## QUALITY GATE

Before delivering synthesis:
- [ ] Every output uses approach language (no avoidance contamination)
- [ ] L4 = Identity Permission in every skill that touches it
- [ ] Aspiration Stratigraphy present and shows meaningful surface/middle/deep differentiation
- [ ] Permission Concepts address the SELF (not the solution)
- [ ] Gap Analysis in every skill recommends mirror intervention, not mechanism explanation
- [ ] Community Architecture is a TRIBAL IDENTITY design, not a content delivery plan
- [ ] USP promise uses "become" language, not "solve" language
- [ ] The three synthesis documents tell a coherent story

---

## HOW THIS CONNECTS

**This is the final skill in the Toward Markets pipeline.** After this:
- Use the Aspiration Architecture Map to brief copywriters
- Use the Identity Permission Brief to build ad creative and content sequences
- Use the Community Demand Strategy to design the membership product architecture
- Compare against demand-architect output to identify hybrid elements (if market has both approach and avoidance motivation)
- Feed into the future hybrid system when that track is built
