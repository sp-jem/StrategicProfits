---
name: progression-pattern-analysis
description: "Maps the progression landscape of an approach-motivated market — where practitioners plateau, what makes casual participants quit vs. go deeper, what separates dabblers from committed practitioners, and the inflection points where identity adoption happens. Replaces failure-pattern-forensics for approach-motivated markets. Part of the ZenithPro: Toward Markets pipeline."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/progression-pattern-analysis [market or avatar description]"
  called_by: [user, toward-demand-architect]
  outputs_to: [project folder]
---

# Progression Pattern Analysis

Maps the complete progression landscape of an approach-motivated market — where practitioners plateau, what makes casual participants quit vs. go deeper, what the inflection points of identity adoption look like, and what the full journey from "tried it once" to "this is who I am" actually involves.

---

## LAYER 1: INVARIANTS

1. **Progression analysis is NOT failure analysis.** This skill maps a journey architecture — the entire arc from first contact to deep identity adoption. It is not forensics on why people quit. Quitting is one data point in a larger trajectory map.
2. **The Dip is a real phenomenon, not a metaphor.** Every skill has a hardest moment. Identify it precisely — at what skill level, what time point, what emotional state — not vaguely as "when it gets hard."
3. **Identity adoption has a timeline and accelerants.** "Becoming a sketcher" is not a feeling — it is a behavioral and self-labeling shift that happens at a specific moment. Map what triggers it and what shortens the path.
4. **Every claim about progression must be grounded in actual market evidence** — reviews, community posts, testimonials, interview data. Not assumed.
5. **The separation between dabblers and committed practitioners is the most strategically important insight in this document.** It tells you who your real buyer is and what they need to cross the line.
6. **Save all outputs to files.** Never deliver analysis only in chat.

---

## PURPOSE

Answers the foundational question that determines whether an approach-motivated market can be converted:

> "What does the journey from 'curious about this' to 'this is part of who I am' actually look like — and where does it break down?"

In avoidance markets, failure pattern forensics maps WHY THINGS DON'T WORK. That produces Core Concepts about the solution.

In approach markets, progression pattern analysis maps HOW COMMITMENT DEEPENS. That produces Permission Concepts about the self — and reveals exactly what your product needs to do to accelerate identity adoption.

**The core insight this skill generates:**

There is always a gap between the people who dabble and the people who go deep. The gap is rarely about talent, time, or money. It is almost always about a specific moment of permission — a moment where someone decides "this is mine to claim." Mapping that moment precisely is the highest-leverage output of this skill.

**Output use:** Feeds directly into permission-concept-generator (which commitment triggers reveal what Permission Concepts must do), identity-belief-gap-analyzer (progression plateaus map directly to belief gaps), toward-usp-generator (USP must promise to shorten or smooth the progression journey), and community-architect (community must be designed around the social conditions that accelerate deepening).

---

## INPUTS

Gather from the user before running:

1. **Market/avatar description** (who they are, what they're being drawn toward, where they are in the journey — beginner, intermediate, returning after a gap)
2. **Practice or skill type** (what specifically they're learning or doing — the more specific, the better: "urban sketching" not just "art")
3. **Any existing community research** — forum posts, Reddit threads, Facebook group discussions, YouTube comment sections, testimonials that reveal progression language
4. **Avatar profiles** (from aspiration-avatar-excavation if run — especially the section on purchase psychology and prior attempts)
5. **Aspiration Hierarchy Map** (from toward-desire-mapper if run — especially Aspiration Stratigraphy, which shows surface/middle/deep aspiration layers)
6. **Output folder path** (ask if not specified — default: project folder for this client/business)

---

## THE SEVEN-PHASE PROGRESSION EXCAVATION

### Phase 1: Plateau Mapping

Map where in the skill or experience arc practitioners consistently lose momentum, get stuck, or stall out without quitting entirely.

A plateau is not a quit point. It is where progress feels invisible, energy drops, and the gap between "where I am" and "who I want to be" feels widest — but the person has not yet decided to leave.

For each significant plateau, document:

**The Plateau Profile:**
- Where in the learning arc it occurs (early: weeks 1-4; middle: months 2-6; advanced: ongoing practitioners)
- What it looks and feels like from the inside ("I keep making the same mistakes," "My progress has stopped," "I feel like I'm going backwards")
- What it looks like behaviorally (buying more materials but not practicing, watching tutorials instead of doing, long gaps between sessions)
- Why it is structurally inevitable at this point in the skill arc (not a character flaw — a natural feature of skill development)
- What percentage of practitioners hit this plateau vs. skip through it

**The Plateau Paradox:**
Every significant plateau contains an internal contradiction — a way in which the plateau is caused by something good, not something bad.

Examples:
- The Urban Sketching Comparison Plateau: happens precisely when their eye develops enough to see the gap between their work and expert work. Better vision creates apparent regression.
- The Music Beginner Plateau: happens when they've learned enough theory to know what they don't know. More knowledge creates more apparent incompetence.

Identify the specific paradox embedded in each plateau. This is the raw material for Permission Concepts.

**Minimum:** Identify 3 distinct plateaus. Describe each with the level of specificity that would make a practitioner say "that is EXACTLY what happened to me."

---

### Phase 2: Quit Pattern Analysis

Identify the 3-5 most common reasons practitioners abandon the practice after starting.

**Critical distinction:** Quit patterns in approach markets are almost never about capability. They are almost always about identity permission, environmental mismatch, or community absence. Document each quit pattern accordingly.

For each quit pattern:

**The Pattern Profile:**
- Name the pattern in language the market uses (not clinical labels)
- Describe what the person tells themselves when they quit (their stated reason)
- Describe what is actually happening structurally (the real reason — usually an identity or environmental issue, not a skill issue)
- Identify when in the progression arc this quit type is most common
- Identify what would have prevented this quit — not more skill instruction, but what environmental, social, or identity intervention would have kept them going

**Stated vs. Actual Reasons Matrix:**

| Quit Type | What They Say | What's Actually Happening | Prevention |
|-----------|--------------|--------------------------|------------|
| [Name] | "I don't have time" | [Real structural issue] | [Actual intervention] |
| [Name] | "I'm not talented enough" | [Real structural issue] | [Actual intervention] |

**The Quit-Prevention Insight:**
For each quit pattern, answer: "What would a product/community/program need to provide to prevent this quit — not at the skill level, but at the identity and environment level?"

These answers directly inform product architecture and community design.

**Language rule:** Never frame quit patterns as failures. They are inflection points where one path (deepening) was available and another path (stepping back) was taken. The goal is understanding what makes the deepening path more accessible — not pathologizing the people who took the other path.

---

### Phase 3: Commitment Trigger Analysis

Identify the specific events, experiences, and moments that cause people to cross from casual to committed.

A commitment trigger is not a decision. It is a specific experience that makes the identity claim feel real and available. After a commitment trigger, something has shifted — they now refer to themselves differently, they invest differently, they talk about the practice differently.

**The Commitment Trigger Taxonomy:**

For approach-motivated markets, commitment triggers typically fall into these categories. Identify which ones operate in this market and which are most powerful:

**1. The Visible Result Trigger**
A specific piece of work they produce that surprises them with its quality. Not just "it was good" — it was good enough that someone else responded to it as if they were a practitioner.
- What does this look like specifically in this market?
- At what skill level does it typically occur?
- What conditions increase the likelihood of this trigger firing?

**2. The Community Belonging Trigger**
A social moment where they feel like they belong with other practitioners — not just welcomed, but seen as one of them.
- What specific interaction creates this? (Another sketcher asks to see their sketchbook. A group invites them to a sketchwalk. A stranger recognizes them as a sketcher.)
- What community structures accelerate this?

**3. The Identity Claim Trigger**
The first time they describe themselves using the practitioner identity to someone outside the practice — unprompted. "I'm a sketcher." "I paint." "I play piano."
- What provokes this? (Someone asks what their hobby is. They introduce themselves at a new venue. They post publicly for the first time.)
- What makes this moment feel safe vs. risky?

**4. The Investment Escalation Trigger**
They spend money on something that only a committed practitioner would buy — a tool, a dedicated space, a course at a level beyond beginner.
- What is the investment that marks the line between dabbler and committed practitioner in this market?
- What precedes this investment — what happened just before they decided to spend it?

**5. The Teaching Trigger**
They explain or demonstrate something to someone less advanced, and the act of teaching makes them realize how far they've come.
- When does this opportunity typically arise?
- What conditions create it?

For each trigger type present in this market:
- Describe exactly what the trigger event looks like
- Identify what produces it (conditions, community structures, specific experiences)
- Rate its power: does this trigger typically produce sustained commitment or just temporary elevation?
- Identify what product architecture or community structure most reliably creates conditions for this trigger

---

### Phase 4: Identity Adoption Timeline

Map the typical timeline from first contact with the practice to the moment someone claims the practitioner identity — and what accelerates or delays it.

**The Standard Timeline:**
For this specific market, construct the typical progression:
- Week 1-2: [Orientation stage — what is happening, what is felt]
- Month 1-3: [Early stage — what is happening, what threatens to derail]
- Month 3-6: [Development stage — what is happening, first plateaus]
- Month 6-12: [Consolidation stage — what is happening, commitment or drift]
- Beyond 12 months: [Integration stage — for those who stay]

For each stage, identify:
- The dominant emotional state
- The dominant doubt or fear
- The most common quit risk
- The most powerful retention factor

**Identity Claim Acceleration Factors:**

What shortens the time to identity claim? Based on market evidence, identify 5-8 specific factors that accelerate identity adoption:

Examples (test against your specific market):
- Having a dedicated space or tool (a sketchbook always in the bag makes the identity portable)
- Being part of a named community ("I'm part of a sketching group" precedes "I'm a sketcher")
- Producing work that gets a real response from a real person
- Finding a teacher whose students look like them demographically
- A specific early win that happens in the first 2-4 sessions (the "I can't believe I made that" moment)
- Participating in a shared event (a sketchwalk, a recital, an open mic) early in the journey

**Identity Claim Delay Factors:**

What lengthens the time to identity claim — or prevents it entirely?
- Comparison to advanced practitioners without demographically similar mirrors
- Practicing in isolation without community feedback
- Framing the practice as "something I'm trying" rather than "something I do"
- Gatekeeping language from experts ("real artists do X")
- The absence of a first public moment

**The Product Implication:**
For each acceleration factor, specify: Can a product, program, or community create this condition deliberately? If yes, how specifically?

---

### Phase 5: Environmental Analysis

Map the environmental conditions — physical, social, temporal, and psychological — that correlate with continued practice vs. drift or abandonment.

**Physical Environment Factors:**
- What physical conditions support sustained practice? (Dedicated space, portable kit, specific location association)
- What physical conditions undermine it? (Practice requiring setup/teardown friction, incompatible living situation, equipment stored out of sight)
- What is the minimum viable environment for this practice?

**Social Environment Factors:**
- What social conditions accelerate deepening? (Practice community, accountability partner, public commitment, social identity reinforcement)
- What social conditions create drift? (Isolation, no feedback loop, social circle that doesn't value the practice, absence of community)
- What is the social baseline that predicts continuation? (Not ideal — baseline. What minimum social reinforcement do practitioners need?)

**Temporal Factors:**
- What practice frequency is the minimum for continuation? (Below this frequency, the skill doesn't feel like it's progressing, and drift begins)
- What time-of-day or week patterns correlate with sustained practitioners vs. dabblers?
- What are the seasonal or life-event disruptions most likely to break the habit — and what gets people back after a break?

**Psychological Environment Factors:**
- What internal permission does the practitioner need to keep going? (Permission to produce imperfect work, permission to take it seriously, permission to invest resources)
- What internal voices most commonly undermine continuation? (Compare these to the identity permission gaps from toward-desire-mapper)
- What psychological anchors do sustained practitioners report? (Specific beliefs or framings that keep them going through plateaus)

**The Environmental Profile of a Sustained Practitioner:**

Synthesize the above into a composite environmental profile: "A person who stays with this practice for 12+ months typically has [X physical conditions], [Y social conditions], [Z temporal conditions], and [W internal permissions]."

This profile tells you what your product must create or reinforce.

---

### Phase 6: Progression Ladder

Map the natural progression from complete beginner to advanced practitioner in this specific domain.

The progression ladder is not a curriculum. It is an empirical map of how skill and identity actually develop in this market — what people can do at each level, how they describe themselves, what they invest, and what they want next.

**Level 1: The Curious Beginner**
- Skill markers: [What they can and cannot do]
- Identity markers: "I'm trying [practice]" / "I want to learn [practice]"
- Investment: [Time, money, attention]
- What they want most: [Permission to start / to feel capable / to belong]
- What threatens them here: [Comparison, early failure, complexity overwhelm]

**Level 2: The Developing Practitioner**
- Skill markers: [What they can and cannot do]
- Identity markers: "I do [practice]" / "I've been [practicing] for a few months"
- Investment: [Time, money, attention]
- What they want most: [Progress they can see / feedback / community connection]
- What threatens them here: [Plateau, comparison to experts, isolation, The Dip]

**Level 3: The Committed Practitioner**
- Skill markers: [What they can and cannot do]
- Identity markers: "I'm a [practitioner]" / "This is part of my life"
- Investment: [Time, money, attention — notably higher than Level 2]
- What they want most: [Refinement / community leadership / deeper expression]
- What threatens them here: [Stagnation at a ceiling, loss of community, life disruption]

**Level 4: The Advanced/Teaching Practitioner** (if relevant to this market)
- Skill markers: [What they can and cannot do]
- Identity markers: "I teach [practice]" / "I've been [practicing] for [years]"
- Investment: [Time, money, attention — may be earning from it]
- What they want most: [Mastery / legacy / teaching opportunity / peer community]
- What threatens them here: [Identity crisis if the practice changes, teaching plateau]

**The Level Transition Points:**
For each level transition, identify:
- What specifically triggers the move from one level to the next (not just "they got better" — what specific event or experience marks the shift)
- What makes the transition risky (what can pull someone back rather than forward at this juncture)
- What product or community support is most valuable at this transition

---

### Phase 7: Dip Analysis

Every skill has a hardest moment. Map it precisely.

Seth Godin's Dip is the point in any learning curve where progress feels invisible, the gap between current ability and desired ability is widest, and the temptation to quit is highest. It is also the point that separates people who eventually go deep from people who drift away.

**The Dip Location:**
- At what skill level does the primary Dip occur in this market?
- At what time point (weeks/months into the practice)?
- What does it feel like from the inside?
- What does it look like behaviorally to observers?

**The Dip Anatomy:**
Describe the Dip in concrete terms specific to this practice:
- What can they do at this point? (More than beginners, but feels inadequate)
- What can they NOT do yet? (The gap that makes progress feel invisible)
- What comparison typically triggers the Dip? (Comparing to what? Whom?)
- What do people tell themselves inside the Dip? (The specific internal narrative)

**What Gets People Through:**

Identify the specific factors that separate people who get through the Dip from people who don't. This is not a generic "they persevere" answer — it is specific:

- A specific social structure (accountability, community, cohort)
- A specific reframe about the Dip itself (knowing it is normal, knowing it is finite)
- A specific milestone or visible result that arrives just in time
- A specific teacher or guide who normalizes the experience
- A specific environmental condition (dedicated practice space, protected time)

**What Makes People Quit at the Dip:**
- The specific absence that makes quitting feel like the reasonable choice
- The specific comparison that makes continuing feel futile
- The specific narrative that frames quitting as wisdom rather than retreat

**The Product Dip Design Implication:**
Based on this analysis, answer: What should a product or program do at this specific moment in the student journey to ensure the highest percentage of students make it through the Dip?

---

## OUTPUT SPECIFICATION

Save to the specified output folder:

**File: `Progression-Landscape-Map-[Market].md`**

Structure:
1. Executive Summary (3-4 sentences: primary plateau, the Dip, key commitment trigger, the profile of someone who goes deep)
2. Plateau Map (3+ plateaus with full profiles including the Paradox for each)
3. Quit Pattern Analysis (3-5 patterns with Stated vs. Actual Reasons Matrix)
4. Commitment Trigger Analysis (all relevant trigger types with conditions and product implications)
5. Identity Adoption Timeline (stage-by-stage with acceleration and delay factors)
6. Environmental Profile of the Sustained Practitioner
7. Progression Ladder (all relevant levels with transition point analysis)
8. Dip Analysis (precise location, anatomy, what gets people through, product design implication)
9. Strategic Implications for downstream work

**Target length:** 2,000-4,000 words. Specificity over comprehensiveness — one perfectly described plateau is worth more than five vague ones.

**Language rule:** NEVER use avoidance language (pain, frustration, failure, broken, stuck, struggling) unless explicitly describing what practitioners experience from their own perspective. This document describes a journey with hard parts — it does not pathologize the journey or the people on it.

---

## QUALITY GATE

Before saving, verify:

- [ ] Every plateau is described with enough specificity that a practitioner would say "that is exactly what happened to me" — not "that sounds familiar"
- [ ] The Dip Analysis identifies a specific moment, not a general difficult period
- [ ] Quit Pattern Analysis distinguishes stated reasons from actual structural reasons for each pattern
- [ ] At least 3 Commitment Triggers are identified with specific conditions and product implications
- [ ] Identity Adoption Timeline includes both acceleration AND delay factors
- [ ] Environmental Profile is specific enough to inform product and community design
- [ ] Progression Ladder identifies transition triggers, not just level descriptions
- [ ] Strategic Implications point toward product architecture, community design, and Permission Concept content — NOT toward mechanism education or failure analysis
- [ ] Output reads as structurally different from a failure-pattern-forensics report — no enemy diagnosis, no false belief architecture, no graveyard inventory

---

## STRATEGIC IMPLICATIONS TEMPLATE

The final section must answer these questions:

1. **What is the primary Dip this market faces, and what does a product need to do to get students through it?**
2. **What is the highest-leverage commitment trigger in this market, and how can a product reliably create conditions for it to fire?**
3. **What environmental conditions are most predictive of a student going deep — and which of those can a product or community create?**
4. **What does the profile of the ideal student look like — not demographically, but in terms of where they are in the progression arc?** (This informs targeting, positioning, and enrollment criteria.)
5. **What is the single most powerful Permission Concept this progression landscape suggests is needed?** (The plateau paradox and Dip anatomy should point directly to a specific identity permission reframe.)
6. **What does the community design need to provide at the critical transition points?** (Feeds community-architect directly.)

---

## HOW THIS CONNECTS DOWNSTREAM

- **permission-concept-generator** → Plateau paradoxes and Dip anatomy are the primary raw material for Permission Concepts. The commitment trigger analysis reveals what identity shifts must happen and when.
- **identity-belief-gap-analyzer** → Progression plateaus map directly to belief gaps. The environmental profile reveals which beliefs must change for someone to create the right conditions for deepening.
- **toward-usp-generator** → The USP must promise to shorten or smooth the progression journey — specifically, to accelerate commitment triggers and reduce Dip severity.
- **community-architect** → Community design must be built around the social conditions that accelerate identity adoption and buffer against the Dip. The environmental analysis is the primary input.
- **aspiration-avatar-excavation** → The Progression Ladder levels map to distinct avatar segments with different aspiration intensities and different identity permission gaps.
- **toward-desire-mapper** → Confirms or expands the Aspiration Stratigraphy — progression patterns reveal which layer of aspiration is active at each level of the ladder.
