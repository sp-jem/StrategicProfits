$Skills = @("toward-desire-mapper", "aspiration-excavation", "aspiration-avatar-excavation", "progression-pattern-analysis", "permission-concept-generator", "ideal-aspiration-mindset", "identity-belief-gap-analyzer", "toward-usp-generator", "aspiration-mimetic-intelligence", "community-architect", "toward-demand-architect")
Write-Host "Installing ZenithPro Toward Path (11 skills)..."
$Success = 0; $Failed = 0
foreach ($Skill in $Skills) {
  $InstallDir = "$env:USERPROFILE\.claude\skills\$Skill"
  New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
  Copy-Item "$Skill\SKILL.md" "$InstallDir\SKILL.md"
  if (Test-Path "$InstallDir\SKILL.md") { Write-Host "✅ $Skill"; $Success++ }
  else { Write-Host "❌ $Skill"; $Failed++ }
}
Write-Host "Installed: $Success / 11 | Run: /toward-demand-architect full [your market]"
