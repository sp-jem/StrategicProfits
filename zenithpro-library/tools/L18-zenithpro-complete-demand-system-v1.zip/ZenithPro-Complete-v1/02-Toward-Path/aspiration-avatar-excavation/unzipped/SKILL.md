---
name: aspiration-avatar-excavation
description: "Multi-dimensional forensic reconstruction of approach-motivated avatar segments. Built around identity aspiration and life-stage context — who they want to BECOME, what life transition they're in, what flow states they seek, what community belonging means to them. Replaces pain stratigraphy with aspiration stratigraphy, shadow work with identity aspiration, somatic fear with flow state mapping. Part of the ZenithPro: Toward Markets pipeline."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Toward-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/aspiration-avatar-excavation [market or business]"
  called_by: [user, toward-demand-architect]
  outputs_to: [project folder]
---

# Aspiration Avatar Excavation

Forensic reconstruction of complete human psyches for approach-motivated markets. Not persona development — archaeological revelation of who these avatars are reaching toward becoming, what life stage they're navigating, and what identity transformation they need permission to believe is possible.

---

## LAYER 1: INVARIANTS

1. **Psychological complexity over clean profiles.** Real humans are contradictory. Avatars built around aspiration still carry doubt, suppression, and permission barriers. Build both.
2. **Specific over general.** Not "they want to create" — "at 7pm when the house is quiet and she finally sits down with her sketchbook, the specific thought that runs is..."
3. **Identity aspiration is mandatory.** These avatars are built around WHO THEY WANT TO BECOME, not what problem they're escaping. Never let avoidance framing infiltrate the core analysis.
4. **Each avatar must receive equal depth.** Never shortchange the 3rd or 4th avatar.
5. **Save all outputs to files.** Never deliver in chat only.
6. **NEVER use avoidance language.** Pain, frustration, failure, broken, stuck, struggling — eliminated throughout except in direct market quotes.

---

## PURPOSE

These avatars are so complete that you could:
- Ghost-write their private journal for 365 days, including entries about why they almost didn't start and what changed
- Predict their response to a teacher's Instagram post, a course sales page, a community invitation
- Script their internal dialogue the moment they hand over their credit card for a learning investment
- Design offerings that feel telepathically built for exactly where they are in their life
- Write content that makes them feel professionally understood — like someone finally sees what they're really reaching for

**Output use:** Becomes the human foundation for all messaging, content, offers, and community design in approach-motivated markets.

**Mental test case throughout:** Women 55+ learning urban sketching (the Neil Maxwell-Keys / Ian Fennelly market). Would this avatar ring completely true for someone in that market? If yes, proceed. If not, recheck.

---

## INPUTS

1. **Website URL** (analyze the business offering first if available)
2. **Market/industry description** (2-3 sentences)
3. **Number of avatars to generate** (3-5 — specify or default to 3)
4. **Aspiration excavation data** (paste output from aspiration-excavation if already run)
5. **Desire hierarchy map** (paste output from toward-desire-mapper if already run)
6. **Output folder path**

---

## PHASE 1: MARKET ECOSYSTEM ANALYSIS

### Website Archaeology (if URL provided)
Forensically analyze the website to:
- Decode the identity transformation promise embedded in the offering
- Extract the psychological contracts being proposed (what identity will the student inhabit after?)
- Identify what kind of person this business helps someone become — explicitly and implicitly
- Reveal the hidden aspiration transaction beneath the course content or features
- Uncover the existential question the business answers ("Can someone like me actually become this?")

### Market Stratification
Dissect the market into 3-5 distinct aspiration segments:
- Map aspiration intensity levels (curious → interested → committed → deeply identified)
- Identify the life stage dynamics creating the aspiration window for each segment
- Decode the market's shared aspirational mythology (the stories that circulate about transformation)
- Reveal the identity permission hierarchy — who has "arrived" and who is still asking if they're allowed
- Extract the transformation archetypes: the late bloomer, the returning creator, the life-stage reinventor, the identity seeker

---

## PHASE 2: AVATAR CONSTRUCTION PROTOCOL

For EACH of the 3-5 avatars, execute the full 11-section excavation below.

---

### SECTION A: DEMOGRAPHIC ARCHITECTURE

**Surface Demographics (with life-stage depth):**
- Age range — include the generational experiences and cultural moments that shaped this cohort's relationship with creativity, learning, and permission
- Geographic psychology — how location shapes access to community and legitimacy signals
- Income reality — the gap between what they can invest and what they believe they're worth investing in
- Education background — how formal education shaped their beliefs about whether they're "the kind of person" who learns things like this
- Occupational identity — how their professional self-concept intersects with their aspiration (relief valve vs. identity expansion vs. late-career reinvention)

**Life Stage Context:**
- The specific life transition creating the aspiration window (empty nest, retirement, health shift, career change, loss, recovery, newfound time)
- What has opened up that wasn't available in previous chapters
- What they have NOW that younger learners don't (patience, perspective, life experience to draw from, financial stability, time intentionality)
- The relationship between this life stage and why the aspiration feels both urgent and accessible right now

**Hidden Demographics:**
- What they compulsively consume in this aspiration space (specific YouTube channels, Instagram accounts, books, podcasts)
- The version of this aspiration they tried before and abandoned — and why
- The "someday" fantasy they've carried for years that is finally getting space
- The identity they publicly claim vs. the identity they secretly aspire toward

---

### SECTION B: PSYCHOGRAPHIC EXCAVATION

**Core Values Architecture** — not what they CLAIM to value, but:
- The LIFE EXPERIENCE that crystallized each core value
- The CHOICE that made this value a non-negotiable part of their identity
- The places where their values around creativity, learning, and community are FULLY EXPRESSED vs. suppressed
- The VALUE they claim (practicality, responsibility) that quietly wars with the VALUE they hunger for (expression, beauty, creation)
- The INTERNAL PERMISSION they need before they can act on the aspiration without guilt

**Identity Archaeology:**
- The story they tell themselves about who gets to pursue this aspiration (and whether that includes them)
- The story they can't tell — the version that includes the attempts, the doubts, the "I used to be creative" grief
- The identity they're protecting (the responsible adult, the practical person, the one who puts others first)
- The identity they're becoming (the artist, the maker, the learner, the person with a practice)
- The specific identity claim they want to make but feel they haven't earned yet: "I'm an artist," "I'm a musician," "I paint"

**Belief System Forensics:**
- Inherited beliefs about who gets to be creative (talent myth, age myth, training myth)
- Protective beliefs created from early experiences with creative judgment
- The invisible ceiling they accept: "I can enjoy it, but I'll never be really good"
- The emerging belief trying to break through: "Maybe process matters more than output. Maybe it's not too late."

---

### SECTION C: ASPIRATION STRATIGRAPHY

The aspiration architecture for approach-motivated avatars has layers — and real purchase decisions live at the deepest layer. Mapping all three is essential.

**Layer 1 — Surface Aspiration:** What they'll tell anyone when asked
- "I've always wanted to learn to draw / play piano / speak Italian"
- Low vulnerability, easy to say, doesn't require permission
- Surface aspiration language: "It looks fun," "I thought I'd try it," "I saw a class and signed up"

**Layer 2 — Identity Aspiration:** What they'll admit when there's trust
- "I want to be someone who makes things"
- "I want to actually be able to call myself a ___"
- "I want something that's just mine — that I'm building for myself"
- Moderate vulnerability, requires genuine conversation or community depth to surface
- Identity aspiration language: "I've always considered myself creative but never had an outlet," "I want to prove to myself I can do this"

**Layer 3 — Deep Aspiration:** What drives the real purchase decision
- "I want to feel like I'm using this chapter of my life for something meaningful"
- "I want to create something that outlasts me"
- "I want to be part of something — a community of people who make things, where I belong"
- "I want to feel like the person I always thought I was — or could be"
- High vulnerability, rarely stated publicly, drives deepest buying motivation
- Deep aspiration language: often about legacy, purpose, belonging, time well used, identity actualization

For each avatar, identify all three layers with specific language and evidence. The strategic implication: content that reaches Layer 3 converts. Content that stays at Layer 1 collects browsers.

---

### SECTION D: IDENTITY ASPIRATION

*(Replaces Shadow Work from avoidance-motivated frameworks.)*

This section excavates the version of themselves these avatars secretly want to become through the pursuit of this aspiration — and what prevents them from giving themselves full permission.

**The Identity They're Reaching Toward:**
- The specific self-concept they want to inhabit: "I'm someone who paints," "I'm a person with a creative practice," "I'm an artist"
- What that identity would enable them to say, do, or feel about themselves
- The people they most admire in this space — and what it is about their identity, not just their skill, that they're drawn to
- The social permission they want: to be someone others think of as creative, as someone who makes things, as having a real practice

**The Permission Barriers:**
- The explicit self-prohibitions: "Real artists start young," "I don't have formal training," "I'm not talented enough to call myself that"
- The implicit wait conditions: "When I reach X level, THEN I can say it"
- The identity occupants they're comparing to: the person who went to art school, the natural talent, the person who's done it for decades
- What it would take for them to feel they'd genuinely earned the identity claim

**The Identity Expansion Story:**
- Who in this market has made the leap from "I'm someone who tries this" to "I'm someone who does this" — and what shifted?
- What was the specific moment, output, or community recognition that moved them?
- What would the same shift look like for THIS avatar?

**The Suppressed Aspiration:**
- The version of this identity they want but feel embarrassed to admit wanting (selling work, being known for something, having other people genuinely admire what they've made)
- The aspiration that feels too big or too pretentious to name out loud
- What permission would look like if someone genuinely granted it to them

---

### SECTION E: FLOW STATE MAPPING

*(Replaces Somatic Fear Signatures from avoidance-motivated frameworks.)*

This section maps the embodied experience of deep engagement and absorption for this avatar — what flow feels like, when it happens, and how marketing can connect to that experience.

**Flow State Signatures:**
- WHERE absorption feels like in their body: the quality of attention, the loss of time, the specific physical sensation of being fully engaged with the skill
- HOW they describe the experience of being in flow with this activity — their own language for it
- WHEN flow happens: what conditions (time of day, physical environment, level of skill, mood) make deep absorption possible
- What they feel immediately AFTER a flow session: specific emotional and physical language

**Absorption Patterns:**
- The specific techniques, materials, or challenges that most reliably produce absorption for this avatar
- What pulls them OUT of flow — the internal critics, the comparisons, the perfectionism that interrupts
- How their flow state experience has changed as they've developed skill (does it come more easily? more deeply? with different triggers?)

**The Flow Promise:**
- The marketing implication: for approach-motivated markets, flow state is often the real product. What they're buying is access to this experience — reliably, repeatedly, skillfully.
- What the teacher/program/community does that makes flow more accessible for this avatar specifically
- How their flow experience differs from what they've experienced with other learning resources (or what they imagine it would feel like with the right approach)

**Body Intelligence in Learning:**
- WHERE success registers physically for this avatar when they make something they're proud of
- HOW progress feels in their hands, their attention, their confidence
- WHAT their body does when they're in the zone vs. when they're trying to force it

---

### SECTION F: LIFE STAGE DYNAMICS

*(Replaces Temporal Trauma from avoidance-motivated frameworks.)*

This section maps the specific life stage transition this avatar is navigating and how it intersects with the aspiration window — why NOW is when this aspiration becomes actionable.

**The Transition Creating the Window:**
- The specific life stage shift: empty nest, retirement (approaching or arrived), major health event that reordered priorities, career completion or pivot, loss that opened space for reinvention, relationship change
- What this transition has taken away (demands, obligations, the identity built around them)
- What it has opened up (time, permission to prioritize self, the "finally" feeling)
- How the transition changed their relationship to this aspiration — from someday to now

**Life Stage-Specific Assets:**
- What they bring to this aspiration at this life stage that younger starters don't have: accumulated visual literacy, life experience to draw from, patience, financial capacity, freedom from performance pressure, clear sense of what they actually want
- The specific advantages of starting NOW vs. starting earlier
- How their relationship to time has shifted: urgency (not enough left to waste) and abundance (fewer obligations competing for it)

**The Clock Dynamics:**
- The sense of urgency that makes NOW feel meaningful: "If not now, when?"
- The freedom from external validation that often comes with life stage maturity: making this for themselves, not for anyone's approval
- The window of opportunity this life stage opens — and what would close it

**Future Projection for This Life Stage:**
- The version of themselves at 70 (or 80) who looked back and did this — what does that feel like?
- The version who didn't — what does that feel like?
- The aspiration they're building toward that will compound over the years ahead

**Daily Rhythm in This Life Stage:**
- The specific time of day when the aspiration gets space: the quiet morning before anyone's up, the evening after the house empties, the afternoon now that there's no schedule to serve
- The environment they create for this practice
- How the rhythm of this pursuit fits into the texture of their current life

---

### SECTION G: COMMUNITY NEEDS

*(Replaces Relational Damage from avoidance-motivated frameworks.)*

This section maps what belonging means to this avatar in the context of the aspiration — what community they're hoping exists on the other side of purchase, and what that community would need to look and feel like.

**The Tribe They're Hoping to Find:**
- What kind of people do they want to belong with? (Not just demographics — values, attitude toward learning, relationship to the craft, how they talk about their work)
- What would their ideal community sound like in conversation? What would the tone be?
- What do they most want other members to understand about them and where they are in their journey?

**The Belonging They Haven't Had:**
- What community experiences in this space have felt wrong or alienating? (Too competitive, too advanced, too focused on output over process, too intimidating, too performance-oriented)
- The community they've witnessed from the outside that felt like "those people" — the ones they assumed weren't for them
- What would need to be different for them to feel like they genuinely belong

**The Identity Mirror They Need:**
- The specific demographic, life stage, and starting point they need to see reflected in other community members: someone their age, starting where they started, now making things they genuinely admire
- Why this mirror is the most powerful proof in approach markets — it answers "Is this identity available to someone like me?" more powerfully than any testimonial about the course content
- What the "before" of that mirror needs to look like for it to work: specific enough to feel like seeing themselves

**What Belonging Would Give Them:**
- The specific permission that comes from being around others who are doing this without apology
- The accountability and momentum that comes from a community of practice
- The identity reinforcement: being around people who call themselves artists/musicians/writers makes it easier to claim that identity for yourself
- The social experience they're building this aspiration around — not just skill but connection

**Community Red Lines:**
- What would immediately make them feel unwelcome, inferior, or like they'd made a mistake joining
- The dynamics they've experienced in other communities that made them leave or lurk without engaging
- What they need from an instructor's relationship to the community: presence, warmth, non-judgment, genuine interest in beginning learners

---

### SECTION H: DECISION NEUROSCIENCE DECODING

**Information Processing Style:**
- Deletion: What they literally screen out in marketing (jargon, prodigy stories, competitive framing, pain-focused language)
- Distortion: How they interpret teacher confidence as evidence that the teacher won't understand a true beginner
- Generalization: The rules they've created from past learning experiences ("courses always sit unwatched," "online learning can't teach real skill")
- Meta-Programs: Toward/away, internal/external reference, possibility/necessity — how these manifest specifically in approach-motivated buying

**Purchase Psychology for Approach Markets:**

Pre-Purchase State:
- The emotional condition required for purchase readiness: not desperation but genuine belief that this version of themselves is possible
- The mental story they must tell themselves: "I'm serious enough about this to invest. This teacher understands people like me. I can actually do this."
- The social permission they sometimes need: "Other people like me have done this. It's not irresponsible to spend on this."
- The identity shift that precedes transaction: moving from "someone who has always wanted to do this" to "someone who is actually doing this"

Purchase Moment Archaeology:
- The specific proof that unlocks commitment: usually a mirror testimonial or a demonstration that makes "I could do that" feel viscerally real
- The emotional tone that creates safety: warmth, non-judgment, evidence that the teacher has taught true beginners successfully
- The demonstration that bypasses logical resistance: watching someone like them make something beautiful
- The guarantee or risk reversal framing that actually lands for this avatar specifically

Post-Purchase Psychology:
- The specific anxiety that surfaces immediately after buying: "Will I actually follow through? Have I wasted money again?"
- The validation they need in the first 24-48 hours to feel they made the right decision
- The first win that creates the momentum to continue — and what it needs to be (small, achievable, genuinely satisfying)
- The milestone that creates the identity shift from "I bought a course" to "I'm someone who does this"

---

### SECTION I: TRANSFORMATION ARCHITECTURE

**Current State: A Day in Their Aspiration Life** (with specific times):
- Morning: The moment when the aspiration surfaces — the Instagram post that catches their attention, the sketchbook on the shelf, the piano they walk past
- Afternoon: The space opening in their day that used to be filled with obligations that are less pressing now
- Evening: The quiet hour that has always felt like it should belong to something — and what happens in that hour currently
- Night: The specific thought that runs when they imagine themselves having actually built this practice

**The Aspiration Architecture:**
- The version of themselves they most consistently return to imagining: what are they doing, where, what does the output look like, who sees it
- The internal conversation they have with themselves about whether to actually start or continue: what holds them back, what pulls them forward
- The specific "not yet" conditions they set for themselves and what it would take to dissolve them

**Future State Vivification** (sensory detail):
- Their transformed practice — what a routine Tuesday evening looks like when this aspiration is a real part of their life
- The identity experience: what it feels like to say "I paint" or "I play" or "I write" without the immediate internal qualifier ("...badly" or "...just for fun" or "...I'm not really that good")
- The community experience: what it feels like to be around others who are doing this at the same level, same life stage, same spirit
- The specific output they imagine having made: the sketchbook filled with a city they love, the song they can play through, the piece they'd actually hang somewhere

---

### SECTION J: OBJECTION ARCHAEOLOGY

**Surface Objections** (what they'll say to avoid commitment):
- "I don't have enough time" = I'm not sure I'm serious enough to prioritize this
- "I'm not talented enough to get real results" = I don't have identity permission to expect that outcome
- "I've bought courses before and never finished them" = I don't trust myself to follow through
- "I'm too old to really get good at this" = I'm not sure this identity is available to someone at my life stage

**Identity Permission Objections** (what they won't say but feel):
- "What if I invest in this and it confirms I don't have what it takes?"
- "If I go all-in and still can't do it, I lose the dream version of myself"
- "People at my age don't become real artists/musicians/writers"
- "The real learners in this space are 30 years younger than me and I'll just feel embarrassed"

**Objection Architecture for Approach Markets:**
- The mirror that makes the identity objection irrelevant (show them someone their age, their starting point, their life stage who made it)
- The reframe that dissolves the talent objection (it was never about talent — it's about process, which is teachable)
- The first-win design that dissolves the follow-through objection (make the first meaningful result come fast enough to create momentum)
- The community proof that dissolves the belonging objection (here's who else is in this — and they look like you)

---

### SECTION K: MARKETING INTEGRATION SYNTHESIS

**Language That Lands:**
- The verbs that activate their aspiration (create, build, develop, explore, make, discover)
- The identity phrases that feel true before they've earned them ("people who paint" vs. "painters" — which feels like permission vs. which feels like a false claim)
- The questions that crack them open without making them defensive: "What would you make if you knew you had the skill?"
- The metaphors that explain their aspiration in terms they recognize: beginner's mind, late bloomer, practice over performance

**Content Architecture Blueprint:**

Awareness Stage: Content that makes the aspiration feel legitimate and available — not just in theory but for people who look like them. Mirror neuron content: watch someone their age, their demographic, making something beautiful with the teacher's guidance. The "I could do that" moment.

Consideration Stage: Process transparency that dissolves intimidation — seeing how the skill is built step by step, what it looks like to genuinely start from nothing, the teacher's relationship to beginners. Community glimpses that answer "would I belong there?"

Decision Stage: The mirror testimonial that is so demographically specific it reads like the prospect's own future story. The demonstration that produces the visceral "I could do that" feeling. The guarantee that removes the identity risk. The community invitation that makes belonging feel possible.

---

## PHASE 3: SYNTHESIS & ACTIVATION

After all avatars are built:

1. **Avatar Overlap Analysis:** Where all avatars share common aspiration layers, identity permission barriers, or community needs — this is where universal messaging works
2. **Avatar Distinction Map:** What makes each segment unique and requires different mirrors, different demonstrations, different community framings
3. **Avatar Journey Intersections:** Where different avatars converge in the funnel (often at the community level — different segments, same tribe)
4. **Avatar Language Matrix:** Specific language that resonates with each segment — and what to avoid (competitive framing for some, "beginner" framing for others who've already been studying)
5. **Avatar Mirror Specifications:** For each avatar, the exact demographic profile of the social proof that would most powerfully shift their identity permission: age, life stage, starting point, life context, and transformation achieved

---

## OUTPUT SPECIFICATION

**File: `Aspiration-Avatar-Excavation-[Market]-[Avatar Name].md`** (one file per avatar)

Plus: **`Aspiration-Avatar-Synthesis-[Market].md`** (the integration document)

Each avatar file includes all 11 sections. The synthesis file covers all 5 integration points.

**Target length per avatar:** 2,000-4,000 words. This is forensic reconstruction of who people want to become, not marketing copy.

**Language rule:** NEVER use pain, frustration, failure, broken, stuck, struggling in the skill's own voice. Quotes may contain whatever language the market uses. The narrative frame is always aspiration, possibility, identity, and permission.

---

## QUALITY GATE

- [ ] Each avatar has all 11 sections complete
- [ ] Aspiration Stratigraphy (Section C) shows meaningfully different content at surface/middle/deep layers — not three paraphrases of the same aspiration
- [ ] Life Stage Dynamics (Section F) is specific to this avatar's actual life transition — not generic
- [ ] Flow State Mapping (Section E) includes embodied, sensory language — not abstract descriptions of engagement
- [ ] Community Needs (Section G) specifies the exact mirror demographic for this avatar's identity permission shift
- [ ] Identity Aspiration (Section D) includes the suppressed aspiration — what they want but won't say out loud
- [ ] Both surface AND identity permission objections in Section J
- [ ] Avatar synthesis document created
- [ ] Zero avoidance language in the skill's own voice
- [ ] Saved to files

---

## HOW THIS CONNECTS DOWNSTREAM

- **permission-concept-generator** → Each avatar's identity permission barriers become the Core Concept targets — the paradigm shifts that make identity available
- **identity-belief-gap-analyzer** → Aspiration Stratigraphy + Identity Aspiration + Decision Neuroscience feed the full belief gap map for each segment
- **toward-usp-generator** → Avatar Language Matrix + suppressed aspirations + community needs feed USP development
- **aspiration-mimetic-intelligence** → Avatar mirror specifications feed the mirror search — finding real people whose stories would create permission for each segment
- **community-architect** → Community Needs section directly feeds community design: what the tribe looks like, what belonging requires, what the onboarding experience must do
- **content-strategy** → Transformation Architecture (Section I) feeds content that shows the before and the possible, with the specific sensory detail that makes it feel real
- **toward-demand-architect** → These avatar profiles are the human foundation for the entire demand creation pipeline
