# Click Architects — 85 Page-Conversion Skills

A complete skill family that puts **12 of the greatest minds in getting people to act on a web page** inside your Claude Code — and a master orchestrator that runs all of them on any page and hands you the prioritized moves to lift the click.

These are the people who built the science and practice of the click: **Fitts** (the motor cost of a click), **Hick** (the cost of every added choice), **Pirolli & Card** (information scent — why a link gets clicked or abandoned), **Nielsen & Pernice** (where eyes actually land), **Norman** (affordances & feedback), **Gigerenzer** (designing with mental shortcuts), the **Eisenberg brothers** (persuasion architecture), **Goward** (the LIFT model), **Kohavi** (trustworthy A/B testing), **Laja** (ResearchXL), **Eyal** + **Skinner** (habit & reward loops), and **Brignull** (the ethics line / dark patterns).

**85 skills total** = 12 thinkers × (6 tools + 1 field-intelligence synthesizer) + 1 master orchestrator (`click-architects`).

---

## Install (2 minutes)

You already run the same Claude Code system Rich uses, so this just drops the skill folders into `~/.claude/skills/`.

1. Unzip the file.
2. **Double-click `install.command`.** (If Mac says it's from an unidentified developer: right-click → Open → Open. Or open Terminal and run `bash install.sh`.)
3. Restart Claude Code.

**The installer is safe.** It copies each skill into `~/.claude/skills/` and **skips anything you already have** — it will never overwrite one of your existing skills.

---

## How to use it

**Run the whole council on a page:**
```
/click-architects
```
Give it a page (URL, screenshot, or description) + the ONE action you want (click buy, opt in, book a call). It runs all 12 thinkers and returns the ranked **Top Moves** to maximize that action, the convergence stack (where multiple thinkers agree), the single highest-leverage move, and an ethics check.

**Run one thinker's full read:**
```
/fitts-field-intelligence
/pirolli-field-intelligence
/eisenberg-field-intelligence      (…and so on for all 12)
```

**Run a single surgical tool:**
```
/fitts-primary-action-dominance-scorer
/pirolli-scent-trail-auditor
/hick-option-pruning-auditor
/brignull-dark-pattern-scanner
```

Every skill takes the same input: **a web page + the one action you want a visitor to take.** It returns that thinker's specific diagnosis and the concrete on-page changes that lift the action.

---

## The 9 mechanism groups

1. **Click & Choice Cost** — Fitts, Hick
2. **Information Scent** — Pirolli & Card
3. **Attention Topography** — Nielsen & Pernice
4. **Affordance & Friction** — Norman
5. **Cognitive Fit** — Gigerenzer
6. **Persuasion Architecture** — Eisenberg, Goward
7. **Experimentation Rigor (Proof)** — Kohavi, Laja
8. **Habit & Reward Loops** — Eyal (+ Skinner)
9. **Ethics Boundary** — Brignull

---

*Built by Strategic Profits · Click Architects Series · v1*
