---
name: hick-default-path-designer
description: Use when a page's primary action competes with alternatives, friction-points, or blank form fields — diagnoses response-uncertainty entropy and pre-selects the good-enough default so the easy choice IS the desired choice.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "William Hick & Ray Hyman (Hick 1952, Hyman 1953; Hick-Hyman Law + Hyman Entropy Extension + Stimulus-Response Uncertainty Split) — Click Architecture (Skill 6 of 7)"
interface:
  invoke: "/hick-default-path-designer"
  calls: []
  called_by: [user, hick-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "CTA count, form fields, and pricing tiers change with product releases; entropy baselines drift within one sprint cycle."

hick_single_decision_enforcer_integration:
  feeds_from: hick-single-decision-enforcer
  feeds_to: hick-default-path-designer
  shared_data: "n-count per decision zone; single-decision enforcer identifies zones with competing CTAs; default-path designer pre-selects the winning option and sets zero-effort accept state."

iyengar_choice_set_auditor_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: hick-default-path-designer
  shared_data: "Iyengar produces the pruned option set (jelly-jar principle); default-path designer takes that set and marks the pre-selected winning option within it."

thaler_field_intelligence_integration:
  feeds_from: thaler-field-intelligence
  feeds_to: hick-default-path-designer
  shared_data: "Thaler's default-architecture and status-quo bias findings reinforce pre-selection; share default-field values and nudge placement coordinates."
---

# Hick-Hyman Default Path Designer

## LAYER 1: INVARIANTS (Never override.)

1. **Response uncertainty is the dominant coefficient.** The Wifall et al. (2015) split proves that response uncertainty (how many ways the user can ACT) has a larger b-coefficient than stimulus uncertainty (how many things appear). Cutting available response actions cuts more decision time than trimming visible menu items. Always target response options first.
2. **The default IS a decision — make it explicit.** A blank form field, an unselected radio button, or an unhighlighted pricing tier forces the user to construct a choice from zero entropy. Pre-selection sets p(i) of the desired option to its maximum, minimizing H = -Σ p(i) × log₂(p(i)) before the user touches the page.
3. **One primary CTA per conversion zone, no exceptions.** Hick-Hyman gives: RT = a + b × log₂(n+1). Moving from n=1 to n=2 adds log₂(3) − log₂(2) ≈ 0.58 bits of processing latency per user, multiplied across every session. Secondary actions must be visually demoted to a different hierarchy level — not co-equal buttons.
4. **Recommended-option badging reduces entropy arithmetically.** Labeling one tier "Most Popular" collapses the user's probability distribution: that option's p(i) dominates the entropy sum. This is Hyman's entropy extension in direct action — the badge does not add copy, it rewrites the probability weights.
5. **Smart defaults must match the modal user path, not the highest-revenue SKU.** Pre-selecting a $997 option when 70% of buyers choose $297 increases friction for the majority. Verify against order data or session recordings before locking a default.
6. **Measure time-to-first-click, not just conversion rate.** Hick-Hyman predicts TTC on the primary CTA correlates with log₂(n) of competing clickable elements. If TTC > 8–12 seconds from page load, n is too high regardless of conversion rate.
7. **Do not remove options from the system — reduce n at the moment of decision.** Progressive disclosure keeps the full catalog available; it just does not present all of it at the decision point. Defaults + staging are not the same as deletion.

## LAYER 2: QUALITY GUIDANCE

1. Produce a before/after entropy score (H before vs. H after) using the actual option count and a realistic probability estimate for each option. Do not hand-wave — compute it.
2. Every pre-selected default must be justified by behavioral data (order history, scroll depth, session recordings) or, when unavailable, by a stated assumption flagged for testing.
3. Flag any recommended default that conflicts with legal, accessibility, or consumer-protection requirements (e.g., pre-ticked opt-ins in GDPR jurisdictions). Compliance overrides entropy optimization.
4. Separate pricing-tier defaults from form-field defaults from CTA defaults — each is a different decision zone with its own n and entropy calculation.
5. Pair every default recommendation with a specific A/B test design: the variant, the primary metric (conversion rate + TTC), and the minimum detectable effect.

## PURPOSE

Hick-Hyman Law (RT = a + b × log₂(n+1)) and Hyman's Entropy Extension establish that the cognitive cost of a page decision is governed by the uncertainty of available response options — not by how many features are listed or how long the copy runs. This skill applies that mechanism in one direction: pre-select the correct option so the user's response uncertainty collapses to near-zero before they consciously evaluate.

Where hick-single-decision-enforcer removes competing actions and hick-option-pruning-auditor cuts the raw option count, this skill engineers the probability distribution of the remaining choices — making the desired action the high-p(i) dominant term in the entropy sum. A pre-filled default, a badged tier, a pre-checked shipping preference, or a highlighted primary CTA all operate through the same mechanism: they transfer the construction cost of the decision from the user's working memory to the page designer.

**Brag line (from the thinker):** "We cut decision time by removing options, and we can prove the math."

Carry to a peer: "Our checkout pre-selects the most common choice at every step. Hick-Hyman math says that alone eliminates multiple bits of processing latency — and we can show the entropy calculation for each field."

## INPUT REQUIREMENTS

**Required:**
- The page: URL, live screenshot, or written description of all visible elements in the conversion zone
- The ONE desired action: the specific click, form submit, or purchase event you are optimizing for

**Optional (improves output precision):**
- Analytics: current conversion rate, TTC on primary CTA, drop-off rate per checkout step
- Order/session data: modal SKU, most common shipping method, most common country — needed to validate defaults match real user behavior
- Funnel position: top-of-funnel discovery page vs. bottom-of-funnel checkout (determines how aggressively to pre-select)
- Existing A/B test history on this page

## EXECUTION PROCESS

**Step 1 — Inventory all response options in the conversion zone.**
List every element a user can interact with in the zone containing the desired action. Include: primary CTA, secondary CTAs, navigation links, form fields (blank = n+1), pricing tiers, radio buttons, dropdowns. Count = n_current.

Compute baseline entropy (equal-probability assumption for a first pass):
  H_baseline = log₂(n_current + 1)
Note: if analytics provide click distributions, use Hyman's weighted formula:
  H_weighted = -Σ p(i) × log₂(p(i)) for each clickable option

**Step 2 — Isolate response options vs. stimulus elements.**
Per the Wifall et al. stimulus-response uncertainty split, separate:
- Response options: things the user can DO (click, submit, enter, select)
- Stimulus elements: things the user reads or views (headlines, images, bullets)

Apply the higher b-coefficient to response options. If n_response > n_stimulus, response reduction is the higher-leverage move.

**Step 3 — Identify every undefaulted field or unselected option.**
A blank field, an unselected tier, a radio group with nothing checked — each one forces the user to construct a choice from H = log₂(n_options) bits. List them. Each is a default-path gap.

**Step 4 — Assign a default to each gap using the modal-user rule.**
For each undefaulted element:
- Pull the modal value from order data, session recordings, or CRO benchmark data
- If no data: state the assumption + flag for A/B test
- Document: Default value | Source | Confidence (High/Medium/Assumed)

**Step 5 — Apply Hyman entropy reduction to the primary CTA.**
Badge the desired action using "Recommended," "Most Popular," or equivalent. Compute the entropy reduction:
- Before badge: uniform distribution → H_before = log₂(n_tiers)
- After badge: assume badged option captures 60% probability share (conservative; literature shows 55–75%)
  H_after = -(0.60 × log₂(0.60) + remaining p(i) × log₂(p(i)) each)
State the delta: ΔH = H_before − H_after (in bits). This is the measurable entropy removed.

**Step 6 — Score each change on the Decision-Load Impact Table.**

| Change | ΔH (bits) | Effort | Priority |
|--------|-----------|--------|----------|
| (list each proposed default) | (computed) | (Low/Med/High) | (1-n) |

Legend: ΔH = Shannon entropy removed from user's decision load; Effort = implementation cost; Priority = implement highest ΔH / lowest Effort first.

**Step 7 — Write the A/B test spec for the top-priority change.**
- Control: current state
- Variant: default applied
- Primary metric: conversion rate (desired action)
- Secondary metric: time-to-first-click on primary CTA
- MDE: 5% relative lift (conservative for high-traffic pages; use 10% for sub-1000 weekly sessions)
- Runtime: minimum 1 week, minimum 200 conversions per variant

**Step 8 — Deliver prioritized change list with entropy math visible.**

## OUTPUT STRUCTURE

**1. Page Entropy Audit**
- n_current (response options in conversion zone)
- H_baseline (bits, equal-probability)
- H_weighted (bits, analytics-adjusted, if data available)
- Response vs. stimulus option split
- TTC benchmark vs. observed (flag if TTC > 8–12s)

**2. Default-Path Gap List**
One row per undefaulted element: element name, current state, recommended default, source/confidence, ΔH.

**3. Entropy-Reduction Recommendations**
Ordered by ΔH/Effort ratio. Each recommendation includes:
- Specific change (exact field, exact pre-selected value, exact badge text)
- Entropy math (H_before → H_after → ΔH)
- Behavioral data supporting the default choice
- Compliance flag if applicable

**4. Recommended-Option Badging Plan**
Which tier or option gets the badge, exact label text, visual treatment (color, size, position). Include the entropy calculation showing the probability-shift effect.

**5. A/B Test Spec**
For the top-priority change: control, variant, metrics, MDE, runtime.

**6. Quick-Win List**
Changes implementable in < 1 day (smart form defaults, pre-checked fields, badge addition) separated from structural changes requiring dev work.

## WORKED MINI-EXAMPLE

**Page:** SaaS pricing page — 4 tiers (Starter $29, Pro $79, Business $149, Enterprise custom), no tier pre-selected, primary CTA on each tier is an identical "Get Started" button.

**Desired action:** Trial signup on the Pro tier (modal conversion tier per order data).

**Before:**
- n_response = 4 (four equal-weight "Get Started" buttons + Enterprise "Contact Us")
- H_baseline = log₂(5) ≈ 2.32 bits
- No default. User must compare all tiers before acting.
- TTC observed: 14 seconds (above 8–12s threshold — confirms entropy overload)

**Hyman entropy calculation after intervention:**
- Add "Most Popular" badge to Pro tier → Pro captures estimated p = 0.65
- Remaining 3 paid tiers split p = 0.30; Enterprise p = 0.05
- H_after = -(0.65 × log₂(0.65) + 3 × 0.10 × log₂(0.10) + 0.05 × log₂(0.05))
- H_after ≈ -(0.65 × −0.621 + 3 × 0.10 × −3.32 + 0.05 × −4.32)
- H_after ≈ -(−0.404 − 0.996 − 0.216) ≈ 1.62 bits
- ΔH = 2.32 − 1.62 = **0.70 bits removed**

**Additional defaults applied:**
- Pre-select annual billing toggle → removes 1 response option for payment-term decision
- Pre-fill country field from IP geolocation → H = 0 for that field

**After (combined):**
- TTC target: < 8 seconds (Hick-Hyman predicts ~30% TTC reduction from 0.70-bit entropy cut)
- Expected conversion lift: 15–25% based on HubSpot/Zoho tier-reduction benchmarks (comparable intervention magnitude)

**A/B test:** Control = 4 equal tiers. Variant = Pro badged "Most Popular" + annual billing pre-selected. Primary metric: trial signup rate. Runtime: 2 weeks.

## OUTPUT FILE

Save to: [project-folder]/Hick-Hyman - Click Architecture/[YYYY-MM] - Default Path Design.md
