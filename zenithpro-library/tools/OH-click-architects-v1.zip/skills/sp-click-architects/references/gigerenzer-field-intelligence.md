---
name: gigerenzer-field-intelligence
description: Meta-synthesis across all Gigerenzer page-action skills + the Click Architects network. Finds convergence zones, surfaces the Single Move, and cross-wires ecological rationality with the full conversion stack.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Gerd Gigerenzer — Field Intelligence (Skill 7 of 7)"

interface:
  invoke: "/gigerenzer-field-intelligence"
  calls:
    - gigerenzer-heuristic-fit-designer
    - gigerenzer-recognition-cue-architect
    - gigerenzer-take-the-best-sequencer
    - gigerenzer-risk-literacy-reframer
    - gigerenzer-less-is-more-auditor
    - gigerenzer-single-cue-spotlighter
  called_by: [user, click-architects]
  outputs_to: [client-output-folder]

freshness_gate:
  max_age_days: 45
  reason: "Offer, copy, and proof-point rotation invalidates cue-validity rankings and natural-frequency baselines within 6 weeks."

integration_hooks:
  - thinker: fogg-field-intelligence
    feeds_from: "Fogg ability audit identifies where visitors stall. Gigerenzer explains WHY: the page environment broke their heuristic (wrong cue order, percentage framing, option flood)."
    feeds_to: "Gigerenzer's cue-validity ranking tells Fogg which prompt to simplify first. Fix the ecological mismatch, then reduce Fogg friction."
    shared_data: "Stopping-rule trigger point = Fogg prompt placement target."

  - thinker: cialdini-field-intelligence
    feeds_from: "Cialdini social proof and authority signals ARE recognition cues. The Recognition Heuristic elevates their conversion weight from 'nice to have' to load-bearing structure."
    feeds_to: "Gigerenzer ranks which Cialdini lever has highest validity on this page; leads with only that one (Take-the-Best discipline)."
    shared_data: "Validity-ordered cue list = Cialdini lever priority queue."

  - thinker: kahneman-field-intelligence
    feeds_from: "Kahneman System 1 is the mechanism by which heuristics fire. Gigerenzer provides the ecological conditions under which System 1 reaches the correct decision (cue-environment fit)."
    feeds_to: "Gigerenzer corrects Kahneman's pessimism: heuristics are not biases when the environment is properly structured. Copy that exploits this is not dark-pattern copy."
    shared_data: "Natural-frequency format satisfies both: cognitively fluent (System 1) and ecologically valid (Gigerenzer)."

  - thinker: thaler-field-intelligence
    feeds_from: "Thaler defaults and choice architecture determine the environment the heuristic operates in. Gigerenzer explains what cognitive tool fires inside that environment."
    feeds_to: "Gigerenzer's Boosting principle constrains Thaler nudge design: acceptable nudges enhance competence; exploitative nudges undermine ecological rationality and erode trust."
    shared_data: "Default placement + cue-validity rank = joint design target."

  - thinker: iyengar-choice-set-auditor
    feeds_from: "Iyengar identifies the choice-overload threshold. Gigerenzer explains the mechanism: too many options prevent the visitor's stopping rule from firing."
    feeds_to: "Gigerenzer's fast-and-frugal tree structure gives Iyengar the pruning logic: remove options that share the same highest-validity cue — they are substitutes, not upgrades."
    shared_data: "Option count ceiling = N where recognition heuristic still discriminates."

  - thinker: hick-field-intelligence
    feeds_from: "Hick quantifies decision time as a function of option count. Gigerenzer explains what happens cognitively during that time: heuristic search stalls when no cue discriminates."
    feeds_to: "Combined model: decision cost = Hick time-to-choose + Gigerenzer search-length. Reduce both simultaneously by leading with ONE high-validity cue."
    shared_data: "Option count N shared; target is N=1 discriminating cue before CTA."

  - thinker: fitts-field-intelligence
    feeds_from: "Fitts measures motor cost to reach the CTA. Gigerenzer determines whether the cognitive stopping rule fires BEFORE the visitor reaches that CTA."
    feeds_to: "If the stopping rule fires early (high-validity cue near top), Fitts motor cost becomes the only remaining barrier — surface the CTA immediately after the cue."
    shared_data: "CTA position = f(cue placement x Fitts target size)."

  - thinker: pirolli-field-intelligence
    feeds_from: "Pirolli information scent predicts which link the visitor follows. Gigerenzer explains which cue on the landing page triggers the stopping rule once they arrive."
    feeds_to: "If scent led the visitor here for Cue X, lead with Cue X (validity match). Mismatched scent breaks the heuristic — visitor searches for the promised cue and leaves."
    shared_data: "Ad/email cue label = page headline cue label. Continuity is a heuristic fit condition."

  - thinker: eisenberg-field-intelligence
    feeds_from: "Eisenberg buying modalities map visitor decision style (competitive, methodical, spontaneous, humanistic). Gigerenzer maps which heuristic each style uses: spontaneous = recognition; methodical = Take-the-Best ordered list."
    feeds_to: "Cue ordering strategy differs by modality: spontaneous visitors need the recognition signal first; methodical visitors need the validity-ordered feature sequence."
    shared_data: "Modality mix from Eisenberg determines which Gigerenzer heuristic to optimize for."

  - thinker: kohavi-field-intelligence
    feeds_from: "Kohavi provides the experiment infrastructure. Every Gigerenzer prescription (cue order, natural-frequency format, option reduction) is a hypothesis until it is tested."
    feeds_to: "Gigerenzer generates prioritized test queue by cue-validity delta: highest-validity cue reorder gets first A/B slot."
    shared_data: "Cue-validity ranking = Kohavi test priority stack."

  - thinker: laja-field-intelligence
    feeds_from: "Laja voice-of-customer mining surfaces the words visitors use when describing their uncertainty. Those words reveal which cue they are searching for."
    feeds_to: "Gigerenzer's ecological rationality requires cue-language match: if VoC says 'I needed proof it was safe,' the highest-validity cue is safety proof — even if the marketer thought features mattered most."
    shared_data: "VoC cue vocabulary = cue label taxonomy for Take-the-Best sequencing."

  - thinker: norman-field-intelligence
    feeds_from: "Norman affordances signal what actions are available. If the CTA's affordance is unclear, the visitor's stopping rule never fires — they cannot act on the heuristic decision."
    feeds_to: "After Gigerenzer's stopping rule fires, Norman's Gulf of Execution must be zero: the CTA must be immediately perceivable and operable."
    shared_data: "Stopping-rule trigger point = Norman feedback state transition target."

  - thinker: nielsen-field-intelligence
    feeds_from: "Nielsen readability and scanability determine whether the visitor's eye finds the highest-validity cue in the first pass. A buried cue cannot trigger Take-the-Best."
    feeds_to: "Gigerenzer cue hierarchy maps directly to Nielsen F-pattern: highest-validity cue at the F-pattern entry point (top-left, first scan line)."
    shared_data: "F-pattern hotspot = mandatory placement for Cue #1 in the Take-the-Best sequence."

  - thinker: eyal-field-intelligence
    feeds_from: "Eyal internal triggers motivate a visit. Gigerenzer determines whether the page environment supports the heuristic the trigger activated."
    feeds_to: "If the trigger was recognition-based ('I know this brand'), the page must reinforce recognition immediately or the heuristic misfires."
    shared_data: "Trigger type (recognition vs. cue-search) determines which Gigerenzer heuristic is live on arrival."

  - thinker: brignull-field-intelligence
    feeds_from: "Brignull dark patterns exploit cognitive shortcuts. Gigerenzer defines the line: Boosting enhances competence; dark patterns corrupt the ecological fit of heuristics."
    feeds_to: "Gigerenzer's Boosting principle is the ethical audit layer: any page tactic that prevents the visitor's heuristic from reaching the correct decision for them is a dark pattern."
    shared_data: "Ecological rationality = the standard against which dark-pattern risk is measured."

  - thinker: goward-field-intelligence
    feeds_from: "Goward conversion research identifies which page elements tested well. Gigerenzer explains the mechanism: elements that won tests likely matched the dominant heuristic on that page."
    feeds_to: "Gigerenzer produces a hypothesis before testing: 'cue X should win because it has highest validity for this audience under uncertainty.' Goward tests it."
    shared_data: "Winning element label = cue-validity validation data point."
---

# Gigerenzer Field Intelligence

## LAYER 1: INVARIANTS

1. Synthesis not summary. Find PATTERNS across the 6 skills (convergence zones), not a recap.
2. Convergence detection mandatory — name each zone explicitly.
3. Contradictions surfaced not hidden.
4. The Single Move is non-negotiable — ONE highest-leverage page change, stated as an executable instruction.
5. The Mirror — examine the business's own page-design biases (complexity inflation, percentage theater).
6. Cross-system intelligence with Click Architects is the highest-value section.
7. Freshness gate 45 days — cue-validity rankings decay as offers and proof rotate.

## LAYER 2: QUALITY GUIDANCE

- Every claim cites a Gigerenzer framework by name (Ecological Rationality, Take-the-Best, Recognition Heuristic, Natural Frequencies, Fast-and-Frugal Trees, Boosting, Risk/Uncertainty Distinction, 1/N, Satisficing).
- Before->After examples use a real page element (headline, stat block, pricing tier), not abstract variables.
- Tables: max 6 columns, short cells, legend for any abbreviation.
- No emojis. No filler. Operational throughout.

---

## PURPOSE

We design WITH the mental shortcuts instead of fighting them. When Gigerenzer's six tools converge on a single page, they reveal the ecological mismatch — the gap between the heuristics visitors are running and the information environment the page provides. Fix the mismatch. Conversion follows.

---

## INPUT REQUIREMENTS

Run at least 4 of the 6 tool skills on the SAME page before invoking field intelligence:

| Tool Skill | What It Produces |
|---|---|
| heuristic-fit-designer | Environment-heuristic mismatch map |
| recognition-cue-architect | Recognition signal audit + placement recommendation |
| take-the-best-sequencer | Validity-ordered cue sequence (Cue #1 through N) |
| risk-literacy-reframer | Natural-frequency rewrites of all stats |
| less-is-more-auditor | Option reduction + LIME threshold check |
| single-cue-spotlighter | The one highest-validity cue + isolation prescription |

Minimum viable set: take-the-best-sequencer + risk-literacy-reframer + less-is-more-auditor + any one of the remaining three.

---

## EXECUTION PROCESS

### Step 1 — Component Synthesis

Ingest all tool-skill outputs. Extract: (a) each skill's primary diagnosis, (b) the page element it flagged, (c) the change it prescribed.

### Step 2 — Convergence Detection

Map all prescriptions onto the page. Name each zone where 3+ skills point at the same element or the same failure mode.

**Convergence Zone taxonomy:**
- **Cue Flood Zone** — take-the-best + single-cue-spotlighter + less-is-more all flag the same section as overloaded.
- **Framing Gap Zone** — risk-literacy-reframer flags stats that also sit in the highest-validity cue position (double fix available).
- **Recognition Deficit Zone** — recognition-cue-architect + heuristic-fit-designer both flag low brand salience at entry.
- **Stopping Rule Dead Zone** — take-the-best sequencer shows no cue discriminates before the CTA — visitor has no heuristic exit.

### Step 3 — Contradiction Surfacing

State any case where two tool skills prescribe conflicting changes to the same element. Common conflict: single-cue-spotlighter says "remove Cue B" while recognition-cue-architect says "Cue B IS the recognition signal." Resolution protocol: recognition signals are exempt from removal — they go first, alone; subsequent cues obey Take-the-Best ordering.

### Step 4 — Amplification Identification

Find the change that resolves the most convergence zones simultaneously. That is the amplification candidate.

### Step 5 — The Single Move

State one instruction: which element to change, how to change it, and why it is the highest-leverage point. Format:

> **Single Move:** [Specific element] → [Specific change] because [Gigerenzer mechanism + convergence count].

### Step 6 — The Mirror

Diagnose the business's own page-design bias. Common Gigerenzer-specific biases:
- **Complexity Inflation** — adding features/stats to signal quality, unaware that complexity destroys heuristic fit.
- **Percentage Theater** — using "X% improvement" because it sounds precise, unaware it requires normalization the visitor cannot perform.
- **Symmetry Illusion** — treating all cues as equally valid because they each "have value," unaware Take-the-Best requires strict ordering.
- **Option Generosity** — offering many plans/packages to avoid restricting choice, unaware this prevents the stopping rule from firing.

Name the bias. State its cost in lost stopping-rule triggers.

### Step 7 — Cross-System Intelligence

For each paired thinker below, state the compound insight that neither thinker produces alone.

| Pair | Compound Insight |
|---|---|
| Gigerenzer + Hick | Total decision cost = Hick choice-time + Gigerenzer search-length. Reduce N to 1 discriminating cue to collapse both simultaneously. |
| Gigerenzer + Fitts | Stopping rule fires first; then motor cost is the only barrier. CTA must be proximate to Cue #1 placement. |
| Gigerenzer + Pirolli | Scent label from ad = Cue #1 label on page. Discontinuity forces a new search that has no valid exit. |
| Gigerenzer + Eisenberg | Modality determines active heuristic: spontaneous = recognition; methodical = Take-the-Best sequence. Page must serve both with recognition first, ordered list second. |
| Gigerenzer + Kohavi | Every cue-order hypothesis is falsifiable. Validity ranking = test priority. Test #1: swap Cue #1 and Cue #2; test #2: natural-frequency vs. percentage stat block. |
| Gigerenzer + Laja | VoC language surfaces which cue visitors are searching for. If VoC says "I needed proof it was safe" and the page leads with features, ecological mismatch is confirmed. |
| Gigerenzer + Norman | Stopping rule fires but the CTA affordance is invisible — decision made, action blocked. Norman Gulf of Execution is the post-heuristic bottleneck. |
| Gigerenzer + Fogg | Ability failures are often ecological mismatches. Fix the cue environment first; then apply Fogg simplicity. |
| Gigerenzer + Cialdini | Social proof and authority ARE recognition cues. Cialdini's levers get validity-ranked and ordered — not stacked arbitrarily. |
| Gigerenzer + Kahneman | System 1 IS the heuristic processor. Gigerenzer corrects Kahneman's framing: System 1 errors are environment errors, not cognitive errors. Fix the page, not the person. |
| Gigerenzer + Thaler | Thaler defaults create the environment; Gigerenzer specifies what cognitive tool operates inside it. Default to the highest-validity cue being unmissable. |
| Gigerenzer + Iyengar | Iyengar caps options; Gigerenzer explains why at that cap: option N+1 breaks the Recognition Heuristic by making all options equally unfamiliar. |
| Gigerenzer + Brignull | Boosting = ethical standard. Any tactic that prevents the visitor's heuristic from reaching the correct decision for them = dark pattern. Audit against this. |
| Gigerenzer + Eyal | Trigger type (recognition vs. cue-search) determines which heuristic is live on arrival. Page must reinforce the heuristic the trigger activated. |
| Gigerenzer + Nielsen | F-pattern hotspot = mandatory position for Cue #1. If Cue #1 is not at the F-pattern entry, Take-the-Best never fires. |
| Gigerenzer + Goward | Winning test elements validate cue-validity hypotheses. Reverse-engineer past winners: the element that won is likely Cue #1 for this audience. |

### Step 8 — Coherence Map

Produce a table showing each of the 6 tool skills, what they prescribed, and whether the Single Move satisfies, partially satisfies, or overrides their prescription.

| Skill | Prescription | Single Move Relation |
|---|---|---|
| heuristic-fit-designer | [from output] | Satisfies / Partial / Override |
| recognition-cue-architect | [from output] | Satisfies / Partial / Override |
| take-the-best-sequencer | [from output] | Satisfies / Partial / Override |
| risk-literacy-reframer | [from output] | Satisfies / Partial / Override |
| less-is-more-auditor | [from output] | Satisfies / Partial / Override |
| single-cue-spotlighter | [from output] | Satisfies / Partial / Override |

### Step 9 — Conversion Projection

State expected lift range, mechanism, and the Kohavi test that would validate it.

**Format:**
> Projected lift: [X–Y%] on [metric]. Mechanism: [Gigerenzer framework]. Caveat: [what would make it higher/lower]. Kohavi test: [specific A/B setup].

**Calibration anchors from Gigerenzer's empirical record:**
- Natural-frequency reframe alone: Bayesian comprehension odds ratio 7.1x (Gigerenzer & Hoffrage 1995). CTA clarity lift: expect 8–18% on stat-heavy pages.
- Take-the-Best cue reorder: 5–14% lift when Cue #1 validity gap vs. current lead element is > 0.2 on a 0–1 scale.
- Option reduction to 1–3: 10–25% lift when current option count exceeds 5 and audience is in uncertainty (unfamiliar category).

---

## OUTPUT STRUCTURE

```
## Gigerenzer Field Intelligence — [Page Name] — [Date]

### Page + Desired Action
[URL or description] / [Target action]

### Tool Skills Run
[List which of the 6 were run]

### Convergence Zones
[Named zones with supporting evidence from tool outputs]

### Contradictions
[Any, or "None detected"]

### The Single Move
[One instruction]

### The Mirror
[Business design bias diagnosis]

### Cross-System Intelligence
[Top 3–5 highest-value compound insights from Step 7 for this specific page]

### Coherence Map
[Table from Step 8]

### Conversion Projection
[Projected lift + Kohavi test]
```

**Worked Before→After Example (sample page: SaaS trial landing page)**

Before: "Our tool improves team output by 34% and reduces meeting time by 22%. Choose from Starter, Growth, Professional, or Enterprise plans."

After (Single Move applied — Take-the-Best + Natural Frequencies + Less-Is-More convergence zone):
"8 of 10 teams cut their weekly meeting load by one hour within 30 days. [Start Free Trial]"
— One natural-frequency stat. One CTA. Plans page linked from footer only.

Mechanism: Stopped the search at the highest-validity cue (social proof count), eliminated option-selection decision from the conversion path, replaced probability theater with a natural frequency the visitor can picture.

---

## OUTPUT FILE

Save to: `[client-output-folder]/gigerenzer-field-intelligence-[YYYY-MM-DD].md`

Flag for re-run if: offer changes, proof rotation, new pricing tiers added, or 45 days elapsed.
