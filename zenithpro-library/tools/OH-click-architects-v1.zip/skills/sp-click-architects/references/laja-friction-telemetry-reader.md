---
name: laja-friction-telemetry-reader
description: Use when you have session-replay or analytics data and need to identify rage clicks, dead clicks, error clicks, and form-abandonment patterns that signal where a page is leaking conversions — outputs a triangulated friction map tied to ResearchXL Spoke 3 (Digital Analytics) + Spoke 6 (Mouse Tracking).
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peep Laja (CXL Institute, ResearchXL Model 2014; Mouse Tracking Analysis + Digital Analytics spokes) — Click Architecture (Skill 5 of 7)"
interface:
  invoke: "/laja-friction-telemetry-reader"
  calls: []
  called_by: [user, laja-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic mix, device split, and page changes alter click patterns; replay findings older than 45 days may reflect a page that no longer exists."

laja_heuristic_walkthrough_integration:
  feeds_from: laja-heuristic-walkthrough
  feeds_to: laja-pxl-prioritizer
  shared_data: "Heuristic walk-through flags friction and distraction axes (Four-Factor Audit) — telemetry confirms which friction nodes generate rage/dead clicks in actual sessions; combined output raises PXL evidence score by +1 (mouse tracking) and +1 (digital analytics)."

laja_pxl_prioritizer_integration:
  feeds_from: laja-friction-telemetry-reader
  feeds_to: laja-pxl-prioritizer
  shared_data: "Every rage/dead-click cluster and form-abandonment field exported as a candidate test idea with pre-filled PXL evidence bits: Q8 (analytics evidence) = 1, Q9 (mouse tracking) = 1."

kahneman_field_intelligence_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: laja-friction-telemetry-reader
  shared_data: "System-1 friction signals (rage clicks = immediate frustration response, dead clicks = failed affordance expectations) map to Kahneman availability heuristic and peak-end memory; telemetry confirms which friction moments dominate the user's experience memory."
---

# Laja Friction Telemetry Reader

## LAYER 1: INVARIANTS (Never override.)

1. **Minimum data floor.** Mouse-tracking analysis requires 2,000-5,000 visitor minimum per page variant before heatmap or scroll patterns are statistically meaningful (ResearchXL Spoke 6). Do not interpret patterns below this threshold — report the data gap instead.
2. **Triangulate before hypothesizing.** No single signal (rage click alone, drop-off rate alone) justifies a hypothesis. Every friction finding must be confirmed by at least two of: analytics funnel data, session replay behavior, heatmap/scrollmap, or qualitative survey verbatim.
3. **Segment before reading.** Raw aggregate click data hides device, browser, and traffic-source breakdowns. Always segment by device type first — mobile vs desktop rage-click patterns routinely point to different root causes.
4. **Do not fix what is not broken.** If a click cluster is dead clicks on a non-linked element and conversion rate on that device/segment is above benchmark, flag for monitoring only — do not generate a test idea from it.
5. **Distinguish fix vs test.** Broken rendering, error clicks on forms, and unresponsive CTAs are "just do it" fixes — not A/B tests. Reserve test capacity for behavioral and motivational hypotheses. Fix technical failures immediately.
6. **Conversion Formula hierarchy.** Per C = 4M + 3V + 2(I-F) - 2A: friction (F) and anxiety (A) have a combined 4x coefficient. Friction telemetry directly measures F and A signals — prioritize findings that reduce anxiety (error clicks on trust fields, form abandonment at payment step) over novelty optimizations.
7. **Report all failures.** If a replay tool returns partial data, a funnel step has no tracking, or a segment is below the data floor — state the gap explicitly before any synthesis. Never present partial telemetry as complete.

## LAYER 2: QUALITY GUIDANCE

1. **Name the element, not the zone.** "Rage clicks near the CTA" is not actionable. Output: element selector, label text, page position (above/below fold), and device segment.
2. **Quantify severity.** Every finding must include: click count or session %, benchmark comparison (site average or industry standard), and estimated revenue impact where calculable.
3. **Pair every friction finding with a hypothesis.** The output is not a bug list — it is a prioritized problem list tied to a specific page change. No diagnosis without a directional fix.
4. **Cross-reference form field analytics with replay.** Field-level abandonment data (time-on-field, re-entry rate, drop-after-field) must be validated against actual session replays of users hitting that field before any field-removal recommendation.
5. **PXL pre-score every output hypothesis.** Pre-fill the PXL binary questions answerable from telemetry (Q8 analytics, Q9 mouse tracking) so the prioritizer skill can immediately ingest findings.

## PURPOSE

This skill reads session-replay and analytics telemetry to locate the exact page elements where visitors express friction — rage clicks (rapid repeated clicks = expectation failure or broken element), dead clicks (clicks on non-interactive elements = affordance confusion), error clicks (clicks on form error states = validation friction), and form-abandonment patterns (field-level exits = anxiety or effort overload).

This is ResearchXL Spokes 3 and 6 in operational form. Spoke 3 (Digital Analytics) locates the funnel steps where money is leaking. Spoke 6 (Mouse Tracking) narrows from step to element — the specific node generating the leak. Together they triangulate a hypothesis that is grounded in behavior, not opinion.

**Brag line:** "We find the real leak with 6 research lenses before we touch the page."

The desired action stays fixed throughout. Every friction cluster is evaluated by whether it sits between the visitor and that one action. Friction elsewhere is lower priority.

## INPUT REQUIREMENTS

**Required:**
- The page URL, screenshot, or written description
- The ONE desired action (e.g., "click Add to Cart", "submit lead form", "click Start Free Trial")
- Telemetry source: session-replay export (Hotjar, FullStory, Microsoft Clarity, LogRocket) or heatmap/scrollmap data — specify tool and date range
- Funnel analytics: step-level conversion rates showing where this page sits

**Optional but high-value:**
- Device/browser segmentation of conversion rate
- Form analytics export (field-level time, abandonment, re-entry)
- Traffic source breakdown
- Visitor count for data-floor check
- Any existing qualitative survey verbatims (feeds from laja-voice-of-customer-miner)

## EXECUTION PROCESS

**Step 1 — Data Floor Check (non-negotiable first gate)**

Before reading any pattern, confirm visitor count meets the 2,000-5,000 minimum for mouse-tracking analysis. State:
- Total sessions in date range
- Device split (mobile / desktop / tablet %)
- Whether data floor is met per segment

If any segment is below floor: flag it, exclude from pattern analysis, state what additional traffic is needed before analysis is valid.

**Step 2 — Funnel Position and Drop-Off Rate (Spoke 3)**

Pull the conversion rate for this page's step in the funnel. Compute:
- Step conversion rate = (visitors who completed desired action) / (visitors who arrived at page) x 100
- Benchmark: landing pages median 2-5%; pricing/checkout 70-90% expected; opt-in pages varies by traffic temperature

Flag any step with conversion rate more than 20% below benchmark as a primary leak. If multiple steps leak, rank by volume x rate delta to identify highest-revenue-impact step first.

**Step 3 — Rage Click Mapping**

From session-replay or heatmap tool:
- Extract all elements with rage click events (3+ rapid clicks within 2 seconds on same target)
- Record: element label/selector, page position (above/below fold), device segment, session count, % of sessions
- Classify each cluster:
  - **Broken CTA** (expected to navigate, did not) — Severity 5, fix immediately
  - **Affordance confusion** (looks clickable, is not) — Severity 3-4, test removal or styling change
  - **Slow response** (element eventually responded, user repeated) — Severity 3, check page speed + element load time

Threshold: rage click rate >5% of sessions on any element = Severity 4+. Rate >10% = Severity 5, fix before any test.

**Step 4 — Dead Click Mapping**

Dead clicks = clicks on non-interactive elements. Most common causes: images assumed to be links, section headers that look like buttons, greyed-out elements assumed active, underlined non-link text.

- Extract dead click clusters by element
- For each: estimate % of sessions, page position, device
- Priority test: does this dead click sit within 200px of the desired action CTA? If yes, users may be missing the real CTA — Severity 4.

**Step 5 — Error Click and Form Abandonment Analysis**

For pages with forms:

A. **Error click rate**: clicks on form submit that trigger validation errors. Rate >20% = friction Severity 4. Common causes: unclear field requirements, premature sensitive data requests (credit card before value established), ambiguous labels.

B. **Field-level abandonment**: if form analytics available, rank fields by:
- Drop-after-field rate (% of sessions that exited immediately after interacting with this field)
- Re-entry rate (% who typed, deleted, typed again — signals confusion)
- Time-on-field (outlier fields with >3x average time = confusing label or validation)

High drop-after rate on any single field = strongest signal for field removal or rewrite. Per Conversion Formula: F has a 2x coefficient — every field removed reduces F directly.

C. **Checkout-specific anxiety signals**: error clicks on security badges, privacy links, or terms = visitors seeking reassurance before completing. This maps to A (anxiety) in the conversion formula — add visible trust signals adjacent to the hesitation point.

**Step 6 — Scroll Depth vs CTA Position**

From scrollmap:
- Note the fold line (50% of visitors reach this point)
- Note the 25% depth line (only 1 in 4 visitors reach this point)
- Map desired action CTA position against these thresholds

If primary CTA is below the 50% scroll line and conversion rate is below benchmark: Severity 4. Move CTA above fold or add a second CTA instance at fold.

If form starts below 25% scroll depth on mobile: Severity 5 on mobile segment.

**Step 7 — Triangulation Table**

For each friction finding, build one row in the output table (see Output Structure). A finding counts as triangulated only if two or more evidence types confirm it (analytics + replay, replay + scroll, etc.).

**Step 8 — PXL Pre-Score**

For each triangulated hypothesis, pre-fill the binary PXL questions answerable from telemetry:
- Q8 (analytics evidence): 1 if drop-off rate confirms the page
- Q9 (mouse tracking): 1 if heatmap/replay confirms the element

Pass complete rows to laja-pxl-prioritizer for final scoring.

## OUTPUT STRUCTURE

### 1. Data Floor Confirmation
Sessions analyzed, date range, device split, floor status per segment. Any excluded segments called out.

### 2. Funnel Position Summary
Step conversion rate, benchmark, delta, revenue-leak rank if multi-step funnel.

### 3. Friction Findings Table

**Table A — Friction Signal (5 columns)**

| ID | Element | Type | Sev | Sess% | Dev |
|----|---------|------|-----|-------|-----|
| F1 | [label] | Rage | 4 | 12% | Mobile |

**Table B — Evidence and Hypothesis (4 columns)**

| ID | Evidence | Fix/Test | Hypothesis |
|----|----------|----------|------------|
| F1 | A+R | Fix | Remove decorative image above CTA |

Legend: Type = Rage/Dead/Error/Abandon | Sev = 1-5 (5=critical) | Sess% = % of sessions | Dev = device segment | Evidence = A=Analytics, R=Replay, H=Heatmap, S=Scroll, Q=Qualitative | Fix/Test = Fix immediately or A/B Test. Join tables on ID.

### 4. Form Field Abandonment Breakdown
(If form present) Field-level table: field name, drop-after rate, re-entry rate, time-on-field, recommendation.

### 5. Fix vs Test Classification
Two lists:
- **Fix immediately** (technical failures, broken CTAs, error-click rates >20%)
- **A/B test** (behavioral/motivational hypotheses requiring validation)

### 6. PXL Pre-Scored Hypotheses
Each hypothesis with Q8 and Q9 pre-filled, ready for laja-pxl-prioritizer ingestion.

### 7. Open Gaps
Any data not available (segments below floor, missing form analytics, no replay for specific device). State what additional data would unlock.

## WORKED MINI-EXAMPLE

**Page:** SaaS trial sign-up page. Desired action: submit 4-field registration form (name, email, company, password).

**Before — raw telemetry read:**
"There are some rage clicks and the form has decent drop-off."

**After — Friction Telemetry Reader output:**

Data floor: 3,800 sessions (floor met). Mobile 61%, desktop 39%.

Funnel step conversion: 18% overall. Benchmark for warm-traffic SaaS trial = 35-45%. Delta = -17-27pp. Primary leak confirmed.

Friction findings:
- F1: "Create Account" button — Rage clicks, 14% of mobile sessions. Replay shows button unresponsive for 800ms on iOS Safari 17. Severity 5. Fix: check JS event listener conflict on that browser version. **Fix immediately.**
- F2: "Company" field — Drop-after rate 31%, re-entry rate 44%. Visitors type, delete, retype. Time-on-field 28s vs 6s average. Hypothesis: label ambiguity ("Company" for solo freelancers feels excluding). **Test:** change label to "Company or freelance work."
- F3: "Password" field — Error click rate 28% on mobile. Validation rule not surfaced until submit. Hypothesis: inline validation required. **Fix immediately.**

Scroll: CTA button at 68% scroll depth on mobile. 49% of mobile sessions never reach it. **Test:** add sticky CTA bar on mobile.

PXL pre-score for F2: Q8=1 (analytics confirms drop), Q9=1 (replay confirms re-entry). Starting PXL score: 2 — pass to prioritizer for remaining 8 questions.

## OUTPUT FILE
Save to: [project-folder]/Laja - Click Architecture/[YYYY-MM] - Friction Telemetry Read - [Page Name].md
