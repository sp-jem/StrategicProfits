---
name: fitts-target-cost-auditor
description: Use when a page's primary CTA is underperforming or when you need a motor-cost baseline for every clickable target — computes the Index of Difficulty (ID = log₂(1 + D/W)) for each target, ranks them by acquisition cost, and prescribes concrete W/D changes to collapse MT on the desired action.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Paul Fitts (1954; Fitts's Law, Shannon formulation 1992; ID / TP / Two-Phase Movement Model) — Click Architecture (Skill 1 of 7)"
interface:
  invoke: "/fitts-target-cost-auditor"
  calls: []
  called_by: [user, fitts-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page layout changes, A/B tests, and device-mix shifts alter D and W for every target; ID calculations go stale within one sprint cycle."

fitts_primary_action_dominance_integration:
  feeds_from: fitts-target-cost-auditor
  feeds_to: fitts-primary-action-dominance-scorer
  shared_data: "ID scores per target; primary CTA ID rank; competing-target proximity map within 200px radius of CTA."

fitts_thumb_zone_integration:
  feeds_from: fitts-thumb-zone-mapper
  feeds_to: fitts-target-cost-auditor
  shared_data: "Prime-pixel coordinates for mobile (dominant-thumb hover centroid); used as the D origin for all mobile ID calculations."

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: fitts-target-cost-auditor
  shared_data: "Perceived-size signals (white space, visual weight, color contrast around CTA) that shift user's homing-phase caution; combine with W to explain effective vs. measured click dispersion."

thaler_integration:
  feeds_from: thaler-default-detector
  feeds_to: fitts-target-cost-auditor
  shared_data: "Default path on the page (where the eye/cursor idles before intent activates); sets the prime pixel origin for D measurement."
---

# Fitts Target Cost Auditor

## LAYER 1: INVARIANTS (Never override.)

1. **ID is the unit of truth.** Every diagnosis and recommendation must trace back to the equation MT = a + b × log₂(1 + D/W). Aesthetic opinions without an ID calculation are not findings.
2. **D is measured from the prime pixel, not from a fixed origin.** Prime pixel on desktop = cursor's likely resting position when page loads or after the last interaction. On mobile = bottom-center thumb hover centroid. If unknown, state the assumption.
3. **W is the hit area, not the visual boundary.** Measure the actual clickable zone (including invisible padding). Then note if perceived W differs — because users regulate homing caution based on what they see, not what is technically clickable.
4. **Edge/corner anchoring is desktop-only.** Screen edges act as infinite-W targets on mouse interfaces. On touch devices, edges and corners are the hardest zones to tap; never apply the "infinite target" benefit to mobile layouts.
5. **Competing targets raise effective ID on the CTA.** Every interactive element within 200px of the primary CTA forces the user to aim precisely to avoid mis-clicks, compressing effective W. Audit the 200px radius; competing targets are a Fitts cost even if they don't change D.
6. **Minimum touch target floor: 44×44 pt (≈59×59 px).** Any mobile CTA below this threshold has an artificially inflated ID floor that cannot be overcome by placement alone. Flag as a hard violation before any other finding.
7. **Destructive actions must have maximum ID relative to the primary CTA.** Place Cancel/Delete at the furthest feasible D from the primary CTA and use maximum size contrast (small, muted). Never co-locate or co-style them.

## LAYER 2: QUALITY GUIDANCE

1. **Report effective ID, not just nominal ID.** Use click-dispersion data (heatmaps, session recordings) to compute effective width We = 4.133 × SD of click coordinates. If dispersion data is unavailable, state "nominal ID — no dispersion data" and note the effective ID will be higher.
2. **Cumulative ID across multi-step flows.** In checkout, opt-in, or registration sequences, sum ID across every CTA step. Identify the single highest-ID step — that is the conversion bottleneck. Fix it first.
3. **Throughput (TP), not click rate, is the real metric.** TP = ID / MT. A CTA with a 15% mis-click rate has lower effective TP than a larger, better-spaced CTA even if raw click velocity looks similar. Use mis-click rate from session recordings to weight findings.
4. **Before-state must be quantified.** Every recommendation must include the current nominal ID value and the projected ID after the change. Percent reduction in ID is the proof of value.
5. **Flag the two-phase implication.** Distinguish whether a change eliminates the homing phase (large W → ballistic phase suffices) or merely shortens it. Full-width buttons on mobile eliminate the homing phase; marginal size increases only compress it.

## PURPOSE

This skill applies Fitts's Law — MT = a + b × log₂(1 + D/W) — directly to a live web page to compute the motor acquisition cost (Index of Difficulty) for every clickable target. It identifies which targets are expensive to hit, why (too small, too far, or surrounded by competing targets), and produces a ranked remediation plan that collapses MT on the one desired action.

**Brag line (carry this to a peer):** "Our primary button is mathematically the easiest thing to hit on the page."

The single lever: minimize ID on the primary CTA by maximizing W and minimizing D simultaneously, while maximizing ID on destructive or competing actions. Every other design decision on the page is evaluated against whether it moves these two variables in the right direction.

## INPUT REQUIREMENTS

**Required:**
- The page (URL, annotated screenshot, or written layout description — enough to identify every clickable element and approximate its pixel dimensions and position)
- The ONE desired action (the click/opt-in/purchase/next-step this page exists to drive)
- Device context: desktop (mouse), mobile (touch), or both

**Strongly recommended:**
- Heatmap or click-dispersion data (to compute effective W rather than nominal W)
- Session recording mis-click rate on the primary CTA
- Viewport dimensions (default assumption: 1440×900 desktop, 390×844 mobile)

**Optional:**
- Funnel position (top of funnel vs. checkout step changes prime pixel assumptions)
- Audience device-mix split (affects which ID calculation to weight more heavily)

## EXECUTION PROCESS

**Step 1 — Inventory every clickable target.**
List all interactive elements: primary CTA, secondary CTAs, nav links, form fields, images with links, social icons, footer links. Include anything with a cursor-pointer or tap event. Number each target T1…Tn. Set T1 = the desired action.

**Step 2 — Establish the prime pixel.**
- Desktop: If post-interaction (e.g., user just typed in a field), prime pixel = center of the last form field. If fresh page load, prime pixel = viewport center (720, 450 at 1440×900) or last known cursor position.
- Mobile: Prime pixel = bottom-center of screen at thumb-hover height (approximately x = screen_width/2, y = screen_height × 0.75).
- State coordinates explicitly. All D values are Euclidean distance from this point to the target center.

**Step 3 — Measure D and W for each target.**
- D = Euclidean distance (px) from prime pixel to center of clickable zone.
- W = clickable width (px) along the dominant axis of approach (usually horizontal for buttons, vertical for list items).
- If edge-anchored (desktop only): note W = ∞ and ID = 0 bits.
- Record: target name | D (px) | W (px) | nominal ID (bits)

**Step 4 — Compute nominal ID for each target.**
ID = log₂(1 + D/W)

Worked computation:
- If D = 400px, W = 120px → ID = log₂(1 + 400/120) = log₂(4.33) ≈ 2.11 bits
- If D = 400px, W = 240px → ID = log₂(1 + 400/240) = log₂(2.67) ≈ 1.41 bits (doubling W cut 0.70 bits)
- If D = 200px, W = 240px → ID = log₂(1 + 200/240) = log₂(1.83) ≈ 0.87 bits (halving D cut another 0.54 bits)

**Step 5 — Audit the CTA's 200px competing-target zone.**
List every interactive element whose center falls within 200px of T1's center. Each competing element compresses effective W by forcing precision during the homing phase. Note count, proximity, and visual similarity to T1 (identical styling = highest compression).

**Step 6 — Score and rank all targets.**

| Target | D (px) | W (px) | ID (bits) | Phase | Priority |
|--------|--------|--------|-----------|-------|----------|
| T1 — Primary CTA | — | — | — | — | FIX FIRST |
| T2…Tn — others | — | — | — | — | ranked ↑ |

Legend: D = distance from prime pixel; W = hit-area width; ID = Index of Difficulty; Phase = H (homing phase present) or B (ballistic-only, W large enough to land without homing); Priority = fix order.

**Step 7 — Identify violations.**

ID thresholds (these are practical UX benchmarks, not formal standards):
- ID ≤ 1.0 bit: excellent (fast acquisition, likely ballistic-only)
- ID 1.0–2.0 bits: acceptable (short homing phase)
- ID 2.0–3.0 bits: high cost (slow, error-prone — fix)
- ID > 3.0 bits: critical (requires deliberate precision — fix immediately)

Flag: touch targets below 44×44 pt as hard violations regardless of ID.

**Step 8 — Generate W/D prescriptions for T1.**
For each failing finding, compute the projected ID after each proposed change and express the reduction:
- Increase W from X to Y → new ID = Z (reduction: N bits, N% drop in MT)
- Move CTA N px toward prime pixel → new ID = Z
- Remove competing element C → effective W increases (mis-click pressure removed)

**Step 9 — Apply Two-Phase Model check.**
Does the proposed W, given D, allow ballistic-only landing? Rule of thumb: if W ≥ D/3, the homing phase is minimal. If W ≥ D, the homing phase is effectively eliminated. State which phase the current and proposed designs fall into.

**Step 10 — Destructive action audit.**
Confirm Cancel/Delete/Back has the highest ID on the page relative to T1. If it shares similar ID, prescribe: increase D (move it away), reduce W (smaller button), or reduce visual contrast (de-emphasize styling).

## OUTPUT STRUCTURE

**Section 1 — Target Inventory Table**
All targets with D, W, ID, phase flag, and competing-target count within 200px.

**Section 2 — Violation Summary**
Bulleted list of ID violations (> 2.0 bits on primary CTA, touch targets below floor, competing targets within 200px, destructive action too close).

**Section 3 — Ranked Prescription**
Ordered by expected ID reduction. Each item: current ID → projected ID → specific change → two-phase impact.

**Section 4 — Cumulative Flow ID (if multi-step)**
Step-by-step ID table. Bottleneck step called out. Fix priority.

**Section 5 — Quick Wins**
Changes achievable in < 1 hour of dev time that produce ≥ 0.5 bit ID reduction on T1.

## WORKED MINI-EXAMPLE

**Page:** SaaS opt-in landing page. Single hero section. CTA = "Start Free Trial" button.
**Desired action:** Click "Start Free Trial."
**Device:** Desktop, 1440×900 viewport.

**Before state:**
- Prime pixel: viewport center (720, 450).
- CTA center: (1100, 700) — right-side, below fold.
- D = √((1100-720)² + (700-450)²) = √(144400 + 62500) = √206900 ≈ 455 px
- W = 140 px (button width, dominant axis = horizontal)
- ID = log₂(1 + 455/140) = log₂(4.25) ≈ 2.09 bits — HIGH COST zone.
- Two-phase: homing phase active (W < D/3 = 152 px... close; homing compresses but present).
- Competing targets within 200px: 3 nav links (top of page) and a "Learn More" text link 80px below CTA.

**After state (prescriptions applied):**
1. Move CTA to horizontal center: CTA x = 720. D = √(0 + (700-450)²) = 250 px.
2. Increase W to 280 px (full-width on content column).
3. ID = log₂(1 + 250/280) = log₂(1.89) ≈ 0.92 bits — EXCELLENT zone.
4. Two-phase check: W (280) > D/3 (83) — homing phase eliminated, ballistic landing sufficient.
5. Remove "Learn More" link from 200px zone (move to feature section below). Nav links remain but are 400px+ from repositioned CTA.

**Result:** 2.09 → 0.92 bits. 56% ID reduction. MT drops proportionally. The primary button is now mathematically the easiest target on the page.

## OUTPUT FILE

Save to: [project-folder]/Fitts - Click Architecture/[YYYY-MM] - Target Cost Audit - [page-name].md
