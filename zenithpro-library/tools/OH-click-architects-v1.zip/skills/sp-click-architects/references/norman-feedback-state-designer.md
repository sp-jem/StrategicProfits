---
name: norman-feedback-state-designer
description: Use when a page has loading/processing/success/error states that are invisible or ambiguous — designs system-status signals that close the Gulf of Evaluation and confirm every action to the visitor.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Don Norman (The Design of Everyday Things 1988/2013; Feedforward vs. Feedback, Gulf of Evaluation, Seven Stages of Action) — Click Architecture (Skill 5 of 7)"
interface:
  invoke: "/norman-feedback-state-designer"
  calls: []
  called_by: [user, norman-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page states change with every A/B test, form revision, or checkout flow update — feedback audit becomes stale within one sprint cycle."

norman_gulf_of_evaluation_integration:
  feeds_from: [norman-gulf-of-evaluation-reducer]
  feeds_to: [norman-error-recovery-architect]
  shared_data: "Gulf of Evaluation severity scores per interaction point; which stages (Perceive/Interpret/Evaluate) are failing and where feedback is missing or misread."

fogg_integration:
  feeds_from: [fogg-prompt-designer]
  feeds_to: [fogg-behavior-system-designer]
  shared_data: "Prompt timing: Fogg's Motivation Wave defines WHEN to show state feedback for maximum behavioral reinforcement; Norman defines WHAT to show. Combine: high-motivation moments get enriched success states; low-motivation moments get minimal friction feedback."

fitts_integration:
  feeds_from: [fitts-primary-action-dominance-scorer]
  feeds_to: [fitts-click-path-minimizer]
  shared_data: "Button state changes (idle/loading/success/error) affect Fitts target size and visual prominence; coordinate state-design so the primary CTA remains the largest, highest-contrast element in every state."
---

# Norman Feedback State Designer

## LAYER 1: INVARIANTS (Never override.)

1. Every action on the page must produce a perceivable state change within 100ms. Norman's Stage 5 (Perceive State) fails entirely if the system is silent after a click. No exceptions for "fast" operations.
2. Feedback must close the Gulf of Evaluation at all three sub-stages: Perceive (is there a signal?), Interpret (is the signal unambiguous?), Evaluate (does it match the visitor's goal?). A spinner satisfies Perceive but fails Interpret and Evaluate. A spinner + label + outcome preview satisfies all three.
3. Never use the same visual treatment for success and error states. Cultural constraint: red = stop/fail, green = proceed/succeed is a learned convention. Violating it forces knowledge-in-the-head work on a conversion-critical step.
4. Feedforward (what will happen) is as mandatory as feedback (what happened). The Seven Stages of Action require both: Stages 1-4 (execution) need feedforward; Stages 5-7 (evaluation) need feedback. A page that omits feedforward creates Gulf of Execution even when feedback is perfect.
5. Loading states must communicate duration class: under 2s = spinner only; 2-10s = spinner + progress indicator; over 10s = progress bar + estimated time + cancel option. Uncertainty about duration is a separate friction source from uncertainty about outcome.
6. Error states must identify the specific field/action that failed, not the general form. "Something went wrong" satisfies Perceive but fails Interpret — the visitor cannot act on it. Norman's error taxonomy: slips need field-level correction prompts; mistakes need goal-level reframing.
7. The System Image (what appears on the page) is the ONLY lever. The designer's intended model and the visitor's mental model must converge through it. Every state — idle, loading, success, error — is a System Image that either builds or breaks the visitor's conceptual model.

## LAYER 2: QUALITY GUIDANCE

1. Test feedback timing with a real network throttle (Chrome DevTools: Slow 3G). If the page appears frozen for more than one second before a state change appears, the feedback is late by Norman's standard.
2. Each state should be independently readable without seeing the preceding state. A visitor who arrives mid-process (refreshed page, slow connection) must still be able to orient. Design each state as a complete communication unit.
3. Prefer state changes that preserve layout stability. A feedback element that shifts page content (layout shift) adds interpretation overhead — the visitor must re-locate elements. Feedback should appear in-place or in a reserved slot.
4. Use the Feedforward/Feedback asymmetry check: count feedforward signals (pre-action) vs. feedback signals (post-action) on the page. Most pages have 0-1 feedforward and 1-2 feedback. Target at least 2 feedforward signals per primary action path.
5. Validate each state against the Conceptual Model Triangle: does the System Image in this state match what the Designer intends AND what the User will infer? Run a 5-person first-click test on each state image in isolation. >80% correct interpretation = pass.

## PURPOSE

This skill designs the loading, processing, success, and error states that communicate system status to visitors at every stage of the Seven Stages of Action. It operates directly on the Gulf of Evaluation — the gap between what the system is doing and what the visitor can perceive and interpret.

The lever: visitors abandon pages not because they decided not to buy, but because they cannot tell whether their action registered, whether they should wait, whether something broke, or whether they succeeded. Norman's Stage 5-7 failure (Perceive / Interpret / Evaluate) causes silent dropout that analytics misreads as "low intent."

Brag line: "Every action on our page is obvious and every click confirms itself."

This skill takes a specific page and desired action, maps every interaction point that produces a state change, scores each state against Norman's evaluation sub-stages, and outputs exact copy, visual treatment, and timing spec for each state.

## INPUT REQUIREMENTS

Required:
- Page: URL, screenshot, or written description of the page
- Desired action: the one conversion event (click / opt-in / purchase / next-step)

Optional but useful:
- Analytics: drop-off rate at each form step, rage-click heatmap, form abandonment rate
- Funnel position: top-of-funnel opt-in vs. checkout vs. upsell page
- Existing state treatments: screenshots or descriptions of current loading/error/success states
- Audience: first-time visitor vs. returning buyer (affects knowledge-in-the-head assumptions)

## EXECUTION PROCESS

**Step 1 — Interaction Point Inventory**
List every user action on the page that triggers a system response. For each, name: (a) the trigger element, (b) what the system does, (c) the expected outcome the visitor holds.
Threshold: a page with a single opt-in form typically has 3-6 interaction points (field focus, field blur/validation, submit click, email confirmation). A checkout page has 8-15.

**Step 2 — Gulf of Evaluation Audit per Interaction Point**
For each interaction point, score 0/1 on three sub-stages:
- P (Perceive): is there a visible signal that the action registered? (0 = silent, 1 = state change visible)
- I (Interpret): is the signal unambiguous — only one reasonable meaning? (0 = ambiguous, 1 = single interpretation)
- E (Evaluate): does the signal confirm the visitor's goal was achieved? (0 = outcome unclear, 1 = goal confirmed)

Score = P + I + E. Target: 3/3 on the primary desired action; 2/3 minimum on all other interaction points.

Present as a narrow table (5 cols):

| Interaction | P | I | E | Score |
|-------------|---|---|---|-------|
| Submit click | 0 | 0 | 0 | 0/3 |
| Field blur | 1 | 0 | 0 | 1/3 |

Legend: P=Perceive, I=Interpret, E=Evaluate (Norman Gulf of Evaluation sub-stages)

**Step 3 — Feedforward Gap Scan**
For each of the 4 execution stages (Form Goal / Form Intention / Specify Action / Execute Action), identify what feedforward information the page currently provides. Count feedforward signals per stage.
A feedforward signal is any visible element that answers "what can I do / what will happen?" before the visitor acts: step indicators, field labels, CTA microcopy, input masks, required-field markers, button outcome preview.
Flag any execution stage with 0 feedforward signals as a Gulf of Execution risk (handled by sibling skill norman-gulf-of-execution-reducer, but feedforward that also functions as feedback state belongs here).

**Step 4 — State Design Specification**
For each interaction point scoring below 3/3, write the state treatment across four states:

Idle state: what the element looks like before interaction (signifier stack: shape + color contrast + label + hover treatment).

Loading state:
- Under 2s: spinner + button label changes to active verb ("Sending..." not "Submit")
- 2-10s: spinner + label + percent indicator if deterministic, "almost there" if not
- Over 10s: progress bar + estimate + cancel link

Success state: green treatment (cultural constraint), checkmark (logical constraint), confirmation copy stating the exact outcome the visitor expected ("You're in — check your inbox for access details"), and next-step instruction.

Error state: red treatment (cultural constraint), field-level highlight (not form-level), slip-error copy ("Email format needs an @ symbol") vs. mistake-error copy ("That card is declined — try a different card or PayPal"). Never "Something went wrong."

**Step 5 — Conceptual Model Alignment Check**
For the primary desired action, write out all three models:
- Designer's Model: what the designer intends to happen
- System Image (current): what the page currently shows/says in each state
- User Model (inferred): what a first-time visitor will believe is happening

Identify any gap between Designer's Model and User Model that is caused by a System Image failure. Prescribe the exact System Image change (copy, visual, timing) that closes the gap.

**Step 6 — Knowledge-in-World Shift**
List every piece of information the visitor currently must hold in memory (knowledge in the head) to complete the desired action. For each: design a visible, in-context element (knowledge in the world) that externalizes it.
Examples: required field markers, inline character counters, password strength indicators, step-count breadcrumbs, order summary panel persisting during checkout.

**Step 7 — Priority Matrix**
Rank all fixes by: (Gulf severity) x (position in funnel). Fixes at the point of the desired action rank highest. Output a prioritized implementation list with copy/visual spec for each.

## OUTPUT STRUCTURE

**1. Interaction Point Inventory** — table of all triggers + expected outcomes

**2. Gulf of Evaluation Scorecard** — P/I/E scoring table per interaction point, current scores highlighted

**3. Feedforward Gap Summary** — which execution stages have 0 feedforward signals

**4. State Design Specs** — for each scored interaction point: idle / loading / success / error treatment with exact copy and visual prescription

**5. Conceptual Model Alignment Report** — Designer Model / System Image / User Model comparison for primary action; gap analysis and fix

**6. Knowledge-in-World Shift List** — memory dependencies identified + externalization prescriptions

**7. Prioritized Implementation List** — ranked fixes with copy/visual spec, estimated lift direction

## WORKED MINI-EXAMPLE

**Page:** SaaS free-trial opt-in. Single email field + "Start Free Trial" button. Desired action: email submission.

**Audit reveals:**
- Submit click: P=0 (button does nothing visible for 1.8s), I=0, E=0. Score: 0/3.
- Field blur: P=1 (red border on invalid email), I=0 (red border has no label — visitor doesn't know what's wrong), E=0. Score: 1/3.
- Success: P=1 (page reloads), I=0 (generic "Thank you" page), E=0 (no confirmation of what happens next). Score: 1/3.

**Feedforward gap:** Zero feedforward below the button. Visitor does not know what "free trial" means, how long it lasts, or whether a credit card is required before clicking.

**State Design Output:**

Before (System Image, submit click): Button label "Start Free Trial" — no state change on click for 1.8s.

After (System Image, submit click):
- 0-100ms: button background shifts to 70% opacity, label changes to "Starting your trial..."
- 100ms-2s: spinner appears left of label
- On success: full-page transition to "You're in. Check [email] for your login link — arrives in under 2 minutes." Green header, email address reflected back (confirms correct address received).
- On error (email taken): "That email already has a trial. Log in instead?" with login link. (Mistake-type error — reframes goal.)

Before (feedforward): None below button.

After (feedforward microcopy below button): "14-day free trial. No credit card. Cancel anytime." — externalizes three memory-held uncertainties that currently suppress clicks.

**Before/After field blur:**
Before: red border, no label.
After: red border + inline label "Needs an @ symbol" (slip error — correct goal, wrong format). Green checkmark + border on valid entry (cultural constraint: green = proceed).

**Estimated lift direction:** Submission rate +12-22% (primary driver: success state closing E-stage failure; secondary: feedforward microcopy closing I-stage failure at specify-action stage).

## OUTPUT FILE
Save to: [project-folder]/Norman - Click Architecture/[YYYY-MM] - Feedback State Design - [Page Name].md
