---
name: brignull-fair-pattern-designer
description: Use when a page has a diagnosed dark pattern or ethics flag — designs the fair-pattern alternative that removes manipulation while preserving or improving conversion.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Harry Brignull (deceptivedesigns.com, 2010–2023; The 16-Pattern Taxonomy; The Disclosure Test; Honesty Spectrum Framework) — Click Architecture (Skill 6 of 7)"
interface:
  invoke: "/brignull-fair-pattern-designer"
  calls: []
  called_by: [user, brignull-field-intelligence, brignull-dark-pattern-scanner, brignull-ethical-line-mapper]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Regulatory enforcement (FTC, CMA, DSA) and platform policies evolve; a compliant design today may be flagged in 6 weeks. Re-audit after any major consent-law update."

brignull_scanner_integration:
  feeds_from: brignull-dark-pattern-scanner
  feeds_to: brignull-fair-pattern-designer
  shared_data: "Detected pattern type (from 16-Pattern Taxonomy), Conti-Sobiesk attack vector, Disclosure Test result, Roach Motel parity score"

thaler_nudge_integration:
  feeds_from: thaler-field-intelligence
  feeds_to: brignull-fair-pattern-designer
  shared_data: "Default architecture, choice framing, and mental-accounting structures that are ethically neutral and survive the Disclosure Test"

cialdini_influence_integration:
  feeds_from: cialdini-field-intelligence
  feeds_to: brignull-fair-pattern-designer
  shared_data: "Reciprocity, social proof, and commitment levers — used ONLY when the lever passes the Disclosure Test (user would still act if mechanism were disclosed)"
---

# Brignull Fair-Pattern Designer

## LAYER 1: INVARIANTS (Never override.)

1. **Disclosure Test is the hard floor.** Every replacement element produced by this skill must pass Brignull's 2023 Disclosure Test: a fully-informed user, hearing an accurate plain-language description of what the element does, would still complete the desired action. If the replacement only works because the user doesn't understand what they're agreeing to, it is still a dark pattern.
2. **Parity asymmetry is the core target.** The Roach Motel and Obstruction patterns both exploit path-resistance asymmetry. The fair-pattern fix is never "reduce CTA friction" alone — it requires equalizing conversion path vs. exit path click-counts. A fix that only smooths the in-path while leaving the out-path rough is cosmetic, not ethical.
3. **Real constraints only.** Fake Urgency and Fake Scarcity replacements must reference verifiable, real-world constraints (actual cohort size, actual deadline, actual inventory). If no real constraint exists, remove the urgency/scarcity element entirely. Do not soften the deceptive copy — replace it with factual copy or remove it.
4. **Preselection requires positive action.** Any checkbox, toggle, or default that enrolls users in communications, subscriptions, or upsells must default to off. "Neutral default" is not off — visually ambiguous states count as preselection. Each consequential consent requires its own affirmative user action.
5. **Visual parity on qualifying information.** The Honesty Spectrum Framework requires that critical qualifying information (recurring billing terms, auto-renewal date, data-sharing scope) be rendered at visual parity — matching font size and contrast ratio — with the CTA it qualifies. Dropping it to <80% contrast or <11px font while the CTA is >16px is Visual Interference regardless of technical presence on page.
6. **Confirmshaming is always removable.** There is no conversion-preserving version of shame-loaded decline copy. Replace every decline/opt-out link with neutral factual language. The test: would you read the decline text aloud to the user's regulator and feel comfortable?
7. **Forced Action bundles must be unbundled.** If the desired action (purchase, sign-up) requires an unwanted secondary action (account creation, app download, social share), the primary path must be available without the secondary requirement. Offer the bundled path as an option, not a requirement.

## LAYER 2: QUALITY GUIDANCE

1. **Name the taxonomy entry before replacing.** Every fix must begin by naming the specific Brignull pattern (from the 16-Pattern Taxonomy) or Mathur superordinate category being replaced. A fix without a named pattern is guesswork.
2. **Compute parity, don't estimate it.** For Roach Motel issues, count the actual clicks/screens for in-path vs. out-path before and after. Document both counts. "Roughly equal" is not a pass.
3. **Preserve real conversion levers.** The Disclosure Test distinguishes manipulation from persuasion. Social proof that is verified and unfiltered, scarcity that is real, urgency that reflects a genuine deadline — these are ethical and should be retained or strengthened after the dark-pattern version is removed.
4. **Apply the Honesty Spectrum as a spectrum, not a binary.** Not every omission is deliberate deception. Map each qualifying disclosure to its Spectrum position: Transparent (shown upfront) → Omission (present but not surfaced) → Deliberate Deception (actively hidden or contradicted). Fixes move elements toward Transparent; they do not all need to be in the hero section.
5. **Test the fix against the Dark Pattern Recipe inputs.** Brignull's Recipe = Applied Psychology + A/B Testing + UI Design. A fair-pattern alternative uses the same three inputs but swaps manipulative psychology (exploit against interest) for aligned psychology (inform and align with interest). Verify the replacement could survive A/B testing with fully-informed users.

## PURPOSE

This skill receives a diagnosed dark pattern (typically from brignull-dark-pattern-scanner or brignull-ethical-line-mapper) and engineers the specific fair-pattern replacement: the interface, copy, and default architecture that removes the manipulation while keeping — or improving — conversion by earning it.

**The lever (Brignull's pageActionLever):** Remove every asymmetry between the action you want the user to take and the actions you want them to avoid. Make both paths frictionless and equally visible. When conversion increases, it reflects genuine user preference — not manufactured compliance.

**The brag-line:** "We use the strongest levers known — and we know exactly where the line is."

This skill does not diagnose dark patterns (that is brignull-dark-pattern-scanner). It does not map the ethical line (that is brignull-ethical-line-mapper). It designs the replacement: concrete copy, default states, visual weight specs, and click-path architectures that pass the Disclosure Test.

## INPUT REQUIREMENTS

**Required:**
- The page (URL, screenshot, or written description with key elements)
- The ONE desired action this page must produce (click / opt-in / purchase / next-step)
- The diagnosed dark pattern(s) to replace — name the Brignull taxonomy entry or supply the brignull-dark-pattern-scanner output

**Optional (improves output quality):**
- Current conversion rate and analytics (helps calibrate what real conversion baseline looks like without the pattern)
- Audience (B2B/B2C, trust level, prior exposure to brand)
- Funnel position (top of funnel consent flows behave differently from checkout)
- Regulatory context (FTC, EU DSA, CMA — stricter jurisdictions constrain replacement options)

## EXECUTION PROCESS

**Step 1 — Identify pattern type and attack vector.**
Name the specific entry from the 16-Pattern Taxonomy (or Mathur superordinate category). Then classify using the Conti-Sobiesk Five Axes:
- Coercion (forces unwanted action)
- Confusion (deliberate ambiguity)
- Distraction (pulls attention from critical info)
- Interruption (blocks task flow)
- Obfuscation (hides important info)

Multiple axes can apply. The dominant axis determines which fix architecture to reach for first.

**Step 2 — Run the Disclosure Test on the current element.**
Write the plain-language disclosure: "This element [does X] so that [you do Y]." Read it as if to a regulator.
- If a fully-informed user would still act: it is persuasion. Flag it as a retained lever (do not remove).
- If a fully-informed user would refuse or the element requires ignorance to work: it fails. Proceed to replacement.

**Step 3 — Compute the Roach Motel Parity Score (if asymmetric friction is present).**
Count clicks/screens for: (a) in-path (enroll, subscribe, purchase) and (b) out-path (cancel, unsubscribe, decline).
Parity Score = out-path clicks / in-path clicks. Target: 1.0 (equal). Acceptable: ≤1.5 (out slightly harder is tolerable if friction serves user interest, e.g., confirming destructive action). Failing: >1.5 or out-path requires a channel not present in the in-path (phone call when sign-up was one-click).

**Step 4 — Design the fair-pattern replacement.**
For each failing element, produce:

| Element | Pattern | Axis | Replacement |
|---------|---------|------|-------------|
| [copy/UI piece] | [taxonomy name] | [C/Co/D/I/O] | [specific replacement] |

Legend: C=Coercion, Co=Confusion, D=Distraction, I=Interruption, O=Obfuscation

Replacement must specify: (a) exact copy or default state, (b) visual weight spec if Visual Interference was present, (c) any required new page element (e.g., cancellation CTA added to header).

**Step 5 — Map to Honesty Spectrum.**
For each qualifying disclosure (billing terms, auto-renewal, data scope), assign current Spectrum position and target position:
- Transparent: shown upfront, equal visual weight, no action required to see it
- Omission: present on page but requires scroll, click, or hover
- Deliberate Deception: smaller than 80% visual weight of CTA, contradictory, or absent until post-commitment

Move every disclosure to Transparent unless it is genuinely secondary (e.g., terms-of-service fine print that supplements a clearly stated summary).

**Step 6 — Draft the Retained Levers list.**
Identify persuasion elements that pass the Disclosure Test and should be kept or strengthened:
- Verified social proof (real reviews, unfiltered, with methodology disclosed)
- Real scarcity (actual cohort cap, genuine inventory count — link to live inventory state if possible)
- Real urgency (price increase on verifiable future date, enrollment deadline tied to program start)
- Aligned defaults (Thaler nudge-compatible: default to the option that benefits the user, not the business)

Each retained lever must include a brief Disclosure Test pass statement: "If we told users [X], they would still act because [Y]."

**Step 7 — Produce the Nagging Frequency Cap spec (if Nagging is present).**
For any repeated interruption (newsletter modal, push notification request, cookie upgrade prompt): specify the exact dismiss-and-suppress logic. Standard: if a user dismisses, do not resurface for ≥30 days. Do not reset the timer on new session. Store suppress state in a persistent cookie or user record, not session state.

**Step 8 — Validate against the Dark Pattern Recipe.**
Confirm the replacement could be: (a) grounded in aligned psychology (not exploitation), (b) A/B tested with fully-informed users and still win, (c) implemented in the UI without requiring user ignorance. If any component fails this check, revise before delivering.

## OUTPUT STRUCTURE

**1. Pattern Inventory (table, ≤6 cols)**
One row per diagnosed element: Element | Pattern Name | Axis | Disclosure Test | Replacement Summary

**2. Replacement Specifications**
For each failing element: exact replacement copy/default/visual spec. Numbered, one element per block.

**3. Roach Motel Parity Report**
Before: in-path clicks / out-path clicks. After: in-path clicks / out-path clicks. Parity Score before → after.

**4. Honesty Spectrum Map**
Each qualifying disclosure: current position → target position → specific change required.

**5. Retained Levers List**
Elements that pass the Disclosure Test and should be kept or strengthened, with pass statement.

**6. Nagging Spec** (if applicable)
Suppress logic, timer basis, storage mechanism.

**7. Estimated Conversion Impact**
Based on Hotels.com / comparable documented fair-pattern cases: expected direction (neutral / modest lift / moderate lift). Note: fair patterns that replace fake social proof with verified social proof and remove confusing double-negatives typically maintain or improve conversion because they increase user confidence. Do not project specific lift percentages without page-specific data.

## WORKED MINI-EXAMPLE

**Page:** SaaS subscription checkout. Desired action: complete purchase.

**Diagnosed patterns (from brignull-dark-pattern-scanner):**
1. Preselection — "Add annual upsell" checkbox pre-checked
2. Trick Wording — "Uncheck if you do not want to NOT receive marketing emails"
3. Hidden Costs — $9.99/mo shown at top; $12.49/mo (after taxes/fees) shown only at payment step
4. Confirmshaming — Decline link reads "No thanks, I prefer to pay more monthly"

**Pattern Inventory:**

| Element | Pattern | Axis | Disclosure Test | Replacement |
|---------|---------|------|-----------------|-------------|
| Pre-checked upsell | Preselection | Coercion | Fail | Default unchecked; positive click to add |
| Double-negative email | Trick Wording | Confusion | Fail | Plain affirmative: "Send me product updates" |
| Hidden $12.49 | Hidden Costs | Obfuscation | Fail | Show "$12.49/mo incl. tax" at first price display |
| Shame decline link | Confirmshaming | Coercion | Fail | "No thanks, continue monthly" |

**Roach Motel (subscription cancel vs. sign-up):**
Before: Sign-up = 3 clicks. Cancel = phone call during business hours (asymmetry: infinite).
After: Cancel = 3 clicks (Account → Billing → Cancel Subscription → Confirm). Parity Score: 1.0.

**Retained Levers:** "Join 4,200 teams using [product]" — verified customer count, passes Disclosure Test. Keep.

**Result:** Four replacements. Zero manipulative elements remain. Checkout confidence typically increases when hidden costs are removed; cart abandonment at payment step should decrease.

---

Before (Confirmshaming): "No thanks, I hate saving money"
After (Fair pattern): "No thanks, continue with monthly billing"

The after copy is factual, neutral, and would survive a regulator reading it aloud.

## OUTPUT FILE

Save to: [project-folder]/Brignull - Click Architecture/[YYYY-MM] - Fair Pattern Design - [Page Name].md
