---
name: eyal-manipulation-matrix-guard
description: Use when a page's Hook loop is designed or under review — audits whether the loop is ethical (high user benefit + low manipulation risk) or dark-pattern territory, and outputs concrete go/no-go verdicts with rewrites. Pairs with brignull-dark-patterns.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Nir Eyal (Hooked, 2014; The Manipulation Matrix; B.F. Skinner Variable-Ratio Schedule) — Click Architecture (Skill 6 of 7)"
interface:
  invoke: "/eyal-manipulation-matrix-guard"
  calls: []
  called_by: [user, eyal-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Regulatory posture (FTC, EU DSA), platform norms, and dark-pattern case law shift; a loop that was compliant 60 days ago may not be today."

eyal_cluster_integration:
  feeds_from: [eyal-hook-loop-designer, eyal-variable-reward-designer, eyal-trigger-architect, eyal-investment-escalator]
  feeds_to: [eyal-habit-zone-tester, eyal-field-intelligence]
  shared_data: "Matrix quadrant verdict + per-phase ethical score; sibling skills must halt and route to this guard before shipping a live Hook loop"

fogg_integration:
  feeds_from: [fogg-behavior-mapper, fogg-ability-auditor]
  feeds_to: [fogg-prompt-designer]
  shared_data: "Ability-friction audit flags overlap with Eyal's Six-Element Simplicity scan — share the scarcest-resource finding so Fogg skill does not re-run it"

kahneman_integration:
  feeds_from: [kahneman-framing-engineer, thaler-loss-aversion-audit]
  feeds_to: [kahneman-peak-end-architect]
  shared_data: "Loss-aversion and scarcity tactics that pass Kahneman framing review still require Matrix scoring here — ethical framing ≠ ethical loop by itself"
---

# Eyal Manipulation Matrix Guard

## LAYER 1: INVARIANTS (Never override.)

1. The Manipulation Matrix is a 2×2 grid: X-axis = does the designer USE the product (yes/no); Y-axis = does the designer BELIEVE the product materially improves users' lives (yes/no). The only ethical quadrant is top-right: Facilitator (uses it + believes in it). All other quadrants are Dealer, Entertainer, or Pusher — each with distinct risk profiles. Never soften a non-Facilitator verdict to spare a client's feelings.
2. Scoring is per Hook phase (Trigger, Action, Variable Reward, Investment), not just for the page as a whole. A loop can be ethical in three phases and dark in one — the dark phase poisons the loop.
3. Variable reward is Skinner's variable-ratio schedule applied to humans. It is the highest-leverage and highest-risk lever: reward variability that serves user goals = ethical; variability that serves retention metrics at the expense of user wellbeing = manipulation. Diagnose by asking: "If the variability were removed, would the user's life improve or worsen?"
4. The Investment phase must store value FOR THE USER, not just extract switching-cost lock-in for the company. Data collected must be used to make the next experience more relevant to that user within the same session or the next session. Harvesting data without returning value is Dealer behavior.
5. The Six-Element Simplicity audit (Time, Money, Physical effort, Brain cycles, Social deviance, Non-routine) is a diagnostic tool, not a permission slip. Eliminating friction is ethical only when it helps users reach goals they already have. Eliminating friction to accelerate behaviors users would regret is manipulation.
6. Internal trigger installation (linking product use to pre-existing emotions like loneliness, boredom, fear) must target emotions the user WANTS to resolve. Exploiting emotions the user wants to suppress (anxiety, shame) to drive product use is Pusher behavior regardless of conversion rates.
7. No verdict is issued without a concrete rewrite. Every failing element gets a compliant alternative — not just a red flag.

## LAYER 2: QUALITY GUIDANCE

1. Use Eyal's exact quadrant names (Facilitator, Dealer, Entertainer, Pusher) in every verdict. Generic labels like "ethical concern" or "dark pattern" lack the diagnostic precision the Matrix provides.
2. A page that scores Facilitator on the Matrix can still fail on a specific phase. Always decompose the overall quadrant verdict into phase-level scores before writing recommendations.
3. Pair every manipulation finding with its Brignull dark-pattern name if one applies (Roach Motel, Trick Questions, Hidden Costs, Confirmshaming, etc.) — cross-referencing sharpens the client brief and satisfies the eyal-brignull pairing role of this skill.
4. Worked rewrites must be concrete enough to hand to a copywriter or developer with no further briefing required.
5. Measurement criteria must be stated for every rewrite — how will the client know the rewrite achieved ethical compliance without sacrificing conversion?

## PURPOSE

This skill applies Eyal's Manipulation Matrix to a live web page's Hook loop, auditing each phase (Trigger, Action, Variable Reward, Investment) for ethical compliance and outputting go/no-go verdicts with mandatory rewrites for every failing element.

It is the ethics gate for the eyal-* cluster. It runs AFTER the loop is designed (eyal-hook-loop-designer) and BEFORE the loop goes live. It pairs with Brignull dark-pattern detection because manipulation in Eyal's framework and deceptive design in Brignull's framework frequently co-occur.

**Brag line:** "Our product builds a return habit, by design — and our ethics review proves it."

The lever this skill controls: distinguishing between habit-forming design that serves the user (Facilitator) and habit-forming design that extracts from the user (Dealer, Entertainer, Pusher). The distinction is not philosophical — it determines regulatory exposure, refund rates, chargeback rates, long-term LTV, and brand trust. Facilitator loops compound. Dealer loops erode.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description of all page elements
- The ONE desired action (e.g., "opt-in to email list," "purchase," "start free trial")
- The designer's answers to two Matrix calibration questions:
  - Q1: Do you personally use this product regularly? (Yes / No / Sometimes)
  - Q2: Do you genuinely believe this product materially improves users' lives? (Yes / No / Unsure)

**Optional but high-value:**
- Session recording or heatmap data showing where users drop off
- Current conversion rate and 7-day return visit rate
- Any existing trigger copy (emails, push notifications, ads driving traffic to this page)
- Funnel position (cold traffic, warm retargeting, existing customer upsell)

## EXECUTION PROCESS

### Step 1 — Matrix Quadrant Assignment (2 min)

Plot the designer's Q1 + Q2 answers on the 2×2:

| | Uses Product | Does Not Use |
|---|---|---|
| **Believes improves lives** | FACILITATOR (ship) | ENTERTAINER (proceed with caution) |
| **Does not believe** | DEALER (redesign) | PUSHER (halt) |

**Legend:** Uses = Q1 Yes/Sometimes; Believes = Q2 Yes

State the quadrant explicitly. If Dealer or Pusher: the loop cannot ship as designed. If Entertainer: proceed to phase audit with heightened scrutiny on Investment and Variable Reward phases.

### Step 2 — Phase-Level Ethical Audit

Score each Hook phase on a 3-point scale: PASS / WARN / FAIL.

**Trigger phase — audit criteria:**
- PASS: headline/subhead names an internal emotional state the user wants to resolve (boredom, uncertainty, frustration) AND the product actually resolves it.
- WARN: trigger names an emotion the user experiences but product only partially addresses.
- FAIL: trigger exploits an emotion the user wants to suppress (shame, inadequacy) without genuine resolution, OR uses manufactured urgency (false countdown, fabricated scarcity).

**Action phase — audit criteria (Six-Element Simplicity):**
- Identify the scarcest resource blocking action. For cold traffic, default assumption: Brain cycles and Non-routine are the bottleneck.
- PASS: friction reduction targets the scarcest resource; form fields match minimum required for the next step only.
- WARN: friction reduction is real but over-reduces (e.g., one-click checkout that bypasses informed consent for subscription).
- FAIL: friction reduction is asymmetric — easy to enter, hard to exit (Roach Motel pattern); or pre-checked boxes for upsells (Trick Questions).

**Variable Reward phase — audit criteria:**
- Test: "If this variability were removed, would the user's life improve or worsen?"
- PASS: variability delivers unpredictable genuine value (curated content, personalized result, surprise bonus relevant to user's stated goal).
- WARN: variability is neutral — novelty for its own sake, not harmful but not serving user goals.
- FAIL: variability exploits loss-aversion (fake "only 2 left" on digital goods), social anxiety (showing who viewed your profile to drive return visits), or delivers dopamine without value (infinite scroll with no endpoint).

**Investment phase — audit criteria:**
- Test: "Is the data/effort collected here used to improve THIS user's experience in the next session?"
- PASS: stored value (preferences, history, progress) is returned to user in next trigger — personalized email, tailored content, remembered progress.
- WARN: stored value improves company targeting but user benefit is indirect and delayed.
- FAIL: investment is extraction — data collected never improves user experience; switching cost is the only purpose (e.g., forcing profile completion that serves ad targeting, not user).

### Step 3 — Brignull Cross-Reference

For every WARN or FAIL, check against these dark-pattern names:
- Roach Motel: easy in, hard out (Investment FAIL)
- Confirmshaming: opt-out copy that shames the user (Trigger FAIL)
- Trick Questions: pre-checked boxes, confusing toggles (Action FAIL)
- Hidden Costs: unexpected charges revealed at Investment phase (Action/Investment FAIL)
- Misdirection: attention drawn away from the exit path (Variable Reward WARN/FAIL)
- Social Proof Manipulation: fake reviews, inflated counts (Variable Reward FAIL)

Name the Brignull pattern in the finding. Unnamed patterns are harder to brief to legal/compliance teams.

### Step 4 — Verdict Table

Build a 5-column table (fits a standard markdown pane):

| Phase | Score | Issue | Brignull | Fix |
|---|---|---|---|---|
| Trigger | PASS/WARN/FAIL | Brief description | Pattern name or — | Rewrite directive |
| Action | ... | ... | ... | ... |
| V. Reward | ... | ... | ... | ... |
| Investment | ... | ... | ... | ... |

**Legend:** V. Reward = Variable Reward phase

**Threshold for shipping:** All four phases must be PASS or WARN. Any FAIL = loop does not ship until rewrite is verified.

### Step 5 — Mandatory Rewrites

For every WARN or FAIL: write the compliant alternative in full. Not a directive — the actual copy, field configuration, or UX instruction. State the measurement that confirms the rewrite is working.

**Rewrite format:**
- Element: [what it is]
- Before: [current state]
- After: [compliant version]
- Measure: [metric + threshold that confirms compliance without conversion loss]

### Step 6 — Facilitator Confirmation Statement

If all phases pass: draft a one-paragraph Facilitator Confirmation the client can use internally to document ethical review. Include: date, page URL, desired action, phase scores, and the designer's Q1/Q2 answers on record.

## OUTPUT STRUCTURE

1. **Matrix Quadrant** — Assigned quadrant with Q1/Q2 answers on record
2. **Phase Audit Table** — 4-row verdict table (Trigger / Action / Variable Reward / Investment)
3. **Brignull Flags** — Named dark patterns found (or "None identified")
4. **Mandatory Rewrites** — One before/after block per WARN or FAIL, with measurement
5. **Ship/Hold Verdict** — Single sentence: "Loop clears ethical review — ship" OR "Loop is on hold: [N] phase(s) require rewrite before launch"
6. **Facilitator Confirmation** (if all PASS) — Paragraph for internal documentation

## WORKED MINI-EXAMPLE

**Page:** SaaS tool opt-in page, cold traffic. Desired action: email opt-in for free trial.

**Matrix calibration:** Designer uses the tool daily (Q1 = Yes). Designer believes it saves 2+ hours/week for users (Q2 = Yes). Quadrant: **FACILITATOR**.

**Phase audit:**

| Phase | Score | Issue | Brignull | Fix |
|---|---|---|---|---|
| Trigger | PASS | Headline names "drowning in busywork" — genuine internal state | — | None |
| Action | WARN | Form has 4 fields; only email needed for trial start | — | Reduce to email only; collect name at onboarding step 2 |
| V. Reward | FAIL | Thank-you page shows "Only 47 trial slots left" — digital product, no real scarcity | Misdirection | Remove false scarcity; replace with unexpected bonus content reveal |
| Investment | PASS | Preference question ("What's your biggest bottleneck?") used to personalize day-1 email | — | None |

**Mandatory rewrites:**

Action — Brain cycles fix:
- Before: Name, Company, Email, Job Title fields
- After: Email field only, with subtext "We'll ask about your role after you log in"
- Measure: Form completion rate lifts to ≥ 65%; no increase in unsubscribe rate at day 7

Variable Reward — False scarcity removal:
- Before: "Only 47 trial slots remaining — claim yours now"
- After: "Your trial is ready. We've also unlocked our [Specific Resource Name] — usually reserved for paid members."
- Measure: Thank-you page exit rate drops; 7-day return visit rate holds or improves vs. baseline

**Ship/Hold Verdict:** Loop is on hold — 1 phase (Variable Reward) requires rewrite before launch.

## OUTPUT FILE

Save to: [project-folder]/Eyal - Click Architecture/[YYYY-MM] - Manipulation Matrix Guard.md
