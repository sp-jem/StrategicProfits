---
name: nielsen-heuristic-evaluation
description: Use when a page has conversion friction you can't locate — runs Nielsen's 10 Usability Heuristics as a structured page audit with severity scores and concrete fixes for the desired action.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Jakob Nielsen & Kara Pernice (10 Usability Heuristics 1994/2020; F-Pattern 2006; Four Scanning Patterns 2017; Banner Blindness 1997/2023; Page Fold Gradient 2018; UX Time-Scale Model 2024; 4 Web Credibility Factors 2016; Inverted Pyramid 1996; CTA Link Promise 2014) — Click Architecture (Skill 1 of 7)"
interface:
  invoke: "/nielsen-heuristic-evaluation"
  calls: []
  called_by: [user, nielsen-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page copy, CTAs, and layout change frequently; heuristic violations that were fixed can re-emerge after redesigns or A/B test deployments."

nielsen_f_pattern_integration:
  feeds_from: nielsen-f-pattern-layout-auditor
  feeds_to: nielsen-scannability-optimizer
  shared_data: "Fixation map + scanning pattern identified (F / Spotted / Layer-Cake / Commitment) — used to prioritize which heuristic violations are above-fold and highest-impact."

eisenberg_integration:
  feeds_from: eisenberg-buying-modality-classifier
  feeds_to: eisenberg-landing-anatomy-architect
  shared_data: "Visitor modality (Competitive / Spontaneous / Humanistic / Methodical) determines which heuristics (Heuristic 7 minimalism for Spontaneous; Heuristic 6 recognition for Methodical) to weight highest in severity scoring."

fogg_integration:
  feeds_from: fogg-ability-auditor
  feeds_to: fogg-prompt-designer
  shared_data: "Ability barriers identified by Fogg (time, money, physical, brain cycles, social deviance, non-routine) map directly to Heuristic 5 (Error Prevention) and Cognitive Load Reduction violations; share severity list before prompt placement."
---

# Nielsen Heuristic Evaluation

## LAYER 1: INVARIANTS (Never override.)

1. Every diagnosis is page-action-specific. The output is not "usability issues in general" — it is usability violations that impede the ONE stated desired action (click / opt-in / purchase / next-step).
2. Use the UX Time-Scale Model thresholds as hard standards: 50ms aesthetic impression, 0.1s feedback ceiling, 10s patience window before abandonment. Any violation that fires within the 10-second window is Priority 1.
3. The five conversion-critical heuristics on landing and checkout pages are H1 (Visibility of Status), H4 (Consistency), H5 (Error Prevention), H6 (Recognition over Recall), and H7 (Aesthetic & Minimalist Design). These are scored first and always weighted highest.
4. Information Scent is the scroll trigger. A visitor will not scroll to a CTA if above-fold content does not signal that relevant value exists below. Every heuristic violation that degrades scent is an abandonment lever, not just a UX issue.
5. The Inverted Pyramid is law: value proposition and primary CTA must be visible before the fold. Benefits precede proof. Proof precedes detail. Detail precedes background. Any inversion is automatically a Priority 1 violation.
6. The CTA Link Promise is binding: the label on every button must match exactly what appears after clicking. Mismatch = promise broken = competitor visit.
7. Severity is rated 0–4 using Nielsen's own scale (0=not a usability problem, 1=cosmetic, 2=minor, 3=major, 4=catastrophic). Only severity 3 and 4 findings appear in the Priority Fix table.

## LAYER 2: QUALITY GUIDANCE

1. Ground every violation in a named framework from the dossier — cite the heuristic number, the scanning pattern, the time threshold, or the credibility factor. No generic "best practice" observations.
2. Each fix must be a concrete on-page change: element to move, word to change, visual property to alter. Not "improve clarity" — "replace 'Get Started' with 'Start Free 30-Day Trial — No Card Required'."
3. When the page has a form, apply all four Cognitive Load Reduction Principles (Structure, Transparency, Clarity, Support) as a sub-checklist within H5/H6.
4. Banner Blindness check is mandatory on every page: flag any CTA, offer box, or form that uses ad-pattern visual properties (colored border, rounded rectangle, contrasting background, right-column placement). These will be ignored.
5. Credibility scan covers all four factors: Design Quality, Upfront Disclosure, Correct/Current Content, Third-Party Validation. A missing credibility element on a page asking for money or personal data is automatically severity 3.

## PURPOSE

Nielsen's 10 Usability Heuristics are the only conversion framework built on what users' eyes and brains actually do — verified across 57,000+ eyetracking fixations, decades of hallway tests, and quantified attention gradients. This skill runs those heuristics as a structured severity audit against a specific page and desired action, then outputs a ranked fix list ordered by conversion impact.

**Brag-line:** "We place CTAs where eyes actually land, not where we hope."

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description (above-fold content + CTA location + form fields if any)
- The ONE desired action: e.g., "click Add to Cart," "complete email opt-in," "purchase $997 course"

**Optional (improves scoring accuracy):**
- Analytics: bounce rate, scroll depth, time-on-page, heatmap or click data
- Audience: awareness level, technical sophistication, prior brand exposure
- Funnel position: cold traffic vs. retargeting vs. warm email list

## EXECUTION PROCESS

### Step 1 — Fold & Time Audit (60 seconds)
Identify the fold boundary. Classify what is visible in the first 10 seconds of viewing (the patience window).
- Does the value proposition appear above fold? (Inverted Pyramid rule)
- Is the primary CTA visible before the fold? Score: Yes / Partially / No
- Is the CTA label a specific promise or a vague generic? (CTA Link Promise Principle)
- Flag any content that appears only below the third screenful (negligible attention per Page Fold Gradient: 74% of viewing time in first two screenfuls; practically zero below fold three).

### Step 2 — Scanning Pattern Prediction
Without formal eyetracking, predict the scanning pattern the visitor will adopt based on formatting cues:
- Unbroken text block → F-Pattern (worst for comprehension; users read left edge only after the second horizontal sweep)
- Bold/colored/linked words present → Spotted Pattern (user jumps to styled words; ensure styled words are conversion-relevant, not decorative)
- Meaningful subheadings present → Layer-Cake Pattern (most effective for users seeking specific information; goal pattern for most conversion pages)
- High-motivation, trusted source → Commitment Pattern (full reading; rare on cold traffic)

Record predicted pattern. Violations that force an F-Pattern on a conversion page are severity 3 minimum.

### Step 3 — 10 Heuristic Scan
Score each heuristic for the desired action. Use severity scale 0–4.

| H# | Heuristic | Conversion-Critical? | Audit Question |
|----|-----------|---------------------|----------------|
| H1 | Visibility of System Status | Yes | After any action (click, form submit, page load), is there immediate feedback within 0.1s? Does the page show progress indicators? |
| H2 | Match System to Real World | Yes | Does the page use visitor language or internal jargon? Are prices, units, and terms the visitor's native vocabulary? |
| H3 | User Control & Freedom | Yes | Is there a clear "emergency exit" — back, undo, cancel — that prevents abandonment anxiety? |
| H4 | Consistency & Standards | Yes | Does every interactive element follow platform conventions? Would a first-time visitor know immediately what is clickable? |
| H5 | Error Prevention | Yes | Are mistakes prevented before submission? Are required fields marked upfront? Does the CTA make the risk of clicking clear? |
| H6 | Recognition over Recall | Yes | Are all needed facts (price, guarantee, next step) visible without requiring the visitor to remember from a prior section? |
| H7 | Aesthetic & Minimalist Design | Yes | Does every element on the page compete with the desired action? (Every extra unit of information diminishes relevant units.) |
| H8 | Error Recovery | No (edge) | Are error messages specific and constructive? ("Email already in use — log in instead" not "Invalid input") |
| H9 | Flexibility & Efficiency | No (edge) | Can experienced visitors shortcut to the action without reading everything? |
| H10 | Help & Documentation | No (edge) | Is help accessible without leaving the page? FAQs, tooltips, or chat — not a separate site. |

### Step 4 — Banner Blindness Check
Inspect every CTA, offer box, sidebar, and pop-up for ad-pattern visual properties:
- Colored border or contrasting background color → flag
- Rounded-rectangle button in a column right of body text → flag
- Placement in right rail → flag (users have learned to ignore right columns entirely)
- Stock-photo imagery in proximity to offer → flag (faces bypass blindness; stock does not)

Any flagged element containing the desired-action CTA is an automatic severity 4 if the page's primary goal is the flagged element.

### Step 5 — Credibility Scan (4 Factors)
Rate each factor present/partial/absent:
1. Design Quality: professional appearance, no typos, no broken links, organized navigation
2. Upfront Disclosure: pricing visible before CTA, return/refund policy linked, contact info present
3. Correct/Current Content: real photos of actual product/service, staff visible if relevant, testimonials dated
4. Third-Party Validation: external reviews linked or displayed, press logos present, trust seals

Any "absent" on a page asking for money or personal data = severity 3.

### Step 6 — Form Cognitive Load Audit (if form present)
Apply the 4 Cognitive Load Reduction Principles:
- **Structure:** Single-column layout? Related fields grouped? Progressive disclosure for complex flows?
- **Transparency:** Completion time stated? Required materials listed before start? Step indicator shown?
- **Clarity:** 6th-8th grade reading level? One question per field? Input length matches expected answer?
- **Support:** Labels outside fields (not placeholder-as-label)? Errors next to offending field? No premature validation? Constructive error messages?

Each violated principle = severity 2 minimum; severity 3 if the form is the desired action.

### Step 7 — Priority Fix Table
List all severity 3 and 4 findings. Order by: severity descending, then by position on page ascending (above-fold violations first).

| Sev | Heuristic | Violation | Fix | Est. Impact |
|-----|-----------|-----------|-----|-------------|
| 4 | H7 | [finding] | [specific change] | [what changes] |
| 3 | H5 | [finding] | [specific change] | [what changes] |

## OUTPUT STRUCTURE

**Section 1 — Audit Header**
Page URL/description, desired action, fold boundary, predicted scanning pattern, date.

**Section 2 — Heuristic Severity Grid**
All 10 heuristics scored 0–4 with one-sentence justification each.

**Section 3 — Banner Blindness Flags**
List of elements with ad-pattern properties and their locations.

**Section 4 — Credibility Factor Summary**
Present / Partial / Absent for each of the 4 factors.

**Section 5 — Form Cognitive Load Report** (if applicable)
Pass/fail for each of the 4 principles with specific field-level notes.

**Section 6 — Priority Fix Table**
Severity 3–4 items only, ordered by impact. Each row: element to change, exact new copy or layout instruction, expected behavior change.

**Section 7 — Quick Wins**
Severity 1–2 items that take under 10 minutes to implement. Bulleted list.

## WORKED MINI-EXAMPLE

**Page:** SaaS pricing page. Desired action: click "Start Free Trial."

**Before (observed):**
- CTA button reads "Get Started" — vague; no promise of what happens next.
- Button placed in right-hand column alongside a comparison chart — ad-pattern placement.
- Pricing section appears below fold 2; page opens with a hero image and testimonial carousel.
- Form on click requires email, company name, team size, phone number — 4 fields before trial begins.
- No refund or cancellation policy visible anywhere above the CTA.

**Heuristic findings:**
- H7 Severity 4: Hero image + carousel above fold competes with CTA; no value prop visible in 10-second window.
- H6 Severity 4: Price not visible without scrolling; visitor must remember it from a prior session or scroll back.
- H5 Severity 3: Form requires phone number with no explanation; unexpected requirement triggers abandonment anxiety.
- H4 Severity 3: "Get Started" is ambiguous; CTA Link Promise broken — visitor expects a dashboard, lands on a form wall.
- Credibility: Upfront Disclosure absent (no visible price, no cancellation terms) = severity 3.
- Banner Blindness: CTA in right column = severity 4.

**After (fixes applied):**
- CTA label changed to "Start Your Free 14-Day Trial — Cancel Anytime."
- CTA moved to center of page, below a 3-bullet value summary, above fold on 1440px viewport.
- Hero image replaced with a single product screenshot showing the core use case.
- Pricing table moved above fold 1, immediately after value prop.
- Form reduced to email only at first step; company/team size collected in-app post-activation.
- "No credit card required. Cancel any time." added in plain gray text directly beneath CTA button.
- Right-rail comparison chart moved to its own below-fold section.

**Predicted scanning pattern shift:** F-Pattern → Layer-Cake (subheadings now guide eye to price, then to CTA, then to social proof).

## OUTPUT FILE
Save to: [project-folder]/Nielsen - Click Architecture/[YYYY-MM] - Heuristic Evaluation - [Page Name].md
