---
name: nielsen-hallway-test-designer
description: Use when a page is pre-launch or underperforming — designs a 5-user hallway usability test grounded in Nielsen/Pernice frameworks to expose conversion blockers before real traffic hits.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Jakob Nielsen & Kara Pernice (Eyetracking Web Usability 2010; 10 Heuristics 1994/2020; Four Scanning Patterns 2017) — Click Architecture (Skill 6 of 7)"
interface:
  invoke: "/nielsen-hallway-test-designer"
  calls: []
  called_by: [user, nielsen-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Conversion page copy, CTAs, and audience expectations shift with offers and ad copy; test protocols older than 45 days may target stale hypotheses."

nielsen_heuristic_evaluation_integration:
  feeds_from: nielsen-heuristic-evaluation
  feeds_to: nielsen-hallway-test-designer
  shared_data: "Heuristic violations flagged (H1–H10 scores) become hallway task scenarios — each critical violation gets a test task that directly probes whether real users hit that same wall."

nielsen_scannability_optimizer_integration:
  feeds_from: nielsen-scannability-optimizer
  feeds_to: nielsen-hallway-test-designer
  shared_data: "Scannability audit zones (Layer-Cake vs F-Pattern triggers) map to think-aloud prompts; tester observes whether users actually scan as predicted or fall into F-Pattern default."

eisenberg_field_intelligence_integration:
  feeds_from: eisenberg-field-intelligence
  feeds_to: nielsen-hallway-test-designer
  shared_data: "Eisenberg buying-modality profiles (competitive/spontaneous/methodical/humanistic) shape which participant profile to recruit; methodical users expose form friction, spontaneous users expose CTA clarity gaps."
---

# Nielsen & Pernice — Hallway Test Designer

## LAYER 1: INVARIANTS (Never override.)

1. **Five users is the threshold.** Nielsen's ROI curve peaks at 5 participants for finding 85% of usability problems. Test 3 if pressed for time. Never test 1. Never justify 10+ for a hallway test — that is a quantitative study, not a diagnostic.
2. **Tasks must mirror the desired action.** Every task scenario is written around the ONE conversion goal (click / opt-in / purchase). Tasks that wander into general exploration produce navigation data, not conversion data.
3. **Think-aloud is non-negotiable.** Silent observation misses the cause. The protocol is concurrent think-aloud: "Tell me what you're thinking as you go." Never retrospective for hallway tests — memory degrades within 90 seconds.
4. **Facilitator does not help.** When a participant is stuck, the facilitator's only permitted response: "What would you do if I weren't here?" Helping invalidates the observation.
5. **Observe eyes, not clicks.** A click is a downstream event. The diagnostic data lives upstream: where participants look first, where they pause, where they re-read, where they express confusion aloud. Use a screen recorder + webcam minimum.
6. **One desired action per test session.** Each test session validates one page's one conversion goal. Multi-page funnels require separate sessions per page.
7. **Session cap: 45 minutes.** Participants beyond 45 minutes give fatigued, unreliable think-aloud. Keep task sets to 3-5 tasks. Trim ruthlessly.

## LAYER 2: QUALITY GUIDANCE

1. **Recruit for fit, not convenience.** "Hallway" means fast, not random. Participants must match the real audience's familiarity with the problem space. A developer testing a personal-finance opt-in page is not a valid hallway participant.
2. **Pre-test the tasks.** Run each task scenario on yourself or a colleague first. If the task is ambiguous or guides the user toward the answer, rewrite it before the session.
3. **Document issues in severity tiers.** After each session: (A) Catastrophic — prevents task completion; (B) Major — causes significant struggle; (C) Minor — friction without failure. Fix all A's before launch. Ship the page with remaining B's tracked.
4. **Debrief within 15 minutes of each session.** Observation notes go cold. Write key findings immediately after each participant, not at end of day.
5. **Do not average participants.** Participant 2 finding a catastrophic blocker Participant 1 missed is not a "mixed result" — it is a launch risk. Report individual findings, then patterns.

## PURPOSE

Nielsen & Kara Pernice's research showed that 5 users expose 85% of a page's usability problems — and that what users say they will do bears almost no relation to what their eyes and hands actually do when given a real task. This skill uses their hallway-test method to catch conversion blockers — misaligned F-Pattern triggers, scent failures, banner-blind CTAs, credibility gaps, cognitive-load spikes on forms — before real traffic amplifies them into revenue leaks.

**Brag line: "We place CTAs where eyes actually land, not where we hope."**

This skill's lane: test design, participant protocol, task writing, observation framework, and severity triage. Heuristic evaluation of the page (pre-test input) belongs to `nielsen-heuristic-evaluation`. Post-test layout changes belong to `nielsen-scannability-optimizer` and `nielsen-attention-zone-placer`.

## INPUT REQUIREMENTS

**Required:**
- The page: live URL, staging URL, screenshot set, or written description of each above-fold section
- The ONE desired action: exact conversion goal (e.g., "click the 'Get Instant Access' button", "complete the opt-in form", "reach the checkout confirmation screen")

**Optional but sharpen the test:**
- Heuristic evaluation output from `nielsen-heuristic-evaluation` (maps violations to task scenarios)
- Scannability audit from `nielsen-scannability-optimizer` (identifies which page sections to probe)
- Audience profile: age range, technical fluency, prior awareness of the offer
- Existing analytics: bounce rate, scroll depth, form abandonment rate
- Funnel position: cold traffic landing page vs. warm retargeting page vs. existing-customer upsell

## EXECUTION PROCESS

### Step 1 — Hypothesis Inventory (Pre-Test, 20 min)

List every suspected conversion blocker on the page. Source these from:
- Heuristic violations already flagged (pull from `nielsen-heuristic-evaluation` output if available)
- Page Fold Attention Gradient: is the value proposition visible in the first 600px? Content above fold gets 102% more views than 100px below. If the primary CTA is below fold 2, it receives near-zero organic attention.
- Banner Blindness check: does any CTA, form, or offer block use colors, borders, rounded corners, or right-rail placement that pattern-matches to ads?
- Information Scent: does the above-fold copy signal clearly that what the user is looking for exists on this page?
- Credibility gaps (4 Credibility Factors): missing pricing, no third-party validation, stock photography instead of real service images.

**Output:** A ranked hypothesis list, max 7 items. Each item states: suspected problem → which framework predicts it → what observable behavior would confirm it.

### Step 2 — Participant Criteria (15 min)

Define minimum viable participant profile:

| Criterion | Specification |
|-----------|---------------|
| Familiarity | Aware of the problem the offer solves (not the offer itself) |
| Excluded | Anyone who works in UX, marketing, or has seen the page |
| Count | 5 (minimum 3 if time-constrained) |
| Format | 1-on-1, not groups; concurrent think-aloud |
| Session length | 30-45 min per participant |

Recruitment channels for speed: colleague referrals, LinkedIn message to non-marketers in the target demo, Respondent.io or UserTesting.com panel (24-48hr turnaround, $30-75/participant).

### Step 3 — Task Script Construction

Write 3-5 tasks. Each task maps to one hypothesis from Step 1.

**Task anatomy (use this template for every task):**
```
Context sentence: [Place participant in realistic scenario — no hints about the page]
Task: [Specific observable completion state]
Completion criterion: [What counts as task success — be exact]
```

**Example tasks for a course opt-in page (desired action: complete the email opt-in form):**

Task 1 — Information Scent / Value Proposition
> "You just clicked an ad that said [headline matching real ad]. You've landed here. Tell me out loud what you think this page is offering and who it's for."
> Completion: Participant states offer accurately within 10 seconds. (Tests whether above-fold copy delivers scent fast enough given the 10-second patience window from the UX Time-Scale Model.)

Task 2 — Desired Action Discovery
> "Without me telling you anything, show me what you'd do next if you were genuinely interested."
> Completion: Participant attempts to interact with the opt-in form or primary CTA. (Tests CTA visibility and Link Promise clarity — does the CTA label match participant's mental model of what happens next?)

Task 3 — Credibility Probe
> "Before you'd enter your email, what questions would you need answered? Look for the answers on this page."
> Completion: Participant either finds the answer or states it's missing. (Tests 4 Credibility Factors: upfront disclosure, social proof visibility, real vs. stock imagery.)

Task 4 — Form Completion
> "Go ahead and complete the form as if you were signing up for real. Use test@test.com if you prefer not to use your real email."
> Completion: Participant reaches the confirmation state. (Tests 4 Cognitive Load Reduction Principles: structure, clarity, error messages, field labeling.)

Task 5 — Recall / Heuristic 6
> [After form completion, blank the screen] "Without looking at the page — what was the main benefit the page promised you?"
> Completion: Participant recalls primary value prop. (Tests Recognition over Recall — if they can't recall it without prompts, the page failed Heuristic 6.)

### Step 4 — Observation Framework

During each session, the note-taker (not the facilitator) logs in real time:

**4-column observation log:**

| Time | Quote / Behavior | Page Location | Hypothesis # |
|------|-----------------|---------------|--------------|
| 0:43 | "I don't know what they want me to do" | Below hero | H2 |
| 1:12 | Re-read headline 3x, then scrolled past CTA | Hero CTA | H1 |

After each session, classify every observation:
- **A — Catastrophic:** task failure or explicit intent to abandon
- **B — Major:** visible confusion, re-reading, hesitation >8 seconds, wrong interpretation
- **C — Minor:** slight friction, recovers without failure

**Eye-movement proxies (no eye-tracker required):**
- Mouse hesitation over element = fixation proxy
- Scroll-then-scroll-back = F-Pattern stem caught; user re-scanning left column
- Long hover without click = Link Promise mismatch (participant uncertain what happens next)
- Scroll past CTA without pause = Banner Blindness or scent failure

### Step 5 — Severity Triage Report

After all 5 sessions, consolidate into a triage table:

| # | Finding | Sev | Framework | Fix |
|---|---------|-----|-----------|-----|
| 1 | CTA not found in 10s | A | Fold Gradient | Move CTA above 600px |
| 2 | Offer unclear to 4/5 | A | Info Scent | Rewrite hero headline |
| 3 | Price missing = distrust | B | 4 Credibility | Add pricing block above form |
| 4 | Form label in placeholder | B | Cognitive Load | Move labels outside fields |
| 5 | Right-rail email box | B | Banner Blind | Move form inline, center |

**Legend:** Sev A = fix before launch; Sev B = fix in v1.1; Sev C = backlog.

**Launch decision rule:**
- 0 Severity A findings: launch cleared
- 1+ Severity A findings: do not launch; fix and retest with 3 users minimum
- 3+ Severity B findings concentrated in one page section: treat as undiscovered Severity A

### Step 6 — Retest Threshold

After fixes: retest only the tasks that produced A or B findings. Full 5-user retest is unnecessary. 3 participants on targeted tasks confirms resolution.

## OUTPUT STRUCTURE

**Section 1 — Hypothesis Inventory**
Ranked list of suspected blockers with framework source.

**Section 2 — Participant Criteria**
Profile spec + recruitment channel recommendation + screener questions (2-3 max).

**Section 3 — Task Script**
3-5 tasks in full template format with completion criteria.

**Section 4 — Observation Log Template**
Pre-formatted 4-column sheet ready for the note-taker.

**Section 5 — Severity Triage Table**
Consolidated findings post-sessions, launch/hold decision, specific fixes.

**Section 6 — Retest Plan**
Which tasks to rerun, how many participants, pass threshold.

## WORKED MINI-EXAMPLE

**Page:** Supplement brand landing page. Desired action: complete the email opt-in to receive a free guide.

**Pre-test hypothesis (top 3):**
1. Hero CTA ("Learn More") violates Link Promise — users expect information not a signup wall. Framework: CTA Link Promise Principle.
2. CTA positioned in right rail — Banner Blindness will cause most users to skip it. Framework: Banner Blindness Law.
3. No visible price or refund terms above fold — credibility gap will cause hesitation before form entry. Framework: 4 Credibility Factors.

**Participant 2, Task 2 observation:**
> 0:22 — Scans hero headline, reads first two words of subhead only (F-Pattern).
> 0:31 — Eyes move to left column, never to right rail.
> 0:38 — "I'm not sure what I'd click... is there a button somewhere?"
> 0:41 — Finds right-rail box only after facilitator prompt. Classified: Severity A, Banner Blindness confirmed.

**Fix applied:**
- Before: Email opt-in form in right rail, blue border, white background.
- After: Inline form centered below hero copy, no border, matching page background color, plain text label "Enter your email to get the free guide."

**Retest (3 users):** All 3 completed Task 2 within 15 seconds. Severity A resolved.

## OUTPUT FILE
Save to: [project-folder]/Nielsen-Pernice - Click Architecture/[YYYY-MM] - Hallway Test Design.md
