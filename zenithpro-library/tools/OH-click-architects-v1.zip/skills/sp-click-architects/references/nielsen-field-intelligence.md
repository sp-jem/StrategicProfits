---
name: nielsen-field-intelligence
description: Use when you have run 4+ individual nielsen-* skill audits on a page and need cross-skill synthesis — finds convergence zones, resolves contradictions, delivers The Single Move, and integrates Nielsen attention data with the full Click Architect thinker network.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Jakob Nielsen & Kara Pernice (10 Usability Heuristics 1994/2020; Eyetracking Web Usability 2010; F-Pattern 2006; Four Scanning Patterns 2017; Banner Blindness 1997/2023; Information Scent; Page Fold Attention Gradient; UX Time-Scale Model; Web Credibility Factors; Cognitive Load Reduction; Inverted Pyramid) — Field Intelligence (Skill 7 of 7)"
interface:
  invoke: "/nielsen-field-intelligence"
  calls: [nielsen-heuristic-evaluation, nielsen-f-pattern-layout-auditor, nielsen-banner-blindness-detector, nielsen-attention-zone-placer, nielsen-scannability-optimizer, nielsen-hallway-test-designer]
  called_by: [user, click-architects]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Eyetracking patterns and scanning behaviors shift as page conventions change. Individual skill outputs older than 45 days may reflect outdated page context. Reassess quarterly minimum."
pirolli_integration:
  feeds_from: [pirolli-field-intelligence]
  feeds_to: [pirolli-scent-trail-auditor]
  shared_data: "Pirolli maps information-scent gradients and foraging cost. Nielsen maps where eyes physically land. Combined: scent is only actionable if it lands in an attention zone. Nielsen's F-stem (left-rail scan) and Layer-Cake subheadings ARE the scent trail — if the most cost-efficient scent cues are right-rail or unfeatured body text, no behavioral prediction holds. The synthesis reveals whether the page's information architecture is scent-aligned to the actual fixation pattern."
kohavi_integration:
  feeds_from: [kohavi-field-intelligence]
  feeds_to: [kohavi-experiment-designer]
  shared_data: "Nielsen provides the causal hypothesis (this heuristic violation is suppressing conversion); Kohavi provides the randomized verification. Every Single Move this skill produces is an A/B test hypothesis. The synthesis discipline: Nielsen identifies, Kohavi confirms. No Nielsen finding should be called 'fixed' without a controlled experiment showing the predicted conversion delta. Skipping Kohavi means trusting eyetracking heatmaps instead of revenue data — a known failure mode."
eisenberg_integration:
  feeds_from: [eisenberg-field-intelligence]
  feeds_to: [eisenberg-conversion-trinity-builder]
  shared_data: "Eisenberg maps the persuasion architecture (which buying modality, which conversion trinity element is active). Nielsen maps where users' eyes and attention actually reach that architecture. Combined: Eisenberg's persuasion sequencing is only as strong as Nielsen's attention routing allows. If the Methodical buyer's spec table is buried past fold three, no conversion-trinity design survives it. The synthesis asks: does the persuasion sequence match the attention sequence, or are they firing in the wrong order?"
fitts_integration:
  feeds_from: [fitts-field-intelligence]
  feeds_to: [fitts-target-cost-auditor]
  shared_data: "Fitts computes motor acquisition cost (size + distance). Nielsen computes attentional acquisition cost (visibility, fold position, banner-blindness risk, scanning pattern). Combined: Total Click Cost = Fitts motor cost + Nielsen attention cost. A large, near button that lives in a banner-blindness zone has low motor cost and high attention cost — users never fixate on it. The synthesis produces the first integrated Total Click Cost metric, revealing where reducing attention cost yields more conversion lift than enlarging the button."
goward_integration:
  feeds_from: [goward-field-intelligence]
  feeds_to: [goward-conversion-lift-auditor]
  shared_data: "Goward maps conversion rate optimization heuristics and lift sequencing. Nielsen maps the perceptual and cognitive layer beneath conversion. Combined: Goward's optimization sequence should be weighted by Nielsen's attention data — elements with low fixation probability should be deprioritized even if they test positively in isolation, because lift from an unread element is fragile. Nielsen's attention gradient is the prior distribution for Goward's test queue."
gigerenzer_integration:
  feeds_from: [gigerenzer-field-intelligence]
  feeds_to: [gigerenzer-fast-frugal-designer]
  shared_data: "Gigerenzer maps fast-and-frugal heuristics and ecological rationality. Nielsen maps the time-scale model (50ms first impression, 10-second patience window). Combined: Nielsen's time thresholds ARE the ecological constraints Gigerenzer's heuristics evolved to solve. The 50ms aesthetic judgment, the 10-second value-proposition scan, the F-pattern default — these are fast-frugal rules users apply under real-world time pressure. The synthesis asks: does the page design exploit these heuristics or fight them?"
laja_integration:
  feeds_from: [laja-field-intelligence]
  feeds_to: [laja-researchxl-diagnostic]
  shared_data: "Laja maps friction telemetry and voice-of-customer misalignment. Nielsen maps perceptual and cognitive friction sources. Combined: Nielsen provides the structural diagnosis (why friction exists at a perceptual level); Laja provides the motivational diagnosis (whether the visitor had sufficient desire to push through it). The synthesis resolves the critical ambiguity: is drop-off caused by Nielsen's perceptual friction or Laja's motivational gap? Different root cause, completely different fix."
norman_integration:
  feeds_from: [norman-field-intelligence]
  feeds_to: [norman-affordance-signifier-auditor]
  shared_data: "Norman maps affordances, signifiers, mappings, and feedback loops. Nielsen maps usability heuristics and attention patterns. These are the two pillars of perceptual UX: Norman explains why users don't know what to do; Nielsen explains where users are looking when they don't know what to do. Combined: the Gulf of Execution is widest when users are in F-pattern mode (low engagement), because they miss signifiers outside the F-stem. The synthesis reveals where Norman's signifier placement must account for Nielsen's scanning geometry."
hick_integration:
  feeds_from: [hick-field-intelligence]
  feeds_to: [hick-option-pruning-auditor]
  shared_data: "Hick quantifies decision time as RT = b × log2(n+1). Nielsen's Heuristic 7 (Aesthetic and Minimalist Design) states every extra unit of information competes with and diminishes relevant units. Combined: choice overload and information overload are the same phenomenon at different scales. Hick × Nielsen produces the Cognitive Overhead Index: decision items × visible competing elements = total cognitive load. The synthesis recommends which items to prune first — those that are both high Hick-cost AND occupy high-Nielsen-attention zones."
eyal_integration:
  feeds_from: [eyal-field-intelligence]
  feeds_to: [eyal-hook-loop-designer]
  shared_data: "Eyal maps Hook Loops (trigger → action → reward → investment). Nielsen maps the 10-second patience window and page attention gradient. Combined: the external trigger (Nielsen's prompt cue on the page) must land in a high-fixation zone and fire within Nielsen's 10-second window or the Hook Loop never initiates. Nielsen is the perception layer of Eyal's trigger mechanism. The synthesis ensures triggers are placed in Layer-Cake subheadings or F-bar positions — the only zones with reliable fixation probability."
brignull_integration:
  feeds_from: [brignull-field-intelligence]
  feeds_to: [brignull-dark-pattern-scanner]
  shared_data: "Brignull maps dark patterns (deceptive design). Nielsen maps Heuristics 3 (user control), 4 (consistency), and 5 (error prevention) — the three heuristics most weaponized in dark patterns. Combined: dark patterns exploit Nielsen violations rather than create new ones. Confirmshaming weaponizes Heuristic 3 failure; roach motels weaponize Heuristic 3 + 6; trick questions weaponize Heuristic 5. The synthesis produces the Ethical UX Boundary: every Nielsen violation is a potential dark-pattern vector that must be audited for intentionality."
fogg_integration:
  feeds_from: [fogg-field-intelligence]
  feeds_to: [fogg-prompt-designer]
  shared_data: "Fogg maps B=MAP (Behavior = Motivation × Ability × Prompt). Nielsen maps the perceptual layer where Fogg's Prompt must fire. Combined: a Fogg Facilitator prompt (ability is low) placed in a banner-blindness zone is a dead prompt — it exists in the design but not in the user's perception. Nielsen's attention model is the visibility constraint on every Fogg prompt. The synthesis ensures Fogg prompt types are matched to Nielsen attention zones: Spark prompts in above-fold F-bar, Facilitators in Layer-Cake subheadings, Signals in the left-stem."
cialdini_integration:
  feeds_from: [cialdini-field-intelligence]
  feeds_to: [cialdini-influence-audit]
  shared_data: "Cialdini maps the six influence principles as persuasion levers. Nielsen maps where eyes land and when trust forms (4 Credibility Factors). Combined: social proof placed below fold three receives negligible fixations (Page Fold Attention Gradient: 74% attention within first two screenfuls). Scarcity signals buried in right-rail suffer banner blindness. Authority signals require design quality — Heuristic violation on the credibility section destroys the authority claim it contains. The synthesis sequences Cialdini principles by Nielsen attention priority."
kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: [kahneman-framing-engineer]
  shared_data: "Kahneman maps System 1 (fast, associative) and System 2 (slow, deliberate). Nielsen's time-scale model maps the same temporal dimension in page interaction: 50ms = pure System 1 aesthetic judgment; 10-second patience window = System 1 value-proposition heuristic; Commitment Pattern reading = System 2 engagement. The synthesis maps which page elements serve which system and ensures each is placed in a Nielsen zone appropriate to its cognitive load. F-pattern mode is System 1; Layer-Cake is the bridge; Commitment is System 2."
thaler_integration:
  feeds_from: [thaler-field-intelligence]
  feeds_to: [thaler-default-detector]
  shared_data: "Thaler maps choice architecture and defaults. Nielsen maps Cognitive Load Reduction for forms and checkouts (4 principles: Structure, Transparency, Clarity, Support). Combined: Thaler's default design is only effective if Nielsen's form cognitive load is low enough for users to reach the default choice. The synthesis identifies where form abandonment is preventing Thaler's nudges from ever being seen, and whether reducing Nielsen cognitive load is a prerequisite for any Thaler optimization."
iyengar_integration:
  feeds_from: [iyengar-choice-set-auditor]
  feeds_to: [iyengar-tier-calibrator]
  shared_data: "Iyengar maps choice overload and jam-study dynamics. Nielsen maps Heuristic 7 (Minimalist Design) and Hick-aligned information density. Combined: Iyengar's choice overload operates at the offer level; Nielsen's information overload operates at the page element level. A page can have a perfectly curated 3-option offer (Iyengar optimal) yet still exhibit cognitive overload if the page surroundings contain competing visual elements (Nielsen violation). The synthesis audits both levels simultaneously."
---

# Nielsen & Pernice Field Intelligence

---

## LAYER 1: INVARIANTS (Never override.)

1. **Field Intelligence is synthesis, not summary.** This skill does NOT recap individual skill findings. It finds PATTERNS ACROSS skills — convergence zones, contradictions, amplification opportunities, and the single highest-leverage page change. Output that reads like six reports pasted together has failed.

2. **Convergence detection is mandatory.** When 3+ Nielsen/Pernice skills point at the same page zone, element, or failure: that is a convergence zone. Name it. Convergence zones are the highest-confidence findings.

3. **Contradictions must be surfaced, not hidden.** When one skill recommends X and another recommends the opposite, resolve through deeper analysis of which force dominates in this specific page context.

4. **The Single Move is non-negotiable.** One recommended page change — the highest-leverage edit that addresses the most convergence zones simultaneously. Not options. Not a list. ONE move.

5. **The Mirror is non-negotiable.** The business's own page-design biases must be examined. Where is the team designing for where they hope users look, not where eyetracking shows they actually look?

6. **Cross-system intelligence is the highest-value section.** Nielsen's attention and usability findings interact with every other Click Architect. That intersection is where the most powerful, least obvious conversion insights live.

7. **Freshness gate: 45 days.** Flag any individual skill output older than 45 days as potentially stale before synthesizing.

---

## LAYER 2: QUALITY GUIDANCE

8. **Name the convergence zones.** Give each a memorable label capturing the insight (e.g., "The Invisible CTA" for convergence around a button that scores poorly on both attention-zone placement and banner-blindness risk; "The Trust Desert" for convergence around credibility elements buried below fold two).

9. **Quantify where possible.** Tie convergence zones to specific, estimated page-action impact. Nielsen's attention gradient benchmark: above-fold content receives 102% more views than content 100px below fold. Use it.

10. **The 90-Day Projection must be specific.** Not "conversion should improve." Instead: "If The Single Move ships in week 1, by day 30 primary CTA click-rate should shift from X% to Y%; by day 90 form completions should move Z%."

---

## PURPOSE

We place CTAs where eyes actually land, not where we hope.

Individual Nielsen/Pernice skills each audit one dimension of how a real visitor perceives and acts on a real page. The Heuristic Evaluation catches interaction design violations. The F-Pattern Auditor maps whether layout fights or leverages the default scanning geometry. The Banner Blindness Detector identifies which elements users are trained to skip. The Attention Zone Placer scores every CTA and offer element against the 57,453-fixation heatmap database. The Scannability Optimizer restructures copy for Layer-Cake triggering. The Hallway Test Designer prescribes the minimal real-user validation that confirms or refutes the findings.

Field Intelligence goes one level beyond. It finds convergence zones across all six analyses, resolves contradictions, identifies amplification opportunities where combined interventions create outsized lift, delivers The Single Move, holds up The Mirror to the business's own design assumptions, and — most critically — integrates Nielsen's perceptual and usability intelligence with EVERY OTHER Click Architect thinker. The result is not a usability report. It is attention-grounded, empirically-anchored conversion intelligence situated within the complete thinker network.

---

## INPUT REQUIREMENTS

**Required:**
- Outputs from at least 4 of 6 individual Nielsen/Pernice skills, all run on the same target page with the same stated desired action

**Optimal:**
- All 6 individual skill outputs
- Field Intelligence outputs from other Click Architects (Fogg, Cialdini, Kahneman, Thaler, Pirolli, Fitts, Hick, Eisenberg, Laja, Norman, Kohavi, Iyengar, Eyal, Brignull, Goward, Gigerenzer)
- Live page performance data (heatmaps, click maps, scroll depth, conversion rates)
- Any prior hallway or usability test recordings

**State clearly:**
- Target page URL or description
- Desired action the page must produce (one action only)
- Current conversion baseline (if available)

---

## EXECUTION PROCESS

### Step 1: Component Synthesis

For each available Nielsen/Pernice skill output:
- **Skill name and date run**
- **Freshness:** Current (≤45 days) / Aging (45–60 days) / Stale (>60 days)
- **Key findings:** 3–5 most important conclusions, with specific page locations
- **Primary recommendation made**
- **Confidence:** High (direct heuristic violation or eyetracking match) / Medium (inferred) / Low (assumed)

### Step 2: Convergence Detection

Cross-skill pattern matching. For every page element, zone, or pattern flagged by multiple skills:

**Convergence scoring:**
- 2 skills: Notable alignment
- 3 skills: Convergence zone — name it
- 4 skills: Strong convergence
- 5–6 skills: Critical convergence — this is the page's dominant failure or dominant opportunity

**For each convergence zone:**
- **Name:** Memorable label
- **Contributing skills:** Which of the six raised this signal
- **Specific findings per skill:** What each found (not a paraphrase — exact diagnosis)
- **System-level implication:** Why this pattern matters beyond the individual finding
- **Implied intervention:** What the convergence demands change on the page

*Worked example — convergence zone "The Invisible CTA":*
Banner Blindness Detector flags CTA uses blue border + rounded corners (ad-signature styling). Attention Zone Placer scores CTA at fold-3 position, 74% of viewing time already spent. Heuristic Evaluation cites Heuristic 6 failure (required action not kept visible). F-Pattern Auditor confirms CTA is right-aligned, out of F-stem. Four skills converging = Strong convergence. Implication: the CTA receives near-zero fixations not because the offer is weak but because four independent perceptual filters are simultaneously suppressing it.

### Step 3: Contradiction Detection

Cross-skill conflict identification:

**Common Nielsen contradiction patterns:**
- Scannability Optimizer recommends more subheadings ↔ Heuristic Evaluation recommends reducing visual noise (Heuristic 7)
- F-Pattern Auditor recommends left-aligning content ↔ Attention Zone Placer recommends centering the hero to maximize above-fold fixations
- Hallway Test Designer recommends real-user testing before changes ↔ Banner Blindness Detector identifies a critical CTA suppression that is losing revenue daily
- Scannability Optimizer recommends bold keywords throughout ↔ F-Pattern Auditor notes that over-bolding teaches users to skip all bold

**For each contradiction:**
- The tension (state both positions precisely)
- Why both skills are correct in their own frame
- Resolution for this specific page context
- Implementation that honors the deeper insight from both

### Step 4: Amplification Opportunities

Where combining two or more Nielsen interventions creates impact greater than the sum:

- Layer-Cake subheadings (Scannability) + primary CTA anchored below each subheading (Attention Zone) = CTA appears at natural pause points, not in dead zones
- Removing banner-blindness styling (Banner Blindness) + repositioning above fold (Attention Zone) + Heuristic 6 compliance (recognition over recall) = single CTA with three compounding visibility gains
- Inverted Pyramid lead copy (Scannability) + Information Scent above fold (F-Pattern) = users receive value-proposition signal AND read-worthiness signal in the same above-fold pass
- Form cognitive load reduction (Heuristic evaluation) + transparent completion time (Heuristic 1 + 3) + error prevention at field level (Heuristic 5) = form abandonment triple-addressed

Before/after: a checkout page where the submit button is styled with a prominent blue gradient (banner-blindness-risk styling), sits in a right-aligned column (outside F-stem), and uses placeholder text as labels (Heuristic 6 failure + cognitive load violation) might show 2.1% form completion. Removing the ad-style gradient, moving to left-aligned single-column layout, and replacing placeholder labels with persistent above-field labels addresses Banner Blindness + F-Pattern + Heuristic 6 simultaneously. Nielsen benchmarks suggest this combination can raise form completion 40–120% (NNg form research, 2023).

### Step 5: The Single Move

ONE page change that addresses the most convergence zones:

- **What to do:** The specific edit (element, location, styling, copy, structure)
- **Why this is THE move:** Which convergence zones it resolves and why simultaneously
- **How it works:** Which Nielsen framework(s) it activates — cite exact heuristic number, scanning pattern name, or attention-gradient threshold
- **Implementation:** Concrete, sequential actions (what to change, where, exactly how)
- **Expected outcome:** Specific metric delta and the Nielsen benchmark supporting the prediction
- **What it does NOT address:** Honest statement of what remains for the next optimization cycle

### Step 6: The Mirror

Where the business's own page-design assumptions are the real problem:

- **Fold assumption:** Team places key offers "above the fold" as defined on their own monitors (typically 1440px viewport), not the visitor's median viewport. Nielsen benchmark: 57% of viewing time above fold — but that fold height varies dramatically by device. Is the team testing fold position on mobile?
- **Attention-zone optimism:** Team assumes users read left-to-right, top-to-bottom. NNg data shows F-pattern default on unformatted text blocks. Where did the team write copy as if users would read every word?
- **CTA styling received wisdom:** Team follows brand guidelines that produce ad-signature styling (gradient fills, rounded corners, border frames) on CTAs — the exact properties Nielsen found trigger banner blindness.
- **Form length anchoring:** Team has normalized form fields added over time (each field seemed reasonable when added). Nielsen's single-column benchmark and progressive disclosure principle would cut completions-killing length, but no one audits the aggregate.
- **10-second assumption failure:** Team writes value propositions that require 30–60 seconds to process. Nielsen's patience window is 10 seconds for a first visit. Is the value proposition deliverable in that window, or is the team presenting a case that requires prior motivation to follow?

### Step 7: Cross-System Intelligence

**Nielsen × Pirolli:** Information Scent is only actionable in high-fixation zones. Scent cues in the F-stem (left-aligned subheadings) propagate; scent cues in the right rail do not. Nielsen's geometry determines which Pirolli signals reach the forager.

**Nielsen × Kohavi:** Every Single Move produced here is an A/B test hypothesis with a predicted conversion delta and a Nielsen mechanistic explanation. Kohavi enforces that no Nielsen finding is called fixed until a controlled experiment confirms the predicted lift. Eyetracking heatmaps are inputs to test prioritization, not proof of conversion impact.

**Nielsen × Eisenberg:** Eisenberg's persuasion sequence (attention → interest → desire → action) must be sequenced to match Nielsen's attention gradient (102% above-fold advantage, 74% in first two screenfuls). If the Desire stage lands below fold two, the conversion sequence fires on a fraction of arrivals. Nielsen restructures where Eisenberg's sequence can be received.

**Nielsen × Fitts:** Total Click Cost = Fitts motor cost (acquisition time = a + b × log₂(distance/size + 1)) + Nielsen attention cost (fold position × banner-blindness risk × scanning-pattern probability). A large, centered button with low Fitts cost that sits in a banner-blindness zone has low motor cost and near-zero fixation probability — effectively infinite total cost. The integrated metric reveals which optimization matters most.

**Nielsen × Goward:** Nielsen's attention gradient is the prior distribution for Goward's test queue. Elements with low fixation probability should be deprioritized for conversion testing until their attention cost is addressed. Testing copy on an element users never fixate on produces noise, not signal.

**Nielsen × Gigerenzer:** Nielsen's time thresholds (50ms, 0.1s, 1s, 10s, 30s) are the ecological constraints that Gigerenzer's fast-frugal heuristics evolved to exploit. The 50ms aesthetic trust judgment is a one-reason heuristic operating under recognition; the F-pattern is a search heuristic for environments where comprehensive reading is not cost-effective. Page design that fights these heuristics is fighting ecological rationality itself.

**Nielsen × Laja:** When conversion drops, two diagnoses are possible: Nielsen's perceptual friction (user can't find, process, or act on the page) or Laja's motivational gap (user lacks sufficient desire to act even with a frictionless page). Different root cause, completely different fix. The synthesis resolves this disambiguation before prescribing treatment.

**Nielsen × Norman:** Norman's Gulf of Execution widens most when users are in F-pattern scanning mode (low engagement, high velocity). Signifiers placed outside the F-stem or above the fold are missed, meaning Norman's affordance design depends on Nielsen's attention routing. The synthesis asks: are Norman's signifiers in Nielsen's fixation zones?

**Nielsen × Hick:** Hick's RT = b × log₂(n+1) quantifies decision time; Nielsen's Heuristic 7 (Aesthetic and Minimalist Design) states each additional information unit competes with and diminishes every other. Combined Cognitive Overhead Index = (number of decision options) × (number of competing visible page elements). The synthesis identifies which elements drive both metrics simultaneously and should be pruned first.

**Nielsen × Eyal:** The Hook Loop's external trigger must land in a Nielsen high-fixation zone and fire within the 10-second patience window. F-bar positions and Layer-Cake subheadings are the only zones with statistically reliable fixation. External triggers buried in body paragraphs (F-stem scan, word three and beyond) are structurally invisible — the Hook never initiates.

**Nielsen × Brignull:** Dark patterns weaponize Nielsen heuristic violations. Confirmshaming exploits Heuristic 3 (user control); roach motels exploit Heuristics 3 + 6 (freedom + recognition); trick questions exploit Heuristic 5 (error prevention). The synthesis produces the Ethical UX Boundary: every Nielsen violation is a potential dark-pattern vector that must be assessed for intent.

**Nielsen × Fogg:** Fogg's Prompt must be visible to fire. A Facilitator prompt (ability is low) placed in a banner-blindness zone is a dead prompt — it exists in the design, not in the user's perception. Nielsen's attention model is the visibility gate on every Fogg prompt type. Spark prompts belong in F-bar positions; Facilitators belong in Layer-Cake subheadings; Signals belong in the left-stem.

**Nielsen × Cialdini:** Social proof below fold three receives negligible fixations. Scarcity signals in the right rail trigger banner blindness. Authority claims embedded in heuristic-violating design (typos, broken layouts, cluttered visuals) are self-defeating — the very elements meant to convey authority are destroyed by the design violations surrounding them. Nielsen's attention gradient is the distribution channel for every Cialdini principle.

**Nielsen × Kahneman:** Nielsen's time-scale maps directly to Kahneman's dual-process architecture. 50ms = System 1 aesthetic trust judgment (pure recognition, no deliberation). 10-second window = System 1 value heuristic scan. Layer-Cake scanning = the bridge where System 1 decides whether to engage System 2. Commitment Pattern = System 2. Each page element should be designed for the system that will process it at that temporal depth.

**Nielsen × Thaler:** Thaler's default design is only effective if Nielsen's form cognitive load is low enough for users to reach the default. Form abandonment before the default choice is encountered means Thaler's nudge never fires. Nielsen's form completion principles (single-column, transparent completion time, persistent labels) are prerequisites for Thaler's choice architecture to function.

**Nielsen × Iyengar:** Iyengar's choice overload operates at the offer level (too many product options). Nielsen's information overload operates at the page element level (too many competing visual elements). A 3-option offer (Iyengar optimal) surrounded by 40 visual elements (Nielsen overload) still produces abandonment. Both levels must be audited and addressed in sequence: fix Nielsen's page-level overload first, then Iyengar's offer-level overload.

**Cross-system convergence:** The highest-confidence findings emerge when Nielsen's attention architecture aligns with Fogg's prompt-visibility requirements, Cialdini's principle placement, Eisenberg's persuasion sequence, and Pirolli's scent gradient simultaneously. When all four systems point at the same page zone as the critical conversion lever, confidence in that intervention is near-certain.

### Step 8: Coherence Map

Score overall page-action design coherence (1–10 each):

| Dimension | Score | What raises it |
|-----------|-------|----------------|
| Heuristic coherence | /10 | Heuristics 1,4,5,6,7 all passing |
| Attention-flow coherence | /10 | CTAs in fixation zones, no fold-burial |
| Scanning-pattern coherence | /10 | Layer-Cake or Commitment triggered (not F) |
| Cross-system coherence | /10 | Cialdini, Fogg, Pirolli elements in Nielsen zones |

**Coherence gaps:** Lowest-scoring dimension and the single edit that would raise it most.

### Step 9: 90-Day Projection

**Days 1–30:**
- The Single Move implemented
- Expected early signal: primary CTA click-rate shift (Nielsen above-fold repositioning: +15–40% fixations within 2 weeks per NNg heatmap database)
- Decision gate at day 14: if heatmap shows CTA fixation has not increased, the attention-cost diagnosis may be wrong — escalate to Kohavi A/B test

**Days 31–60:**
- Layer-Cake restructure completed across all page sections
- Scanning pattern should shift from F toward Layer-Cake (verifiable via session recordings showing subheading-anchor pauses)
- Form cognitive load reductions showing in completion-rate data
- Expected form completion lift range: 20–80% based on Nielsen single-column and label benchmarks

**Days 61–90:**
- Full attention-gradient alignment achieved
- Page fold audit across device viewports completed
- Cross-system synthesis run: Kohavi confirms or refutes each predicted lift
- Identified bottleneck for next cycle: likely motivational (Laja diagnosis) or persuasion-sequence (Eisenberg) once perceptual barriers are cleared

---

## OUTPUT STRUCTURE

### Nielsen & Pernice Page-Action Intelligence Briefing

**Section 1: Input Status and Freshness**
All six skill outputs with freshness, page tested, desired action stated.

**Section 2: Convergence Map**
Named convergence zones with contributing skills, specific findings per skill, and implied interventions. Minimum one zone per 4+ skill convergence found.

**Section 3: Contradiction Analysis**
Each cross-skill tension stated precisely, resolved for this page context.

**Section 4: Amplification Opportunities**
Combined interventions producing outsized impact, with before/after estimate and Nielsen benchmark cited.

**Section 5: The Single Move**
One highest-leverage page change with implementation steps, predicted metric delta, and benchmark support.

**Section 6: The Mirror**
Business's own attention-design biases examined honestly.

**Section 7: Cross-System Intelligence**
Interactions with all Click Architect thinkers in the network. Highest-confidence cross-system convergence findings stated explicitly.

**Section 8: Coherence Map**
Scored table (4 dimensions). Lowest score and the single edit that raises it.

**Section 9: 90-Day Page-Action Projection**
Specific predictions by 30/60/90-day milestones with decision gates.

---

## OUTPUT FILE

Save complete briefing to:
`[project-folder]/Nielsen-Pernice - Field Intelligence/[YYYY-MM] - Page-Action Intelligence Briefing.md`
