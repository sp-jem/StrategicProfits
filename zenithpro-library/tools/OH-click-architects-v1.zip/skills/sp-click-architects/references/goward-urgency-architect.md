---
name: goward-urgency-architect
description: Use when a page conversion rate is acceptable but visitors are delaying action or abandoning at the final step — diagnoses and strengthens urgency signals using the LIFT Model's Urgency factor, adding only credible time/scarcity pressure that the audience will not punish.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Chris Goward (You Should Test That! 2012; WiderFunnel methodology 2009-2014; LIFT Model — Urgency factor) — Click Architecture (Skill 5 of 7)"
interface:
  invoke: "/goward-urgency-architect"
  calls: []
  called_by: [user, goward-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Urgency signals (deadlines, inventory, pricing) are event-driven and expire; an audit older than 45 days may describe offers that no longer exist or miss new ones."

goward_cluster_integration:
  feeds_from: [goward-value-prop-fulcrum-auditor, goward-clarity-relevance-optimizer]
  feeds_to: [goward-lift-scorer, goward-hypothesis-generator]
  shared_data: "LIFT six-factor scores; Value Proposition POD list (urgency claims must match a real POD — not a POI); Anxiety score (urgency that raises Anxiety net-harms conversion)"

kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: [goward-hypothesis-generator]
  shared_data: "Loss-aversion framing for real scarcity; Peak-End Rule for positioning urgency at the right moment in page scroll; Prospect Theory asymmetry applied to cost-of-waiting statements"

cialdini_integration:
  feeds_from: [cialdini-field-intelligence]
  feeds_to: [goward-lift-scorer]
  shared_data: "Scarcity and social proof as credibility anchors for urgency claims; Commitment-ladder position determines which urgency lever is appropriate (early vs. final-CTA urgency differ)"
---

# Goward Urgency Architect

## LAYER 1: INVARIANTS (Never override.)

1. **Value Proposition ceiling is absolute.** Urgency is a LIFT driver, not a substitute for a weak value prop. If the VP/fulcrum audit scores below 6/10, urgency optimization delivers diminished returns. Run goward-value-prop-fulcrum-auditor first.

2. **Urgency must be real or it triggers Anxiety — the opposite LIFT factor.** Manufactured countdown timers on evergreen pages signal deception to sophisticated audiences, increase Anxiety, and net-reduce conversion. Every urgency element must tie to an honest, externally verifiable constraint (deadline, inventory, pricing event, cohort close).

3. **Audience-congruence test is non-negotiable.** Goward's wine-buyer case: countdown timers that work for mass e-commerce BACKFIRE with premium/luxury buyers who interpret pressure as a signal the product is unsaleable. Score audience sophistication before choosing the urgency lever.

4. **Single macro conversion only.** Do not optimize urgency signals toward micro-conversions (newsletter sign-up, video view). Define the one revenue-driving action and anchor all urgency to that action exclusively.

5. **Context beats tips.** There are no universal urgency tactics — only tested hypotheses. Every urgency prescription here is a hypothesis. Run an A/B or fractional factorial DOE test before declaring a winner.

6. **Urgency positioned at wrong page moment multiplies Anxiety.** Cost-of-waiting statements at the top of a cold-traffic landing page raise perceived risk before perceived benefit is established. Sequence: establish VP and Relevance first; introduce Urgency near the CTA.

7. **Do not eliminate existing urgency signals before testing.** Even a weak urgency element may be load-bearing. Removal is a hypothesis, not an assumption.

## LAYER 2: QUALITY GUIDANCE

1. Urgency diagnoses must name the specific LIFT sub-factor affected (e.g., "time-based urgency," "supply-based urgency," "event-driven urgency") — not generic labels like "add scarcity."

2. Every recommendation must include a falsifiable A/B hypothesis statement: "If we [change X], we expect [metric Y] to increase by [direction], because [LIFT mechanism]."

3. Recommendations must be sequenced by Kaizen priority logic: changes with highest Expected Return on Effort (traffic volume × uplift potential × implementation speed) go first.

4. Worked hypotheses must specify which page zone the urgency element lives in (above-fold, mid-page, CTA zone, post-CTA confirmation) — placement is part of the hypothesis.

5. Flag any urgency recommendation that could interact with the Anxiety score. If the recommendation risks raising Anxiety on a net basis, state the interaction explicitly and propose an anxiety-mitigation companion change.

## PURPOSE

This skill operates on a specific web page targeting one desired action. It applies Chris Goward's LIFT Model Urgency factor — one of three conversion drivers that lift what the Value Proposition makes possible — to diagnose why visitors are delaying or abandoning at the final step, and to architect honest urgency signals that reduce perceived cost-of-waiting without triggering Anxiety.

**Brag line:** "We can score any landing page on 6 conversion forces before testing." — Chris Goward. This skill delivers the Urgency slice of that score as a tested hypothesis stack.

Urgency in the LIFT Model is not "add a countdown." It is the systematic removal of reasons to wait. Those reasons include: uncertainty about whether the offer changes, indifference to timing, absence of social momentum signals, and no named cost for delay. Each has a different page-lever fix.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description with all visible copy and page elements
- The ONE desired action (e.g., "click Add to Cart," "submit lead form," "register for webinar")

**Strongly recommended:**
- Audience description (sophistication level, prior exposure to the offer, channel source)
- Analytics: bounce rate, scroll depth, time-on-page, exit rate at CTA zone, conversion rate baseline
- Funnel position (cold traffic / warm / hot retargeting)
- Any existing urgency elements currently on the page (copy, timers, badges, inventory signals)
- Current LIFT Model scores if goward-lift-scorer has already run

**Optional:**
- Seasonal or promotional calendar (reveals real urgency windows)
- Competitor urgency tactics (for audience expectation calibration)
- Qualitative research (user test recordings, Motivation Lab findings)

## EXECUTION PROCESS

### Step 1 — LIFT Urgency Baseline Score (0–10)

Score the page's current Urgency factor on a 0–10 scale before recommending anything.

| Score | Signal |
|-------|--------|
| 0–2 | No urgency present; page reads as always-available |
| 3–5 | Weak or buried urgency (e.g., fine-print deadline) |
| 6–7 | One credible urgency signal, moderate placement |
| 8–9 | Multiple authentic urgency levers, well-placed |
| 10 | Rare; full urgency architecture with audience fit |

**Threshold:** scores below 5 = urgency is a primary testing focal area (Kaizen priority). Scores 6–7 = test placement and framing. Scores 8+ = test removal of a signal to confirm it is load-bearing.

Record: `Current Urgency Score: [X/10]`

### Step 2 — Urgency Type Inventory

Audit every urgency element on the page. Classify each by type:

| Type | Definition | Example Signal |
|------|-----------|---------------|
| Time-based | Hard deadline, event date, offer expiry | "Enrollment closes Friday" |
| Supply-based | Finite inventory or seats | "12 seats remaining" |
| Price-event | Pricing changes at a date | "Price increases after launch" |
| Social momentum | Others acting now | "847 people enrolled this week" |
| Cost-of-waiting | Named consequence of delay | "Each week costs $X in lost revenue" |

For each element found: note page zone (above-fold / mid-page / CTA zone / post-CTA), credibility rating (Can the audience verify this? Yes/Partial/No), and Anxiety interaction risk (Low/Medium/High).

### Step 3 — Audience Sophistication Filter

Before prescribing any urgency tactic, apply Goward's audience-congruence test:

- **Mass / price-sensitive / impulse buyers:** countdown timers, inventory badges, and social proof volume signals are credible and expected. Use them.
- **Mid-market / considered-purchase buyers:** event-driven urgency (cohort closes, live launch windows) outperforms manufactured timers. Use real dates.
- **Premium / luxury / high-ticket buyers:** pressure-based urgency triggers Anxiety. Use cost-of-waiting and social momentum framing instead. Avoid visible timers.
- **B2B / enterprise buyers:** urgency must connect to business consequence (fiscal quarter, competitive window, regulatory deadline). Generic "offer expires" copy damages credibility.

Flag mismatches: if current page uses timer-style urgency for a premium audience, this is an Anxiety-increasing element masquerading as an urgency element — remove or reframe.

### Step 4 — Cost-of-Waiting Calculation (Core LIFT Lever)

Goward's Urgency factor includes explicit cost-of-waiting framing. Compute or estimate a named cost for delay:

```
Cost-of-Waiting Formula:
[Quantified benefit per period] × [Average delay days in audience]
= Named cost of inaction per prospect

Example:
Offer: productivity software saving 3 hr/week at $150/hr loaded cost
Average sales cycle delay: 30 days
Cost-of-waiting: 3 hr × $150 × 4.3 weeks = $1,935 left on table per month
On-page framing: "Every month you wait costs your team ~$1,900 in recoverable time."
```

If no quantified benefit is available: use social proof velocity ("1,200 businesses have already recovered this time"), or event-based framing ("Q3 closes in [X] days — this implementation takes 3 weeks").

### Step 5 — Urgency Placement Map

Map where urgency elements should appear relative to page scroll and CTA position:

| Page Zone | Urgency Role | Recommended Type |
|-----------|-------------|-----------------|
| Above fold | None or minimal | Avoid; VP and Relevance must land first |
| Mid-page | Soft momentum | Social proof velocity, cost-of-waiting |
| CTA zone | Primary urgency | Event deadline, supply signal, cost-of-waiting |
| Post-CTA | Reinforcement | Confirmation + "you beat the deadline" framing |

**Rule:** Urgency in the CTA zone is always highest priority. Urgency above the fold on cold traffic is highest-risk Anxiety interaction.

### Step 6 — Hypothesis Stack (Kaizen Priority Order)

Produce 3–5 ranked A/B test hypotheses. Each must include:

- **Current state:** what the page does now
- **Proposed change:** specific copy, element, placement
- **LIFT mechanism:** which Urgency sub-type this activates
- **Anxiety interaction:** Low / Medium / High (flag High-risk hypotheses)
- **Expected Return on Effort (ROE):** score 1–5 (traffic × uplift potential × speed)
- **Falsifiable hypothesis:** "If [change], then [metric] will [direction] because [mechanism]"

Rank by ROE score descending. The top hypothesis is the first test to run.

### Step 7 — Anxiety Cross-Check

For every hypothesis flagged Medium or High Anxiety interaction risk: prescribe a companion element that reduces perceived risk in parallel (e.g., adding a guarantee statement adjacent to a countdown timer, or a "no-pressure" opt-out language near a seat-count badge).

Goward principle: the goal is to increase Urgency while holding or reducing Anxiety — not to trade one for the other.

## OUTPUT STRUCTURE

**Section 1 — LIFT Urgency Audit**
- Current Urgency Score (0–10) with scoring rationale
- Urgency Type Inventory table (all elements found, type, zone, credibility, Anxiety risk)
- Audience Sophistication classification and congruence verdict

**Section 2 — Cost-of-Waiting Analysis**
- Computed or estimated cost-of-waiting figure
- Recommended on-page framing (exact copy or copy direction)

**Section 3 — Urgency Placement Map**
- Annotated page zones with current vs. recommended urgency element placement

**Section 4 — Hypothesis Stack**
- 3–5 ranked hypotheses, Kaizen priority order, each with full fields from Step 6
- Anxiety cross-check notes for Medium/High-risk hypotheses

**Section 5 — Test Sequencing Note**
- Which test to run first and why (ROE logic)
- If site is below 1M monthly visitors: flag DOE (fractional factorial) approach to run multiple hypotheses simultaneously

## WORKED MINI-EXAMPLE

**Page:** SaaS project management tool, free-trial CTA page. Desired action: "Start Free Trial."

**Before:**
- Urgency Score: 2/10
- Copy: "Start your free trial anytime." (signals no urgency)
- No deadline, no social proof, no cost-of-waiting
- Audience: mid-market SMB buyers, considered purchase

**Diagnosis:** Urgency factor is near zero. Audience is mid-market — event-driven urgency fits better than countdown timers. Cost-of-waiting framing is the primary lever.

**Hypothesis 1 (ROE: 5):**
- Current: "Start your free trial anytime."
- Proposed: Add beneath CTA button — "Teams that start this week are fully onboarded before Q3 planning begins. Teams that wait typically miss the window."
- LIFT mechanism: event-driven cost-of-waiting (Q3 planning deadline)
- Anxiety interaction: Low
- Hypothesis: "If we add Q3 planning urgency framing under the CTA, trial starts will increase because mid-market buyers respond to business-calendar consequences, not artificial timers."

**After (projected):** Urgency Score: 6/10. One credible, audience-congruent urgency signal in the CTA zone. No Anxiety increase. Test ready to launch.

## OUTPUT FILE

Save to: [project-folder]/Goward - Click Architecture/[YYYY-MM] - Urgency Architect Audit.md

**Legend for tables above:**
- VP = Value Proposition
- POD = Point of Difference
- ROE = Return on Effort
- DOE = Design of Experiments (fractional factorial)
- CTA = Call to Action
- LIFT = Landing page Influence Function for Tests
