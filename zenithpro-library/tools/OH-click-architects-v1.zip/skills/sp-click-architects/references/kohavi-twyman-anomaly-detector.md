---
name: kohavi-twyman-anomaly-detector
description: Use when an A/B test result looks suspiciously strong — too-good-to-be-true lifts, metric spikes, or unexpected guardrail violations on a page variant — to systematically surface false positives and data artifacts before anyone celebrates or ships.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Ronny Kohavi (Trustworthy Online Controlled Experiments, 2020; Twyman's Law + Guardrail Metrics + SRM Check) — Click Architecture (Skill 4 of 7)"
interface:
  invoke: "/kohavi-twyman-anomaly-detector"
  calls: []
  called_by: [user, kohavi-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic mix, instrumentation, and bot filtering change constantly — anomaly baselines shift with each platform update or traffic source change."

kohavi_srm_guard_integration:
  feeds_from: [kohavi-srm-guard]
  feeds_to: [kohavi-rollout-decision-architect]
  shared_data: "SRM p-value and actual vs. designed traffic ratio feed directly into anomaly triage — an SRM is itself the most common Twyman-trigger; this skill decides whether the anomaly is SRM-driven or a true signal artifact."

kohavi_oec_definer_integration:
  feeds_from: [kohavi-oec-definer]
  feeds_to: [kohavi-experiment-validity-auditor]
  shared_data: "The composite OEC formula defines which metric directions are expected — anomaly detection compares observed lift against OEC component weights to spot impossible combinations (e.g., revenue up 40% while sessions flat)."

kahneman_field_intelligence_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: []
  shared_data: "Kahneman's focusing illusion and availability heuristic explain why teams anchor on the impressive headline metric; Twyman audit re-directs attention to the full metric dashboard before the anchoring hardens into a launch decision."
---

# Kohavi Twyman Anomaly Detector

## LAYER 1: INVARIANTS (Never override.)

1. **Twyman's Law is absolute.** Any result that looks interesting or surprising is probably wrong. If a lift exceeds your historical distribution of wins by 2x or more, treat it as an anomaly until proven otherwise — not the other way around.
2. **Hide the scorecard until the anomaly check passes.** Do not share results with stakeholders, write up a launch plan, or let anyone celebrate until every check in Step 3 clears. An MSN experiment that looked like +3.3% engagement was actually -3.3% after SRM correction.
3. **Guardrail violations halt the experiment, period.** If any organizational guardrail (latency, crash rate, error rate, churn) is breached, the experiment stops regardless of how good the OEC looks. The Bing coupon field experiment: Treatment 1 = -2.8% revenue (p=0.0003); Treatment 2 = -7.8% revenue (p=1.5E-23). Both were killed on guardrail breach alone.
4. **p≈0.05 is not enough.** At p=0.05 with 10 independent metrics tested, there is a 40% chance at least one is significant by chance. Pre-define the OEC composite and 3-5 key metrics before the experiment runs; evaluate only those.
5. **Novelty effect is a confound, not a win.** Any new on-page element produces a transient CTR spike. A result measured in the first 48 hours cannot be declared stable. Minimum window: 1 full week; 2+ weeks for new UI paradigms.
6. **Trigger analysis is mandatory before quoting segment lifts.** A 1% triggered segment showing 10% improvement = ~0.1% aggregate impact. Never quote the segment lift without the dilution-adjusted estimate.
7. **True breakthrough frequency is ~1 in 500 at mature orgs.** When p≈0.05 and the claimed lift is large, the base rate of true breakthroughs implies a ~3.1% posterior probability the effect is real. Demand replication before launch.

## LAYER 2: QUALITY GUIDANCE

1. Run the SRM check before any other anomaly check — SRM is the most common Twyman trigger and contaminates all downstream metrics. p < 0.001 = warning; p < 0.05 = investigation required; do not proceed until resolved.
2. Decompose the OEC into its component metrics (e.g., revenue = purchase_rate × conditional_revenue) and check each leg. A 30% revenue lift with flat purchase rate and flat session counts means the math does not close — that is an anomaly signal.
3. Compare the lift magnitude against historical experiment distribution for this page/funnel. Lifts above the 95th percentile of past winners are Twyman-flagged by default.
4. Check debug/diagnostic metrics (bot ratios, cache-hit rates, JS error rates) as trust-related invariants — these should not change between control and treatment. Any change signals instrumentation contamination.
5. Plot the metric time series daily, not as a single aggregate. A spike that appears only on day 1 or only on weekends is not a reliable signal.

## PURPOSE

This skill applies Kohavi's Twyman's Law to a live or completed A/B test result on a specific web page. It systematically interrogates whether a lift is real before anyone ships, celebrates, or writes a case study. The skill runs a structured five-layer anomaly triage — SRM check, metric decomposition, guardrail scan, novelty-effect test, and historical percentile comparison — and returns a PASS/FLAG/HALT verdict with the specific evidence behind it.

**Brag-line:** "We know our winner is real, not a 1-in-20 false positive."

This skill does NOT define the OEC (that is kohavi-oec-definer), run the initial validity audit (kohavi-experiment-validity-auditor), or make the launch/kill decision (kohavi-rollout-decision-architect). It is the dedicated anomaly gate between "results are in" and "we act."

## INPUT REQUIREMENTS

**Required:**
- The page under test (URL, screenshot, or written description)
- The ONE desired action the experiment was designed to move
- The reported lift: metric name, control value, treatment value, p-value, confidence interval, and sample sizes for each variant
- Experiment duration (days) and traffic split design (e.g., 50/50)

**Strongly recommended:**
- Full metric dashboard (not just the headline metric) including guardrail metrics
- Daily time-series of the primary metric for both variants
- Historical distribution of past experiment lifts on this page or funnel stage
- Whether trigger analysis was applied (yes/no; if yes, triggered N and total N)

**Optional:**
- Bot filter configuration and any recent changes to it
- Recent platform changes (CDN, JS framework, analytics SDK version)
- Audience composition (new vs. returning, device mix)

## EXECUTION PROCESS

### Step 1 — Twyman Threshold Screen (2 minutes)

Before any math, ask: Is this result surprising? Score it:

| Signal | Flag if... |
|---|---|
| Lift magnitude | > 10% on a mature, high-traffic page |
| p-value | < 0.0001 on first run with no prior evidence |
| Direction | Opposite to all prior experiments on this element |
| Metric combo | Revenue up + sessions flat + purchase rate flat |
| Speed | Full lift apparent within 24 hours of launch |

Two or more flags = automatic Twyman trigger. Proceed through all steps before sharing results.

### Step 2 — SRM Check

Compute the chi-squared statistic for the actual vs. designed traffic split.

Formula (2-variant, 50/50 design):
```
χ² = (n_control - n_expected)² / n_expected + (n_treatment - n_expected)² / n_expected
n_expected = (n_control + n_treatment) / 2
```

Thresholds:
- p > 0.05 → SRM clear, proceed
- 0.001 < p < 0.05 → investigate before concluding (check bot filters, redirect chains, JS errors)
- p < 0.001 → HALT; hide scorecard; SRM is contaminating all metrics

If SRM is present and corrected: re-compute all metric estimates on the validated population only. The MSN case showed a 0.992 ratio (p=1.8E-6) that flipped +3.3% to -3.3% engagement post-correction.

### Step 3 — Metric Decomposition Audit

Decompose the headline metric into its multiplicative components and verify the math closes.

Example decomposition tree for a purchase page:
```
Revenue = Sessions × Purchase_Rate × Conditional_Revenue_per_Purchase
```

For each component, record control vs. treatment. If the headline metric moved but no component moved proportionally, there is a data artifact.

Worked decomposition check:
- Reported: Revenue +22% (treatment vs. control)
- Sessions: control 50,000 / treatment 50,200 → +0.4% (plausible)
- Purchase rate: control 2.1% / treatment 2.2% → +4.8% (plausible)
- Conditional revenue: control $48 / treatment $58 → +20.8% (suspicious alone)
- Math check: 1.048 × 1.208 ≈ 1.27 → only +27%, not +22%... recalculate
- If the math does not close within rounding, flag as data integrity issue

### Step 4 — Guardrail Metric Scan

Check all organizational guardrails. Halt threshold: any statistically significant degradation (p < 0.05) in:
- Page load time / latency (100ms = ~1% revenue; 250ms = ~1.5%)
- JS error rate
- Crash / unhandled exception rate
- Email unsubscribe rate (if applicable)
- Trust-invariant metrics: bot ratio, cache-hit rate, API error rate

Format for reporting:

| Guardrail | Control | Treatment | Delta | p-val | Status |
|---|---|---|---|---|---|
| Load time (ms) | 820 | 890 | +8.5% | 0.003 | HALT |
| JS errors/session | 0.12 | 0.13 | +8% | 0.21 | OK |

If any guardrail = HALT, stop. The experiment cannot be launched regardless of OEC lift.

### Step 5 — Novelty Effect Test

Plot the primary metric daily for both variants from day 1 through the experiment end.

Pattern checks:
- **Novelty pattern (invalid):** Treatment metric declines week-over-week, was highest in days 1-3
- **Stable pattern (valid):** Treatment metric holds flat or rises across all days
- **Ramp artifact:** Metric spikes on a day coinciding with a traffic source change

Rule: If the metric trend is still declining at experiment end, the experiment has not run long enough. Do not declare a winner. Minimum: 1 full week; 2+ weeks for new page layouts or nav paradigms.

### Step 6 — Historical Percentile Comparison

Locate or estimate the distribution of past experiment lifts on this page or funnel position.

Score the current lift against that distribution:
- Below 75th percentile of past winners → plausible, proceed to launch decision
- 75th–95th percentile → elevated scrutiny; document reasoning
- Above 95th percentile → Twyman-flagged; require replication before launch
- No historical distribution available → flag as unknown; recommend A/A test baseline first

### Step 7 — Trigger Analysis Validation (if segments reported)

If the reported lift comes from a segment or triggered population:

1. Confirm the triggered population (N_triggered) vs. total experiment population (N_total)
2. Compute dilution-adjusted aggregate impact:
   ```
   Aggregate_Impact = Segment_Lift × (N_triggered / N_total)
   ```
3. Report both numbers. The segment lift is for diagnostic use only; the aggregate impact is the business number.

Example: Landing page CTA test, triggered on desktop visitors only.
- Segment lift: +18% click-through
- N_triggered: 12,000 / N_total: 95,000 → dilution ratio = 0.126
- Aggregate impact: 18% × 0.126 = **+2.3%** — the real business number

### Step 8 — Verdict

Issue one of three verdicts:

- **PASS** — All checks clear. Proceed to kohavi-rollout-decision-architect.
- **FLAG** — One or more checks elevated but not halting. Document the specific flag, rerun with more data or replication arm.
- **HALT** — SRM confirmed, guardrail breached, or decomposition math cannot close. Hide scorecard. Escalate to engineering and analytics before any decision.

## OUTPUT STRUCTURE

**Section 1: Twyman Threshold Screen** — Which signals fired, total flag count, automatic trigger or not.

**Section 2: SRM Result** — chi-squared value, p-value, pass/investigate/halt, and corrected traffic ratio if applicable.

**Section 3: Metric Decomposition Table** — Component breakdown, math-close check, any anomalous legs flagged.

**Section 4: Guardrail Scan Table** — All guardrail metrics with control, treatment, delta, p-value, and status.

**Section 5: Novelty Effect Assessment** — Trend description, pattern classification (stable/novelty/ramp), minimum additional runtime if needed.

**Section 6: Historical Percentile** — Lift percentile vs. distribution, scrutiny level.

**Section 7: Trigger Analysis** (if applicable) — Segment lift, dilution ratio, aggregate impact.

**Section 8: Verdict** — PASS / FLAG / HALT with one-paragraph rationale and next action.

## WORKED MINI-EXAMPLE

**Page:** SaaS pricing page. Desired action: start free trial click.

**Reported result:** Treatment (new headline copy) vs. control. Free trial clicks +31% (p=0.0008). Experiment ran 4 days. Split design: 50/50.

**Step 1 — Twyman Screen:**
- +31% lift on mature pricing page: FLAG
- p=0.0008 in 4 days: FLAG
- Total flags: 2 → automatic Twyman trigger

**Step 2 — SRM:**
- n_control = 8,240, n_treatment = 7,910, n_expected = 8,075
- χ² = (8240-8075)²/8075 + (7910-8075)²/8075 = 3.37 + 3.37 = 6.74, p=0.009
- Result: 0.001 < p < 0.05 → investigate. Possible redirect bug on treatment variant.

**Step 3 — Decomposition:**
- Clicks = Sessions × CTR
- Sessions: control 8,240 / treatment 7,910 → -4% (suspicious; SRM likely cause)
- CTR: control 3.1% / treatment 4.0% → +29%
- Math: sessions down 4%, CTR up 29% → net clicks up ~24%, not +31%. Gap unresolved.

**Step 4 — Guardrails:**
- Page load: control 1.1s / treatment 1.4s, +27%, p=0.001 → **HALT**

**Verdict: HALT.** SRM detected (p=0.009) and page load guardrail breached (+27%, p=0.001). Scorecard hidden. Engineering to investigate redirect chain on treatment variant and CDN behavior before any result is interpreted.

Before → After: team was about to write up a "31% lift case study." After Twyman audit, the experiment was correctly halted and re-instrumented. Rerun 2 weeks later (post-fix) showed the true lift was +7% — real, shippable, and trustworthy.

## OUTPUT FILE

Save to: [project-folder]/Kohavi - Click Architecture/[YYYY-MM] - Twyman Anomaly Audit - [Page Name].md
