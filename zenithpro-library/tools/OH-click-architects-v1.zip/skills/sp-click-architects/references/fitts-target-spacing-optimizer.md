---
name: fitts-target-spacing-optimizer
description: Use when a CTA has mis-click complaints, a heatmap shows clicks landing off-target, or spacing between the primary action and adjacent elements looks crowded — diagnoses and fixes button size, hit area, and inter-target spacing to minimize Fitts ID and eliminate accidental dead-clicks.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Paul Fitts (1954; Fitts's Law MT = a + b × log₂(1 + D/W); Shannon formulation 1992) — Click Architecture (Skill 5 of 7)"
interface:
  invoke: "/fitts-target-spacing-optimizer"
  calls: []
  called_by: [user, fitts-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page layout, A/B test winners, and device traffic mix shift frequently; spacing findings become stale as responsive breakpoints change."

fitts_target_cost_auditor_integration:
  feeds_from: fitts-target-cost-auditor
  feeds_to: []
  shared_data: "ID scores per CTA from the auditor become the baseline; this skill applies spacing and sizing fixes to bring ID below threshold."

fitts_thumb_zone_mapper_integration:
  feeds_from: fitts-thumb-zone-mapper
  feeds_to: []
  shared_data: "Thumb-zone heatmap defines the prime pixel on mobile; this skill anchors CTA placement and competitive-target clearance to that zone."

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: kahneman-framing-engineer
  shared_data: "White space added for Fitts W amplification also reduces visual noise that triggers System 2 resistance; share spacing decisions with kahneman for peak-end and isolation-effect framing."

iyengar_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: []
  shared_data: "Competing-target removal (200px radius clearance) aligns with iyengar's choice-set reduction; run iyengar audit first to confirm which secondary elements to suppress vs. relocate."
---

# Fitts Target-Spacing Optimizer

## LAYER 1: INVARIANTS (Never override.)

1. **ID is the master variable.** Every spacing decision must reduce ID = log₂(1 + D/W) on the primary CTA. If a change does not reduce D or increase W, it is decoration, not optimization.
2. **Effective width (We) is measured from click dispersion, not CSS width.** We = 4.133 × SD of actual click coordinates (ISO 9241-9). A visually large button with clustered off-center clicks has a low We and a high effective ID. Always use We when analytics are available.
3. **Competing targets increase D.** Every interactive element within the user's swing path to the CTA forces precision-aiming that inflates D for the primary action. Clearance is not cosmetic — it is mechanical.
4. **Touch and desktop rules invert at the edge.** Desktop screen edges are infinite targets (W = ∞). Mobile edges are the hardest zones. Never apply desktop edge-anchoring logic to a mobile design.
5. **Minimum touch target is a hard floor, not a goal.** Apple HIG: 44×44 pt (~59×59 px). WCAG 2.5.5: 44×44 CSS px. Any CTA below this floor has artificially inflated ID and is non-negotiable to fix before any other spacing work.
6. **Separation of the destructive action is mandatory.** Cancel, Delete, Back must be separated from the primary CTA by maximum physical distance AND visual distinction. Raising the destructive action's ID is as important as lowering the CTA's ID.
7. **Cumulative ID governs multi-step flows.** Each step in a checkout or opt-in sequence has its own CTA with its own ID. The highest-ID step is the conversion bottleneck. Fix it first.

## LAYER 2: QUALITY GUIDANCE

1. Report W, D, and ID as numeric estimates wherever possible. Pixel measurements are preferred; relative estimates (small/medium/large) require a justification note.
2. Every recommendation must state which component of ID it targets: does this reduce D, increase W, or both?
3. Distinguish desktop vs. mobile findings explicitly — the physics differ and the fixes differ.
4. Before-and-after ID estimates are required for every recommended change.
5. If heatmap or session-recording data are available, extract We from click dispersion SD; if not, note the gap and use the CTA's CSS width as a conservative proxy.

## PURPOSE

This skill applies Fitts's Law at the spacing and sizing layer of a web page. Where fitts-target-cost-auditor measures what the ID is, and fitts-primary-action-dominance-scorer ranks CTAs against each other, this skill diagnoses WHY the primary CTA accumulates mis-clicks and dead-clicks — and prescribes exact changes to button dimensions, hit-area extension, inter-target clearance, and page-position that bring ID down to its mechanical minimum.

The lever: MT = a + b × log₂(1 + D/W). Reduce D (move the button closer to the prime pixel or the last interaction point). Increase W (wider button, taller hit area, invisible padding, sticky anchoring). Eliminate competing targets that force the user to aim precisely to avoid a mis-click. The result: "Our primary button is mathematically the easiest thing to hit on the page."

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description with element layout
- The ONE desired action (e.g., "click Buy Now," "submit email opt-in," "start free trial")

**Optional but high-value:**
- Heatmap or click-coordinate export (enables We calculation from SD)
- Session recording noting mis-click rate and bounce events
- Device traffic split (mobile %, desktop %)
- Funnel position (step N of M in a checkout or opt-in flow)
- Current CSS dimensions of the primary CTA and adjacent elements

## EXECUTION PROCESS

### Step 1: Establish the Prime Pixel
Identify where the user's cursor or thumb rests when the page loads.
- **Desktop:** Center of viewport or wherever the user's cursor was from the previous page action (e.g., if they clicked a menu link to get here, the cursor starts near that link).
- **Mobile:** Bottom-center of the screen — the natural dominant-thumb hover position.
- Mark this point. D in every subsequent measurement is the straight-line distance from this point to the CTA's center.

### Step 2: Measure or Estimate W, D, and ID for the Primary CTA
Compute: **ID = log₂(1 + D/W)**

| Symbol | Source | Notes |
|--------|--------|-------|
| W (px) | CSS width | Use effective W from click SD × 4.133 if heatmap available |
| D (px) | Distance: prime pixel → CTA center | Measure in the axis of expected approach |
| ID | Calculated | Interpret: <2 bits = easy; 2-3 bits = moderate; >3.5 bits = high friction |

**Threshold table:**

| ID (bits) | User experience | Action |
|-----------|----------------|--------|
| < 2.0 | Fast, low error | Maintain |
| 2.0 – 3.0 | Moderate friction | Optimize W or D |
| 3.0 – 3.5 | High friction | Fix W AND D |
| > 3.5 | Conversion killer | Urgent redesign |

### Step 3: Compute Effective Width (We) If Data Exist
If click-coordinate data are available: We = 4.133 × SD of click x-coordinates (for horizontal W) or y-coordinates (for vertical W). If We < CSS width, the button is effectively smaller than it appears — users are clustering on a sub-region. Diagnose why (visual bias, label position, hover state) and correct.

### Step 4: Audit the 200px Radius for Competing Targets
List every interactive element (links, buttons, nav items, chat widgets) within a 200px radius of the CTA center. For each:
- Does it draw clicks that could be intended for the CTA?
- Is it visually similar to the CTA (same color, size, or shape)?
- Is it closer to the prime pixel than the CTA (would users hit it first)?

Any element that scores YES on two or more questions is a competing target. Flag for removal, relocation, or visual suppression.

### Step 5: Identify the Two-Phase Movement Bottleneck
The two-phase model: ballistic phase (fast, coarse travel) + homing phase (slow, precise acquisition). Diagnose which phase is the bottleneck:
- **Homing-phase bottleneck (small W):** Users overshoot, hover, correct. Mis-clicks on adjacent elements. Fix: increase W.
- **Ballistic-phase bottleneck (large D):** Users must travel far before they can even enter the homing phase. Fix: reduce D by repositioning or adding a sticky CTA.

### Step 6: Apply Spacing and Sizing Prescriptions (in priority order)

**P1 — Hit-floor check (non-negotiable):**
CTA below 44×44 px (touch) or 32px height (desktop)? Fix immediately. This is the highest-ID correction available.

**P2 — Width expansion:**
Extend CTA to full container width where possible. On mobile: full screen width collapses the homing phase entirely. On desktop: extend to column width and add 12–16px invisible padding on all sides (increase hit area without changing visual footprint).

**P3 — D reduction:**
Reposition CTA to the prime pixel or immediately after the last interaction point (e.g., directly below the email field, not 80px below). Target D < 120px from the prime pixel on mobile; < 200px on desktop.

**P4 — Edge-anchor (desktop):**
Sticky header CTA bar exploits the infinite-target property of the top edge — W is effectively unlimited. Sticky bottom bar: same for the bottom edge. On long-form pages, a sticky CTA cuts D to near-zero regardless of scroll position.

**P5 — Competing target clearance:**
Remove or visually suppress competing interactive elements in the 200px radius. If removal is not possible, add 24px+ of whitespace buffer and reduce the competitor's visual weight (gray text links vs. colored buttons).

**P6 — Destructive action separation:**
Cancel/Back must be: (a) at least 80px from the primary CTA, (b) visually styled as plain text or ghost button, and (c) lower-contrast than the primary CTA. This raises the destructive action's ID while keeping the CTA's ID low.

**P7 — Sticky CTA on long-form pages:**
If the page scrolls more than 2 viewports, add a fixed-position CTA bar. Without it, D grows proportionally with scroll depth — a user 3 screens down must scroll back to click. Sticky CTA keeps D constant at approximately prime-pixel distance.

### Step 7: Score the Cumulative ID (Multi-Step Flows Only)
For checkout or opt-in sequences: calculate ID for each step's CTA. Sum the MTs (MT = a + b × ID; use b ≈ 100ms/bit as a desktop benchmark). Identify the highest-ID step — that is the abandonment point. Fix that step before any other.

### Step 8: Write the Prescription
For each finding, output: current state → diagnosis (which ID component is inflated, which phase is the bottleneck) → exact fix → expected new ID.

## OUTPUT STRUCTURE

**Section 1: Prime Pixel & Baseline ID**
State the prime pixel location, CTA CSS dimensions, estimated D, computed ID, and We (if data available). One paragraph, one table.

**Section 2: Two-Phase Bottleneck Diagnosis**
State whether this is a W problem, a D problem, or both. Name the phase that is the bottleneck. One sentence verdict.

**Section 3: Competing Target Map**
Table of interactive elements within 200px radius. Columns: Element | Distance (px) | Risk | Recommended Action. Max 6 columns, abbreviate if needed.

**Section 4: Prescriptions (Priority-Ordered)**
Numbered list. Each entry: Fix | Component Targeted (D/W/both) | Before ID | After ID | Implementation note.

**Section 5: Destructive Action Clearance**
Current separation from destructive action(s) → recommended separation + styling change.

**Section 6: Cumulative ID Summary (multi-step only)**
Table: Step | CTA size | D estimate | ID | Fix priority.

**Section 7: Quick-Win vs. Structural Changes**
Two-column list. Quick wins (CSS only, < 1 hour) vs. structural (repositioning, sticky implementation, layout changes).

## WORKED MINI-EXAMPLE

**Page:** SaaS pricing page. Single "Start Free Trial" button, 160×44px, positioned 480px below the prime pixel (page center), surrounded by a "Compare plans" link 30px above and a "Schedule a demo" link 40px below.

**Baseline:**
- W = 160px, D = 480px
- ID = log₂(1 + 480/160) = log₂(4) = 2.0 bits — moderate, but competing targets inflate effective D

**Competing targets:** "Compare plans" is 30px above the CTA, visually similar (same blue underline style). Users aiming for the CTA from above hit this link first. "Schedule a demo" is 40px below — mis-clicks on downward overshoots.

**Prescriptions:**
1. Expand CTA to full column width (340px): W 160→340, ID = log₂(1 + 480/340) = 1.49 bits. (Fix: W)
2. Relocate CTA to 120px below the hero headline, near page center: D 480→120, ID = log₂(1 + 120/340) = 0.58 bits. (Fix: D)
3. Restyle "Compare plans" as gray text link, move to page footer. Removes the ballistic-path competitor.
4. Move "Schedule a demo" to a sidebar or below-fold section. 200px clearance from CTA.

**After:** ID ≈ 0.58 bits. Homing phase nearly eliminated. Zero competing targets in the acquisition path. Before: 2.0 bits with interference. After: 0.58 bits clean.

## OUTPUT FILE

Save to: [project-folder]/Fitts - Click Architecture/[YYYY-MM] - Target Spacing Optimizer.md

---
Legend for Section 3 table: Dist = distance in px from CTA center; Risk = H/M/L (High/Medium/Low mis-click risk).
Sibling skills: fitts-target-cost-auditor (baseline ID audit), fitts-primary-action-dominance-scorer (CTA rank vs. page), fitts-thumb-zone-mapper (prime pixel on mobile), fitts-edge-magnet-designer (infinite-target anchoring), fitts-click-path-minimizer (sequential flow MT), fitts-field-intelligence (thinker overview + routing).
