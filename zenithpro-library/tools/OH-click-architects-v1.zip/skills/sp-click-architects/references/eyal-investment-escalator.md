---
name: eyal-investment-escalator
description: Use when a page converts once but loses users before a return visit — diagnoses missing Investment phase triggers and adds stored-value micro-commitments that load the next trigger automatically.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Nir Eyal (Hooked, 2014; Stored Value / Loaded Triggers + Hook Model) — Click Architecture (Skill 4 of 7)"
interface:
  invoke: "/eyal-investment-escalator"
  calls: []
  called_by: [user, eyal-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "User behavior and page analytics drift; variable reward baselines and habit-path data stale after ~6 weeks."

eyal_trigger_architect_integration:
  feeds_from: eyal-trigger-architect
  feeds_to: eyal-trigger-architect
  shared_data: "Trigger-architect identifies which internal emotional state the page must address; Investment-escalator produces the stored-value payload that loads the NEXT trigger after action. The two skills form the closed loop: trigger fires action, investment reloads trigger."

eyal_variable_reward_designer_integration:
  feeds_from: eyal-variable-reward-designer
  feeds_to: eyal-variable-reward-designer
  shared_data: "Variable-reward-designer owns the surprise/novelty mechanism post-action; Investment-escalator hands off the moment the reward is consumed and asks for the follow-on micro-commitment that encodes stored value. Reward fires the dopamine loop; investment locks the user into the next pass."

fogg_field_intelligence_integration:
  feeds_from: fogg-field-intelligence
  feeds_to: fogg-field-intelligence
  shared_data: "Fogg B=MAP governs the Action phase friction scan (Six Elements of Simplicity); Investment-escalator takes over at the post-action moment. Fogg identifies the scarcest resource blocking action; Eyal captures the user momentum that follows cleared friction and converts it into stored value."

thaler_field_intelligence_integration:
  feeds_from: thaler-field-intelligence
  feeds_to: thaler-field-intelligence
  shared_data: "Thaler endowment effect and sunk-cost dynamics amplify investment stickiness. Stored value the user creates (playlists, profile data, reputation scores) feels owned, not rented — Thaler's endowment framing reinforces why defection is psychologically costly."
---

# Eyal Investment Escalator

## LAYER 1: INVARIANTS (Never override.)

1. **Investment must follow reward, never precede it.** Asking for user effort before delivering value violates the Hook sequence and kills compliance. The investment ask lives AFTER the variable reward is consumed, when the user's dopamine-search state is satisfied and goodwill is highest.
2. **Investment does not give immediate gratification — it primes future reward.** Frame every micro-commitment as "this makes what you get next more relevant to you," not as "give us your data." The psychological job of investment is to raise the perceived cost of leaving, not to reward the user now.
3. **Stored value types are concrete and enumerable: Content, Data, Followers, Reputation, Skill.** Each type maps to a specific on-page mechanic. Vague "engagement" is not a stored value type — identify the exact bucket.
4. **Investment loads the NEXT trigger.** The investment step is only complete when it changes the probability that the user self-triggers a return visit. If the action does not increase return frequency, it is not investment — it is data extraction.
5. **Every investment ask must be a single, low-friction micro-commitment.** Never stack multiple investments at one point. One ask per pass through the loop. Stacking raises brain-cycle cost and collapses the compliance rate.
6. **Investment stickiness is proportional to perceived ownership, not volume.** One piece of content the user created (a saved list, a named preference) is more defection-resistant than ten data points the system collected silently. Make the stored value feel like the user's, not yours.
7. **The Habit Zone check is mandatory before designing any Investment sequence.** If the target action plots outside the Habit Zone (low frequency AND low perceived utility), loop design is premature. Build utility first; loops second.

## LAYER 2: QUALITY GUIDANCE

1. **Test the Investment step in isolation.** A/B the presence vs. absence of the post-action micro-commitment and measure 7-day return rate, not just same-session metrics. Investment's KPI is return frequency, not click-through.
2. **Use the 5% habitual-user threshold as the loop health signal.** If fewer than 5% of users return without an external trigger (email, ad) after three sessions, the loop is broken. Diagnose which of the four Hook phases is failing before adding more investment mechanics.
3. **Language in every investment ask must position the output as user-owned.** "Your playlist," "your profile," "your score" — not "help us personalize." Endowment language (Thaler) amplifies the psychological cost of defecting.
4. **Map stored value type to the specific defection scenario it prevents.** Content stored value prevents "I'll just Google it." Follower stored value prevents "I'll just post on [other platform]." Diagnose the actual defection path before choosing the investment type.
5. **Habit Path mapping is the ground truth for investment placement.** Session recordings + funnel data reveal the exact action sequence of your top 10% loyal users. The investment ask belongs at the last step on that proven path — not in the middle of it.

## PURPOSE

This skill operates on a specific web page to add the Investment phase of the Hook Model: stored-value micro-commitments that increase the product's value to the user AND load the next trigger, closing the loop so the next visit is self-generated rather than externally prompted.

The lever is Eyal's Stored Value / Loaded Triggers mechanism, rooted in Skinner's variable-ratio schedule. Each pass through the loop that ends in Investment deepens the user's psychological switching cost and makes defection progressively more irrational — not because you locked them in, but because they loaded value they do not want to abandon.

**Brag line (PURPOSE statement):** "Our product builds a return habit, by design."

The five stored-value types (Content, Data, Followers, Reputation, Skill) each map to a concrete on-page mechanic. This skill selects the right type for this page, this funnel position, and this desired action — then specifies the exact ask, placement, framing, and trigger it loads.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description (enough to identify page type, funnel position, and primary CTA)
- The ONE desired action (e.g., email opt-in, purchase, free trial activation, content download)

**Strongly recommended:**
- Analytics: return visit rate at 7 days, % of users who self-trigger vs. require email/ad
- Session recordings or heatmap data (Habit Path evidence)
- Audience description: sophistication level, likely internal trigger emotion, alternatives they might defect to

**Optional:**
- Existing Hook sequence on the page (if trigger and reward are already designed)
- Funnel position: top/mid/bottom of funnel affects investment type selection

## EXECUTION PROCESS

### Step 1 — Habit Zone Qualification (Gate)

Before any investment design, plot the target action on the Frequency x Perceived Utility matrix.

- **Frequency score (1-5):** How often does your user naturally encounter the internal trigger this page addresses? Daily boredom/fear/loneliness = 5. Annual purchase decision = 1.
- **Perceived Utility score (1-5):** How much more useful is this product vs. the user's next-best alternative? Irreplaceable = 5. Commodity = 1.

**Habit Zone threshold:** Either Frequency >= 3 OR Perceived Utility >= 4. If both are below threshold, stop. Investment design is premature — the product must first build utility or increase touchpoint frequency before the loop can install. Document this finding and redirect to eyal-habit-zone-tester.

### Step 2 — Internal Trigger Identification

Write the sentence: "Every time [your user] feels [internal trigger emotion], they [desired action on this page]."

Internal triggers are negative emotions or uncomfortable states, not positive desires. Common triggers for B2B pages: uncertainty about whether they are falling behind, fear of being outcompeted, loneliness of operating without peer input, frustration with their current tool. Name the exact emotion. The investment ask must reinforce this emotional association, not interrupt it.

### Step 3 — Stored Value Type Selection

For this page and desired action, identify the primary stored value bucket:

| Type | Definition | On-Page Mechanic | Defection Prevented |
|------|-----------|-----------------|-------------------|
| Content | User-created or curated items | Saved lists, bookmarks, playlists, notes | "I'll just search elsewhere" |
| Data | Profile, history, preferences | Progress records, personalization answers, usage history | "Starting over is too costly" |
| Followers | Audience the user built here | Subscriber count, community connections | "My audience is here" |
| Reputation | Scores, badges, ratings | Leaderboards, certification levels, review history | "I have status here" |
| Skill | Learned competency inside the product | Mastered features, workflows, keyboard shortcuts | "I'm good at this one" |

**Legend:** "Defection Prevented" = the specific alternative the stored value raises the cost of choosing.

Select ONE primary type for this pass. Choose the type that maps most directly to the defection scenario your analytics show (or, absent data, the most likely defection path given funnel position).

### Step 4 — Investment Ask Design

Design the micro-commitment:

1. **Single ask, lowest viable friction.** One field, one preference, one question. Brain-cycle cost must be near zero — this is post-action, not a new form.
2. **Framing:** "This personalizes [X] for you" — not "Tell us about yourself."
3. **Position:** Immediately after the variable reward is consumed (post-opt-in confirmation page, post-purchase thank-you, end of onboarding step 1). Never before.
4. **Loaded trigger specification:** Define exactly how this investment changes the next trigger. Example: Data stored (preferred topic) -> next email surfaces that topic -> internal trigger (curiosity) fires -> user clicks without prompting.

### Step 5 — Habit Path Alignment

Map the investment ask onto the Habit Path:

1. From session recordings, identify the action sequence shared by your top 10% most loyal users. The investment ask must sit at or immediately after the last step on that path.
2. If no session data is available, place the investment ask on the confirmation/thank-you page (post-primary-action) — this is the universal lowest-resistance insertion point.
3. Remove any element between the primary CTA completion and the investment ask that is not on the Habit Path.

### Step 6 — Trigger Load Verification

Confirm the loop closes:

- State the specific mechanism: "[Investment type] stored -> [trigger type] loaded -> [internal emotion] fired -> [return action] probable."
- If you cannot complete this sentence with concrete page elements, the investment does not close the loop. Redesign.

### Step 7 — Measurement Setup

Define two KPIs before shipping:

1. **7-day self-triggered return rate:** % of users who return without email/ad prompt within 7 days. Baseline this before the investment step goes live.
2. **Investment completion rate:** % of users who complete the micro-commitment after the primary action. Target >= 40% (low friction = high compliance). Below 25% = friction audit required (return to Six Elements of Simplicity scan).

## OUTPUT STRUCTURE

**1. Habit Zone Verdict**
Pass/Fail with Frequency and Perceived Utility scores. If Fail, redirect recommendation.

**2. Internal Trigger Sentence**
"Every time [user] feels [emotion], they [action]." One sentence. Used to pressure-test all copy.

**3. Stored Value Diagnosis**
Current state: what stored value (if any) the page already creates. Gap: what type is missing or misframed.

**4. Investment Ask Specification**
- Ask text (exact copy)
- Placement (exact page location, post-which-action)
- Framing language (user-ownership frame)
- Loaded trigger: what fires next because of this investment

**5. Habit Path Map**
The current confirmed path (or hypothesized path if no data) and where the investment ask inserts.

**6. Loop Closure Statement**
Single sentence: [Investment] -> [Trigger loaded] -> [Internal emotion] -> [Return action].

**7. Before/After CTA Block**
Original post-action page experience vs. revised experience with investment step.

**8. Measurement Plan**
KPI 1 (7-day return rate) baseline and target. KPI 2 (investment completion rate) target and friction-audit trigger threshold.

## WORKED MINI-EXAMPLE

**Page:** SaaS free-trial thank-you page. Desired action: return login within 7 days without email prompt.

**Habit Zone:** Frequency = 4 (daily productivity frustration). Perceived Utility = 3. PASS (Frequency >= 3).

**Internal Trigger Sentence:** "Every time [the user] feels [frustrated that their workflow is fragmented], they [open the tool to consolidate it]."

**Stored Value Gap:** Page currently shows only "Check your email to confirm." Zero stored value created. No trigger loaded.

**Before:**
> "You're in! Check your email to get started."
> [No follow-on ask]

**After:**
> "You're in. One question to make your dashboard useful from day one:"
> "What's the biggest workflow you want to fix first?" [3-option button select: Client reporting / Team handoffs / Task tracking]
> [Stores preference as Data; personalizes first login dashboard]

**Loaded Trigger:** Preference stored -> dashboard surfaces chosen workflow on next login -> internal trigger (frustration with that workflow) fires on sight -> self-triggered return without email prompt.

**Loop Closure Statement:** Data stored (workflow preference) -> owned trigger loaded (personalized dashboard) -> frustration-relief emotion fires on login -> user returns unprompted within 48 hours.

**KPI targets:** 7-day self-triggered return rate: baseline 12% -> target 28%. Investment completion rate: target >= 45% (3-button select = near-zero brain-cycle cost).

## OUTPUT FILE

Save to: [project-folder]/Eyal - Click Architecture/[YYYY-MM] - Investment Escalator Audit.md
