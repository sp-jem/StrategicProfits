---
name: goward-clarity-relevance-optimizer
description: Use when a landing page has high traffic but low conversion and the cause is unclear messaging or audience mismatch — diagnoses and rewrites for LIFT clarity and relevance forces to raise the conversion ceiling before any A/B test is run.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Chris Goward (You Should Test That, 2012; LIFT Model 2009; Kaizen Method 2012) — Click Architecture (Skill 3 of 7)"
interface:
  invoke: "/goward-clarity-relevance-optimizer"
  calls: []
  called_by: [user, goward-field-intelligence, goward-lift-scorer]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Offer language, competitive context, and traffic-source messaging drift — mismatches that were invisible 45 days ago appear as visitors' expectations change."

goward_lift_scorer_integration:
  feeds_from: goward-lift-scorer
  feeds_to: goward-hypothesis-generator
  shared_data: "LIFT six-factor scores (0-10) for Clarity and Relevance; page element inventory; current headline and subhead text"

goward_value_prop_fulcrum_integration:
  feeds_from: goward-value-prop-fulcrum-auditor
  feeds_to: goward-hypothesis-generator
  shared_data: "PODs (Points of Difference) identified in the competitive audit; value-proposition cost-benefit equation scores; buried-copy candidates for headline elevation"

kahneman_framing_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: goward-hypothesis-generator
  shared_data: "Framing direction (gain vs. loss) and anchoring context to apply when rewriting the clarified value prop headline"
---

# Goward Clarity-Relevance Optimizer

## LAYER 1: INVARIANTS (Never override.)

1. Value Proposition is the ceiling. The LIFT Model treats VP as the fulcrum — no amount of clarity or relevance work lifts conversion beyond the ceiling set by a weak or mis-stated VP. Run the POPs/PODs/POIs audit before rewriting a single word.
2. Clarity and Relevance are distinct forces. Clarity is how easily visitors understand the offer; Relevance is how closely the offer matches what brought them to the page. Fixing one without the other leaves lift on the table.
3. Match traffic source language exactly. If the ad said "free trial," the headline must say "free trial." Any terminology mismatch triggers visitor disorientation and exit — there are no exceptions.
4. Buried copy is priority-one test material. Goward's empirical rule: the clearest explanation of what a page does is almost always in the last paragraph. Surface it to the top before writing new copy.
5. First-person button copy is a tested lever, not a preference. "Download My Checklist" consistently outperforms "Download Your Checklist" and any generic label. Apply to every CTA evaluated.
6. No universal best practices. Context governs. Every clarity and relevance recommendation in this skill is a hypothesis to be tested, not a truth to be deployed blind.
7. Single macro-conversion focus. Define the one revenue-driving action before the audit begins. Optimizing for secondary metrics fragments the diagnosis and corrupts recommendations.

## LAYER 2: QUALITY GUIDANCE

1. Score Clarity and Relevance separately on the 0-10 LIFT scale before generating any recommendations. Scores below 6 on either factor demand immediate attention; below 4 demand redesign-level intervention.
2. Every recommendation must name the specific page element (headline, subhead, CTA button, hero image, form label) and the LIFT factor it affects. Generic "improve your messaging" outputs are rejected.
3. Before/after rewrites are required for headline, subhead, and primary CTA button. Describing the change without showing the change is incomplete.
4. Traffic-source segmentation check is mandatory. If multiple traffic sources (paid search, email, social) land on the same page, flag the mismatch risk explicitly. Single-source pages get a different clarity/relevance profile than multi-source pages.
5. POD extraction must precede rewrite. If the value-prop fulcrum audit has not been run, run a compressed POPs/PODs/POIs pass within this skill before touching copy.

## PURPOSE

This skill applies Chris Goward's LIFT Model — specifically the two lift forces of Clarity and Relevance — to diagnose why visitors who want what a page offers still fail to convert, then produces concrete rewrites and prioritized test hypotheses to fix it. The diagnosis is grounded in Goward's Kaizen Method: analytics + source matching + heuristic LIFT analysis + competitive POD extraction, in that sequence, before any test runs.

**Brag line:** "We can score any landing page on 6 conversion forces before testing." — Chris Goward. This skill operationalizes that claim for Clarity and Relevance specifically, giving practitioners a scored diagnosis and ready-to-test hypotheses within a single session.

Skill 3 of 7 in the goward-* cluster. This skill's lane: raising the two lift forces. Anxiety/Distraction reduction belongs to goward-anxiety-distraction-reducer. Value Prop ceiling diagnosis belongs to goward-value-prop-fulcrum-auditor. Urgency belongs to goward-urgency-architect.

## INPUT REQUIREMENTS

**Required:**
- Page: URL, screenshot, or written description of all above-the-fold and form elements
- Desired action: the single macro-conversion event (e.g., "opt-in for free checklist," "purchase plan," "start free trial")

**Strongly recommended:**
- Traffic source(s) and the exact ad/email copy that drives traffic to this page
- Analytics: bounce rate, time-on-page, scroll depth (identifies where clarity breaks)
- Funnel position: cold traffic, warm list, retargeting, post-demo

**Optional:**
- Competitor landing pages (enables POPs/PODs/POIs pass)
- Existing customer language (survey verbatims, chat logs, review mining)

## EXECUTION PROCESS

### Step 1 — Traffic Source Audit (Relevance Diagnosis)

List every traffic source hitting the page. For each:
- Extract the exact headline/subject line/ad copy that drove the click
- Score terminology match: Does the page's H1 use the same core phrase the visitor just clicked? (Yes = 10, Partial = 5, No = 0)
- Score audience alignment: Does the page's assumed customer state match where this source's visitor actually is in their awareness journey? (Perfectly aligned = 10, one stage off = 5, two+ stages off = 2)

**Relevance Score** = average of terminology match + audience alignment, divided by 2. Below 6: critical. Below 4: redesign required.

Flag: if multiple traffic sources land on one page, the page cannot be fully relevant to all of them. Recommend dedicated landing pages per source if Relevance scores differ by 3+ points across sources.

### Step 2 — Compressed POPs/PODs/POIs Audit

Build a three-column table (max 5 rows each; use abbreviations if needed):

| Prospect Need | Competitors Have | You Have |
|---------------|-----------------|----------|
| [need]        | Y / N           | Y / N    |

Identify the POD column: needs that are important AND competitors cannot match. If the current headline/subhead does not feature a POD, that is a Clarity + Relevance failure simultaneously — the page is leading with parity, not difference.

**If PODs identified:** mark them as Primary Rewrite Targets.
**If no PODs found:** escalate to goward-value-prop-fulcrum-auditor before continuing. Clarity work on a parity value prop is wasted effort.

### Step 3 — Clarity Score: Above-the-Fold Audit

Evaluate these six sub-factors. Score each 0-10:

| Sub-factor | Question | Score |
|------------|----------|-------|
| H1 specificity | Does H1 name a concrete outcome, audience, or mechanism — not a tagline? | |
| Subhead support | Does the subhead answer "how" or "for whom" the H1 delivers? | |
| Buried copy | Is the clearest plain-language explanation of the offer above the fold? | |
| CTA label | Does the button name the specific action and its immediate benefit? | |
| Visual hierarchy | Does the eye path lead: H1 → subhead → CTA without detours? | |
| Jargon load | Is every term understood by a first-time visitor with no prior exposure? | |

**Clarity Score** = average of six sub-factors. Below 6: rewrite required. Below 4: structural redesign.

### Step 4 — Buried Copy Extraction

Read the page bottom-to-top. Find the single paragraph or sentence that most plainly explains what the offer is, who it is for, and what the visitor gets. This is almost always in a footer, an "about this program" section, or a final reassurance block.

Copy it verbatim. This is your Headline Candidate #1.

### Step 5 — Rewrite Package

Produce all three before/after pairs. Use POD from Step 2, plain language from Step 4, and traffic-source language from Step 1.

**Headline (H1):**
- Before: [current H1 verbatim]
- After: [POD-forward, plain-language, traffic-source-matched rewrite]
- Rule applied: [buried copy elevated / POD surfaced / source terminology matched]

**Subhead:**
- Before: [current subhead verbatim]
- After: [answers "how" or "for whom"; adds the second-most important POD or the mechanism]
- Rule applied: [specificity / jargon removal / audience narrowing]

**Primary CTA Button:**
- Before: [current label verbatim]
- After: [first-person action + immediate benefit] — e.g., "Get My Free Checklist" not "Download Now"
- Rule applied: first-person possession; action-oriented; benefit-named

### Step 6 — Relevance: Funnel-Position Match Check

Score the page's assumed visitor awareness against the actual traffic source:

| Awareness Stage | Description | Match? |
|----------------|-------------|--------|
| Unaware | Has the problem, does not know it | |
| Problem-aware | Knows the problem, not the solution category | |
| Solution-aware | Knows the category, not your brand | |
| Product-aware | Knows your brand, evaluating | |
| Most-aware | Ready to act, needs terms | |

If cold paid traffic lands on a page written for product-aware visitors, the Relevance gap is the primary conversion killer. Recommendation: rewrite the lead frame (H1 + first 50 words) for the actual awareness stage. Do not rewrite the offer.

### Step 7 — Prioritized Hypothesis Stack

Produce 3-5 testable hypotheses, ordered by expected lift × ease:

| # | Hypothesis | Element | LIFT Factor | Rationale |
|---|-----------|---------|-------------|-----------|
| 1 | [If we change X to Y, conversion will increase because Z] | [element] | Clarity / Relevance | [mechanism] |

Flag one "left field" variation — a hypothesis that isolates a never-tested element (layout shift, traffic-specific page variant, self-identification question before CTA).

## OUTPUT STRUCTURE

1. **Relevance Score** — per traffic source, scored and flagged
2. **Clarity Score** — six sub-factor table with scores and total
3. **POPs/PODs/POIs Summary** — three-column table, PODs highlighted
4. **Rewrite Package** — H1, subhead, CTA: before/after with rule applied
5. **Awareness-Stage Match** — current vs. required, gap diagnosis
6. **Hypothesis Stack** — 3-5 prioritized, table format, one left-field variation
7. **Next Skill** — routes to goward-hypothesis-generator or goward-anxiety-distraction-reducer based on which LIFT factor scores lowest after rewrites

## WORKED MINI-EXAMPLE

**Page:** SaaS free trial signup. Traffic source: Google Ads, ad headline "Project Management for Remote Teams."

**Before:**
- H1: "Work Better Together" (tagline — Clarity score: 3)
- Subhead: "The platform built for collaboration" (parity — no POD, Clarity score: 4)
- CTA: "Get Started" (generic — Clarity score: 4)
- Buried copy found at page bottom: "Finally, a project management tool where remote teams finish projects on time without chasing status updates in Slack."
- Relevance: ad said "remote teams," H1 says nothing about remote — Relevance score: 4

**After:**
- H1: "Remote Teams Finish Projects On Time — Without Status-Update Slack Threads" (buried copy elevated + source terminology "remote teams" matched)
- Subhead: "See how 4,200 distributed teams cut meeting load by 40% in their first month" (mechanism + social proof + specificity)
- CTA: "Start My Free Trial" (first-person + mirrors ad's implied offer)
- Relevance score lifted: 9 (terminology matched, awareness stage matched — solution-aware cold traffic)
- Clarity score lifted: 8

**Hypothesis #1:** Headline swap (current tagline → elevated buried copy) will increase trial starts because it matches traffic-source language and surfaces the concrete outcome currently hidden at page bottom.

## OUTPUT FILE

Save to: [project-folder]/Goward - Click Architecture/[YYYY-MM] - Clarity-Relevance Optimizer.md
