---
name: eyal-variable-reward-designer
description: Use when a page has a working CTA but low return-visit rate, or when post-action experience is flat/predictable — designs the Skinner variable-ratio reward schedule across the Hook loop phases to build compulsive return behavior without crossing into manipulation.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Nir Eyal (Hooked, 2014; Three Variable Reward Categories + Skinner Variable-Ratio Schedule) — Click Architecture (Skill 3 of 7)"
interface:
  invoke: "/eyal-variable-reward-designer"
  calls: []
  called_by: [user, eyal-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Audience reward-saturation shifts with feed algorithm changes, competitive novelty, and seasonal attention cycles — variable schedules habituate faster when competitors copy the pattern."

eyal_hook_loop_integration:
  feeds_from: eyal-trigger-architect
  feeds_to: eyal-investment-escalator
  shared_data: "Internal trigger emotion identified by trigger-architect becomes the 'search-mode' target the reward schedule is calibrated to relieve; investment escalator receives the stored-value type (Tribe/Hunt/Self) to load the next trigger."

fogg_behavior_integration:
  feeds_from: fogg-behavior-mapper
  feeds_to: fogg-prompt-designer
  shared_data: "Six Elements of Simplicity audit output from fogg-behavior-mapper identifies the scarcest friction resource; this skill places the variable reward immediately AFTER that friction is eliminated to maximize dopamine-gap effect."

kahneman_peak_end_integration:
  feeds_from: kahneman-peak-end-architect
  feeds_to: kahneman-framing-engineer
  shared_data: "Kahneman peak-end rule governs which reward moment is encoded in memory; this skill identifies the peak reward moment in the Hook sequence and ensures it is variable (not guaranteed) to prevent habituation of the peak."
---

# Eyal Variable Reward Designer

## LAYER 1: INVARIANTS (Never override.)

1. **Variability is the mechanism, not the reward.** The dopamine-driven search state is triggered by unpredictability, not by the reward itself. A guaranteed reward habituates. An unpredictable one maintains the seeking loop. Every reward touchpoint on the page must have at least one dimension of surprise.
2. **Three categories, not one.** Effective Hook loops layer all three Skinner categories: Tribe (social validation), Hunt (unpredictable resource acquisition), Self (mastery/completion). A page relying on only one category saturates faster and loses the habit loop within 3–5 sessions.
3. **Variable reward follows action — never precedes it.** Placing the reward before the action (e.g., showing the bonus content in the opt-in preview) eliminates the search state. The reward must be behind the behavioral gate.
4. **Habit Zone pre-qualification is mandatory.** Before designing any reward loop, plot the target action on the Frequency x Perceived Utility matrix. If both axes score low, no reward schedule will install a habit — optimize for single conversion instead and do not build a loop.
5. **Internal trigger must be named.** The reward schedule is calibrated to relieve a specific internal emotional trigger (boredom, uncertainty, loneliness, fear of missing out). If the emotion is unnamed, the loop has no anchor and will not self-reinforce.
6. **Investment loads the next trigger — not the current reward.** The Investment phase (post-action micro-commitment) is NOT a second reward. Its function is to store value that makes the user's next return more personally relevant. Conflating investment with reward breaks the loop structure.
7. **Manipulation Matrix boundary.** Eyal's own test: if the designer would use the product themselves AND believes it materially improves the user's life, proceed. If either is false, this skill defers to eyal-manipulation-matrix-guard before execution.

## LAYER 2: QUALITY GUIDANCE

1. **Name the emotion, not the product.** Every headline, subhead, and CTA label must address the internal trigger state the user is in right now. "I see your pain" precedes "here is the solution." Copy that opens with product features fails to activate the trigger-reward association.
2. **Reward surprise must be genuine.** A "bonus" announced in advance is not variable. The post-action reveal must be something the user could not have predicted from pre-action page content — a personalized result, an unexpected resource, a social signal they did not know existed.
3. **Progress indicators serve Rewards of the Self.** Visible completion states (progress bars, streak counters, inbox-zero states) generate intrinsic motivation. They must show the gap between current state and a named mastery milestone — not just a percentage — to activate the completion drive.
4. **Social proof sections serve Rewards of the Tribe only when dynamic.** Static testimonials are weak Tribe rewards. Live purchase notifications, real-time member counts, and recent-activity feeds introduce variability into social proof, mimicking the unpredictable stream that maintains search mode.
5. **Minimum viable surprise.** The surprise element does not need to be large — it needs to be unexpected. A single personalized sentence generated from opt-in data, a counter that shows a number the user didn't expect, or a curated resource the user did not see before action all qualify. Magnitude is less important than unpredictability.

## PURPOSE

This skill engineers the variable-ratio reward schedule embedded in the Hook Model's Action and Variable Reward phases for a specific web page, using Skinner's operant conditioning logic as translated by Eyal into three reward categories: Tribe, Hunt, and Self. It diagnoses which reward type is absent or predictable, then prescribes concrete on-page changes that introduce the variability required to keep users in dopamine-driven search mode and compel return visits — without guaranteeing satisfaction or crossing into compulsion.

**Brag line:** "Our product builds a return habit, by design."

This is the Skinner engine: the lever that distinguishes a page users visit once from a page users return to automatically, without an external prompt.

## INPUT REQUIREMENTS

**Required:**
- The page (URL, live screenshot, or written description including all visible elements)
- The ONE desired action (click / opt-in / purchase / next step)

**Strongly recommended:**
- Return-visit rate / 7-day retention (baseline habit metric)
- Post-action experience description (thank-you page, confirmation email, follow-on state)
- Funnel position (cold traffic / warm retarget / existing user)
- Audience's primary internal trigger emotion (if known from prior research)

**Optional:**
- Session recording or heatmap data (for Habit Path identification)
- Competitor post-action experiences (for Hunt reward benchmarking)
- Current A/B test results on CTA or post-action variants

## EXECUTION PROCESS

### Step 1 — Habit Zone Pre-Qualification (5 min)

Plot the target action on the two-axis matrix before any reward design:

| | Low Frequency | High Frequency |
|---|---|---|
| **High Utility** | Habit possible (Amazon model) | Core habit zone |
| **Low Utility** | No habit loop possible | Marginal — needs utility lift |

**Threshold:** If both axes score below midpoint, output a single-conversion optimization brief instead of a reward loop design. Do not build a loop for an action that cannot become habitual.

Score each axis 1–5 from user's perspective (not yours). Document scores before proceeding.

### Step 2 — Internal Trigger Identification

Write the narrative sentence: "Every time [user persona] feels [specific emotion], they [desired action on this page]."

The emotion must be one of the canonical internal trigger categories: boredom, loneliness, uncertainty, fear, confusion, inadequacy, FOMO. Generic substitutes ("want more") are not internal triggers — they are desires. Internal triggers are uncomfortable states the user wants to relieve.

If no internal trigger can be named with confidence, flag: "Internal trigger unknown — run user interview protocol before reward design."

### Step 3 — Variable Reward Audit (Current State)

Audit the page's current Action → Reward → Investment sequence. Score each dimension:

| Category | Signal to Check | Predictable? | Variable? |
|---|---|---|---|
| Tribe | Social proof: static vs dynamic | — | — |
| Hunt | Post-action reveal: known vs surprise | — | — |
| Self | Progress indicator: present/absent | — | — |

**Scoring:**
- 0 = category absent
- 1 = present but fully predictable (habituation risk)
- 2 = present with genuine variability

**Diagnosis threshold:** Total score ≤ 3 = reward schedule is broken. Total 4–5 = partially functional. 6 = fully operational (rare on first audit).

### Step 4 — Friction Elimination (Scarcest Resource First)

Run the Six Elements of Simplicity audit on the primary CTA and any form:

| Element | Friction Present? | User Scarcest? |
|---|---|---|
| Time | — | — |
| Money | — | — |
| Effort | — | — |
| Brain cycles | — | — |
| Social deviance | — | — |
| Non-routine | — | — |

**Rule:** Cold traffic almost always bottlenecks on brain cycles (cognitive load of unfamiliar decision) and non-routine (behavior doesn't map to existing habit). Eliminate the single scarcest resource first. Do not attempt to eliminate all six simultaneously — that dilutes focus and produces generic copy.

The variable reward must be placed immediately after this friction is cleared, not before. Sequence: friction cleared → action taken → variable reward fires.

### Step 5 — Reward Schedule Design (Per Category)

For each absent or predictable category, prescribe one concrete change:

**Tribe reward prescriptions:**
- Replace static testimonial block with live activity feed (X users joined in last 24h, recent purchase notifications, real-time member count)
- Add a post-opt-in social signal: "You joined [N] others who [specific outcome]" — where N updates dynamically
- Show a community proof element that varies by time of day or recency (introduces variability even if underlying data is stable)

**Hunt reward prescriptions:**
- Add a post-action bonus reveal: do not announce the bonus before action; reveal it only on the thank-you page or in the first email, framed as "something we don't advertise"
- Introduce a curated resource that appears to be personalized to the user's opt-in answers (even minimal personalization — "because you said X, here is Y" — activates hunt-mode)
- Use a limited-access or time-gated item revealed only after primary action; variability comes from the user not knowing what they will find

**Self reward prescriptions:**
- Install a visible multi-step progress indicator on any multi-page funnel: show step N of M AND the named mastery milestone at step M
- Add a streak or return-visit counter for returning users: "You've visited X times — most members who reach [milestone] have visited Y times"
- Use an inbox-zero or completion state after action: "Your spot is confirmed — 0 items left before your first session" activates completion drive

### Step 6 — Investment Phase (Loads the Next Trigger)

Immediately after the variable reward fires, install one micro-investment:

**Formula:** Ask the user to store one piece of data that makes their next return more personally relevant.

Options (choose the lowest-friction for your audience):
- One preference question ("What's your biggest challenge right now? A / B / C")
- One customization (choose your track, choose your focus area)
- One identity marker (name, role, goal — anything that personalizes the follow-on trigger)

**Frame:** "Personalizes your [program/feed/results]" — not "helps us understand you." The stored value must feel like it belongs to the user.

### Step 7 — Habit Path Mapping (If Analytics Available)

1. Identify top 10% most loyal returning users from analytics
2. Extract the exact action sequence they share (session recordings or funnel analysis)
3. Find the minimum viable action chain between first trigger and first reward
4. Strip any page element not on that path
5. Measure: what % of new users hit that same path within session 1?

**Threshold:** If fewer than 5% of users perform the target action without external trigger after 3+ sessions, the Hook loop has not installed. Re-diagnose which phase (Trigger / Action / Reward / Investment) is breaking before iterating reward design.

### Step 8 — Measurement Setup

Primary habit metric: **7-day return rate without external trigger** (organic return, not email-prompted)

Secondary metrics:
- A/B: predictable post-action vs. variable post-action — measure return visit rate AND time-on-page after action (not just conversion rate)
- 5% habitual-user threshold check at day 14 and day 30
- Habit Path adoption: % of new users hitting the identified sequence in session 1

## OUTPUT STRUCTURE

**1. Habit Zone Verdict** — Frequency score / Utility score / Recommendation: loop or single-conversion

**2. Internal Trigger Statement** — "Every time [persona] feels [emotion], they [action]"

**3. Variable Reward Audit Scorecard** — Current state by category (Tribe / Hunt / Self), score, diagnosis

**4. Six Elements Audit** — Scarcest friction resource identified, prescribed elimination

**5. Reward Schedule Prescriptions** — Specific on-page changes per category (Tribe / Hunt / Self), with before/after copy or UX description

**6. Investment Phase Design** — Exact micro-commitment to install, framing language

**7. Habit Path Recommendation** — Minimum viable action sequence (or "requires analytics — run session recording audit")

**8. Measurement Plan** — 7-day return rate baseline, A/B test design, threshold checkpoints

## WORKED MINI-EXAMPLE

**Page:** Email opt-in landing page for a free productivity framework PDF.
**Desired action:** Email opt-in.

**Before (Broken reward schedule):**
- Headline: "Download Our Free Productivity Framework" (product-first, no internal trigger)
- CTA: "Submit" (no trigger implication)
- Thank-you page: "Thanks for subscribing. Your PDF is on its way." (fully predictable, no variable reward)
- No post-action investment prompt
- Static testimonials ("This PDF changed my workflow. — J.S.")
- 7-day return rate: 4% (below 5% habit threshold)

**After (Variable reward schedule installed):**

*Trigger fix:* Headline becomes "Still losing 2 hours a day to decisions you've already made?" (names the internal trigger: low-grade frustration/uncertainty)

*Action fix:* Six Elements audit reveals brain cycles is scarcest for cold traffic. Form reduced from 4 fields to email only. CTA becomes "Send Me the Framework" (names the action and implies relief).

*Variable reward — Hunt:* Thank-you page reveals: "One more thing — we don't advertise this, but the framework comes with a companion decision audit most people find more useful than the PDF itself. It's yours." (unpredictable bonus, discovered only post-action)

*Variable reward — Tribe:* Thank-you page adds a live counter: "You joined 847 people who downloaded this in the last 30 days — [N] of them reported clearing their decision backlog within a week." (dynamic social signal, not static testimonial)

*Variable reward — Self:* A 3-step onboarding sequence shown on thank-you page: "Step 1 of 3: Framework received. Step 2: Run your first audit (takes 12 min). Step 3: Post your result to the community." Progress gap activates completion drive.

*Investment fix:* One question on thank-you page: "Which area costs you the most time? A) Email B) Meetings C) Projects" — framed as "personalizes the companion audit for you."

*Measurement:* A/B test: control (predictable PDF download) vs. treatment (variable reward sequence). Primary metric: 7-day return rate. Hypothesis: treatment increases return rate from 4% to 10%+, crossing the 5% habitual-user threshold.

## OUTPUT FILE

Save to: [project-folder]/Eyal - Click Architecture/[YYYY-MM] - Variable Reward Schedule Design.md
