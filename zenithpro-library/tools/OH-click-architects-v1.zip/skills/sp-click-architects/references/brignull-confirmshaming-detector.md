---
name: brignull-confirmshaming-detector
description: Use when a page has opt-out links, decline copy, dismiss buttons, or newsletter/offer refusals — detect confirmshaming and all shame-loaded decline language, then rewrite to neutral, disclosure-proof alternatives.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Harry Brignull (deceptivedesigns.com 2010–2023; 16-Pattern Deceptive Design Taxonomy + Disclosure Test) — Click Architecture (Skill 3 of 7)"
interface:
  invoke: "/brignull-confirmshaming-detector"
  calls: []
  called_by: [user, brignull-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Regulatory enforcement language evolves; new confirmshaming variants appear as A/B test cycles complete and dark-pattern litigation shifts what sites believe they can publish."

brignull_dark_pattern_scanner_integration:
  feeds_from: brignull-dark-pattern-scanner passes the full 16-pattern inventory; confirmshaming-detector deep-dives pattern #2 (Confirmshaming) and its Misdirection superclass.
  feeds_to: confirmshaming-detector outputs rewritten decline copy that dark-pattern-scanner can re-scan to confirm clean.
  shared_data: page URL, desired action, Misdirection superclass hit-list.

fogg_field_intelligence_integration:
  feeds_from: fogg-field-intelligence surfaces motivation wave state — confirmshaming exploits high-motivation moments; knowing the wave position calibrates severity of the shame load.
  feeds_to: rewritten decline copy that removes coercion leaves only genuine motivation intact; Fogg's Tiny Habits framing can audit whether the replacement language still uses legitimate persuasion.
  shared_data: user motivation state, trigger timing, ability rating for the decline action.

kahneman_field_intelligence_integration:
  feeds_from: kahneman-field-intelligence identifies active cognitive biases (loss aversion, framing effect, isolation effect) that confirmshaming leverages.
  feeds_to: rewritten copy strips the loss-aversion frame from declines; kahneman can verify the replacement is System 2-safe (not exploiting the same bias in disguise).
  shared_data: bias inventory, framing polarity of original copy, before/after Prospect Theory exposure.

cialdini_field_intelligence_integration:
  feeds_from: cialdini-field-intelligence flags Scarcity and Social Proof elements that confirmshaming piggybacks on ("No thanks, I don't want what 10,000 others already have").
  feeds_to: confirmshaming detector identifies which Cialdini principle is being weaponized in each shame phrase so Cialdini integration can audit whether the principle survives ethical use.
  shared_data: influence principle taxonomy, shame-trigger phrase list, principle × shame cross-reference table.
---

# Brignull Confirmshaming Detector

## LAYER 1: INVARIANTS (Never override.)

1. **Confirmshaming is a named Misdirection subtype** in the Mathur et al. taxonomy (2019): copy that makes users feel foolish, cheap, or morally inferior for declining. The detector operates on language, not just intent.
2. **The Disclosure Test governs every finding.** For each suspect phrase: if a regulator read it aloud in court, would the user's consent be embarrassed? If yes — that is the finding; rewrite is mandatory.
3. **Neutral decline copy is the output standard.** Not "softer shame." Not "nicer tone." Factual. Symmetric. If the CTA says "Save 30% now," the decline says "No thanks, I'll pay full price." No self-deprecation required from the user.
4. **Shame operates on the Conti-Sobiesk Coercion axis.** Confirmshaming forces users into an unwanted action (accepting an offer or opt-in) by making the alternative self-attack. Document the axis for each instance.
5. **The pattern survives design changes if copy is unchanged.** A redesigned page that keeps the shame phrase is still guilty. This skill audits COPY, not layout.
6. **Severity is graded against the Dark Pattern Recipe.** If A/B testing evidence appears (variant copy, test IDs in URL parameters), severity escalates to CRITICAL — the shame was optimized deliberately.
7. **Every shame instance gets a rewrite.** No instance is flagged without a concrete replacement. Flagging without fixing is incomplete work.

## LAYER 2: QUALITY GUIDANCE

1. **Catalog, don't summarize.** Every decline link, dismiss button, opt-out label, and modal close text on the page gets individual treatment. One scan missed is one pattern left live.
2. **Classify by Conti-Sobiesk axis.** Each instance maps to Coercion, Confusion, Distraction, Interruption, or Obfuscation. Most confirmshaming is Coercion; some layered instances also trigger Confusion (e.g., double-negative shame phrases).
3. **Apply the Honesty Spectrum.** Rate each instance: Transparent (neutral) → Omission (muted shame) → Deliberate Deception (direct self-attack). Only Transparent passes.
4. **Note the exploited bias.** Confirm what psychological lever the shame phrase uses (loss aversion, social proof, identity threat, self-consistency). This enables the Kahneman/Cialdini integration hooks.
5. **Rewrite must pass a mirror test.** Read the rewrite aloud. If it sounds like it was written to make the user feel bad in any way, revise again.

## PURPOSE

This skill deploys Harry Brignull's Confirmshaming pattern (Misdirection subcategory, 16-Pattern Taxonomy) and the Disclosure Test on a specific web page to identify every shame-loaded decline, dismiss, or opt-out phrase — then rewrites each to neutral, disclosure-proof language.

**Brag line:** "We use the strongest levers known — and we know exactly where the line is."

Confirmshaming works by making refusal feel like self-attack. The user clicks "No thanks, I hate free money" not because they changed their mind but because the interface manufactured shame. Under Brignull's Dark Pattern Recipe, this is Applied Psychology (loss aversion, identity threat) + A/B Testing (the phrase that generates most compliance is deployed) + UI Design (the shame word is the label; there is no neutral alternative). The Disclosure Test collapses it immediately: describe the mechanism to a fully-informed user and they refuse consent.

This skill removes the coercion and leaves only legitimate persuasion, so any increase in opt-in or purchase rate reflects genuine user preference.

## INPUT REQUIREMENTS

**Required:**
- **Page:** URL, screenshot, or written description of the page at sufficient detail to read all microcopy.
- **Desired action:** One action (e.g., "newsletter opt-in," "trial signup," "upsell purchase," "push notification consent").

**Optional (improves scoring):**
- Analytics: opt-in rate, dismiss rate, bounce rate at the modal/offer step.
- Audience: first-time visitors vs. returning customers (context affects severity).
- Funnel position: top-of-funnel awareness vs. checkout (mid-funnel shame is more coercive).
- URL parameters or variant IDs (evidence of A/B optimization triggers CRITICAL severity).

## EXECUTION PROCESS

**Step 1 — Full Decline Copy Inventory**

Scan every element that is not the primary CTA:
- "No thanks" / dismiss / close links on modals and popups.
- Opt-out checkboxes and their adjacent labels.
- Secondary links below or beside the primary CTA ("I don't want X").
- Cookie consent decline options.
- Newsletter / push notification / upsell refusal copy.
- GDPR consent withdrawal paths.

List each as a numbered instance: location, verbatim copy, element type (link / label / button / checkbox caption).

**Step 2 — Shame Trigger Detection**

For each instance, apply the four-question filter:

| Q | Test | Fail Condition |
|---|------|----------------|
| Q1 | Does declining require the user to make a self-deprecating statement? | Any "I hate X," "I don't want Y," "I'm not interested in my success" |
| Q2 | Does the copy assign a negative identity to the decliner? | "Only [lazy / broke / unambitious] people say no" |
| Q3 | Does the copy invoke a social norm the user violates by declining? | "Join the 10,000 who said yes — or not" |
| Q4 | Does the copy use loss-aversion framing to make refusal feel like a mistake? | "No thanks, I'll miss out" / "I'd rather pay more" |

Any "yes" = Shame Confirmed. Record Q-triggers fired per instance.

**Step 3 — Conti-Sobiesk Axis Classification**

Map each confirmed instance:
- **Coercion** — Forces user into action by making alternative painful (most confirmshaming).
- **Confusion** — Double-negative shame phrases obscure what the user is actually declining.
- **Distraction** — Shame copy draws attention away from the offer terms.
- **Interruption** — Shame triggers mid-task (checkout flow, article read) to exploit cognitive load.
- **Obfuscation** — Shame buried inside terms or visually de-emphasized but still present.

**Step 4 — Disclosure Test**

For each confirmed instance, write one sentence describing what the element does in plain language (as if to a regulator). Ask: would a fully-informed user still click the primary CTA? If the mechanism only works because the user does not fully understand it is a coercion device, the test fails.

**Step 5 — Severity Scoring**

Score each instance 1–5:

| Score | Criteria |
|-------|----------|
| 1 | Mild implication, no direct self-attack, passes Disclosure Test marginally |
| 2 | Implied shame, user not forced to vocalize it |
| 3 | Direct shame phrase user must "say" by clicking |
| 4 | Identity attack or social norm violation framing |
| 5 | CRITICAL: A/B test evidence, legal-exposure language, multiple Q-triggers |

**Step 6 — Honesty Spectrum Rating**

Rate each instance on Brignull's three-point Honesty Spectrum:
- **Transparent** — Neutral, factual, no shame. Passes.
- **Omission** — Muted shame or asymmetric framing. Borderline; flag for monitoring.
- **Deliberate Deception** — Active shame mechanism. Must rewrite.

**Step 7 — Rewrite**

For every instance at Omission or Deliberate Deception, produce a rewrite that:
1. Uses factual language symmetrical to the CTA.
2. Does not require self-deprecation.
3. Passes the Disclosure Test.
4. Passes the mirror test (read aloud — no residual shame).

Rewrite formula: "No thanks, [factual statement of what they are forgoing]." Not a judgment. Not an invitation to reconsider. A fact.

**Step 8 — Aggregate Risk Rating**

| Finding | Score |
|---------|-------|
| Zero instances | CLEAN |
| 1–2 instances, severity ≤ 3 | LOW RISK |
| 3+ instances OR any severity 4 | MEDIUM RISK |
| Any severity 5 OR legal-exposure language | HIGH RISK / CRITICAL |

## OUTPUT STRUCTURE

**Section 1 — Decline Copy Inventory**
Full enumerated list of every decline element found. Verbatim copy. Element type. Location on page.

**Section 2 — Shame Instances (Findings)**
For each confirmed shame instance:
- Verbatim copy
- Q-triggers fired (Q1–Q4)
- Conti-Sobiesk axis
- Disclosure Test result (pass/fail + one-sentence description)
- Severity score (1–5)
- Honesty Spectrum position

**Section 3 — Rewrites**
For each Omission or Deliberate Deception instance:
- Original (verbatim)
- Rewrite (ready to implement)
- Bias exploited (so Kahneman/Cialdini integration can cross-reference)

**Section 4 — Aggregate Risk Rating**
Single rating with rationale. Priority order for fixes.

**Section 5 — Implementation Notes**
Dev handoff: element selector (if URL provided), change required, estimated lines of copy affected.

## WORKED MINI-EXAMPLE

**Page:** SaaS newsletter popup. Desired action: email opt-in.

**Primary CTA:** "Yes! Send me the weekly growth tips."
**Decline link:** "No thanks, I don't want to grow my business."

**Shame analysis:**
- Q1: Yes — user must state they don't want business growth.
- Q3: Yes — implicit social norm (growth-minded people say yes).
- Q4: Yes — refusal framed as choosing to stagnate.
- Conti-Sobiesk: Coercion.
- Disclosure Test: FAIL — "This link requires users to self-label as uninterested in their business growth to dismiss a popup."
- Severity: 4 (identity attack).
- Honesty Spectrum: Deliberate Deception.

**Rewrite:**
- Original: "No thanks, I don't want to grow my business."
- Rewrite: "No thanks, I'll skip this."
- Bias purged: Identity threat, loss aversion.

**Aggregate: MEDIUM RISK.** One instance, severity 4. Single fix required before launch.

## OUTPUT FILE

Save to: [project-folder]/Brignull - Click Architecture/[YYYY-MM] - Confirmshaming Audit.md
