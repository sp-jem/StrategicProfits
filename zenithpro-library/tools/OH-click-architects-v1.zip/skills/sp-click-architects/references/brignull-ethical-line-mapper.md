---
name: brignull-ethical-line-mapper
description: Use when you need to map exactly where persuasion ends and manipulation begins on a specific web page — applies the Disclosure Test, Honesty Spectrum, and Roach Motel Parity Test to every friction point and default on the page before optimizing conversion.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Harry Brignull (deceptivedesigns.com 2010–2023; The 16-Pattern Deceptive Design Taxonomy + Disclosure Test + Honesty Spectrum Framework) — Click Architecture (Skill 5 of 7)"
interface:
  invoke: "/brignull-ethical-line-mapper"
  calls: []
  called_by: [user, brignull-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page copy, defaults, and pricing structures change; legal landscape (FTC click-to-cancel 2024) shifts what crosses the line."

brignull_scanner_integration:
  feeds_from: brignull-dark-pattern-scanner
  feeds_to: brignull-fair-pattern-designer
  shared_data: "Scanner identifies candidate dark patterns by taxonomy name; this skill applies the Disclosure Test to each candidate to rule persuasion IN or OUT; designer receives the cleared list of what to replace."

fogg_integration:
  feeds_from: fogg-field-intelligence
  feeds_to: fogg-behavior-system-designer
  shared_data: "Fogg maps ability/motivation/prompt levers; this skill checks whether each lever passes the Disclosure Test — a low-ability simplification is ethical if the informed user still accepts it; a false scarcity prompt exploits motivation against user interest and fails."

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: kahneman-framing-engineer
  shared_data: "Kahneman identifies which cognitive biases the page is already exploiting (anchoring, loss aversion, defaults); this skill determines whether each bias use passes the Disclosure Test or constitutes manipulation under the Conti-Sobiesk Coercion/Obfuscation axes."
---

# Brignull Ethical Line Mapper

## LAYER 1: INVARIANTS (Never override.)

1. **Disclosure Test is the bright line.** For every persuasion element on the page: if a fully-informed user, hearing an accurate plain-language description of what the element does and why, would still complete the desired action — it is ethical persuasion. If they would refuse upon disclosure, it is a dark pattern. No exceptions.
2. **The test operates on the informed user, not the average user.** Do not argue "most users don't notice X therefore it is fine." Manipulation works precisely because users lack information — that is the mechanism, not the exculpation.
3. **Asymmetry is the diagnostic signal.** Any design asymmetry — entry smoother than exit, consent harder to withdraw than to give, desired path more visible than alternative paths — requires a Disclosure Test pass before it is permitted.
4. **Sludge on the exit is a dark pattern; sludge on irreversible actions is ethical.** Friction before deleting an account (confirmation dialog) serves the user. Friction on cancellation that exceeds the friction on signup fails the Roach Motel Parity Test and is a dark pattern regardless of business benefit.
5. **The Dark Pattern Recipe flags intent.** If a page element shows evidence of Applied Psychology + A/B Testing + UI Design deployed to extract compliance — Brignull's three-ingredient recipe — the Disclosure Test must be run. The recipe does not make something a dark pattern; it flags it for testing.
6. **Social proof and scarcity are ethical only if verifiable.** Fabricated review counts, unverifiable activity signals ("12 people viewing"), and stock numbers that do not reflect real inventory fail automatically — no Disclosure Test needed; deception is not a persuasion lever.
7. **This skill maps the line; it does not redesign the page.** Flag and score every element. Handoff redesign of flagged elements to brignull-fair-pattern-designer.

## LAYER 2: QUALITY GUIDANCE

1. Score every flagged element on the Honesty Spectrum (Transparent → Omission → Deliberate Deception) before assigning a verdict. Do not jump to "dark pattern" without locating the element on the spectrum.
2. Apply both lenses: the 16-Pattern Taxonomy (what is it called?) and the Conti-Sobiesk Five-Axis (which attack vector: Coercion, Confusion, Distraction, Interruption, Obfuscation?). One pattern can trigger multiple axes.
3. Distinguish between patterns that harm the user (Roach Motel, Hidden Costs, Hidden Subscription) and patterns that are merely annoying but recoverable (Nagging). Severity determines remediation priority.
4. Cite the specific taxonomy name from the dossier when flagging. Do not use generic language like "this is misleading." Use "this is Trick Wording (double-negative consent copy) under the 16-Pattern Taxonomy."
5. Produce a final Ethical Line Map: a single table showing every flagged element, its taxonomy name, Conti-Sobiesk axis, Honesty Spectrum position, Disclosure Test verdict, and severity.

## PURPOSE

This skill applies Harry Brignull's complete ethical boundary framework to a single web page, producing a precise map of which persuasion elements are legitimate and which are manipulation — defined not by taste but by the Disclosure Test: does the element work only because the user is uninformed?

The page-action lever: strip every asymmetry between the conversion path and all alternative paths. Where conversion increases because the user genuinely prefers the offered value, that is persuasion. Where conversion increases because the user was confused, deceived, or blocked from alternatives, that is a dark pattern. The lever maximizes the first kind of lift and eliminates the second.

**Brag line: "We use the strongest levers known — and we know exactly where the line is."**

## INPUT REQUIREMENTS

**Required:**
- The page: URL, live screenshot, or written description with sufficient detail to identify interactive elements, defaults, copy, pricing, and exit paths.
- The ONE desired action: the single conversion this page is optimized for (click, opt-in, purchase, trial start, next step).

**Strongly recommended:**
- Audience profile (sophistication, familiarity with the offer category).
- Funnel position (cold traffic, warm list, retargeting).
- Analytics: bounce rate, drop-off point, conversion rate — to identify where friction is already costing the page.

**Optional:**
- Competitor page for Roach Motel Parity comparison.
- Existing legal/compliance constraints.

## EXECUTION PROCESS

**Step 1 — Element Inventory (5 min)**
List every interactive or informational element on the page that could influence the desired action: CTAs, pricing displays, timers, social proof signals, default selections, consent checkboxes, exit links, decline copy, fine print, and navigation options. Number each element E1, E2…En.

**Step 2 — Recipe Screen (2 min per element)**
Apply the Dark Pattern Recipe test to each element. Ask: does this element show evidence of (a) an identified cognitive bias being exploited, (b) iterative A/B optimization for extraction, AND (c) a specific UI implementation of that bias? Elements passing all three are flagged for the Disclosure Test. Elements failing one or more are marked Clean and excluded from further analysis.

**Step 3 — 16-Pattern Classification (2 min per flagged element)**
Assign each flagged element its taxonomy name from the 16-Pattern Taxonomy. Use exact names: Comparison Prevention, Confirmshaming, Disguised Ads, Fake Scarcity, Fake Social Proof, Fake Urgency, Forced Action, Hard to Cancel, Hidden Costs, Hidden Subscription, Nagging, Obstruction, Preselection, Sneaking, Trick Wording, Visual Interference. If an element matches multiple patterns, list all.

**Step 4 — Conti-Sobiesk Axis Assignment**
For each flagged element, identify the attack vector: Coercion (forces unwanted action), Confusion (prevents clear understanding), Distraction (pulls attention from critical info), Interruption (blocks task flow), Obfuscation (hides/disguises important information). One element may use multiple axes.

**Step 5 — Honesty Spectrum Placement**
Place each flagged element on the three-point spectrum:
- **Transparent**: Full costs, conditions, and implications displayed upfront before commitment. Passes automatically.
- **Omission**: Not actively lying but withholding timely reminders that would allow informed decision (e.g., no auto-renewal email). May pass or fail depending on context.
- **Deliberate Deception**: Copy or design that contradicts reality when fully examined. Fails automatically.

**Step 6 — Disclosure Test (core step)**
For each element at Omission or Deliberate Deception on the spectrum:
> Write the plain-language disclosure sentence: "This [element] works by [exact mechanism]. If you proceed, [exact consequence]."
> Ask: would the informed user still complete the desired action?
- Yes → **Passes. Ethical persuasion.**
- No → **Fails. Dark pattern.**
- Uncertain → **Flag for legal/compliance review. Treat as Fails until cleared.**

**Step 7 — Roach Motel Parity Test (asymmetry scan)**
Map click-counts and friction for:
- Signup vs. cancellation
- Opt-in vs. opt-out
- Add to cart vs. remove from cart
- Consent grant vs. consent withdrawal

**Threshold:** If exit path requires more steps than entry path, or requires a channel (phone, chat) not required for entry, it fails the Parity Test. FTC click-to-cancel standard: cancellation must be as simple as enrollment.

**Step 8 — Severity Scoring**
Score each failing element:
- **Critical (3)**: Financial harm possible (Hidden Costs, Hidden Subscription, Roach Motel). Regulatory exposure under FTC/GDPR.
- **Significant (2)**: Misleads decision-making (Fake Scarcity, Fake Social Proof, Trick Wording, Confirmshaming).
- **Minor (1)**: Annoying but recoverable (Nagging, Preselection on low-stakes defaults).

**Step 9 — Audience Calibration Check**
Adjust severity upward if the audience is less sophisticated or less familiar with the offer category. A hidden auto-renewal buried in fine print is Severity 2 for a tech-savvy SaaS audience; it is Severity 3 for a consumer health audience. Funnel position matters: manipulation at top-of-funnel (cold traffic) is more damaging than at bottom-of-funnel (warm, researched buyer) because the user's ability to verify claims before committing is lower.

**Step 10 — Produce Ethical Line Map**
Compile results into the output table (see Output Structure). Include a one-line summary of the overall ethical posture: "X of Y flagged elements fail the Disclosure Test. [Critical/Significant/Minor] severity. Priority remediation targets: [E-IDs]."

## OUTPUT STRUCTURE

### Section 1: Page Summary
- Page URL / description
- Desired action
- Total elements inventoried / flagged / passing / failing

### Section 2: Ethical Line Map

| ID | Element | Pattern | Axis | Spectrum | Verdict |
|----|---------|---------|------|----------|---------|
| E3 | Timer resets on refresh | Fake Urgency | Coercion | Deception | FAIL (2) |
| E7 | Pre-checked upsell box | Preselection | Obfuscation | Omission | FAIL (2) |
| E9 | "Only 3 left" (real stock) | Scarcity | — | Transparent | PASS |

**Legend:** Pattern = 16-Pattern Taxonomy name. Axis = Conti-Sobiesk attack vector. Spectrum = Transparent / Omission / Deception. Verdict = PASS / FAIL / REVIEW. Severity in parentheses: 1=Minor, 2=Significant, 3=Critical.

### Section 3: Disclosure Test Writeups
For each FAIL, the exact disclosure sentence used and why the informed user would refuse.

### Section 4: Roach Motel Parity Report
Entry path click-count vs. exit path click-count. Pass/Fail per asymmetric pair.

### Section 5: Priority Remediation List
Ranked by Severity (3 → 1). Each item: Element ID, pattern name, one-sentence fix. Handoff note to brignull-fair-pattern-designer for redesign.

### Section 6: What Passes and Why
Explicit list of persuasion elements that cleared the Disclosure Test — with the disclosure sentence written out. This is the positive case: what you are allowed to use, and the ethical basis for using it.

## WORKED MINI-EXAMPLE

**Page:** SaaS annual plan pricing page. **Desired action:** Start free trial.

**E4 — Countdown timer: "Offer expires in 14:32"**
- Recipe Screen: Exploits loss aversion (a) + clearly A/B tested variant (b) + prominent timer UI (c). Flagged.
- Pattern: Fake Urgency.
- Axis: Coercion.
- Spectrum: On refresh, timer resets to 14:32. → Deliberate Deception.
- Disclosure Test: "This timer resets every time you reload the page. There is no real deadline." Would informed user still start trial? No — they started it in part to capture the expiring deal.
- **Verdict: FAIL. Severity 2.**
- Fix: Replace with real constraint (e.g., trial cohort closes Friday because onboarding is capped) or remove. Pass the constraint to brignull-fair-pattern-designer.

**E9 — "Join 4,200 marketers already inside"**
- Recipe Screen: Social proof (a) + present on page (b) + prominent badge UI (c). Flagged.
- Pattern: Fake Social Proof — candidate.
- Axis: Confusion — candidate.
- Spectrum: Count is pulled from CRM; last updated 30 days ago. Current count is 4,410. Minor lag, not fabricated.
- Disclosure Test: "4,200 is the verified member count as of last month." Would informed user still act? Yes — slight lag in a real count does not change the decision.
- **Verdict: PASS. Update cadence to weekly.**

**Integration note:** After the Ethical Line Map is complete, pass the PASS list to kahneman-framing-engineer with the note "these elements cleared the Disclosure Test — frame them using prospect theory and anchoring without restriction." Pass the FAIL list to brignull-fair-pattern-designer with the note "these elements fail the Disclosure Test — replace with equivalent-strength ethical alternatives." Brignull-sludge-auditor runs in parallel on the exit path independently; do not duplicate its friction scoring here.

## OUTPUT FILE

Save to: [project-folder]/Brignull - Click Architecture/[YYYY-MM] - Ethical Line Map - [Page Name].md
