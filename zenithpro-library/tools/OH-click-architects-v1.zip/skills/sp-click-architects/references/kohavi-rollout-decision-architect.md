---
name: kohavi-rollout-decision-architect
description: Use when an experiment has concluded and you need a structured ship/iterate/kill/ramp verdict — converts raw results into a defensible rollout decision with guardrail enforcement.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Ronny Kohavi (Trustworthy Online Controlled Experiments, 2020; Experiment Launch Decision Matrix + Guardrail Metrics Framework + Progressive Deployment Strategy) — Click Architecture (Skill 6 of 7)"
interface:
  invoke: "/kohavi-rollout-decision-architect"
  calls: []
  called_by: [user, kohavi-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic mix, seasonal demand, and competitive context shift experiment baselines; a valid rollout decision from Q4 may be wrong in Q2."

kohavi_srm_guard_integration:
  feeds_from: kohavi-srm-guard
  feeds_to: []
  shared_data: "SRM p-value and confirmed-clean flag. If SRM p < 0.001 and not yet cleared, rollout decision is blocked — scorecard data is corrupt and cannot be trusted."

kohavi_oec_definer_integration:
  feeds_from: kohavi-oec-definer
  feeds_to: []
  shared_data: "Pre-defined OEC formula and practical significance threshold. These must exist BEFORE the experiment ends; if they were defined post-hoc the decision carries elevated false-positive risk and must be flagged."

eisenberg_field_intelligence_integration:
  feeds_from: eisenberg-field-intelligence
  feeds_to: []
  shared_data: "Buying modality and micro-action sequence context. Eisenberg's persona pathway data identifies which triggered subpopulation the experiment actually served; inform trigger analysis segmentation."
---

# Kohavi Rollout Decision Architect

## LAYER 1: INVARIANTS (Never override.)

1. **SRM must clear before any verdict.** If Sample Ratio Mismatch p < 0.001 (or not yet checked), the decision is BLOCKED. All scorecard numbers are potentially corrupted. Run kohavi-srm-guard first — no exceptions.
2. **OEC must be pre-defined, not reverse-engineered.** If the composite metric was set after seeing results, label the decision PROVISIONAL and require pre-registration before the next experiment. Post-hoc OEC selection inflates false-positive rate to unknown levels.
3. **Statistical significance alone is never sufficient for SHIP.** The CI must also exceed the pre-defined practical significance threshold (PST). A statistically significant +0.1% revenue lift on a PST of 1% is a KILL, not a SHIP.
4. **Guardrail violations halt the experiment.** If any organizational guardrail metric (latency, crash rate, error rate, churn) degraded significantly, STOP regardless of OEC direction. The coupon-popup experiment showed -7.8% revenue with p=1.5E-23 — violating the revenue guardrail. The correct call is KILL.
5. **Novelty effect must be evaluated before SHIP.** Plot OEC over the experiment duration. If the metric trended upward throughout, users are still adapting; declare RAMP-WITH-MONITORING, not SHIP. Instagram-style new formats can show 28% CTR early and then regress.
6. **Trigger analysis is mandatory for sub-page elements.** Only users who encountered the variant element count. A 1% triggered segment with 10% improvement = 0.1% aggregate lift. Size rollout decisions using aggregate impact, not triggered-segment impact.
7. **Practical significance threshold is set before seeing data.** Pre-register the PST in the experiment brief. Moving it after unblinding is a protocol violation requiring a notation in the decision record.

## LAYER 2: QUALITY GUIDANCE

1. **Use the six-scenario matrix, not intuition.** Each result falls into exactly one of the six cells (stat sig × practical sig × CI position). The matrix output is the verdict; override requires documented justification.
2. **Progressive ramp starts at 2%, not 50%.** Even a confirmed SHIP verdict goes through the cooling-water ramp: 2% → 10% → 25% → 50% → 100% over two weeks, with guardrail checks at each gate. Early ramp data skews toward frequent/Wi-Fi users and cannot be treated as final signal.
3. **Debug metric decomposition precedes ITERATE.** If the verdict is ITERATE, decompose the OEC failure: revenue = purchase_indicator × conditional_revenue. Identify which component moved in the wrong direction before redesigning the treatment.
4. **Cap the metric dashboard at ~5 key metrics.** Ten independent metrics produce a 40% chance that at least one is significant by chance alone. Report OEC + guardrails only; move debug metrics to an appendix.
5. **Document the decision, not just the verdict.** Record: OEC value, PST, stat sig p-value, guardrail status, SRM status, novelty check result, triggered vs. full-population impact, and the rollout schedule. The record is auditable evidence that the decision was trustworthy.

## PURPOSE

Kohavi's core insight is that 70-90% of expert-generated ideas fail to move their target metric. The only reliable oracle is a pre-defined OEC enforced against guardrails — not the HiPPO (Highest-Paid Person's Opinion). This skill operationalizes the full rollout decision protocol: it takes a concluded experiment's result data and outputs a structured SHIP / ITERATE / KILL / RAMP verdict with the exact reasoning chain, guardrail status, and progressive deployment schedule.

**Brag line: "We know our winner is real, not a 1-in-20 false positive."**

It lives at the terminal end of the experiment lifecycle, after validity checks (kohavi-srm-guard, kohavi-twyman-anomaly-detector) and before post-launch monitoring.

## INPUT REQUIREMENTS

**Required:**
- The page URL, screenshot, or written description of the page under test.
- The ONE desired action this experiment was designed to increase (click / opt-in / purchase / next-step).
- Experiment results: OEC delta (lift %), confidence interval, p-value, and sample sizes (control n, treatment n).
- Pre-defined OEC formula and practical significance threshold (PST) from the experiment brief.
- Guardrail metric readings: latency delta, crash rate delta, error rate delta, any churn/unsubscribe delta.
- SRM status: confirmed clean or p-value.

**Optional but high-value:**
- Trigger analysis results (triggered-population n and lift vs. full-population n and diluted lift).
- Time-series plot of OEC across experiment duration (for novelty check).
- Funnel position and audience segment (affects ramp schedule risk tolerance).
- Maturity level of the experimentation program (Crawl/Walk/Run/Fly — affects what the team can execute).

## EXECUTION PROCESS

### Step 1: SRM Gate
Confirm SRM p-value from kohavi-srm-guard output.
- p ≥ 0.05: CLEAN — proceed.
- 0.001 ≤ p < 0.05: INVESTIGATE — document finding, proceed with caution label.
- p < 0.001: BLOCKED — return "Verdict: BLOCKED. Scorecard invalid until SRM resolved." Stop here.

### Step 2: Guardrail Sweep
Check each organizational guardrail against its pre-set bound.

| Metric | Pre-set Bound | Actual Delta | Status |
|--------|--------------|--------------|--------|
| Latency | ≤ +50ms | [fill] | Pass/Fail |
| Crash rate | ≤ +0.1% | [fill] | Pass/Fail |
| Error rate | ≤ +0.5% | [fill] | Pass/Fail |
| Unsubscribe/churn | ≤ +2% | [fill] | Pass/Fail |

Legend: Pre-set Bound = threshold set in experiment brief before unblinding.

If ANY guardrail is FAIL: verdict is KILL regardless of OEC direction. Document the violated metric and magnitude.

Trust-related invariants (e.g., ratio of users per variant, cache-hit rates) feed into SRM and are handled in Step 1.

### Step 3: Practical Significance Check
PST = pre-registered minimum meaningful lift (e.g., 1% revenue improvement).

Compute: Is OEC delta ≥ PST? (Yes / No)

### Step 4: Statistical Significance Check
p-value threshold: p ≤ 0.05 (or pre-registered alpha, typically 0.05).

Compute: Is p ≤ alpha? (Yes / No)

Apply the six-scenario matrix:

| Scenario | Stat Sig | Pract Sig | CI Position | Verdict |
|----------|----------|-----------|-------------|---------|
| 1 | No | No | Inside PST bound | KILL or ITERATE |
| 2 | Yes | Yes | Above PST | SHIP |
| 3 | Yes | No | Below PST | KILL (too small) |
| 4 | No | Outside CI | Cannot determine | RERUN (more users) |
| 5 | Yes | Likely | CI straddles PST | RAMP-with-monitoring |
| 6 | No | Inside CI | Inconclusive | RERUN (more power) |

Legend: Stat Sig = p ≤ alpha; Pract Sig = OEC delta ≥ PST; CI = confidence interval for OEC delta.

### Step 5: Novelty Check
If verdict from Step 4 is SHIP or RAMP-with-monitoring:
- Plot OEC by day (or week) across experiment duration.
- If metric trended upward throughout and experiment ran < 2 full weeks: downgrade to RAMP-with-monitoring with a 2-week stabilization window before full deployment.
- If metric stabilized or slightly declined after initial days: novelty effect resolved. Verdict stands.
- Rule of thumb: new UI changes need 2+ weeks of run time before the novelty effect dissipates.

### Step 6: Trigger Analysis Adjustment
If triggered-population results are available:
- Aggregate impact = (triggered_n / total_n) × triggered_lift.
- Use aggregate impact for rollout sizing and business-case reporting, not the triggered-segment lift alone.
- Example: 1% triggered segment with +10% OEC lift → aggregate impact = 0.10%. If PST was 1%, this is a KILL even if the triggered result is impressive.

### Step 7: Assign Verdict and Rollout Schedule

**SHIP (full rollout):**
- Progressive ramp: 2% → 10% → 25% → 50% → 100%.
- Minimum gate time at each step: 48 hours with guardrail check.
- At 100%: run post-launch monitoring for 2 weeks minimum.

**RAMP-with-monitoring:**
- Hold at 10% for 2-week stabilization window.
- Re-evaluate OEC after stabilization; apply Step 4 matrix to stabilized data.
- If still passes: advance to full SHIP ramp.
- If regresses below PST: KILL.

**ITERATE:**
- Decompose OEC failure: identify which sub-metric broke (purchase rate vs. AOV, engagement vs. retention).
- Output: specific hypothesis for the next treatment variant.

**KILL:**
- Document the failed hypothesis explicitly for the experiment log.
- At Bing, only 1 in 500 experiments is a true breakthrough; when p ≈ 0.05, true effect probability is ~3.1%. Kills are expected and valuable — they eliminate bad ideas cheaply.

### Step 8: Output the Decision Record
Produce the structured deliverable (see Output Structure below).

## OUTPUT STRUCTURE

**Section 1: Experiment Summary**
Page URL/description, desired action, experiment duration, sample sizes (control n / treatment n), SRM status.

**Section 2: Guardrail Sweep Table**
Five-column table: Metric | Bound | Delta | Status | Notes.

**Section 3: Decision Matrix Result**
Which of the six scenarios applies. OEC delta, CI, PST, p-value, and the resulting cell.

**Section 4: Novelty Check Result**
Time-series summary: stabilized or still trending. Effect on verdict.

**Section 5: Trigger Analysis**
Triggered-population lift vs. aggregate impact. Impact on business case.

**Section 6: Verdict**
SHIP / RAMP-with-monitoring / ITERATE / KILL — with one-paragraph rationale grounded in the matrix.

**Section 7: Rollout Schedule (if SHIP or RAMP)**
Table: Stage | Audience % | Gate Duration | Guardrail Check.

**Section 8: Next Hypothesis (if ITERATE or KILL)**
OEC decomposition finding and the next treatment direction.

## WORKED MINI-EXAMPLE

**Page:** E-commerce checkout page. Desired action: complete purchase.
**Experiment:** Removed optional coupon code field from below the credit card form.
**Results:** OEC (revenue/user) delta = -2.8%, p = 0.0003, CI = [-4.1%, -1.5%].
**PST:** Pre-registered at +1% revenue.
**SRM:** p = 0.47, CLEAN.

**Step 1:** SRM CLEAN — proceed.

**Step 2 Guardrail Sweep:**
| Metric | Bound | Delta | Status |
|--------|-------|-------|--------|
| Latency | ≤+50ms | +3ms | Pass |
| Error rate | ≤+0.5% | +0.0% | Pass |
| Revenue/user | Must not drop | -2.8% | FAIL |

Revenue guardrail violated. Verdict: KILL.

**Verdict:** KILL. The coupon field removal degraded OEC by -2.8% (p=0.0003), breaching the revenue guardrail. Hypothesis rejected. This mirrors Kohavi's documented finding: coupon-field placement experiments at Bing showed -2.8% (below card) and -7.8% (popup) revenue — both correctly killed. Next hypothesis: investigate whether coupon-seeking users self-select out of the funnel before reaching checkout; test earlier coupon-entry point rather than removal.

**Before:** Checkout with coupon field below credit card → conversion rate C, revenue/user R.
**After (treatment):** Coupon field removed → revenue/user R × 0.972. KILL. Do not ship.

## OUTPUT FILE
Save to: [project-folder]/Kohavi - Click Architecture/[YYYY-MM] - Rollout Decision - [page-name].md
