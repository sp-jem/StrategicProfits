---
name: brignull-field-intelligence
description: Use when you have outputs from 4–6 individual Brignull skills on the same page and need cross-skill convergence zones, The Single Move, and a 90-day ethical-design projection — synthesizes the full Click Architects network into one highest-leverage intervention.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Harry Brignull (Deceptive Design, 2010–2023; deceptivedesign.org; 16-Pattern Taxonomy; Disclosure Test; Sludge; Roach Motel) — Field Intelligence (Skill 7 of 7)"
interface:
  invoke: "/brignull-field-intelligence"
  calls: [brignull-dark-pattern-scanner, brignull-sludge-auditor, brignull-confirmshaming-detector, brignull-consent-integrity-checker, brignull-ethical-line-mapper, brignull-fair-pattern-designer]
  called_by: [user, click-architects]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Dark pattern landscapes shift as regulatory pressure (FTC click-to-cancel 2024, EU DSA) triggers redesigns and as A/B testing cycles produce new manipulation variants. Individual skill outputs older than 45 days may reflect pre-enforcement or pre-redesign page states. Reassess quarterly minimum."
fitts_integration:
  feeds_from: [fitts-field-intelligence]
  feeds_to: [fitts-click-path-minimizer]
  shared_data: "Fitts measures the motor cost of every click (target size × distance). Brignull measures the asymmetric friction between desired and undesired paths. Combined: the Roach Motel pattern is a deliberate Fitts violation — cancellation targets are small, distant, and buried. The synthesis reveals which friction asymmetries are also motor-cost asymmetries, making them doubly coercive. Fix: parity of Fitts cost for all paths the user might want."
pirolli_integration:
  feeds_from: [pirolli-field-intelligence]
  feeds_to: [pirolli-scent-trail-auditor]
  shared_data: "Pirolli maps information scent — the signals that tell a user whether a path leads to their goal. Brignull maps Visual Interference — design that camouflages key information. Combined: dark patterns that suppress scent (hiding cancellation, burying costs) exploit the forager's heuristic of abandoning low-scent trails. The synthesis: every Brignull-flagged scent suppression is also a Pirolli foraging failure. Restoring scent is the ethical and conversion-positive fix."
eisenberg_integration:
  feeds_from: [eisenberg-field-intelligence]
  feeds_to: [eisenberg-conversion-trinity-builder]
  shared_data: "Eisenberg maps the four buying modalities (Competitive, Spontaneous, Humanistic, Methodical) and the conversion trinity (relevance, value, call to action). Brignull maps the line between persuasion and coercion. Combined: Methodical and Humanistic buyers disengage permanently when they detect deception — their modality requires trust above urgency. A page optimized for short-term extraction via dark patterns destroys the trust layer that Methodical conversion requires. The synthesis: dark pattern removal is conversion optimization for high-LTV modalities."
kohavi_integration:
  feeds_from: [kohavi-field-intelligence]
  feeds_to: []
  shared_data: "Kohavi's Online Controlled Experiment framework is the empirical test layer for every Brignull hypothesis. A page suspected of Fake Urgency gets A/B tested: timer present vs. absent. Confirmshaming removal gets measured against opt-in rates with neutral copy. The Disclosure Test becomes a split-test condition. Combined: Brignull identifies which patterns exist and why they're problematic; Kohavi provides the measurement infrastructure to quantify the conversion impact of removing them — and catches cases where removal unexpectedly hurts metrics (signaling the pattern was filling a real persuasion gap)."
laja_integration:
  feeds_from: [laja-field-intelligence]
  feeds_to: [laja-friction-telemetry-reader]
  shared_data: "Laja's CXL conversion framework prioritizes reducing friction and increasing clarity (ResearchXL). Brignull identifies friction that is deliberate and adversarial. Combined: Laja's friction audit surfaces all friction; Brignull's taxonomy classifies it as benign (serves the user) vs. manufactured (serves only the business). The synthesis produces a friction triage: remove manufactured friction immediately; evaluate benign friction for conversion impact; never add manufactured friction as a 'growth hack.'"
fogg_integration:
  feeds_from: [fogg-field-intelligence]
  feeds_to: [fogg-ability-auditor]
  shared_data: "Fogg's B=MAP model shows that behavior requires Motivation, Ability, and a Prompt simultaneously. Brignull's Sludge concept is deliberate Ability destruction on exit paths. Combined: sludge works by crashing the user's Ability score on cancellation — multiple screens, phone requirements, forced retention offers. The ethical standard: exit Ability must not be lower than entry Ability. Any design that makes exit harder than entry by more than one step is a Fogg-Brignull violation."
cialdini_integration:
  feeds_from: [cialdini-field-intelligence]
  feeds_to: [cialdini-ethical-influence-system-designer]
  shared_data: "Cialdini maps ethical influence principles; Brignull maps where influence crosses into coercion. Combined: Confirmshaming perverts commitment/consistency (exploiting self-concept instead of eliciting genuine alignment). Fake Social Proof corrupts the social proof principle at its source. Fake Urgency weaponizes scarcity against uninformed users. The Disclosure Test is the operational bright line: if a Cialdini principle holds up under plain-language disclosure, it is influence; if it collapses, it is a dark pattern using a Cialdini mechanism. The synthesis maps each dark pattern to the Cialdini principle it perverts."
kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: [kahneman-framing-engineer]
  shared_data: "Kahneman's System 1/2 framework explains WHY dark patterns work: they exploit System 1 (fast, automatic, bias-prone) to override System 2 (slow, deliberate, informed). Preselection exploits status-quo bias (System 1 accepts defaults). Trick Wording exploits processing fluency (System 1 takes the easy parse). The Disclosure Test is a System 2 intervention: it forces the fully-informed, deliberate user to evaluate the design. The synthesis: every Brignull pattern is a System 1 exploit; every ethical fix reduces System 1 exploitation without eliminating genuine persuasion."
thaler_integration:
  feeds_from: [thaler-field-intelligence]
  feeds_to: [thaler-default-detector]
  shared_data: "Thaler's Nudge framework shows defaults are powerful and can be ethical when they serve the user's long-run interest. Brignull's Preselection and Hidden Subscription patterns weaponize defaults against users. Combined: the Thaler-Brignull synthesis distinguishes ethical defaults (opt-in to a free feature the user genuinely wants) from dark defaults (pre-checked add-ons, auto-enrollment in paid tiers). The test: would the user select this default if fully informed? Ethical defaults pass; dark defaults fail the Disclosure Test."
iyengar_integration:
  feeds_from: [iyengar-choice-set-auditor]
  feeds_to: []
  shared_data: "Iyengar shows that choice overload increases when options are numerous and structurally similar. Brignull's Comparison Prevention and Trick Wording exploit choice complexity to prevent informed comparison. Combined: a page that maximizes choice complexity (to prevent price comparison) combined with Trick Wording (to confuse terms) and Preselection (to exploit defaults) is a three-layer coercion stack. The synthesis: simplify the choice set to what users actually need (Iyengar) and remove artificial complexity added to prevent comparison (Brignull)."
---

# Brignull Field Intelligence

---

## LAYER 1: INVARIANTS (Never override.)

1. **Synthesis not summary.** This skill does NOT recap individual skill findings. It identifies PATTERNS ACROSS skills — convergence zones where multiple independent analyses point at the same coercion mechanism. If the output reads like six summaries stapled together, it has failed.

2. **Convergence detection is mandatory.** When 3+ individual Brignull skills flag the same page element or mechanism, that is a convergence zone. Name it. Convergence zones are highest-confidence findings because multiple lenses arrived at the same coercion independently.

3. **Contradictions surfaced, not hidden.** When skills conflict (e.g., Dark Pattern Scanner flags scarcity as fake; Fair Pattern Designer proposes a scarcity-adjacent lever), resolve it through the Disclosure Test — does the proposed lever hold up under plain-language disclosure? Name every tension.

4. **The Single Move is non-negotiable.** Every briefing produces ONE highest-leverage page change — the intervention that addresses the most convergence zones simultaneously and passes the Disclosure Test with the highest margin.

5. **The Mirror is mandatory.** The business deploying these tools has its own dark-pattern biases. Which patterns does it default to? Which ethical line does it hover near? Naming this honestly is not an indictment — it is the data needed to calibrate.

6. **Cross-system intelligence is the highest-value section.** When Brignull's Disclosure Test intersects with Kahneman's System 1, Fogg's Ability scoring, Fitts's motor cost, Pirolli's scent, Kohavi's A/B infrastructure, and Thaler's default ethics — those intersections produce insights no single thinker can generate alone.

7. **Freshness gate: 45 days.** Flag any individual Brignull skill output older than 45 days as potentially stale. Regulatory and competitive page design changes move fast.

---

## LAYER 2: QUALITY GUIDANCE

8. **Name the convergence zones memorably.** Labels like "The Exit Trap" or "The Phantom Clock" make patterns actionable and memorable. Generic labels like "Issue #3" get ignored.

9. **Quantify asymmetry.** Where possible, count the click-count parity gap between entry and exit paths. Roach Motel severity = (cancel clicks) - (signup clicks). A gap > 2 is an enforcement-level risk under FTC 2024 standards.

10. **The 90-Day Projection is forward-looking.** What does the ethical page design look like in 90 days if The Single Move is implemented? What metric shifts are expected? Be specific: "opt-in rate to [X], refund rate down [Y]%, complaint volume down [Z]."

---

## PURPOSE

We use the strongest levers known — and we know exactly where the line is.

Individual Brignull skills each audit one coercion vector: the Dark Pattern Scanner inventories all 16 pattern types on a page; the Sludge Auditor measures exit friction; the Confirmshaming Detector reads every decline label; the Consent Integrity Checker audits every default and opt-out; the Ethical Line Mapper applies the Disclosure Test to every element; the Fair Pattern Designer proposes persuasion-grade replacements.

Field Intelligence operates one level above. It finds convergence zones where multiple coercion mechanisms cluster on the same page element (a pattern cluster is more coercive — and more legally exposed — than any single pattern). It detects contradictions between what different skills recommend and resolves them through the Disclosure Test. It identifies the single highest-leverage ethical intervention. And it integrates Brignull's complete framework with every other Click Architect system in the network — because the ethical line on a page is not just a legal standard; it is a conversion architecture question with measurable downstream effects on trust, LTV, and refund rates.

---

## INPUT REQUIREMENTS

**Required:** Outputs from at least 4 of 6 individual Brignull skills, run on the same page with the same stated desired action.

**Optimal:** All 6 skill outputs + Field Intelligence from: pirolli, fitts, eisenberg, kohavi, laja, fogg, cialdini, kahneman, thaler, iyengar.

**Page context required:** URL or description, stated desired action (the ONE action this page is optimized for), and current conversion rate if available.

---

## EXECUTION PROCESS

### Step 1: Component Synthesis

For each available Brignull skill output:

| Field | Detail |
|-------|--------|
| Skill | Name |
| Date | Produced |
| Freshness | Current (<=45d) / Aging (45-60d) / Stale (>60d) |
| Patterns found | Count + named types |
| Severity flags | Disclosure Test failures noted |
| Recommendations | Summary of fixes proposed |

### Step 2: Convergence Detection

Cross-skill pattern matching. Score each element touched by multiple skills:

- 2 skills: Notable alignment
- 3 skills: **Convergence zone** — name it
- 4 skills: Strong convergence — high enforcement/trust risk
- 5-6 skills: Critical convergence — intervention non-negotiable

**For each convergence zone:**
- **Name:** Memorable label
- **Mechanism:** Which Brignull pattern(s) from the 16-pattern taxonomy or Mathur superordinate categories
- **Contributing skills:** Which analyses flagged it
- **Coercion stack:** If multiple patterns cluster on the same element (e.g., Fake Urgency + Confirmshaming + Preselection on the same CTA), the stack is more coercive than any single pattern
- **Disclosure Test verdict:** Would a fully-informed user still complete the action? (Pass / Fail / Marginal)
- **Implied intervention:** What change removes the coercion while preserving genuine persuasion

### Step 3: Contradiction Detection

**Common Brignull contradiction patterns:**
- Dark Pattern Scanner flags scarcity as fake ↔ Fair Pattern Designer proposes urgency-adjacent lever: resolve via inventory audit — real constraints are ethical; manufactured ones are not
- Sludge Auditor flags cancellation friction ↔ Consent Checker finds the original consent was deficient: resolve by fixing consent first (sludge on a bad consent stack is double coercion)
- Ethical Line Mapper passes a default ↔ Consent Checker flags the same default as unexplained: resolve by applying Thaler's standard — does the default serve the user's long-run interest?
- Confirmshaming Detector flags copy ↔ Fair Pattern Designer proposes identity-aligned alternative that still feels pressuring: resolve by testing the alternative against the Disclosure Test, not by feel

**For each contradiction:**
- The tension
- Why both skills are correct in their own frame
- Resolution: which lens takes priority in this specific context, and why

### Step 4: Amplification Opportunities

Where removing multiple patterns in sequence creates compounded trust recovery:

- **The Transparency Stack:** Remove hidden costs + move preselections to opt-in + add explicit consent checkboxes → each removal amplifies the others because users respond to consistency of honesty across the page
- **The Exit Parity Fix:** Reduce cancellation clicks to match signup clicks + replace cancel retention offer with a transparent downgrade option → FTC compliance + measurable refund/chargeback reduction
- **The Proof Cleanse:** Replace fake social proof with verified, unfiltered data + add explicit methodology note → converts the proof from a liability into a trust asset that amplifies other conversions
- **The Scarcity Truth:** Replace Fake Urgency timer with a real constraint (cohort size, genuine deadline) or remove it → passes the Disclosure Test and eliminates the trust erosion from users who notice the reset

**For each amplification stack:**
- Which interventions combine
- Why the combination exceeds individual fixes
- Sequence (which to fix first)
- Expected metric shift

### Step 5: The Single Move

The ONE page change that addresses the most convergence zones, passes the Disclosure Test with the highest margin, and is implementable in a single sprint:

- **What to do:** Specific, named change (element, copy, or flow)
- **Why this is THE move:** Which convergence zones it addresses
- **How it works:** In Brignull's terms — which pattern(s) it removes, which Mathur category it collapses
- **Disclosure Test score:** Before change / after change (1-10, where 10 = fully passes)
- **Implementation steps:** Ordered, concrete
- **Expected outcome:** Specific metric(s) predicted to move and direction
- **What it does NOT fix:** Honest scope — which patterns remain after this move

**Worked example (sample page: SaaS subscription page):**
Before: "Start Free Trial" button (preselected annual plan, monthly hidden in fine print, cancel requires chat, timer resets on refresh, decline button reads "No thanks, I prefer paying more").
Single Move: Make monthly plan the default displayed option, add visible plan-switcher above fold, rewrite decline to "Maybe later" (neutral), remove timer. Click parity: signup 3 clicks = cancel 3 clicks.
After Disclosure Test: 8/10 (timer removal + parity fix). Predicted: opt-in rate holds within 5% (loss of manufactured urgency), 12-month LTV increases as refund and chargeback rates decline, complaint volume drops.

### Step 6: The Mirror

Where the business's own dark-pattern defaults operate:

- **The common bias pattern:** Most businesses default to Fake Urgency (countdowns feel like urgency levers), Confirmshaming (feels clever), and Preselection (defaults feel like "setting expectations"). These are the three most common and most legally exposed patterns under FTC 2024 rules.
- **Where does THIS business sit on the Honesty Spectrum?** (Transparent Disclosure / Omission / Deliberate Deception — Brignull's 2023 three-point scale)
- **The Dark Pattern Recipe bias:** Which of the three ingredients (Applied Psychology, A/B Testing, UI Design) is over-indexed? Businesses that run heavy A/B testing on manipulation variants without a Disclosure Test gate are at highest risk.
- **Which patterns does the team treat as "normal design"?** The most dangerous dark patterns are the ones the team doesn't recognize as patterns — they have been A/B-tested so long they feel like defaults.
- **The Mirror question:** If a regulator ran the Disclosure Test on your page today, what would they find?

### Step 7: Cross-System Intelligence

**Brignull x Fitts:** Roach Motel is a Fitts violation. Cancellation targets are deliberately made small and distant (high motor cost), while signup CTAs are large and prominent (low motor cost). The Fitts-Brignull synthesis: measure the Fitts cost differential between the primary CTA and the cancel/exit path. A cost differential > 3x is both a dark pattern and an accessibility failure.

**Brignull x Pirolli:** Visual Interference and Hidden Costs suppress information scent on exit paths. When scent toward cancellation or refund is deliberately killed (no visible link, buried in FAQ, requires search), Pirolli's forager heuristic predicts abandonment — the user stops because the trail runs cold. The fix restores scent parity: exit paths should have equal or greater scent than entry paths.

**Brignull x Eisenberg:** Fake Social Proof destroys Methodical and Humanistic buyer trust permanently when detected. These modalities require verification before commitment. One detected fake review breaks conversion for the entire modality segment. The Eisenberg-Brignull synthesis: proof authenticity is not optional for high-LTV modalities; it is structural to conversion.

**Brignull x Kohavi:** Every Brignull hypothesis becomes a Kohavi A/B test. Fake Urgency removal: measure conversion rate with and without timer. Confirmshaming replacement: measure opt-in with shame copy vs. neutral copy. The critical addition: Kohavi's trustworthy experiment standard requires that the manipulation variant NOT be the control. Dark patterns that have been running as "the page" are themselves confounded — their conversion lift must be measured against a Disclosure-Test-passing alternative, not against nothing.

**Brignull x Laja:** Laja's ResearchXL framework flags all friction. Brignull classifies friction as benign vs. manufactured. The Laja-Brignull synthesis: every friction item from a Laja heuristic audit gets a Disclosure Test pass/fail score. Friction that passes (confirmation before deleting data) stays; friction that fails (multi-step cancel flow with retention offers) is removed. This produces a friction triage list with ethical classification, not just a friction count.

**Brignull x Fogg:** Sludge is deliberate Ability destruction. In Fogg's B=MAP, sludge on exit paths crashes the user's Ability score below the action threshold — the user wants to cancel but can't complete the behavior. The Fogg-Brignull bright line: Ability on exit paths must match Ability on entry paths (same number of steps, same cognitive load, same availability of support). Any design that makes exit harder than entry by more than one step is a combined Fogg-Brignull violation.

**Brignull x Cialdini:** Every dark pattern is a perverted Cialdini principle. Confirmshaming perverts commitment/consistency (exploits self-concept rather than eliciting genuine identity alignment). Fake Social Proof corrupts the social proof principle at the source. Fake Urgency weaponizes scarcity against uninformed users. The Cialdini-Brignull rule: use the Disclosure Test to verify every influence principle deployment. If it holds under disclosure, it's Cialdini. If it collapses, it's a Brignull pattern wearing a Cialdini mask.

**Brignull x Kahneman:** All 16 dark patterns exploit System 1. Preselection: status-quo bias. Trick Wording: processing fluency (the easy parse is wrong). Fake Urgency: loss aversion under manufactured time pressure. Visual Interference: attention exploitation. The Kahneman-Brignull synthesis: the Disclosure Test is a System 2 intervention — it asks the fully-informed, deliberate user to evaluate the design. Any pattern that passes the System 1 test but fails the System 2 Disclosure Test is a Kahneman exploit.

**Brignull x Thaler:** Thaler's ethical default standard is whether the default serves the user's long-run interest. Brignull's Preselection and Hidden Subscription are defaults that serve only the business. The Thaler-Brignull synthesis: every default on the page gets the long-run interest test. Ethical default = user would select it if informed. Dark default = user would reject it if informed.

**Brignull x Iyengar:** Comparison Prevention combines with Iyengar's choice overload to prevent informed decisions. The pattern: maximize structural complexity (many similar options, bundled features, opaque pricing) to make comparison impossible — then add Preselection to exploit the paralysis. The Iyengar-Brignull fix: simplify the choice set to what users actually need AND remove artificial complexity added solely to prevent comparison.

**Cross-system convergence — highest confidence finding:** When Fitts motor cost asymmetry + Pirolli scent suppression + Fogg Ability destruction + Kahneman System 1 exploitation all flag the same exit path — that path is a critical convergence zone. The intervention is exit path redesign: equal Fitts cost, restored scent, matched Ability score, and a Disclosure Test pass. This is the single highest-leverage move in most SaaS and subscription page audits.

### Step 8: Coherence Map

Score the page's ethical design coherence (1-10 per dimension):

| Dim | What it measures |
|-----|-----------------|
| Pat | Pattern coverage: how many of 16 patterns present (0=none, 10=all removed) |
| Dis | Disclosure Test average across all elements |
| Par | Path parity: exit clicks vs. entry clicks (10=equal) |
| Con | Consent integrity: all preselections and defaults ethical |
| Pro | Proof authenticity: all social proof verified and unfiltered |
| Reg | Regulatory exposure: FTC/EU DSA compliance posture |

Legend: Pat=Pattern count; Dis=Disclosure score; Par=Path parity; Con=Consent; Pro=Proof; Reg=Regulatory

Overall coherence = average of 6 dimensions.

- 8-10: Ethical design — optimize for genuine persuasion
- 6-7: Moderate exposure — targeted pattern removal needed
- 4-5: Significant exposure — structural redesign required
- 1-3: High exposure — enforcement-level risk; redesign immediately

### Step 9: 90-Day Projection

**If nothing changes:** Regulatory exposure compounds. FTC 2024 click-to-cancel enforcement is active; complaint volume is a leading indicator of enforcement action. Trust erosion from detected patterns accelerates as users share screenshots on social. LTV shortens as refund/chargeback rates climb.

**If The Single Move is implemented (Days 1-30):** Primary pattern removed. Disclosure Test score for affected elements rises above 7. No expected conversion collapse — genuine persuasion fills the gap. Monitor: opt-in rate (expect flat to -5%), refund rate (expect -10 to -20%), complaint volume (expect decline within 30 days).

**If full recommendation set implemented (Days 31-90):**
- Days 31-60: Secondary pattern removal complete. Exit path parity achieved. Proof authenticity restored. Social proof begins compounding as authentic reviews build.
- Days 61-90: Full ethical page design operational. Coherence Map scores 8+ across all dimensions. LTV segment recovers for Methodical and Humanistic buyers. Regulatory exposure at minimum. Page is defensible under disclosure in any enforcement context.

---

## OUTPUT STRUCTURE

**Section 1: Input Status and Freshness** — All six skill outputs with dates and freshness ratings.

**Section 2: Convergence Map** — Named convergence zones with contributing skills, coercion stacks, Disclosure Test verdicts, and implied interventions.

**Section 3: Contradiction Analysis** — Resolved tensions between competing skill recommendations.

**Section 4: Amplification Opportunities** — Sequenced intervention stacks with compounded trust-recovery projections.

**Section 5: The Single Move** — One highest-leverage change with Disclosure Test score before/after, implementation steps, and predicted metric shifts.

**Section 6: The Mirror** — Business's own dark-pattern defaults, Honesty Spectrum position, and the Mirror question.

**Section 7: Cross-System Intelligence** — Brignull interactions with all Click Architects and owned canon, with cross-system convergence finding.

**Section 8: Coherence Map** — Six-dimension ethical design scorecard with overall score and interpretation.

**Section 9: 90-Day Projection** — Forward scenarios: no change, single move, full implementation.

---

## OUTPUT FILE

Save complete briefing to:
`[project-folder]/Harry Brignull - Field Intelligence/[YYYY-MM] - Deceptive Design Intelligence Briefing.md`
