---
name: nielsen-f-pattern-layout-auditor
description: Use when a page has unformatted text blocks, weak CTA placement, or unknown scan pattern — diagnoses which of the four eyetracking patterns visitors use and restructures layout so key content sits in the actual scan path.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Jakob Nielsen & Kara Pernice (Eyetracking Web Usability 2010; F-Pattern 2006; Four Scanning Patterns 2017; Page Fold Gradient 2010/2018) — Click Architecture (Skill 2 of 7)"
interface:
  invoke: "/nielsen-f-pattern-layout-auditor"
  calls: []
  called_by: [user, nielsen-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Scroll depth, device mix, and content formatting change visitor scan behavior; a page rebuilt after an A/B test may have shifted which pattern fires."

pirolli_integration:
  feeds_from: pirolli-scent-trail-auditor
  feeds_to: nielsen-attention-zone-placer
  shared_data: "Scent gradient scores per page section inform which zones must carry high-value content; F-stem column is the weakest scent zone."

eisenberg_integration:
  feeds_from: eisenberg-scent-continuity-auditor
  feeds_to: nielsen-scannability-optimizer
  shared_data: "Buying modality (competitive/methodical/spontaneous/humanistic) predicts whether Layer-Cake or Commitment pattern is achievable; spontaneous buyers default to Spotted."

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: nielsen-banner-blindness-detector
  shared_data: "System 1 aesthetic first impressions (50ms threshold) fire before any scan pattern begins; visual design signals that trigger ad-association suppress fixations on CTAs."
---

# Nielsen F-Pattern Layout Auditor

## LAYER 1: INVARIANTS (Never override.)

1. **F-Pattern is a failure state, not a feature.** It emerges when pages lack structural cues. Never design for it; design against it by giving users Layer-Cake triggers (meaningful subheadings).
2. **Above-fold receives 102% more views than 100px below.** The value proposition and primary CTA must clear the fold. No exceptions for "scrollers will find it."
3. **Right rail is dead.** Eyetracking heatmaps show near-zero fixations on right-column content due to ad-association. CTAs, testimonials, and forms placed right of center receive negligible attention.
4. **First two words of every line are read 3-4x more than word three onward.** The F-stem scan makes this structurally inevitable. Left-align all key claims; front-load benefit language before qualifiers.
5. **Users grant ~10 seconds to decide if the page is worth their time.** The Inverted Pyramid applies: conclusion first, supporting proof second, background last. A page that buries the offer below three paragraphs of context loses before it starts.
6. **The CTA label is a promise.** If the button says "Get Started" and a signup wall appears, the user leaves for a competitor. Label must match destination exactly (Splitwise eyetracking finding, 2014).
7. **Commitment Pattern requires trust OR high motivation — not just good copy.** If credibility signals (real photos, pricing disclosure, third-party reviews) are absent, Commitment is structurally unavailable to you regardless of how good the headline is.

## LAYER 2: QUALITY GUIDANCE

1. Diagnose the active scan pattern BEFORE prescribing layout changes. Treating a Spotted-Pattern page as an F-Pattern page produces wrong fixes.
2. Every structural recommendation must cite which eyetracking finding or time-scale threshold it addresses. No generic "improve readability" language.
3. Fold placement must account for device mix. Mobile fold ~600px; desktop fold ~768-900px. Audit both breakpoints.
4. Subheadings that trigger Layer-Cake must carry standalone meaning — a user reading only subheadings must reconstruct the argument. Test by reading subheads in isolation.
5. When Banner Blindness is the primary pathology (not F-Pattern), hand off to nielsen-banner-blindness-detector; do not patch here.

## PURPOSE

Nielsen and Pernice's eyetracking research across thousands of page sessions identified four distinct scan patterns visitors use — and proved that three of them result in most conversion content being ignored. This skill applies their diagnostic framework to a specific page: identifies which pattern is active, scores how much conversion content falls outside the scan path, and produces concrete restructuring moves to put the offer where eyes actually land.

**Brag line: "We place CTAs where eyes actually land, not where we hope."**

The primary lever is pattern-switching: moving a page from F-Pattern (worst) toward Layer-Cake (most efficient for motivated buyers) or Commitment (best comprehension, requires trust infrastructure). The secondary lever is the Page Fold Attention Gradient — quantified at 102% more fixations above fold vs. 100px below — used to score exactly how much conversion weight is being sacrificed to scroll distance.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written section-by-section description
- The ONE desired action: click, opt-in, purchase, next-step, call booking, etc.

**Optional (improves diagnosis):**
- Analytics: scroll depth data, heatmap screenshots, time-on-page
- Device split: % mobile vs. desktop (affects fold threshold)
- Funnel position: cold traffic vs. warm vs. retargeted (affects Commitment achievability)
- Audience motivation level: high (premium buyers), medium (comparison shopping), low (cold interruption)

## EXECUTION PROCESS

### Step 1 — Scan Pattern Diagnosis

Identify which of Pernice's Four Scanning Patterns is the page currently triggering, and why.

**Pattern Triggers:**

| Pattern | Trigger Condition | Conversion Implication |
|---------|------------------|----------------------|
| F-Pattern | Unformatted text blocks, no subheads, no bolding | Most content after line 3 ignored |
| Spotted | Bold/linked/colored words, specific target terms visible | Users jump to styled words, skip context |
| Layer-Cake | Meaningful subheadings every 2-4 paragraphs | Users skim heads, dive into relevant sections |
| Commitment | High trust signals + high personal relevance + motivated audience | Best comprehension; rarely achieved cold |

**Diagnosis method:** Count the number of distinct subheadings visible on the page. If fewer than 1 per 200 words: F-Pattern is the active state. If color/bold styling applied to non-critical words: Spotted risk. If subheadings carry standalone meaning (read them in isolation — do they tell the story?): Layer-Cake eligible.

**Score:** Assign one primary pattern + note any mixed signals.

### Step 2 — Fold Audit (Attention Gradient Scoring)

Locate the fold on the primary device (use 768px desktop, 600px mobile as defaults if not specified).

List every conversion element on the page and classify by fold position:

| Element | Position | Fold Status | Attention Weight |
|---------|----------|-------------|-----------------|
| Value prop headline | px from top | Above/Below | High/Med/Low |
| Primary CTA | px from top | Above/Below | High/Med/Low |
| Lead form | px from top | Above/Below | High/Med/Low |
| Key benefit block | px from top | Above/Below | High/Med/Low |
| Social proof | px from top | Above/Below | High/Med/Low |

**Gradient rule:** Above fold = 100% attention weight. 0-100px below fold = ~50% weight. 100-300px below = ~20%. Beyond 2nd screenful = <5% (74% of viewing time is in first two screenfuls). Beyond 3rd screenful = negligible.

**Fold Score:** Sum of (conversion element importance × attention weight). Minimum viable score: primary CTA above fold with value prop. If either is below fold on mobile: critical finding.

### Step 3 — Left-Rail Dominance Check

F-stem scanning means the left 20-25% of page width receives disproportionate fixations. Map every content element to its horizontal position:

- **Left-anchored (0-30% width):** High scan probability
- **Center (30-70%):** Medium — captured during horizontal passes only
- **Right (70-100%):** Low — ad-association zone; near-zero fixations on right rail

Flag any of these appearing right-of-center: CTA buttons, opt-in forms, testimonials, price blocks, guarantee badges. These are the highest-cost placement errors.

### Step 4 — First-Two-Words Test

For every headline, subhead, bullet, and CTA on the page, extract words 1-2 and assess whether they carry the core benefit/action.

**Passing:** "Double your revenue without hiring" — words 1-2: "Double your"
**Failing:** "The complete system for doubling revenue" — words 1-2: "The complete" (generic, scannable value = zero)

Count failures. Any subhead or CTA where words 1-2 are articles, prepositions, or generic qualifiers is a First-Two-Words failure. Target: 0 failures on above-fold content, <20% failures on below-fold content.

### Step 5 — 10-Second Value Proposition Test

Apply the UX Time-Scale Model: users allocate ~10 seconds to decide if the page merits attention. Simulate a cold-read: read only what is visible above the fold for 10 seconds.

Answer these three questions from that 10-second read:
1. What is being offered?
2. Who is it for?
3. What is the one action to take now?

If any answer is "unclear" or "not present": critical finding. The Inverted Pyramid (conclusion first) has been violated.

### Step 6 — Pattern-Switch Prescription

Based on Steps 1-5, prescribe the minimum structural changes to shift the active scan pattern toward Layer-Cake (default target) or Commitment (if trust signals are present and audience motivation is high).

**F-Pattern → Layer-Cake conversion moves:**
- Add a meaningful subheading every 150-200 words; subhead must carry standalone meaning
- Bold the 2-3 key benefit words per section (triggers Spotted for those terms, which is acceptable when the spotted words are conversion-critical)
- Break any paragraph >4 lines into bullets or sub-sections
- Move the primary CTA to follow the first subheaded section (not the end of the page)

**Layer-Cake → Commitment moves (only if trust infrastructure exists):**
- Confirm: real staff photos present, pricing disclosed, external reviews linked
- Add a credibility cluster (design quality, upfront disclosure, third-party validation) above fold
- Increase information density per section — motivated readers want depth, not summaries
- Reduce "emergency exits" language that signals doubt

### Step 7 — CTA Promise Audit

For every CTA on the page, run the Link Promise test (Nielsen 2014 Splitwise finding):

1. Read the CTA label exactly
2. Describe what the user encounters after clicking
3. Do they match? Yes/No

**Common failures:** "Get Started" → signup wall; "Learn More" → sales page; "Download Free Guide" → requires credit card. Each mismatch is a promise violation; users who discover the break go to competitors. Prescribe exact label replacements grounded in destination reality.

## OUTPUT STRUCTURE

**1. Scan Pattern Diagnosis**
Active pattern, trigger evidence, conversion implication specific to this page.

**2. Fold Audit Table**
All conversion elements, fold position, attention weight, critical findings.

**3. Left-Rail Placement Errors**
List of mis-placed elements with current position and target position.

**4. First-Two-Words Failures**
Table of failing headlines/subheads with rewrites where words 1-2 carry the benefit.

**5. 10-Second VP Test Result**
Pass/fail on each of the three questions, with specific copy gaps identified.

**6. Pattern-Switch Prescription**
Ordered list of structural changes (highest-impact first), each tagged to the specific eyetracking finding it addresses.

**7. CTA Promise Audit**
Each CTA: current label → current destination → match status → recommended label.

**8. Priority Stack**
Top 3 changes that, if made only, would produce the highest lift in scan-path alignment. For when the client can only ship one sprint.

## WORKED MINI-EXAMPLE

**Page:** SaaS project management tool — free trial landing page
**Desired action:** Start free trial (email opt-in above fold)

**Before:**
- Headline: "The Complete Project Management Solution for Growing Teams"
- Wall of text (280 words, no subheadings)
- Free trial button at page bottom, right-aligned
- Pricing table in right column
- Testimonials below fold 2

**F-Pattern Diagnosis:** Active. No subheadings, unformatted body = F-stem scan. Users read headline + first two lines, then vertical scan down the left edge. Button (bottom-right) receives near-zero fixations.

**Fold Audit:** CTA below fold on 100% of mobile devices (estimated 800px from top). Value prop: "Growing Teams" — words 1-2: "The Complete" (generic, fails First-Two-Words test).

**Fixes applied:**
1. Headline rewrite: "Ship Projects 2x Faster — Free 14-Day Trial" (words 1-2 carry core benefit; CTA embedded in headline)
2. Button moved: immediately below headline, left-aligned, above fold on all breakpoints
3. Body split into 3 sections with subheads: "Where Your Team Loses Time Now" / "How [Product] Cuts That in Half" / "What You Get in 14 Days"
4. Pricing table removed from right rail; moved to dedicated section below fold left-aligned
5. Top testimonial moved above fold, left of CTA (credibility signal at decision point)

**Pattern shift:** F-Pattern → Layer-Cake. Users now scan subheads, enter at the relevant section, reach CTA within first screenful.

**After (estimated):** CTA attention weight: 15% → 82% (above fold, left-aligned, after high-scent headline).

## OUTPUT FILE

Save to: [project-folder]/Nielsen & Pernice - Click Architecture/[YYYY-MM] - F-Pattern Layout Audit.md
