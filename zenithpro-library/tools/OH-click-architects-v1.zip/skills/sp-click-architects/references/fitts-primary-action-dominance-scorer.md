---
name: fitts-primary-action-dominance-scorer
description: Use when a page's primary CTA is underperforming or competing actions are stealing clicks — scores the primary CTA's Index of Difficulty relative to every other interactive element and issues a dominance verdict with ranked fixes.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Paul Fitts (Fitts's Law, 1954; Shannon formulation, 1992; Index of Difficulty, Throughput) — Click Architecture (Skill 2 of 7)"
interface:
  invoke: "/fitts-primary-action-dominance-scorer"
  calls: []
  called_by: [user, fitts-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Layout changes, A/B test deployments, and responsive breakpoint updates alter button geometry and prime-pixel positions continuously."

fitts_target_cost_auditor_integration:
  feeds_from: fitts-target-cost-auditor
  feeds_to: fitts-primary-action-dominance-scorer
  shared_data: "Per-element ID scores (D, W, computed ID bits) for every interactive element on the page. Target Cost Auditor measures all targets; this skill uses those scores to rank the primary CTA against competitors and issue the dominance verdict."

fitts_thumb_zone_mapper_integration:
  feeds_from: fitts-thumb-zone-mapper
  feeds_to: fitts-primary-action-dominance-scorer
  shared_data: "Mobile prime-pixel coordinates (dominant-thumb hover zone, bottom-center region) used as D origin for the primary CTA's mobile ID calculation."

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: fitts-primary-action-dominance-scorer
  shared_data: "System 1 / System 2 load analysis: cognitive friction from competing CTAs amplifies physical friction from high ID. Both components must be suppressed for true CTA dominance."

iyengar_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: fitts-primary-action-dominance-scorer
  shared_data: "Count and visual weight of alternative choices near the primary CTA. Iyengar's choice overload evidence quantifies the cognitive-cost component that Fitts's physical-cost equation does not cover."
---

# Fitts Primary Action Dominance Scorer

## LAYER 1: INVARIANTS (Never override.)

1. **ID is the unit of truth.** Every diagnosis references ID = log₂(1 + D/W) in bits. No vague "the button is small" — compute or estimate D and W, state the resulting ID, compare it against competitors.
2. **Dominance requires the primary CTA to have strictly the lowest ID of any interactive element in the viewport at page load.** If any competing element has equal or lower ID, dominance fails — regardless of how large or well-designed the CTA appears.
3. **Prime pixel is the D origin, not page center.** Desktop D is measured from the last likely cursor resting point (center-screen on cold load; last field/element on warm load). Mobile D is measured from the dominant-thumb hover zone (bottom-center, ~80% down the viewport).
4. **Effective width (We) governs mobile scoring.** Compute We = 4.133 × SD of actual tap x-coordinates from heatmap data if available. If not, use the rendered CSS width × 0.75 as a conservative estimate. Never use CSS width alone — declared hit areas overestimate actual acquisition width.
5. **Speed-Accuracy Trade-off (SAT) penalizes small distant targets doubly.** A CTA with ID > 4 bits forces users into careful, slow homing-phase acquisition OR produces mis-clicks on adjacent elements. Flag any primary CTA with ID > 4 bits as a SAT risk, not merely a "slow click."
6. **Edge/corner infinite-target logic applies to desktop sticky elements only.** A sticky header or footer CTA on desktop exploits infinite W at the screen boundary. Do NOT apply this reasoning to mobile, where edges are the hardest zones to hit.
7. **Cumulative ID matters in multi-step flows.** Each step's CTA has its own ID. The highest-ID step is the conversion bottleneck. Report cumulative MT estimate across all steps, not just the final CTA.

## LAYER 2: QUALITY GUIDANCE

1. **Separate mobile and desktop analyses.** Prime pixel, effective width, and edge-target rules differ by input modality. A score that conflates them is wrong for both contexts.
2. **Include at least one competing element in every comparison.** A dominance score without a comparison target is a standalone number, not a verdict. Always name the second-lowest-ID element and quantify the gap.
3. **Translate ID gap to estimated click-time difference.** Use MT = a + b × ID with conservative constants (a = 200ms, b = 150ms/bit for mouse; a = 300ms, b = 200ms/bit for touch) to make the business case concrete.
4. **Mis-click radius audit is mandatory when ID gap < 1 bit.** If the primary CTA's ID advantage over a neighboring element is less than 1 bit, the SAT virtually guarantees accidental clicks. Measure the pixel gap between their boundaries.
5. **Recommend the two-phase movement test.** Full-width buttons on mobile eliminate the homing phase. Any CTA that fails the homing-phase test (width < 80% of container) is a candidate for full-width treatment before any other change.

## PURPOSE

This skill takes a real web page and a stated desired action, then applies Fitts's Law to answer one question: is the primary CTA mathematically the easiest thing to hit on the page?

The lever: minimize ID = log₂(1 + D/W) on the primary CTA while simultaneously raising or suppressing ID on every competing interactive element. When the primary CTA achieves the lowest ID on the page, it dominates — not through visual hierarchy alone, but through the motor physics of pointing.

The brag line: **"Our primary button is mathematically the easiest thing to hit on the page."**

This is Skill 2 of 7 in the fitts-* cluster. Its lane is the relative dominance verdict — comparing the primary CTA's ID against competitors and quantifying the gap. Target Cost Auditor (Skill 1) measures all targets individually. Thumb Zone Mapper (Skill 3) supplies the mobile prime-pixel origin. This skill synthesizes those inputs into a pass/fail dominance score with ranked interventions.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written layout description precise enough to estimate button dimensions and positions.
- The ONE desired action: e.g., "click Add to Cart," "submit email opt-in," "click Start Free Trial."

**Strongly recommended:**
- Viewport dimensions being evaluated (desktop 1440px, mobile 390px, etc.).
- Heatmap or session-recording data showing actual click/tap distributions (enables effective-width We calculation).
- List of all interactive elements visible without scrolling (or a screenshot where they can be counted).

**Optional:**
- Funnel position (landing page, checkout step 2, etc.) — informs cumulative ID analysis.
- Current click-through rate on primary CTA and mis-click rate on competing elements.
- Analytics showing device split (sets weighting between desktop and mobile analysis).

## EXECUTION PROCESS

**Step 1 — Inventory all interactive elements in the above-the-fold viewport.**

List every clickable/tappable element visible at page load without scrolling: primary CTA, nav links, secondary CTAs, social proof links, header logo, chat widgets, footer links if visible. Assign each a label (P = primary CTA, C1, C2, C3 … for competitors).

**Step 2 — Establish the prime pixel for each modality.**

- Desktop: default D origin = viewport center (x: 720, y: 400 at 1440×800). If the page has a form or wizard, D origin shifts to the last field in the sequence.
- Mobile: default D origin = bottom-center of the thumb zone (x: 195, y: 650 at 390×844, i.e., 83% down the viewport height).

**Step 3 — Measure or estimate D and W for each element.**

For each element:
- D = Euclidean distance from prime pixel to element center (pixels).
- W = rendered width in pixels along the axis of approach (horizontal for thumb approach, width of button along x-axis; vertical for vertical scrolling approach, height of button along y-axis). Use min(width, height) as the conservative W if approach axis is ambiguous.
- If heatmap data exists: We = 4.133 × SD of click/tap x-coordinates for that element. Use We in place of W.

**Step 4 — Compute ID for each element.**

ID = log₂(1 + D/W)

Round to two decimal places. Record in the scoring table.

| Label | Element | D (px) | W (px) | ID (bits) | MT est. (ms) |
|-------|---------|--------|--------|-----------|-------------|
| P | Primary CTA | … | … | … | … |
| C1 | Nav link | … | … | … | … |
| C2 | Secondary CTA | … | … | … | … |

MT estimate: use MT = 200 + 150 × ID (desktop mouse) or MT = 300 + 200 × ID (touch).

**Step 5 — Issue the dominance verdict.**

- DOMINANT: Primary CTA has strictly the lowest ID of all elements. Gap to nearest competitor ≥ 1 bit.
- MARGINAL: Primary CTA has lowest ID but gap to nearest competitor < 1 bit. SAT risk — mis-click rate likely elevated.
- FAILING: One or more competing elements have ID ≤ primary CTA's ID. Page fails dominance.

State: "Primary CTA ID = X bits. Nearest competitor ([label]) ID = Y bits. Gap = Z bits. Verdict: [DOMINANT / MARGINAL / FAILING]."

**Step 6 — Diagnose the root cause of any non-DOMINANT verdict.**

Apply the two-variable diagnosis:
- Is D too large? (CTA is far from prime pixel.) Root cause: placement problem.
- Is W too small? (CTA hit area is narrow.) Root cause: size problem.
- Is a competitor's ID too low? (A competing element is large or close.) Root cause: suppression problem.

Rank the three interventions by ID-reduction impact: fixing the highest-magnitude variable first.

**Step 7 — Generate ranked interventions.**

For each finding, state:
- Current D and W → current ID.
- Proposed change → new D and W → new ID → estimated MT reduction in ms.
- Implementation instruction (specific CSS/layout change, not vague advice).

Order interventions by estimated ID reduction, largest first.

**Step 8 — Two-phase movement test (mobile only).**

Does the primary CTA span ≥ 80% of the container width? If yes: homing phase is effectively eliminated (W ≈ container, D along x-axis ≈ 0). If no: full-width treatment is the highest-leverage single change available — compute the ID difference between current W and container W and add it to the intervention list.

**Step 9 — SAT risk audit.**

For any competitor within 200px of the primary CTA boundary: measure the pixel gap between element boundaries (not centers). If gap < 20px (desktop) or < 44px (mobile), flag as SAT collision — mis-clicks are mechanically probable at typical approach speeds. Recommend either suppressing the competitor or separating it by minimum 44px (mobile) / 20px (desktop).

**Step 10 — Cumulative ID (multi-step flows only).**

If the page is a step in a funnel: sum the primary CTA ID across all steps. Identify the max-ID step. State: "Cumulative MT estimate across [N] steps = [X] ms. Conversion bottleneck = Step [N] (ID = [X] bits)."

## OUTPUT STRUCTURE

**Section 1: Page Snapshot**
One-paragraph description of the page and stated desired action as understood. Confirm prime pixel origin used.

**Section 2: Scoring Table**
Full table per Step 4. All interactive elements, D, W, ID, MT estimate. Two tables if analyzing both desktop and mobile.

**Section 3: Dominance Verdict**
Single sentence per Step 5. DOMINANT / MARGINAL / FAILING with exact ID gap.

**Section 4: Root Cause Diagnosis**
Which variable (D, W, competitor ID) is the primary failure driver. Two to four sentences.

**Section 5: Ranked Interventions**
Numbered list. Each entry: current state → proposed change → new ID → MT reduction → implementation note. Minimum 3, maximum 8 interventions. Ordered by ID reduction impact.

**Section 6: SAT Collision Flags**
Any element within collision distance of the primary CTA. Boundary gap in pixels. Recommended separation.

**Section 7: Cumulative ID Summary** (multi-step flows only)
Bottleneck step identified. Cumulative MT. Priority fix.

## WORKED MINI-EXAMPLE

**Page:** SaaS landing page. Desired action: click "Start Free Trial" button.

**Layout (desktop, 1440px wide):**
- "Start Free Trial" button: center-right of hero, x=900, y=520. Rendered width=160px, height=44px.
- "Watch Demo" link: x=700, y=520. Width=120px, height=32px.
- Top nav: "Pricing" link at x=1100, y=40. Width=60px, height=32px.
- Prime pixel (cold load): x=720, y=400.

**Scoring:**

| Label | Element | D (px) | W (px) | ID (bits) | MT (ms) |
|-------|---------|--------|--------|-----------|---------|
| P | Start Free Trial | 215 | 160 | 3.75 | 762 |
| C1 | Watch Demo | 51 | 120 | 2.06 | 509 |
| C2 | Pricing nav | 717 | 60 | 3.65 | 747 |

**Verdict:** FAILING. "Watch Demo" (C1) has ID = 2.06 bits vs. primary CTA ID = 3.75 bits. Gap = -1.69 bits in the wrong direction. "Watch Demo" is the mathematically easier click.

**Root cause:** D problem on primary CTA (215px from prime pixel vs. 51px for Watch Demo) AND W advantage on Watch Demo is modest — the real driver is placement.

**Top interventions:**
1. Move "Start Free Trial" to x=720, y=480 (directly below the headline, at prime pixel). New D = 80px. New ID = 2.54 bits. MT reduction = -182ms. (CSS: adjust hero layout, center the button horizontally.)
2. Reduce "Watch Demo" to a text link with no background fill, W shrinks from 120px to effective 60px (text span only). New C1 ID = 2.53 bits — now at parity with fixed primary CTA. Add 60px left margin to increase D to 150px. New C1 ID = 3.22 bits. Gap = +0.68 bits. Verdict becomes MARGINAL; add 20px spatial separation to reach DOMINANT.
3. Increase "Start Free Trial" button width to 240px (full hero column). New W = 240px. New ID (at new D=80) = 2.12 bits. Gap to C1 after C1 fix = 1.10 bits. **Verdict: DOMINANT.**

## OUTPUT FILE
Save to: [project-folder]/Fitts - Click Architecture/[YYYY-MM] - Primary Action Dominance Score.md
