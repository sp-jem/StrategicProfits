---
name: eisenberg-scent-continuity-auditor
description: Use when ad-to-page message-match is broken or unverified — audits information scent across the full referral chain (ad/email/SERP -> landing page headline -> CTA) and outputs concrete on-page fixes to prevent abandonment before any other persuasion can act.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Bryan Eisenberg & Jeffrey Eisenberg (Waiting For Your Cat to Bark 2006; Call to Action 2005; Always Be Testing 2008; Persuasion Architecture + Information Scent / Ad Continuity framework) — Click Architecture (Skill 2 of 7)"
interface:
  invoke: "/eisenberg-scent-continuity-auditor"
  calls: []
  called_by: [user, eisenberg-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Ad creative, email copy, and SERP snippets change frequently; scent gaps that were sealed last month may reopen with any campaign refresh."

eisenberg_persona_pathway_integration:
  feeds_from: eisenberg-persona-pathway-mapper
  feeds_to: eisenberg-landing-anatomy-architect
  shared_data: "Dominant buying modality for this traffic source; persona-specific trigger words that must echo in the headline"

fogg_integration:
  feeds_from: fogg-behavior-system-designer
  feeds_to: fogg-prompt-designer
  shared_data: "Motivation state of visitor at moment of click (high vs low); if motivation is already high from the ad, scent break is the primary abandonment cause, not ability or prompt failures"

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: kahneman-peak-end-architect
  shared_data: "Isolation effect — the specific framing/contrast in the ad that made the visitor click; this exact frame must be maintained on the page headline or System 1 registers mismatch and triggers bounce"
---

# Eisenberg Scent Continuity Auditor

## LAYER 1: INVARIANTS (Never override.)

1. **Scent is the single highest-leverage headline test.** Before any other page variable is touched, the landing page headline must echo the trigger phrase from the ad/email/SERP result that delivered the visitor. This is not copywriting preference — it is information foraging mechanics (Ed Chi, 2001, operationalized by the Eisenbergs 2004).
2. **Scent break causes abandonment before persuasion can act.** The Hierarchy of Optimization pyramid requires Functional → Accessible → Usable → Intuitive → Persuasive, in order. Scent break is a Functional failure — the page does not do what the ad promised. No amount of Spontaneous urgency or Humanistic storytelling recovers a visitor whose scent was broken at the fold.
3. **The denominator of CR is qualified intentional visitors.** CR = (# who took desired action) / (# who INTENDED to take that action). Scent audit uses this denominator: segment analytics by the specific ad/email source, not raw traffic. A 1.2% page CR may hide a 9% CR from one ad group where scent is intact and 0.3% from another where it is broken.
4. **Matched keywords, matched visual register, matched emotional tone — all three must hold.** Scent is not just word-matching. Switching from a fear-framed ad to a hope-framed headline, or from a product image in the ad to an abstract hero on the page, breaks scent even when words match.
5. **The Conversion Trinity runs after scent is confirmed, not instead of it.** Relevance (scent) → Value (proposition) → Call to Action. These are sequential gates, not parallel levers. Fixing CTA contrast on a page with a broken headline is wasted effort.
6. **Never test headline and image independently when diagnosing scent.** They function as a single Relevance unit. Split-test them together against the referral source's trigger phrase.
7. **Every scent finding maps to one level of the Hierarchy pyramid.** State which level is failing before recommending a fix. Fixes at a lower pyramid level invalidate fixes at higher levels; resolve bottom-up.

## LAYER 2: QUALITY GUIDANCE

1. Ground every diagnosis in the specific trigger phrase from the referral source. Quote it verbatim. Then quote the actual page headline. Gap is the finding.
2. Score scent strength numerically (0-10 per dimension: keyword match, visual register match, emotional register match). Composite score under 7/10 requires immediate fix before any other optimization.
3. After confirming scent, run the full Conversion Trinity audit: Relevance confirmed → diagnose Value (does body copy explain why THIS solution for THIS visitor?) → diagnose Action (is the CTA mechanically obvious?).
4. Use the buying modality framework to validate that the page's above-fold language matches the dominant modality of this traffic source — scent can be word-matched but modality-mismatched (e.g., ad uses urgency language targeting Spontaneous buyers; page serves Methodical copy above the fold).
5. Flag every finding at its pyramid level. Deliver fixes in pyramid order (functional first, persuasive last).

## PURPOSE

This skill takes one real page and its referral source (ad copy, email subject/body, SERP snippet, or social post) and runs the Eisenbergs' Information Scent / Ad Continuity audit from first click to desired action. It identifies exactly where the promised trail breaks, scores the break, and outputs concrete headline/image/copy fixes using the Conversion Trinity and Four Buying Modalities frameworks.

**Brag line:** "Our ad and our page tell one unbroken story — scent never breaks."

The page-action lever: visitors follow scent trails and abandon when the trail weakens. No persuasion mechanism — urgency, social proof, authority, loss aversion — can compensate for a broken scent trail. This audit seals the trail before other optimizations are applied.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description of above-fold content (headline, subhead, hero image, CTA)
- The referral source: verbatim ad copy, email subject line + preview text, SERP snippet, or social post that delivered the visitor
- The ONE desired action: the single conversion event this page is built for (click, opt-in, purchase, book call, etc.)

**Optional (significantly improves output):**
- Analytics segment: conversion rate from this specific referral source vs. page average
- Audience/buying modality data: which of the four temperaments dominates this traffic source
- Funnel position: cold traffic vs. warm list vs. retargeting
- Additional page sections (below fold) for full Conversion Trinity audit

## EXECUTION PROCESS

**Step 1 — Extract the trigger phrase from the referral source**

Identify the single phrase in the ad/email/SERP that was most likely the proximate cause of the click. For search ads: the headline. For email: the subject line's core promise. For social: the hook sentence. For display: the headline + image combination.

Isolate: (a) the core keyword/phrase, (b) the emotional register (fear / aspiration / curiosity / urgency), (c) the specific promise or claim.

**Step 2 — Score scent strength across three dimensions (0-10 each)**

| Dimension | What to Score | 0 = | 10 = |
|-----------|---------------|-----|------|
| Keyword | Trigger phrase echo in headline | No shared words | Near-verbatim |
| Visual | Ad image tone matches hero image | Opposite tone/style | Same object/style |
| Emotional | Ad register matches page register | Inverted (fear vs joy) | Identical register |

Composite scent score = (K + V + E) / 3. Threshold: >= 7 = scent intact; 5-6.9 = weak, fix before other optimization; < 5 = critical break, bounce cause identified.

**Step 3 — Map the break to the Hierarchy of Optimization**

- Broken link / 404 / wrong page loaded = Level 1 (Functional) — stop, fix immediately
- Hero image fails to load on mobile = Level 2 (Accessible)
- Headline is present but hidden below a nav banner = Level 3 (Usable)
- Correct words but confusing sentence structure = Level 4 (Intuitive)
- Correct words, clear structure, but wrong emotional register for this audience = Level 5 (Persuasive)

State the pyramid level before proposing a fix. Do not fix Level 5 issues on a page with Level 1-3 failures.

**Step 4 — Run the Conversion Trinity audit (only after scent score >= 7 or after fixing it)**

Gate 1 — Relevance: Does the headline explicitly confirm the visitor is in the right place for what the ad promised? If the ad said "Free CRO audit for SaaS" and the headline says "Grow Your Business" — Relevance fails regardless of keyword presence.

Gate 2 — Value: Does the body copy (above the fold or first scroll) explain WHY this specific solution is right for this visitor's stated intent? Not generic benefits — benefits linked to the trigger intent. Threshold: a visitor who arrived from this specific ad should be able to answer "why this?" without scrolling past the first content block.

Gate 3 — Action: Is the CTA (a) mechanically visible — passes grayscale contrast test, (b) verbally specific — names what happens next, not just "Submit" or "Learn More", and (c) friction-matched to buying modality (see Step 5)?

**Step 5 — Validate buying modality match**

From the ad's language, classify the dominant modality being targeted:

- Urgency + emotional benefit language = Spontaneous (fast+emotional): page must deliver friction-free CTA, urgency signals, visual dynamism above fold. If page serves Methodical copy (specs, data, "learn more"), modality mismatch is a scent-level failure for that segment.
- Superlatives + competitive framing = Competitive (fast+logical): page must show named proof (awards, rankings) and comparison within first scroll.
- Detailed feature claims + "how it works" = Methodical (slow+logical): page must deliver specs, data, no urgency hype. Urgency language on a Methodical-targeted page breaks trust.
- Mission/story/people framing = Humanistic (slow+emotional): page must show real people, authentic testimonials, purpose-language above fold.

Score modality match: Matched / Partially matched / Mismatched. Mismatch at this level = rewrite above-fold zone to serve the correct modality.

**Step 6 — Run the Buyer Legend pre-mortem for this visitor**

Walk the page as the specific visitor who clicked this specific ad. For each step (arrival → headline → body → CTA), list every reason they would NOT proceed. Each item is a required fix. Prioritize by pyramid level, then by revenue impact (estimated conversion lift).

**Step 7 — Output prioritized fixes**

Rank findings:
- P0: Scent break (composite < 7) — fix before anything else
- P1: Conversion Trinity gate failure (Relevance, then Value, then Action — in order)
- P2: Buying modality mismatch above fold
- P3: Below-fold improvements

For each fix: state current element (verbatim), state replacement (verbatim draft), state expected mechanism (which framework principle it activates), state pyramid level.

## OUTPUT STRUCTURE

**1. Referral Source Analysis**
Verbatim trigger phrase, emotional register, specific promise.

**2. Scent Score Card**

| Dimension | Score (0-10) | Finding |
|-----------|-------------|---------|
| Keyword | X | [gap or confirmation] |
| Visual | X | [gap or confirmation] |
| Emotional | X | [gap or confirmation] |
| Composite | X/10 | [Intact / Weak / Critical break] |

**3. Hierarchy Level Assessment**
Which pyramid level is failing (if any). Bottom-up fix order.

**4. Conversion Trinity Audit**
Gate 1 Relevance: Pass / Fail + evidence
Gate 2 Value: Pass / Fail + evidence
Gate 3 Action: Pass / Fail + evidence

**5. Buying Modality Match**
Dominant modality from ad → above-fold page modality → Matched / Mismatched

**6. Buyer Legend Pre-Mortem**
Bullet list: reasons this specific visitor would not proceed at each page step.

**7. Prioritized Fix List**
P0 → P3 fixes, each with: Current element | Replacement draft | Mechanism | Pyramid level

**8. Integration Handoffs**
- If persona pathway gaps found: flag for eisenberg-persona-pathway-mapper
- If page anatomy restructuring needed: flag for eisenberg-landing-anatomy-architect
- If CTA optimization needed post-scent-fix: flag for eisenberg-micro-action-sequencer

## WORKED MINI-EXAMPLE

**Page:** SaaS project management tool, desired action: start free trial

**Referral source (Google ad headline):** "Stop Missing Deadlines — Free 14-Day Trial"
Trigger phrase: "Stop Missing Deadlines"
Emotional register: fear/relief
Specific promise: free trial, deadline relief

**Current page headline:** "The Project Management Platform Built for Teams"

**Scent Score:**
- Keyword: 1/10 — zero shared words ("deadlines" absent, "trial" absent)
- Visual: 5/10 — hero shows a dashboard (neutral), ad had no image
- Emotional: 2/10 — ad = fear/relief; page = generic capability statement
- Composite: 2.7/10 — Critical break. Bounce cause identified.

**Pyramid level:** Level 5 (Persuasive — wrong language register). Levels 1-4 assumed functional.

**Conversion Trinity:** Relevance FAILS at the headline. Value and Action audit deferred until Relevance is fixed.

**Buying modality:** Ad targeted Spontaneous (fast-emotional, urgency + pain language). Page headline serves Methodistic register (platform, built for teams = capability, not relief). Modality mismatch.

**Fix (P0):**
- Current headline: "The Project Management Platform Built for Teams"
- Replacement: "Stop Missing Deadlines — Start Your Free 14-Day Trial"
- Mechanism: Near-verbatim trigger echo (keyword scent = 10/10) + emotional register match (fear/relief preserved) + promise confirmation (trial reiterated)
- Pyramid level: Level 5 — Persuasive copy

**Expected impact:** Segment CR for this ad group recovers toward page average or above; denominator-normalized CR test isolates the lift to this referral segment specifically.

## OUTPUT FILE

Save to: [project-folder]/Eisenberg - Click Architecture/[YYYY-MM] - Scent Continuity Audit - [Page Name].md
