---
name: eisenberg-field-intelligence
description: "Use when you have run 4-6 individual Eisenberg skill analyses on the same page and need to synthesize convergence zones, resolve contradictions, identify The Single Move, and integrate findings with the broader Click Architects network — produces a Persuasion Architecture Intelligence Briefing with one prioritized page change and a 90-day conversion projection."
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Bryan Eisenberg & Jeffrey Eisenberg (Persuasion Architecture, 2003-2006; Call to Action, 2005; Waiting for Your Cat to Bark, 2006; Buyer Legends, 2014) — Field Intelligence (Skill 7 of 7)"
interface:
  invoke: "/eisenberg-field-intelligence"
  calls: [eisenberg-persona-pathway-mapper, eisenberg-scent-continuity-auditor, eisenberg-landing-anatomy-architect, eisenberg-buying-modality-classifier, eisenberg-conversion-trinity-builder, eisenberg-micro-action-sequencer]
  called_by: [user, click-architects]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Ad campaigns, traffic sources, and audience buying-modality distributions shift quarterly. Scent mapping becomes stale as ad creative rotates. Reassess when any traffic source changes >20% mix or any ad creative refreshes."
pirolli_integration:
  feeds_from: [pirolli-field-intelligence]
  feeds_to: [pirolli-scent-trail-auditor]
  shared_data: "Pirolli's information foraging theory is the scientific substrate of Eisenberg's scent doctrine. Pirolli quantifies the cost-benefit calculus visitors run at each click; Eisenberg specifies which content signals sustain or break the trail. Combined: Pirolli tells you WHEN a visitor abandons (when information gain per click falls below threshold); Eisenberg tells you WHY (scent break, modality mismatch, Trinity failure). The synthesis produces scent trails with measurable proximal scent strength scores at each step."
kohavi_integration:
  feeds_from: [kohavi-field-intelligence]
  feeds_to: [kohavi-experiment-designer]
  shared_data: "Kohavi's controlled experimentation framework converts Eisenberg's persuasion architecture hypotheses into statistically valid tests. Eisenberg generates rich directional theory (which modality, which Trinity element, which scent signal); Kohavi enforces that those theories are proven rather than assumed. Combined: every convergence zone produced by Eisenberg Field Intelligence is a pre-registered hypothesis waiting for an A/B test. Nothing from the Eisenberg stack is treated as confirmed until Kohavi validates it at p<0.05 with pre-specified power."
fitts_integration:
  feeds_from: [fitts-field-intelligence]
  feeds_to: [fitts-click-path-minimizer]
  shared_data: "Fitts quantifies motor cost (distance + target size = movement time) for every click action on a page. Hick quantifies choice cost (decision time rises logarithmically with options). Eisenberg's Conversion Trinity specifies WHAT the CTA must communicate. The synthesis is total click cost = Fitts motor time + Hick decision time + Trinity confidence gap. A CTA that scores well on all three converts; any single failure suppresses conversion. Micro-action sequencer outputs feed directly into Fitts target-cost scoring."
goward_integration:
  feeds_from: [goward-field-intelligence]
  feeds_to: [goward-test-prioritizer]
  shared_data: "Goward's conversion research methodology operationalizes Eisenberg's Persuasion Pyramid into test queues. Eisenberg's hierarchy (Functional → Accessible → Usable → Intuitive → Persuasive) maps directly onto Goward's test sequencing logic: fix the lower layers before testing persuasion variables. Combined: Eisenberg diagnoses the layer; Goward determines whether to fix or test at that layer and estimates the revenue impact that governs prioritization."
gigerenzer_integration:
  feeds_from: [gigerenzer-field-intelligence]
  feeds_to: [gigerenzer-fast-frugal-auditor]
  shared_data: "Gigerenzer's fast-and-frugal heuristics explain why Methodical and Competitive buyers (two of four Eisenberg modalities) reject complex pages even when those pages contain all needed information. The heuristic mind uses one or two cues and stops — not six. Eisenberg's modality design must align with the decision heuristics dominant in each quadrant. Combined: for Competitive buyers, Eisenberg says 'provide superlatives with proof'; Gigerenzer says 'make one proof cue dominant so the Take-the-Best heuristic fires immediately.'"
laja_integration:
  feeds_from: [laja-field-intelligence]
  feeds_to: [laja-conversion-research-synthesizer]
  shared_data: "Laja's qualitative conversion research (user interviews, session recordings, heatmaps) surfaces the specific objections, confusions, and desire language that populates each Eisenberg modality pathway. Eisenberg builds the architecture; Laja fills it with the visitor's actual words. Combined: Laja's voice-of-customer data is the raw material for scent-signal selection, modality-specific headline variants, and Trinity body copy. Without Laja, Eisenberg's framework operates on assumptions; with it, the persuasion architecture speaks the visitor's language."
norman_integration:
  feeds_from: [norman-field-intelligence]
  feeds_to: [norman-affordance-auditor]
  shared_data: "Norman's affordance and feedback principles govern the Usable and Intuitive layers of Eisenberg's Persuasion Pyramid — the two layers that must be resolved before persuasion tactics can operate. Eisenberg tells you the order (Functional → Accessible → Usable → Intuitive → Persuasive); Norman tells you the mechanisms for fixing layers 3 and 4 (clear affordances, feedback loops, mapping). Combined: Norman is the repair manual for Eisenberg layers 3-4."
hick_integration:
  feeds_from: [hick-field-intelligence]
  feeds_to: [hick-choice-reducer]
  shared_data: "Hick's Law (RT = b × log2(n+1)) quantifies the decision-time cost of every choice set on a page. Eisenberg's four modalities have different Hick tolerances: Spontaneous buyers are maximally harmed by high choice counts (Hick adds delay when they want instant friction-free action); Methodical buyers can process more options but need them organized. Combined: each modality pathway gets a different Hick budget. The micro-action sequence for Spontaneous buyers must minimize n at every step; Methodical pathways can widen option sets if organized by decision-relevant taxonomy."
nielsen_integration:
  feeds_from: [nielsen-field-intelligence]
  feeds_to: [nielsen-usability-heuristic-auditor]
  shared_data: "Nielsen's 10 usability heuristics audit the Usable layer of Eisenberg's Persuasion Pyramid before persuasion optimization begins. Nielsen's visibility-of-system-status, error prevention, and recognition-over-recall heuristics are the specific failure modes that suppress conversion before the Trinity can operate. Combined: run Nielsen's heuristic evaluation first; any violation at Usable layer is a pre-persuasion fix that blocks Eisenberg Trinity work."
eyal_integration:
  feeds_from: [eyal-field-intelligence]
  feeds_to: [eyal-hook-cycle-designer]
  shared_data: "Eyal's Hook Model (Trigger → Action → Variable Reward → Investment) maps onto Eisenberg's conversion sequence in a recurring-engagement context. The Trigger is Eisenberg's scent signal from an email or retargeting ad; the Action is the micro-action sequence; the Variable Reward is the Spontaneous modality's emotional payoff; the Investment is the Humanistic modality's relationship deepening. Combined: for multi-visit funnels, Eisenberg architects the pathway within each visit; Eyal architects the return-visit loop between visits."
brignull_integration:
  feeds_from: [brignull-field-intelligence]
  feeds_to: [brignull-dark-pattern-scanner]
  shared_data: "Brignull's dark patterns taxonomy is the audit that verifies Eisenberg's persuasion architecture is ethical. Methodical buyers specifically detect and punish dark patterns (bait-and-switch, hidden costs, confirmshaming) — these patterns break the Conversion Trinity's Relevance and CTA Confidence questions for the modality most likely to have read the fine print. Combined: Brignull scans for dark patterns before Eisenberg Trinity work is presented; any detected pattern is flagged as a Methodical-buyer conversion killer and a legal/reputational risk."
fogg_integration:
  feeds_from: [fogg-field-intelligence]
  feeds_to: [fogg-prompt-designer]
  shared_data: "Fogg's B=MAP (Behavior = Motivation × Ability × Prompt) maps onto the Conversion Trinity at the page level. Relevance controls Motivation (does this visitor feel this page is FOR them?); Usable/Intuitive layers control Ability (can they act without friction?); the CTA is the Prompt (is it placed at a moment of sufficient M×A?). Combined: Fogg diagnoses WHY a Trinity element is failing in mechanistic terms. If CTA is failing, Fogg determines whether it is a prompt-timing failure, an ability barrier, or a motivation deficit — each has a different fix."
cialdini_integration:
  feeds_from: [cialdini-field-intelligence]
  feeds_to: [cialdini-ethical-influence-architect]
  shared_data: "Cialdini's six principles are the persuasion fuel inside Eisenberg's Trinity Value and CTA Confidence stages. Social proof supplies modality-matched credibility (logos for Competitive, testimonials for Humanistic, case studies for Methodical, fast-adopter signals for Spontaneous). Scarcity powers Spontaneous urgency. Authority powers Methodical trust. Commitment/consistency powers Humanistic identity alignment. Combined: Eisenberg's modality classifier outputs the required Cialdini mix; each modality has a ranked hierarchy of which principles apply and in what order."
kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: [kahneman-prospect-theory-architect]
  shared_data: "Kahneman's System 1/System 2 and Prospect Theory explain the cognitive substrate of Eisenberg's buying modalities. Spontaneous (fast+emotional) and Humanistic (slow+emotional) buyers operate primarily in System 1; Methodical (slow+logical) and Competitive (fast+logical) buyers engage System 2 more readily but still have System 1 defaults. Loss aversion applies to CTA confidence: the perceived risk of clicking is a loss-frame that must be counteracted by Trinity Value before the CTA fires. Combined: Eisenberg's modality design + Kahneman's framing theory produces the specific loss/gain language per modality."
thaler_integration:
  feeds_from: [thaler-field-intelligence]
  feeds_to: [thaler-nudge-auditor]
  shared_data: "Thaler's choice architecture (defaults, mental accounting, NUDGE) interacts with Eisenberg's Conversion Trinity at the CTA stage. Default-opt framing (pre-checked boxes, pre-selected plans) reduces CTA friction for Spontaneous and Humanistic buyers. Mental accounting shapes how the Value stage presents price — Methodical buyers need unbundled line-item value; Spontaneous buyers need a single integrated transaction. Combined: Thaler architects the choice set; Eisenberg architects the persuasion pathway into that choice set."
iyengar_integration:
  feeds_from: [iyengar-choice-set-auditor]
  feeds_to: [iyengar-tier-calibrator]
  shared_data: "Iyengar's paradox of choice research (more options reduce conversion) intersects Eisenberg's modality design at a critical junction: Methodical buyers want options but suffer from too many; Spontaneous buyers need one clear path. Combined: Iyengar determines the optimal choice count per modality (typically 3-4 for Methodical, 1-2 for Spontaneous); Eisenberg's persona pathways deliver each modality to the correctly-sized choice set."
---

# Eisenberg Field Intelligence

---

## LAYER 1: INVARIANTS (Never override.)

1. **Synthesis not summary.** This skill does not recap what individual skills found. It identifies PATTERNS across the 6 skill outputs — convergence zones, contradictions, amplification opportunities, and the single highest-leverage page change. If the output reads like a summary of six reports, it has failed.

2. **Convergence detection is mandatory.** When 3+ individual Eisenberg skills point at the same page problem or intervention: that is a convergence zone. Convergence zones are highest-confidence findings. Every zone must be explicitly named.

3. **Contradictions must be surfaced, not hidden.** When one skill recommends X and another recommends the opposite, this is signal, not noise — it reveals where modality-specific design requirements conflict. Resolve by determining which modality is the primary revenue driver and designing for that modality first.

4. **The Single Move is non-negotiable.** Every Field Intelligence briefing produces exactly ONE recommended page change — the change that addresses the most convergence zones. Not a list. Not options. ONE move, actionable this week.

5. **The Mirror is non-negotiable.** Examine the business's own persuasion architecture biases — which buying modality the team's design instincts favor, where their personal modality is distorting page decisions for the audience's actual dominant modality.

6. **Cross-system intelligence is the highest-value section.** When Eisenberg's scent + modality + Trinity findings interact with other Click Architects — that intersection produces insights no single skill can generate.

7. **Freshness gate: 45 days.** Flag any individual Eisenberg skill output older than 45 days as potentially stale. Scent maps expire when ad creative rotates.

---

## LAYER 2: QUALITY GUIDANCE

8. **Name the convergence zones.** Give each a label capturing the insight (e.g., "The Scent Break at the Fold," "The Methodical Desert," "The Spontaneous Squeeze").

9. **Quantify where possible.** Tie convergence zones to estimated impact on conversion rate. A scent break at the landing page headline typically suppresses 20-40% of click-throughs before the body copy is read.

10. **The 90-Day Projection must be specific.** Not "conversion should improve." Instead: "If The Single Move (headline scent match) is implemented by week 1, click-through-to-conversion should shift from X% to Y% by day 30, and cost per acquisition should fall by Z% by day 90."

---

## PURPOSE

The brag: "Our ad and our page tell one unbroken story — scent never breaks."

Individual Eisenberg skills each diagnose one dimension of conversion failure. Persona Pathway Mapper reveals which buying modality is unserved. Scent Continuity Auditor traces the scent chain from ad to CTA. Landing Anatomy Architect maps the page against the Conversion Trinity. Buying Modality Classifier identifies the dominant visitor temperament and its non-negotiable requirements. Conversion Trinity Builder produces the specific relevance/value/CTA elements for each modality. Micro-action Sequencer designs the click path from entry to desired action.

Field Intelligence goes one level beyond. It finds convergence zones across all six analyses, detects contradictions that reveal competing design pressures, identifies where cross-skill amplification produces outsized conversion gains, delivers The Single Move, holds up The Mirror to the business, and integrates Eisenberg's Persuasion Architecture with every other Click Architect thinker in the network. Output is not six diagnoses stapled together — it is conversion intelligence that sees the whole page system at once.

---

## INPUT REQUIREMENTS

**Required:** Outputs from at least 4 of 6 individual Eisenberg skill analyses, all run on the same page (URL, screenshot, or written description) with the same stated desired action.

**Optimal:** All 6 Eisenberg skill outputs + Field Intelligence from other Click Architects (Pirolli, Kohavi, Fitts, Goward, Laja, Norman, Nielsen, Hick, Fogg, Cialdini, Kahneman, Thaler, Iyengar).

**Required metadata per skill output:**
- Skill name and run date
- Page URL or identifier
- Desired action analyzed
- Top 3 findings
- Recommendations made

---

## EXECUTION PROCESS

### Step 1: Component Synthesis

For each available Eisenberg skill output, extract:

| Field | Content |
|-------|---------|
| Skill | Name + date |
| Age | Current (≤45d) / Aging (45-60d) / Stale (>60d) |
| Top finds | 3 highest-signal conclusions |
| Recs | Specific changes recommended |
| Confidence | High / Medium / Low (based on data quality) |

### Step 2: Convergence Detection

Cross-skill pattern matching — score by number of skills converging on the same finding:

- 2 skills: Notable alignment
- 3 skills: Convergence zone (name it)
- 4-5 skills: Strong convergence
- 6 skills: Critical convergence (act first)

**Eisenberg-specific convergence patterns to watch for:**

- *The Scent Break* — Scent Auditor + Anatomy Architect + Modality Classifier all flag a disconnect between traffic-source language and page headline
- *The Modality Desert* — Pathway Mapper + Trinity Builder + Micro-action Sequencer agree the dominant buying modality is unserved above the fold
- *The Trinity Collapse* — Anatomy Architect + Trinity Builder both find the same Trinity element (Relevance, Value, or CTA) failing for 2+ modalities
- *The CTA Confidence Gap* — Trinity Builder + Micro-action Sequencer + Anatomy Architect converge on CTA confidence as the primary suppressor
- *The Persuasion Pyramid Bypass* — Anatomy Architect + Scent Auditor + Modality Classifier all find persuasion work happening on top of unresolved Usable or Functional failures

For each named convergence zone, state:
- Which skills contribute
- What each found (specific finding, not a paraphrase)
- System-level implication
- Implied single intervention

### Step 3: Contradiction Detection

**Common Eisenberg contradiction patterns:**

- Scent Auditor says tighten headline to ad keywords ↔ Modality Classifier says dominant modality is Humanistic (emotional, slow) and keyword-matched headlines read as mechanical/cold to that modality
- Trinity Builder says lead with Value ↔ Anatomy Architect says Relevance is failing (Value cannot operate until Relevance is established — Trinity sequence is strict)
- Micro-action Sequencer says compress steps ↔ Pathway Mapper says Methodical pathway requires checkpoints with proof at each gate
- Buying Modality Classifier says page needs urgency (Spontaneous) ↔ Trinity Builder finds CTA confidence is failing (urgency accelerates abandonment when confidence is low)
- Landing Anatomy Architect says add proof ↔ Scent Auditor says current proof elements break scent by introducing a new brand name/product frame not established in the ad

For each contradiction:
- The tension
- Why both skills are correct in their own frame
- Resolution based on which modality generates primary revenue
- Implementation that honors the deeper insight from both

### Step 4: Amplification Opportunities

Where combining interventions creates outsized conversion impact:

- Scent-matched headline (Scent Auditor) + dominant-modality opening (Modality Classifier) + Relevance-confirming image alt text (Anatomy Architect) = triple-secured above-fold relevance
- Methodical pathway (Pathway Mapper) + comparison table with named proof (Trinity Builder) + low-friction form with field reduction (Micro-action Sequencer) = self-qualifying Methodical buyer at maximum readiness
- Spontaneous buyer scent (urgency + visual dynamism) + single-field form at fold + zero-step CTA sequence (Micro-action Sequencer) = compression of Spontaneous decision from 4 clicks to 1
- Pre-mortem pass (Buyer Legends process) across the Humanistic pathway + testimonials placed at each identified doubt point + social-impact CTA language = Humanistic conversion sequence with every objection pre-answered

### Step 5: The Single Move

ONE page change addressing the most convergence zones:

- **What:** The specific change, stated as a concrete page edit
- **Why this move:** Which convergence zones it directly addresses
- **Mechanism:** Which element of the Conversion Trinity or Persuasion Architecture it repairs, and how
- **Implementation steps:** Numbered, sequential, specific (e.g., "Replace headline 'Welcome to X' with the exact trigger phrase from the Google ad: 'Finally, Y without Z'")
- **Before/After example:** Worked miniature illustrating the change
  - Before: "Get Started Today" (generic, no scent, no modality match)
  - After: "Get the [specific outcome from ad] in [timeframe]" (scent-matched, Spontaneous-targeted, Trinity Relevance confirmed)
- **Expected outcome:** Specific metric shift predicted (e.g., "Scent match at headline reduces above-fold bounce by estimated 15-25% based on Eisenberg's documented scent-break research")
- **What it does NOT address:** Honest about remaining gaps

### Step 6: The Mirror

Where the business's own Persuasion Architecture biases distort page decisions:

- **Designer modality projection:** The team's dominant buying modality shapes every page they build. A Methodical design team builds for Methodical buyers — data-dense, proof-heavy, long-form — while the actual audience is 35% Spontaneous. Identify the team's implicit modality from the current page design.
- **Scent blind spot:** Pages are designed by people who never see the ad. The person writing the landing page has never experienced arriving from the ad. This structural disconnect produces scent breaks no one inside the business can see.
- **Trinity sequence inversion:** Teams default to CTA optimization (button color, button text) before establishing Relevance and Value — skipping the mandatory Trinity sequence. The result is optimized CTAs on pages that haven't yet answered "why is this for me?"
- **Persuasion Pyramid bypass:** The most common internal error — investing in persuasion copy on a page with unresolved Usable-layer friction. The business hires a copywriter before fixing a confusing navigation. Eisenberg's hierarchy is strict; persuasion work on a Functional/Usable failure is wasted.
- **Proof type mismatch:** The business produces the proof it is proud of (awards, press logos) rather than the proof the dominant modality requires (Methodical needs data; Humanistic needs real-person stories; Competitive needs comparative rankings; Spontaneous needs social momentum signals).

### Step 7: Cross-System Intelligence

Synthesize Eisenberg findings with available Click Architect outputs. For each available system:

**Eisenberg × Pirolli:** Pirolli's foraging model quantifies the scent-strength threshold below which visitors abandon. Eisenberg's scent prescriptions gain a measurable proxy: if information gain per click falls below the cost of clicking (Pirolli), the scent is too weak regardless of keyword match. Combined finding: identify the weakest scent link in the pathway by estimating information gain vs. click cost at each step.

**Eisenberg × Kohavi:** Eisenberg generates directional hypotheses (which Trinity element, which modality, which scent signal to fix). Kohavi determines whether those hypotheses are tested or assumed. Every convergence zone is a pre-registered test hypothesis. The Single Move is the first test in the queue — not the confirmed fix.

**Eisenberg × Fitts + Hick:** Total click cost = Fitts motor time (CTA size and distance) + Hick decision time (number of competing options) + Trinity confidence gap (persuasive barrier to clicking). A CTA that fails any one element suppresses conversion. Eisenberg diagnoses the confidence gap; Fitts and Hick diagnose the physical and cognitive costs. All three must be resolved for the CTA to convert at maximum rate.

**Eisenberg × Goward:** Goward's test sequencing logic maps directly onto Eisenberg's Persuasion Pyramid. Goward's revenue-impact scoring determines which Eisenberg layer to fix first when multiple layers are failing simultaneously. The hierarchy is Eisenberg's; the prioritization formula is Goward's.

**Eisenberg × Gigerenzer:** Gigerenzer reveals that Competitive buyers (the modality Eisenberg says needs comparative proof) use fast-and-frugal heuristics — one dominant cue, then stop. The Competitive buyer does not read the comparison chart; they read the dominant headline superlative and decide. Design for the heuristic, not the chart.

**Eisenberg × Laja:** Laja's voice-of-customer research populates Eisenberg's modality pathways with the visitor's actual language. Without Laja, Eisenberg's scent signals are assumed. With Laja, the headline scent match uses the visitor's own words, producing scent that is both structurally correct and linguistically native.

**Eisenberg × Norman:** Norman's affordance and feedback principles are the repair manual for Eisenberg's Usable and Intuitive Pyramid layers. When those layers fail, the Norman audit identifies the specific affordance breakdown — and fixing it is the prerequisite for any Trinity or modality work to operate.

**Eisenberg × Hick:** Hick's Law gives each Eisenberg modality pathway a decision-time budget. Spontaneous pathway: minimize n (reduce choices to 1-2). Methodical pathway: organize n (structure many options into clear taxonomies). Competitive pathway: rank n (offer a clear winner with ranked alternatives). Humanistic pathway: personalize n (offer a curated set that feels chosen, not generic).

**Eisenberg × Nielsen:** Nielsen's heuristic evaluation catches Usable-layer violations before Eisenberg Trinity work begins. Particularly: error prevention (broken forms break CTA confidence), recognition-over-recall (navigation should not require memory), and consistency (scent breaks are sometimes Nielsen consistency violations).

**Eisenberg × Eyal:** For multi-visit funnels, Eisenberg architects the conversion sequence within each visit; Eyal architects the return-trigger between visits. The Trigger in Eyal's Hook is the scent-bearing email or retargeting ad; it must maintain Eisenberg scent to the landing page.

**Eisenberg × Brignull:** Brignull's dark patterns are Methodical-buyer conversion killers and Trinity Confidence destroyers. Confirmshaming and hidden costs are detected by the modality most likely to complete the Trinity Value evaluation fully — and then abandon permanently when they discover the deception.

**Eisenberg × Fogg:** Fogg's B=MAP diagnoses WHY a Trinity element fails mechanistically. CTA failing? Fogg determines if it is prompt timing (CTA appears before M×A peak), ability barrier (form friction), or motivation deficit (Value stage failed). Each diagnosis has a distinct fix; without Fogg, Trinity diagnosis is directional only.

**Eisenberg × Cialdini:** Each Eisenberg buying modality has a ranked Cialdini mix. Competitive: Authority (dominant) + Social Proof with named sources. Methodical: Authority + Commitment/Consistency + documented Social Proof. Spontaneous: Scarcity + Liking + rapid Social Proof (volume signals). Humanistic: Liking + Social Proof (real people) + Reciprocity (mission alignment). The modality classifier output determines which Cialdini principles are applied and in which position on the page.

**Eisenberg × Kahneman:** System 1/System 2 maps onto buying modalities. Spontaneous and Humanistic operate primarily in System 1 — framing, imagery, and emotional register drive their conversion. Methodical and Competitive engage System 2 — but Kahneman shows they still have System 1 defaults that determine whether they engage System 2 at all. The above-fold image and headline must pass System 1 before System 2 begins evaluating proof.

**Eisenberg × Thaler:** Thaler's mental accounting shapes how Value is presented per modality. Methodical buyers need disaggregated value (line-item benefits, explicit feature-to-cost mapping). Spontaneous buyers need integrated transactions (one price, one decision, instant outcome). Thaler's default effects — pre-selected options, pre-checked fields — reduce CTA friction for Spontaneous and Humanistic buyers.

**Eisenberg × Iyengar:** Iyengar's paradox of choice calibrates the option count per modality pathway. Spontaneous: 1-2 options maximum. Methodical: 3-4 organized options. Competitive: 2-3 with a ranked winner clearly marked. Humanistic: 2-3 with the curated "recommended" option prominently positioned. The Micro-action Sequencer output sets the option architecture; Iyengar determines the maximum count before conversion suppression begins.

**Cross-system convergence:** The highest-confidence finding emerges when 3+ systems agree. Example: Scent Auditor (Eisenberg) + Pirolli scent strength + Laja voice-of-customer + Kohavi test history all converge on the above-fold headline as the single largest conversion lever. That four-system convergence outranks any single-system finding.

### Step 8: Coherence Map

Score the page's persuasion architecture coherence:

| Dimension | Score (1-10) | What would raise it |
|-----------|-------------|---------------------|
| Internal — do all 6 Eisenberg diagnoses align? | [score] | [gap] |
| Modality — is the dominant modality served first? | [score] | [gap] |
| Scent — is the chain unbroken ad-to-CTA? | [score] | [gap] |
| Trinity — are all 3 questions answered in sequence? | [score] | [gap] |
| Cross-system — does the architecture align with Fitts, Hick, Fogg, Cialdini? | [score] | [gap] |

Coherence total: [sum/50]. Below 35: critical intervention required before any variable testing. 35-42: The Single Move is the priority. Above 42: optimize for secondary modality pathway.

### Step 9: 90-Day Conversion Projection

**Days 1-30:** Implement The Single Move. Expected early signal: above-fold bounce rate decline within 7 days of scent match. If bounce rate has not moved by day 14, the traffic source mix has shifted and modality re-classification is required.

**Days 31-60:** Secondary modality pathway activated. If the dominant modality conversion has stabilized at the new rate, begin serving the second-largest modality segment. Expect incremental conversion rate lift of 8-15% from secondary pathway activation.

**Days 61-90:** Full Persuasion Architecture operating. All modality pathways live, Trinity validated for each, scent maintained from each traffic source. Conversion rate should be at a new stable baseline. The next bottleneck identified is typically in the post-conversion sequence (Eyal hook) or the traffic-source modality mix shift (Kohavi validates).

---

## OUTPUT STRUCTURE

### Persuasion Architecture Intelligence Briefing

**Section 1: Input Status and Freshness**
All 6 Eisenberg skill outputs with freshness assessment. Flag any stale output.

**Section 2: Convergence Map**
Named convergence zones with contributing skills, specific findings, and implied intervention.

**Section 3: Contradiction Analysis**
Resolved tensions between competing Eisenberg skill recommendations.

**Section 4: Amplification Opportunities**
Combined interventions producing outsized conversion impact.

**Section 5: The Single Move**
One page change with before/after example, mechanism, implementation steps, and metric prediction.

**Section 6: The Mirror**
Business's own Persuasion Architecture biases examined.

**Section 7: Cross-System Intelligence**
Interactions with all available Click Architect thinker systems.

**Section 8: Coherence Map**
Scored table — Internal, Modality, Scent, Trinity, Cross-system — with gap analysis.

**Section 9: 90-Day Conversion Projection**
Specific predictions at 30/60/90-day milestones with decision triggers.

---

## WORKED MINI-EXAMPLE

**Page:** B2B SaaS project management tool. Desired action: start free trial. Traffic from Google paid search ("project management software for agencies") + warm email list.

**Inputs available:** 5 of 6 Eisenberg skill outputs (all except eisenberg-persona-pathway-mapper).

**Step 1 — Component synthesis (abbreviated):**

| Skill | Age | Top Finding | Confidence |
|-------|-----|-------------|------------|
| Scent Auditor | 3d | Headline "Work Smarter" scores 1/10 vs. ad trigger "stop missing deadlines" | High |
| Anatomy Architect | 3d | Methodical dominant; Relevance zone FAIL; Value zone FAIL (no data above fold) | High |
| Modality Classifier | 3d | Methodical primary (67% comparison-page engagement); Spontaneous secondary (30%) | High |
| Trinity Builder | 3d | R=2, V=4, CTA=5; scent break suppresses all Trinity work | High |
| Micro-action Sequencer | 3d | Scent FAIL at entry; Spontaneous ladder collapses at step 1 (no emotional hook) | High |

**Step 2 — Convergence zones:**

*The Scent Break at the Fold* (5/5 skills converge): Every skill independently identified the headline-to-ad disconnect as the primary conversion suppressor. Mechanism: visitor arrives expecting "stop missing deadlines" content; page serves "Work Smarter" (unrelated frame). System 1 registers mismatch; bounce decision made within 3 seconds before any persuasion element is read.

*The Methodical Desert* (3/5 skills): Anatomy Architect, Modality Classifier, and Trinity Builder all confirm Methodical buyers (67% of qualifying traffic) encounter zero hard data above the fold. The modality requires proof before CTA; page serves no proof until scroll depth 3.

**Step 3 — Contradiction:**

Scent Auditor says match ad headline verbatim ("stop missing deadlines") — fear/urgency register. Trinity Builder says dominant modality is Methodical — urgency language suppresses Methodical trust. Resolution: headline echoes the trigger phrase's OUTCOME ("Fewer missed deadlines" or "Deadlines hit 43% more reliably") rather than its pain register — satisfies scent mechanics AND Methodical logical frame simultaneously.

**Step 4 — Amplification opportunity:**

Scent-matched outcome headline (Scent Auditor) + "43% fewer missed deadlines — verified in 8,200 teams" (Anatomy/Methodical proof) + CTA "See the data — start free" (Trinity Builder) = above-fold zone that satisfies scent, modality, and all three Trinity gates in one coherent unit. Three fixes, one above-fold rewrite.

**Step 5 — The Single Move:**

Replace the above-fold headline, hero subhead, and CTA as a single Relevance unit.

- Before: "Work Smarter. Move Faster. Do More." / CTA: "Get Started"
- After: "43% fewer missed deadlines — start free, see your team's data in 8 minutes." / CTA: "See the data — start free"
- Mechanism: Scent restored (trigger outcome echoed) + Methodical proof delivered at fold + Spontaneous hook ("8 minutes") serves secondary modality without contradicting primary.
- Expected outcome: Above-fold bounce rate decline within 7 days; conversion rate from paid search segment should shift from estimated 1.2% toward 3-4% (Eisenberg benchmark: scent fix alone averages 20-35% CR lift on broken segments).

**Step 8 — Coherence Map:**

| Dimension | Score | Gap |
|-----------|-------|-----|
| Internal (6 skills align?) | 4/10 | Scent break invalidates all other work |
| Modality (dominant served first?) | 2/10 | Methodical gets zero proof above fold |
| Scent (unbroken ad-to-CTA?) | 1/10 | Critical break at headline |
| Trinity (all 3 gates answered?) | 3/10 | Relevance fails; blocks Value and CTA |
| Cross-system (Fitts, Fogg, Cialdini?) | 5/10 | CTA button passes Fitts; Fogg prompt timing wrong |

Coherence total: 15/50. Critical intervention required before variable testing.

---

## OUTPUT FILE

Save complete briefing to:
`[project-folder]/Eisenberg - Field Intelligence/[YYYY-MM] - Persuasion Architecture Intelligence Briefing.md`
