---
name: laja-voice-of-customer-miner
description: Use when you have raw surveys, reviews, or chat logs and need the exact words and objections that belong on the page — mines VoC for copy, not for insights reports.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peep Laja (CXL Institute / Wynter, 2014–2022; ResearchXL Model Spoke 4 — Qualitative Research) — Click Architecture (Skill 4 of 7)"
interface:
  invoke: "/laja-voice-of-customer-miner"
  calls: []
  called_by: [user, laja-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Market language, objection language, and dominant pain framing shift with competitive context — VoC copy older than 45 days may reflect a problem environment the page no longer faces."

laja_researchxl_integration:
  feeds_from: laja-researchxl-diagnostic
  feeds_to: laja-heuristic-walkthrough
  shared_data: "ResearchXL Spoke 4 (qualitative) output feeds into Spoke 1 (heuristic) headline and anxiety audits; use VoC verbatims to stress-test whether the heuristic walk-through's clarity rating matches what actual visitors were confused about."

laja_friction_integration:
  feeds_from: laja-friction-telemetry-reader
  feeds_to: laja-friction-telemetry-reader
  shared_data: "Friction telemetry (session replays, rage clicks) identifies WHERE users abandon; VoC mining surfaces WHY they almost did not convert — triangulate both before writing a copy hypothesis."

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: kahneman-framing-engineer
  shared_data: "VoC surfaces the reference point and loss frame the prospect is already using (System 1 language). Feed verbatims to kahneman-framing-engineer to match the page's before/after framing to the prospect's own words."
---

# Laja — Voice-of-Customer Miner

## LAYER 1: INVARIANTS (Never override.)

1. Open-ended only. ResearchXL Spoke 4 requires open-ended questions — no multiple choice, no rating scales in collection. Multiple choice bakes in your assumptions and suppresses the exact language you need.
2. Minimum viable corpus: 100 survey responses OR 50 post-purchase interviews OR 200 public reviews before drawing copy conclusions. Below threshold = directional signal, not page copy.
3. Verbatim over paraphrase. Every phrase surfaced for on-page use must be a direct quote or a minimal-edit composite. Paraphrased summaries destroy the conversion value — the goal is their words on the page, not a clean summary of their words.
4. Objection source = most valuable output. The ResearchXL survey questions "What was your biggest hesitation before buying?" and "What almost stopped you from buying?" are the primary extraction targets. These feed anxiety reduction (the A term in C = 4M + 3V + 2(I-F) - 2A).
5. Page action governs which verbatims matter. Every mined phrase must be evaluated against the ONE desired action this page must produce. Pain language relevant to awareness-stage content is noise on a checkout page.
6. Do not fix messaging before fixing messaging hierarchy. If VoC reveals a clarity problem (visitors do not understand what the product is), that is a positioning problem, not a copywriting problem. Flag it and route up — do not paper over it with new headline copy.
7. Message scent check required. For each verbatim flagged for headline or hero use: verify it matches the language in the ad, email, or channel that drives traffic to this page. Scent break = the verbatim is wrong for this page even if it is true.

## LAYER 2: QUALITY GUIDANCE

1. Tag every verbatim by B2B Message Layer (Clarity / Relevance / Value / Differentiation) before placement. A verbatim that solves a Clarity problem does not belong in the Differentiation section and vice versa.
2. Score each candidate phrase for PXL impact: above-the-fold placement + noticeable within 5 seconds = 3 bonus points toward implementation priority. Surface-level phrases with no placement context are low value.
3. Separate "just do it" fixes (missing anxiety reducer, absent trust signal, broken scent) from A/B test candidates. Verbatims that directly answer "What almost stopped you?" go live as FAQ or objection-handling copy immediately — no test required when the problem is unambiguous.
4. Track source type per verbatim: survey / review / chat / interview / user test. ResearchXL treats each as a separate research spoke; verbatims corroborated across multiple sources carry higher implementation confidence.
5. Flag any verbatim that references a competitor by name or feature. These become differentiation copy candidates and must cross-reference the B2B Message Layers Framework Layer 4 (Differentiation).

## PURPOSE

This skill executes ResearchXL Model Spoke 4 (Qualitative Research) directly on the page conversion problem. It mines surveys, reviews, and chat transcripts for the verbatim language that replaces assumed copy with real prospect language — then maps each phrase to the exact page location and B2B Message Layer where it reduces the conversion formula's anxiety term or raises the value coefficient.

Brag line: "We find the real leak with 6 research lenses before we touch the page."

Most pages fail at Clarity and Relevance (Layers 1 and 2) before differentiation ever matters. VoC mining answers: what words were prospects already using before they arrived, and what almost made them leave? Those are the words the page must say back.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description of the page under audit
- The ONE desired action: click / opt-in / purchase / next-step (be explicit — mining priorities shift by funnel position)
- VoC corpus: one or more of — survey export (CSV/text), review set (Amazon, G2, Trustpilot, Yelp), chat transcript batch, post-purchase interview transcripts

**Optional but high-value:**
- Analytics funnel data showing which step precedes this page (frames which objections are most load-bearing)
- Ad or email copy driving traffic (required for message scent verification)
- Audience role/title (B2B: what metrics is this buyer measured on — feeds Relevance layer)
- Existing page copy (for before/after contrast)
- Competitor page URLs (for differentiation gap analysis)

## EXECUTION PROCESS

**Step 1 — Corpus triage (5 min)**

Before reading a single verbatim, classify the corpus by source type and count:

| Source | Count | Threshold | Confidence |
|--------|-------|-----------|------------|
| Post-purchase surveys | # | 100+ | High |
| Post-signup polls | # | 100+ | High |
| Public reviews | # | 200+ | Medium |
| Chat/support logs | # | 50+ sessions | Medium |
| User test sessions | # | 5–15 | High (qualitative) |

If below threshold: flag as directional, proceed with lower confidence, note in output.

**Step 2 — Extract objection language (primary pass)**

Search the corpus specifically for responses to:
- "What was your biggest hesitation before signing up / buying?"
- "What almost stopped you from purchasing?"
- "What questions did you have that were not answered?"
- Any negative-valence language in reviews (1–3 star content is the highest-density objection mine)

Collect verbatims in raw form. Do not edit. Tag each: [OBJECTION], [CONFUSION], [ANXIETY], [COMPETITOR].

Threshold for inclusion: a phrase or concern appears in >=3 independent responses = page-level pattern. Below 3 = individual signal, note but do not elevate to copy.

**Step 3 — Extract value/desire language (secondary pass)**

Search for responses to:
- "Why did you ultimately decide to buy / sign up?"
- "What made you choose us over alternatives?"
- "What result were you most hoping for?"
- Highest-rated positive review language (4–5 star, but focus on specific outcome claims, not generic praise)

Tag each: [VALUE], [OUTCOME], [DIFFERENTIATOR]. Flag any phrase that contains a specific metric or named result (these become headline candidates).

**Step 4 — Tag by B2B Message Layer**

For every verbatim in the working set, assign one primary layer:

- L1-CLARITY: "I wasn't sure what this actually was" / "I didn't understand how it worked"
- L2-RELEVANCE: "This sounded like it was for bigger companies, not us" / "I recognized my exact problem"
- L3-VALUE: "I could see exactly how this would change my [metric]" / "The result was concrete"
- L4-DIFFERENTIATION: "Unlike [competitor], this actually [specific thing]"

Rule: if 20%+ of verbatims cluster at L1-CLARITY, that is a positioning problem. Do not write new copy — flag for messaging hierarchy review before proceeding.

**Step 5 — Map verbatims to page locations**

For each verbatim tagged [OBJECTION] or [ANXIETY]: identify the page section where that objection is most likely to surface during the visitor's read path. Standard mapping:

| Objection type | Page location |
|----------------|--------------|
| "What is this?" | Hero headline / subhead |
| "Is this for me?" | Hero subhead / who-it's-for section |
| "Will it work for my situation?" | Social proof / case study selection |
| "What if it doesn't work?" | Guarantee / risk-reversal block |
| "I can't afford it" | Pricing framing / payment options |
| "I need to think about it" | FAQ / urgency / next-step clarity |
| "I don't trust this site" | Trust seals / security signals / about section |

For each verbatim tagged [VALUE] or [OUTCOME]: flag for headline, hero subhead, or benefit bullet placement. Prioritize phrases with specific metrics or named before/after states.

**Step 6 — Message scent verification**

Pull the ad or email copy driving traffic to this page. For every verbatim flagged for above-the-fold placement: confirm the key noun phrase, pain word, or promise word appears in both the traffic source and the page. If not: the verbatim may be true but creates scent break — mark [SCENT-RISK], do not place above fold without revising the traffic source too.

**Step 7 — Prioritize using PXL signal**

For each copy change the verbatim implies, score PXL impact:
- Above the fold? +1
- Noticeable in 5 seconds? +2
- Addresses issue found in user testing? +1
- Addresses issue found in qualitative feedback (this source)? +1
- High-traffic page? +1

Changes scoring 4+ = run first. Changes scoring 1–3 = queue after. Changes scoring 0 = log but defer.

**Step 8 — Conversion formula check**

Apply C = 4M + 3V + 2(I-F) - 2A:

Categorize each verbatim-driven change by which term it affects:
- V (value clarity, coefficient 3): new headline, value proposition, specific outcome language
- A (anxiety, coefficient 2, negative): objection handling, trust signals, risk reversal
- F (friction, coefficient 2, negative): form simplification, step reduction, jargon removal
- I (incentive): urgency, bonus, scarcity

Surface the V-changes and A-changes first — they carry the highest leverage. Do not lead with I-changes; these have the lowest coefficient and mask the real problem.

## OUTPUT STRUCTURE

**1. Corpus Audit**
Source types, counts, threshold status, confidence level.

**2. Top Objections (Verbatim)**
Exact quotes, frequency count, B2B Message Layer tag, page location mapping. Minimum 5, maximum 15.

**3. Top Value Phrases (Verbatim)**
Exact quotes with outcome specificity rating (generic praise vs. specific metric). Placement recommendation.

**4. Message Scent Assessment**
Traffic source language vs. page language — match / gap / risk per verbatim.

**5. Copy Insertions (Ready to Place)**
Verbatim or minimal-edit phrases formatted for their specific page location. Each labeled: location / layer / PXL score / conversion formula term.

**6. Positioning Flag (if triggered)**
If L1-CLARITY objections exceed 20%: explicit flag that this is a messaging hierarchy problem, not a copy problem. No copy insertions in this case — escalate to positioning review.

**7. "Just Do It" Fixes**
Unambiguous anxiety reducers with no A/B test required. List with specific placement.

**8. A/B Test Candidates**
Copy changes that are behavioral hypotheses requiring traffic to validate. One sentence per hypothesis.

## WORKED MINI-EXAMPLE

**Page:** SaaS tool landing page, desired action = start free trial

**VoC source:** 140 post-trial-cancellation surveys, question: "What stopped you from upgrading?"

**Raw verbatim clusters (n >= 3):**
- "I couldn't figure out how to connect my existing data" (n=31) — [CONFUSION] [FRICTION] L1-CLARITY
- "I wasn't sure if it worked with Salesforce" (n=19) — [ANXIETY] L2-RELEVANCE
- "The price felt high for a tool I hadn't fully used yet" (n=22) — [OBJECTION] [ANXIETY] L3-VALUE
- "I didn't see any results in the first week" (n=14) — [OBJECTION] L3-VALUE

**Before (existing page copy):**
Hero: "The most powerful analytics platform for growth teams."
FAQ: [none addressing integrations]
Pricing: $299/mo, billed annually.

**After (VoC-driven insertions):**

| Location | Before | After | Layer | PXL | Formula term |
|----------|--------|-------|-------|-----|--------------|
| Hero subhead | "Insights that drive growth" | "Connects to Salesforce in 4 minutes — see your first insight before lunch" | L2 | 5 | V |
| FAQ item 1 | [missing] | "What if I can't get my data in?" + step-by-step answer | L1 | 3 | A |
| Pricing page | "$299/mo" | "$299/mo — or pause anytime; no annual lock-in required" | L3 | 4 | A |
| Onboarding email | [day 3 generic] | "Here's what a result looks like in week 1: [customer example]" | L3 | n/a | V |

Result: hero now passes message scent (ad said "Salesforce analytics"), top objection addressed in FAQ, pricing anxiety reduced without a price change.

## OUTPUT FILE

Save to: [project-folder]/Laja - Click Architecture/[YYYY-MM] - VoC Mining - [Page Name].md
