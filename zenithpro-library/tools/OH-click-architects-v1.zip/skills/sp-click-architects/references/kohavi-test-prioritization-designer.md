---
name: kohavi-test-prioritization-designer
description: Use when a page team has more test ideas than bandwidth — ranks candidates by Expected Value, MDE, and traffic budget so the highest-ROI experiment runs first.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Ronny Kohavi (Trustworthy Online Controlled Experiments 2020; OEC + Seven Rules of Thumb + Experiment Launch Decision Matrix) — Click Architecture (Skill 5 of 7)"
interface:
  invoke: "/kohavi-test-prioritization-designer"
  calls: []
  called_by: [user, kohavi-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic volumes and conversion baselines shift with seasonality, campaigns, and product changes — MDE calculations go stale within one business quarter."

kohavi_oec_integration:
  feeds_from: kohavi-oec-definer
  feeds_to: kohavi-experiment-validity-auditor
  shared_data: "Composite OEC formula (including guardrail bounds) used as the optimization target for every candidate ranked here; practical significance threshold (min δ) set by OEC definer is the denominator for EV scoring."

kohavi_srm_guard_integration:
  feeds_from: kohavi-srm-guard
  feeds_to: kohavi-rollout-decision-architect
  shared_data: "Traffic-split fractions from the prioritization schedule feed directly into SRM Guard's expected-vs-actual allocation table; confirmed-clean splits advance to rollout decision."

iyengar_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: kohavi-rollout-decision-architect
  shared_data: "Choice-reduction hypotheses surfaced by Iyengar Choice Set Auditor (fewer options → higher conversion) are candidate experiments ranked and budgeted here before running."
---

# Kohavi Test Prioritization Designer

## LAYER 1: INVARIANTS (Never override.)

1. **OEC first, test ideas second.** No candidate enters the priority queue until the OEC formula and its practical-significance floor (min δ) are locked. Testing without a pre-defined OEC produces unactionable p-values.
2. **Expected Value = Probability × Impact × Reach.** EV(candidate) = P(real effect) × estimated_δ × daily_affected_users. P(real effect) at p≈0.05 with no prior evidence is ~3.1% (Kohavi Rule 2). With strong prior evidence (e.g., replication of a known pattern), use 20-40%.
3. **70-90% of expert ideas fail to move the OEC.** The priority queue exists precisely because most ideas are wrong; rank ruthlessly, run in series unless traffic budget allows parallel.
4. **Minimum Detectable Effect (MDE) drives sample-size, not intuition.** Pre-commit to the smallest δ worth acting on. MDE = minimum_practical_δ / (z_α/2 + z_β) × σ / √n rearranged: n = 2 × [(z_α/2 + z_β)² × σ²] / δ². Use σ from baseline; use α=0.05, power=0.8 as defaults.
5. **Traffic budget is a hard constraint, not a suggestion.** Total test slots = daily_unique_users × test_duration_days / n_required_per_arm. Never over-commit: each simultaneous experiment consumes a slice of the same users.
6. **Speed is a pre-filter, not a separate test.** Rule 4 (100ms slowdown = −1% Amazon revenue; 250ms = −1.5% Bing revenue) means latency improvements are highest-ROI by default — run them before any UX variant.
7. **One week minimum; two weeks if the change affects UI.** Day-of-week effects corrupt results. New UI requires two weeks to separate novelty-effect decay from true adoption signal.

## LAYER 2: QUALITY GUIDANCE

1. **Cap the active test list at 5 key metrics per experiment.** 10 independent metrics = 40% false-positive probability by chance. Trim before scoring, not after.
2. **Segment candidates by Maturity-Model stage.** A Crawl-stage org (≤10 experiments/yr) cannot reliably run parallel tests; prioritize one high-confidence candidate at a time. A Fly-stage org (1,000+/yr) can run many; budget accordingly.
3. **Assign a triggered-population estimate.** If the element tested is seen by only 15% of visitors, effective n = 0.15 × total traffic. A 10% improvement on that segment = 1.5% aggregate impact (segment dilution principle). Factor this into EV before ranking.
4. **Label each candidate with its Launch Decision Zone.** After computing CI: Zone 1 (stat+pract sig → launch), Zone 2 (stat but not pract sig → do not launch), Zone 3 (neither → iterate/abandon), Zone 4 (underpowered → rerun), Zones 5-6 (borderline → pre-commit acceptance rule).
5. **Pre-commit practical significance threshold before unblinding.** Threshold set after seeing data is p-hacking in disguise.

## PURPOSE

This skill takes a real page and a list of test candidates, then applies Kohavi's Expected Value, MDE, and traffic-budget frameworks to output a ranked, budgeted test queue — so the team runs the experiment most likely to move the OEC next, not the one the HiPPO championed last.

**Brag line:** "We know our winner is real, not a 1-in-20 false positive."

The lever: before any pixel changes hands, this skill forces the team to compute P(effect) × Impact × Reach for every idea, derive minimum sample sizes from pre-committed practical significance floors, and confirm the traffic budget can support the top candidate in isolation — eliminating the most common form of CRO waste (running under-powered tests on low-probability ideas because they felt compelling in a meeting).

## INPUT REQUIREMENTS

**Required:**
- The page URL, screenshot, or written description.
- The ONE desired action (e.g., "complete checkout", "click primary CTA", "submit email opt-in").
- A list of test candidates (minimum 3; each with a one-sentence hypothesis).

**Recommended:**
- Baseline conversion rate (CR%) and daily unique visitors to the page.
- OEC formula from kohavi-oec-definer (or a proxy OEC if not yet formalized).
- Practical significance floor: the smallest δ worth launching for (e.g., "we only ship if lift ≥ 1% revenue").
- Current page load time (ms) — required to apply latency pre-filter.
- Funnel position (top of funnel, checkout, confirmation, etc.).
- Maturity stage: Crawl / Walk / Run / Fly.

**Optional:**
- Historical test results on this page.
- Audience segment data (% triggered per candidate).

## EXECUTION PROCESS

### Step 1 — Latency Pre-Filter (always first)

Benchmark current page load time. Apply Kohavi's latency constants:
- Every 100ms over baseline costs ~1% revenue (Amazon) / +0.6% gain if eliminated (Bing).
- 250ms server delay = −1.5% revenue; 500ms = −3%.

If load time > 2,000ms OR Time-to-First-Byte > 600ms: **insert a Speed candidate at the top of the queue automatically.** No scoring needed — latency improvements are structurally highest-EV.

### Step 2 — Candidate Intake + Triggered Population

For each candidate:
1. Name the element being changed (form field, CTA copy, layout, image, load time).
2. Estimate % of page visitors who encounter that element (triggered %).
3. State the directional hypothesis: "Removing the coupon code field will increase checkout completion rate by ≥ 2%."

Apply segment dilution: **Effective Impact = Raw Effect × Triggered%.**
Example: A checkout-flow candidate affects 20% of page visitors; raw effect estimate = 10% lift; effective aggregate impact = 2%.

### Step 3 — P(Real Effect) Assignment

Use Kohavi's base-rate calibration:

| Evidence Level | P(real effect) |
|---|---|
| No prior data, novel idea | 3–5% |
| Analogous test exists (same domain) | 15–25% |
| Direct replication (same element, similar site) | 30–50% |
| Guardrail violation pattern (e.g., friction removal) | 50–70% |

Assign each candidate a P value. Document justification. Do not adjust upward for internal enthusiasm.

### Step 4 — Expected Value Scoring

Compute for each candidate:

```
EV = P(real effect) × effective_impact_δ × daily_affected_users
```

Express EV in the same unit as the OEC (revenue/day, signups/day, etc.).

**Worked example (landing page opt-in, 10,000 daily visitors):**
- Candidate A: Remove secondary nav (triggered: 100%, P: 20%, estimated δ: 3% lift on opt-in rate 4% → 4.12%)
  - Effective impact: 0.03 × 0.20 = 0.006 × 10,000 × 0.04 CR = 2.4 extra opt-ins/day EV
- Candidate B: Change CTA copy (triggered: 100%, P: 10%, estimated δ: 8%)
  - EV = 0.10 × 0.08 × 10,000 × 0.04 = 3.2 extra opt-ins/day EV
- Candidate C: Shorten form from 5 to 2 fields (triggered: 40% reach checkout step, P: 40%, estimated δ: 12%)
  - EV = 0.40 × 0.12 × 4,000 × 0.04 = 7.7 extra opt-ins/day EV → **top priority**

### Step 5 — MDE + Sample Size Calculation

For each candidate (in EV rank order), derive minimum required n per arm:

```
n = 2 × (z_α/2 + z_β)² × σ² / δ²
```

Defaults: α = 0.05 (z = 1.96), power = 0.80 (z = 0.84), σ² = p × (1−p) for binary metrics.

For a baseline CR = 4%, practical significance floor δ = 0.005 (0.5pp absolute):
```
n = 2 × (1.96 + 0.84)² × (0.04 × 0.96) / (0.005)²
n = 2 × 7.84 × 0.0384 / 0.000025
n ≈ 24,084 per arm
```

Minimum duration = n / (daily_visitors × triggered% / 2 arms).

If duration > 8 weeks → candidate is under-powered at current traffic; move to backlog or relax δ floor with justification.

### Step 6 — Traffic Budget Allocation

Compute total simultaneous test capacity:

```
Slots = daily_unique_users × test_overlap_fraction / max(n_per_arm candidates)
```

Default: cap simultaneous experiments at 3 unless Fly-stage org confirmed. At Crawl/Walk stage: 1 experiment at a time.

Assign candidates to sequential or parallel slots. Mark conflicts (same page region, same user segment).

### Step 7 — Progressive Ramp Schedule

For top-ranked candidate, output the ramp plan per Kohavi's progressive deployment:

- **Days 1–2:** 2% exposure. Monitor guardrail metrics only (latency, error rate, crash rate).
- **Days 3–5:** Ramp to 10%. First OEC signal visible; do not interpret yet — bias toward frequent/Wi-Fi users.
- **Days 6–14:** Full allocation (50/50 or designed split). Measure OEC.
- **Day 14:** SRM check (chi-squared, p<0.001 threshold); if triggered, halt and investigate before reading scorecards.

### Step 8 — Launch Decision Zone Assignment

After test runs, map result to Launch Decision Matrix:

| Stat Sig? | Pract Sig? | Zone | Action |
|---|---|---|---|
| Yes | Yes | 1 | Launch |
| Yes | No | 2 | Do NOT launch |
| No | No | 3 | Iterate/abandon |
| No | Outside CI | 4 | Rerun, more users |
| Yes | Likely yes | 5 | Launch (accept risk) |
| No | Inside CI | 6 | Rerun, more power |

Pre-assign expected zone based on power calculation before unblinding.

## OUTPUT STRUCTURE

**1. Latency Pre-Filter Result**
Current load time, latency-to-revenue slope, Speed candidate status (inserted/not needed).

**2. Candidate Scorecard**
Table (≤6 cols): Candidate | Triggered% | P(effect) | EV/day | n/arm | Duration (days)
Legend: Triggered% = % page visitors reaching element; P = prior probability of real effect; EV = expected value in OEC units; n/arm = sample required per variant; Duration = days at current traffic.

**3. Ranked Test Queue**
Ordered list: Slot 1 → Slot 2 → Backlog. Each with: hypothesis, min δ committed, ramp schedule, guardrail metrics to watch.

**4. Traffic Budget Summary**
Total capacity, simultaneous slots available, conflicts flagged.

**5. Pre-Committed Decision Rules**
For each active test: practical significance floor, stat sig threshold (α), power, planned duration, SRM trigger, Launch Decision Zone prediction.

## WORKED MINI-EXAMPLE

**Page:** SaaS pricing page. Desired action: click "Start Free Trial."
Baseline: CR = 3.2%, 8,000 daily visitors, load time = 1,800ms.

**Latency pre-filter:** 1,800ms is elevated but under threshold (2,000ms). No auto-insert, but flag for future optimization.

**Three candidates:**

Before ranking, intuition said: Test the headline first (it's the most visible change).

After EV scoring:
- Headline rewrite: P=8%, δ=6%, triggered=100% → EV = 0.08 × 0.06 × 8,000 × 0.032 = 1.2 signups/day
- Remove annual/monthly toggle confusion (friction): P=35%, δ=10%, triggered=60% → EV = 0.35 × 0.10 × 4,800 × 0.032 = 5.4 signups/day
- Add social proof near CTA: P=15%, δ=5%, triggered=100% → EV = 0.15 × 0.05 × 8,000 × 0.032 = 1.9 signups/day

**Ranked queue:**
1. Remove toggle confusion (EV=5.4; n=18,200/arm; 4.6 weeks — fits budget)
2. Social proof near CTA (EV=1.9; n=14,800/arm; 3.7 weeks — run after slot 1)
3. Headline rewrite (EV=1.2; backlog — lowest EV, highest HiPPO enthusiasm)

**Outcome:** Team overrides intuition. Friction-removal runs first. Kohavi Rule 5 (reducing abandonment is hard but friction elements can be tested) confirmed in the data.

## OUTPUT FILE

Save to: [project-folder]/Kohavi - Click Architecture/[YYYY-MM] - Test Prioritization Design.md
