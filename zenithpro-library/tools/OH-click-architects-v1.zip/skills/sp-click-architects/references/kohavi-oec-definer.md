---
name: kohavi-oec-definer
description: Use when a page has no clear winning metric, uses vanity clicks as the goal, or when experiments are producing contradictory signals — defines the single composite OEC that ties every page element to long-term value before any test runs.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Ronny Kohavi (Controlled Experiments on the Web 2007-2020; Overall Evaluation Criterion + Metric Taxonomy + Guardrail Metrics) — Click Architecture (Skill 1 of 7)"
interface:
  invoke: "/kohavi-oec-definer"
  calls: []
  called_by: [user, kohavi-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "User behavior, pricing, and business model changes alter the causal chain between page metrics and strategic objectives; an OEC calibrated to last quarter's economics can point in the wrong direction."

kohavi_srm_guard_integration:
  feeds_to: kohavi-srm-guard
  shared_data: "Defined OEC formula + guardrail metric list + traffic-split design. srm-guard validates that the population actually exposed to each variant matches the designed ratio before the OEC is computed — a miscounted denominator invalidates any OEC reading."

eisenberg_field_intelligence_integration:
  feeds_from: eisenberg-field-intelligence
  feeds_to: eisenberg-field-intelligence
  shared_data: "Eisenberg buying-modality segments (Competitive/Spontaneous/Humanistic/Methodical) define which driver metrics are plausible proxies for each visitor type. OEC weights should reflect the modal modality of the page's traffic. OEC output (composite formula) feeds back into Eisenberg micro-action sequencer as the optimization target."

kahneman_field_intelligence_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: kahneman-field-intelligence
  shared_data: "Kahneman peak-end framing identifies which page moments matter most to long-term memory and return visits. These moments surface as candidate driver metrics. OEC feeds back to kahneman-prospect-theory-architect as the constraint: loss-aversion framing is only valid if the OEC confirms that the framed metric is causally linked to retention."
---

# Kohavi OEC Definer — Overall Evaluation Criterion

## LAYER 1: INVARIANTS (Never override.)

1. **One decision variable.** The OEC is a single composite number. If the experiment team would debate which metric to look at after results come in, the OEC is not defined yet. Multiple metric dashboards without an aggregation rule = no OEC.
2. **Measurable within experiment duration.** Lifetime revenue is not an OEC for a two-week test. The OEC must close within the experiment window. Use a causally validated proxy (e.g., 6-session retention as a proxy for 12-month LTV) — but document the causal hypothesis explicitly.
3. **Explicit tradeoff encoding.** Any OEC that maximizes revenue without penalizing user-health metrics will destroy long-term value. Amazon's email OEC: `(Total Revenue - s × unsubscribe_lifetime_loss) / n`. If you are not encoding a penalty for harm, the OEC is incomplete.
4. **Guardrails are not OEC.** Latency, crash rate, error rate, and trust-invariant ratios (bot-filter rate, cache-hit rate) are guardrails — they create a feasible region. The OEC is maximized only inside that feasible region. A guardrail violation halts the experiment regardless of OEC improvement.
5. **Pre-registered before data is seen.** The OEC formula, weights, and practical significance threshold must be written and locked before unblinding results. Post-hoc OEC construction is p-hacking by another name.
6. **Practical significance threshold is required.** Statistical significance alone is not a launch criterion. Pre-define the minimum OEC delta that justifies launch cost and risk (e.g., +1% revenue). Stat-sig + below practical threshold = do NOT launch (Kohavi Launch Matrix scenario 3).
7. **Five-metric cap.** Ten independent metrics in a results dashboard = 40% probability that at least one is significant by chance alone. Hard cap: define no more than five metrics per experiment. OEC aggregates them; debug metrics decompose; guardrails protect.

## LAYER 2: QUALITY GUIDANCE

1. **Decompose before composing.** Use the Metric Taxonomy (Goal / Driver / Guardrail / Debug) to classify every candidate metric before weighting. Do not put debug metrics in the OEC — they decompose results, not decide them.
2. **Validate the proxy-to-goal causal chain.** Driver metrics are proxies. Write the causal hypothesis: "Sessions/User increases → 30-day retention increases → LTV increases" with cited evidence (even if internal A/A analysis). An OEC built on an unvalidated proxy is a guess dressed in math.
3. **Use Bing's decomposition pattern as a structure template.** Bing OEC = `Users/Month × Sessions/User × Distinct Queries/Session`. Each factor is independently interpretable, multiplicatively combines into a single number, and each has a natural guardrail floor. Apply this multiplicative factor pattern to any OEC on complex pages.
4. **Weight by business model, not page position.** An email opt-in page OEC should weight long-term email health (unsubscribe rate, complaint rate) not just raw opt-ins. A checkout page OEC should weight revenue-per-completed-checkout, not just checkout-page CTR.
5. **Document every weight decision.** Weights encode business judgment. Write the rationale for each weight coefficient before the experiment runs. If a stakeholder disputes results, the weight rationale is the audit trail.

## PURPOSE

This skill defines the Overall Evaluation Criterion — the single composite metric that is the legal decision variable for every experiment on a page. Without a valid OEC, experiments produce noise: teams debate which metric matters, winners get declared on vanity clicks, and 70-90% of launched changes quietly destroy long-term value while the dashboard shows green.

Kohavi's core finding: at Bing, only 1 in 500 experiments is a true breakthrough; when p≈0.05, the probability the effect is real is ~3.1%. The OEC is the oracle that filters signal from this noise. It encodes the tradeoffs the business actually cares about — not the metrics that are easiest to move.

**Brag line (carry this to a peer): "We know our winner is real, not a 1-in-20 false positive."**

This skill produces the OEC formula, the guardrail set, the practical significance threshold, and the metric taxonomy map — everything a team needs locked before a single variant goes live.

## INPUT REQUIREMENTS

**Required:**
- The page (URL, screenshot, or written description — enough to identify all interactive elements and funnel position)
- The ONE desired action this page must drive (click / opt-in / purchase / next step)
- The business model context: what does a completed desired action ultimately produce? (revenue, subscriber, trial, qualified lead)

**High-value optional:**
- Current analytics: conversion rate, bounce rate, time-on-page, funnel drop-off rates
- Experiment duration available (days)
- Audience size (monthly unique visitors to this page)
- Prior experiment results on this page or funnel neighbors
- Any metrics the team is currently watching (to classify and potentially prune)

## EXECUTION PROCESS

**Step 1: Classify All Candidate Metrics (Metric Taxonomy)**

For every metric the team currently tracks or could track on this page, assign to one of four bins:

| Bin | Definition | Action |
|-----|-----------|--------|
| Goal | Ultimate strategic objective | Validate OEC proxy against this |
| Driver | Short-term proxy with causal hypothesis | Candidate for OEC composition |
| Guardrail | Must not degrade | List explicitly; halt trigger if violated |
| Debug | Decomposes results | Exclude from OEC; keep in dashboard |

Hard cap: no more than 5 metrics cross goal+driver+guardrail combined in the OEC dashboard. Prune or demote to debug before proceeding.

**Step 2: Write the Causal Chain**

For each driver metric candidate, write the hypothesis chain:
`[Driver metric] increases → [intermediate outcome] increases → [Goal metric] increases`

Rate each chain: Strong (prior evidence), Plausible (logical, no contradicting data), Weak (assumed). Only Strong and Plausible chains qualify for OEC composition. Weak chains become debug metrics at best.

**Step 3: Construct the OEC Formula**

Choose one of two patterns based on page type:

*Pattern A — Additive with penalty (for pages with user-health tradeoffs):*
`OEC = (Primary_Value - w × Harm_Proxy) / n`

Example (email opt-in page): `OEC = (Opt_ins - 3.2 × unsubscribes_projected_lifetime) / visitors`
The coefficient `w` = estimated lifetime value of one unsubscribed user. If LTV = $320 and 1% of unsubscribes would have converted, `w = 3.2`.

*Pattern B — Multiplicative decomposition (for multi-step funnel pages):*
`OEC = Factor_1 × Factor_2 × Factor_3`

Example (SaaS trial page): `OEC = Visit-to-Trial_Rate × Trial-to-Active_Rate × Active_30d_Retention`
Each factor is bounded [0,1], their product is the end-to-end conversion probability.

**Step 4: Set the Guardrail List**

Mandatory guardrails for any web page experiment:
- Page load time: must not increase by more than [threshold]ms (recommend: 200ms absolute max; ideally 0 regression)
- Error rate: must not increase
- Bot-filter rate: must stay within ±0.5% of control (trust invariant)
- Bounce rate: alert if increase exceeds 5 percentage points (investigate, not auto-halt)

Page-specific guardrails (derive from the desired action context):
- If desired action = purchase: revenue/session is a guardrail floor, not just OEC input
- If desired action = opt-in: complaint/unsubscribe rate in first 30 days is a guardrail
- If desired action = next-step click: downstream funnel completion rate is a guardrail

**Step 5: Set the Practical Significance Threshold**

Pre-register the minimum OEC delta that justifies launch. Derive it:

`Min_delta = (Launch_cost + Risk_premium) / (Monthly_traffic × Expected_OEC_denominator)`

If launch is zero-marginal-cost (code already written, test passed), practical threshold can be as low as 0.5% OEC improvement. If launch requires engineering work, set higher. Write the number. Do not look at results first.

**Step 6: Compute Minimum Sample Size**

Use Kohavi's Rule 7: minimum ~200,000 users to detect a 5% effect at 80% power, α=0.05. For smaller effects:

`Required_n ≈ (16 × σ²) / δ²`

Where σ² = variance of the OEC metric and δ = minimum detectable effect (= practical significance threshold). If the page does not reach this sample in the planned experiment window, the experiment is underpowered — do not run it; fix the page's traffic problem first or widen the practical threshold.

**Step 7: Audit the OEC for Gaming Vectors**

For each term in the OEC formula, ask: "If an engineer optimized only this term, ignoring all others, what would the page look like?" If the answer is harmful (e.g., "they would remove the unsubscribe link to kill the unsubscribe rate term"), add a guardrail or a penalty term that closes the loophole. An OEC that can be gamed will be gamed.

## OUTPUT STRUCTURE

**Section 1: Metric Taxonomy Map**
Table of all candidate metrics, classified into Goal / Driver / Guardrail / Debug bins, with causal chain rating and OEC inclusion decision.

**Section 2: OEC Formula**
The composite formula, written out in full, with each term defined, each coefficient justified, and the formula's output unit stated (e.g., "revenue-adjusted opt-in rate per visitor").

**Section 3: Guardrail Set**
Numbered list of guardrails, each with: metric name, direction of protection (must not increase / must not decrease), halt threshold, and investigation threshold.

**Section 4: Practical Significance Threshold**
The pre-registered minimum OEC delta required to launch, with derivation shown.

**Section 5: Sample Size Requirement**
Required unique visitors per variant, expected experiment duration at current traffic, and verdict (Powered / Underpowered / Marginal).

**Section 6: Gaming Audit**
For each OEC term: the gaming vector and the countermeasure (guardrail or penalty already in formula).

**Section 7: Sibling Skill Handoff**
What to pass to kohavi-srm-guard (OEC formula + guardrails + traffic split design) and what to pass to kohavi-experiment-validity-auditor (OEC + metric taxonomy map).

## WORKED MINI-EXAMPLE

**Page:** SaaS pricing page. Desired action: start free trial.

**Current team metric:** Trial button CTR. Problem: CTR is gamed by making the button huge and the page confusing — users click impulsively, don't activate, churn immediately.

**Step 1 — Classify:**
- Goal: 90-day retained paying customer
- Driver candidates: Trial CTR, Trial activation rate (completes onboarding), 30-day active usage
- Guardrail: page load time, error rate, pricing page bounce rate
- Debug: button hover rate, scroll depth

**Step 2 — Causal chain:**
- Trial CTR → Trial-to-active rate: Plausible (clicks that don't activate indicate intent mismatch; reducing page confusion should improve both together)
- Trial-to-active rate → 30-day retention: Strong (internal cohort data shows 0.78 correlation)

**Step 3 — OEC formula (Pattern B):**
`OEC = Trial_CTR × Trial_Activation_Rate × Active_30d_Rate`

Before: Team optimized Trial_CTR alone = 8.2% CTR, 31% activation, 44% 30d retention → OEC = 0.082 × 0.31 × 0.44 = **0.0112**

After (new variant reduces CTR but qualifies intent better): 6.1% CTR, 52% activation, 61% 30d retention → OEC = 0.061 × 0.52 × 0.61 = **0.0193**

OEC declares the lower-CTR variant the winner. CTR-only analysis would have killed it.

**Step 4 — Guardrails:** Load time ≤ current baseline + 200ms; error rate ≤ control; bounce rate increase ≤ 5pp.

**Step 5 — Practical threshold:** 0.001 OEC unit improvement minimum (≈ 9% relative gain vs. current 0.0112).

**Step 6 — Sample size:** σ² estimated at 0.01 (binary-ish OEC), δ = 0.001. n ≈ (16 × 0.01) / 0.000001 = 160,000 per variant. At 40,000 monthly visitors, run for 8+ weeks. Verdict: Marginal — extend to 10 weeks to add safety margin.

## OUTPUT FILE

Save to: [project-folder]/Kohavi - Click Architecture/[YYYY-MM] - OEC Definition - [Page Name].md
