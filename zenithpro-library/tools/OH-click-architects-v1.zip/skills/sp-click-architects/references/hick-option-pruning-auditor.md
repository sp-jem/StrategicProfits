---
name: hick-option-pruning-auditor
description: Use when a page has multiple CTAs, heavy navigation, long forms, or crowded option sets that may be throttling conversions — audits which options to cut to lower decision load and speed the desired action using Hick-Hyman Law.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "William Hick & Ray Hyman (Hick 1952, Hyman 1953; Hick-Hyman Law + Hyman Entropy Extension) — Click Architecture (Skill 2 of 7)"
interface:
  invoke: "/hick-option-pruning-auditor"
  calls: []
  called_by: [user, hick-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "CTA counts, nav structures, and form fields change with site updates; stale audits miss net-new bloat added post-deploy."

hick_decision_load_calculator_integration:
  feeds_from: hick-decision-load-calculator
  feeds_to: hick-option-pruning-auditor
  shared_data: "Computed RT estimates (RT = a + b×log₂(n+1)) and per-zone entropy scores feed directly into this skill's priority ranking — cut highest-entropy zones first."

iyengar_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: hick-option-pruning-auditor
  shared_data: "Iyengar's catalog-size findings (6 vs 24 jam study) calibrate the Goldilocks floor: flag any option set >7 items for chunking before pruning to avoid over-restriction."

thaler_integration:
  feeds_from: thaler-field-intelligence
  feeds_to: hick-option-pruning-auditor
  shared_data: "Thaler's Smart Default / choice architecture lens confirms which default pre-selections reduce response uncertainty to 0 — those fields are pruning candidates rather than removal candidates."
---

# Hick-Hyman Option Pruning Auditor

## LAYER 1: INVARIANTS (Never override.)

1. **Response uncertainty is the dominant variable.** Wifall et al. (2015) separates the law into stimulus vs. response uncertainty; response uncertainty carries the larger coefficient. Cutting the number of *response options* (buttons, form fields, links) outranks hiding visual stimuli when time is limited.
2. **One primary CTA per conversion zone.** The Hick-Hyman formula bottoms out at n=1: RT = a + b×log₂(2) = a + b×0.155s — the minimum achievable. Any second CTA at the same visual level adds ≥0.155s processing overhead and opens response-uncertainty competition.
3. **The first options added are the most expensive.** Because RT scales as log₂(n+1), adding option 2 costs +0.155s, option 3 costs +0.087s more, option 7 costs only +0.032s more. Prune from the low end first — removing options 2-4 is worth more than removing options 8-12.
4. **Entropy, not count, governs actual decision time.** Hyman's extension: H = -Σ p(i)×log₂(p(i)). A page with 6 options where one CTA gets 70% visual salience may have lower effective H than a page with 3 equally weighted CTAs. Audit entropy, not raw n alone.
5. **Goldilocks floor: never drop below 3 on pricing/offer pages.** Fewer than 3 tiers reduces perceived choice legitimacy and can raise abandonment. The operational range is 1 CTA (conversion zones), 3 tiers (pricing), 5-7 items (navigation).
6. **Pruning candidates must be identified by role, not aesthetics.** A link is a prune candidate if removing it does not block the user from completing the desired action. Secondary/escape links are last to cut; competing conversion-path links are first.
7. **Track time-to-first-click, not just conversion rate.** Hick-Hyman predicts decisions that take >8-12 seconds on primary CTA indicate n is too high — use this as the leading diagnostic before A/B results mature.

## LAYER 2: QUALITY GUIDANCE

1. Anchor every recommendation to a specific formula output: state the before/after RT estimate using RT = a + b×log₂(n+1) where b ≈ 0.155s. Show the math.
2. Separate the audit into zones (Hero, Nav, Form, Pricing, Footer) — entropy loads compound across zones but pruning is zone-specific.
3. Apply the Hyman entropy check to the highest-traffic zones before recommending removal: if a competing option has p(i) < 0.05 in user behavior data, its entropy contribution is near-zero and it may be cut without meaningful risk.
4. When removal is not viable (legal links, required nav), recommend chunking or progressive disclosure as the fallback — do not leave a high-n zone without a resolution path.
5. Prioritize output: rank pruning candidates by estimated RT savings (largest first), not by visual proximity or personal preference.

## PURPOSE

This skill takes a real web page — URL, screenshot, or written description — plus one stated desired action, and identifies which specific options, links, buttons, and form fields to remove or defer in order to minimize decision latency on the path to that action.

The thinker's lever: **Hick-Hyman Law proves that decision reaction time = a + b×log₂(n+1). Pruning options is not a design opinion — it is a calculable RT reduction.** Hyman's entropy extension (H = -Σ p(i)×log₂(p(i))) refines the target: cut the options that contribute highest entropy to the user's response uncertainty, not merely the options with the most pixels.

**Brag line:** "We cut decision time by removing options, and we can prove the math."

Cluster position: This is Skill 2 of 7. Skill 1 (hick-decision-load-calculator) computes RT per zone; this skill identifies *which items to remove*. Skill 3 (hick-categorization-architect) handles what remains after pruning. Do not re-compute load here — import from Skill 1 if available.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description (include all visible CTAs, nav items, form fields, links, and pricing tiers)
- The ONE desired action (e.g., "click 'Start Free Trial'", "submit lead form", "select Tier 2 plan")

**Optional (improves entropy scoring):**
- Click/heatmap data or analytics showing per-option engagement rates (used to estimate p(i) per option)
- Current conversion rate and time-to-first-click on primary CTA
- Funnel position (top-of-funnel vs. conversion page changes the Goldilocks target)
- Prior A/B test results on CTA or field counts

## EXECUTION PROCESS

**Step 1 — Inventory all response options by zone.**
List every element the user could click, tap, or complete. Group by zone:
- Hero zone: CTAs, headline links
- Navigation: top-level items, dropdowns
- Body: embedded links, secondary CTAs, banners
- Form: fields, optional fields, checkboxes
- Pricing: tiers, add-ons, comparison links
- Footer: nav links, legal, social icons

Record: zone | element | type (CTA / link / field / option) | estimated p(i) if data available.

**Step 2 — Compute baseline RT per zone.**
Apply RT = a + b×log₂(n+1) where b = 0.155s, a = 0.2s (standard baseline).
If p(i) data exists, compute zone entropy H = -Σ p(i)×log₂(p(i)) instead.
Flag any zone where RT > 0.8s or H > 2.0 bits as HIGH LOAD.

**Step 3 — Classify each option as PRUNE / DEFER / KEEP.**

| Class | Criteria |
|-------|----------|
| PRUNE | Does not block desired action; user can complete goal without it; zero or minimal p(i) |
| DEFER | Needed by some users but not on the conversion path; move behind progressive disclosure |
| KEEP | Required for desired action, legal compliance, or trust signal; p(i) > 0.15 |

Apply the single-CTA rule first: if the conversion zone has >1 CTA-level button, classify all but the primary as PRUNE or DEFER.

**Step 4 — Compute post-prune RT and entropy delta.**
For each PRUNE recommendation, show:
- n_before → n_after
- RT_before → RT_after (using formula)
- Estimated seconds saved per decision

Rank recommendations by RT savings descending.

**Step 5 — Apply Hyman Entropy Check on remaining items.**
For kept options: calculate whether the desired CTA is the visually dominant (high p(i)) option. If not — if competing options have comparable visual weight — flag for entropy reduction via hierarchy, not removal (covered by Skill 1 integration, but flag here for completeness).

**Step 6 — Goldilocks validation.**
Verify final n per zone does not fall below floors:
- Conversion/CTA zone: n = 1 primary (1 secondary escape is acceptable)
- Form fields: minimum required for this transaction step only
- Pricing: n = 3 tiers (floor), n = 5 tiers (ceiling, beyond which chunk)
- Navigation: n = 5-7 top-level items

**Step 7 — Output prioritized prune list with implementation spec.**
Each item: what to cut/defer, where to move deferred items, expected RT delta, and the one-sentence rationale in Hick-Hyman terms.

## OUTPUT STRUCTURE

### Section 1: Page Snapshot
- Desired action stated
- Total response options counted by zone
- Baseline RT or entropy per zone (formula shown)

### Section 2: Decision Load Map

| Zone | n | RT (s) | H (bits) | Load |
|------|---|--------|----------|------|
| Hero | # | #.## | #.## | HIGH/MED/LOW |
| Nav | # | #.## | #.## | HIGH/MED/LOW |
| Form | # | #.## | #.## | HIGH/MED/LOW |
| Price | # | #.## | #.## | HIGH/MED/LOW |
| Body | # | #.## | #.## | HIGH/MED/LOW |

*Legend: n = option count; RT = reaction time from formula; H = Shannon entropy (requires p(i) data); Load = HIGH (RT>0.8s or H>2.0 bits), MED, LOW*

### Section 3: Prune Priority List
Ranked by RT savings. Per item: Zone | Element | Class | n_before→after | RT delta | Rationale.

### Section 4: Deferred Items Routing
Where each DEFER item moves: expandable accordion, secondary screen, footer, or post-conversion page.

### Section 5: Post-Prune RT Summary
Before/after RT per zone. Total estimated decision-latency reduction across the conversion path.

### Section 6: Measurement Setup
- What to track (time-to-first-click on primary CTA, abandonment rate per step)
- A/B test spec: primary variable (CTA count, field count, or tier count), minimum runtime (1 week), expected direction

## WORKED MINI-EXAMPLE

**Page:** SaaS trial landing page. Desired action: click "Start Free Trial."

**Before — Hero zone inventory:**
- "Start Free Trial" (primary CTA)
- "Watch Demo" (secondary CTA, same visual weight)
- "See Pricing" (tertiary link)
- "Book a Call" (fourth link)
- n = 4; RT = 0.2 + 0.155×log₂(5) = 0.2 + 0.155×2.32 = **0.56s**

**Prune decision:**
- "Watch Demo" → DEFER to body section below fold (used by researchers, not converters)
- "See Pricing" → DEFER to nav (already accessible)
- "Book a Call" → PRUNE from hero (serve in footer for enterprise path)
- n_after = 1; RT = 0.2 + 0.155×log₂(2) = 0.2 + 0.155×1.0 = **0.36s**

**RT delta:** −0.20s per visit. At 10,000 monthly visitors, that is 33 minutes of aggregate decision latency eliminated — and, more importantly, the response uncertainty around the primary CTA drops from competing against 3 alternatives to zero competitors. Conversion rate benchmark improvement: from ~11.9% (2-CTA baseline) toward ~13.5% (1-CTA baseline).

**Form zone (same page, opt-in):**
- Before: 8 fields (name, last name, company, role, team size, phone, email, country) — n=8; completion rate ~52%
- Prune: last name, company, role, team size, phone, country → collect post-conversion via onboarding
- After: 2 fields (first name, email) — n=2; expected completion rate ~74% (Baymard: ~+8-50% per field removed from 5+)

## OUTPUT FILE
Save to: [project-folder]/Hick-Hyman - Click Architecture/[YYYY-MM] - Option Pruning Audit.md
