---
name: fitts-thumb-zone-mapper
description: Use when a mobile page has low tap-through on the primary CTA — diagnoses thumb reachability zones and relocates the primary action into the natural thumb hover zone to minimize Index of Difficulty.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Paul Fitts (Fitts's Law 1954; Shannon formulation 1992; Index of Difficulty, Two-Phase Movement Model, Speed-Accuracy Trade-off) — Click Architecture (Skill 3 of 7)"
interface:
  invoke: "/fitts-thumb-zone-mapper"
  calls: []
  called_by: [user, fitts-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page layout changes, A/B tests, and new device viewport distributions shift thumb zone coverage; findings stale within 1-2 sprint cycles."

fitts_target_cost_auditor_integration:
  feeds_from: [fitts-target-cost-auditor]
  feeds_to: []
  shared_data: "ID scores (log₂(1+D/W)) for all clickable elements; auditor surfaces which elements have the highest ID — mapper uses that list to prioritize relocation candidates."

fitts_primary_action_dominance_scorer_integration:
  feeds_from: []
  feeds_to: [fitts-primary-action-dominance-scorer]
  shared_data: "Thumb-zone placement verdict and new button W (effective width) after relocation; dominance scorer uses these to recompute the primary CTA's ID advantage over competing elements."

kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: []
  shared_data: "System 1 friction audit — Kahneman's peak-end and availability heuristics flag emotional friction points; mapper cross-references those locations with high-ID zones to identify double-friction hot spots on the mobile page."
---

# Fitts Thumb Zone Mapper

## LAYER 1: INVARIANTS (Never override.)

1. **ID is the only metric.** Every relocation decision derives from ID = log₂(1 + D/W). Gut feel, aesthetic preference, or brand guidelines cannot override a lower-ID placement for the primary CTA.
2. **D is measured from the thumb prime pixel, not the screen center.** On mobile, the prime pixel is bottom-center of the visible viewport for a right-handed dominant grip (~75% of users). Measure D from that point to the CTA center.
3. **Edges and corners are hard on touch.** Desktop infinite-target logic is inverted for mobile: screen edges require extreme thumb extension (ulnar deviation) or grip shift. Never anchor a primary CTA to screen edges on mobile.
4. **Minimum touch target is a hard floor, not a goal.** Apple HIG 44×44 pt (~59×59 px); Google Material 48×48 dp. Below this floor, ID is artificially inflated by required precision. Hit this floor first, then maximize W above it.
5. **Two-phase movement is the mechanism.** Large W eliminates the homing phase — the thumb lands during the ballistic phase. Any button narrow enough to require homing phase acquisition is undersized. Full-width mobile buttons collapse homing to zero.
6. **SAT creates abandonment, not just latency.** A small or distant CTA forces the user to slow and aim (speed-accuracy trade-off). Misclicks on adjacent elements generate frustration and back-navigation. This is the mechanical source of lost conversions, not merely a speed issue.
7. **One primary CTA per thumb zone.** Competing interactive elements within the natural thumb arc (easy zone radius) force the user to aim precisely to avoid mis-taps. Every competing element in that arc raises effective D for the primary CTA.

## LAYER 2: QUALITY GUIDANCE

1. **Compute, don't estimate.** Use actual device dimensions (CSS pixels at 2×/3× DPR) to compute D and W numerically. State the ID value before and after relocation. A diagnosis without numbers is not a Fitts diagnosis.
2. **Use effective width (We) when session data exists.** If heatmap or tap-coordinate data is available, compute We = 4.133 × SD of tap coordinates on the CTA axis. We < W indicates users are treating the button as smaller than it is — a visual/contrast issue, not a size issue.
3. **Map all three zones before prescribing.** Easy zone (thumb reaches without grip shift), stretch zone (requires extension), and hard zone (requires grip change). Every page element must be placed on this map before relocation recommendations are made.
4. **Prioritize the highest-ID bottleneck in multi-step flows.** Calculate cumulative MT across all CTA steps in a funnel. Fix the single highest-ID step first — it governs abandonment rate for the entire flow.
5. **Validate with throughput, not click rate alone.** TP = ID / MT. A CTA with fast clicks but high mis-tap rate on adjacent elements has low effective TP. Use heatmaps and session recordings to capture effective width and error dispersion.

## PURPOSE

This skill applies Fitts's Law (MT = a + b × log₂(1 + D/W)) to the mobile thumb specifically: it maps the three reachability zones on the actual page, measures the Index of Difficulty for the primary CTA in its current position, and outputs a relocation + resizing prescription that collapses the homing phase and brings ID as close to zero as the layout allows.

**Brag line:** "Our primary button is mathematically the easiest thing to hit on the page."

This is the mobile-specific complement to fitts-target-cost-auditor (which scores all elements) and fitts-primary-action-dominance-scorer (which measures the CTA's ID advantage over competitors). This skill owns the thumb-zone map and the physical relocation prescription.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written layout description (enough to identify element positions in the viewport)
- The ONE desired action: the single tap the page must convert (e.g., "tap Add to Cart," "tap Start Free Trial," "tap Submit")
- Target device: phone form factor (default: 390×844 CSS px, iPhone 14 Pro equivalent) and dominant hand assumption (default: right-handed)

**Optional (improves precision):**
- Heatmap or tap-coordinate data (enables We calculation)
- Analytics: device breakdown, session duration, scroll depth at CTA
- Funnel position: single page vs. step N of M in a flow
- Competing CTA elements and their current positions

## EXECUTION PROCESS

**Step 1 — Establish the thumb prime pixel.**
For a right-handed grip on a 390×844 viewport:
- Natural thumb hover: approximately x=195 (center), y=650–700 (lower third, ~77–83% down)
- This is D=0 reference point. Record: Prime Pixel = (195, 675) for 390×844.
- For left-handed or tablet adjustments, shift x accordingly. State the assumption.

**Step 2 — Draw the three zones.**
From the prime pixel, map radial distances:
- Easy zone: 0–75 px radius (thumb reaches without grip shift, no extension)
- Stretch zone: 75–150 px radius (ulnar extension required, accuracy decreases ~15%)
- Hard zone: >150 px from prime pixel OR top 30% of screen (grip shift or second hand required)

On a 390×844 page:
- Easy zone center: roughly y=600–750, x=120–270
- Hard zone top: y=0–253 (top 30%)
- Hard zone edges: x<40 or x>350 (edge strain), y>800 (bottom edge — thumb must curl under)

**Step 3 — Place every interactive element on the zone map.**
List all tappable elements: primary CTA, secondary CTAs, nav links, form fields, social proof taps, back/cancel.
For each, record: element name | center (x,y) | W (px, along tap axis) | D from prime pixel | ID = log₂(1+D/W) | Zone.

| Element | Center | W (px) | D (px) | ID (bits) | Zone |
|---------|--------|--------|--------|-----------|------|
| Primary CTA | current | current | computed | computed | Easy/Stretch/Hard |
| Secondary CTA | ... | ... | ... | ... | ... |
| Nav links | ... | ... | ... | ... | ... |

Cap table at 6 columns. If more elements exist, group them in a second table.

**Step 4 — Diagnose the primary CTA.**
Verdict thresholds:
- ID < 1.5 bits → Optimal (prime-pixel placement, large target)
- ID 1.5–2.5 bits → Acceptable (within easy zone, standard size)
- ID 2.5–3.5 bits → Degraded (stretch zone or undersized)
- ID > 3.5 bits → Critical (hard zone or tiny target — fix immediately)

State: current ID, current zone, verdict, and what is causing the high ID (D too large, W too small, or both).

**Step 5 — Map competing elements in the easy zone.**
Any tappable element with ID < 2.5 bits (easy or low-stretch zone) that is NOT the primary CTA is a competing target. It forces users to aim rather than tap freely.
List competitors: name, ID, proximity to primary CTA center (px).
Flag any competitor within 80 px of the primary CTA center as a mis-tap risk.

**Step 6 — Generate relocation prescription.**
Produce three changes, in priority order:

1. **Relocate** the primary CTA center to the easy zone. Target: D ≤ 60 px from prime pixel. Recommended anchor: bottom-center of viewport, fixed/sticky, y ≈ 780–820 on 390×844 (above bottom edge strain zone, within easy reach).

2. **Resize** the button to maximize W. On mobile: full-width (W = viewport width − padding, target W ≥ 330 px on 390 viewport). This collapses homing phase. Minimum height: 52 px (above 44 pt HIG floor with breathing room).

3. **Clear the easy zone** of competitors. Move secondary CTAs, cancel/back links, and nav elements to the stretch or hard zone. Minimum separation from primary CTA center: 80 px.

For each change, state: before ID → after ID (bits saved).

**Step 7 — Compute cumulative MT improvement (if multi-step flow).**
If the page is step N of M: estimate MT reduction using b ≈ 0.1 s/bit (empirical constant for touchscreen pointing tasks). MT_saved = b × (ID_before − ID_after). Annualize against conversion volume if provided.

**Step 8 — Sticky CTA prescription for long-form pages.**
If page scroll depth > 2× viewport height: primary CTA must be sticky/fixed. A scrolled-away CTA has D = ∞ (user must scroll back). State: fixed-position bar at y = viewport_height − 64 px, full width, z-index above content.

## OUTPUT STRUCTURE

**Section 1 — Zone Map Summary**
- Prime pixel coordinates stated
- Three zones defined with pixel boundaries for this device/viewport
- Table: all interactive elements mapped to zones with ID scores

**Section 2 — Primary CTA Diagnosis**
- Current position, W, D, ID, Zone, Verdict (Optimal/Acceptable/Degraded/Critical)
- Root cause: D issue, W issue, or competitor interference

**Section 3 — Competing Elements Audit**
- List of elements in easy zone that are not the primary CTA
- Mis-tap risk flags (within 80 px of primary CTA center)

**Section 4 — Relocation Prescription**
- Three changes (relocate, resize, clear zone) with before/after ID for each
- Net ID reduction for primary CTA
- Estimated MT saved per tap (using b = 0.1 s/bit)

**Section 5 — Implementation Notes**
- CSS/layout specifics (fixed positioning, z-index, padding)
- Minimum touch target compliance check (44×44 pt / 59×59 px)
- Effective width test: if heatmap available, compute We = 4.133 × SD and compare to W
- Sticky prescription if long-form page

**Section 6 — Next Skill Handoff**
- Pass ID scores table to fitts-primary-action-dominance-scorer for competitive advantage calculation
- Pass relocation verdict to fitts-target-spacing-optimizer to verify cleared-zone spacing is sufficient

## WORKED MINI-EXAMPLE

**Page:** Mobile opt-in landing page. Viewport: 390×844 px. Desired action: tap "Get Instant Access" button.

**Current state:**
- "Get Instant Access" button: center (195, 320), W = 180 px, D from prime pixel (195,675) = 355 px
- ID = log₂(1 + 355/180) = log₂(2.97) = 1.57 bits... but button is in the hard zone (y=320, top 38% of screen)
- Actual: D = 355 px, W = 180 px → ID = log₂(1 + 355/180) = 1.57 bits on paper, but accuracy penalty from hard-zone placement inflates effective ID; user must shift grip.
- "Maybe Later" link: center (195, 380), W = 80 px — 60 px below primary CTA, easy to mis-tap.

**Verdict:** Degraded-to-Critical. Button is in hard zone (grip shift required). Competitor 60 px away.

**After prescription:**
- Relocate CTA to sticky bottom bar: center (195, 800), D = |800−675| = 125 px → now stretch zone
- Resize to full width: W = 350 px → ID = log₂(1 + 125/350) = log₂(1.357) = 0.44 bits
- Move "Maybe Later" to top-right corner (hard zone, y=40): no longer competes
- ID reduction: from ~3.2 bits (hard zone, grip-shift corrected) → 0.44 bits
- MT saved: 0.1 s/bit × 2.76 bits = 0.28 seconds per tap — across 10,000 monthly visitors at 40% mobile, that's measurable friction eliminated at scale, plus mis-tap abandonment eliminated entirely.

**Net result:** Primary CTA is now the mathematically easiest thing to hit on the page.

## OUTPUT FILE
Save to: [project-folder]/Fitts - Click Architecture/[YYYY-MM] - Thumb Zone Map.md
