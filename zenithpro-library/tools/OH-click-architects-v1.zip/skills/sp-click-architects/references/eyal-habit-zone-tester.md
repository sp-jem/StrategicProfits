---
name: eyal-habit-zone-tester
description: Use when a page's desired action is meant to become habitual (return visits, re-engagement, recurring purchase) — tests whether the behavior sits inside the Habit Zone via Frequency x Perceived Utility and diagnoses which Hook phase is blocking loop completion.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Nir Eyal (Hooked, 2014; The Habit Zone + Hook Model + B=MAP) — Click Architecture (Skill 5 of 7)"
interface:
  invoke: "/eyal-habit-zone-tester"
  calls: []
  called_by: [user, eyal-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "User intent signals and competitive perceived utility shift with product updates and market entries; a habit-zone plot older than 45 days may misclassify the behavior."

eyal_hook_loop_integration:
  feeds_from: eyal-hook-loop-designer
  feeds_to: eyal-trigger-architect
  shared_data: "Hook phase scores (Trigger/Action/Variable Reward/Investment) inform zone diagnosis; Trigger phase output feeds directly into this skill's internal-trigger installation audit."

fogg_behavior_integration:
  feeds_from: fogg-behavior-mapper
  feeds_to: eyal-investment-escalator
  shared_data: "B=MAP convergence score from fogg-behavior-mapper identifies which of the six simplicity elements is scarcest; that scarcest-resource finding powers eyal-habit-zone-tester's Action friction audit."

kahneman_thaler_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: thaler-field-intelligence
  shared_data: "Loss aversion from sunk Investment (stored value) is quantified here as defection cost; thaler-field-intelligence uses that endowment score to price anchoring and cancellation framing."
---

# Eyal Habit Zone Tester

## LAYER 1: INVARIANTS (Never override.)

1. The Habit Zone is a two-axis gate, not a spectrum. A behavior is either inside or outside. If it is outside, do NOT attempt Hook loop design — optimize for a single strong first conversion instead.
2. Frequency is measured in return visits WITHOUT external trigger (self-triggered sessions). Prompted return visits from email or retargeting do not count as habitual frequency.
3. Perceived utility is always relative to the user's next-best alternative at the moment of trigger, not relative to the product's objective value. If the user perceives Google Docs as equally useful, a writing tool's perceived utility is effectively zero at that moment.
4. The 5% habitual-user threshold is diagnostic, not aspirational. If fewer than 5% of users self-trigger after three sessions, the Hook loop has failed at one specific phase — identify which phase and fix that phase only.
5. The B=MAP equation governs the Action phase absolutely. Motivation enhancement is expensive and slow; scarcest-resource friction elimination is cheap and fast. Always audit the six simplicity elements before writing motivational copy.
6. Variable rewards must remain variable. A guaranteed post-action outcome removes the dopamine-driven search state and kills return behavior. Never make the post-click experience fully predictable.
7. Investment value belongs to the user, not the product. Frame every micro-commitment (preference, quiz answer, profile field) as personalizing the user's experience. Data-collection framing destroys willingness to invest.

## LAYER 2: QUALITY GUIDANCE

1. Plot the Habit Zone before any other diagnosis. A product outside the zone wastes Hook loop design effort; redirect that effort to conversion optimization.
2. Identify the single failing Hook phase before recommending changes. Fixing all four phases simultaneously produces no usable learning about causality.
3. Use the Habit Path — the minimum action sequence shared by the top 10% of loyal users — as the optimization target for onboarding and page flow. Do not invent a path; extract it from session recordings or funnel data.
4. When survey data is unavailable, proxy perceived utility with NPS and 7-day unaided return rate; proxy frequency with weekly active user rate vs. monthly active user rate (WAU/MAU ratio target: 0.5+ for habit-forming products).
5. All recommended page changes must map to a specific Hook phase (Trigger / Action / Variable Reward / Investment) and a specific mechanism (internal trigger, simplicity element, reward category, stored-value type). Unattributed changes are not accepted.

## PURPOSE

This skill tests a single question before any Hook loop design begins: **does this behavior belong inside the Habit Zone?** It plots the page's target action on the Frequency x Perceived Utility matrix, runs the Hook loop phase-by-phase to find the first failing gate, and delivers a concrete on-page fix sequence grounded in Eyal's frameworks and Skinner's variable-ratio reinforcement logic.

**Brag line:** "Our product builds a return habit, by design."

The lever: eliminate the single scarcest friction resource blocking the first action, then follow that action with an unpredictable variable reward — not a guaranteed one — to activate dopamine-driven search mode and compel the user back without external prompting.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description (above-the-fold copy + CTA + post-click experience)
- The ONE desired action: what the page is designed to make the visitor do (opt-in / click / purchase / profile completion / etc.)

**Optional but materially improves output:**
- Analytics: 7-day return rate, WAU/MAU ratio, self-triggered vs. prompted session split
- Audience: who is the visitor, what internal emotional state brings them to this page
- Funnel position: cold traffic / warm list / re-engagement
- Competitive landscape: what is the user's next-best alternative at the moment of trigger

## EXECUTION PROCESS

### Step 1 — Habit Zone Gate (run before any other step)

Plot the target action on two axes:

| Axis | Measurement | Habit Zone Threshold |
|------|-------------|---------------------|
| Frequency | Self-triggered return sessions per week | >= 1x/week OR WAU/MAU >= 0.50 |
| Perceived Utility | User's rating vs. next-best alternative (1–10 survey) | >= 7/10 OR NPS >= 40 |

**Decision rule:**
- BOTH axes below threshold → behavior is outside the Habit Zone. Stop. Recommend single-conversion optimization. Do not design a Hook loop.
- EITHER axis at/above threshold → behavior is inside the Habit Zone. Proceed to Step 2.
- No data available → proxy: if the product category is checked daily by power users in adjacent markets (social, messaging, search, email, news), treat frequency as qualifying; if the product solves an emotional pain with no obvious free alternative, treat utility as qualifying.

**Worked proxy example:**
A SaaS dashboard for freelance invoicing. Frequency proxy: invoices are sent 2–4x/week by active freelancers → frequency qualifies. Perceived utility proxy: FreshBooks, Wave, and Google Sheets are free alternatives → utility score is contestable. Habit Zone verdict: conditional pass on frequency, utility must be proven via copy. Proceed with a utility-first Hook strategy.

### Step 2 — Internal Trigger Audit (Trigger phase)

Write the narrative sentence: *"Every time [user] feels [internal emotional trigger], they [desired action]."*

Score the current page headline and above-the-fold copy against this sentence:
- Does the copy name the internal emotional state (boredom, loneliness, uncertainty, fear, FOMO) BEFORE naming the product? Score 1 if yes, 0 if no.
- Does every CTA label imply emotional relief, not just the mechanical action? Score 1 if yes, 0 if no.
- Does owned trigger copy (email subject lines, retargeting ads) display the user's own data (their progress, their metrics, their status) within the message? Score 1 if yes, 0 if no.

**Threshold:** Score 2/3 minimum to pass. Below 2/3 → Trigger phase is the failing gate. Fix: rewrite headline to open with the emotional state; rewrite CTA labels to name the relief.

### Step 3 — Six-Element Simplicity Audit (Action phase)

For the primary CTA and its form/path, rate each of Eyal's six friction dimensions on a 1–3 scale (1 = high friction, 3 = low friction):

| # | Resource | Score 1–3 | Notes |
|---|----------|-----------|-------|
| 1 | Time | | Duration to complete |
| 2 | Money | | Fiscal cost or perceived risk |
| 3 | Physical | | Labor / clicks / scrolling |
| 4 | Brain cycles | | Cognitive load, jargon, decisions |
| 5 | Social deviance | | Is this what people like me do? |
| 6 | Non-routine | | Does this disrupt existing habits? |

**Identify the single lowest score.** That is the scarcest resource. Fix that dimension first — increasing motivation before eliminating the scarcest friction is the wrong order.

**Cold traffic default:** Brain cycles (#4) and Non-routine (#6) are almost always the lowest scores for cold traffic. Default fix: reduce form to one field, replace jargon with vernacular, add social proof normalizing the action.

**Threshold:** If any dimension scores 1, that is the first fix regardless of other dimensions.

### Step 4 — Variable Reward Diagnostic (Variable Reward phase)

Map the post-action experience to Eyal's three reward categories:

| Category | Mechanism | Example on page | Present? |
|----------|-----------|-----------------|---------|
| Tribe | Social validation, acceptance | Live member count, real-time activity feed | Y/N |
| Hunt | Unpredictable info/resource | Bonus revealed only after opt-in | Y/N |
| Self | Mastery, completion, progress | Progress bar, streak counter, inbox zero | Y/N |

**Variability test:** Is any element of the post-action experience unpredictable? If the user can fully predict what they will see after clicking, the dopamine search state does not activate.

**Threshold:** At least one reward category must be present AND at least one element must be genuinely unpredictable. If neither condition is met, Variable Reward phase is failing. Fix: introduce one surprise element on the thank-you/confirmation page (a curated bonus, a personalized result, a community reveal).

### Step 5 — Investment + Loaded Trigger Audit (Investment phase)

After the primary action, does the page ask for a small follow-on investment that:
(a) stores value in the product (content, data, followers, reputation, skill), AND
(b) loads the next external trigger (sets a preference that drives a personalized email, schedules a follow-up, etc.)?

Score: 1 if both conditions are met, 0 if either is missing.

**Threshold:** Score 1 to pass. If failing: add a single post-action micro-commitment — one preference question, one customization choice — framed as "make this yours" (user's value, not our data).

### Step 6 — Habit Path Gap Analysis

From session recordings or funnel data, identify the minimum action sequence shared by the top 10% of returning users. Compare new-user onboarding against that path.

- List every page element that is NOT on the Habit Path and is receiving attention from new users.
- Each off-path element is a candidate for removal or de-emphasis.
- Redirect new users onto the Habit Path within 3 seconds of landing (hero section must point directly at path step 1).

If no analytics are available: use the Habit Path from the nearest analogous product category as a structural template.

### Step 7 — Priority Fix Sequence

Rank failing phases by this order (the phase that fires first in the Hook loop is always fixed first):

1. Trigger (if internal trigger sentence is not embedded in copy)
2. Action (if scarcest simplicity resource scores 1)
3. Variable Reward (if post-action is fully predictable)
4. Investment (if no loaded trigger follows primary action)

Output one concrete fix per failing phase. Do not output fixes for passing phases.

## OUTPUT STRUCTURE

**1. Habit Zone Verdict**
INSIDE / OUTSIDE / CONDITIONAL — with the two-axis scores or proxies used and the decision rule applied.

**2. Hook Phase Scorecard**

| Phase | Score | Status | Primary Finding |
|-------|-------|--------|-----------------|
| Trigger | 0–3 | Pass/Fail | |
| Action | 1–3 | Pass/Fail | Scarcest resource |
| Var Reward | 0–1 | Pass/Fail | Variability present? |
| Investment | 0–1 | Pass/Fail | Loaded trigger exists? |

**3. Priority Fix Sequence**
Numbered list: one concrete change per failing phase, mapped to the specific mechanism and the exact copy/UX element to change.

**4. Internal Trigger Sentence**
The completed narrative: "Every time [user] feels [emotion], they [action on this page]." This sentence governs all copy revisions.

**5. Habit Path Delta**
Off-path elements identified + recommended disposition (remove / de-emphasize / relocate).

**6. Measurement Protocol**
Specific metrics and thresholds to track after changes are implemented (7-day return rate, WAU/MAU, self-triggered vs. prompted session split, 5% habitual-user threshold tracking).

## WORKED MINI-EXAMPLE

**Page:** Email opt-in landing page for a weekly AI tools newsletter. Desired action: subscribe.

**Step 1 — Habit Zone Gate:**
Frequency proxy: newsletters are checked 3–5x/week by active subscribers (industry data) → qualifies. Perceived utility: dozens of free AI newsletters exist → contested. Conditional pass. Strategy: lead with perceived utility gap in copy.

**Step 2 — Trigger Audit (Score: 1/3):**
Current headline: "The Best AI Tools, Curated Weekly." Names the product, not the emotion. No emotional state named. CTA says "Subscribe." No relief implied. Owned trigger: not yet in scope (no existing list). Score: 1/3. FAIL.
Fix: Rewrite headline to "Drowning in AI noise? Every Friday, one email cuts through it." Rewrite CTA to "Send Me Friday's Shortlist."

**Step 3 — Simplicity Audit:**
Brain cycles score: 1 (visitor must evaluate whether this newsletter is worth an inbox slot — high cognitive cost with no proof). Fix: add one-sentence social proof above fold — "11,400 operators already unsubscribed from everything else."

**Step 4 — Variable Reward:**
Current post-opt-in: standard confirmation page, fully predictable. No variability. FAIL.
Fix: On confirmation page, reveal one "this week's #1 tool" with a brief tease — unpredictable from session to session, creates Hunt reward.

**Step 5 — Investment:**
No post-opt-in micro-commitment. FAIL.
Fix: After confirmation, ask one question: "Which AI use case matters most to you right now?" (options: writing / research / automation / hiring). Answer personalizes the next email and loads an owned trigger with the subscriber's stated priority.

**Before:** Generic feature-forward headline → Subscribe CTA → Standard confirmation.
**After:** Emotion-first headline → Social-proof normalized CTA → Variable reward reveal → Personalization micro-commitment loading next trigger.

**Projected impact:** 7-day return rate improvement (users self-open the personalized email rather than waiting for a reminder); WAU/MAU ratio moves from estimated 0.3 toward 0.5 threshold within 60 days.

## OUTPUT FILE

Save to: [project-folder]/Eyal - Click Architecture/[YYYY-MM] - Habit Zone Test - [Page Name].md
