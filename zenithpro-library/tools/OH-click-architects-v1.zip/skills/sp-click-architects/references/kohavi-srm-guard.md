---
name: kohavi-srm-guard
description: Use when an A/B test result looks suspicious, traffic splits feel off, or before trusting any conversion lift claim — detects Sample Ratio Mismatch and data-quality red flags that invalidate experiment results before you act on them.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Ronny Kohavi (Trustworthy Online Controlled Experiments 2020; Seven Rules of Thumb 2014; Sample Ratio Mismatch 2009-2020) — Click Architecture (Skill 3 of 7)"
interface:
  invoke: "/kohavi-srm-guard"
  calls: []
  called_by: [user, kohavi-field-intelligence, kohavi-experiment-validity-auditor]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic routing logic, bot-filter rules, and instrumentation configs change frequently; SRM root-causes found in one audit may be fixed or re-introduced within weeks."

kohavi_cluster_integration:
  feeds_from: [kohavi-oec-definer, kohavi-experiment-validity-auditor]
  feeds_to: [kohavi-twyman-anomaly-detector, kohavi-rollout-decision-architect]
  shared_data: "SRM p-value, confirmed root-cause category, corrected vs. raw metric delta, guardrail-metric breach flags"

eisenberg_integration:
  feeds_from: [eisenberg-field-intelligence]
  feeds_to: [eisenberg-conversion-trinity-builder]
  shared_data: "Which funnel stages are instrumented cleanly vs. have lossy logging; SRM-safe segments to trust for persona-pathway analysis"

kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: [kahneman-framing-engineer]
  shared_data: "Validated (SRM-free) metric deltas that can be safely reframed using loss-aversion or prospect-theory copy changes; contaminated results flagged as not safe to act on"
---

# Kohavi SRM Guard — Data Quality Firewall for A/B Test Results

## LAYER 1: INVARIANTS (Never override.)

1. **SRM = stop everything.** When p < 0.001 on the chi-squared ratio test, hide the scorecard immediately. Drawing conclusions from an SRM-contaminated result is epistemically invalid regardless of how promising the lift looks.
2. **p < 0.05 requires investigation, not just a warning.** At the 0.05 threshold, run all 40+ root-cause categories before proceeding. At p < 0.001, escalate to engineering before touching copy or design.
3. **Guardrail metrics are hard gates, not advisory.** If latency, error rate, or crash rate degrades in treatment — halt the experiment. The coupon-field case: treatment 1 (-2.8% revenue, p=0.0003) and treatment 2 (-7.8% revenue, p=1.5E-23) were both correctly killed by the revenue guardrail. No amount of OEC improvement overrides a violated guardrail.
4. **Trust-invariant metrics must not move.** Cache-hit rates, bot-filter rates, and the control/treatment user ratio are invariants: if they shift, the experiment is corrupted, not informative.
5. **Never interpret progressive-ramp data as a final result.** Early ramp (first 72 hours) oversamples frequent, Wi-Fi users. True population signal emerges only after 1 full week minimum; 2 weeks for novelty-effect separation.
6. **Trigger-analysis scope must match claim scope.** You cannot report a page-level conversion lift if your analysis includes non-triggered users (visitors who never saw the variant element). Segment or retract.
7. **Practical significance threshold must be set before seeing data.** Post-hoc threshold selection is p-hacking. If the pre-defined minimum meaningful effect (e.g., 1% revenue) is not met, do not launch — even if stat sig.

## LAYER 2: QUALITY GUIDANCE

1. Cap reported metrics at 5 per experiment. With 10 independent metrics, the probability that at least one is spuriously significant is ~40%. Report only pre-registered metrics; move the rest to a debug-only appendix.
2. Run an A/A test before any A/B test on a new instrumentation stack. If the A/A produces p < 0.05 on the primary metric, the instrumentation is broken — fix it before spending a single dollar on traffic.
3. Document the SRM root-cause category even when p > 0.05. Marginal ratios (0.98-1.02) with no SRM flag still deserve a logged hypothesis so the pattern can be detected across experiments.
4. Use chi-squared for ratio checks, not visual inspection. A 50.2%/49.8% split looks fine; at N=500,000 it may be flagged at p=0.0003.
5. Correct for SRM only if the root cause is confirmed and correctable (e.g., re-filtering bots); otherwise discard the result entirely and rerun.

## PURPOSE

This skill does one job on a real A/B test (or claimed A/B test result) tied to a specific page and desired action: it determines whether the data can be trusted before anyone acts on it.

Kohavi's research across Microsoft, Amazon, Google, and LinkedIn shows SRM occurs in **6-10% of all A/B tests**. The MSN case is the canonical example: a 0.992 treatment ratio (p=1.8E-6) made a result look like a -3.3% engagement drop; after correcting the SRM, the true effect was +3.3% — a **6.6 percentage point swing caused purely by corrupted traffic assignment**. Acting on the raw result would have reversed the correct launch decision.

Beyond SRM, this skill catches the full suite of data-quality red flags: instrumentation loss, bot-filter asymmetry, bad hash functions, browser-redirect differentials, and guardrail-metric breaches — any of which can flip a result.

**Brag line: "We know our winner is real, not a 1-in-20 false positive."**

## INPUT REQUIREMENTS

**Required:**
- The page under test (URL, screenshot, or written description)
- The ONE desired action being optimized (click, opt-in, purchase, next step)
- Experiment configuration: designed split ratio (e.g., 50/50), actual observed user counts per variant, experiment duration
- Primary metric value + p-value as reported by the testing platform

**Strongly recommended:**
- Raw user counts by variant (not just percentages)
- Guardrail metric readings (latency, error rate, crash rate)
- Instrumentation stack (client-side JS, server-side log, or third-party tag)
- Whether progressive ramp was used and current ramp percentage
- List of all reported metrics (to check for multiple-testing inflation)

**Optional:**
- Trigger analysis scope definition (triggered vs. all exposed users)
- Bot-filter methodology
- Hash function used for assignment

## EXECUTION PROCESS

### Step 1 — Compute the SRM p-value

Given designed ratio R (e.g., 0.5 for 50/50) and observed counts N_c (control) and N_t (treatment):

```
Total N = N_c + N_t
Expected_c = N × R
Expected_t = N × (1 - R)
chi_sq = (N_c - Expected_c)² / Expected_c + (N_t - Expected_t)² / Expected_t
p = chi_squared_survival(chi_sq, df=1)
```

Observed ratio = N_t / N (report as decimal, e.g., 0.992).

**Thresholds:**
- p ≥ 0.05 → no SRM detected; proceed to Step 3
- 0.001 ≤ p < 0.05 → SRM suspected; flag, investigate all root-cause categories (Step 2), do not publish result yet
- p < 0.001 → SRM confirmed; **hide scorecard immediately**; escalate to engineering

### Step 2 — Root-Cause Triage (when p < 0.05)

Work through these four root-cause categories in order. Stop and document the first confirmed cause.

| Cat | Root-Cause Family | How to Check |
|-----|-------------------|--------------|
| A | Bad hash / assignment bug | Re-hash user IDs in test env; check for modulo bias |
| B | Bot / crawler asymmetry | Compare bot-flagged % by variant; check User-Agent distributions |
| C | Browser redirect differential | Compare redirect chains; treatment extra redirect = lost users |
| D | Lossy instrumentation | Compare server-logged vs. client-logged user counts per variant |

If root cause is confirmed in Cat D (instrumentation loss): correct by switching to server-side counts, then recompute all metrics. If Cat A or B: discard and rerun. If Cat C: fix redirect logic before rerunning.

**40+ known SRM causes exist.** The above four are the highest-frequency. Log all checked categories even when none is confirmed (marginal cases recur).

### Step 3 — Guardrail Metric Check

For each guardrail metric (latency p99, error rate, crash rate, revenue if revenue is a guardrail):

```
Guardrail breach = |treatment_value - control_value| / control_value > threshold
```

Typical thresholds: latency +5%, error rate +10%, crash rate any increase.

**If any guardrail breaches:** halt experiment regardless of OEC result. Document breach metric, magnitude, and p-value.

### Step 4 — Trust-Invariant Check

Confirm these metrics did NOT move between variants:
- Cache-hit rate differential < 0.5%
- Bot-filter rate differential < 0.5%
- Geographic distribution KL-divergence < 0.02
- Device-type distribution chi-sq p > 0.10

If any trust-invariant moved: record as SRM-adjacent corruption. Escalate to engineering.

### Step 5 — Multiple-Testing Inflation Check

Count reported metrics (M). Compute family-wise false-positive risk:

```
FWER = 1 - (1 - 0.05)^M
```

| M | FWER |
|---|------|
| 1 | 5% |
| 5 | 23% |
| 10 | 40% |
| 20 | 64% |

If M > 5 and no Bonferroni/BH correction was applied: flag. Require pre-registration of primary metric. Demote remaining to debug-only.

### Step 6 — Trigger Scope Validation

Ask: were all analyzed users actually exposed to the variant element?

- If yes, and triggered population = analyzed population: scope is clean.
- If no (e.g., all page visitors analyzed but variant only shown on checkout): trigger-isolation required.

**Dilution formula:** If triggered fraction = f and triggered effect = E, then aggregate observed effect ≈ f × E. A 10% effect on 5% of users appears as ~0.5% aggregate — easy to miss or misattribute.

Require: re-run analysis on triggered-only population. Report both figures.

### Step 7 — Practical Significance Gate

Compare the confirmed metric delta (post-SRM-correction if applicable) against the pre-defined minimum meaningful effect (MME).

```
Launch if: stat_sig AND |delta| >= MME
Rerun if: not stat_sig AND CI excludes MME (need more users)
Abandon if: stat_sig AND |delta| < MME (real but too small to matter)
```

Per Kohavi's Experiment Launch Decision Matrix, statistical significance alone is not sufficient. Report the scenario number (1-6) the result falls into.

### Step 8 — Novelty Effect Screen

If experiment has been running: plot primary metric over time by day.

- Monotone plateau after day 3-4 → stable signal, report result.
- Metric still rising at day 7 → users still adapting; extend run.
- Metric peaked and declining → novelty effect; true long-run effect is lower than peak. Require 2+ week run before concluding.

## OUTPUT STRUCTURE

**Section 1 — SRM Verdict**
- Observed ratio, chi-sq statistic, p-value, threshold crossed (none / warning / confirmed)
- Root cause if identified (category + specific mechanism)
- Recommended action: proceed / investigate / halt / discard-and-rerun

**Section 2 — Guardrail Status**
- Table: each guardrail metric, control value, treatment value, delta %, breach threshold, status (OK / BREACHED)

**Section 3 — Trust-Invariant Status**
- Table: each invariant checked, delta observed, pass/fail

**Section 4 — Multiple-Testing Report**
- M metrics reported, FWER, pre-registered primary metric Y/N, correction applied Y/N

**Section 5 — Trigger Scope Finding**
- Trigger fraction, raw vs. trigger-corrected effect estimate

**Section 6 — Launch Decision**
- Scenario number (1-6 from Kohavi matrix), stat sig Y/N, practical sig Y/N, MME used
- Final verdict: LAUNCH / ITERATE / RERUN / HALT

**Section 7 — Fix-Before-Rerun Checklist**
- Ordered list of issues to resolve before the next experiment run

## WORKED MINI-EXAMPLE

**Page:** SaaS pricing page. Desired action: click "Start Free Trial."

**Reported result:** Control = 48,200 users; Treatment = 51,800 users. Designed 50/50 split. Platform reports +4.1% trial starts, p=0.031.

**Step 1 — SRM check:**
```
N = 100,000; Expected each = 50,000
chi_sq = (48200-50000)²/50000 + (51800-50000)²/50000
       = (3,240,000 + 3,240,000) / 50,000 = 129.6
p ≈ 4.1E-30  →  SRM CONFIRMED
```
Observed ratio = 0.518 (vs. designed 0.500). Result is invalid. Scorecard hidden.

**Step 2 — Root cause:** Treatment variant added a JavaScript redirect for the new hero section. Cat C confirmed. Treatment loses ~3,600 users who bounce before the redirect completes on slow connections.

**Corrected action:** Remove redirect, implement variant server-side. Rerun experiment. The reported +4.1% lift cannot be trusted — it reflects over-representation of fast-connection users in treatment, not a real conversion improvement.

**Before:** Team prepares to ship the new hero. Revenue impact projected at +$180K/mo.
**After:** SRM guard blocks the launch. Engineering fixes redirect. Rerun shows +1.1% (p=0.04), practical sig threshold was 2% → Scenario 3 (stat sig, not pract sig) → do not launch.

Net outcome: avoided shipping a change that appeared to work but didn't meet the bar, and identified a redirect bug that was corrupting all future experiments on this page.

## OUTPUT FILE

Save to: [project-folder]/Kohavi - Click Architecture/[YYYY-MM] - SRM Guard Audit - [Page Name].md
