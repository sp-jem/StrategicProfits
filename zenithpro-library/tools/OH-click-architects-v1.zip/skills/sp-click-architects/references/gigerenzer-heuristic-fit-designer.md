---
name: gigerenzer-heuristic-fit-designer
description: Use when a page is overloaded with data, features, or statistics and conversion is stalling — designs the page environment to FIT the visitor's natural decision heuristics instead of fighting them.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Gerd Gigerenzer (Simple Heuristics That Make Us Smart, 1999; Ecological Rationality, Adaptive Toolbox, Take-the-Best, Natural Frequencies) — Click Architecture (Skill 1 of 7)"
interface:
  invoke: "/gigerenzer-heuristic-fit-designer"
  calls: []
  called_by: [user, gigerenzer-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page statistics, proof point rankings, and competitive recognition signals rotate — what was the highest-validity cue 6 weeks ago may no longer be the strongest discriminator."

gigerenzer_siblings_integration:
  feeds_from: [gigerenzer-field-intelligence]
  feeds_to: [gigerenzer-take-the-best-sequencer, gigerenzer-recognition-cue-architect, gigerenzer-less-is-more-auditor]
  shared_data: "Cue validity rankings, option count audit, recognition signal inventory — pass these outputs to sibling skills to avoid re-auditing the same page."

iyengar_integration:
  feeds_from: [iyengar-choice-set-auditor]
  feeds_to: [iyengar-choice-set-auditor]
  shared_data: "Option overload diagnosis — iyengar-choice-set-auditor counts options; this skill explains WHY reduction improves conversion (Fast-and-Frugal Tree model) and how to order the remaining options by cue validity."

kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: [kahneman-framing-engineer]
  shared_data: "Probability vs. frequency framing — kahneman surfaces anchoring/framing candidates; this skill converts those candidates to natural frequency formats grounded in Gigerenzer's 7.1 odds-ratio finding."

pirolli_integration:
  feeds_from: [pirolli-scent-trail-auditor]
  feeds_to: [pirolli-scent-gradient-designer]
  shared_data: "Information foraging path — pirolli maps where visitors search; this skill aligns the cue ordering (Search Rule of Adaptive Toolbox) with the scent trail so the highest-validity cue intercepts foragers at first contact."
---

# Gigerenzer Heuristic-Fit Designer

## LAYER 1: INVARIANTS (Never override.)

1. **Ecological Rationality test first.** A heuristic is only as good as its environmental fit. Before recommending any change, map the actual information structure the visitor faces (options count, cue order, stat formats). A page that violates the visitor's natural toolkit is irrational regardless of its feature density.

2. **One discriminating cue leads.** The Adaptive Toolbox Search Rule requires cues ordered by validity, one at a time. The highest-validity cue must appear FIRST, ALONE, above any list of secondary claims. Never bury the best reason in a bullet cluster — Take-the-Best stops at the first discriminating cue and decides.

3. **Natural frequencies, never bare percentages.** Gigerenzer and Hoffrage (1995): 24% correct Bayesian inference under natural frequency format vs. 4% under probability format — odds ratio 7.1. Every stat on the page must be converted. No exceptions. "80% success rate" is prohibited; "8 of 10 customers achieved X" is required.

4. **Reference class explicit.** Every absolute count must state its denominator. "1 in 5" without a stated population is manipulable. State the reference class: "1 in 5 customers who applied the protocol in 90 days."

5. **Option count caps enforce Fast-and-Frugal Tree logic.** Each visible choice node must offer the visitor an exit (action). Cap pricing tiers at 3; cap features displayed before first CTA at the minimum discriminating set (often 1-3). Options beyond this force the visitor out of fast-and-frugal mode into exhaustive search — where competing exits multiply.

6. **Recognition before conversion.** The Recognition Heuristic fires on recognition vs. non-recognition. If the visitor does not yet recognize the brand/product, the heuristic cannot discriminate in your favor. Recognition signals (known media logos, partner names, familiar faces) must precede the CTA — not follow it.

7. **Boosting over nudging.** Gigerenzer (2015): a boost is transparent and autonomy-preserving; a nudge exploits blindspots. Write copy that gives the visitor the one cognitive tool (the right comparison frame, the right question) to see clearly why action is right for them — do not engineer confusion to force compliance.

---

## LAYER 2: QUALITY GUIDANCE

1. **Validity score the cues.** Before writing the page diagnosis, rank every proof point, testimonial, stat, and claim by its discriminating power for THIS visitor segment. "Validity" = P(correct decision | cue) across the realistic distribution of visitors. The highest-validity cue is not the longest stat — it is the one that most reliably separates "will act" from "won't act."

2. **Test the stopping rule.** After arranging cues in validity order, ask: at which cue would a rational visitor using Take-the-Best stop and decide? If the stopping rule fires before the CTA, you pass. If the page's design forces the visitor to read all 12 features before the CTA appears, the stopping rule is sabotaged.

3. **Less-Is-More Effect check.** If the brand is already recognized by this visitor segment, additional feature detail can HURT conversion by shifting the visitor from recognition-heuristic mode to analytical mode, where less-recognized competitors can compete on specs. Diagnosed by audience familiarity × page feature density matrix (see Step 5 below).

4. **Uncertainty vs. risk framing.** Distinguish Risk (all alternatives and probabilities known — use stats freely) from Uncertainty (alternatives or probabilities unknown — heuristics outperform, complexity misleads). For visitors new to the category, feature-dense comparison tables create false precision and delay the stopping rule. Simplify under uncertainty.

5. **Satisficing threshold explicit.** The page should state a clear satisficing threshold — the minimum condition under which acting is the right call. This fires the visitor's stopping rule at the CTA. "If you need to [outcome], this is enough" is the satisficing frame.

---

## PURPOSE

This skill audits a web page for mismatches between the page's information architecture and the visitor's natural decision heuristics (Gigerenzer's Adaptive Toolbox), then outputs a concrete redesign spec.

The primary lever: most pages defeat their own conversion by front-loading feature lists, probability stats, and option arrays — the very formats that disrupt fast-and-frugal heuristics and force exhaustive search. Gigerenzer's empirical finding is that Take-the-Best (one cue, highest validity first, stop) matched or beat multiple-regression on out-of-sample prediction while using fewer than half the cues. The same principle applies on-page: the single highest-validity cue, leading alone, outperforms a feature compendium.

**Brag line: "We design WITH the mental shortcuts instead of fighting them."**

---

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written section-by-section description
- The ONE desired action (e.g., "click Add to Cart," "submit opt-in form," "book call")

**Strongly recommended:**
- Visitor segment: first-time vs. returning, category-aware vs. new, warm list vs. cold traffic
- Funnel position: top-of-funnel awareness page, product page, checkout, post-opt-in VSL
- Current conversion rate and primary drop-off point if known

**Optional:**
- Heatmap / scroll data showing where attention collapses
- Existing A/B test results

---

## EXECUTION PROCESS

### Step 1 — Environment Audit (Ecological Rationality map)

List every information element the visitor encounters in scroll order:
- Header/hero claim
- Statistics and proof points (note format: % or frequency)
- Options/tiers visible before first CTA
- CTA position (what cue immediately precedes it?)
- Social proof / recognition signals and their position
- Total word count above fold vs. below

Output: an ordered inventory of elements, tagged by type (Cue / Option / Recognition Signal / Stat / CTA).

### Step 2 — Cue Validity Ranking

Rank every proof point and claim by estimated validity for this visitor segment.
Validity proxy: which single piece of evidence, if known first and alone, would most reliably produce the desired action?

Scoring rubric (0-3):
- 3: Recognized brand authority, category-specific outcome stat in natural frequency, expert endorsement the segment trusts
- 2: Customer testimonial with named outcome, media logo recognition, specific result with reference class
- 1: Generic feature claim, relative % stat, unnamed social proof
- 0: Filler copy, feature that does not discriminate this segment from alternatives

Report the top-3 cues by validity score. Flag which cue currently occupies the lead position on the page.

### Step 3 — Natural Frequency Conversion

For every percentage, relative risk, or probability claim on the page, apply the conversion formula:

  Natural frequency = "[X] of [N] [reference class]"
  N should be the smallest round number that preserves the ratio and states the actual population.

Example conversions:
  "80% success rate" -> "8 of 10 customers who completed the 90-day protocol"
  "20% faster results" -> "4 weeks faster on average across 50 tracked members"
  "Reduces risk by 33%" -> "Drops from 3 in 10 to 2 in 10 for [specific risk]"

Report: table of original stat | natural frequency rewrite | reference class stated (Y/N)

Format: 3 columns max.

| Original | Rewrite | Ref Class |
|---|---|---|
| [stat] | [NF version] | Y/N |

### Step 4 — Fast-and-Frugal Tree Diagnosis

Map the page as a decision tree. Each node = one visible choice or discriminating question the visitor faces. Each branch = continue reading vs. exit (act or leave).

Diagnosis criteria:
- Does an action exit exist at each node? (Pass/Fail)
- Is the first node the highest-validity cue? (Pass/Fail)
- How many nodes does the visitor traverse before reaching the CTA? (Target: 1-3)
- Are there orphan nodes (features/options with no exit attached)? List them.

Flag: if node count before CTA > 3, the page is forcing exhaustive search. Recommend collapsing or reordering.

### Step 5 — Recognition + Less-Is-More Check

Estimate visitor recognition level: High / Medium / Low for this brand/product.

- High recognition + high feature density = LIME risk (Less-Is-More Effect). Recommendation: strip features; let recognition do the work. Do not dilute the heuristic by shifting visitors to analytical mode.
- Low recognition + sparse social proof = Recognition Heuristic cannot fire. Recommendation: add recognition signals (media logos, partner names, known testimonial sources) BEFORE the CTA. Recognition is a prerequisite.
- Medium recognition: balance — one recognition signal in hero, then highest-validity cue, then minimal feature set.

### Step 6 — Satisficing Threshold Copy

Write one satisficing frame for the CTA section:
  "If you need [stated outcome threshold], this is enough to decide."

This explicitly fires the visitor's stopping rule at the CTA rather than sending them to "research more."

### Step 7 — Redesign Spec

Produce a prioritized change list:

Priority A (heuristic-breaking): changes that, left unresolved, prevent Take-the-Best or Recognition Heuristic from firing.
Priority B (amplifying): changes that accelerate the stopping rule once A-items are fixed.
Priority C (polish): natural frequency conversions and copy tightening that improve comprehension without restructuring.

For each change: element | current state | recommended state | mechanism (which Gigerenzer framework this activates).

Table: 4 columns.

| Element | Current | Recommended | Mechanism |
|---|---|---|---|

---

## OUTPUT STRUCTURE

1. **Environment Audit** — scroll-order inventory, tagged
2. **Cue Validity Rankings** — top 3 cues with validity scores, current lead cue identified
3. **Natural Frequency Conversion Table** — all stats rewritten, reference classes stated
4. **Fast-and-Frugal Tree Diagram** — node map, action exits, node count to CTA
5. **Recognition + LIME Assessment** — recognition level, risk flag, recommendation
6. **Satisficing Threshold Copy** — one ready-to-use line for the CTA section
7. **Redesign Spec** — Priority A / B / C change list with mechanism column

---

## WORKED MINI-EXAMPLE

**Page:** SaaS product landing page. Desired action: start free trial.

**Current hero (before):**
> "Trusted by 10,000+ teams. 47% faster onboarding. 3x more integrations. 99.9% uptime. SOC 2 certified. 14-day free trial."

**Problems diagnosed:**
- Lead cue: "Trusted by 10,000+ teams" — validity score 2 (no reference class, no segment specificity)
- "47% faster onboarding" — bare relative %, reference class unstated
- 6 claims before CTA — Fast-and-Frugal Tree has 6 nodes, no action exit until final line
- Recognition signals: none (no logos, no named customers)

**Rewritten hero (after):**
> [Row of 3 recognized customer logos — fires Recognition Heuristic]
>
> "47 of 100 teams cut onboarding from 3 weeks to under 2 days in their first quarter."
>
> [CTA: Start free trial]
>
> — If you need your team running in under 2 days, this is enough to decide.

**Changes applied:**
- Recognition signals added before CTA (Step 5)
- "47% faster" converted to natural frequency with reference class (Step 3)
- Nodes before CTA: 6 -> 2 (logos + one natural frequency stat) (Step 4)
- Satisficing threshold stated (Step 6)
- Lead cue is now the highest-validity cue for this segment: outcome + natural frequency (Step 2)

---

## OUTPUT FILE

Save to: [project-folder]/Gigerenzer - Click Architecture/[YYYY-MM] - Heuristic Fit Design.md
