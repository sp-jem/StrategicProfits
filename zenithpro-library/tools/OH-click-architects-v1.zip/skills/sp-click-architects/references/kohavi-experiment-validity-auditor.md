---
name: kohavi-experiment-validity-auditor
description: Use when you're about to read, act on, or kill an A/B test result — audits the test for peeking, novelty/primacy, instrumentation drift, and segment leakage before a ship decision is made.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Ronny Kohavi (Trustworthy Online Controlled Experiments, 2020; Seven Rules of Thumb 2014; SRM Check, Guardrail Metrics Framework) — Click Architecture (Skill 2 of 7)"
interface:
  invoke: "/kohavi-experiment-validity-auditor"
  calls: []
  called_by: [user, kohavi-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic composition, instrumentation stacks, and bot-filter logic shift. An SRM pass from six weeks ago may not hold today."

kohavi_srm_guard_integration:
  feeds_from: kohavi-srm-guard
  feeds_to: kohavi-rollout-decision-architect
  shared_data: "p-value and actual vs. expected variant split ratios; SRM status gates whether validity audit can proceed to launch decision"

kohavi_oec_definer_integration:
  feeds_from: kohavi-oec-definer
  feeds_to: kohavi-twyman-anomaly-detector
  shared_data: "Defined OEC formula and guardrail metric thresholds; validity audit checks whether the running experiment is actually measuring the OEC that was pre-specified"

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: kahneman-framing-engineer
  shared_data: "Novelty-effect timeline and peak-end curve; Kahneman peak-end framing decisions should only be tested after novelty decay is confirmed (≥2 weeks runtime)"
---

# Kohavi Experiment Validity Auditor

## LAYER 1: INVARIANTS (Never override.)

1. **Never read a scorecard until SRM is cleared.** If the actual traffic split deviates from the designed ratio at p < 0.001 (chi-squared or binomial), hide all metric results and investigate root cause before touching any conversion number.
2. **A winning p-value alone is not a ship signal.** Practical significance must be pre-defined before seeing data (e.g., "minimum 1% revenue lift"). Stat sig + not pract sig = do NOT launch. This is Kohavi's Decision Matrix Scenario 3.
3. **Novelty and primacy effects are threats, not features.** If the primary metric is still trending upward at experiment end, the experiment is not done — users are still adapting. Declare no winner.
4. **Guardrail violations halt the experiment, full stop.** If latency, crash rate, error rate, or revenue guardrail is breached — even with a positive OEC result — halt and investigate. The coupon field experiment killed two "winning" treatments because both violated the revenue guardrail.
5. **Triggered population only, always.** Analyze users who were actually exposed to the variant element, not all page visitors. Aggregate dilution destroys effect detectability.
6. **Run minimum one full week.** Day-of-week effects (weekend vs. weekday behavior) invalidate shorter runtimes. New UI elements require ≥2 weeks to separate novelty signal from steady-state adoption.
7. **Cap at ~5 key metrics per experiment.** With 10 independent metrics, there is a 40% chance at least one is significant by chance (α=0.05). Each additional metric inflates false discovery rate multiplicably.

## LAYER 2: QUALITY GUIDANCE

1. **Flag every validity threat explicitly before delivering a verdict.** A clean SRM pass with a novelty problem is still an invalid experiment. Surface all threats; let the team decide which to accept.
2. **Quantify leakage before dismissing it.** Segment leakage (treatment users appearing in control counts, or vice versa) invalidates intent-to-treat analysis. Compute crossover rate; anything above 1% requires trigger-analysis correction.
3. **Document instrumentation assumptions.** Cache-hit rates, bot-filter rates, and SDK version distribution should be treated as invariant guardrail metrics. If any shift during the experiment window, the instrumentation has drifted.
4. **Pre-specify the minimum detectable effect (MDE) and required N before running.** Kohavi's Rule of Thumb 7: ~200,000 users minimum to detect a 5% effect. Under-powered experiments produce noisy estimates even when stat sig is reached by peeking.
5. **Check for interaction between novelty effect and segment composition.** Frequent/Wi-Fi users are overrepresented in the first 48–72 hours of a progressive ramp; their behavior differs from the full population. Do not call early ramp data representative.

## PURPOSE

This skill takes a real page experiment — identified by URL, screenshot, or written description, with a stated desired action (click, opt-in, purchase, next-step) — and audits the running or completed test against Kohavi's four canonical validity threats: **peeking**, **novelty/primacy effects**, **instrumentation drift**, and **segment leakage**. It applies the SRM Check, Guardrail Metrics Framework, Decision Matrix, and Trigger Analysis to produce a structured go/no-go signal with the exact remediation step for each threat found.

**Brag line:** "We know our winner is real, not a 1-in-20 false positive."

This is the validity gate between experiment execution (handled by kohavi-srm-guard and kohavi-oec-definer) and the launch decision (handled by kohavi-rollout-decision-architect). Its job is to surface every reason the result might be wrong before anyone acts on it.

## INPUT REQUIREMENTS

**Required:**
- The page under test (URL, screenshot, or written description)
- The ONE desired action being optimized (e.g., "checkout completion," "email opt-in," "CTA click")
- Experiment design: variant count, designed split ratio, start date, end date or current runtime
- Reported result: primary metric delta, p-value, confidence interval

**Strongly recommended:**
- Actual vs. designed traffic split (to run SRM check)
- Time-series chart of the primary metric across experiment duration
- Guardrail metric values (latency, error rate, crash rate, revenue per user if not primary metric)
- Triggered vs. total user counts if trigger analysis was applied
- Number of metrics on the scorecard

**Optional:**
- Segment breakdown (device, geography, new vs. returning)
- Instrumentation version during experiment window
- Bot-filter rate before and after experiment start

## EXECUTION PROCESS

### Step 1 — SRM Check (Instrument Before Metrics)

Compute: χ² = Σ (Observed_i − Expected_i)² / Expected_i across all variants.

For a 50/50 two-variant test with n_control and n_treatment:
- Expected each = (n_control + n_treatment) / 2
- χ²(1 df): p < 0.001 → STOP, hide scorecard, investigate
- p < 0.05 → FLAG, proceed with caution, document assumption

**Known SRM causes to check on this page:** redirect chains (landing page redirects before pixel fires), bot-filtering running post-assignment, lossy instrumentation (JavaScript error before event fires), cache serving stale variant to returning users.

**MSN precedent:** a 0.992 actual/expected ratio (p=1.8E-6) flipped results from −3.3% to +3.3% engagement once corrected. The result direction inverted. Never skip this step.

### Step 2 — Peeking Check

Peeking = stopping the experiment early because p < 0.05 was reached, without pre-specified stopping rules.

Check:
- Was a fixed sample size or runtime pre-specified before the experiment launched? If no → peeking risk is HIGH.
- Was the reported p-value computed at a single look or at multiple looks? If multiple → apply Bonferroni or sequential testing correction.
- Peeking inflates false positive rate dramatically: checking daily at α=0.05 over 20 days produces a ~64% false positive rate for a true null effect.

**Threshold:** If no pre-specification exists and the experiment was stopped when it "looked good," downgrade confidence to exploratory. Do not ship based on this result without re-running with a pre-registered stopping rule.

### Step 3 — Novelty / Primacy Effect Check

Novelty = temporary metric lift from users exploring a new UI, not from genuine preference change.
Primacy = temporary metric drop from users annoyed by a changed familiar interface.

Diagnosis protocol:
1. Plot primary metric by day (or week) across experiment runtime.
2. Novelty signature: metric starts HIGH, declines toward baseline over time.
3. Primacy signature: metric starts LOW, recovers over time.
4. Healthy steady-state: metric is flat within ±noise band after day 3–4.

**Rule:** If the metric is still trending (up or down) at experiment end, extend the runtime. Minimum signal window = the portion of the time-series where the metric is flat. Kohavi's documented case: Instagram-style ad format showed 28% CTR initially, then declined sharply as novelty dissipated — the "winner" was an artifact.

For new UI elements on this page, flag if runtime < 14 days regardless of trend.

### Step 4 — Instrumentation Drift Check

Instrumentation drift = the measurement system changed during the experiment, making early and late data incomparable.

Check for:
- SDK or tag manager version deploy during experiment window
- Bot-filter rule changes (new bot signatures added mid-flight)
- Cache-hit rate shift (CDN config change, cache invalidation event)
- A/A test result: run a concurrent or historical A/A; if p < 0.05 on a metric that should not move, instrumentation is suspect

**Guardrail metric proxy for drift:** cache-hit rate and bot-filter rate are Kohavi's "trust-related invariant" guardrails — they should not change. If they shifted >2% during the window, flag instrumentation drift.

**Severity scoring:**
- Drift confirmed → result is invalid, re-instrument and re-run
- Drift suspected (single indicator) → add as caveat, widen confidence interval mentally
- No evidence of drift → pass

### Step 5 — Segment Leakage Check

Leakage = users assigned to one variant are being counted in another, or triggered-population analysis was not applied and dilution is masking the real effect.

Check:
1. Crossover rate: % of users whose variant assignment changed during the experiment (cookie deletion, device switching without ID stitching). Acceptable: <1%. Above 1%: flag.
2. Trigger analysis applied? If the page element only shows to a subset of visitors (e.g., a checkout upsell, a modal that fires on scroll-depth), was analysis scoped to triggered users only?
   - If not: apply the segment dilution formula → actual_impact = triggered_fraction × measured_delta.
   - Example: 8% of visitors reach checkout; checkout CTA variant shows +12% lift; aggregate page impact = 0.08 × 12% = 0.96% — not 12%.
3. Holdout contamination: if a "holdout group" was used, confirm they received zero treatment exposure (no logged-in cross-device exposure, no email with variant content).

### Step 6 — Guardrail Metric Review

For each organizational guardrail (latency p75/p99, crash rate, error rate, revenue per user if separate from OEC):
- Was each guardrail pre-specified with a bound (e.g., "p99 latency must not increase >50ms")?
- Did any guardrail breach its bound during the experiment window?

**Coupon field precedent:** Treatment 1 (field below credit card) = −2.8% revenue (p=0.0003), Treatment 2 (popup) = −7.8% revenue (p=1.5E−23). Both passed primary metric; both were killed because revenue was the guardrail. Guardrails are non-negotiable.

### Step 7 — Decision Matrix Classification

Cross the audit results against Kohavi's six-scenario matrix:

| Scenario | Stat Sig? | Pract Sig? | Verdict |
|----------|-----------|------------|---------|
| 1 | No | No | Iterate or abandon |
| 2 | Yes | Yes | LAUNCH |
| 3 | Yes | No | Do NOT launch |
| 4 | No | Outside CI | Re-run, more users |
| 5 | Yes | Likely yes | Launch (acceptable risk) |
| 6 | No | Inside CI | Re-run with more power |

Legend: Stat Sig = p < pre-specified α; Pract Sig = delta exceeds pre-defined MDE threshold; CI = confidence interval.

Apply Scenario only after Steps 1–6 pass. If any step fails, the experiment result is invalid and no Scenario applies until the failure is resolved.

## OUTPUT STRUCTURE

**Section 1 — Experiment Identity**
Page URL / description, desired action, variant count, runtime, designed split.

**Section 2 — Validity Audit Scorecard**

| Check | Status | Evidence | Severity |
|-------|--------|----------|----------|
| SRM | Pass/Fail/Flag | χ² p-value, actual split | High/Med/Low |
| Peeking | Pass/Fail/Flag | Pre-spec exists? Y/N | High/Med/Low |
| Novelty/Primacy | Pass/Fail/Flag | Trend direction + runtime | High/Med/Low |
| Instrumentation | Pass/Fail/Flag | Drift indicators found | High/Med/Low |
| Seg. Leakage | Pass/Fail/Flag | Crossover %, trigger applied? | High/Med/Low |
| Guardrails | Pass/Fail/Flag | Each guardrail delta | High/Med/Low |

Legend: Seg. = Segment; Pass = no issue; Fail = experiment invalid until resolved; Flag = caveat required.

**Section 3 — Dilution-Corrected Effect Estimate**
If trigger analysis was not applied: recalculate aggregate impact using triggered_fraction × reported_delta. State the corrected number alongside the reported number.

**Section 4 — Decision Matrix Verdict**
Which of the six scenarios applies. Go / No-Go / Extend / Re-run with rationale citing the specific audit findings.

**Section 5 — Remediation Steps**
One concrete action per failed or flagged check, with the specific data to pull or change to make, and the person/team responsible.

## WORKED MINI-EXAMPLE

**Page:** E-commerce checkout page, desired action = order completion.
**Experiment:** New single-page checkout (treatment) vs. 3-step checkout (control). 50/50 split, 10-day runtime. Reported: +6.2% order completion, p=0.031.

**Step 1 — SRM:** Control = 48,210 users, Treatment = 51,890 users. Expected = 50,050 each. χ²(1 df) = 136.8, p < 0.0001. **FAIL. Scorecard hidden.** Investigation: redirect in treatment adds a step before pixel fires — control fires on page-load, treatment fires after redirect completes. Fix: align pixel placement. Re-run required.

*Without the SRM check, the team would have shipped a "6.2% winner" that was a measurement artifact. The MSN precedent suggests the true effect could be opposite in sign.*

**If SRM had passed (hypothetically):**
- Step 3 (Novelty): Day-by-day chart shows order rate declining from day 1 (+9%) to day 10 (+3%). Trending down → novelty effect present. Extend to day 21, re-evaluate when flat.
- Step 5 (Leakage): Trigger analysis not applied. 62% of sessions reach checkout; dilution correction = 0.62 × 6.2% = 3.8% aggregate impact — still above the pre-specified 2% MDE, so pract sig holds if novelty resolves.
- Decision Matrix: Scenario 4 (Not stat sig outside CI) after novelty correction → Re-run with 14-day minimum runtime.

## OUTPUT FILE
Save to: [project-folder]/Kohavi - Click Architecture/[YYYY-MM] - Experiment Validity Audit - [Page Name].md
