---
name: norman-gulf-of-evaluation-reducer
description: Use when a page's desired action completes but visitors don't know it worked — diagnoses perception and interpretation failures in the Bridge of Evaluation, then prescribes immediate, legible feedback at every post-click stage.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Don Norman (The Design of Everyday Things, 1988/2013; Seven Stages of Action, Two UX Gulfs, Feedforward vs. Feedback) — Click Architecture (Skill 3 of 7)"
interface:
  invoke: "/norman-gulf-of-evaluation-reducer"
  calls: []
  called_by: [user, norman-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page states, button behaviors, and success messaging change with every redesign or A/B test; stale audits flag resolved issues or miss new breaks."

norman_gulf_of_execution_integration:
  feeds_from: norman-gulf-of-execution-reducer
  feeds_to: norman-feedback-state-designer
  shared_data: "Stage 4 (Execute Action) is the handoff point — execution audit ends when the visitor clicks; evaluation audit begins at that click. Pass the identified desired action + CTA element inventory to this skill."

fitts_integration:
  feeds_from: fitts-field-intelligence
  feeds_to: norman-feedback-state-designer
  shared_data: "Fitts confirms the CTA is physically reachable and large enough; this skill then audits what happens after the click — whether the system response is perceivable and interpretable."

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: norman-error-recovery-architect
  shared_data: "Kahneman's Peak-End Rule governs which feedback moments encode in memory. Share the identified page 'peak' and 'end' moments; this skill ensures those exact moments carry unambiguous evaluation signals."
---

# Norman Gulf of Evaluation Reducer

## LAYER 1: INVARIANTS (Never override.)

1. **Stages 5-7 are the audit scope.** This skill covers only the Bridge of Evaluation — Perceive State, Interpret State, Evaluate Outcome. Gulf of Execution issues (signifiers, mapping, affordances) belong to the sibling execution skill. Do not cross lanes.
2. **Perception precedes interpretation.** A visitor cannot interpret a state they cannot perceive. Audit perceivability first (is the feedback visible at all?), then interpretability (does its meaning map to their goal?). Fixing interpretation before fixing perception wastes effort.
3. **100ms is the outer limit for Stage 5 response.** Any action that produces no perceivable state change within 100ms leaves the visitor in an evaluation void. This is a hard threshold from Norman's feedback requirement, not a guideline.
4. **The System Image is the only lever.** The visitor's User Model is built entirely from what the page shows (System Image). Designers cannot inject belief directly. Every evaluation fix is a System Image fix — change what is visible, labeled, or timed.
5. **Feedforward is not feedback.** Feedforward answers "what will happen?" before the action. Feedback answers "what happened?" after. This skill focuses on feedback (post-action). Do not substitute feedforward copy for post-action state signals.
6. **All three Conceptual Model layers must align.** Designer's Model (intent) → System Image (page state) → User Model (visitor belief). Flag any mismatch as a Gulf of Evaluation break regardless of how "obvious" the designer believes the outcome to be.
7. **No evaluation fix is valid without a measurable signal.** Every recommendation must name the metric that confirms the gulf is closed: task completion rate, error recurrence rate, time-to-next-action, or rage-click rate on the feedback element.

## LAYER 2: QUALITY GUIDANCE

1. **Score each stage independently.** A page that passes Stage 5 (visible spinner) can still fail Stage 6 (spinner disappears but success message is ambiguous) or Stage 7 (visitor believes action succeeded but reaches the wrong conclusion about next steps). Report stage-level failures, not a single page-level grade.
2. **Distinguish slip recovery from mistake recovery.** A slip (correct goal, wrong execution — e.g., double-submit) requires a different feedback signal than a mistake (wrong goal formed — e.g., opted into wrong tier). Match feedback specificity to error type from Norman's taxonomy.
3. **Prioritize by conversion impact.** Rank gaps: Stage 5 failures (invisible state) destroy conversion immediately; Stage 7 failures (wrong evaluation) create delayed abandonment and refund requests. Fix Stage 5 first.
4. **Test with zero-context users.** Evaluation gaps are invisible to people who already know the system. Every recommended fix must be validated by someone seeing the page for the first time and asked aloud: "What just happened? Did it work?"
5. **One success state per action.** Multiple possible success messages for the same action (e.g., different copy for different plans) create ambiguity. Standardize to one legible signal per action type.

## PURPOSE

This skill closes the did-it-work gap on any page where a visitor completes the desired action but cannot confirm the outcome. It applies Don Norman's Seven Stages of Action — specifically Stage 5 (Perceive State), Stage 6 (Interpret State), and Stage 7 (Evaluate Outcome) — to diagnose every post-click feedback failure and prescribe concrete System Image fixes.

The lever: visitors who cannot evaluate whether their action succeeded abandon, retry (causing double-submits), or leave with a false belief about what they bought/joined/requested. Closing the Gulf of Evaluation is not UX polish — it is the difference between a completed conversion and a refund request.

**Brag line:** "Every action on our page is obvious and every click confirms itself."

Skill 3 of 7 in the norman-* cluster. Assumes the Gulf of Execution is already addressed (sibling skill 2). Feeds findings to norman-feedback-state-designer (skill 5) and norman-error-recovery-architect (skill 6).

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description of all visible elements
- The ONE desired action: what the visitor should do (e.g., "click Buy Now and complete checkout")

**Strongly recommended:**
- Post-click flow: what the page/element does after the action (state changes, redirects, messages)
- Analytics: rage-click rate, error submission rate, form abandonment rate, time-to-next-action after CTA click
- Funnel position: where this page sits (top/mid/bottom of funnel affects evaluation stakes)

**Optional:**
- Session recordings (Hotjar, FullStory) showing post-click behavior
- Support tickets mentioning "I thought I submitted" / "I didn't know if it worked"

## EXECUTION PROCESS

### Step 1 — Map the Post-Click Sequence (Stage 4 → Stage 5 handoff)

List every system event that occurs after the desired action fires, in order:
- Button click registers
- Visual state changes (button label, color, disabled state)
- Network request initiates
- Processing indicator appears
- Request resolves (success or error path)
- Redirect or in-page state update
- Confirmation message or page renders

If any event in this sequence is invisible to the visitor, flag it as a Stage 5 gap immediately. Document the gap with: what is invisible, how long the invisible window lasts, and what the visitor sees instead (nothing, a frozen button, a blank redirect).

**Threshold:** Any invisible window > 100ms between action and perceivable response = Stage 5 failure.

### Step 2 — Stage 5 Audit: Perceivability

For each post-click event, score perceivability on a 3-point scale:

| Score | Meaning |
|-------|---------|
| 2 | Immediately visible, no search required |
| 1 | Visible but requires looking away from action point |
| 0 | Invisible or requires scrolling/interaction to see |

**How to compute:** Place a naive user at the page. After the action fires, what do their eyes naturally land on first? Is the feedback there? If the success message appears above the fold while the CTA is below the fold, score 0 — the visitor's attention will not travel there without instruction.

**Minimum acceptable total:** Every post-click state must score ≥ 1. Any score of 0 = fix before proceeding.

### Step 3 — Stage 6 Audit: Interpretability

For each perceivable post-click signal, test interpretability:
- Does this signal tell the visitor WHAT happened (not just that something happened)?
- Does it align with the Conceptual Model they hold entering the page?
- Does it eliminate alternative interpretations?

**Conceptual Model alignment check:** State the Designer's Model (intended meaning of the signal), then state the most likely User Model (what a first-time visitor will infer). If they differ, document the mismatch as a Stage 6 failure.

**Common Stage 6 failures:**
- Generic success banners ("Done!" — what is done? Did the order process or just save?)
- Spinner without label (processing what? for how long?)
- Redirect to a page with a different heading than the action promised
- Error messages in system language ("Error 422") rather than user language ("That email is already registered — try logging in")

### Step 4 — Stage 7 Audit: Outcome Evaluation

Stage 7 asks: does the visitor correctly conclude that their goal was achieved?

This stage can fail even when Stages 5 and 6 pass — if the visitor's original goal and the system's confirmed action are not explicitly connected in the feedback.

**Test:** Read the success message aloud. Does it directly reference the goal the visitor entered the page with? If the visitor came to "get the free guide" and the success message says "Thank you for subscribing," Stage 7 has a gap — the word "guide" is absent, creating uncertainty.

**Scoring:** Binary. The visitor either correctly evaluates success (pass) or remains uncertain or forms a wrong conclusion (fail). No partial credit.

### Step 5 — Generate the Gulf Score and Priority Stack

Compile a Gulf of Evaluation Score (GoE Score):

| Stage | Issue | Severity | Fix |
|-------|-------|----------|-----|
| 5 – Perceive | [what is invisible] | High/Med | [fix] |
| 6 – Interpret | [ambiguous signal] | High/Med | [fix] |
| 7 – Evaluate | [goal mismatch] | High/Med | [fix] |

Severity: High = conversion-breaking (visitor cannot confirm action at all); Med = conversion-degrading (visitor is uncertain, may retry or contact support).

Fix Stage 5 failures first, then Stage 6, then Stage 7. Do not invert — interpretable feedback that cannot be seen is worthless.

### Step 6 — Prescribe System Image Fixes

For each gap, prescribe a specific System Image change. Format:

**Element:** [the specific UI element to change]
**Current state:** [what it shows now]
**Required state:** [what it must show, with exact copy or behavior spec]
**Timing:** [when it must appear, relative to the action]
**Constraint type applied:** [physical / semantic / cultural / logical — from Norman's Four-Type Constraint Architecture]

Every fix must name a measurable signal confirming the gulf is closed (see Invariant 7).

## OUTPUT STRUCTURE

### 1. Post-Click Sequence Map
Ordered list of all system events after the desired action, with visibility status for each.

### 2. Stage-Level Gap Report
Three-section table (Stage 5 / Stage 6 / Stage 7), each row: gap description, severity, conversion impact.

### 3. Conceptual Model Alignment Check
Designer's Model vs. inferred User Model for the primary success state. Mismatch flagged with specific language.

### 4. Prioritized Fix Stack
Ordered list of System Image prescriptions, highest conversion impact first. Each fix includes element, current state, required state, timing, constraint type, and success metric.

### 5. Verification Protocol
How to confirm each fix closed the gap: specific user test (first-click test, moderated session question, or analytics threshold to clear).

## WORKED MINI-EXAMPLE

**Page:** SaaS free trial signup — email + password form, "Start Free Trial" button.

**Desired action:** Visitor submits the form and begins trial.

**Before (Gulf of Evaluation open):**
- Button click: button stays blue, no state change (Stage 5 fail — 0/2)
- Network request fires but page is silent for 2.8 seconds
- Page reloads to dashboard with no success message (Stage 6 fail — visitor does not know if trial is active or if the page just refreshed)
- Dashboard header says "Welcome" — no mention of trial, trial end date, or what was just activated (Stage 7 fail — visitor cannot evaluate whether goal "start free trial" was achieved)

**After (Gulf of Evaluation closed):**
- Button click at t=0ms: button label changes to "Starting your trial..." + spinner appears, button disabled (Stage 5 fixed — score 2/2, physical + logical constraint applied)
- At t=100ms: progress label updates to "Setting up your account" (Stage 6 feedforward — interprets the wait)
- At t=2.8s redirect: dashboard loads with dismissible banner: "Your 14-day free trial is active — expires June 14. Explore your dashboard below." (Stage 6 fixed — specific, matches goal language)
- Banner copy references "free trial" directly, matching visitor's entry intent (Stage 7 fixed — goal achieved signal is explicit)

**Measurable outcome:** Rage-click rate on "Start Free Trial" button drops from 18% to < 2% (indicates visitors no longer retry believing the click didn't register). Support tickets citing "I didn't know if it worked" eliminated.

## OUTPUT FILE

Save to: [project-folder]/Norman - Click Architecture/[YYYY-MM] - Gulf of Evaluation Audit.md
