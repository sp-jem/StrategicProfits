---
name: click-architects
description: >
  Master orchestrator for the Click Architects family. Takes a real web page
  (URL, screenshot, or written description) plus ONE desired action, runs all
  12 thinker field-intelligence skills on it, then produces a single
  prioritized "Top Moves to Maximize the Desired Action" synthesis organized
  across 9 mechanism groups. Trigger: "Use when you need every web-conversion
  thinker to optimize a page for a single desired action."
version: 1.0.0
author: Strategic Profits / Click Architects Series
interface:
  invoke: "/click-architects"
  calls:
    - pirolli-field-intelligence
    - kohavi-field-intelligence
    - eisenberg-field-intelligence
    - fitts-field-intelligence
    - goward-field-intelligence
    - gigerenzer-field-intelligence
    - laja-field-intelligence
    - norman-field-intelligence
    - hick-field-intelligence
    - nielsen-field-intelligence
    - eyal-field-intelligence
    - brignull-field-intelligence
  called_by: [user]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 30
  reason: "Pages change, offers change, audiences shift. Any FI output older than
    30 days on a live page should be re-run before synthesis."
mechanism_groups:
  G1: "Click & Choice Cost"
  G2: "Information Scent & Foraging"
  G3: "Attention & Perception Topography"
  G4: "Affordance & Friction Legibility"
  G5: "Cognitive Fit & Heuristics"
  G6: "Persuasion Architecture & Page Anatomy"
  G7: "Experimentation Rigor (Proof)"
  G8: "Habit & Reward Loops"
  G9: "Ethics & Dark-Pattern Boundary"
cluster_manifest:
  - thinker: "Peter Pirolli & Stuart Card"
    group: G2
    skill: pirolli-field-intelligence
    lever: "Information Foraging Theory / Information Scent — why a link gets clicked or abandoned"
    brag: "We can predict which links leak visitors before we ship the page."
  - thinker: "Ronny Kohavi"
    group: G7
    skill: kohavi-field-intelligence
    lever: "Trustworthy online controlled experiments — OEC, SRM, validity threats; only 10-20% of ideas win"
    brag: "We know our winner is real, not a 1-in-20 false positive."
  - thinker: "Bryan & Jeffrey Eisenberg"
    group: G6
    skill: eisenberg-field-intelligence
    lever: "Persuasion Architecture — scent, persona-pathways, buying modalities, conversion trinity, landing-page anatomy"
    brag: "Our ad and our page tell one unbroken story — scent never breaks."
  - thinker: "Paul Fitts"
    group: G1
    skill: fitts-field-intelligence
    lever: "Fitts's Law: T = a + b·log₂(2D/W) — the motor-cost math of the click"
    brag: "Our primary button is mathematically the easiest thing to hit on the page."
  - thinker: "Chris Goward"
    group: G6
    skill: goward-field-intelligence
    lever: "LIFT Model — Value Prop fulcrum raised by Clarity/Relevance/Urgency, dragged by Anxiety/Distraction"
    brag: "We can score any landing page on 6 conversion forces before testing."
  - thinker: "Gerd Gigerenzer"
    group: G5
    skill: gigerenzer-field-intelligence
    lever: "Ecological rationality / fast-and-frugal heuristics / risk literacy via natural frequencies"
    brag: "We design WITH the mental shortcuts instead of fighting them."
  - thinker: "Peep Laja"
    group: G7
    skill: laja-field-intelligence
    lever: "ResearchXL conversion research (6 spokes) + PXL prioritization; clarity trumps persuasion"
    brag: "We find the real leak with 6 research lenses before we touch the page."
  - thinker: "Don Norman"
    group: G4
    skill: norman-field-intelligence
    lever: "Affordances & signifiers; gulfs of execution/evaluation; feedback loops; natural mapping"
    brag: "Every action on our page is obvious and every click confirms itself."
  - thinker: "William Hick & Ray Hyman"
    group: G1
    skill: hick-field-intelligence
    lever: "Hick's Law: RT = b·log₂(n+1) — decision time rises with the log of the number of options"
    brag: "We cut decision time by removing options, and we can prove the math."
  - thinker: "Jakob Nielsen & Kara Pernice"
    group: G3
    skill: nielsen-field-intelligence
    lever: "10 usability heuristics + largest eyetracking studies (F-pattern, banner blindness, attention heatmaps)"
    brag: "We place CTAs where eyes actually land, not where we hope."
  - thinker: "Nir Eyal"
    group: G8
    skill: eyal-field-intelligence
    lever: "Hook Model: Trigger → Action → Variable Reward (Skinner variable-ratio) → Investment loop"
    brag: "Our product builds a return habit, by design."
  - thinker: "Harry Brignull"
    group: G9
    skill: brignull-field-intelligence
    lever: "Dark patterns taxonomy (confirmshaming, roach motel, sneak-into-basket) + sludge; the ethical line"
    brag: "We use the strongest levers known — and we know exactly where the line is."
---

# Click Architects — Master Orchestrator

---

## LAYER 1: INVARIANTS (Never override.)

1. **Every analysis is anchored to a specific page and a single desired action.** There is no generic optimization. Every finding, every recommendation, every ranked move must be evaluated against: does this increase the probability of the ONE desired action on THIS page? If a finding is interesting but doesn't connect to the desired action, cut it.

2. **Synthesis is not summary.** This skill does NOT recap what each FI found. It identifies patterns ACROSS the 12 analyses — convergence zones, contradictions between thinkers, amplification opportunities. If the output reads like 12 separate reports stapled together, it has failed.

3. **Convergence is gold.** When 3+ thinkers independently diagnose the same friction or opportunity, that is a convergence zone. Name it. Prioritize it above any single-thinker finding. Convergence zones are the highest-confidence, highest-leverage moves on the page.

4. **Contradictions must be resolved, not hidden.** Fitts wants the biggest boldest button. Brignull warns a coercive oversized button becomes a dark pattern. Norman says the affordance must match the commitment level. That three-way tension must be RESOLVED with a specific design decision — not noted and abandoned.

5. **Brignull is a guardrail on everything, not one input among twelve.** Every recommended move must pass the Brignull ethics check before appearing in the final plan. Moves that fail get redesigned to preserve the lever while removing the manipulation. Moves that cannot be redesigned are cut.

6. **Kohavi owns the test queue.** Any move with uncertainty above a defined threshold gets flagged as test-first. The Kohavi gate prevents shipping unproven changes that look obvious but fail in experiment. This is especially important for moves that converge across thinkers — high-convergence moves still need OEC definition and SRM checks before declaring a winner.

7. **The Single Highest-Leverage Move is mandatory.** The output must produce exactly ONE move that, if implemented tomorrow with no other changes, would have the greatest impact on the desired action. Not a top-5. One.

8. **Freshness gate: 30 days.** Flag any FI output older than 30 days. Live pages change. Stale analyses produce stale moves.

---

## LAYER 2: QUALITY GUIDANCE

9. **Name convergence zones memorably.** "The Button Blindspot" is actionable. "Convergence around CTA visibility" is not. A named zone gets acted on. An unnamed observation gets read and forgotten.

10. **Tie every move to the desired action explicitly.** "Increase headline clarity" is not a move. "Rewrite the headline so the visitor knows within 3 seconds that clicking the button gets them [X]" is a move. The desired action must be visible in every recommendation.

11. **The Top Moves table has 6 columns maximum.** Most readers view these in a markdown viewer. If the table requires horizontal scrolling, reformat it. Abbreviate headers, add a legend below. No exceptions.

12. **Include worked examples.** Every group section must contain at least one before-vs-after illustration on the actual page under analysis. Not a hypothetical. The specific page.

13. **Quantify where the math exists.** Fitts's Law gives a formula. Hick's Law gives a formula. Use them. "Removing 2 nav options reduces decision time by ~12%" is a move. "Simplify the nav" is noise.

14. **The conversion projection must be specific.** Not "things should improve." Give a range: "Implementing moves in G1 and G3 should shift click-through from current baseline toward the top quartile for this page type, estimated +8–15% based on Laja's PXL scoring."

---

## PURPOSE

Individual Click Architects field-intelligence skills each apply one thinker's lens to a page. Pirolli predicts link abandonment. Fitts scores motor cost. Norman audits affordances. Nielsen maps eye-flow. Each produces a diagnosis and a list of recommendations — from one perspective.

The power is at the intersections.

When Pirolli says the nav links have weak information scent AND Nielsen's F-pattern analysis shows the CTA lands outside the primary attention zone AND Fitts scores the button as motor-expensive AND Hick calculates that the nav presents 9 competing options — those four findings converge on one intervention: restructure the page hierarchy so the CTA is the dominant, closest, clearest path to the desired action.

Click Architects Master Orchestrator finds those convergence points. It transforms 12 independent analyses into one ranked, ethics-gated, experiment-sequenced action plan — the complete picture of why visitors don't take the desired action and exactly what to change first, second, and third.

**Brag:** "We ran 12 conversion thinkers on your page simultaneously and ranked every move by leverage, ease, and confidence — then told you which one to ship first."

---

## INPUT REQUIREMENTS

**Required:**
- The page: URL (preferred), screenshot, or detailed written description
- The desired action: ONE specific action (e.g., "click the opt-in button," "add to cart," "start free trial," "scroll past fold to read offer")

**High-value optional:**
- Current conversion rate or click-through rate (baseline)
- Traffic source and audience segment hitting this page
- Funnel position (cold traffic / warm retargeting / existing customer)
- Analytics heatmap or scroll map data
- Outputs from individual Click Architects skills already run

**What NOT to provide:**
- Multiple desired actions. Pick one. If the page has two goals, run Click Architects twice — once per goal.

---

## EXECUTION PROCESS

### Step 1: Page Intake & Desired Action Lock

Before invoking any skill, state explicitly:
- **Page:** [URL / description]
- **Desired action:** [exact one-line definition]
- **Baseline metric (if known):** [current rate]
- **Audience & funnel position:** [if known]

Lock the desired action. Every subsequent step is evaluated against it.

### Step 2: Run All 12 Field-Intelligence Skills

Invoke each skill with the page + desired action as input. Record:

| Skill | Status | Date | Freshness |
|-------|--------|------|-----------|
| pirolli-field-intelligence | | | |
| kohavi-field-intelligence | | | |
| eisenberg-field-intelligence | | | |
| fitts-field-intelligence | | | |
| goward-field-intelligence | | | |
| gigerenzer-field-intelligence | | | |
| laja-field-intelligence | | | |
| norman-field-intelligence | | | |
| hick-field-intelligence | | | |
| nielsen-field-intelligence | | | |
| eyal-field-intelligence | | | |
| brignull-field-intelligence | | | |

Flag any skill that could not complete (note reason and impact on synthesis).

### Step 3: Group Findings by Mechanism Group

For each of the 9 mechanism groups, list every recommendation produced by the skills assigned to that group. Do not filter yet — capture everything.

- **G1 Click & Choice Cost:** Fitts + Hick findings
- **G2 Information Scent & Foraging:** Pirolli findings
- **G3 Attention & Perception Topography:** Nielsen findings
- **G4 Affordance & Friction Legibility:** Norman findings
- **G5 Cognitive Fit & Heuristics:** Gigerenzer findings
- **G6 Persuasion Architecture & Page Anatomy:** Eisenberg + Goward findings
- **G7 Experimentation Rigor (Proof):** Kohavi + Laja findings
- **G8 Habit & Reward Loops:** Eyal findings
- **G9 Ethics & Dark-Pattern Boundary:** Brignull findings

### Step 4: Detect Cross-Thinker Convergence Zones

Scan across all groups for recommendations where 3+ thinkers — regardless of group — independently point at the same page element, friction, or opportunity.

**Convergence scoring:**
- 2 thinkers: Notable alignment — flag
- 3 thinkers: Convergence zone — name it, prioritize
- 4+ thinkers: Critical convergence — top candidate for The Single Move

For each convergence zone:
- **Name:** Memorable label (e.g., "The Invisible CTA," "The Choice Paralysis Zone")
- **Contributors:** Which thinkers converge here
- **Each thinker's finding:** What specifically they found
- **System implication:** What the convergence reveals about the page
- **Implied move:** What single change addresses this zone

### Step 5: Detect and Resolve Contradictions

Flag every case where two thinkers recommend opposite or incompatible actions on the same element.

**Common contradiction patterns:**
- Fitts (bigger/closer button) vs. Brignull (coercive oversized CTA = dark pattern)
- Eyal (variable reward ambiguity) vs. Norman (feedback must be immediate and clear)
- Goward (add urgency) vs. Brignull (manufactured scarcity = dark pattern)
- Hick (remove all secondary options) vs. Eisenberg (persona-pathway requires multiple routes)
- Pirolli (strengthen scent trail) vs. Gigerenzer (one-cue simplicity beats complex signaling)

For each contradiction:
- State the tension exactly
- Explain why both thinkers are correct in their own frame
- State the resolution for this specific page and desired action
- Define the implementation that honors both insights

### Step 6: Rank by Leverage × Ease × Confidence (PXL-style)

Credit Laja's PXL framework: score each move on three dimensions.

**Scoring per move (1–5 each):**
- **Leverage:** How much impact on the desired action if this works?
- **Ease:** How fast / cheap to implement? (5 = hours; 1 = weeks of dev)
- **Confidence:** How certain are we this will help? (5 = 3+ thinkers converge; 1 = one thinker, weak signal)

**PXL Score = Leverage × Ease × Confidence**
Max: 125. Moves scoring 75+ are high-priority. Moves scoring below 30 go to the backlog.

### Step 7: Kohavi Gate — What Gets Tested First

Apply Kohavi's experimental rigor to the ranked list:

- **Ship without testing:** Moves with Confidence ≥ 4 (strong convergence) AND low downside risk AND non-reversible changes (e.g., removing confirmed-broken element)
- **A/B test before shipping:** Moves with Confidence ≤ 3 OR where the size of the bet warrants an experiment
- **Test sequencing:** Define ONE primary OEC (Overall Evaluation Criterion) tied to the desired action. Every test is evaluated against this single metric. Multi-metric testing without a hierarchy is Kohavi's most common failure mode.
- **SRM check:** Any split showing Sample Ratio Mismatch invalidates the result before looking at outcomes.

### Step 8: Brignull Ethics Gate

Every move in the final plan — regardless of PXL score — passes through Brignull before publication.

Evaluate each move against:
- Does it use deception to generate the click?
- Does it create obstacles to NOT taking the action (roach motel / sludge)?
- Does it use shame or social pressure to coerce (confirmshaming)?
- Does it obscure what happens AFTER the click?
- Does it exploit cognitive load or visual hierarchy manipulatively?

**Outcome per move:**
- Pass: Move is clean — include as-is
- Redesign: Move has lever value but needs ethical redesign — note the redesign
- Cut: Move cannot be made ethical — remove from plan, note why

### Step 9: Emit the Prioritized Top Moves Plan

Produce the full output structure below.

---

## OUTPUT STRUCTURE

### Section 1: Page Brief

- **Page:** [URL or description]
- **Desired action:** [exact definition]
- **Baseline:** [current rate if known, else "not provided"]
- **Audience / funnel position:** [if known]
- **Skills completed:** [X/12 — list any that did not complete and why]

---

### Section 2: Top Moves Table

6 columns, no horizontal scroll. Legend below.

| Move | Grp | Thinker(s) | PXL | Effort | Test? |
|------|-----|-----------|-----|--------|-------|
| [Specific change, named element] | G# | [initials] | [score] | H/M/L | Y/N |

**Legend:**
- Grp: G1=Click & Choice Cost, G2=Scent & Foraging, G3=Attention & Perception, G4=Affordance & Friction, G5=Cognitive Fit, G6=Persuasion Architecture, G7=Experimentation Rigor, G8=Habit & Reward, G9=Ethics Boundary
- Thinker initials: Pi=Pirolli, Ko=Kohavi, Ei=Eisenberg, Fi=Fitts, Go=Goward, Gi=Gigerenzer, La=Laja, No=Norman, Hi=Hick, Ni=Nielsen, Ey=Eyal, Br=Brignull
- Effort: H=hours (today), M=days, L=weeks
- Test?: Y=run A/B before shipping, N=ship directly

---

### Section 3: Convergence Zone Analysis

For each named convergence zone (3+ thinkers):

**[Zone Name]**
- Contributors: [thinker list]
- What each found: [specific diagnosis]
- System implication: [what this reveals]
- Recommended move: [specific change]
- Worked example on this page: Before → After

---

### Section 4: Contradiction Resolutions

For each thinker conflict:

**[Element]: [Thinker A] vs. [Thinker B]**
- A says: [recommendation]
- B says: [opposing recommendation]
- Resolution: [specific decision for this page]
- Implementation: [how to honor both]

---

### Section 5: Per-Group Diagnostic

For each group, list:
- Strongest finding relevant to the desired action
- Highest-confidence move
- One worked before→after example on the actual page

**G1 — Click & Choice Cost (Fitts + Hick)**

Fitts's Law check: T = a + b·log₂(2D/W)
- Primary CTA distance from thumb zone: [measure / estimate]
- CTA width: [px / relative]
- Computed acquisition difficulty: [High / Medium / Low]
- Hick's Law check: RT = b·log₂(n+1)
- Competing options visible at decision point: [count]
- Estimated decision-time penalty vs. single-option: [%]
- Move: [specific]

**G2 — Information Scent & Foraging (Pirolli)**

- Scent strength of primary CTA link: [Strong / Weak / Broken]
- Patch value vs. patch cost at decision point
- Predicted abandonment trigger: [specific element]
- Move: [specific]

**G3 — Attention & Perception Topography (Nielsen)**

- F-pattern scan: primary CTA falls in zone [A/B/C/D — hot/warm/cold]
- Banner blindness risk on this page: [High / Medium / Low]
- Scannability score: [headline → subhead → CTA hierarchy intact? Y/N]
- Move: [specific]

**G4 — Affordance & Friction Legibility (Norman)**

- Gulf of Execution: does the visitor know what to do? [Clear / Ambiguous / Hidden]
- Gulf of Evaluation: does the visitor know what happens after clicking? [Clear / Ambiguous / Hidden]
- Signifier quality on CTA: [Explicit / Weak / Absent]
- Feedback after click: [Immediate / Delayed / None]
- Move: [specific]

**G5 — Cognitive Fit & Heuristics (Gigerenzer)**

- Dominant heuristic available at decision point: [Recognition / Take-the-Best / Other]
- Risk communication format: [Frequency / Probability / Neither]
- Less-is-more opportunity: [Y/N — what to remove]
- Move: [specific]

**G6 — Persuasion Architecture & Page Anatomy (Eisenberg + Goward)**

LIFT Score for this page:
- Value Proposition clarity: [1–10]
- Relevance to visitor intent: [1–10]
- Clarity of offer: [1–10]
- Urgency (real vs. manufactured): [1–10]
- Anxiety signals present: [list]
- Distraction elements present: [list]

Persuasion Architecture:
- Buying modality served: [Competitive / Spontaneous / Humanistic / Methodical]
- Scent continuity from traffic source to page: [Intact / Broken — where]
- Micro-action sequence toward desired action: [mapped / missing]

Move: [specific]

**G7 — Experimentation Rigor (Kohavi + Laja)**

- OEC for the desired action: [define it]
- Top ResearchXL friction source: [heuristic / technical / copy / value prop / social / mouse]
- PXL top candidates already scored above
- SRM watch: [any existing test data to audit?]
- Test queue sequencing: [move 1 → move 2 → move 3]

**G8 — Habit & Reward Loops (Eyal)**

- External trigger present: [Y/N — what type]
- Internal trigger tapped: [Y/N — which emotion]
- Action ease at decision point: [Easy / Moderate / Hard per Fogg ability axes]
- Variable reward legibility: [Clear / Ambiguous / Absent]
- Investment mechanism post-action: [Y/N — what type]
- Move: [specific — only include if habit loop is relevant to desired action]

**G9 — Ethics & Dark-Pattern Boundary (Brignull)**

Gate results for all moves — list each move and its gate outcome (Pass / Redesign / Cut).

Ethical levers available on this page that are NOT currently deployed: [list]
Dark patterns already present that must be removed: [list]

---

### Section 6: The Single Highest-Leverage Move

**What:** [One specific, implementable action]

**Why this is THE move:**
- Convergence zones it addresses: [list]
- PXL score: [score]
- Thinkers who independently identified this: [list]

**How it works (by thinker frame):**
- In Fitts terms: [mechanism]
- In Norman terms: [mechanism]
- In Pirolli terms: [mechanism]
- In Goward/LIFT terms: [mechanism]

**Implementation steps:**
1. [Step]
2. [Step]
3. [Step]

**Test or ship directly:** [with rationale citing Kohavi]

**Brignull gate:** [Pass / Redesign — note redesign if needed]

**Expected impact:** [specific metric shift, stated as a range]

**What this does NOT address:** [honest about limitations — which groups remain unaddressed]

---

### Section 7: Conversion Projection

If the Top Moves plan is implemented in full:

- **30 days:** [what gets shipped, what early signal to watch]
- **60 days:** [first test results readable, which metrics move]
- **90 days:** [full plan implemented, estimated conversion range vs. baseline]

Projection anchored to: Laja PXL confidence scoring + Kohavi OEC + baseline provided (or estimated if not provided).

---

### Section 8: Ethics Summary

- Total moves evaluated: [n]
- Passed clean: [n]
- Redesigned to pass: [n] — [list with redesign notes]
- Cut: [n] — [list with reason]
- Dark patterns discovered pre-existing on page: [list — must remove regardless of Top Moves plan]

---

## OUTPUT FILE

Save complete analysis to:
`[project-folder]/Click Architects/[YYYY-MM-DD] - [Page Name] - [Desired Action] - Click Architects Analysis.md`

If no project folder is specified, save to:
`~/click-architects-output/[YYYY-MM-DD] - [Page Name] - Analysis.md`
