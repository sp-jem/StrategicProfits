---
name: gigerenzer-less-is-more-auditor
description: Use when a page is overloaded with options, statistics, or feature lists and conversion is lagging — audits which information to remove so fast-and-frugal heuristics fire at the CTA instead of stalling.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Gerd Gigerenzer (Simple Heuristics That Make Us Smart, 1999; Ecological Rationality 1999; Recognition Heuristic 2002; Natural Frequencies 1995; Fast-and-Frugal Trees 2003) — Click Architecture (Skill 5 of 7)"
interface:
  invoke: "/gigerenzer-less-is-more-auditor"
  calls: []
  called_by: [user, gigerenzer-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page information density, offer framing, and social proof formats shift with testing cycles; stale audits miss new overload sources introduced in copy updates."

gigerenzer_take_the_best_integration:
  feeds_from: gigerenzer-take-the-best-sequencer
  feeds_to: gigerenzer-single-cue-spotlighter
  shared_data: "Validity-ranked cue list produced by take-the-best-sequencer feeds into this auditor's Step 3 (identify the #1 discriminating cue). Audit findings on which cues survive removal feed single-cue-spotlighter for final placement execution."

iyengar_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: iyengar-choice-set-auditor
  shared_data: "Iyengar identifies overload via option count; this auditor identifies overload via information density per option. Combined: reduce both the number of tiers AND the number of claims per tier. Audit flags from both run in parallel on pricing sections."

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: kahneman-framing-engineer
  shared_data: "Kahneman anchoring and isolation-effect findings intersect with the Less-Is-More Effect: stripping surrounding claims amplifies the anchor. This auditor's removal recommendations feed kahneman-framing-engineer for re-sequencing after subtraction."
---

# Gigerenzer Less-Is-More Auditor

## LAYER 1: INVARIANTS (Never override.)

1. **Subtraction precedes addition.** Diagnose what to remove before recommending new copy. This skill's output is a removal list first, a rewrite list second.
2. **The Less-Is-More Effect (LIME) applies to information, not just options.** Adding proof points past the first discriminating cue degrades decision quality by shifting the visitor from recognition/heuristic mode into analytical comparison mode where you lose control of the decision.
3. **Natural frequency format is non-negotiable on every statistic.** "80% success rate" must become "8 in 10 customers achieved X." No exceptions. Odds ratio of 7.1 in favor of frequencies over percentages (Gigerenzer & Hoffrage, 1995).
4. **Stopping rule must fire at the CTA, not before it.** The page's highest-validity cue must appear before any secondary claim so Take-the-Best stops there — not at a competitor logo, a pricing discrepancy, or a secondary feature list that triggers a new search loop.
5. **The recognized option must NOT add detail in a recognition-advantage context.** When your brand is recognized and the competitor is not, additional feature detail destroys the recognition heuristic advantage by moving the visitor into analytical mode where the unknown can compete on specs.
6. **Uncertainty context demands simplicity.** When the visitor faces genuine uncertainty (unfamiliar category, new product type), complex comparison tables create the illusion of precision without reducing uncertainty. Fast-and-frugal tree structure (one discriminating question per section) outperforms feature matrices in this environment.
7. **Reference class must always be stated.** Every statistic must answer "percent of what?" or "out of how many?" Copy without a reference class is treated as a missing cue — remove or rewrite.

## LAYER 2: QUALITY GUIDANCE

1. Score each information element on the page using the LIME Score (defined in Execution). Elements below threshold are removal candidates, not refinement candidates.
2. Verify the surviving highest-validity cue is genuinely discriminating — it must distinguish your offer from the next-best alternative in the visitor's consideration set, not just describe a feature.
3. The rewrite of any statistic must preserve the absolute number AND the reference class. "4 of 5" is incomplete without "4 of 5 [customers who completed onboarding in 60 days]."
4. Do not replace a list of 12 features with a list of 6 features and call it done. The audit is complete when the page enables one-reason decision-making at the CTA — all secondary claims below the fold or removed entirely.
5. Flag any section that uses relative risk/benefit language ("25% more effective," "2x faster") and replace with absolute counts. Relative claims without reference class are manipulation by omission (Gigerenzer, 2014).

## PURPOSE

This skill applies Gigerenzer's Less-Is-More Effect and Ecological Rationality to diagnose where a page's information density is preventing fast-and-frugal heuristics from firing at the CTA. It identifies which elements to strip — not polish — so the visitor's Take-the-Best heuristic stops at your strongest proof point and decides, rather than continuing to search until it finds an exit or defers the decision entirely.

**Brag line:** "We design WITH the mental shortcuts instead of fighting them."

Most conversion optimization adds: more testimonials, more bullets, more guarantees. This skill subtracts — because in environments of genuine uncertainty, the simple model outperforms the complex one out of sample, every time.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description (above-the-fold and full scroll)
- The ONE desired action: what the page must make the visitor do (click, opt-in, purchase, next step)

**Optional but high-value:**
- Current analytics: scroll depth, heatmap, CTA click rate, time-on-page
- Audience prior knowledge: is this a recognized category or genuinely novel?
- Funnel position: cold traffic vs. warm retargeting changes the recognition baseline
- Competitor page (to assess recognition-heuristic competitive position)

## EXECUTION PROCESS

**Step 1 — Recognition Baseline (2 min)**

Determine whether this page operates in a recognition-advantage or recognition-deficit context.

- Recognition-advantage: your brand/product is known to this traffic source. Visitor can use the Recognition Heuristic. Strategy: do NOT add feature detail — it destroys the heuristic. Maximize the recognition signal (logo size, familiar proof names) and go straight to CTA.
- Recognition-deficit: visitor does not recognize your brand. Recognition Heuristic cannot fire. Strategy: build recognition first (media logos, known partner names, familiar testimonial sources), then present your highest-validity discriminating cue.

Score: 0 = unknown, 1 = partial recognition, 2 = strong recognition. Record this as the **Recognition Score**.

**Step 2 — LIME Score Each Information Element**

List every distinct information element on the page (headline, subhead, each bullet, each statistic, each testimonial, each logo, each CTA, each section header).

Score each element:

| Dimension | Question | Score |
|-----------|----------|-------|
| Validity | Is this the #1 reason a visitor would choose you? | 2=yes, 1=partial, 0=no |
| Discriminating | Does this separate you from the next-best option? | 2=yes, 1=partial, 0=no |
| Stopping power | Does this enable a stopping rule (visitor decides here)? | 2=yes, 1=maybe, 0=no |

**LIME Score = Validity + Discriminating + Stopping Power. Max = 6.**

Threshold rules:
- Score 5-6: Keep. This is a valid Take-the-Best cue. Place it first and alone.
- Score 3-4: Conditional keep. Move below fold. Never let it compete with a 5-6 element.
- Score 0-2: Remove. This element is breaking the stopping rule by extending the search process.

Legend: Validity = cue-validity weight; Discriminating = cue discriminates between options; Stopping power = enables visitor to stop searching and act.

**Step 3 — Identify the Single Highest-Validity Cue**

From the LIME scored list, identify the one element with the highest score. This becomes the page's **Primary Cue**. It must:
- Appear in the first viewport (above fold)
- Appear alone — no competing claims immediately adjacent
- Be stated as a natural frequency or a recognition signal, not a percentage

If no element scores above 4, flag as a Primary Cue Gap — the page lacks a discriminating lead claim and must rewrite before removing anything else.

**Step 4 — Natural Frequency Conversion**

Locate every statistic, percentage, or probability claim on the page.

Conversion formula:
- "X% of customers" → "X in 100 customers" or better, use the actual count if known ("47 of 52 clients")
- "20% more effective" → "In our study of 500 users, [N] additional users achieved [outcome]"
- Relative risk → Absolute count: "reduces churn by 30%" → "3 fewer cancellations per 10 customers per month"
- Always state reference class: who, over what time window, under what conditions

Worked conversion:
- Before: "80% of members hit their revenue goal in 90 days"
- After: "8 of 10 members who completed the 12-week protocol hit their revenue goal within 90 days"

**Step 5 — Fast-and-Frugal Tree Audit**

Map the page's current decision structure. A well-structured page functions as a fast-and-frugal tree: each section answers one binary question (yes/no, fit/not-fit) in order of discriminating validity, with an action exit available at each node.

Identify sections that violate this:
- Multiple questions in one section = tree collapse (remove until one question per section)
- No action exit before fold 3+ = missing early stopping nodes (add micro-CTAs at each high-LIME-score section)
- Feature matrices with 6+ columns = complexity that prevents stopping rule from firing (reduce to 3 columns max or convert to sequential single-cue reveals)

**Step 6 — Removal Priority List**

Produce a ranked removal list (not a rewrite list). For each removal:
- Element name
- LIME Score
- Reason for removal (which stopping-rule violation it creates)
- Disposition: Remove / Move below fold / Collapse into Primary Cue

**Step 7 — Boosting vs. Nudging Check**

Flag any element that exploits bias blindspots (manufactured urgency with no real scarcity, hidden fee reveals, deceptive comparison framing). Gigerenzer's Boosting principle requires interventions to be transparent and autonomy-preserving. Replace these with honest competence-building framing: give the visitor the one cognitive tool (the right comparison format, the right reference class, the right question) to see clearly that action is correct for them.

## OUTPUT STRUCTURE

**1. Recognition Baseline** — Score (0/1/2) + strategic implication for this page

**2. LIME Score Table** — All elements scored; highlight Primary Cue; flag removal candidates

**3. Natural Frequency Rewrites** — Before/after for every statistic; reference class stated

**4. Fast-and-Frugal Tree Map** — Current structure vs. recommended structure; missing exit nodes flagged

**5. Removal Priority List** — Ranked by LIME Score (lowest first); disposition for each

**6. Page Reconstruction Sequence** — The order in which changes should be implemented (removal first, then reposition Primary Cue, then rewrite statistics, then add exit nodes)

**7. Predicted Stopping-Rule Outcome** — Where on the page Take-the-Best should now fire, and why

## WORKED MINI-EXAMPLE

**Page:** SaaS landing page. Desired action: start free trial.

**Current above-fold:** Headline + 6 feature bullets + "Join 10,000+ teams" + "97% satisfaction rate" + "SOC2 certified" + "Free for 14 days" CTA.

**LIME Scores (selected):**
- "Join 10,000+ teams" — Validity 2, Discriminating 1, Stopping 2 = **5** (Primary Cue)
- "97% satisfaction rate" — Validity 1, Discriminating 0, Stopping 0 = **1** (Remove)
- Feature bullet #1 "Unlimited projects" — Validity 0, Discriminating 0, Stopping 0 = **0** (Remove)
- Feature bullet #4 "Slack integration" — Validity 1, Discriminating 1, Stopping 1 = **3** (Move below fold)
- "SOC2 certified" — Validity 1, Discriminating 1, Stopping 0 = **2** (Move below fold)

**Removals:** 5 of 6 feature bullets removed from above fold. "97% satisfaction rate" removed.

**Natural frequency rewrite:**
- Before: "97% satisfaction rate"
- After: (removed — not discriminating; cannot state reference class without manipulation)
- "Join 10,000+ teams" stays as recognition signal — already a natural count format.

**Reconstructed above-fold:** Headline → "Join 10,000+ teams" (alone, prominent) → "Free for 14 days" CTA.

**Predicted outcome:** Take-the-Best fires at "10,000+ teams" (recognition + social proof as single discriminating cue), stopping rule triggers, visitor clicks trial CTA before reaching the feature list that previously extended search into a competing exit.

## OUTPUT FILE

Save to: [project-folder]/Gigerenzer - Click Architecture/[YYYY-MM] - Less-Is-More Audit - [Page Name].md
