---
name: norman-field-intelligence
description: Use when you have outputs from 4+ Norman page-action skills on the same page and need the highest-leverage single move — synthesizes convergence zones, resolves cross-skill contradictions, and integrates with the full Click Architects network (Fitts, Hick, Pirolli, Eisenberg, Kohavi, Fogg, Cialdini, Kahneman, and more) to identify the one intervention that closes the most Norman gulfs simultaneously.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Don Norman (The Design of Everyday Things, 1988; revised 2013; Seven Stages of Action, Two UX Gulfs, Affordances & Signifiers, Natural Mapping, Feedforward/Feedback) — Field Intelligence (Skill 7 of 7)"
interface:
  invoke: "/norman-field-intelligence"
  calls: [norman-affordance-signifier-auditor, norman-gulf-of-execution-reducer, norman-gulf-of-evaluation-reducer, norman-mapping-auditor, norman-feedback-state-designer, norman-error-recovery-architect]
  called_by: [user, click-architects]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page affordance and signifier patterns degrade as offers, audiences, competitive pages, and design conventions evolve. Individual skill outputs older than 45 days may not reflect the current page state. Reassess quarterly minimum."
fitts_integration:
  feeds_from: [fitts-field-intelligence]
  feeds_to: [fitts-target-cost-auditor]
  shared_data: "Fitts measures motor cost (distance × target size) to reach and click. Norman measures cognitive cost (Gulf of Execution + Gulf of Evaluation) to understand and confirm. Combined: total click cost = Fitts motor cost + Norman gulf cost. Reducing either alone leaves the other as the bottleneck. The synthesis reveals which dimension dominates abandonment on each CTA — if Fitts cost is low but Gulf of Execution is high, signifier work is the priority; if both are high, fix Fitts placement THEN signal it clearly."
pirolli_integration:
  feeds_from: [pirolli-field-intelligence]
  feeds_to: [pirolli-scent-trail-auditor]
  shared_data: "Pirolli's information foraging theory maps how visitors follow information scent toward a goal. Norman's signifiers ARE the scent markers on a page — every affordance signal is a scent patch. Combined: strong information scent requires signifiers that match the visitor's mental representation of their goal. A button with weak scent (vague label) AND weak signifiers (flat design) fails both theories simultaneously. The synthesis reveals where scent gaps correspond to signifier deficits and where fixing one fixes both."
eisenberg_integration:
  feeds_from: [eisenberg-field-intelligence]
  feeds_to: [eisenberg-micro-action-sequencer]
  shared_data: "Eisenberg maps persuasion architecture — the sequence of micro-conversions from attention to action. Norman maps the interaction architecture — the sequence of stages from goal to outcome. Combined: Eisenberg's persuasion pathway and Norman's Seven Stages must run in parallel. A visitor who is persuaded (Eisenberg) but cannot bridge the Gulf of Execution (Norman) will not convert. The synthesis reveals where persuasion succeeds but Norman failure points kill the action — and vice versa."
kohavi_integration:
  feeds_from: [kohavi-field-intelligence]
  feeds_to: [kohavi-field-intelligence]
  shared_data: "Kohavi enforces the rule that every UX claim must be tested, not assumed. Norman provides the theoretical model for what to test. Combined: Norman's convergence zones generate the hypotheses; Kohavi's controlled experimentation validates which intervention actually moves conversion. Every 'The Single Move' recommendation from Norman Field Intelligence should be the primary hypothesis for a Kohavi-rigorous A/B test. Norman without Kohavi is theory; Kohavi without Norman is undirected guessing."
laja_integration:
  feeds_from: [laja-field-intelligence]
  feeds_to: [laja-voice-of-customer-miner]
  shared_data: "Laja's ResearchXL methodology mines voice-of-customer to surface the visitor's actual mental model. Norman's Conceptual Model Triangle requires that the System Image (what the page shows) match the User Model (what the visitor believes). Combined: Laja provides the empirical input for the User Model — what visitors actually believe about the page, its CTAs, and the outcome of clicking. Without Laja's research, Norman's Conceptual Model analysis is hypothetical. With it, every misalignment is verifiable and fixable."
hick_integration:
  feeds_from: [hick-field-intelligence]
  feeds_to: [hick-field-intelligence]
  shared_data: "Hick's Law: reaction time = b × log2(n choices). Norman's Gulf of Execution widens with every competing clickable element. Combined: Fitts motor cost + Hick choice cost + Norman gulf cost = total action cost. Each additional CTA on a page raises Hick cost AND splits the visitor's signifier-reading load. Norman's single-action page architecture directly expresses Hick's prescription: minimize n to minimize reaction time. The synthesis: audit competing elements through both lenses before removing anything — Hick scores the choice, Norman scores whether the surviving choice is perceivable."
nielsen_integration:
  feeds_from: [nielsen-field-intelligence]
  feeds_to: [nielsen-field-intelligence]
  shared_data: "Nielsen's usability heuristics (visibility, match with world, user control, consistency, error prevention, recognition, flexibility, aesthetics, recovery, help) are page-level expressions of Norman's deeper principles — consistency is natural mapping, visibility is discoverability, error prevention is constraint architecture, recognition-over-recall is knowledge-in-the-world. Combined: Norman explains WHY each Nielsen violation hurts; Nielsen provides the audit checklist to catch every Norman failure mode. The synthesis: use Nielsen to find the violations, Norman to diagnose the mechanism, and fix at the Norman level to solve whole classes of heuristic failures simultaneously."
eyal_integration:
  feeds_from: [eyal-field-intelligence]
  feeds_to: [eyal-hook-loop-designer]
  shared_data: "Eyal's Hook Model maps the habit loop: trigger → action → variable reward → investment. Norman maps the action cycle: goal → intention → specify → execute → perceive → interpret → evaluate. The Action stage in Eyal's Hook is Norman's Stages 2-4; the Reward stage is Norman's Stages 5-7. Combined: a page that closes Norman's Gulf of Execution enables Eyal's trigger-to-action transition; a page that closes Norman's Gulf of Evaluation enables the reward perception that drives the next loop. Norman friction in either gulf breaks the Hook."
brignull_integration:
  feeds_from: [brignull-field-intelligence]
  feeds_to: [brignull-dark-pattern-scanner]
  shared_data: "Brignull catalogs dark patterns — design that exploits users by manipulating signifiers, mappings, and feedback to trick rather than help. Norman's principles are the positive standard; Brignull's dark patterns are deliberate violations of those principles. Combined: Norman's signifier stack reveals WHERE dark patterns operate (manipulated affordance signals, false feedforward, misleading feedback). Every dark pattern in Brignull's taxonomy has a Norman mechanism: confirmshaming exploits semantic constraints; roach motels exploit action-to-undo asymmetry; hidden costs sabotage Gulf of Evaluation. Use Norman to detect, use Brignull to name and classify."
gigerenzer_integration:
  feeds_from: [gigerenzer-field-intelligence]
  feeds_to: [gigerenzer-field-intelligence]
  shared_data: "Gigerenzer's fast-and-frugal heuristics describe how visitors make decisions with minimal information. Norman's knowledge-in-the-world principle prescribes externalizing information so visitors need no memory. Combined: visitors are applying one-reason decision-making on the page — scanning for a single strong signifier to guide action. A page with multiple competing signifiers violates both Gigerenzer (too many cues) and Norman (no single dominant affordance). The synthesis: design the signifier hierarchy so the first cue a heuristic-scanning visitor hits is the CTA."
goward_integration:
  feeds_from: [goward-field-intelligence]
  feeds_to: [goward-field-intelligence]
  shared_data: "Goward's conversion research identifies the psychological levers behind page optimization. Norman provides the interaction-design substrate underneath those levers. Combined: Goward's messaging hierarchy requires that the most conversion-relevant message be the most visually signified element on the page. If the strongest message has the weakest signifier (low contrast, ambiguous affordance), Goward-level copy improvements will underperform. The synthesis: align Norman signifier hierarchy with Goward's persuasive hierarchy so the most important message is also the most discoverable action."
fogg_integration:
  feeds_from: [fogg-field-intelligence]
  feeds_to: [fogg-behavior-mapper]
  shared_data: "Fogg's B=MAP model identifies Motivation × Ability × Prompt as the three behavior determinants. Norman's page-action work is a sub-system of Ability — every gulf and signifier failure is an ability cost. Combined: Norman diagnoses the Ability component with surgical precision. When Fogg's Ability audit flags a page as 'hard,' Norman's Six skills reveal WHICH ability cost is highest: Gulf of Execution (can't figure out what to do) vs. Gulf of Evaluation (can't confirm what happened) vs. signifier deficit (can't see where to act) vs. mapping failure (can't predict outcome from layout). Fix at the Norman level; verify at the Fogg level."
cialdini_integration:
  feeds_from: [cialdini-field-intelligence]
  feeds_to: [cialdini-influence-audit]
  shared_data: "Cialdini's six principles (reciprocity, commitment, social proof, authority, liking, scarcity) operate through the same signifier channels Norman maps. A social proof element with weak signifiers (small font, low contrast, buried below fold) delivers zero influence impact. Combined: Cialdini determines WHICH principles to deploy on the page; Norman determines HOW to signal them so they are actually perceived. The synthesis: audit every influence element through Norman's signifier stack — influence without discoverability is wasted copy."
kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: [kahneman-framing-engineer]
  shared_data: "Kahneman's System 1 / System 2 model describes the fast-automatic vs. slow-deliberate processing modes. Norman's knowledge-in-the-world principle and signifier stack are designed for System 1 comprehension — visitors should not need to deliberate. Combined: every Norman signifier failure forces System 2 engagement, increasing cognitive effort and abandonment probability. Kahneman's peak-end rule also applies to Norman's feedback: the quality of the post-click feedback state (System Image after action) is the visitor's peak experience of the page. Optimize for System 1 discoverability; make the feedback moment the peak."
thaler_integration:
  feeds_from: [thaler-field-intelligence]
  feeds_to: [thaler-nudge-auditor]
  shared_data: "Thaler's choice architecture shapes decisions through defaults, framing, and structure. Norman's constraint architecture shapes decisions through physical, semantic, cultural, and logical constraints. Combined: Thaler and Norman are operating at the same level — both design the decision environment, not just the message. Thaler's defaults should be set to the most Norman-compatible choice (the action with the strongest signifier stack). The synthesis: every choice architecture decision from Thaler should be expressed through Norman's constraint types so the structural nudge is also the maximally visible affordance."
iyengar_integration:
  feeds_from: [iyengar-choice-set-auditor]
  feeds_to: [iyengar-choice-set-auditor]
  shared_data: "Iyengar's choice overload research proves that too many options reduce conversion. Norman's single-action page architecture reaches the same prescription from the interaction side. Combined: Iyengar scores the choice set size; Norman audits whether the surviving choice is properly signified. A page reduced to one CTA (Iyengar) with a weak signifier stack (Norman failure) still underperforms. The synthesis: Iyengar reduces the choice set to one; Norman maximizes the discoverability and confirmability of that one choice."
---

# Don Norman Field Intelligence

---

## LAYER 1: INVARIANTS (Never override.)

1. **Synthesis, not summary.** This skill finds PATTERNS ACROSS the six Norman skills — convergence zones, contradictions, amplification opportunities, The Single Move. If the output recaps what six reports found, it has failed.

2. **Convergence detection is mandatory.** When 3+ Norman skills flag the same page element or stage of the Seven Stages Action Cycle: that is a convergence zone. Name it. Score it. It is the highest-confidence finding.

3. **Contradictions must be surfaced, not hidden.** When one Norman skill recommends adding an element and another recommends removing it: both may be correct in their own frame. Resolve by identifying which Norman mechanism dominates in this specific context.

4. **The Single Move is non-negotiable.** One highest-leverage page change. Not a list. ONE move that closes the most Norman gulfs simultaneously or eliminates the most acute signifier failure.

5. **The Mirror is non-negotiable.** Examine the business's own page-design biases — where the design team is exhibiting Norman failures in their own process (designer's curse, over-relying on knowledge-in-the-head, building complex systems on the assumption that users share the team's conceptual model).

6. **Cross-system intelligence is the highest-value section.** Norman's gulfs interact with Fitts motor cost, Hick choice cost, Pirolli information scent, Kohavi testable hypotheses, Fogg ability, Cialdini influence, and every other system in the Click Architects network. That interaction layer is where the non-obvious insights live.

7. **Freshness gate: 45 days.** Flag any individual Norman skill output older than 45 days as potentially stale.

---

## LAYER 2: QUALITY GUIDANCE

8. **Name convergence zones memorably.** Label each pattern to capture the diagnostic insight (e.g., "The Invisible CTA" when Affordance Auditor + Gulf of Execution + Mapping Auditor all flag the same button, "The Silent Confirmation" when Gulf of Evaluation + Feedback Designer both flag missing post-click feedback).

9. **Quantify where possible.** Tie convergence zones to estimated impact on the desired action metric (click rate, opt-in rate, purchase rate). Use before/after framing: "CTA with single-layer signifier stack converts at X%; adding all four signifier layers typically lifts 15-35%."

10. **The 45-Day Projection must be specific.** Not "things should improve." Instead: "If The Single Move is implemented in week 1, click-through on the primary CTA should move from X% to Y% by day 30 based on the signifier gap identified in Skill 1 and confirmed by Skill 2."

---

## PURPOSE

The six Norman page-action skills each audit one dimension of the action architecture: signifiers and affordances, closing the Gulf of Execution, closing the Gulf of Evaluation, natural mapping, feedback-state design, and error recovery. Each finds real problems. None finds the system.

Norman Field Intelligence finds the system. It identifies which Norman mechanisms are co-firing on the same page element, names those convergence zones, quantifies their combined impact, resolves the contradictions between skills, and delivers THE SINGLE MOVE — the one intervention that produces the highest lift on the desired page action.

It then situates every Norman finding within the full Click Architects network: Fitts motor cost, Hick choice burden, Pirolli scent, Kohavi testing discipline, Eisenberg persuasion sequencing, Fogg ability cost, Cialdini influence visibility, and the rest. This is where the non-obvious leverage appears.

Brag: "Every action on our page is obvious and every click confirms itself."

---

## INPUT REQUIREMENTS

**Required:** Outputs from at least 4 of the 6 Norman skills, all run on the same page with the same stated desired action.

**Optimal:** All 6 Norman skill outputs + Field Intelligence from other Click Architects thinkers (Fitts, Pirolli, Eisenberg, Fogg, Cialdini, Kahneman, Thaler, Iyengar, Laja, Hick, Nielsen, Eyal, Brignull).

**Also useful:** Heatmap data, click-through rates on primary CTA, session recordings, first-click test results, form abandonment rates.

---

## EXECUTION PROCESS

### Step 1: Component Synthesis

For each available Norman skill output, extract:

| Field | What to record |
|-------|---------------|
| Skill | Name and run date |
| Age | Current (≤45d) / Aging (46-60d) / Stale (>60d) |
| Key findings | Top 3 Norman violations found |
| Recommended fix | What the skill prescribed |
| Stage of Action Cycle | Which of the 7 stages is broken |
| Gulf affected | Execution / Evaluation / Both |

_Legend: Age = days since skill was run on this page._

### Step 2: Convergence Detection

Cross-skill pattern matching using the Seven Stages as the common axis:

**Convergence scoring:**
- 2 skills flagging same stage/element: Notable alignment
- 3 skills: Convergence zone — name it
- 4 skills: Strong convergence
- 5-6 skills: Critical convergence — this is The Single Move candidate

**For each convergence zone:**
- **Name** (memorable label)
- **Contributing skills** (which of the 6 flagged it)
- **Stage of Action Cycle broken** (1-7)
- **Gulf implicated** (Execution / Evaluation / Both)
- **Implied intervention** (what the pattern demands)
- **Estimated lift** (percentage range based on signifier-stack research)

**Common Norman convergence patterns:**
- Affordance Auditor + Gulf of Execution + Mapping Auditor all flag the CTA: "The Invisible CTA" — every click-side Norman mechanism fails on the same element
- Gulf of Evaluation + Feedback Designer both flag post-click: "The Silent Confirmation" — visitor cannot perceive that the action succeeded
- Mapping Auditor + Error Recovery + Gulf of Execution flag form layout: "The Disorienting Form" — spatial layout contradicts reading order AND errors increase gulf width
- Signifier Auditor + Feedback Designer + Gulf of Evaluation all flag button state: "The Unresponsive Button" — no feedforward, no feedback, no perceived state change

### Step 3: Contradiction Detection

Identify cross-skill tensions before prescribing fixes:

**Common Norman contradiction patterns:**
- Affordance Auditor says add more visual weight to CTA ↔ Mapping Auditor says the heavy CTA pulls attention away from the prerequisite copy that must be read first
- Gulf of Execution Reducer says simplify page to one action ↔ Error Recovery Architect says a second "undo" affordance is required to lower commitment cost on the primary action
- Feedback Designer says add immediate confirmation animation ↔ Gulf of Evaluation Reducer says the animation introduces ambiguity about whether processing is complete
- Signifier Auditor says use stronger color contrast on CTA ↔ Mapping Auditor says CTA color already violates the page's established semantic constraint system (red = warning)

**For each contradiction:**
1. State the tension precisely
2. Explain why both skills are correct in their own frame
3. Resolve by identifying which Norman mechanism takes precedence for this page's desired action
4. Prescribe the implementation that honors the deeper insight from both

### Step 4: Amplification Opportunities

Where combining two or more Norman fixes creates outsized lift:

- **Signifier stack × feedforward microcopy:** Adding all four signifier layers to the CTA simultaneously with feedforward copy below it closes Gulf of Execution at Stage 2 (intention) AND Stage 3 (specify action) simultaneously. Worked example: button changes from flat gray "Submit" → raised green "Get Instant Access" with "You'll receive login details in 60 seconds — no credit card required" below. Stage 2 clarity improves (visitor knows what to do) AND Stage 3 certainty improves (visitor knows what will happen).
- **Natural mapping × error-prevention constraints:** Aligning tab order with reading order (mapping) + disabling Submit until required fields complete (physical constraint) eliminates both Gulf of Execution failures and slip-type errors in one structural change.
- **Feedback state × Gulf of Evaluation:** Redesigning button state (idle → processing → success) with microcopy at each state closes Gulf of Evaluation at Stage 5 (perceive), Stage 6 (interpret), and Stage 7 (evaluate outcome) simultaneously. Single design change addresses three consecutive stages.

### Step 5: The Single Move

One recommendation that addresses the most convergence zones. Structure:

- **The Move:** The specific, concrete page change
- **Which convergence zones it closes:** Name each
- **Norman mechanism:** Which gulf it bridges and at which stage of the Action Cycle
- **Implementation steps:** Concrete, ordered, completable in one sprint
- **Measurement:** The exact metric to watch and the threshold that confirms success
- **Worked example:** Before → After on a sample landing page element
- **What it does NOT address:** Honest about remaining gaps

**Measurement threshold rule:** If the primary CTA click-through rate does not increase by at least 10% within 14 days of implementation (sufficient traffic assumed), the Single Move has not fired — reassess whether the convergence zone diagnosis was correct.

### Step 6: The Mirror

Where the design team's own Norman failures operate:

- **Designer's curse:** The team assumes visitors share their knowledge-in-the-head about what the button does, where to click next, and what the outcome will be. Symptom: no feedforward microcopy, vague CTA labels, no tooltips.
- **Conceptual model assumption:** The Design Model (intended interaction) is clear to the team but never verified against the User Model (what visitors actually believe). No first-click testing, no session recording review, no Laja voice-of-customer mining.
- **Signifier neglect:** The team adds new CTAs without applying the full four-layer signifier stack (shape + color + label + hover state). Each new CTA ships with partial signifiers because the team "knows" it's a button.
- **Feedback assumption:** Post-action states are treated as technical outputs, not UX moments. Thank-you pages are generic; button states are not designed; confirmation emails are auto-generated. The Gulf of Evaluation after conversion is the widest gulf on the page.
- **Mapping creep:** Form fields, checkboxes, and step sequences accumulate without auditing spatial correspondence to reading order or logical flow. Natural mapping degrades with every added element.

### Step 7: Cross-System Intelligence

Synthesize with available Click Architects Field Intelligence outputs.

**Norman × Fitts:** Motor cost + gulf cost = total action cost. Fitts identifies which CTAs are physically hard to reach; Norman identifies which are cognitively hard to understand. Fix in order: first make the CTA large and close (Fitts), then make it visually signified (Norman). Attempting Norman fixes on a Fitts-failing button is premature.

**Norman × Hick:** Each competing clickable element raises Hick reaction time AND splits Norman signifier attention. Hick's Law quantifies the cost of each additional choice; Norman's single-action page architecture is the prescription. Together: reduce the choice set to one (Hick), then signal that one choice with maximum signifier coverage (Norman).

**Norman × Pirolli:** Information scent (Pirolli) travels through signifiers (Norman). A CTA with strong scent words but weak signifier stack is invisible. A CTA with strong signifiers but weak scent words attracts clicks from wrong-intent visitors. The highest-converting CTAs score high on both dimensions simultaneously.

**Norman × Eisenberg:** Eisenberg's persuasion architecture defines WHAT the visitor needs to believe before clicking. Norman's signifier architecture defines WHETHER the visitor can see where to click. Combined: run Eisenberg first (is the persuasion architecture complete?), then Norman (is the action clearly signified?). Persuasion fixes on a Norman-broken CTA waste copywriting effort.

**Norman × Kohavi:** Every Norman convergence zone is a testable hypothesis. The Single Move recommendation is the primary A/B test hypothesis. Kohavi's discipline prevents acting on Norman theory without controlled evidence. Required output: translate The Single Move into a precise A/B hypothesis (control vs. treatment, primary metric, minimum detectable effect, required sample size).

**Norman × Laja:** Laja's ResearchXL mines what visitors actually believe — the User Model in Norman's Conceptual Model Triangle. Without Laja, User Model assumptions are hypothetical. With Laja data, every Norman signifier fix can be targeted at the specific misalignment between System Image and User Model that the research surface.

**Norman × Nielsen:** Nielsen's heuristics (visibility of system status, match with real world, recognition over recall, error prevention, help users recognize/diagnose/recover) are practical checklists for Norman's theoretical principles. Use Nielsen to find violations fast; use Norman to fix at the root-cause level rather than patching individual heuristic violations.

**Norman × Eyal:** Eyal's Hook action stage requires that the desired behavior have minimum ability cost. Norman's gulf reduction is ability-cost reduction. A page optimized for Norman (both gulfs closed, strong signifiers, natural mapping) enables Eyal's trigger-to-action transition. Every Norman failure point is a Hook interruption.

**Norman × Brignull:** Brignull's dark patterns are deliberate violations of Norman principles — signifiers that mislead, mappings that confuse, feedback that misdirects. Audit every Norman-flagged element through the Brignull scanner: is this a design failure or a dark pattern? The fix is identical (correct the Norman violation) but the strategic response differs.

**Norman × Gigerenzer:** Gigerenzer's visitors use one-reason heuristics to scan pages. Norman's signifier hierarchy determines which element gets scanned first. Design the signifier stack so that the first element a fast-heuristic visitor encounters IS the primary CTA. If any other element has stronger signifiers than the CTA, the page will generate wrong clicks.

**Norman × Goward:** Goward's conversion research produces the message hierarchy (what to say and in what order). Norman produces the signifier hierarchy (what to make visible and with what weight). These must align: Goward's most persuasive message should carry Norman's strongest signifier stack. Misalignment wastes both great copy and great design.

**Norman × Fogg:** Norman gulf failures are Ability bottlenecks in Fogg's B=MAP model. Closing both Norman gulfs is the fastest way to raise the Ability component without changing the offer. Combined: when Fogg's system flags low conversion as a Motivation problem, check Norman first — misdiagnosed Ability failures are frequently treated with Motivation interventions (more urgency copy, more social proof) that fail because the real constraint is the visitor can't figure out what to do or confirm it worked.

**Norman × Cialdini:** Every Cialdini influence element (social proof, authority badge, scarcity notice) must pass Norman's signifier audit. An authority element with weak visual weight is not perceived. A scarcity counter with no feedforward (what happens when it hits zero?) creates Gulf of Execution uncertainty. Norman makes Cialdini's influence elements actually perceivable and predictable.

**Norman × Kahneman:** Kahneman's System 1 is the operating mode of page visitors. Norman's principles (knowledge-in-the-world, signifiers, natural mapping) are System 1-compatible design. Every Norman gulf failure forces System 2 engagement — deliberate, effortful, and abandonment-prone. Kahneman's peak-end rule: the post-click confirmation state (feedback) is the peak experience of the page interaction; design the Gulf of Evaluation closure as the emotional peak, not an afterthought.

**Norman × Thaler:** Thaler's defaults are the page's pre-selected state; Norman's constraints define what states are reachable from there. Align: set the default to the desired action (Thaler), then use Norman's constraint architecture to make the default the only obviously available path (physical, semantic, cultural, logical constraints all pointing toward the same action).

**Norman × Iyengar:** Iyengar says eliminate choice to increase conversion. Norman says make the surviving choice maximally discoverable and confirmable. Combined prescription: reduce to one CTA (Iyengar), then apply the full Norman signifier stack to that single CTA (Norman). Neither alone is sufficient — one CTA with poor signifiers still underperforms.

**Cross-system convergence:** The highest-confidence finding from this network is where Norman, Fitts, Hick, and Iyengar all converge on the same element: one CTA, physically accessible, cognitively discoverable, with minimum choice burden, fully signified. Pages that satisfy all four systems simultaneously produce the highest measured click-through rates.

### Step 8: Coherence Map

Score the page's Norman coherence on four dimensions (1-10 each):

| Dimension | Score | What it measures |
|-----------|-------|-----------------|
| Gulf closure | 1-10 | Both gulfs addressed adequately |
| Signifier coverage | 1-10 | CTA signifier stack completeness |
| Mapping fidelity | 1-10 | Layout-to-action correspondence |
| Feedback completeness | 1-10 | Post-action state communication |

_Legend: Score = 1 (complete failure) to 10 (no detectable Norman violation). Gaps = dimensions scoring below 7._

Flag lowest-scoring dimension as the priority repair target. A page scoring below 6 on any single dimension will underperform regardless of copy quality.

### Step 9: 45-Day Conversion Projection

Specific, measurable predictions tied to The Single Move:

**Days 1-14:**
- The Single Move implemented
- Primary CTA click-through rate should show movement; monitor daily
- If no movement by day 10, revisit convergence zone diagnosis — the gulf identified may not be the binding constraint

**Days 15-30:**
- Signifier stack stabilizes; visitor behavior reflects new design
- Compare click-through rate to pre-intervention baseline
- Run first-click test to verify the primary CTA is now the first element visitors click

**Days 31-45:**
- Full conversion funnel impact visible (click → form completion → purchase/opt-in)
- Identify the next Norman constraint: which stage of the Action Cycle is now the bottleneck?
- Generate input requirements for the next Norman Field Intelligence cycle

---

## OUTPUT STRUCTURE

### Don Norman — Page Action Intelligence Briefing

**Section 1: Input Status & Freshness**
All Norman skill outputs with freshness assessment and confidence rating.

**Section 2: Convergence Map**
Named convergence zones with contributing skills, stages, gulfs implicated, and implied interventions.

**Section 3: Contradiction Analysis**
Resolved tensions between competing Norman recommendations.

**Section 4: Amplification Opportunities**
Combined Norman interventions that produce outsized impact on desired action rate.

**Section 5: The Single Move**
One highest-leverage page change with implementation steps, measurement threshold, and worked before/after example.

**Section 6: The Mirror**
Design team's own Norman failure patterns examined.

**Section 7: Cross-System Intelligence**
Interactions across the full Click Architects network — Fitts, Hick, Pirolli, Eisenberg, Kohavi, Laja, Nielsen, Eyal, Brignull, Gigerenzer, Goward, Fogg, Cialdini, Kahneman, Thaler, Iyengar.

**Section 8: Coherence Map**
Four-dimension Norman coherence score with priority repair target.

**Section 9: 45-Day Conversion Projection**
Specific predictions at 14/30/45-day milestones.

---

## OUTPUT FILE

Save complete briefing to:
`[project-folder]/Don Norman - Field Intelligence/[YYYY-MM] - Page Action Intelligence Briefing.md`
