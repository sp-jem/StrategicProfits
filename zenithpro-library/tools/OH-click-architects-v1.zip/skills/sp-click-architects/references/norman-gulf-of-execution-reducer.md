---
name: norman-gulf-of-execution-reducer
description: Use when a page has a clear desired action but visitors stall, hesitate, or fail to click — closes the how-do-I-act gap by making the path to the desired action self-evident using Norman's Seven Stages and Gulf of Execution frameworks.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Don Norman (The Design of Everyday Things, 1988 / 2013; Seven Stages of Action, Two UX Gulfs, Signifier Stack) — Click Architecture (Skill 2 of 7)"
interface:
  invoke: "/norman-gulf-of-execution-reducer"
  calls: []
  called_by: [user, norman-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "CTA placement, copy, and signifier effectiveness shift with every design iteration and A/B test; findings older than 45 days no longer reflect the live page."

norman_signifier_integration:
  feeds_from: norman-affordance-signifier-auditor
  feeds_to: norman-gulf-of-evaluation-reducer
  shared_data: "Signifier stack completeness score (shape + color + label + hover); affordance-perception gap findings; CTA discoverability rating. Signifier audit runs first — execution-reducer uses its output as baseline and hands off to evaluation-reducer once click is secured."

fitts_integration:
  feeds_from: fitts-field-intelligence
  feeds_to: norman-gulf-of-evaluation-reducer
  shared_data: "CTA target size (px), distance-to-target from reading terminus, Fitts index of difficulty (ID = log2(2D/W)). Fitts defines motor-execution cost; Norman defines cognitive-execution cost. Both must be minimized to close the Gulf of Execution fully."

fogg_integration:
  feeds_from: fogg-field-intelligence
  feeds_to: norman-mapping-auditor
  shared_data: "Fogg Ability score (time/effort/physical/brain cycles/social deviance/non-routine); Norman Execution Stage where ability breaks. Low Fogg Ability = high Gulf of Execution. Norman constraints + signifiers are the on-page mechanism Fogg's prompt must land into."

iyengar_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: norman-gulf-of-evaluation-reducer
  shared_data: "Choice count on page; Iyengar paradox-of-choice threshold (>7 options degrades decision quality). Multiple CTAs or navigation links widen the Gulf of Execution by splitting intention formation — iyengar audit quantifies how many competing clickables exist."
---

# Norman: Gulf of Execution Reducer

## LAYER 1: INVARIANTS (Never override.)

1. **Audit at the stage level, not the page level.** The Seven Stages of Action are the diagnostic unit. A visitor who knows what they want (Stage 1) but cannot identify the right element to click (Stage 3: Specify Action) has a different failure than one who cannot formulate an intention (Stage 2). Prescriptions must target the exact failing stage.
2. **Signifier stack is all-or-nothing.** A CTA without all four signifier layers (shape, color contrast, action-verb label, hover state) is not fully signified. Removing any single layer measurably reduces discoverability. Do not accept partial stacks as "good enough."
3. **Knowledge in the World over Knowledge in the Head.** Every conversion-critical piece of information — what the CTA does, what fields are required, what comes next — must appear on the page. Never require the visitor to remember, infer, or already know.
4. **One action, one page.** Each additional clickable element that is NOT the desired action widens the Gulf of Execution by competing for Stage 2 (Intention Formation). Audit every clickable. Non-essential clickables are execution friction.
5. **Feedforward is not optional.** Feedback-only pages address evaluation, not execution. Microcopy beneath every CTA stating what happens next is a required execution element, not a nice-to-have.
6. **Constraints gate errors before they occur.** Slips (correct goal, wrong execution) are prevented by physical and logical constraints — not by user willpower. Disable submit until valid; mask invalid input; use logical sequencing. Do not rely on the visitor catching their own errors.
7. **Natural mapping must be explicit.** Tab order, visual hierarchy, and spatial arrangement must match the intended action sequence. Any mismatch between reading order and action order increases cognitive load at Stage 3.

## LAYER 2: QUALITY GUIDANCE

1. **Score each of the first four stages independently.** A valid execution audit produces a per-stage friction rating (0-10 scale, 0=no friction). Aggregate scoring masks the actual failure point.
2. **Every diagnosis must be falsifiable.** Specify the metric that will confirm improvement: first-click accuracy rate, CTA CTR, form completion rate, time-to-first-click. "Should feel clearer" is not acceptable.
3. **Prioritize by stage order.** Stage 1-2 failures (goal/intention) override Stage 3-4 failures (specification/execution). Fixing a click mechanic when the visitor has not formed an intention is wasted effort.
4. **Before-after must be explicit.** Every recommendation includes the current state and the rewritten/redesigned state on the specific page being audited — not generic advice.
5. **Check interaction with evaluation gulf.** Fixes that close execution may open evaluation if the resulting feedback is ambiguous. Flag handoff to norman-gulf-of-evaluation-reducer for any change that alters post-click state.

## PURPOSE

This skill applies Don Norman's Gulf of Execution framework directly to a live web page to close the gap between what a visitor wants to do and the actions visibly available to them. The lever: audit every element of the visitor's action path through Norman's Seven Stages (Goal → Intention → Specify → Execute), identify exactly which stage breaks, and apply the corresponding mechanism — signifier stacks, feedforward microcopy, constraint gating, natural mapping, and single-action architecture — to make the desired action the only obviously correct next move.

**Brag-line:** "Every action on our page is obvious and every click confirms itself."

This is not a UX essay. It is a diagnostic-and-fix protocol that outputs specific copy, layout, and constraint changes mapped to the exact stage where execution breaks on this specific page.

## INPUT REQUIREMENTS

**Required:**
- Page: URL, live screenshot, or written description with enough detail to identify all clickable elements, CTA copy, form fields, and navigation present.
- Desired action: One specific action (e.g., "click the opt-in button," "complete the checkout form," "click the schedule-a-call CTA").

**Optional (improves precision):**
- Heatmap or click-map data (identifies where visitors look vs. click)
- First-click test results
- Form completion rate and drop-off field
- Current CTA CTR
- Audience: cold/warm/hot (affects Stage 1: Goal Formation assumptions)
- Funnel position (top-of-funnel pages require more feedforward; bottom-of-funnel pages have more formed intentions)

## EXECUTION PROCESS

### Step 1: Stage-by-Stage Execution Audit (Stages 1-4)

Work through each stage sequentially. Score each 0-10 (0 = no friction, 10 = complete block). Record the specific page element causing friction.

| Stage | Question | Friction Signal | Score |
|-------|----------|-----------------|-------|
| 1 Goal | Is the page's value proposition clear enough to form a goal? | Vague headline, missing outcome statement | 0-10 |
| 2 Intent | Does the page generate a specific intention (not just curiosity)? | Competing messages, no dominant offer | 0-10 |
| 3 Specify | Can the visitor identify the exact element to click? | Low-signifier CTA, multiple competing CTAs | 0-10 |
| 4 Execute | Is the mechanical action (click, type, submit) frictionless? | Small targets, disabled state unclear, input masks absent | 0-10 |

**Threshold:** Any stage scoring >= 6 requires a fix before lower-priority stages are addressed.

### Step 2: Signifier Stack Audit (Stage 3 focus)

For the primary CTA, check all four layers:

- **Shape:** Is the CTA a raised button (not flat text, not underlined link)? (Yes/No)
- **Color contrast:** Does the CTA color appear NOWHERE ELSE on the page? (Yes/No — if the same color appears elsewhere, the signifier is diluted)
- **Label:** Is the label an action verb with specific outcome? ('Get Instant Access' = pass; 'Submit' = fail; 'Learn More' = fail)
- **Hover state:** Does the button visually respond to cursor contact within 100ms? (Yes/No)

Score: 4/4 = fully signified. Each missing layer = -1. Score <= 2 = critical failure.

### Step 3: Feedforward Audit (Stages 2-3)

Feedforward answers "what will happen if I click?" BEFORE the click. Check:

- Is there microcopy within 20px below/above the CTA stating the immediate next event?
- Does it specify outcome, not just action? ("You'll receive instant login credentials" > "Click here")
- If a form is present, are all required fields marked visible (not just asterisked at bottom)?
- Is there a step indicator if multi-step? ("Step 1 of 3")

Each absent feedforward element = explicit friction at Stage 2-3.

### Step 4: Competing Clickable Count (Gulf of Execution Width)

Count every clickable element on the page that is NOT the desired action. This is the raw Gulf of Execution width.

- **0-2 competing clickables:** Narrow gulf. Acceptable.
- **3-5:** Moderate. Evaluate which to suppress.
- **6+:** Wide gulf. Audit is critical. Each competing element adds intention-split cost at Stage 2.

Navigation bars on conversion pages typically add 5-15 competing clickables. Default recommendation: suppress or remove on high-intent pages.

### Step 5: Constraint Architecture Check (Stage 4 — slip prevention)

Four constraint types applied to the desired action:

- **Physical:** Submit button disabled until required fields validly complete? Input masks on phone/email fields?
- **Semantic:** Destructive or irreversible actions styled distinctively (red, explicit warning copy)?
- **Cultural:** Validated fields show green checkmark? Progress fills left-to-right?
- **Logical:** Field count/completion state visibly communicated? (e.g., "2 of 3 fields complete")

Missing constraints = slip risk. Record which types are absent.

### Step 6: Natural Mapping Check

- Does tab order match reading order (top-to-bottom, left-to-right)?
- Do spatial relationships imply correct sequence? (CTA appears after value delivery, not before)
- Does visual hierarchy place the desired action at the dominant visual terminus of the reading path?

Misalignment = Stage 3 friction (visitor must consciously override their natural eye path to reach the CTA).

### Step 7: Stage-Priority Fix Stack

Rank fixes by stage (Stage 1 fixes before Stage 4 fixes). Output as ordered action list.

## OUTPUT STRUCTURE

**1. Stage Friction Scorecard**
Table: Stage | Question | Score | Primary Friction Element
(abbreviate column headers; max 6 cols; legend below)

**2. Critical Failures (score >= 6)**
List each with: Stage | Current state | Root cause (Norman mechanism) | Fix

**3. Signifier Stack Report**
CTA name | Shape | Color | Label | Hover | Stack Score (N/4) | Rewrite

**4. Feedforward Gap List**
Each missing feedforward element: Location on page | Stage addressed | Recommended microcopy

**5. Competing Clickable Audit**
Count | List of non-desired clickables | Suppression recommendation per item

**6. Constraint Gap List**
Constraint type | Present? | Fix required

**7. Priority Fix Stack (ordered)**
Numbered list: Fix | Stage it addresses | Expected metric impact | How to verify

**8. Before / After Summary**
Two-column before-after for the top 3 fixes on this specific page.

## WORKED MINI-EXAMPLE

**Page:** SaaS free-trial landing page. Desired action: click "Start Free Trial" button.

**Stage audit reveals:** Stage 3 score = 7 (critical). CTA uses flat text link styling ("Start free trial" underlined, same blue as all body links — no shape distinction, no unique color, no hover state). Stage 2 score = 5 (moderate). Headline reads "Powerful Analytics for Teams" — goal-adjacent but no intention trigger.

**Signifier stack:** Shape = fail (text link, not button). Color = fail (same blue as 3 other links on page). Label = partial pass ("Start" is action verb but outcome vague). Hover = fail (underline only, no state change). Stack score: 1/4.

**Feedforward:** None below CTA. No microcopy. No trial length stated anywhere on page.

**Competing clickables:** 14 (nav bar = 8, footer = 4, two in-body links = 2).

**Priority fix stack:**

1. (Stage 3) Rebuild CTA as raised button. Unique color (orange, appears nowhere else on page). Label: "Start My 14-Day Free Trial." Add hover: darken 15%, cursor: pointer. **Verify:** first-click accuracy rate on CTA target.

2. (Stage 3) Add feedforward microcopy below button: "No credit card required. Access all features instantly." **Verify:** CTA CTR uplift.

3. (Stage 2) Headline rewrite. Before: "Powerful Analytics for Teams." After: "See Every Customer Drop-Off in 60 Seconds — Free for 14 Days." Intention now formed before visitor reaches CTA. **Verify:** time-to-first-click reduction.

4. (Stage 1-2) Suppress top navigation on this page. Reduces competing clickables from 14 to 6. **Verify:** scroll depth to CTA; bounce rate.

**Before / After (CTA):**

| Element | Before | After |
|---------|--------|-------|
| Shape | Underlined text link | Raised button (border-radius 4px, shadow) |
| Color | #1a73e8 (same as body links) | #F26419 (unique on page) |
| Label | "Start free trial" | "Start My 14-Day Free Trial" |
| Hover | Underline only | Darken 15%, cursor pointer |
| Microcopy | None | "No credit card required. Access all features instantly." |

Legend: CTA = call-to-action; CTR = click-through rate; Stage = Norman's Seven Stages of Action stage number.

## OUTPUT FILE

Save to: [project-folder]/Norman - Click Architecture/[YYYY-MM] - Gulf of Execution Audit - [Page Name].md
