---
name: hick-decision-load-calculator
description: Use when a page has multiple CTAs, options, or competing links and conversions are lagging — computes the Hick-Hyman decision-time cost (log₂ of option count) for every decision point and ranks them by drop-off risk.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "William Hick & Ray Hyman (Hick 1952, Hyman 1953; Hick-Hyman Law + Hyman Entropy Extension) — Click Architecture (Skill 1 of 7)"
interface:
  invoke: "/hick-decision-load-calculator"
  calls: []
  called_by: [user, hick-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page layouts, CTA counts, and navigation structures change frequently; entropy scores become stale within 45 days of any redesign or A/B test cycle."

iyengar_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: hick-option-pruning-auditor
  shared_data: "Option count per decision zone; Jelly Jar Principle threshold violations (>6 items surface-displayed); catalog display entropy scores."

fogg_integration:
  feeds_from: fogg-prompt-designer
  feeds_to: hick-single-decision-enforcer
  shared_data: "Prompt placement and competing-click map; response-uncertainty score per CTA zone to confirm single-prompt alignment."

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: hick-default-path-designer
  shared_data: "Default pre-selection state; System-1 vs System-2 friction classification per decision point; peak-end scoring aligned with progressive disclosure sequence."
---

# Hick-Hyman Decision Load Calculator

## LAYER 1: INVARIANTS (Never override.)

1. **Formula is non-negotiable.** Decision reaction time RT = a + b × log₂(n+1). Use b = 0.155 s/option as the empirical constant. Every decision point on the page gets a computed RT estimate, not a gut call.
2. **Response uncertainty outweighs stimulus uncertainty.** Per Wifall et al. (2015), reducing available response actions (fewer CTA buttons at the same visual level) cuts more decision time than reducing visible menu items. Score response options first.
3. **Entropy, not raw count, governs high-probability zones.** Where one option dominates via visual hierarchy (size, color, placement), apply Hyman's H = -Σ p(i) × log₂(p(i)). A page with 5 options but one at p = 0.85 has lower H than a page with 3 equally weighted options. Model this; don't default to raw count.
4. **The scan covers the entire above-the-fold viewport AND the conversion zone separately.** A page may be clean above the fold but noisy at the CTA. Both zones require independent decision-load scores.
5. **Every decision point gets a risk tier.** Green (n ≤ 3), Yellow (n = 4–7), Red (n ≥ 8). Red zones are flagged for pruning before any copy or design changes.
6. **Time-to-first-click ≥ 8 seconds is the behavioral threshold.** When session recordings show median time-to-click on the primary CTA exceeding 8 s from page load, the decision load score predicts why. Flag it.
7. **Do not conflate this skill's job with pruning or categorization.** This skill DIAGNOSES load and computes cost. Recommendations to prune go to hick-option-pruning-auditor; chunking recommendations go to hick-categorization-architect.

## LAYER 2: QUALITY GUIDANCE

1. **Use real option counts from the actual page.** Count every distinct clickable element in each zone — nav links, CTA buttons, footer links, inline text links, modal triggers. Do not estimate or group without explicit justification.
2. **Apply Hyman's probability weighting when visual dominance is evident.** If a button is 3× the size of alternatives or uses the page's single high-contrast color, assign it p ≥ 0.60 and recalculate H accordingly. Document the assigned probabilities.
3. **Output a ranked decision-load table, not a prose list.** The ranked table (zone, n, RT estimate, H score, risk tier) is the primary deliverable. Prose summaries follow the table.
4. **Benchmark against conversion data when available.** If the user provides funnel analytics, correlate drop-off rates to decision-load scores per step. Hick-Hyman predicts the two move together.
5. **Flag secondary wins separately from primary CTA wins.** A navigation menu in Red tier costs time but may not be the conversion bottleneck. Primary CTA zone Red always gets priority.

## PURPOSE

This skill applies the Hick-Hyman Law (RT = a + b × log₂(n+1)) and Hyman's Entropy Extension (H = -Σ p(i) × log₂(p(i))) to map every decision point on a specific web page, compute the decision-time cost at each zone, and rank them by conversion risk. It treats the page as an information system with measurable cognitive load, not a design opinion.

**The lever:** Response uncertainty is the dominant coefficient in the Hick-Hyman equation. Cutting response options at the conversion zone from n = 5 to n = 1 eliminates ~1.32 seconds of processing latency per visitor — directly predictive of drop-off, not correlated with it.

**Brag-line (carry this to peers):** "We cut decision time by removing options, and we can prove the math."

## INPUT REQUIREMENTS

**Required:**
- The page — provide one of: live URL, screenshot, or written description with element inventory
- The ONE desired action (e.g., "click the 'Start Free Trial' button", "submit the opt-in form", "select a pricing tier")

**Optional but high-value:**
- Session recording data or heatmap (time-to-first-click on primary CTA)
- Funnel analytics (drop-off rate per step)
- Audience context (cold traffic vs. warm list — affects baseline entropy tolerance)
- Funnel position (top-of-funnel discovery page vs. checkout confirmation)

## EXECUTION PROCESS

### Step 1 — Zone Decomposition
Divide the page into decision zones. Standard zones:
- Z1: Global navigation bar
- Z2: Above-the-fold hero (first viewport)
- Z3: Body content / features section
- Z4: Primary conversion zone (main CTA area)
- Z5: Footer / secondary links
For single-page checkout or opt-in: Z4 = the form + submit button area.

### Step 2 — Option Inventory per Zone
Count every distinct clickable or selectable element within each zone. Include:
- Navigation links (each counts as 1)
- CTA buttons (each counts as 1)
- Inline text hyperlinks
- Form field select/radio/checkbox groups (each group = n options within it)
- Modal triggers, accordion toggles, tab headers
Record as: Zone | Element Type | Count

### Step 3 — Compute RT and H per Zone

**Equal-probability baseline (apply when visual weights are roughly equivalent):**
RT = a + b × log₂(n+1)
Use: a = 0 s (page-context baseline absorbed into measurement), b = 0.155 s

| n | log₂(n+1) | RT estimate (s) |
|---|-----------|-----------------|
| 1 | 1.00 | 0.16 |
| 2 | 1.58 | 0.24 |
| 3 | 2.00 | 0.31 |
| 5 | 2.58 | 0.40 |
| 7 | 3.00 | 0.47 |
| 10 | 3.46 | 0.54 |
| 15 | 4.00 | 0.62 |
| 30 | 4.95 | 0.77 |

**Entropy-weighted (apply when visual dominance is detectable):**
Assign p(i) to each option. Dominant option: p ≥ 0.60. Remaining options split residual probability.
H = -Σ p(i) × log₂(p(i))
Lower H = faster decision. An n = 5 zone with p = [0.70, 0.10, 0.10, 0.05, 0.05] yields H = 1.67 bits vs. H = 2.32 bits for equal-probability n = 5. Use H as the adjusted RT input: RT = b × H.

### Step 4 — Build the Decision-Load Scorecard

Columns: Zone | n | RT(s) | H | Tier | Primary Risk?

Tier thresholds:
- Green: n ≤ 3, RT ≤ 0.31 s
- Yellow: n 4–7, RT 0.32–0.47 s
- Red: n ≥ 8, RT ≥ 0.48 s

Flag any zone containing the desired action as "Primary Risk = YES" if Tier = Yellow or Red.

Legend: n = option count; RT = reaction time estimate (Hick-Hyman); H = Shannon entropy (bits); Tier = G/Y/R.

### Step 5 — Response-Uncertainty Priority Adjustment
Per Wifall et al. (2015): response uncertainty has a larger coefficient than stimulus uncertainty. Apply a 1.2× multiplier to RT for zones where multiple response TYPES exist at the same visual level (e.g., a zone with both a form submit AND two CTA buttons AND a "chat with us" link — three different response modalities). Note the multiplier in the scorecard.

### Step 6 — Behavioral Cross-Check
If session data is available:
- Map median time-to-first-click on primary CTA against the Z4 RT estimate. If observed > 2× estimated, there are hidden decision points (off-zone distractions, above-fold noise bleeding into attention).
- Map step drop-off rates to zone scores. Hick-Hyman predicts R ≈ 0.7+ correlation between log₂(n) and drop-off. Flag mismatches for investigation.

### Step 7 — Ranked Output + Handoff Flags
Rank all zones by RT descending. Top 2 Red zones = Priority 1 intervention. Annotate with the appropriate sibling skill to handle each:
- Too many options → hick-option-pruning-auditor
- Options need chunking → hick-categorization-architect
- Single CTA needs enforcing → hick-single-decision-enforcer
- Defaults needed → hick-default-path-designer

## OUTPUT STRUCTURE

**Section 1 — Decision-Load Scorecard**
Full ranked table (zones × metrics). Green/Yellow/Red tier per zone.

**Section 2 — Entropy Detail (for Yellow + Red zones)**
For each flagged zone: option inventory, p(i) assignments if weighted, H calculation shown step-by-step, RT estimate, response-uncertainty multiplier if applied.

**Section 3 — Primary CTA Diagnosis**
Focused analysis of the desired action's zone. Answers: What is the effective n at the moment of decision? What is the H? Does visual hierarchy reduce p(i) of competing options? Is time-to-first-click benchmark met?

**Section 4 — Ranked Intervention Queue**
Zones sorted by RT descending. Each row: zone, score, risk classification, recommended next skill from hick-* cluster, expected RT reduction if n is cut to target.

**Section 5 — Behavioral Benchmark (if data provided)**
Observed time-to-click vs. predicted RT. Drop-off correlation analysis.

## WORKED MINI-EXAMPLE

**Page:** SaaS pricing page. Desired action: click "Start Free Trial" (middle tier).

**Zone inventory (before):**
- Z1 Nav: 8 links (logo, Features, Pricing, Blog, Docs, Login, Start Free Trial nav, Contact) → n = 8
- Z4 Conversion: 3 tier cards each with own CTA button + "Compare all features" link + "Talk to Sales" link → n = 5 CTAs + 1 link = 6 response options

**Scorecard (before):**

| Zone | n | RT(s) | H | Tier | Primary? |
|------|---|-------|---|------|----------|
| Z1 Nav | 8 | 0.48 | 3.00 | Red | No |
| Z4 Conv | 6 | 0.44 | 2.58 | Yellow | YES |

Z4 with p(i) weighting: Middle tier is badged "Most Popular" (p = 0.60), other two tiers p = 0.15 each, "Compare" link p = 0.07, "Talk to Sales" p = 0.03. H = 1.87 bits. Adjusted RT = 0.155 × 1.87 = 0.29 s. Tier shifts to Green for the entropy-weighted model — visual hierarchy is doing work.

**Intervention:** Z1 Nav is still Red and bleeds attention into Z4. Recommendation → hick-option-pruning-auditor to cut Z1 to 5 items. Z4 already entropy-optimized via badge; no pruning needed if badge is maintained.

**After (projected):** Z1 pruned to 5 links (RT = 0.40 s, Yellow). Z4 stays entropy-weighted Green. Expected time-to-first-click on "Start Free Trial": drops from observed 11 s to ≤ 8 s threshold.

## OUTPUT FILE

Save to: [project-folder]/Hick-Hyman - Click Architecture/[YYYY-MM] - Decision Load Calculator.md
