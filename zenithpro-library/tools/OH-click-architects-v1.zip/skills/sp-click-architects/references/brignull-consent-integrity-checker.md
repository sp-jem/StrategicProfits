---
name: brignull-consent-integrity-checker
description: Use when a page collects email, billing, permissions, or subscription consent — audits every opt-in mechanism for pre-ticked traps, forced continuity, and disclosure failures, then outputs rewrite-ready fixes.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Harry Brignull (deceptivedesigns.com 2010–2023; The 16-Pattern Taxonomy, Disclosure Test, Honesty Spectrum, Roach Motel) — Click Architecture (Skill 4 of 7)"
interface:
  invoke: "/brignull-consent-integrity-checker"
  calls: []
  called_by: [user, brignull-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Regulatory thresholds (FTC click-to-cancel, GDPR, CAN-SPAM) update; A/B test winners rotate; consent UX evolves fast enough that a 6-week-old audit may miss new pattern variants."

brignull_cluster_integration:
  feeds_from: [brignull-dark-pattern-scanner, brignull-sludge-auditor]
  feeds_to: [brignull-ethical-line-mapper, brignull-fair-pattern-designer]
  shared_data: "Pattern inventory list + Disclosure Test verdicts. Scanner surfaces candidate patterns; this skill narrows to consent flows specifically; Ethical Line Mapper uses verdicts to draw the actionable boundary."

thaler_integration:
  feeds_from: [thaler-default-detector, thaler-nudge-auditor]
  feeds_to: [brignull-fair-pattern-designer]
  shared_data: "Default architecture. Thaler-default-detector flags which defaults exist; this skill applies the Disclosure Test to determine whether each default is a nudge (survives disclosure) or a dark pattern (collapses under disclosure)."

fogg_integration:
  feeds_from: [fogg-ability-auditor]
  feeds_to: [brignull-fair-pattern-designer]
  shared_data: "Ability/friction mapping. Fogg ability score on the conversion path vs. the exit path reveals Roach Motel asymmetry; this skill converts the asymmetry into a Parity Score and prescribes the equalizing fix."
---

# Brignull Consent Integrity Checker

## LAYER 1: INVARIANTS (Never override.)

1. **Every checkbox, toggle, and pre-selection is a consent claim.** Treat each as a testable assertion: does the default state match what a reasonable user would choose if they read it carefully? Default-ON = you are claiming they already chose this.
2. **Apply the Disclosure Test to every friction asymmetry.** If a fully-informed user, told in plain language what the element does, would still accept it — it is persuasion. If they would refuse — it is a dark pattern. No exceptions.
3. **Parity is the standard for entry vs. exit.** Click-count to subscribe must equal click-count to cancel. If they diverge, the excess on the exit side is a Roach Motel violation regardless of business justification.
4. **Price displayed first is the price the user agreed to.** Any final total more than 10% above the first-seen price is a Hidden Cost pattern. The 10% threshold is operationalizable and defensible in regulatory proceedings.
5. **Decline language must be factually neutral.** The Confirmshaming test: read the "No thanks" or opt-out copy aloud in a regulatory hearing. If it would embarrass the brand, rewrite it.
6. **Recurring billing terms are a visual-weight obligation.** Auto-renewal, subscription duration, and next-charge date must appear at visual parity (size, contrast) with the primary CTA — not below the fold, not in gray 9pt type.
7. **Consent obtained through ambiguity is not consent.** Double-negative opt-out language ("Uncheck this box if you do not wish to receive...") fails the Trick Wording standard automatically. Rewrite to affirmative plain language.

## LAYER 2: QUALITY GUIDANCE

1. **Name the pattern, cite the taxonomy.** Every finding maps to one of Brignull's 16 named patterns or one of Mathur et al.'s seven superordinate categories. "Feels off" is not an audit finding.
2. **Quantify the asymmetry.** Roach Motel findings include an entry click-count and an exit click-count. Hidden Cost findings include first-seen price and final price. Ratios over 1.5x or 10% respectively are report-worthy.
3. **Before/after rewrites are mandatory outputs.** For every pattern found, deliver the current copy verbatim and the compliant replacement. Not a vague instruction — an actual rewrite.
4. **Score severity on a 3-point scale.** CRITICAL (regulatory exposure, likely FTC/GDPR violation), HIGH (conversion inflated at the expense of user preference), MODERATE (design could be misread; fixable without structural change).
5. **Test against Honesty Spectrum position.** Every finding is placed on the three-point spectrum: Transparent Disclosure / Omission / Deliberate Deception. Omission findings get a "trigger" (what event would make this actionable — e.g., upcoming GDPR audit).

## PURPOSE

This skill applies Harry Brignull's consent-specific frameworks — the Preselection pattern, Roach Motel asymmetry, Honesty Spectrum, and the Disclosure Test — to a real web page's opt-in and sign-up flows to remove manufactured consent and replace it with genuine user preference.

**Brag line: "We use the strongest levers known — and we know exactly where the line is."**

Use this when: a page collects email consent, subscription enrollment, cookie permissions, billing authorization, or any opt-in/opt-out mechanism and you need to know whether the consent collected is genuine or manufactured.

## INPUT REQUIREMENTS

**Required:**
- The page — URL (for live audit), screenshot, or written description with copy verbatim
- The ONE desired action (e.g., "email opt-in," "paid subscription start," "free trial signup")

**Optional but high-value:**
- Analytics: form submission rate, checkout abandonment rate by step, cancel/refund rate
- Regulatory context: GDPR-covered audience (Y/N), US consumer (FTC exposure), COPPA
- Funnel position: top-of-funnel cold traffic vs. warm retargeting vs. existing customer upgrade

## EXECUTION PROCESS

**Step 1 — Consent Inventory (5 min)**

List every consent-collecting element on the page:
- Checkboxes (default state: checked / unchecked)
- Toggles (default state: on / off)
- Radio groups (which option is pre-selected)
- Hidden subscriptions (auto-enrollment buried in terms)
- Cookie consent banners (pre-accepted categories)
- "By clicking X you agree to..." strings

For each: record element type, default state, what it consents to, and visual prominence (above fold / below fold, font size relative to CTA).

**Step 2 — Preselection Pattern Audit**

Score each element:
- DEFAULT-ON → flag as Preselection (Brignull Taxonomy #13)
- DEFAULT-ON for a paid add-on → CRITICAL severity
- DEFAULT-ON for marketing consent → HIGH severity (GDPR: requires affirmative)
- DEFAULT-OFF but buried → Moderate (visual interference, not preselection)

Threshold: any consequential consent (billing, data sharing, recurring charge) that is not the result of a distinct affirmative act fails this step.

**Step 3 — Disclosure Test on Every Default**

For each flagged element, run the Disclosure Test:

> "If we showed a fully-informed user this sentence: '[plain-language description of what this element does]', would they still accept this default?"

Verdicts:
- SURVIVES: This is persuasion. Keep it, document it as clean.
- COLLAPSES: This is a dark pattern. Redesign required. Log under Brignull Taxonomy category.

**Step 4 — Roach Motel Parity Test**

Map the conversion path step-by-step: count clicks from page entry to completed desired action.
Map the exit path step-by-step: count clicks to cancel, unsubscribe, or undo the desired action.

Compute Parity Score = Exit Clicks / Entry Clicks.

- Score ≤ 1.2: Acceptable.
- Score 1.2–2.0: HIGH — structural friction asymmetry present.
- Score > 2.0: CRITICAL — likely Roach Motel pattern, FTC click-to-cancel exposure.

If exit requires phone, chat, or email (vs. in-app): automatic CRITICAL regardless of click-count.

**Step 5 — Honesty Spectrum Placement**

For each consent element, place it on the three-point spectrum:

| Position | Definition | Action |
|----------|-----------|--------|
| Transparent | Full terms + cost shown before commitment | Document as clean |
| Omission | Not lying but withholding material fact | Flag trigger event |
| Deception | Copy contradicts reality when read fully | CRITICAL — rewrite now |

"Omission" trigger events: upcoming renewal, price increase, data sale. If the page never surfaces these, note the trigger.

**Step 6 — Trick Wording & Confirmshaming Scan**

Search all opt-out, decline, and "No thanks" copy for:
- Double negatives ("Uncheck if you do not want...")
- Self-incriminating decline language ("No thanks, I don't want better results")
- Alternating opt-in/opt-out syntax across rows in a preference center

For each: record current copy, classify (Trick Wording / Confirmshaming), write compliant replacement.

**Step 7 — Visual Interference Check**

For each consent-qualifying disclosure (recurring charge date, auto-renewal terms, data sharing):
- Font size relative to CTA copy (should be ≥ 80% of CTA size)
- Contrast ratio (WCAG AA minimum: 4.5:1 for normal text)
- Position: above fold = acceptable; below CTA but on page = moderate; requires scroll = HIGH

Threshold: critical billing terms at less than 80% CTA font size and below the CTA = Visual Interference (Taxonomy #16).

**Step 8 — Priority Matrix**

| Severity | Pattern | Fix Type | Effort |
|----------|---------|---------|--------|
| CRITICAL | [name] | [rewrite/restructure] | [hrs] |
| HIGH | [name] | [copy/design] | [hrs] |
| MODERATE | [name] | [copy] | [hrs] |

(Max 6 columns, abbreviate as needed. Legend: Sev=Severity, Pat=Pattern Name, Fix=Fix Type, Eff=Effort estimate.)

## OUTPUT STRUCTURE

**Section 1 — Consent Inventory Table**
All consent elements: element type, default, what it consents to, visual prominence, initial verdict.

**Section 2 — Pattern Findings**
For each finding: Brignull taxonomy name + Mathur superordinate category + Conti-Sobiesk attack vector + Severity + Disclosure Test verdict + current copy verbatim + rewrite.

**Section 3 — Roach Motel Parity Report**
Entry path (steps listed) + Exit path (steps listed) + Parity Score + regulatory exposure note.

**Section 4 — Honesty Spectrum Map**
Each element placed on the three-point spectrum. Deception items get immediate rewrite. Omission items get a trigger event and a "disclose proactively" recommendation.

**Section 5 — Priority Action List**
CRITICAL items first, with exact copy replacements, design specs (font size, contrast, position), and structural changes. HIGH and MODERATE follow.

**Section 6 — Clean Consent Checklist**
Post-fix verification: 10 yes/no items a developer or designer can run through before re-launch.

## WORKED MINI-EXAMPLE

**Page:** SaaS free-trial signup. Desired action: start free trial.

**Before — three findings:**

1. Preselection (CRITICAL): Checkbox pre-ticked: "Yes, enroll me in the Pro annual plan at $299 on Day 15."
   Disclosure Test: Collapses — user signing up for a free trial would refuse if told this.
   Fix: Uncheck by default. Require affirmative check. Move billing terms above the CTA.

2. Confirmshaming (HIGH): Decline link reads: "No thanks, I'll keep losing money."
   Fix: "No thanks, I'll skip the trial."

3. Roach Motel (CRITICAL): Signup = 2 clicks. Cancel = email support@company.com + wait 3–5 days.
   Parity Score = ∞ (no in-app cancel path).
   Fix: Add in-app cancel under Account > Billing > Cancel Plan (target: ≤ 3 clicks).

**After — verified clean:**
- Trial enrollment has no pre-ticked billing upgrade.
- Decline copy is factually neutral.
- Cancel is 3 clicks, matching signup at 2 clicks (Parity Score: 1.5 — acceptable).
- $299 charge date appears in 14pt bold above the CTA (same font as "Start Free Trial").

## OUTPUT FILE
Save to: [project-folder]/Brignull - Click Architecture/[YYYY-MM] - Consent Integrity Audit - [Page Name].md
