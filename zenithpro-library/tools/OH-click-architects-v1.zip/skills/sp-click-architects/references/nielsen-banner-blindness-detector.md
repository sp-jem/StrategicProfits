---
name: nielsen-banner-blindness-detector
description: Use when a page has CTAs, opt-in forms, or offers that users are likely ignoring because they look like ads — detects ad-mimicking elements and redesigns or relocates them to trigger fixations.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Jakob Nielsen & Kara Pernice (Eyetracking Web Usability 2010; Banner Blindness Law 1997/2018; Four Scanning Patterns 2017) — Click Architecture (Skill 3 of 7)"
interface:
  invoke: "/nielsen-banner-blindness-detector"
  calls: []
  called_by: [user, nielsen-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Ad-association patterns shift as users adapt to new ad formats; right-rail blindness extends to new placements as platforms evolve."

nielsen_f_pattern_integration:
  feeds_from: nielsen-f-pattern-layout-auditor
  feeds_to: nielsen-attention-zone-placer
  shared_data: "F-pattern audit identifies where eyes actually travel; banner blindness detector uses those zones to flag elements sitting outside fixation paths and redesigns them to survive inside those zones."

pirolli_integration:
  feeds_from: pirolli-scent-trail-auditor
  feeds_to: pirolli-link-diagnosticity-scorer
  shared_data: "Information scent scores for CTAs — a CTA with weak scent gets ignored for two reasons simultaneously (wrong zone AND looks like ad); both must be fixed together."

eisenberg_integration:
  feeds_from: eisenberg-scent-continuity-auditor
  feeds_to: eisenberg-micro-action-sequencer
  shared_data: "Eisenberg's buying modality paths show which visitor types are most susceptible to banner blindness at which funnel stage; restructure CTA styling per modality."
---

# Nielsen & Pernice — Banner Blindness Detector

## LAYER 1: INVARIANTS (Never override.)

1. **Banner Blindness Law is non-negotiable.** Eyetracking confirmed "almost no fixations within advertisements" even from engaged users. Any element that visually resembles an ad — regardless of its actual content — will receive the same zero-fixation treatment.
2. **Right rail is dead.** Nielsen's direct finding: "people have learned not to look at the right rail." No CTA, no form, no offer belongs in the right column. Not even once.
3. **The three properties that bypass blindness are specific.** Plain text. Faces. Nothing else passes the heuristic filter. Rounded corners, colored backgrounds, bordered boxes, and graphic buttons all trigger the blindness reflex.
4. **Making ads look like editorial content is an ethics violation** (Nielsen's explicit ruling). The fix is not native-ad disguise. The fix is removing ad-like visual properties from legitimate conversion elements.
5. **The CTA Link Promise Principle holds.** A CTA label is a promise about what appears after clicking. A "Get Started Now" button that leads to a sign-up wall breaks the promise and drives users to competitors. Label must match destination precisely.
6. **Page fold attention gradient governs urgency.** Above-fold content receives 102% more views than content 100px below fold. Any offer buried below fold 3 receives negligible attention. Primary CTA must appear before the first scroll threshold.
7. **Heuristic 7 (Aesthetic Minimalism) applies to surrounding clutter.** Every non-essential visual element adjacent to a CTA competes with it and diminishes its effective attention share. Strip or push competing elements.

## LAYER 2: QUALITY GUIDANCE

1. Diagnose before redesigning. Categorize each blind element by its specific blindness trigger (color cue, positional cue, shape cue, density cue) before prescribing a fix. Different triggers require different antidotes.
2. Prioritize above-fold CTA rescue first. The fold gradient (57% of viewing time in first screenful) means above-fold blindness is disproportionately costly. Fix those before below-fold elements.
3. Validate the scanning pattern the page is triggering. A page triggering F-Pattern is already underperforming; fixing banner blindness in an F-Pattern context requires both the blindness fix AND a structural nudge toward Layer-Cake or Commitment Pattern.
4. One redesign recommendation per blind element. Do not stack three options. Pick the highest-confidence fix based on the specific trigger.
5. Flag the CTA Link Promise for every CTA redesigned. If the new label cannot be verified against the destination page, mark it as unverified and note what to confirm.

## PURPOSE

This skill takes a specific web page and a single desired action. It identifies every conversion element (CTA, form, offer block, urgency signal) that users are actively not seeing — not because the element is hidden, but because users' trained ad-avoidance reflex is suppressing fixations on it. It then prescribes exact visual and positional changes that remove the ad-association triggers while preserving the conversion intent.

**Brag line: "We place CTAs where eyes actually land, not where we hope."**

Nielsen and Pernice's eyetracking work across hundreds of pages established that users do not scan randomly — they apply a learned, largely unconscious filter that suppresses attention on anything resembling an advertisement. The filter is applied in under 50ms (pre-cognitive, aesthetic first impression). By the time a user consciously processes a page, the blind spots are already set.

This skill operationalizes their specific findings into a four-phase audit: locate, classify, score, redesign.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written element-by-element description
- The ONE desired action: what you want the visitor to do (click CTA / submit form / start trial / purchase)

**Optional (sharpen diagnosis):**
- Analytics: scroll depth heatmap, click map, fold-break data
- Audience: first-time visitor vs. returning, traffic source (paid ad traffic = heightened ad sensitivity)
- Funnel position: awareness / consideration / decision (decision-stage pages tolerate more prominent offer styling)

## EXECUTION PROCESS

### Step 1 — Element Inventory

List every conversion element on the page in a table:

| # | Element | Type | Position | Zone |
|---|---------|------|----------|------|
| 1 | "Start Free Trial" button | CTA btn | Above fold, right | Right rail |
| 2 | Email opt-in box | Form | Fold 2, centered | Center |

Zones: Above-fold-left / Above-fold-center / Above-fold-right / Fold-2 / Fold-3+ / Right-rail / Left-rail

### Step 2 — Blindness Trigger Classification

For each element, apply the four trigger tests:

**T1 — Color/Background Trigger**
Does the element use a colored background, gradient, or border that isolates it from surrounding text? (Yes = ad-like)
Threshold: any background color that differs from the page's primary content background.

**T2 — Shape/Container Trigger**
Does the element sit inside a bordered box, card, or rounded container? (Yes = ad-like)
Threshold: any visible border or border-radius > 4px on a non-form element.

**T3 — Positional Trigger**
Is the element in the right column, in a sidebar, or horizontally separated from the main content stream? (Yes = ad-like)
Threshold: right of the main text column, or clearly offset in a distinct visual channel.

**T4 — Density/Isolation Trigger**
Is the element visually isolated with whitespace margins significantly larger than surrounding content spacing? (Yes = ad-like)
Threshold: padding > 2x the line-height of surrounding body text.

Score each element 0-4 (one point per trigger). Score >= 2 = Banner Blind Risk. Score >= 3 = Near-certain ignored.

| # | T1 | T2 | T3 | T4 | Score/Risk |
|---|----|----|----|----|------------|
| 1 | 1 | 1 | 1 | 0 | 3 / Near-certain |
| 2 | 1 | 1 | 0 | 0 | 2 / At Risk |

*Legend: T1=Color/Background, T2=Shape/Container, T3=Position, T4=Density/Isolation. Score >= 2 = Banner Blind Risk; >= 3 = Near-certain ignored.*

### Step 3 — Fold Attention Gradient Scoring

Map every element against the attention gradient:

- Above fold: 102% more views than 100px below fold. Full weight.
- Fold 2 (first scroll): ~57% of total page viewing time captured in first screenful. Diminished.
- Fold 3+: Negligible unless information scent above is strong.

For each Banner Blind Risk element, compute **Visibility-Adjusted Risk (VAR)**:
VAR = Blindness Score x Fold Weight

Fold weights: Above-fold = 1.0 / Fold-2 = 0.55 / Fold-3+ = 0.20

VAR >= 2.0 = Critical. VAR 1.0-1.9 = Significant. VAR < 1.0 = Low.

### Step 4 — Scanning Pattern Assessment

Determine which of the Four Scanning Patterns (Pernice 2017) the page currently triggers:

- **F-Pattern indicator:** Long unbroken text blocks, no subheadings for 200+ words, minimal bold keywords. Fix: structural. Blindness fixes embedded here get partial lift only.
- **Layer-Cake indicator:** Clear subheadings every 2-3 paragraphs, visible hierarchy. Blindness fixes here get full lift.
- **Spotted indicator:** Styled keywords visible in the text. CTAs inline with content benefit most.
- **Commitment indicator:** Personal relevance language, motivated audience. Any well-placed CTA converts here.

If the page is in F-Pattern, note that blindness fixes must be paired with subheading insertion (handled by nielsen-f-pattern-layout-auditor) to achieve full conversion lift.

### Step 5 — Redesign Prescription

For each Critical or Significant VAR element, prescribe exactly ONE change per trigger:

**T1 Color fix:** Remove background color from the CTA container. Make it visually continuous with the text field. If a button is required, use the page's primary text color as the button text on a minimal stroke border — not a filled background.

**T2 Shape fix:** Remove the card border. Let the element float in the content stream as inline copy with an underlined or bolded action phrase. Reserve bordered containers for functional forms (input fields), not promotional blocks.

**T3 Position fix:** Move the element into the left-aligned main content column. The specific rule from the F-Pattern data: left-aligned text is always read more than right-side content. Eliminate right-rail placement for any conversion element.

**T4 Density fix:** Reduce padding around the element to match surrounding body text spacing. The goal is visual continuity — the CTA reads as part of the page, not as a separate object.

**CTA Label fix (apply to every CTA regardless of blindness score):** Apply the CTA Link Promise Principle. Replace generic labels ("Get Started," "Learn More," "Click Here") with destination-specific labels that describe what the user gets after clicking. Nielsen's tested replacements: instead of "Get Started," use the exact next action ("See Your Price," "Download the Guide," "Book Your Call"). Label must match within 3 words of what the landing destination actually delivers.

### Step 6 — Information Scent Check on Surviving CTAs

After redesigning, verify each CTA emits adequate information scent (Nielsen/Pirolli):

Scent test: Does the CTA label and immediate surrounding text give a user enough signal to estimate what value they'll receive? If a user reads only the CTA label and the single sentence above it, can they decide whether clicking is worth their time?

Scent score: Strong (label + context = clear value), Weak (label only = vague), Dead (label contradicts context).

Dead and Weak scent CTAs need surrounding copy edits, not just label edits.

## OUTPUT STRUCTURE

**Section 1: Element Inventory + Trigger Scores**
Full table from Step 1 and Step 2.

**Section 2: Fold-Adjusted Risk Summary**
VAR scores. Ranked by severity. Top 3 elements flagged as Priority Fixes.

**Section 3: Scanning Pattern Diagnosis**
Which pattern the page currently triggers and what that means for conversion lift ceiling.

**Section 4: Redesign Prescriptions**
One prescription per Priority Fix element. Format:

> **Element #N — [element name]**
> Current: [what it looks like now]
> Triggers: T1, T2, T3 (three triggered)
> Fix: [single concrete change]
> Label fix: "[old label]" → "[new label]"
> Scent: [Strong/Weak/Dead] → action required if not Strong

**Section 5: Heuristic 7 Audit**
List every adjacent visual element competing for attention near Priority Fix CTAs. Flag any that can be removed or pushed (Aesthetic Minimalism — each extra unit diminishes relevant units).

**Section 6: Quick Win Checklist**
Bulleted list of all changes ordered by implementation effort (CSS change only → copy change only → layout change).

## WORKED MINI-EXAMPLE

**Page:** SaaS pricing page. Desired action: click "Start Free Trial."

**Before:**
- "Start Free Trial" button: blue filled background, rounded corners (12px radius), centered in a card with 40px padding, positioned in the right column alongside feature comparison.
- Trigger scores: T1=1, T2=1, T3=1, T4=1. Total = 4. Near-certain blind.
- Fold position: Above fold. VAR = 4.0 x 1.0 = 4.0. Critical.

**After:**
- Removed card container and right-column placement.
- Moved button inline below the pricing headline in the left-aligned main content column.
- Removed filled background. Changed to text link styled as bold with a simple underline.
- Reduced padding to match body text line-height (24px).
- Label changed: "Start Free Trial" → "Start Your Free 14-Day Trial — No Card Required"
- Scent check: surrounding copy says "cancel any time, no setup fee" — scent is Strong.
- Trigger scores after: T1=0, T2=0, T3=0, T4=0. Total = 0. Blind risk eliminated.

Expected outcome per Nielsen's documented cases: elements that drop from score 3-4 to score 0-1 in controlled redesigns showed 40-90% increase in fixation rate in subsequent eyetracking sessions. Click-through lift varies by page quality but fixation rate recovery is consistent.

## OUTPUT FILE

Save to: [project-folder]/Nielsen-Pernice - Click Architecture/[YYYY-MM] - Banner Blindness Audit.md
