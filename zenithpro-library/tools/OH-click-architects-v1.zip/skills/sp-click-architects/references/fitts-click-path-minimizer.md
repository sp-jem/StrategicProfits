---
name: fitts-click-path-minimizer
description: Use when a page has a multi-step or scrolling click path to conversion — diagnoses cumulative motor cost across every CTA in the flow and outputs a ranked repair list to collapse total MT.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Paul Fitts (Fitts's Law 1954; Shannon formulation 1992; Index of Difficulty, Two-Phase Movement Model, Speed-Accuracy Trade-off) — Click Architecture (Skill 6 of 7)"
interface:
  invoke: "/fitts-click-path-minimizer"
  calls: []
  called_by: [user, fitts-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page layouts, sticky elements, and CTA placement shift with A/B tests and redesigns; cumulative-ID scores expire with any layout change."

fitts_target_cost_auditor_integration:
  feeds_from: fitts-target-cost-auditor
  feeds_to: fitts-click-path-minimizer
  shared_data: "Per-CTA ID scores (D, W, MT) from the auditor become the raw inputs for path-level cumulative-ID ranking. Auditor identifies worst single target; minimizer identifies worst sequence."

fitts_thumb_zone_mapper_integration:
  feeds_from: fitts-thumb-zone-mapper
  feeds_to: fitts-click-path-minimizer
  shared_data: "Thumb-zone heat map establishes D baselines for each mobile CTA position. Minimizer uses these distances when computing cumulative mobile MT across multi-step flows."

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: fitts-click-path-minimizer
  shared_data: "Kahneman System 1 load at each step is overlaid on the MT map. Steps with high cognitive load AND high motor cost are double-friction bottlenecks and are prioritized in the repair queue."
---

# Fitts Click-Path Minimizer

## LAYER 1: INVARIANTS (Never override.)

1. **Motor cost is cumulative.** Conversion requires completing every CTA in sequence. Total MT = sum of MT at each step. A single high-ID step can exceed the combined cost of all others — it is the bottleneck.
2. **ID = log₂(1 + D/W) governs each step.** D is distance from the user's pointer/thumb resting position after the previous action. W is target width along the axis of motion. Both variables are measured, not assumed.
3. **The prime pixel resets after every action.** When a user completes step N, their cursor or thumb is now at the location of the step-N CTA. D for step N+1 is measured FROM THAT POINT, not from page load.
4. **Two-phase movement: homing phase is the conversion killer.** Small or distant CTAs force the slow, precision-governed homing phase. Full-width or edge-anchored CTAs collapse it. Fix homing-phase targets before optimizing ballistic-phase ones.
5. **Speed-Accuracy Trade-off raises abandonment.** A CTA requiring slow, careful aiming generates mis-clicks on adjacent elements. Mis-clicks are not neutral — they force correction movements that spike total MT and trigger frustration-driven exits.
6. **Competing targets near any CTA inflate its effective D.** Competing links within 200px force users to aim carefully to avoid mis-clicks. Removing competition lowers effective D even without moving the CTA.
7. **Touch minimum is a hard floor, not a target.** Apple HIG: 44×44 pt (~59×59 px). Any step CTA below this floor has artificially inflated ID. Hit the floor, then maximize above it.

## LAYER 2: QUALITY GUIDANCE

1. **Repair the highest-ID step first.** The weakest link sets the ceiling for conversion rate. Rank steps by ID descending; work top-down.
2. **Measure, don't guess W.** Use browser DevTools (computed width + padding) for actual hit area. Use session recording click dispersion to compute effective width (We = 4.133 × SD of click coordinates). If We << W, users perceive the target as smaller than it is — fix visual cues.
3. **Sticky CTAs compress all D measurements.** A fixed-position CTA that persists across scroll sets D ≈ constant (near the prime pixel throughout). Apply sticky anchoring to pages where the highest-ID step is scroll-position-dependent.
4. **Test with throughput (TP = ID / MT), not click rate alone.** A faster click with a 15% mis-click rate has lower effective TP than a slightly slower click with 2% mis-click rate. Heatmaps + session recordings are required for accurate TP measurement.
5. **Sequential control clustering is the strongest single tactic.** Place each CTA immediately adjacent to the action that precedes it. The cursor is already there; D ≈ 0.

## PURPOSE

This skill minimizes cumulative motor cost across the entire click path from page load to conversion. Where sibling skills (fitts-target-cost-auditor, fitts-primary-action-dominance-scorer) score individual CTAs in isolation, this skill maps the FULL SEQUENCE — treating each step as a Fitts target whose D is determined by where the user landed on the previous step. The lever is sequential ID reduction: collapse D at each step by placing the next CTA at the current prime pixel, and collapse the homing phase by maximizing W.

**Brag line:** "Our primary button is mathematically the easiest thing to hit on the page."

## INPUT REQUIREMENTS

**Required:**
- The page or flow (URL, screenshot, or written description of each step in sequence)
- The ONE desired conversion action (purchase, opt-in, next step, etc.)
- Device context (desktop mouse, mobile touch, or both)

**Optional (increases precision):**
- Click heatmaps or session recordings (to compute effective width We)
- Analytics showing drop-off rate per step in the flow
- Current button dimensions and positions (DevTools computed style)
- Audience funnel position (cold traffic vs. warm vs. retargeted)

## EXECUTION PROCESS

**Step 1 — Map the full click path.**
List every CTA the user must interact with from page load to the conversion action. Include form fields as targets (each is a Fitts acquisition). Number them Step 1 … Step N. For each step, record:
- Element type (button, input field, link, checkbox)
- Position on page (viewport coordinates or scroll depth)
- Visible dimensions (px width × height)

**Step 2 — Identify the prime pixel at each step.**
- Step 1: Prime pixel = page-load cursor/thumb resting position. Desktop: approximate as viewport center or last-known cursor position (default: treat as center). Mobile: bottom-center of viewport (dominant thumb hover zone).
- Step 2+: Prime pixel = location of the CTA completed in the previous step.
Record the (x, y) coordinates of each step's prime pixel.

**Step 3 — Compute D and W for each step.**
- D = Euclidean distance from that step's prime pixel to the center of the step's CTA.
- W = CTA width (or height, along the axis of motion; use the smaller axis if both apply).
- If heatmap data is available, compute We = 4.133 × SD of click coordinates and use We in place of W.

**Step 4 — Compute ID and rank.**
ID(step) = log₂(1 + D / W)

Build the path table (5 columns max — see Output Structure). Rank steps by ID descending. The top-ranked step is the conversion bottleneck.

**Step 5 — Identify failure modes at each high-ID step.**
For each step with ID > 3.0 bits (high-friction threshold), diagnose root cause:
- D too high? CTA is far from where the user just was. Fix: sequential control clustering or sticky anchoring.
- W too small? Button is narrow or touch target is below 44pt floor. Fix: widen button, add invisible padding, use full-width layout.
- Competing targets? Links or secondary buttons within 200px inflate effective D. Fix: remove or visually suppress.
- Two-phase homing required? Button is narrow enough that the ballistic phase overshoots. Fix: widen to collapse homing phase.

**Step 6 — Generate the repair queue.**
Rank repairs by expected ID reduction (ΔID = ID_before − ID_after). Output as a numbered list. Each repair states: step number, root cause, specific change, estimated new D and W, estimated new ID.

**ID thresholds for triage:**
| ID (bits) | Classification | Priority |
|-----------|---------------|----------|
| 0 – 1.5   | Optimal       | Monitor  |
| 1.5 – 3.0 | Acceptable    | Low      |
| 3.0 – 4.5 | High friction | Medium   |
| 4.5+      | Bottleneck    | Fix now  |

**Step 7 — Compute cumulative MT before and after.**
Using Fitts device constants (typical mouse: a = 50ms, b = 140ms/bit; typical touch: a = 100ms, b = 200ms/bit):
MT(step) = a + b × ID(step)
Total MT = Σ MT(step) across all steps.
Report Total MT before repairs and projected Total MT after top-3 repairs are applied.

**Step 8 — Flag SAT risk points.**
Any step where a competitor CTA is within 100px of the primary CTA and has similar visual weight creates Speed-Accuracy Trade-off risk. Flag these separately — they inflate error rate even when ID is acceptable.

## OUTPUT STRUCTURE

### 1. Click Path Map
Table: Step | Element | D (px) | W (px) | ID (bits)
(5 cols, abbreviated headers — see legend below table)
Legend: D = distance from prime pixel to CTA center; W = target width along motion axis; ID = Index of Difficulty = log₂(1 + D/W)

### 2. Bottleneck Ranking
Ordered list of steps by ID descending. Mark steps above 3.0 bits as HIGH FRICTION. Mark steps above 4.5 bits as BOTTLENECK.

### 3. Root-Cause Diagnosis
For each step with ID > 3.0 bits: one paragraph identifying whether the problem is D (distance), W (size), competition (competing targets), or two-phase homing. Name the specific Fitts mechanism responsible.

### 4. Repair Queue
Numbered list ordered by expected ΔID (largest reduction first). Each entry:
- Step N — [root cause] — [specific change]
- Before: D = Xpx, W = Ypx, ID = Z bits
- After: D = X'px, W = Y'px, ID = Z' bits
- ΔID = Z − Z' bits

### 5. Cumulative MT Summary
| Metric | Before | After Top-3 Repairs |
|--------|--------|---------------------|
| Total MT (mouse) | Xms | X'ms |
| Total MT (touch) | Xms | X'ms |
| Highest-ID step | Step N (Z bits) | Step N' (Z' bits) |

### 6. SAT Risk Flags
List any step where competing CTAs are within 100px. State the competing element, its distance, and the recommended separation action.

### 7. Implementation Notes
Device-specific guidance. Max 6 bullets. Reference the specific Fitts tactic (infinite-target anchoring, sequential control clustering, prime pixel placement, full-width collapse, etc.) by name.

## WORKED MINI-EXAMPLE

**Page:** SaaS trial signup — 3-step flow: (1) Hero "Start Free Trial" button, (2) Email input field, (3) "Create Account" submit button.

**Device:** Mobile touch. Prime pixel at load = bottom-center of viewport (thumb zone), approximately (195, 740) on a 390×844 viewport.

**Step 1 — "Start Free Trial" button**
Position: centered horizontally, 380px from top. Center at (195, 380).
D = distance from (195, 740) to (195, 380) = 360px. W = 200px (button width).
ID = log₂(1 + 360/200) = log₂(2.8) = 1.49 bits. Acceptable.

**Step 2 — Email input field**
After tapping Step 1, keyboard opens. CTA prime pixel shifts to (195, 480) (bottom of visible area above keyboard). Email field center at (195, 320). D = 160px. W = 340px (full-width field).
ID = log₂(1 + 160/340) = log₂(1.47) = 0.56 bits. Optimal.

**Step 3 — "Create Account" submit button**
Button center at (195, 420). Prime pixel is at (195, 320) (end of email field). D = 100px. W = 120px (narrow submit button — not full-width).
ID = log₂(1 + 100/120) = log₂(1.83) = 0.87 bits. Acceptable.

**Wait — Step 1 is actually the bottleneck hidden by small cumulative cost.**
Revised audit reveals a competing "Learn More" link at (195, 395) — 15px below the CTA. SAT risk: user must slow ballistic movement to avoid the secondary link. Effective We from heatmap: 80px (users aim carefully). ID_effective = log₂(1 + 360/80) = log₂(5.5) = 2.46 bits. Elevated.

**Repair:** Remove "Learn More" from within 200px of the CTA. Widen "Start Free Trial" to full-width (390px). Reposition to bottom of viewport (D = 0 from thumb prime pixel).
After: D = 0px → MT ≈ a = 100ms. ID → 0 bits. Cumulative MT drops from ~680ms to ~320ms (53% reduction).

## OUTPUT FILE

Save to: [project-folder]/Fitts - Click Architecture/[YYYY-MM] - Click Path Motor Cost Analysis.md
