---
name: gigerenzer-take-the-best-sequencer
description: Use when a page presents multiple claims, proof points, or features in an unordered list — orders on-page cues by validity so the single best cue fires the visitor's stopping rule at the CTA.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Gerd Gigerenzer (Simple Heuristics That Make Us Smart, 1999; Rationality for Mortals, 2008; Take-the-Best heuristic, Gigerenzer & Goldstein 1996) — Click Architecture (Skill 3 of 7)"
interface:
  invoke: "/gigerenzer-take-the-best-sequencer"
  calls: []
  called_by: [user, gigerenzer-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Proof point validity rankings decay as competitors publish counter-evidence and audience priors shift; cue order that dominated last quarter may no longer discriminate."

gigerenzer_recognition_integration:
  feeds_from: gigerenzer-recognition-cue-architect
  feeds_to: gigerenzer-take-the-best-sequencer
  shared_data: "Recognition audit output — list of cues already recognized by target audience. Recognition-cue-architect scores recognizability; this skill uses that score as one input to the validity ranking. A cue that triggers recognition heuristic carries built-in validity weight and should rank above equally-proven but unrecognized cues."

iyengar_integration:
  feeds_from: gigerenzer-less-is-more-auditor
  feeds_to: iyengar-choice-set-auditor
  shared_data: "Option count and cue count. Less-is-more-auditor flags overload; this skill sequences what remains. Iyengar's choice-set auditor then confirms the surviving option set is below cognitive threshold before this skill's cue order is applied."

kahneman_integration:
  feeds_from: gigerenzer-take-the-best-sequencer
  feeds_to: kahneman-framing-engineer
  shared_data: "Top-ranked cue identity and its natural-frequency reformat. Kahneman framing engineer wraps the highest-validity cue in the correct prospect-theory frame (gain vs. loss) after this skill has established which cue ranks first and rewritten it in natural-frequency format."
---

# Gigerenzer Take-the-Best Sequencer

## LAYER 1: INVARIANTS (Never override.)

1. **One cue leads.** The highest-validity discriminating cue must appear first, alone, before any secondary claim. Take-the-Best fires on the first cue that discriminates — list order IS decision architecture.
2. **Stop at the first discriminating cue.** The Adaptive Toolbox stopping rule is: stop searching when the first cue that distinguishes the options is found. A page that front-loads the best cue lets this rule fire at your CTA. A page that buries it extends search until a competing exit wins.
3. **Natural frequencies, never percentages.** Gigerenzer and Hoffrage (1995): Bayesian inference accuracy rises from 4% to 24% when information switches from conditional probabilities to natural frequencies (odds ratio 7.1). Every stat on the page must carry its reference class explicitly: "4 of 5 customers" not "80%."
4. **Relative risk is forbidden.** "25% more effective" requires the visitor to reconstruct the base rate — cognitive work that breaks the frugal search. State absolute counts: "reduces from 6 to 5 outcomes per 1,000" not "16% risk reduction."
5. **Validity ranking drives order, not narrative appeal.** Sequence by empirical discriminating power — conversion lift, past decision-influence data, or proxy metric — not by story flow or what sounds impressive.
6. **Each cue gets one shot.** Do not re-state a cue lower on the page as a variation. The heuristic has already processed it. Repetition wastes attention without adding validity weight.
7. **Exit node at every stage.** Fast-and-frugal trees have an action exit at each branch. The page must have a CTA reachable from the first cue, not only after reading all content.

## LAYER 2: QUALITY GUIDANCE

1. **Validity must be computable.** A cue earns its rank only if you can point to a number: historical A/B lift, survey weight ("which reason most influenced your purchase?"), expert judgment with explicit threshold. Intuition-ranked cues get flagged.
2. **Test for the Less-Is-More Effect.** If this brand/product is already recognized, adding more feature detail shifts visitors to analytical mode where unknown competitors can compete on specs. If recognition score > 70%, the first cue IS recognition — do not dilute it with a feature list.
3. **Maintain Boosting, not nudging.** Gigerenzer's 2015 distinction: boosts improve competence transparently; nudges exploit blindspots. Every reframe must give the visitor a clearer, truer picture — not a manipulated one. If the natural-frequency reformat makes a weak claim look weaker, leave it weak.
4. **Fast-and-frugal tree test.** After sequencing, redraw the page as a binary tree: Node 1 = top cue (yes/no discriminates). If yes: action exit. If no: Node 2 = second cue. Does an action exit appear at each node? If not, the CTA architecture is broken.
5. **Satisficing threshold must be named.** Copy must state the threshold at which stopping is rational: "If you need X, this is enough." Unnamed thresholds push visitors into indefinite search and off-page.

## PURPOSE

This skill applies Gigerenzer and Goldstein's Take-the-Best heuristic (1996) directly to page architecture. The core mechanism: humans order cues by validity, search one at a time, stop at the first cue that discriminates, and decide on that cue alone — ignoring everything else.

Most pages violate this by listing every benefit at equal weight, forcing visitors into exhaustive search that produces confusion, "I need to think about it," and exit. This skill fixes that: it ranks every on-page cue by validity score, sequences them top-to-bottom so the single best cue leads, rewrites all statistics into natural-frequency format (comprehension odds ratio 7.1x), and structures CTA placement so the stopping rule fires at conversion rather than at the browser back button.

**Brag line:** "We design WITH the mental shortcuts instead of fighting them."

Cluster position: Skill 3 of 7 in the gigerenzer-* group. This skill handles cue ordering and frequency reformat. gigerenzer-recognition-cue-architect handles recognizability scoring. gigerenzer-less-is-more-auditor handles cue elimination. gigerenzer-single-cue-spotlighter handles the spotlight execution of the lead cue. Do not overlap those.

## INPUT REQUIREMENTS

**Required:**
- The page — URL, screenshot, or written description of all visible content
- The ONE desired action (click, opt-in, purchase, next step)

**Optional but improves ranking accuracy:**
- Any A/B test results, heatmaps, or survey data ("what most influenced your decision?")
- Audience recognition score for this brand/product (0-100%)
- Funnel position (cold traffic, retargeting, existing customer upsell)
- Competitor pages the visitor likely viewed before arriving

## EXECUTION PROCESS

**Step 1 — Inventory all cues on the page.**
List every distinct claim, proof point, feature, statistic, social signal, and visual element that could influence the desired action. Assign each a short ID: C1, C2 ... Cn. Do not evaluate yet.

**Step 2 — Score each cue for Validity (V) and Discriminating Power (D).**

Validity (V): How strongly does this cue predict that a visitor who encounters it will take the desired action?
- 3 = Hard evidence: A/B lift data, before/after count, verified testimonial with specifics
- 2 = Soft evidence: plausible claim backed by recognizable authority or recognizable name
- 1 = Weak: generic benefit claim, unverified statistic, feature without outcome

Discriminating Power (D): Does this cue separate "should act" visitors from "should not act" visitors?
- 3 = Highly discriminating: only your offer has this
- 2 = Moderately discriminating: few competitors have this
- 1 = Non-discriminating: table stakes, category norm

**Validity Score (VS) = V x D** (range 1-9).

Take-the-Best rank = descending VS. Ties broken by recognition score (prefer recognized cue) then by naturalness of frequency reformat.

**Step 3 — Identify the Lead Cue.**
The cue with the highest VS is the Lead Cue. Threshold for reliable stopping rule: VS >= 6. If no cue reaches VS 6, flag as "weak cue environment" — the page lacks a discriminating proof point and the diagnosis should surface that upstream problem before reordering.

**Step 4 — Reformat all statistics to natural frequencies.**
For each cue containing a percentage, relative risk, or probability:
- Identify the reference class (1,000 customers? 100 trials? All buyers?)
- Rewrite as a count within that class
- Before: "80% success rate" → After: "8 of 10 customers achieved [outcome]"
- Before: "reduces risk by 25%" → After: "drops from 4 to 3 per 1,000 [population]"
- If the reference class is genuinely unknown, flag the stat as unverifiable — do not reformat a number you cannot anchor.

**Step 5 — Build the Fast-and-Frugal Tree for the page.**
Draw the information hierarchy as a binary tree:
- Node 1: Lead Cue (VS highest). Exit: CTA visible and reachable here.
- Node 2: Second-ranked cue. Exit: CTA repeated or anchored here.
- Node 3: Third-ranked cue. Exit: final CTA.
- Remaining cues: supporting detail, below the fold or in FAQ.

Rule: no more than 3 nodes above the fold. A page that requires 7 discriminating reads before offering an exit is not fast-and-frugal — it is exhaustive search in disguise.

**Step 6 — Apply the Satisficing Threshold.**
Write one sentence of copy that names the threshold at which stopping is rational:
"If [specific condition], this is enough to [desired action] now."
Place this sentence immediately before or immediately after the Lead Cue. This fires the visitor's satisficing stopping rule at the point of maximum cue validity.

**Step 7 — Check the Less-Is-More Effect.**
If audience recognition score > 70%: the page should NOT expand feature detail above the fold. Recognition alone is the Lead Cue. Adding feature specs shifts the visitor to analytical mode — and analytical mode allows unknown competitors to compete on specs. Recommendation: suppress feature detail to below-fold or FAQ. Let recognition heuristic operate uninterrupted.

**Step 8 — Produce the Sequenced Cue Map.**
Deliver a ranked table (max 5 columns, see Rule 4) and the rewritten page hierarchy.

## OUTPUT STRUCTURE

**1. Cue Inventory + Validity Scores**
Table: Cue ID | Label (short) | V | D | VS | Freq-reformat needed?
Legend: V=Validity (1-3), D=Discriminating Power (1-3), VS=Validity Score (VxD, 1-9)

**2. Lead Cue Diagnosis**
- Name the Lead Cue and its VS
- State whether VS >= 6 threshold is met
- Flag "weak cue environment" if not met

**3. Natural-Frequency Rewrites**
Before/after for every stat that contained a percentage or relative risk.

**4. Fast-and-Frugal Tree**
Text diagram: Node 1 (Lead Cue + CTA exit) → Node 2 (second cue + CTA exit) → Node 3 (third cue + CTA exit) → Supporting detail.

**5. Satisficing Threshold Copy**
The one sentence that names the stopping-rational condition.

**6. Less-Is-More Flag**
Recognition score assessment and whether feature suppression is recommended.

**7. Sequenced Page Hierarchy**
The reordered above-fold content, in final recommended order, with CTA placement notes.

**8. Diagnosis Summary**
Current state vs. recommended state in 3-5 bullets. Include cue count before/after fold, lead cue VS, and one key stat reformat.

## WORKED MINI-EXAMPLE

**Page:** SaaS landing page, desired action: start free trial.
**Current above-fold content (order as written):**
C1: "Integrates with 200+ tools" (feature)
C2: "Used by 40,000 teams"
C3: "97% of users renew after year one"
C4: "SOC 2 certified"
C5: "Free 14-day trial, no credit card"
C6: "Winner, G2 Best Software 2024"

**Scoring:**

| ID | Label | V | D | VS | Freq? |
|----|-------|---|---|----|-------|
| C2 | 40K teams | 3 | 2 | 6 | Yes |
| C3 | 97% renew | 3 | 2 | 6 | Yes |
| C6 | G2 winner | 2 | 2 | 4 | No |
| C5 | Free trial | 2 | 1 | 2 | No |
| C1 | 200+ integrations | 1 | 1 | 1 | No |
| C4 | SOC 2 | 1 | 1 | 1 | No |

Legend: V=Validity 1-3, D=Discriminating Power 1-3, VS=V x D

**Lead Cue tie (C2 and C3, both VS=6):** Break by discriminating power — both equal. Apply natural-frequency test: C3 carries a percentage; reformat strengthens it.

C3 before: "97% of users renew after year one"
C3 after: "97 of 100 customers pay to continue after their first year"

C2 before: "Used by 40,000 teams"
C2 after: Already a natural frequency. No change needed.

**Decision:** C3 leads because the natural-frequency reformat makes the social-proof outcome count concrete. C2 reinforces immediately after.

**Satisficing threshold:** "If you need a tool your team will actually keep using, the renewal number tells you everything."

**Reordered above-fold hierarchy:**
1. C3 (Lead Cue): "97 of 100 customers pay to continue after their first year" — alone, large, above headline
2. Satisficing threshold sentence
3. CTA: "Start free trial" (first exit node)
4. C2: "40,000 teams already inside"
5. C6: "G2 Best Software 2024"
6. C5: "14 days free, no credit card"
7. C1 + C4: below fold, FAQ/features section

**Result:** Visitor's Take-the-Best heuristic hits C3 first, it discriminates (high renewal = others tested this and stayed), stopping rule fires, CTA is present — trial starts. Old order buried the best cue at position 3 behind two non-discriminating features.

## OUTPUT FILE

Save to: [project-folder]/Gigerenzer - Click Architecture/[YYYY-MM] - Take-the-Best Cue Sequencing.md
