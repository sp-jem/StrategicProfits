---
name: eisenberg-persona-pathway-mapper
description: Use when a page is converting traffic unevenly across audience segments, or when you suspect the page serves only one buyer type — maps each buying modality to its own conversion pathway through the page so every temperament finds a clear lane to the desired action.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Bryan & Jeffrey Eisenberg (Call to Action 2005; Waiting for Your Cat to Bark 2006; Persuasion Architecture 2003-2006; Four Buying Modalities; Persuasion Scenario/Persona Pathway) — Click Architecture (Skill 1 of 7)"
interface:
  invoke: "/eisenberg-persona-pathway-mapper"
  calls: []
  called_by: [user, eisenberg-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic mix, ad sources, and audience psychographics shift — a pathway built for last quarter's dominant Methodical segment becomes wrong when a Spontaneous-heavy ad campaign changes the mix."

eisenberg_scent_integration:
  feeds_from: eisenberg-scent-continuity-auditor
  feeds_to: eisenberg-landing-anatomy-architect
  shared_data: "Scent audit identifies the trigger phrase arriving visitors carry; pathway mapper assigns that trigger phrase to the correct modality lane and routes it to the anatomy architect for fold placement."

fogg_integration:
  feeds_from: fogg-behavior-mapper
  feeds_to: fogg-prompt-designer
  shared_data: "Fogg's Motivation × Ability × Prompt axis aligns to modality requirements: Spontaneous = high motivation, needs low-friction prompt; Methodical = high ability requirement, needs motivation-building before prompt. Pathway sequencing must match Fogg's prompt timing."

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: kahneman-peak-end-architect
  shared_data: "System 1 buyers (Spontaneous, Humanistic) respond to Kahneman loss/gain framing and peak-end sequencing; System 2 buyers (Methodical, Competitive) require deliberate processing — pathway depth and page length are calibrated accordingly."
---

# Eisenberg Persona Pathway Mapper

## LAYER 1: INVARIANTS (Never override.)

1. **Modality is fixed.** You cannot change a buyer's buying temperament. Competitive, Spontaneous, Methodical, and Humanistic are hard-wired traits, not moods. The page adapts to them — not the reverse.
2. **The Conversion Trinity gates every element.** Before assigning any copy or visual to a pathway lane, confirm it passes in sequence: (1) Relevance — does it match the visitor's stated intent? (2) Value — does it explain why this is the right solution? (3) CTA — is the next action obvious and confidence-inducing? A lane missing any Trinity element is broken regardless of how well it serves the modality.
3. **Hierarchy of Optimization is mandatory pre-work.** Pathway mapping is a persuasion-layer activity (Level 5). Running it on a page with functional errors (Level 1), accessibility failures (Level 2), or usability friction (Level 3) wastes optimization budget. Confirm Levels 1-4 are clear before building pathways.
4. **One primary lane, above the fold.** The dominant modality by revenue — not by visitor count — owns above-fold real estate. Secondary modalities are layered below in sequence without contradicting the above-fold message.
5. **The denominator is intent, not traffic.** Pathway assignments must be tied to qualified intentional visitors. Segment analytics by traffic source and intent signal before diagnosing which modality lane is broken. CR = (converters) / (intenders), not (converters) / (all visitors).
6. **Pathways are storyboards, not tag clouds.** Each lane specifies exact page elements — headline variant, proof type, CTA language, visual treatment — in the exact order that modality needs them. Vague "serve Methodical buyers" instructions are not pathways.
7. **Pre-mortem is non-negotiable before shipping.** Walk the page as each persona. List every reason they would NOT click. Each reason is a required fix, not a backlog item.

## LAYER 2: QUALITY GUIDANCE

1. **Identify the revenue-dominant modality, not the traffic-dominant modality.** Analytics may show 60% Methodical visitors but 70% of revenue from Spontaneous. The Spontaneous lane owns the fold.
2. **Pathway depth scales with modality.** Spontaneous and Competitive buyers need short, intense pathways (fold → CTA ≤ 2 scroll stops). Methodical and Humanistic buyers need longer pathways with proof density before the CTA appears.
3. **Proof types are not interchangeable.** Methodical proof = hard data, percentages, specs, documented case study results. Competitive proof = superlatives backed by named third-party source. Spontaneous proof = social validation, star ratings, fast-win testimonials. Humanistic proof = real human stories, mission statement, people photos, social impact. Cross-assigning proof types destroys the lane's credibility signal.
4. **Test pathway elements as Trinity units, not isolated variables.** Headline + hero image = one Relevance test. Body copy block = one Value test. Form + button + CTA copy = one Action test. Testing in atomic isolation produces false signals.
5. **Grayscale contrast check before launch.** In grayscale, the primary CTA must visually dominate the page. If it does not, redesign before measuring modality conversion — you are testing broken visual hierarchy, not modality response.

## PURPOSE

The Eisenbergs' Persuasion Architecture treats a web page as a multi-lane highway, not a single funnel. Four distinct buying temperaments — Competitive, Spontaneous, Methodical, Humanistic — each need a different sequence of information triggers to reach the same destination: the desired action. This skill operationalizes their Persuasion Scenario framework to map exactly which page elements (headlines, proof types, CTA language, visual treatment) appear in what order for each temperament, then layers those lanes onto one page so every buyer finds their path.

**Brag line:** "Our ad and our page tell one unbroken story — scent never breaks."

The lever: once you know which temperament is reading each section of the page, every word and image has a job. Without pathway mapping, a page accidentally optimizes for one temperament and repels the others — a structural conversion ceiling that no headline test alone can break.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description of the full page layout
- The ONE desired action (click / opt-in / purchase / call / download — pick one)

**Strongly recommended:**
- Traffic source data (what ad, email, search query, or link delivered visitors)
- Analytics segment showing where drop-off occurs (fold, pricing section, form, etc.)
- Audience description (B2B/B2C, product category, price point)

**Optional but high-value:**
- Existing CR by segment or traffic source
- Any prior A/B test results and what changed

## EXECUTION PROCESS

**Step 1 — Hierarchy of Optimization Gate (≤10 min)**

Before pathway work, audit the page at all five levels in order. Score each:

| Level | Check | Pass/Fail |
|-------|-------|-----------|
| 1 Functional | Links work, forms submit, no 404s, page loads | Pass/Fail |
| 2 Accessible | Screen reader, alt text, contrast ratio ≥4.5:1 | Pass/Fail |
| 3 Usable | Navigation obvious, no UX dead ends | Pass/Fail |
| 4 Intuitive | Next action self-evident without instruction | Pass/Fail |
| 5 Persuasive | THIS is where pathway mapping lives | Proceed |

*If any Level 1-4 fails: document the failure, fix it, return to Step 1. Do not proceed to pathway mapping on a broken page.*

**Step 2 — Modality Revenue Audit**

Identify the revenue-dominant modality. Use analytics or proxy signals:

- High above-fold / hero CTA conversion → Spontaneous dominant
- Heavy pricing/comparison/specs page engagement → Methodical dominant
- Low time-on-page, high direct checkout → Competitive dominant
- High testimonial/story page engagement, low direct checkout → Humanistic dominant

If no analytics: classify the product category.
- SaaS productivity tool, B2B services → default Methodical primary
- Impulse consumer goods, event tickets, short-copy offers → Spontaneous primary
- Premium commodity where vendor comparison is obvious → Competitive primary
- Coaching, community, cause-aligned brands → Humanistic primary

Assign a revenue weight to each modality: Primary (highest revenue), Secondary, Tertiary, Background.

**Step 3 — Four-Lane Pathway Specification**

For each of the four modalities, specify the pathway using this template:

```
MODALITY: [name]
Axis: [Fast/Slow] × [Logic/Emotion]
Dominant question: [see below]
Revenue rank: [Primary / Secondary / Tertiary / Background]
Page zone: [Above fold / Mid-page / Lower / Sidebar callout]

Pathway elements (in order):
  1. Headline trigger: [exact phrase or frame]
  2. Proof type required: [data / superlative+source / social / human story]
  3. Visual signal: [achievement visual / dynamic/urgency / data chart / real people]
  4. CTA language: [exact button/link copy and tone]
  5. Friction to remove: [specific element that would block THIS buyer]
```

Dominant questions by modality:
- **Methodical** (slow+logical, ~45%): "What is the evidence that this works and what are all the details?"
- **Competitive** (fast+logical, ~5-10%): "How is this better than alternatives and am I getting the best?"
- **Spontaneous** (fast+emotional, ~25-35%): "Will this feel good right now and is it easy to start?"
- **Humanistic** (slow+emotional, ~10-15%): "Can I trust the people behind this and do we share values?"

**Step 4 — Lane Layering Map**

Stack the four pathways onto a single page layout. Rule: Primary modality above fold; others in descending order below. No contradictions between layers (e.g., urgency headline for Spontaneous above fold + slow evidence-building hero image = contradiction, fix it).

Produce a zone map:

| Zone | Fold Position | Primary Lane | What appears |
|------|--------------|--------------|--------------|
| Hero | Above fold | Primary modality | Headline, hero, CTA |
| Band 1 | 1st scroll | Secondary | Proof block for #2 |
| Band 2 | 2nd scroll | Tertiary | Proof block for #3 |
| Band 3 | 3rd scroll | Background | Proof block for #4 |
| Footer | Bottom | All | Trust signals, final CTA |

*Short columns, no scroll required in a standard markdown pane.*

**Step 5 — Conversion Trinity Audit Per Lane**

For each lane, confirm all three Trinity criteria are satisfied:

- **Relevance**: Does the headline/image echo the exact trigger phrase or emotional signal the visitor arrived with? (Scent maintenance — handed off to eisenberg-scent-continuity-auditor for full audit)
- **Value**: Does the body copy in this zone explain WHY this offer is the right solution for THIS modality's dominant question?
- **CTA**: Is the action step unambiguous, with language matching this modality's emotional register? Is the button visually dominant in grayscale?

Score each lane: Relevance ✓/✗, Value ✓/✗, CTA ✓/✗. Any ✗ = required fix before testing.

**Step 6 — Pre-Mortem Per Persona**

Walk through the page as each buying temperament. For each:
- List every reason this buyer would NOT click the CTA at each zone
- Classify each reason: missing information / wrong proof type / friction point / trust gap / wrong CTA language
- Mark as Required Fix (blocks conversion) or Enhancement (improves conversion)

Threshold: any Required Fix identified in pre-mortem must be resolved before the pathway is considered launch-ready.

**Step 7 — Segment Denominator Verification**

Apply the Conversion Rate formula correctly: CR = converters / intenders (not all visitors).

Confirm: are you measuring each lane's performance against the visitors who arrived with intent matching that lane? If all traffic is pooled, segment by:
- Traffic source (organic search vs paid vs email vs social)
- Landing query or ad creative used
- Behavioral signal (visited pricing page, clicked comparison tab, read testimonials first)

A 2% blended CR can hide a 15% Methodical-lane CR and a 0.1% Spontaneous-lane CR. Optimization targets the broken segment.

## OUTPUT STRUCTURE

**Section 1: Hierarchy Gate Results**
Five-level pass/fail table. Blocking issues called out with required fix.

**Section 2: Modality Revenue Audit**
Four modalities ranked by revenue weight with supporting evidence or proxy reasoning.

**Section 3: Four-Lane Pathway Specifications**
One block per modality using the Step 3 template. Each block specifies headline, proof, visual, CTA language, friction to remove.

**Section 4: Lane Layering Map**
Zone table showing which modality owns which page zone and what appears there.

**Section 5: Conversion Trinity Audit**
Per-lane table: Relevance / Value / CTA scored with specific gap callouts.

**Section 6: Pre-Mortem Findings**
Persona-by-persona list of conversion blockers, classified as Required Fix or Enhancement.

**Section 7: Segment Denominator Report**
How to measure each lane's CR correctly. What segments to create in analytics.

**Section 8: Priority Fix List**
Ranked list of changes by revenue impact (modality revenue weight × severity of gap).

## WORKED MINI-EXAMPLE

**Page:** B2B SaaS project management tool landing page
**Desired action:** Start free trial (email opt-in form)
**Traffic source:** Google Ads, keyword "project management software for teams"

**Before (single-lane page):**
- Hero headline: "Work smarter, not harder." (generic, no scent match)
- Hero subhead: "The only tool your team needs."
- CTA: "Get started" (no modality match)
- Body: 3 bullet points, no data, no testimonials, no comparison
- Form: 5 fields (name, company, email, phone, team size)

**Modality audit:** B2B SaaS + team purchase decision → Methodical primary (~45%), Competitive secondary (~10%), Spontaneous tertiary (~25%)

**After (three-lane layered page):**

*Above fold (Methodical primary):*
- Headline: "Project management software for teams — 43% faster delivery, tracked across 8,200 teams" (matches keyword scent + hard data)
- Subhead: "Compare our feature set against Asana and Monday.com side-by-side"
- CTA: "See the data — start free trial" (Methodical CTA language)
- Form reduced to 2 fields (email + team size) — friction removal for Spontaneous who also sees this fold

*Band 1 — Competitive:*
- "Rated #1 by G2 in Project Tracking 2025 — see the full report" with comparison chart

*Band 2 — Spontaneous:*
- "Your team is live in 8 minutes. No credit card." with urgency badge and social proof count

*Band 3 — Humanistic:*
- "Built by a 12-person team that missed too many deadlines" — founder story + real user photo testimonials

**Trinity check on primary (Methodical) lane:**
- Relevance ✓ — headline echoes search query verbatim
- Value ✓ — 43% stat + comparison offer answers "what is the evidence?"
- CTA ✓ — "See the data" matches Methodical desire to investigate before committing

**Pre-mortem catch:** Methodical buyer would not trust "free trial" without knowing what happens at end of trial. Required fix: add "No auto-charge. Cancel any time." as microcopy under the CTA button.

## OUTPUT FILE

Save to: [project-folder]/Eisenberg - Click Architecture/[YYYY-MM] - Persona Pathway Map - [page name].md
