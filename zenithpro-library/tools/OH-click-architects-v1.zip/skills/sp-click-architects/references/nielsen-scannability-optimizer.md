---
name: nielsen-scannability-optimizer
description: Use when a page has poor engagement, low scroll depth, or buried CTAs — applies Nielsen & Pernice's scanning-pattern frameworks to front-load content, restructure headings, and trigger Layer-Cake or Commitment reading on any page with a desired action.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Jakob Nielsen & Kara Pernice (Eyetracking Web Usability 2010; F-Pattern 2006; Four Scanning Patterns 2017; Inverted Pyramid 1996; Page Fold Attention Gradient 2018) — Click Architecture (Skill 5 of 7)"
interface:
  invoke: "/nielsen-scannability-optimizer"
  calls: []
  called_by: [user, nielsen-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Scroll-depth analytics, heatmaps, and user reading behavior shift with page redesigns, traffic source changes, and seasonal audience intent — a 45-day-old audit may reflect a page that no longer exists."

nielsen_f_pattern_integration:
  feeds_from: [nielsen-f-pattern-layout-auditor]
  feeds_to: [nielsen-attention-zone-placer]
  shared_data: "F-pattern layout audit identifies which text blocks are triggering F-scan; this skill converts those blocks into Layer-Cake or Spotted structures; attention-zone-placer then maps where CTAs land post-restructure."

pirolli_integration:
  feeds_from: [pirolli-information-scent-trail-auditor]
  feeds_to: [pirolli-scent-gradient-designer]
  shared_data: "Information scent (Pirolli & Card 1999, applied by Nielsen) determines whether above-fold copy gives users enough signal to scroll; this skill strengthens scent by restructuring headlines and subheadings; pirolli-scent-gradient-designer then tunes link text and anchor phrases."

kahneman_integration:
  feeds_from: [kahneman-framing-engineer]
  feeds_to: [kahneman-peak-end-architect]
  shared_data: "Kahneman's aesthetic-minimalist framing (Heuristic 7: every extra unit competes with relevant units) feeds directly into cognitive-load reduction decisions here; peak-end audit receives the restructured page to ensure the strongest frame lands at the last-read point."
---

# Nielsen-Pernice Scannability Optimizer

## LAYER 1: INVARIANTS (Never override.)

1. **Inverted Pyramid is non-negotiable.** Every section starts with its conclusion. Value proposition and primary CTA appear before the fold. Benefits before proof. Proof before detail. Detail before background. Reversing this order is abandonment.

2. **The F-Pattern is a failure state, not a design target.** The F-Pattern is a learned scanning shortcut triggered by absent formatting. If the audit detects F-scan conditions (unbroken prose, no subheadings, no bold keywords), the page is failing — not the user.

3. **Above-fold attention gradient is 84% higher than below-fold.** Any conversion element that cannot be placed within the first two screenfuls (74% of total viewing time) must be preceded by strong information scent — a specific, relevant signal that value exists below.

4. **Subheadings must be meaningful, not decorative.** The Layer-Cake Pattern (by far the most effective scanning mode for information-seeking) requires users to read only subheadings and find them sufficient to decide whether to dip into body text. Generic subheadings ("Our Approach," "Why Choose Us") break the layer-cake and force fallback to F-scan.

5. **Plain language at 6th–8th grade reading level.** Cognitive load from jargon, passive constructions, and long sentences forces users to re-read. Re-reading is not engagement — it is friction that delays or prevents the desired action.

6. **Every CTA label is a promise.** The CTA text must match exactly what appears after clicking. "Get Started" that leads to a sign-up wall breaks the promise and drives users to competitor sites. Specific labels ("Download the 12-Page Guide," "See Pricing") outperform generic ones.

7. **Right-rail and banner-pattern placements are dead zones.** Per Banner Blindness Law (1997/2023): any offer using colors, borders, rounded corners, or spatial positions associated with ads will be skipped regardless of content quality.

## LAYER 2: QUALITY GUIDANCE

1. **Target Layer-Cake or Commitment scanning, not F-scan.** Spotted Pattern (styled keywords) is acceptable as a bridge, but the goal is subheadings strong enough to trigger Layer-Cake — users who read only headings and find them persuasive enough to convert.

2. **Chunk body copy into 3-line maximum paragraphs above the fold.** Nielsen's eyetracking data: initial paragraphs receive the most attention; long blocks above the fold signal "wall of text" and accelerate scroll-past or abandonment.

3. **Front-load the first two words of every heading and bullet.** Users read the third word on a line far less often than the first two (F-Pattern research). Place the meaningful keyword in positions 1–2, not position 4+.

4. **10-second value proposition window.** Users allocate ~10 seconds to decide if a page is worth their time. The primary value proposition — stated in visitor language, not internal jargon (Heuristic 2) — must be readable in the first 10 seconds of page load.

5. **Credibility signals must be visible, not buried.** The 4 Web Credibility Factors (design quality, upfront disclosure, comprehensive content, external validation) affect conversion before users reach the CTA. Third-party validation belongs above fold or at the natural trust-decision point, not in a footer.

## PURPOSE

Nielsen and Pernice's scannability research produces one actionable truth: **users don't read pages — they scan for relevance signals, and the structure of your page either triggers efficient scanning toward your CTA or trains users to skip it entirely.** This skill applies their empirical eyetracking findings to restructure any page so it triggers Layer-Cake scanning (the most effective pattern), front-loads the value proposition using the Inverted Pyramid, and places CTAs where attention actually lands based on the Page Fold Attention Gradient — not where designers hope it lands.

**Brag line: "We place CTAs where eyes actually land, not where we hope."**

The desired action is the organizing principle. Every diagnosis and every change recommendation is evaluated against a single criterion: does this increase the probability that a visitor completes the stated desired action before leaving the page?

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description with section-by-section content summary
- The ONE desired action: the single conversion event this page exists to produce (e.g., "click Add to Cart," "submit the opt-in form," "click 'Book a Call'")

**Optional but improves precision:**
- Scroll-depth analytics (where users drop off — identifies the fold problem zone)
- Heatmap or click-map data (identifies current scanning pattern)
- Traffic source (cold traffic requires stronger scent signals than warm/retargeted)
- Funnel position (top-of-funnel pages need Layer-Cake; bottom-of-funnel can assume Commitment)
- Word count per section (to compute cognitive-load score)

## EXECUTION PROCESS

**Step 1 — Classify Current Scanning Pattern (5 min)**

Read the page top-to-bottom. Classify the likely scanning pattern triggered by current structure:

| Pattern | Trigger Condition | Conversion Impact |
|---------|------------------|-------------------|
| F-scan | Prose blocks, no subheads, no bold | Worst — users miss 60%+ of content |
| Spotted | Some bold/links but no subhead hierarchy | Partial — users jump to styled words only |
| Layer-Cake | Meaningful subheads every 150–200 words | Best for info-seekers — dip into relevant sections |
| Commitment | High relevance + trust signals above fold | Best overall — full reading, highest conversion |

*Legend: F-scan = F-Pattern default; Spotted = Spotted Pattern; Layer-Cake = Layer-Cake Pattern; Commitment = Commitment Pattern*

Record: Current pattern, evidence (e.g., "4 consecutive prose blocks, zero subheadings in first 600 words").

**Step 2 — Fold Audit (3 min)**

Identify where the fold falls on a 1280×800 viewport (standard desktop baseline). Map content against the Page Fold Attention Gradient:

- Zone A (above fold, screenful 1): receives ~57% of total viewing time — value proposition + primary CTA must be here
- Zone B (screenful 2): receives ~17% of viewing time — primary supporting proof, strongest benefit
- Zone C (screenful 3): receives ~11% — secondary benefits, secondary CTA
- Zone D (screenful 4+): <15% combined — background, FAQ, footer

Flag any conversion-critical element (primary CTA, price, main benefit statement) located in Zone C or D as a **Priority 1 relocation issue**.

**Step 3 — Inverted Pyramid Compliance Check**

For each section, answer:
- Does this section start with its conclusion or with setup/context?
- Is the most important claim in the first sentence?
- Does the value proposition appear in the first visible paragraph?

Score: 1 point per section that is front-loaded. Divide by total sections.
- 80%+ = Compliant
- 50–79% = Partial — fix above-fold sections first
- Below 50% = Failing — full restructure required

**Step 4 — Subheading Diagnostic**

List every subheading. For each, apply the Layer-Cake test:

*If a motivated but skeptical visitor read ONLY the subheadings on this page, would they have enough information to (a) understand the offer and (b) decide to take the desired action?*

Flag subheadings that fail the test. Categories of failure:
- Generic labels ("Overview," "Features," "Learn More")
- Internal jargon (language users would not use to describe their own problem)
- Passive or vague ("Designed with you in mind")
- Benefit-absent (names a feature but not the outcome)

Replacement rule: Subheadings must carry a scannable benefit or decision signal. Test: could this subheading appear as a standalone bullet in a summary email? If yes, it passes.

**Step 5 — First-Two-Words Scan**

Extract the first two words of every heading, subheading, and bullet. Check: is the meaningful keyword in position 1 or 2?

F-Pattern research finding: users read the third word on a line far less often than the first two.

Flag every instance where a filler word occupies position 1 or 2:
- Articles: "The," "A," "An" in position 1
- Prepositions: "With," "For," "By" in position 1
- Setup phrases: "We believe," "Our team," "You can"

Rewrite to lead with the substantive word. Example:
- Before: "A comprehensive system for managing your pipeline"
- After: "Pipeline management — automated, tracked, closed faster"

**Step 6 — Cognitive Load Score**

For each above-fold section (Zone A + Zone B), compute:

- Paragraph length: flag any paragraph above the fold with more than 3 lines
- Sentence length: flag sentences above 20 words
- Reading level: use Flesch-Kincaid estimate (aim for grade 6–8)
- Jargon density: count internal/industry terms per 100 words (flag if >3)

Threshold: if Zone A has any paragraph >3 lines OR any sentence >20 words, it is a Priority 1 rewrite.

**Step 7 — CTA Promise Audit**

For each CTA on the page:
- Record the exact label text
- Describe what the user encounters immediately after clicking
- Apply the Link Promise Principle: does the label text accurately predict the post-click experience?

Flag mismatches. Common failures:
- "Get Started" → sign-up form (promise: action; reality: barrier)
- "Learn More" → sales page (promise: information; reality: pitch)
- "Download Now" → email gate (promise: immediate delivery; reality: required exchange)

Provide specific replacement labels for each flagged CTA.

**Step 8 — Credibility Placement Check**

Locate the 4 Web Credibility Factors on the page:
1. Design quality signals (professional appearance, no broken elements, no typos)
2. Upfront disclosure (pricing visible, contact info present, policies accessible)
3. Real content (actual photos, real testimonials, named sources)
4. External validation (third-party reviews, press mentions, certifiable claims)

Flag any credibility factor located in Zone C or D. Credibility affects conversion decisions — it must be visible at or before the trust-decision point (typically just above the primary CTA).

## OUTPUT STRUCTURE

**Section 1 — Scanning Pattern Diagnosis**
Current pattern classification with evidence. Target pattern and what structural changes will trigger it.

**Section 2 — Fold Map**
Zone A–D content inventory. Priority 1 relocation issues (conversion-critical elements in wrong zones).

**Section 3 — Inverted Pyramid Compliance**
Score + specific section-by-section rewrites for failing sections. Lead with conclusion, not setup.

**Section 4 — Subheading Rewrites**
Before/after table for every failing subheading. New subheadings pass the Layer-Cake test.

**Section 5 — First-Two-Words Fixes**
Before/after list of all headlines and bullets where meaningful word was buried after position 2.

**Section 6 — Cognitive Load Reductions**
Specific paragraph and sentence rewrites for Zone A and Zone B. Reading-level target confirmed.

**Section 7 — CTA Promise Corrections**
Before/after table: current label, post-click reality, recommended replacement label.

**Section 8 — Credibility Relocations**
List of credibility elements to move, with recommended placement zone and rationale.

**Section 9 — Priority Stack**
Ranked list of all changes by conversion impact. Top 3 are the 48-hour implementation list.

## WORKED MINI-EXAMPLE

**Page:** SaaS landing page. Desired action: click "Start Free Trial."

**Before (Zone A, above fold):**
> Headline: "Introducing the Most Comprehensive Sales Pipeline Solution for Modern Teams"
> Body: "Our platform has been designed with sales professionals in mind. With a focus on simplicity, power, and flexibility, we've created a tool that can help your team close more deals and track performance across every stage of the pipeline."
> CTA: "Get Started"

**Diagnosis:**
- Scanning pattern: F-scan (single prose block, no subheads, no bold keywords)
- Inverted Pyramid: FAIL — setup/description precedes the value claim
- First-two-words: "Our platform" and "With a focus" — both lead with filler
- CTA Promise: "Get Started" → likely sign-up form — promise/reality mismatch
- Cognitive load: 2 sentences over 20 words in Zone A
- Zone A has zero credibility signals

**After:**
> Headline: "Close Deals Faster — Pipeline Tracking That Runs Itself"
> Subhead: "Join 4,200 sales teams who cut deal-review time by 40%"
> Body (3 lines max): "Set up in 15 minutes. Connect your CRM. Every deal tracked, every follow-up automated."
> CTA: "Start Your Free 14-Day Trial — No Card Required"

**Changes applied:**
- Headline front-loads benefit (position 1: "Close"); eliminates "Introducing the Most" filler
- Subhead passes Layer-Cake test: specific claim + social proof number
- Body chunked to 3 lines; each sentence under 12 words; Grade 5 reading level
- CTA label matches post-click reality (free trial, no card) — promise kept

## OUTPUT FILE
Save to: [project-folder]/Nielsen-Pernice - Click Architecture/[YYYY-MM] - Scannability Optimization.md
