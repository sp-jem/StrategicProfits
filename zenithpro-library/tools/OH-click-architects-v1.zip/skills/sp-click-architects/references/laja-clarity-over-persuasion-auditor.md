---
name: laja-clarity-over-persuasion-auditor
description: Use when a page is clever but not converting — applies Laja's clarity-trumps-persuasion principle to find every place where wit replaced comprehension, and replaces it with language that answers "what is it, who is it for, what do I do" in 5 seconds.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peep Laja (CXL Institute 2013-2022; Four-Factor Heuristic Audit, Conversion Formula C=4M+3V+2(I-F)-2A, B2B Message Layers Framework) — Click Architecture (Skill 6 of 7)"
interface:
  invoke: "/laja-clarity-over-persuasion-auditor"
  calls: []
  called_by: [user, laja-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page copy, headlines, and CTA language drift with traffic sources and seasonal offers; clarity issues re-emerge whenever new copy is written without a clarity gate."

laja_sibling_integration:
  feeds_from: laja-heuristic-walkthrough
  feeds_to: laja-researchxl-diagnostic
  shared_data: "Heuristic walkthrough surfaces CLARITY severity scores (axis 1 of Four-Factor Audit) — this skill receives those scores and produces specific rewrite mandates; ResearchXL uses the rewritten hypotheses as test candidates."

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: kahneman-framing-engineer
  shared_data: "System 1 processing requires fluency — Kahneman's fluency effect amplifies conversion when clarity is achieved first. Clarity audit hands off clean, concrete language for Kahneman framing overlays."

fogg_integration:
  feeds_from: fogg-ability-auditor
  feeds_to: fogg-prompt-designer
  shared_data: "Fogg's Ability axis overlaps with Laja's Friction axis — low-clarity pages reduce perceived ability. Clarity audit findings inform fogg-ability-auditor's 'simplicity lever' recommendations."
---

# Laja Clarity-Over-Persuasion Auditor

## LAYER 1: INVARIANTS (Never override.)

1. **Clarity before persuasion, always.** In Laja's Conversion Formula (C = 4M + 3V + 2(I-F) - 2A), Value Proposition clarity carries a 3x coefficient — the highest on the page. No persuasion tactic compensates for a visitor who cannot parse what the page is selling.
2. **5-second rule is the hard gate.** If a cold visitor cannot state (a) what the product is, (b) who it is for, and (c) what action to take within 5 seconds of landing, the headline must be rewritten before anything else is optimized.
3. **Clever is a conversion killer.** Puns, metaphors, brand voice wordplay, and clever headlines delay comprehension. Every syllable spent on wit is a syllable not spent on clarity. Flag every instance of clever-over-clear and propose a direct alternative.
4. **Message scent is non-negotiable.** The headline, hero image, and CTA language must use the same words and promise as the ad, email, or search result that delivered the visitor. Scent breaks = immediate exit intent.
5. **One page, one most-wanted action.** Every navigation item, secondary CTA, social link, and sidebar element not pointing to the primary action is distraction (Distraction axis, Four-Factor Audit). Distraction must be scored and removed or visually subordinated.
6. **Concrete beats abstract, always.** Replace "powerful," "seamless," "robust," and every other adjective-posing-as-benefit with a specific, quantified outcome. No exceptions.
7. **Layer 1 before Layer 2 before Layer 3.** Per B2B Message Layers: if CLARITY (Layer 1) fails, diagnosing RELEVANCE, VALUE, or DIFFERENTIATION is premature. This skill audits in layer order — do not skip forward.

## LAYER 2: QUALITY GUIDANCE

1. **Score each axis on 1-5 severity** (per Four-Factor Heuristic Audit): 1 = minor, 3 = noticeable conversion drag, 5 = critical — likely driving significant revenue loss. Only issues scored 3+ require immediate rewrite; 1-2 issues go to the backlog.
2. **Produce rewrites, not recommendations.** Every flagged element must include a specific before → after rewrite. "Make the headline clearer" is not an output; "Replace 'Your unfair advantage in the attention economy' with 'CRO software that increases checkout conversions — free 14-day trial'" is.
3. **Preserve the single most-wanted action in every rewrite.** Clarity work must not accidentally dilute the conversion goal by adding nuance or choice.
4. **Triangulate with one data signal when possible.** If analytics, survey verbatims, or heatmap data are available, cite the signal that confirms each clarity problem. An observed problem is stronger than a hypothesized one.
5. **Tier the fixes.** Tier 1 = fix immediately, no test needed (broken scent, unanswerable 5-second test, missing CTA). Tier 2 = A/B test required (alternative headline approaches, CTA copy variants). Never test what is obviously wrong — fix it.

## PURPOSE

This skill applies Peep Laja's core conviction — clarity always outranks persuasion — directly to a specific web page and desired action. It executes the CLARITY axis of the Four-Factor Heuristic Audit, applies the B2B Message Layers framework (Layer 1: Clarity → Layer 2: Relevance), and uses the Conversion Formula's coefficient hierarchy to rank every intervention by revenue leverage before a single word is changed.

The lever: Value Proposition (V) carries a 3x weight in C = 4M + 3V + 2(I-F) - 2A. This skill maximizes V on the target page.

**Brag line:** "We find the real leak with 6 research lenses before we touch the page."

Use this skill when a page has traffic but underwhelming conversion and the team suspects (or you've observed) that copy is trying to be smart when it should be obvious.

## INPUT REQUIREMENTS

**Required:**
- The page — URL, screenshot, or written description of headline/subhead/hero/CTA/body copy
- The ONE desired action (e.g., "click free trial CTA," "opt-in to lead magnet," "purchase $97 offer")

**Optional (improves output quality):**
- Traffic source (ad, email, organic search — needed for scent audit)
- Ad/email copy or subject line that sent traffic to this page
- Funnel position (cold traffic / warm list / retargeting)
- Analytics: conversion rate, bounce rate, device split
- Any available survey verbatims or on-site poll responses
- Heuristic severity scores from laja-heuristic-walkthrough (if run first)

## EXECUTION PROCESS

**Step 1 — 5-Second Comprehension Test**
Read only the above-the-fold section (headline, subhead, hero image alt/context, primary CTA). Answer three questions as a cold visitor:
- What is this product/offer?
- Who is it for (specifically)?
- What should I do right now?

Scoring: all three answerable without scrolling = PASS. Any unanswerable = FAIL (Severity 5 — fix before anything else). Record verbatim what a visitor would likely answer or be unable to answer.

**Step 2 — Four-Factor Heuristic Audit (Clarity Axis)**
Score the page on the CLARITY axis only (the other three axes belong to sibling skills):

| Element | Clarity Question | Score 1-5 | Flag |
|---------|-----------------|-----------|------|
| Headline | States what it is + who it's for? | | |
| Subhead | Extends headline with concrete benefit? | | |
| Hero image | Reinforces headline or adds info? | | |
| Primary CTA | Action verb + what they get? | | |
| Body intro | Confirms product category within 2 sentences? | | |
| Value prop | Answers: how it helps, specific results, for whom, vs alternatives? | | |

Score legend: 1=minor, 3=noticeable drag, 5=critical conversion failure. Issues scored 3+ require immediate rewrite.

**Step 3 — Clever-vs-Clear Scan**
Comb every line of visible copy for:
- Puns, metaphors, brand-voice wordplay that delay comprehension
- Abstract adjectives: powerful, seamless, robust, game-changing, transformative
- Industry jargon or insider language the audience may not recognize
- Rhetorical questions that add friction instead of clarity
- Passive constructions that obscure who does what

Flag each instance. Rate: (a) how many seconds does this delay comprehension? (b) what direct replacement clarifies without losing the core meaning?

**Step 4 — Message Scent Check**
If traffic source is known: compare the exact words in the ad/email to the exact words in the headline and CTA on the landing page.

Scent Score:
- 3/3 of {main keyword, core promise, audience qualifier} match = STRONG SCENT
- 2/3 match = WEAK SCENT (flag, recommend alignment)
- 1/3 or 0/3 = BROKEN SCENT (Severity 5 — fix before any other work)

**Step 5 — B2B Message Layers Diagnosis (Layers 1-2)**
Apply the four-layer diagnostic in sequence. STOP at the first failed layer — do not diagnose deeper layers until shallower ones are solved.

- **Layer 1 — Clarity:** Can a visitor in the target segment state the product category within 5 seconds? (Test: Likert 1-5 comprehension score, or proxy via 5-second test in Step 1). Threshold: average score below 4 = Layer 1 fail.
- **Layer 2 — Relevance:** Does the copy use the visitor's own pain language, their specific job responsibilities, the metrics they are measured on? Or does it use the company's internal feature language? Fail = copy talks about the product, not the buyer's world.

If Layer 1 fails: produce Layer 1 rewrites only. Flag Layer 2-4 as deferred until Layer 1 is validated.

**Step 6 — Conversion Formula Leverage Stack**
Using C = 4M + 3V + 2(I-F) - 2A, rank every identified clarity problem by which coefficient it impacts:

| Fix | Formula Variable | Coefficient | Priority |
|-----|-----------------|-------------|----------|
| Headline clarity | V (value prop) | 3x | Highest |
| Concrete outcome statements | V | 3x | Highest |
| Remove distracting CTAs | F (friction) | 2x | High |
| Add trust/proof signals | A (anxiety) | 2x | High |
| CTA label specificity | I (incentive) | 2x | High |

Output: a ranked fix list in coefficient order, highest leverage first.

**Step 7 — Rewrite Package**
For every element scored 3+ in Step 2 or flagged in Steps 3-5:
- Original text (exact quote)
- Problem diagnosis (which axis, which layer, which formula variable)
- Severity score (1-5)
- Rewrite: the specific replacement copy, ready to paste
- Tier: 1 = implement now, 2 = A/B test

## OUTPUT STRUCTURE

### Section 1: 5-Second Test Result
PASS or FAIL + verbatim answers a cold visitor can/cannot give.

### Section 2: Clarity Heuristic Scores
The 6-row table from Step 2, populated with scores and flags.

### Section 3: Clever-vs-Clear Violations
Bulleted list — each entry: original phrase | problem | direct replacement.

### Section 4: Scent Score
STRONG / WEAK / BROKEN + the specific mismatches identified.

### Section 5: Message Layer Diagnosis
Layer 1 and Layer 2 pass/fail + evidence. Deeper layers flagged as deferred if Layer 1 fails.

### Section 6: Ranked Fix List
Table: Fix | Formula Variable | Coefficient | Severity | Tier. Sorted by coefficient descending.

### Section 7: Rewrite Package
One block per flagged element: Original | Problem | Severity | Rewrite | Tier.

### Section 8: What to Test vs. What to Just Fix
Tier 1 (implement now, no test): list. Tier 2 (A/B test required): list.

## WORKED MINI-EXAMPLE

**Page:** SaaS analytics tool landing page. Desired action: start free trial.
**Traffic source:** Google Ad — "sales dashboard software for revenue teams"

**Headline (original):** "See the full picture. Move with confidence."

**5-Second Test:** FAIL. Visitor cannot state what the product is ("analytics? A BI tool? A CRM?") or who it is for ("confidence" signals no specific audience).

**Scent check:** Ad said "sales dashboard software for revenue teams." Page says "See the full picture." Zero keyword overlap. BROKEN SCENT (Severity 5).

**Clever-vs-Clear violation:** "Move with confidence" — metaphor that costs 2-3 seconds of decoding. Adds zero information about the product.

**Formula variable:** Headline impacts V (value proposition), coefficient 3x. Tier 1 fix.

**Rewrite:**
- Before: "See the full picture. Move with confidence."
- After: "Sales dashboards for revenue teams — real-time pipeline, forecast accuracy, and deal health in one view."

**Result:** Headline now answers what (sales dashboards), who (revenue teams), and what specifically (pipeline, forecast, deal health). Scent restored. CTA "Start free trial" becomes credible because the visitor now knows what they are trialing.

## OUTPUT FILE
Save to: [project-folder]/Laja - Click Architecture/[YYYY-MM] - Clarity Audit - [Page Name].md
