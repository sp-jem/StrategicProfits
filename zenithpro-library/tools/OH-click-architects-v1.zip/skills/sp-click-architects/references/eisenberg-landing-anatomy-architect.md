---
name: eisenberg-landing-anatomy-architect
description: Use when a landing page needs anatomical diagnosis — maps every required page zone to the Conversion Trinity (Relevance/Value/CTA), runs the Hierarchy of Optimization in order, and outputs a zone-by-zone rewrite spec that ends bounce before persuasion even begins.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Bryan & Jeffrey Eisenberg (Call to Action 2005; Always Be Testing 2008; Persuasion Architecture 2003-2006; Conversion Trinity + Hierarchy of Optimization) — Click Architecture (Skill 3 of 7)"
interface:
  invoke: "/eisenberg-landing-anatomy-architect"
  calls: []
  called_by: [user, eisenberg-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic source mix and dominant buying modality shift with campaigns — anatomy prescriptions go stale when the audience changes."

eisenberg_scent_integration:
  feeds_from: eisenberg-scent-continuity-auditor
  feeds_to: eisenberg-conversion-trinity-builder
  shared_data: "Trigger phrase extracted from ad/email used to verify headline echo; scent score handed off to trinity builder for Relevance zone rewrite."

fogg_integration:
  feeds_from: fogg-ability-auditor
  feeds_to: fogg-prompt-designer
  shared_data: "Fogg Ability audit surfaces friction points (form length, cognitive load) that map directly to the Hierarchy of Optimization's Usability layer — fixes inform the same anatomy zones."

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: kahneman-peak-end-architect
  shared_data: "Loss/gain framing affects Value zone copy; peak-end rule governs CTA zone emotional register — both are Conversion Trinity outputs handed to kahneman skills for refinement."

iyengar_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: iyengar-tier-calibrator
  shared_data: "Choice overload in the CTA zone (multiple competing actions) is a Hierarchy-Usability failure before it is a persuasion failure — iyengar audit data informs CTA zone simplification."
---

# Eisenberg Landing Anatomy Architect

## LAYER 1: INVARIANTS (Never override.)

1. **Scent before substance.** The page headline must echo the trigger phrase of the ad, email, or search result that delivered this visitor. Scent maintenance (Information Foraging, Dr. Ed Chi 2001, applied by Eisenbergs 2004) is the highest-leverage headline test. No body copy fix outperforms a broken scent fix.
2. **Conversion Trinity sequence is non-negotiable.** Every page element is evaluated in exactly this order: Relevance first, Value second, CTA third. Diagnosing Value before confirming Relevance wastes optimization effort on the wrong layer.
3. **Hierarchy of Optimization is bottom-up.** Functional errors must be fixed before accessibility, accessibility before usability, usability before intuitive flow, intuitive flow before persuasion copy. Persuasion tactics applied on top of functional/usability failures produce zero lift.
4. **Denominator discipline.** CR = desired-action takers / qualified intentional visitors. Never optimize against total traffic. Segment analytics by intent signal (source, query, campaign) before computing conversion rate. A 2% aggregate CR can mask a 15% CR from one segment and 0.1% from another.
5. **Buying modality cannot be changed.** The page must serve the visitor's modality (Methodical / Spontaneous / Competitive / Humanistic), not train them into a different one. Mismatched page language = abandonment regardless of offer quality.
6. **Test Relevance and image as a unit; test Value as a unit; test CTA zone as a unit.** These are not independent variables. Testing headline copy without testing the hero image produces ambiguous results.
7. **Every anatomy zone maps to a dollar value.** Elements with the highest revenue proximity (CTA button, headline, hero image) get the best real estate: above-fold, left-weighted for Western readers, maximum contrast.

## LAYER 2: QUALITY GUIDANCE

1. Deliver zone-specific rewrites, not general advice. Every diagnosis must resolve to a specific element change on a specific zone of this page.
2. Flag Hierarchy violations first. A page with a broken form (Functional) or 4-second load time (Accessible/Usable) has no persuasion problem yet — it has an infrastructure problem. Naming this explicitly saves the client from optimizing the wrong layer.
3. Identify the dominant buying modality from behavioral signals (analytics patterns, heatmaps, form completion data) before prescribing above-fold copy. If analytics are unavailable, default to Methodical (45% base rate) but flag the assumption.
4. Run the pre-mortem persona walk-through for at least the primary modality. Every identified abandonment reason is a required anatomy fix, not an optional improvement.
5. Produce a prioritized fix list ordered by Hierarchy layer first, then by revenue proximity. Functional fixes always outrank persuasion fixes in the queue.

## PURPOSE

This skill applies the Eisenbergs' full landing page anatomy system to a specific page with a specific desired action. It runs the Conversion Trinity audit (Relevance / Value / CTA), diagnoses each anatomy zone against the Hierarchy of Optimization (Functional → Accessible → Usable → Intuitive → Persuasive in bottom-up order), identifies the dominant buying modality from the page and traffic signals, and outputs a zone-by-zone rewrite spec.

The lever: **unbroken information scent from the referring source to the page headline, then anatomy elements that serve the dominant modality's non-negotiable proof requirements** — these two mechanics control whether a visitor stays or bounces before any other persuasion can land.

Brag line: "Our ad and our page tell one unbroken story — scent never breaks."

## INPUT REQUIREMENTS

**Required:**
- The page (URL, screenshot, or written description with all current copy)
- The ONE desired action (click / opt-in / purchase / next-step)
- The referring source (ad copy, email subject+preview, or search query that delivered visitors)

**Strongly recommended:**
- Analytics: traffic source breakdown, scroll depth, heatmap data, form field completion rates
- Dominant traffic source (paid search, social, email, organic)
- Any existing A/B test data

**Optional:**
- Audience description (to classify dominant buying modality if analytics unavailable)
- Funnel position (top/mid/bottom of funnel affects modality weighting)

## EXECUTION PROCESS

### Step 1 — Scent Audit (Information Foraging)
Extract the trigger phrase from the referring source (ad headline, email subject line, or search query). Locate the page's H1 and hero image.

Scent score (0–3):
- 3: Trigger phrase echoed verbatim or near-verbatim in H1
- 2: Trigger concept present but words changed
- 1: Related topic but different frame
- 0: No connection — page does not confirm visitor is in the right place

Score < 2 = fix headline before everything else. This is the single highest-leverage change available. Do not proceed to Trinity audit until scent is scored.

### Step 2 — Hierarchy of Optimization Audit
Walk through the five layers in order. Flag any failure at each layer. Stop recommending persuasion changes for any zone that has an unresolved layer below Persuasive.

| Layer | Check | Failure Signal |
|-------|-------|----------------|
| Functional | Page loads, links work, form submits | 404s, JS errors, broken submit |
| Accessible | Screen reader labels, color contrast ≥ 4.5:1, keyboard nav | Missing alt text, tab traps |
| Usable | No UX friction points, self-evident navigation | Rage clicks, unexpected scroll behavior |
| Intuitive | Feels natural without thinking | Users report confusion, high exit on key step |
| Persuasive | Copy, proof, urgency, CTA | Low CR on functional/usable page |

### Step 3 — Buying Modality Classification
Classify dominant modality from analytics signals:

| Signal Pattern | Dominant Modality |
|----------------|-------------------|
| High above-fold conv., low scroll | Spontaneous (fast+emotional) |
| Heavy pricing/spec page engagement | Methodical (slow+logical) |
| High comparison page time | Competitive (fast+logical) |
| High testimonial/story page time | Humanistic (slow+emotional) |
| No analytics: default | Methodical (45% base rate) |

If multiple modalities present, identify primary (highest revenue share) and secondary. Primary goes above fold; secondary layered below without contradicting primary.

### Step 4 — Conversion Trinity Zone Map
Map every page section to its Trinity function. Score each zone Pass / Fail / Missing.

**Zone → Trinity function mapping:**
- H1 + hero image = Relevance zone (echoes scent, confirms visitor is in right place)
- Subheadline + opening copy = Relevance extension (narrows to specific desire/problem)
- Body copy + proof blocks = Value zone (explains WHY this is the right solution)
- Form layout + button copy + micro-copy = CTA zone (makes next action obvious + confident)
- Trust signals (guarantees, logos, testimonials) = CTA confidence layer

Score each zone:
- Pass: element answers its Trinity question for the dominant modality
- Fail: element present but answers the wrong question or wrong modality
- Missing: zone absent entirely

### Step 5 — Modality-Specific Anatomy Requirements
Apply the non-negotiable requirements for the dominant modality:

**Competitive (5-10% of buyers — fast+logical):**
- H1 must carry superlative backed by named evidence ("Highest-rated by [Source]")
- Comparison chart required above fold or within first scroll
- CTA language: achievement frame ("Get the advantage," "Claim your edge")
- Never: unsubstantiated claims, vague benefit language

**Methodical (45% — slow+logical):**
- Hard data, percentages, detailed specs required
- Transparent pricing with specific feature limits
- Case studies with documented, specific results
- CTA: low-pressure, evidence-forward ("See the full comparison," "Review the specs")
- Never: urgency, scarcity, hype — these signal low credibility to this type

**Spontaneous (25-35% — fast+emotional):**
- Emotional benefit lead above fold
- Visual dynamism (movement, high contrast, emotional imagery)
- Urgency and scarcity elements present
- CTA: friction-free, instant-gratification language ("Try free," "Start now," "Instant access")
- Form: one field maximum preferred; three-field max absolute

**Humanistic (10-15% — slow+emotional):**
- Mission/purpose lead ("We believe...")
- Real people visible behind brand (photos, names, authentic stories)
- Testimonials from named individuals — not logo walls
- Social impact language where authentic
- CTA: relationship language ("Join us," "Be part of this")

### Step 6 — Pre-Mortem Walk-Through
Assume the role of the dominant modality buyer. Walk the page in order. At each zone, list every reason this buyer would NOT click the CTA. Each listed reason = required fix before running variable tests.

Format: "As a [Modality] buyer at [Zone], I would not convert because: [reason]. Fix: [specific element change]."

### Step 7 — Grayscale CTA Test
Evaluate the CTA button in grayscale (simulate by describing contrast). If the button does not dominate visual attention in grayscale, it will not dominate in color. Contrast is the visual proxy for conversion priority. Prescribe specific contrast fix if failing.

### Step 8 — Denominator Segmentation Recommendation
Identify which analytics segment to use as the optimization denominator. Specify: "Compute CR using visitors from [specific source/query/campaign] who reached this page with intent to [desired action], not total pageviews." Flag any current reporting that uses total traffic as denominator — this produces a misleading baseline.

### Step 9 — Prioritized Fix List
Output all fixes ranked:
1. Hierarchy layer (Functional first, then Accessible, Usable, Intuitive, Persuasive)
2. Within Persuasive: revenue proximity (Relevance/scent fixes first, Value second, CTA third)
3. Within same priority: highest modality match lift first

## OUTPUT STRUCTURE

**SCENT SCORE:** [0–3] + verdict + specific headline rewrite recommendation

**HIERARCHY VIOLATIONS:** Table of any failures at layers 1–4, with fix and priority. If none, state "Hierarchy clear — optimization budget goes to Persuasive layer."

**DOMINANT MODALITY:** [Classification] + signal evidence used + confidence level

**CONVERSION TRINITY ZONE AUDIT:**
| Zone | Trinity | Current | Score | Required Change |
|------|---------|---------|-------|-----------------|
| (max 5 cols — abbreviated headers) | | | | |

Legend: Rel=Relevance, Val=Value, CTA=Call to Action, P=Pass, F=Fail, M=Missing

**MODALITY REQUIREMENTS GAP:** Specific elements required for dominant modality that are absent or wrong.

**PRE-MORTEM FINDINGS:** Numbered list of abandonment reasons by zone, each with a specific fix.

**CTA CONTRAST VERDICT:** Pass or fail + specific fix if failing.

**DENOMINATOR RECOMMENDATION:** Exact segmentation spec for CR calculation.

**PRIORITIZED FIX LIST:** Ranked table — Hierarchy layer, zone, fix, effort (Low/Med/High), expected impact.

**TEST GROUPINGS:** Which elements to bundle as single test units (Relevance unit = H1 + hero image; Value unit = body copy changes; CTA unit = form + button + micro-copy).

## WORKED MINI-EXAMPLE

**Page:** Email marketing SaaS landing page. Desired action: free trial signup.
**Referring source:** Google ad headline — "Automate your email list in 10 minutes"
**Current H1:** "Grow your business with smarter email"

**Scent score: 1** (related topic, different frame — "Automate / 10 minutes" promise gone).
**Rewrite:** "Automate your email list in 10 minutes — free trial, no card required"

**Analytics signal:** Heavy feature comparison tab engagement = Methodical dominant.

**Trinity audit (abbreviated):**
- Relevance zone: FAIL — H1 does not echo scent trigger; hero image shows abstract graph (no human)
- Value zone: FAIL — body copy leads with company history, not evidence-based feature specs
- CTA zone: PASS structure, FAIL language — "Sign up free" (acceptable for Spontaneous, weak for Methodical)

**Methodical gap:** No hard data above fold, no spec comparison chart, no documented case study results, CTA lacks evidence frame.

**After fixes:**
- H1: "Automate your email list in 10 minutes — free trial, no card required"
- Hero: Replaced abstract graph with screenshot of actual interface + "Used by 14,200 teams — 4.8/5 on G2"
- Body lead: "In an independent test of 47 teams, list setup took 8.3 minutes average. Competitor average: 47 minutes."
- CTA: "Start your free trial — see full feature comparison first"

**Expected outcome:** Scent restored (score 3), Methodical proof requirements met, CTA confidence layer added.

## OUTPUT FILE
Save to: [project-folder]/Eisenberg - Click Architecture/[YYYY-MM] - Landing Anatomy Audit - [Page Name].md
