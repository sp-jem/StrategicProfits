---
name: norman-error-recovery-architect
description: Use when a page has form failures, dead-end states, or abandonment after errors — diagnoses slip vs. mistake errors, installs constraint gates, and engineers one-step recovery so no visitor ever hits a dead end.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Don Norman (The Design of Everyday Things 1988/2013; Error Taxonomy: Slips vs. Mistakes, Four-Type Constraint Architecture, Seven Stages of Action) — Click Architecture (Skill 6 of 7)"
interface:
  invoke: "/norman-error-recovery-architect"
  calls: []
  called_by: [user, norman-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Form abandonment rates and device/browser error rendering shift with traffic mix; findings go stale after ~45 days of copy or layout changes."

norman_sibling_integration:
  feeds_from: [norman-gulf-of-execution-reducer, norman-feedback-state-designer]
  feeds_to: [norman-gulf-of-evaluation-reducer]
  shared_data: "Gulf-of-Execution audit surfaces which fields/steps produce slip errors; Feedback-State audit confirms whether error recovery messages meet the 100ms perception threshold; Evaluation audit inherits the resolved conceptual-model alignment from error states."

fogg_integration:
  feeds_from: [fogg-ability-auditor]
  feeds_to: [fogg-prompt-designer]
  shared_data: "Fogg Ability score drops whenever error states are unclear (ability perception collapses); error recovery patches directly raise perceived ability, restoring prompt effectiveness."

kahneman_integration:
  feeds_from: [kahneman-framing-engineer]
  feeds_to: [kahneman-peak-end-architect]
  shared_data: "An unrecovered error is a negative peak in the peak-end evaluation of the page experience; one-step recovery converts the peak from negative to neutral/positive, improving overall retrospective evaluation."
---

# Norman Error Recovery Architect

## LAYER 1: INVARIANTS (Never override.)

1. **Classify before fixing.** Every error on the page is either a Slip (correct goal, wrong execution) or a Mistake (wrong goal formed). Slip fixes = constraints + visual differentiation. Mistake fixes = semantic clarity + value-proposition restatement. Applying a Slip fix to a Mistake error wastes budget and leaves abandonment intact.

2. **Constraints prevent; feedback recovers — in that order.** The Four-Type Constraint Architecture (Physical, Semantic, Cultural, Logical) is the first line: make the error impossible or self-correcting before it occurs. Feedback messaging is the second line: if the error was not prevented, recovery must be one step with no dead ends.

3. **Every error state must close both gulfs simultaneously.** An error message that explains what went wrong (closes Gulf of Evaluation) but does not show how to fix it (leaves Gulf of Execution open) produces abandonment. Both gulfs must be resolved by the same inline intervention.

4. **No dead ends.** Every error state must present exactly one next action. A page that shows "invalid email" with no cursor placement, no field highlight, and no submit-button state change has created a dead end. Norman's rule: every erroneous state must have a visible, affordance-signaled exit path.

5. **Knowledge of the error lives in the world, not the head.** Error messages that say "Error 403" or "Invalid input" require the visitor to recall what they did wrong. The page must externalize the diagnosis: "Email must include an @ symbol — fix it here." Field label, error copy, and cursor position are all Knowledge-in-the-World mechanisms.

6. **Slip errors require physical or logical constraints, not just warnings.** A warning that a field is incomplete after submit is a post-hoc notification. The correct fix disables the Submit button (physical constraint) until all fields pass validation (logical constraint), preventing the slip from occurring.

7. **One-step recovery is the ceiling.** If recovering from an error requires more than one user action, the recovery path has failed Norman's standard. Inline correction within the same field, same modal, same page — with the cursor auto-placed — is the target state.

## LAYER 2: QUALITY GUIDANCE

1. **Error copy follows the Conceptual Model Triangle.** The Designer's Model says "the field requires a valid email." The System Image (the error message the visitor sees) must align the User Model to that intent precisely. Misaligned copy ("Something went wrong") breaks the triangle and produces confusion, not correction.

2. **Feedforward precedes feedback in form design.** Before the visitor enters a field, feedforward signals what valid input looks like: placeholder text, input mask, "(Required)" marker, format hint. This is Seven-Stages stage 3 (Specify Action) support. Feedback (error message) fires at stage 6 (Interpret State). Pages that deploy only feedback and no feedforward produce higher error rates because visitors discover constraints after failing, not before attempting.

3. **Error rates are the quantitative diagnostic.** Target: form error rate (errors per submission attempt) below 8%. Above 15% indicates a Slip-class problem requiring constraint-layer intervention. Above 25% indicates a Mistake-class problem requiring value-proposition or field-design intervention. Measure per field, not per form.

4. **Cultural constraints are the lowest-cost intervention.** Red border on an invalid field, green checkmark on a validated one — these are learned cultural signals requiring zero copy. Install them before writing a single word of error copy. If cultural constraints alone drop error rate below threshold, additional copy is optional.

5. **Test recovery, not just prevention.** Deliberately trigger every error state in QA and measure: (a) time to recover (target: under 10 seconds), (b) number of actions to recover (target: 1), (c) whether cursor auto-places in the offending field (target: yes). All three must pass before the form is considered error-safe.

## PURPOSE

Norman's error recovery lever operates on a specific web page truth: visitors do not abandon because they hit errors — they abandon because the page gives them no visible, one-step path back. This skill installs the full Norman error-prevention and error-recovery stack on a real page: classify each error as Slip or Mistake, layer the Four-Type Constraint Architecture to prevent slips, write externalized error copy that closes both Gulfs simultaneously, and verify that every broken state has exactly one affordance-signaled exit.

**Brag line:** "Every action on our page is obvious and every click confirms itself."

This is Skill 6 of 7 in the norman-* cluster (G4 Affordance & Friction Legibility). It handles only error states — prevention and recovery. Signifier stacking, feedforward on CTAs, and feedback timing live in sibling skills (norman-affordance-signifier-auditor, norman-feedback-state-designer).

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description (enough to enumerate all interactive elements and form fields)
- The ONE desired action (opt-in / purchase / next-step click)

**Highly useful (provide if available):**
- Form analytics: per-field error rates, field-level abandonment, submission failure rate
- Session recordings or heatmaps showing where visitors rage-click or stall post-error
- Current error message copy (verbatim)
- Device/browser split (mobile vs. desktop error rates often diverge sharply)

**Optional:**
- Funnel position (top-of-funnel opt-in vs. checkout has different Slip/Mistake distributions)
- Audience sophistication (novice users produce more Slip errors; expert users produce more Mistake errors)

## EXECUTION PROCESS

### Step 1 — Enumerate All Error-Producing States (10 min)

List every interactive element on the page that can produce an error or a failed state:
- Form fields (required, validated, formatted)
- Submit / CTA buttons (premature click, double-submit)
- Multi-step flows (step skipped, back-navigation data loss)
- Payment fields (card number format, expiry, CVV)
- Conditional logic (field appears/disappears based on prior answer)

For each, document: (a) what triggers the error, (b) what the current page shows, (c) whether recovery is currently possible in one step.

### Step 2 — Classify Each Error: Slip or Mistake

Apply Norman's Error Taxonomy to each item from Step 1:

| Error type | Diagnostic question | Fix layer |
|------------|--------------------|-----------| 
| Slip | Did visitor intend the right goal but execute wrong? | Physical + logical constraints |
| Mistake | Did visitor form the wrong goal or wrong belief? | Semantic clarity + model alignment |

Slip signals: typo in email, premature form submit, wrong field clicked, double-click on buy button.
Mistake signals: wrong plan tier selected, misunderstood what "free trial" means, expected different post-submit behavior.

Score: count Slip errors vs. Mistake errors. Majority-Slip pages need constraint architecture. Majority-Mistake pages need conceptual model repair first.

### Step 3 — Audit the Four-Type Constraint Layer (per field/element)

For each Slip-classified error, audit which constraint types are present and which are missing:

- **Physical:** Is the Submit button disabled until fields are valid? Are invalid characters blocked at input (e.g., phone field rejects letters)? Input masks active?
- **Semantic:** Does destructive action copy (delete, cancel, unsubscribe) communicate permanence? Is the action label precise enough to set correct expectations?
- **Cultural:** Does invalid field show red border? Does valid field show green checkmark? Is the error icon universally recognizable (not a custom glyph)?
- **Logical:** Does the step indicator show remaining steps? Does field count ("3 of 4 required") tell the visitor exactly what is left?

Missing constraint = install it. Score each field: 0-4 constraints present. Target: minimum 2 constraints per Slip-prone field; 3+ for high-stakes fields (payment, password, email).

### Step 4 — Audit Current Error Message Copy Against the Knowledge-in-the-World Standard

For each existing error message, test it against three criteria:

1. **Diagnosis externalized?** Does the copy state WHAT is wrong without requiring recall? (Pass: "Email must include @domain.com" — Fail: "Invalid email")
2. **Fix externalized?** Does the copy state HOW to correct it, on-page, right now? (Pass: "Fix it above" with cursor auto-placed — Fail: no instruction)
3. **Conceptual Model aligned?** Does the copy reflect the Designer's Model accurately via the System Image? (Pass: matches the actual validation rule — Fail: vague or contradicts the real constraint)

Score: Pass/Fail per criterion per message. Rewrite all Fail items.

**Rewrite formula:** "[What is wrong] — [Exact fix] — [Where to fix it]"
Example: "Phone number needs 10 digits — remove spaces and dashes — fix it in the field above."

### Step 5 — Verify One-Step Recovery for Every Error State

For each error state, simulate recovery and count actions required:

- Action 1: Visitor reads error message (perception — this is free, not counted)
- Action 2+: Each click, field re-entry, scroll, or navigation step

One-step recovery = a single field correction with cursor auto-placed. The visitor types the fix and hits Submit. No additional clicks, no page reload, no navigation.

If recovery requires 2+ actions, identify the specific friction point and redesign:
- Cursor not auto-placed → add `autofocus` to offending field on error
- Error message not visible without scroll → move inline, directly below field
- Submit button re-disabled → keep disabled only until fix is detected (real-time validation)
- User loses other field data on error → preserve form state on validation failure (never reset)

### Step 6 — Install and Verify

Produce a prioritized fix list ordered by: (error frequency × recovery steps required). Highest-frequency, multi-step-recovery errors ship first.

For each fix, specify:
- Element: exact field or button
- Constraint type to install or message to rewrite
- Expected error rate change (use baseline from Step 1 analytics)
- QA test: the exact action sequence that proves the fix is working

## OUTPUT STRUCTURE

**Section 1 — Error Inventory**
Table: Element | Error Type (Slip/Mistake) | Current State | Constraint Score (0-4) | Recovery Steps (current)

**Section 2 — Constraint Gap Report**
Per Slip-error field: which of the four constraint types are missing and the exact installation instruction.

**Section 3 — Error Copy Rewrites**
Table: Current copy | Diagnosis (P/F) | Fix (P/F) | Model-aligned (P/F) | Rewritten copy

**Section 4 — Recovery Path Fixes**
Ordered fix list: Element | Problem | Fix | QA test | Expected impact

**Section 5 — One-Step Recovery Verification Checklist**
For each error state post-fix: cursor auto-placed (Y/N) | form state preserved (Y/N) | single action to recover (Y/N) | error visible without scroll (Y/N)

## WORKED MINI-EXAMPLE

**Page:** Webinar registration landing page. Desired action: email opt-in submit.

**Current state:**
- Email field has no format validation until Submit is clicked
- Submit button is always active (no physical constraint)
- On error, page reloads and shows "Invalid email" at top of page
- Cursor placed at top of page, not in email field
- All other field values are reset on reload

**Error classification:** Slip (visitor typed email without @, intended valid submission)

**Constraint audit:** Physical = 0 (Submit always active), Semantic = 0, Cultural = 0 (no red border), Logical = 0 (no field status indicator). Score: 0/4.

**After — constraint layer installed:**
- Submit button disabled until email field passes regex validation (Physical)
- Email field shows red border + shake animation on invalid entry (Cultural)
- Inline error appears directly below field: "Email needs an @ — e.g., you@example.com" (Knowledge in the World)
- Cursor auto-places in email field on error (one-step recovery)
- All other field values preserved on validation failure

**Recovery steps before:** 4 (read top-of-page error, scroll to field, click field, retype). **After:** 1 (type the correction in the already-focused field).

**Expected impact:** Form error rate from ~22% to under 8% (Slip-class constraint installation benchmark from Norman taxonomy application in high-traffic opt-in forms).

## OUTPUT FILE

Save to: [project-folder]/Norman - Click Architecture/[YYYY-MM] - Error Recovery Audit.md
