---
name: eyal-hook-loop-designer
description: Use when a page has a single desired action (opt-in / click / purchase / next-step) and you need to design or audit the full Hook cycle — Trigger → Action → Variable Reward → Investment — so each visit loads the next one. Outputs a concrete four-phase redesign plan grounded in Eyal's Hook Model and Skinner's variable-ratio schedule.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Nir Eyal (Hooked, 2014; Hook Model — Trigger/Action/Variable Reward/Investment) with B.F. Skinner (variable-ratio reinforcement schedule) — Click Architecture (Skill 1 of 7)"
interface:
  invoke: "/eyal-hook-loop-designer"
  calls: []
  called_by: [user, eyal-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page copy, audience emotional state, and funnel position shift; variable reward novelty decays as users habituate to a fixed surprise pattern."

eyal_trigger_architect_integration:
  feeds_from: eyal-trigger-architect
  feeds_to: eyal-hook-loop-designer
  shared_data: "Internal trigger emotion identified (e.g. 'loneliness', 'uncertainty'); external trigger inventory (CTA labels, email subjects, push copy) — passes directly into Phase 1 of the loop design."

fogg_field_intelligence_integration:
  feeds_from: fogg-field-intelligence
  feeds_to: eyal-hook-loop-designer
  shared_data: "B=MAP friction audit output (scarcest resource: time / money / effort / brain-cycles / social-deviance / non-routine) — plugs directly into the Action phase Six-Element Simplicity diagnosis."

kahneman_field_intelligence_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: eyal-hook-loop-designer
  shared_data: "Loss-aversion framing and Peak-End memory architecture inform Investment phase copy — stored value is framed as potential loss upon defection, amplifying lock-in."

cialdini_field_intelligence_integration:
  feeds_from: cialdini-field-intelligence
  feeds_to: eyal-hook-loop-designer
  shared_data: "Commitment-ladder micro-actions feed the Investment phase; social-proof density feeds the Variable Reward Tribe category scoring."
---

# Eyal Hook Loop Designer — Click Architecture

## LAYER 1: INVARIANTS (Never override.)

1. **The loop is the unit, not the page.** Every element on the page is evaluated by whether it advances Trigger → Action → Variable Reward → Investment. Elements that break or bypass the loop are cut or repositioned.
2. **Internal trigger first.** The page must name the emotional state the visitor already feels (boredom, loneliness, fear, uncertainty) before it names a solution. Copy that skips the internal trigger installs no association and cannot become habit.
3. **Simplicity beats motivation in the Action phase.** Never write persuasion copy to overcome friction. Identify the single scarcest resource from the Six Elements of Simplicity and eliminate that one first. Adding motivation atop high friction fails.
4. **Variability is the mechanism, not the reward itself.** A guaranteed post-action experience is a de-motivator. At least one post-action element must be unpredictable to sustain dopamine-driven search mode. Remove certainty deliberately.
5. **Investment must store value and load the next trigger.** A micro-commitment that collects data for the company but delivers nothing perceivably personal to the user is a friction cost, not an investment. Reframe or cut it.
6. **Habit Zone prerequisite.** Before designing a Hook loop, plot the desired action on the Frequency × Perceived Utility matrix. If frequency is low AND perceived utility is not extremely high, the action will not become habitual. Optimize for a single strong conversion instead; do not apply Hook Model design to actions outside the Habit Zone.
7. **Primary metric is return frequency, not conversion rate alone.** A page that converts 12% on first visit but returns 3% in 7 days has a broken loop. Target ≥5% habitual-user threshold (autonomous return with no external trigger after 3+ sessions).

## LAYER 2: QUALITY GUIDANCE

1. **Each phase diagnosis must cite a specific Eyal framework** (Hook Model phase name, Six-Element dimension, Variable Reward category, stored-value type) — not generic UX language.
2. **Before→After rewrites must be present** for every copy change recommended. Do not produce observations without paired recommendations.
3. **Variable reward novelty must be specified** — name the exact unpredictable element introduced and the category it activates (Tribe / Hunt / Self). "Add a surprise" is not a deliverable.
4. **Investment micro-commitment must name the stored-value type** it creates (Content / Data / Followers / Reputation / Skill) and state how it increases future product value to this user specifically.
5. **Session recording and Habit Path diagnostic** should be referenced when analytics are available. Without analytics, flag as an assumption and recommend instrumentation.

## PURPOSE

This skill designs or rebuilds the full four-phase Hook loop on a single web page — so that each user visit increases the probability of the next. It applies Nir Eyal's Hook Model (Trigger → Action → Variable Reward → Investment) with Skinner's variable-ratio reinforcement schedule embedded in the reward phase, making habit formation a structural property of the page rather than an accident of content.

**Brag line:** "Our product builds a return habit, by design."

The key lever: eliminate the single scarcest friction resource blocking action, then follow action with an unpredictable variable reward — not a guaranteed one — to activate the dopamine-driven search state and compel return. The Investment phase then loads the next trigger, closing the loop.

## INPUT REQUIREMENTS

**Required:**
- The page (URL, screenshot, or written description with full above-the-fold and CTA copy)
- The ONE desired action (e.g. "opt-in for free guide", "click to checkout", "book a call")

**Optional (sharpen diagnosis):**
- Funnel position (cold traffic / warm / retargeting / logged-in user)
- Existing analytics (conversion rate, scroll depth, return visit rate at 7 days, session recording observations)
- Audience description (job-to-be-done, emotional state on arrival, prior product experience)
- Sibling skill outputs: eyal-trigger-architect audit, fogg B=MAP friction score

## EXECUTION PROCESS

### Step 0 — Habit Zone Gate (2 min)

Before any Hook design, plot the desired action:

| Axis | Score 1-5 | Threshold |
|------|-----------|-----------|
| Frequency (how often a user would naturally perform this action) | __ | ≥3 to qualify |
| Perceived Utility vs. alternatives | __ | ≥4 if Frequency <3 |

**Legend:** Freq = return visit / action frequency score; Util = perceived utility vs. alternatives score.

If BOTH scores are below threshold: stop Hook loop design. Recommend single-conversion optimization (no loop). Document this finding in output.

---

### Step 1 — Phase 1: Trigger Audit

**1a. Internal Trigger Mapping**

Write the narrative sentence:
> "Every time [visitor] feels [internal trigger emotion], they [desired action on this page]."

Test: does the current headline or hero copy name that emotion BEFORE naming a solution? If not, rewrite the first 7 words.

Internal trigger candidates by funnel position:
- Cold traffic: uncertainty, skepticism, FOMO
- Warm / retargeted: unresolved frustration, progress anxiety
- Logged-in / existing user: boredom, incompleteness, social comparison

**1b. External Trigger Inventory**

For each entry point (CTA button, email subject, push notification, ad headline):
- Does the label tell the user what happens next? (Yes/No)
- Does it imply the emotional relief that follows? (Yes/No)
- Score: 2/2 = functional trigger; 1/2 = partial; 0/2 = replace.

Replacement template: "[Action verb] + [object] + [implied relief]"
Example: "Submit" → "Get My Free Profit Map" (action + object + implied relief)

---

### Step 2 — Phase 2: Action Audit (Six-Element Simplicity)

For the primary action (form fill, click, purchase step), score each dimension 1 (no friction) to 5 (high friction):

| Dim | Score | Description |
|-----|-------|-------------|
| Time | __ | Seconds to complete |
| Money | __ | Fiscal cost or perceived price risk |
| Effort | __ | Physical or click labor |
| Brain | __ | Mental load, choices, reading required |
| Social | __ | Peer normalcy of this behavior |
| Routine | __ | Disruption to existing habits |

**Legend:** Dim = simplicity dimension; Brain = brain cycles; Social = social deviance; Routine = non-routine disruption.

**Diagnosis rule:** Identify the single highest-scoring dimension. That is the bottleneck. Fix it first. Do not add motivation copy to compensate for un-fixed friction — this fails.

**Cold traffic rule of thumb:** Brain cycles and Non-routine are almost always the bottleneck. Reduce form fields to minimum viable, eliminate jargon, and use social proof to normalize behavior.

**Threshold:** Any dimension scoring 4+ is a critical fix. Any form with >3 fields on cold traffic is a Brain-cycle violation.

---

### Step 3 — Phase 3: Variable Reward Design

**3a. Classify existing post-action experience**

Is the current post-click / post-opt-in / post-purchase experience:
- [ ] Fully predictable (same thank-you page for everyone) — **broken**
- [ ] Partially variable (one personalized element) — **weak**
- [ ] Genuinely unpredictable on one dimension — **functional**

**3b. Variable reward audit by category**

| Category | Present? | Implementation |
|----------|----------|----------------|
| Tribe | __ | Live social signals, real-time counts, community activity |
| Hunt | __ | Surprise reveal, curated resource, limited offer post-action |
| Self | __ | Progress bar, streak counter, completion milestone visible |

**Legend:** Tribe = social validation rewards; Hunt = information/resource acquisition rewards; Self = mastery/completion rewards.

**Requirement:** At least TWO categories must be active. All three is the target. Email is the canonical example because it delivers all three simultaneously (Tribe: replies / likes; Hunt: unknown content of next message; Self: inbox-zero completion drive).

**Implementation rule:** The unpredictable element must appear WITHIN the post-action experience (on the thank-you page, in the confirmation email, or in the product's first session). Delaying it to "future emails" does not close the loop.

---

### Step 4 — Phase 4: Investment Design

**4a. Micro-commitment placement**

Immediately after the primary action, present ONE small investment ask. Criteria:
- Takes ≤90 seconds
- Stores value in the product (not just in your CRM)
- Framed as personalizing the experience for the user

**4b. Stored-value type classification**

| Type | Example | How it loads next trigger |
|------|---------|--------------------------|
| Content | Playlist, saved items | Product becomes their library |
| Data | Profile, history | Future recommendations improve |
| Followers | Connections made | Social obligations increase |
| Reputation | Scores, ratings earned | Status at risk if they leave |
| Skill | Competency built | Switching cost increases |

**Investment copy template:**
> "Take 60 seconds to [micro-action] so we can [specific personalization benefit]."

Frame: the data belongs to the user. The product becomes more valuable to them personally. Defection now costs them their stored value.

---

### Step 5 — Habit Path Diagnostic (when analytics available)

1. Pull session recordings or funnel data for top 10% most loyal/returning users.
2. Map the exact action sequence from landing to first reward (the Habit Path).
3. Identify the minimum viable action chain — every step not on this path is a candidate for removal from new-user onboarding flow.
4. Measure: what percentage of new users hit this same path within their first session?
5. Target: ≥40% of new visitors reach at least Step 2 of the Habit Path on first visit.

---

### Step 6 — Loop Closure Check

The loop is closed when Investment loads the next Trigger. Verify:
- Does the micro-commitment generate a future external trigger? (Follow-up email, progress notification, social update)
- Does the stored value create an emotion that will function as an internal trigger on the next visit? (Incompleteness, anticipation, social obligation)
- Is there a specific next-visit hook embedded in the post-action experience? (e.g., "Your results will be ready in 24 hours — check back here.")

Score: 3/3 = loop closed; 2/3 = partial loop; <2/3 = loop broken, Investment phase rebuild required.

---

## OUTPUT STRUCTURE

**Section 1: Habit Zone Gate Result**
Frequency score / Utility score / Recommendation (Hook loop or single-conversion optimization)

**Section 2: Phase-by-Phase Diagnosis**
For each phase (Trigger / Action / Variable Reward / Investment): current state, specific failure, framework citation, fix recommendation with Before→After copy.

**Section 3: Variable Reward Specification**
Named unpredictable element + category (Tribe/Hunt/Self) + placement in post-action flow.

**Section 4: Investment Micro-Commitment**
Exact ask, stored-value type, copy, framing, next-trigger it loads.

**Section 5: Loop Closure Score**
3/3 checklist. If <3/3: specific rebuild steps.

**Section 6: Measurement Plan**
Primary metric (7-day return rate), 5% habitual-user threshold tracking method, A/B test recommendation for variable reward novelty vs. predictable control.

---

## WORKED MINI-EXAMPLE

**Page:** Cold-traffic opt-in page for a free PDF guide. Desired action: email opt-in.

**Habit Zone Gate:** Frequency = 2 (users don't naturally seek free PDFs daily) / Perceived Utility vs. alternatives = 5 (specific, high-value guide vs. generic blog posts). Score: low frequency offset by high utility — qualifies for Hook loop design.

**Phase 1 — Trigger**
- Before: Headline = "Download Our Free Guide to Doubling Revenue"
- After: "Still Unsure Which Growth Lever to Pull First?" (names internal trigger: uncertainty) → "Get the Free Map That Ends the Guessing" (names action + implies relief)

**Phase 2 — Action**
- Six-Element audit: Brain cycles = 5 (form has 6 fields + dropdown), Non-routine = 4 (unusual to give email for a PDF). Bottleneck: Brain cycles.
- Fix: reduce form to first name + email only. Remove dropdown. Add social proof line: "14,372 business owners downloaded this last month." (reduces Social Deviance score from 3 to 1)

**Phase 3 — Variable Reward**
- Before: Standard thank-you page with "Check your inbox."
- After: Thank-you page reveals ONE of three possible bonus resources (random rotation — Hunt reward) + shows "You're in good company: [live count] downloads today" (Tribe reward) + shows a one-step progress indicator: "Step 1 of 3 complete: Guide claimed" (Self reward).

**Phase 4 — Investment**
- Immediately below the bonus reveal: "Which of these 3 growth problems is your biggest right now?" (3-option button selector, 15 seconds)
- Stored-value type: Data (their answer personalizes the follow-up email sequence)
- Loads next trigger: follow-up email in 24h references their specific answer by name, creating an internal trigger of anticipation and personal recognition

**Loop closure score:** 3/3. Investment generates external trigger (24h follow-up), stored data creates anticipation (internal trigger), post-action page contains explicit next-visit hook ("Your personalized action plan arrives tomorrow").

---

## OUTPUT FILE

Save to: [project-folder]/Eyal - Click Architecture/[YYYY-MM] - Hook Loop Design - [Page Name].md
