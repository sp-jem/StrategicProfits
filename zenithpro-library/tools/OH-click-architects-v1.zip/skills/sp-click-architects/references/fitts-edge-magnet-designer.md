---
name: fitts-edge-magnet-designer
description: Use when a page's primary CTA is not anchored to screen edges, corners, or the prime pixel — diagnoses infinite-target opportunities and outputs sticky-bar / full-width button specifications that collapse Index of Difficulty to near-zero.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Paul Fitts (Fitts's Law 1954; Shannon formulation 1992; Infinite Targets / Magic Pixels) — Click Architecture (Skill 4 of 7)"
interface:
  invoke: "/fitts-edge-magnet-designer"
  calls: []
  called_by: [user, fitts-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page layout, device mix, and scroll-depth analytics shift with campaigns; edge-magnet placements go stale when hero copy or page structure changes."

fitts_target_cost_auditor_integration:
  feeds_from: fitts-target-cost-auditor
  feeds_to: fitts-edge-magnet-designer
  shared_data: "ID scores per CTA element; auditor surfaces which buttons have highest ID — edge-magnet-designer then determines whether edge/corner anchoring or full-width expansion eliminates that ID."

fitts_thumb_zone_mapper_integration:
  feeds_from: fitts-thumb-zone-mapper
  feeds_to: fitts-edge-magnet-designer
  shared_data: "Mobile prime pixel coordinates (dominant-thumb hover centroid); thumb-zone output defines where D=0 on mobile — edge-magnet-designer translates that into sticky-bottom-bar specs."

kahneman_field_intelligence_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: fitts-edge-magnet-designer
  shared_data: "Framing and salience data; Kahneman's focusing illusion means users overweight the most visible element — edge-magnet placements exploit this by making the CTA the first salient object the eye (and cursor) encounters."
---

# Fitts Edge Magnet Designer

## LAYER 1: INVARIANTS (Never override.)

1. **Infinite targets apply to desktop edges only.** On touch/mobile, screen edges and corners are the hardest zones (thumb cannot comfortably reach corners). Never apply desktop edge-anchoring logic to mobile layouts without verifying thumb-zone data first.
2. **ID = log₂(1 + D/W) governs every recommendation.** Every change proposed — wider button, sticky bar, repositioned CTA — must be traceable to a reduction in D, an increase in W, or both. Aesthetic rationale is not sufficient.
3. **Effective width (We) beats nominal width.** If heatmap/session data exists, compute We from click dispersion (standard deviation of click X-coords × 4.133). A visually large button with tight click clusters has low We — expand hit area or padding, not just visual size.
4. **Sticky CTAs must not compete with content legibility.** A sticky bar that covers 20% of viewport permanently raises the cognitive component of Interaction Cost even as it lowers the motor component. Maximum sticky bar height: 64px on desktop, 56px on mobile.
5. **Destructive actions (Cancel, Delete, Back) must be maximally distant from the primary CTA.** Proximity reduces mis-click D for the destructive action, which is the opposite of the goal. Minimum spatial separation: 200px, distinct visual treatment, no size parity.
6. **Full-width buttons collapse the homing phase by eliminating precision requirements on the horizontal axis.** This is the Two-Phase Movement Model in practice — the ballistic phase deposits the cursor/thumb anywhere on the button. Never reduce a full-width button to a narrower fixed-width without computing the ID cost.
7. **Prime pixel distance (D) is measured from the cursor's post-interaction resting position, not from page top.** After a form field, the cursor is at the input — the CTA should be the next reachable target from that exact point, not from an abstract page center.

## LAYER 2: QUALITY GUIDANCE

1. **Compute before recommending.** Provide an estimated ID value (bits) for the current state and the proposed state. Even rough estimates (D in pixels from prime pixel, W as button width) make recommendations falsifiable.
2. **Distinguish device contexts explicitly.** Every recommendation must be labeled [Desktop], [Mobile], or [Both]. An edge-magnet strategy that works on desktop (infinite target at top edge) may raise ID on mobile (edge = far from thumb zone).
3. **Test with Throughput (TP), not click rate alone.** Capture mis-click rate from session recordings. A CTA with fast clicks but 12% mis-clicks on adjacent elements has lower effective TP than a slower-clicked, better-spaced CTA. TP = ID / MT — both components must be measured.
4. **Anchor sticky elements at the correct edge per device.** Desktop: top or bottom edge (infinite targets). Mobile: bottom edge only, full-width, above the OS navigation bar.
5. **Sequential control clustering is non-negotiable in multi-field flows.** In any opt-in or checkout, the CTA must be the physically nearest interactive element to the final form field. Gap between last input and CTA submit button must be minimized — the cursor is already there.

## PURPOSE

This skill operationalizes Fitts's Law's most powerful and most underused insight: screen edges and corners are mathematically infinite targets on desktop, because the cursor cannot overshoot them. A 1px-wide sticky bar at the top of a browser window is acquired as fast as a 10,000px target. Full-width mobile buttons eliminate the homing phase entirely. The skill audits a page for edge-magnet opportunities — places where anchoring the primary CTA to an infinite surface, or expanding it to full container width, collapses Index of Difficulty toward zero — then outputs precise placement and sizing specifications.

**Brag line (carry this to a peer): "Our primary button is mathematically the easiest thing to hit on the page."**

This is the physical-effort layer of Interaction Cost. Pair with fitts-target-cost-auditor (which surfaces the problem) and fitts-thumb-zone-mapper (which defines mobile prime pixel) to get the full motor reduction stack.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description including layout structure and scroll length
- The ONE desired action (e.g., "click Add to Cart," "submit email opt-in," "click Book a Call")
- Device split: approximate % desktop vs. mobile traffic (if unknown, assume 60% mobile)

**Strongly recommended:**
- Heatmap or session recording data (click dispersion, scroll depth, mis-click rate)
- Current CTA dimensions (px width, height) and position (px from viewport top, px from viewport left/right edge)
- Number of steps in the flow if multi-step (checkout, opt-in sequence)

**Optional:**
- Analytics: conversion rate, bounce rate at CTA step
- Funnel position: entry page, mid-funnel, final checkout

## EXECUTION PROCESS

**Step 1 — Identify the Prime Pixel per device context.**
- Desktop: assume cursor rests near viewport center (approx. 640px from left on 1280px screen) or at the last interacted element. For pages with a video hero, cursor parks near the play button after engagement.
- Mobile: prime pixel is bottom-center of screen, approximately 80% of screen height from top, 50% of screen width from left (dominant-thumb hover zone, per fitts-thumb-zone-mapper output if available).
- Record prime pixel coordinates as (Px, Py).

**Step 2 — Measure current CTA ID.**
- Locate CTA center coordinates (Cx, Cy) on page load.
- Compute D = sqrt((Cx - Px)² + (Cy - Py)²) in pixels.
- Record CTA nominal width W (px) and height H (px).
- Compute ID_x = log₂(1 + D / W) along horizontal axis; ID_y = log₂(1 + D / H) along vertical axis.
- Use the higher of the two as the governing ID.
- **Threshold:** ID > 3.5 bits = high friction (act immediately). ID 2.5–3.5 bits = moderate. ID < 2.5 bits = acceptable.

**Step 3 — Audit edge/corner anchoring opportunities.**
Evaluate each option against the page's device split:

| Opportunity | Applies To | W Effect | D Effect | ID Reduction |
|-------------|-----------|----------|----------|--------------|
| Sticky top bar (CTA in header) | Desktop | High (W = full bar width) | D → 0 (cursor hits top edge) | Extreme |
| Sticky bottom bar (full-width) | Desktop + Mobile | High (W = viewport width) | D = ~Py (prime pixel to bar) | High |
| Full-width CTA (no fixed-width) | Both | Eliminates homing phase | Unchanged | High (W axis) |
| CTA directly below last form field | Both | Unchanged | D → ~40px | High (D axis) |
| Corner anchor (logo-zone CTA) | Desktop only | Low | D → near-zero | Moderate |

Legend: W = button width, D = distance from prime pixel, ID = Index of Difficulty

**Step 4 — Compute proposed ID for each candidate.**
For each viable opportunity from Step 3, estimate new D and new W and compute proposed ID = log₂(1 + D_new / W_new). Select the candidate with the lowest proposed ID that does not violate LAYER 1 invariants (especially the sticky height cap and destructive action separation rule).

**Step 5 — Specify effective width expansion.**
If heatmap data is available: compute We = 4.133 × SD_clicks (standard deviation of click X-coordinates in pixels). If We < nominal W by more than 20%, the visual button is misleading users about its hit area. Prescribe: increase visible button width, add invisible padding, or both. Target We ≥ 0.85 × nominal W.

**Step 6 — Audit competing click targets in CTA proximity.**
Scan the 200px radius around the proposed CTA position. Identify every interactive element (links, secondary buttons, nav items, social icons). Each competitor:
- Raises effective D for the primary CTA (users must aim more carefully to avoid mis-clicks)
- Adds cognitive Interaction Cost (choice friction)
- Prescribe: remove, visually suppress (reduce contrast), or relocate outside the 200px zone.

**Step 7 — For multi-step flows, compute cumulative ID.**
List each step's CTA with its estimated ID. Sum to get cumulative MT proxy. Flag the highest-ID step as the conversion bottleneck. Prioritize the edge-magnet fix at that step first.

**Step 8 — Output specifications (see OUTPUT STRUCTURE).**

## OUTPUT STRUCTURE

**Section 1: Current State Diagnosis**
- Prime pixel coordinates (desktop / mobile)
- Current CTA ID (bits) per device
- Friction classification: High / Moderate / Acceptable
- Competing click targets within 200px radius (list)

**Section 2: Edge Magnet Recommendations**
One row per recommended change, ordered by ID reduction magnitude:

| Change | Type | Device | New W | New D | Proposed ID |
|--------|------|--------|-------|-------|-------------|
| [e.g., Sticky bottom bar] | Edge anchor | Mobile | 375px | ~320px | 1.1 bits |

Legend: W = effective button width (px), D = estimated distance from prime pixel (px), ID = Index of Difficulty (bits)

**Section 3: Effective Width Audit**
- Nominal W vs. computed We (if heatmap available)
- Gap diagnosis
- Prescribed padding / visual expansion

**Section 4: Competing Target Removal List**
- Element name, distance from CTA, prescribed action (remove / suppress / relocate)

**Section 5: Cumulative ID Summary (multi-step flows)**
- Table of steps with ID per step and total cumulative ID
- Bottleneck step identified

**Section 6: Implementation Specs**
- CSS/HTML notes: sticky positioning, z-index, height constraints, min-touch-target sizes (Apple HIG: 44×44pt minimum)
- For sticky bars: scroll-trigger logic (appears after X px scroll, or always visible)
- Destructive action separation: minimum distance, visual treatment

## WORKED MINI-EXAMPLE

**Page:** SaaS free-trial landing page. Hero section, email input field, "Start Free Trial" button below input, then 800px of feature copy, then a repeat CTA at bottom of page.

**Desired action:** Click "Start Free Trial" (first CTA instance, above the fold).

**Before:**
- Desktop prime pixel: (640, 400) on 1280x800 viewport
- CTA above fold: centered, 200px wide, 44px tall, positioned at (540, 620)
- D = sqrt((640-540)² + (400-620)²) = sqrt(10000 + 48400) = 242px
- W = 200px
- ID = log₂(1 + 242/200) = log₂(2.21) = **1.14 bits** — acceptable, but...
- Repeat CTA at bottom: 200px wide, at (540, 1600)
- D from prime pixel = 1208px
- ID = log₂(1 + 1208/200) = log₂(7.04) = **2.82 bits** — moderate friction
- No sticky element. On mobile, button is 280px wide on 375px viewport, at page position 620px from top. Thumb prime pixel at ~300px from top. D = 320px, W = 280px. ID = log₂(1 + 320/280) = **1.19 bits** — but scroll required to reach repeat CTA adds immense D.

**After — Two changes:**

1. **Sticky bottom bar (mobile):** Full-width (375px), fixed at bottom (56px height). Mobile D from thumb prime pixel to bar = ~0px (cursor lands anywhere on bar; edge stops movement). ID_mobile → ~0.1 bits. Eliminates need to scroll to repeat CTA.

2. **Desktop: extend above-fold CTA to full container width (580px):** D stays at 242px. W increases from 200px to 580px. New ID = log₂(1 + 242/580) = log₂(1.417) = **0.50 bits**. Homing phase compressed from precise 200px target to land-anywhere 580px target.

**Competing target audit:** Navigation bar contains 4 text links within 80px above the CTA. Prescribe: remove nav from landing page or visually suppress to near-invisible. Each link was forcing users to aim carefully past them to hit the CTA.

**Result summary:**

| Metric | Before | After |
|--------|--------|-------|
| Desktop ID (above fold) | 1.14 bits | 0.50 bits |
| Mobile ID (sticky bar) | 1.19 bits | ~0.10 bits |
| Repeat CTA ID (mobile) | ~3.5 bits (scroll) | Eliminated by sticky |
| Competing targets (200px) | 4 nav links | 0 |

## OUTPUT FILE

Save to: [project-folder]/Fitts - Click Architecture/[YYYY-MM] - Edge Magnet Design.md
