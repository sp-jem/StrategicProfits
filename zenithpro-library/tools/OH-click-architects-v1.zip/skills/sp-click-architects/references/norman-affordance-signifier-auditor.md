---
name: norman-affordance-signifier-auditor
description: Use when a page has low click-through, invisible CTAs, or visitor confusion about what to do — audits whether each action is both structurally possible (affordance) and visibly signaled (signifier) using Norman's Affordance/Signifier Distinction and Discoverability framework.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Don Norman (The Design of Everyday Things, 1988/2013; Affordances vs. Signifiers Distinction; Discoverability & Understanding) — Click Architecture (Skill 1 of 7)"
interface:
  invoke: "/norman-affordance-signifier-auditor"
  calls: []
  called_by: [user, norman-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page redesigns, A/B test winners, and seasonal copy changes can invalidate signifier stacks within weeks."

norman_gulf_integration:
  feeds_from: norman-gulf-of-execution-reducer
  feeds_to: norman-gulf-of-evaluation-reducer
  shared_data: "Signifier audit findings directly populate gulf-of-execution analysis; evaluation gulf audit requires affordance inventory as prerequisite."

fitts_integration:
  feeds_from: fitts-field-intelligence
  feeds_to: fitts-target-spacing-optimizer
  shared_data: "Signifier stack completeness score passed to Fitts as CTA salience input; Fitts target-size data feeds back as physical-constraint recommendation."

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: kahneman-framing-engineer
  shared_data: "Invisible affordances force System 2 effort; signifier completeness score maps to kahneman cognitive-load dial — high-friction audit flags become kahneman isolation-effect candidates."
---

# Norman Affordance & Signifier Auditor

## LAYER 1: INVARIANTS (Never override.)

1. Audit the SIGNIFIER stack, not the affordance directly. Designers control signifiers — shape, color, label, hover state — not affordances. Every finding must name which signifier layer is absent or broken.
2. Discoverability is the primary diagnostic question: can the visitor figure out what actions are possible and where/how to perform them WITHOUT relying on memory (knowledge in the head)? If the answer requires prior learning, the page fails Norman's standard.
3. Every audit produces a per-element Signifier Completeness Score (SCS): 0-4, one point per signifier layer present (shape/affordance cue, color contrast, action-verb label, hover state). SCS < 3 on the primary CTA = critical failure, fix before anything else.
4. Knowledge must be in the world, not the head, for every conversion-critical step. If a visitor must remember what a button does, where to find the form, or what a field expects — that is a signifier failure, not a user failure.
5. The audit is scoped to ONE desired action per session. Competing clickables are friction inventory, not features. Do not normalize secondary links — flag every one.
6. Feedforward (what can I do?) is audited here. Feedback (what happened?) is the domain of norman-gulf-of-evaluation-reducer. Do not conflate them.
7. Constraint architecture (physical, semantic, cultural, logical) is evaluated only as it affects signifier clarity on this skill's target action. Constraint design belongs to siblings.

## LAYER 2: QUALITY GUIDANCE

1. Use Norman's exact vocabulary: affordance, signifier, discoverability, knowledge-in-the-world, feedforward. Generic UX language ("make it clearer," "improve visibility") is not acceptable output.
2. Every recommendation includes the specific signifier layer being added or repaired, not just "improve the button."
3. Threshold-anchor all scores. SCS 0-1 = broken. SCS 2 = marginal. SCS 3 = functional. SCS 4 = optimized. Report the score, then the prescription.
4. Before-after copy must be literal: old label text → new label text. Not "use action-oriented language."
5. If two elements share a color (CTA color found elsewhere on page), flag it as a signifier collision — the exclusivity that makes the CTA visually privileged is destroyed.

## PURPOSE

This skill puts Don Norman to work on a live web page: it systematically audits whether every intended action is both structurally possible (affordance) and visibly, unambiguously signaled (signifier), so the visitor never has to guess, remember, or hunt.

Norman's core distinction — affordances exist whether or not perceived; signifiers are the perceivable signals that make affordances visible — is the lever. A button that affords clicking but lacks a complete signifier stack is invisible in practice. This skill finds every gap between what the page allows and what it communicates.

**Brag line: "Every action on our page is obvious and every click confirms itself."**

The audit closes the Gulf of Execution at stages 2-4 of Norman's Action Cycle (Form Intention → Specify Action → Execute Action) by ensuring that every affordance the page offers is backed by a full signifier stack, and that every conversion-critical step externalizes its knowledge onto the page rather than demanding it from visitor memory.

## INPUT REQUIREMENTS

**Required:**
- Page: URL, live screenshot, or written description with key element positions
- Desired action: the ONE outcome this page must drive (opt-in / purchase / click-to-next-step)

**Optional but improves output:**
- Heatmap or first-click test data (identifies where visitors look vs. where they click)
- Click-through rate on primary CTA (baseline for measuring signifier impact)
- Funnel position (top/mid/bottom-of-funnel shifts expected signifier density)
- Audience prior familiarity with the product/category

## EXECUTION PROCESS

### Step 1 — Element Inventory (5 min)
List every clickable element on the page. Include: primary CTA, secondary CTAs, navigation links, inline hyperlinks, form submit buttons, image links, social icons. Record each with its label text and visual position.

Flag the desired-action element (DA). Flag every non-DA clickable as friction inventory (FI). Count: FI items > 3 on a conversion page = architectural problem regardless of signifier quality.

### Step 2 — Signifier Completeness Score (SCS) Per Element
Score the DA element and the top 3 FI items on four layers. Award 1 point each:

| Layer | What to check | Pass condition |
|-------|--------------|----------------|
| Shape | Does it look like a button? | Raised, bordered, or pill shape — not flat text |
| Color | Is CTA color unique on page? | That exact color appears nowhere else |
| Label | Is the label an action verb? | "Get Access" not "Submit" or "Learn More" |
| Hover | Does it respond visually? | Color shift, shadow, or cursor change on hover |

**Threshold:** DA must score 4/4. Score 3/4 = one repair. Score ≤ 2/4 = rebuild.

### Step 3 — Discoverability Test (3-second scan)
Cover all text labels mentally. Can a visitor determine from shape and color alone that the DA element is the next action? If no: the page relies on knowledge in the head — signifier failure at the shape/color layers.

Scoring proxy (use if heatmap available): first-click accuracy on DA element. Target ≥ 60%. Below 40% = critical discoverability failure.

### Step 4 — Feedforward Audit
Below or adjacent to the DA element: is there microcopy stating what happens after clicking? Norman's feedforward requirement: the visitor must be able to answer "what will happen?" BEFORE executing the action.

Score: present + specific ("You'll get instant access — no card required") = pass. Absent or vague ("Click here") = fail.

**Worked threshold:** if funnel position is checkout, feedforward must address the top purchase anxiety (e.g., "Cancel anytime. Billed monthly."). Generic feedforward ("Learn more") scores 0 even if present.

### Step 5 — Knowledge-in-the-World Audit (Form elements)
For each required form field: is the expected input format visible on the page without clicking? Check for:
- Visible field label (not placeholder-only — placeholder disappears on focus, forcing memory)
- Inline format hint for structured fields (phone: "(555) 555-5555", card: "16-digit number")
- Required-field marker visible before interaction

Any field relying on placeholder-as-label = knowledge-in-the-head violation. Flag each.

### Step 6 — Signifier Collision Audit
Search the page for the CTA's exact hex color. If found in a non-CTA element (header, body text, decoration), the CTA loses visual privilege. One collision = marginal. Two or more = CTA is indistinguishable at the color layer.

### Step 7 — Competing Affordances Score
Count total clickable elements not serving the DA. Rate:
- 0-2 FI items: clean
- 3-5 FI items: moderate friction
- 6+ FI items: high friction — Gulf of Execution widened at the "Specify Action" stage; recommend suppressing navigation and secondary links

### Step 8 — Synthesize & Prioritize
Rank all findings by impact tier:

| Tier | Condition | Fix urgency |
|------|-----------|-------------|
| P0 | DA SCS ≤ 2 or first-click accuracy < 40% | Fix before any traffic |
| P1 | Missing feedforward / placeholder-only labels | Fix before optimization testing |
| P2 | Signifier collision / FI count > 5 | Fix in next iteration |
| P3 | Hover state absent / marginal label copy | Fix in A/B test |

## OUTPUT STRUCTURE

**1. Element Inventory Table**
Cols: Element | Type (DA/FI) | Label | SCS (0-4) | Tier
Abbreviate: Type → T, Label → Lbl, Tier → Pr

**2. SCS Detail for DA Element**
Layer-by-layer: pass/fail + exact repair instruction.

**3. Feedforward Status**
Current microcopy (verbatim) → recommended replacement (verbatim).

**4. Knowledge-in-the-World Violations**
Each field with placeholder-as-label: field name + repair.

**5. Competing Affordances Count + Recommendation**
Raw count + suppress/keep decision per FI item.

**6. Priority Repair List**
Ordered P0 → P3, one sentence per item, naming the signifier layer and the Norman principle violated.

**7. Projected Impact**
If baseline CTR is known: estimate CTR lift from P0+P1 fixes. Benchmark: SCS 2→4 repair on primary CTA = 15-35% CTR lift (Nielsen Norman Group first-click studies; confirm via A/B test within 45 days per freshness gate).

## WORKED MINI-EXAMPLE

**Page:** Software opt-in landing page. DA: email opt-in form with "Submit" button.

**Before audit:**
- Button label: "Submit" (shape layer: pass — has border; color layer: fail — same blue as header links; label layer: fail — not an action verb; hover layer: pass — darkens on hover). SCS = 2/4.
- Below button: no microcopy.
- Email field: label is placeholder text only ("Enter your email").
- Competing clickables: top nav with 6 links visible.

**After repairs:**
- Button label changed to "Send Me the Free Guide" (label layer: pass).
- Button color changed to high-contrast orange used nowhere else on page (color layer: pass). SCS = 4/4.
- Feedforward added below button: "Delivered instantly. Unsubscribe any time."
- Email field: visible label "Work Email" added above input; placeholder retained as format hint only.
- Navigation hidden on landing page variant.

**Measured result proxy:** first-click accuracy on DA button from 34% → 61% (simulated via first-click test). Qualifies for A/B traffic split.

**Action Cycle stage mapping for this example:**
- Stage 3 (Specify Action) was failing: "Submit" label did not communicate the outcome.
- Stage 2 (Form Intention) was degraded: blue-on-blue made the CTA indistinguishable from nav links.
- Repairs addressed both stages before any traffic ran.

## CLUSTER SIBLINGS — DO NOT DUPLICATE

This skill covers Layers 1-4 of the Action Cycle (Execution side, affordance/signifier diagnosis).
- **norman-gulf-of-execution-reducer** — full Gulf of Execution architecture and constraint design.
- **norman-gulf-of-evaluation-reducer** — Layers 5-7 (Perception, Interpretation, Evaluation) and feedback system design.
- **norman-mapping-auditor** — Natural Mapping violations (spatial, metaphorical, behavioral).
- **norman-feedback-state-designer** — state-change feedback (spinner, button label change, success messages).
- **norman-error-recovery-architect** — Slip vs. Mistake taxonomy and recovery copy.
- **norman-field-intelligence** — meta-skill; routes to all siblings by page symptom.

## OUTPUT FILE
Save to: [project-folder]/Norman - Click Architecture/[YYYY-MM] - Affordance Signifier Audit.md
