---
name: pirolli-foraging-cost-reducer
description: Use when a page has traffic but low conversion and you suspect friction (not scent) is the culprit — diagnoses and eliminates within-patch and between-patch costs blocking the desired action.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peter Pirolli & Stuart Card (Information Foraging Theory 1999; Two-Cost Model; Marginal Value Theorem applied to pages) — Click Architecture (Skill 6 of 7)"
interface:
  invoke: "/pirolli-foraging-cost-reducer"
  calls: []
  called_by: [user, pirolli-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page friction profiles shift with device mix, traffic source changes, and CRO edits — stale audits miss new cost sources introduced by redesigns or new ad campaigns."

pirolli_scent_trail_integration:
  feeds_from: [pirolli-scent-trail-auditor]
  feeds_to: []
  shared_data: "Scent-trail auditor identifies WHERE scent breaks; this skill identifies WHERE friction accumulates after scent is sufficient. Run scent-trail-auditor first; if scent is strong but conversion still fails, hand off to this skill for within-patch cost reduction."

pirolli_patch_abandonment_integration:
  feeds_from: [pirolli-patch-abandonment-predictor]
  feeds_to: []
  shared_data: "Patch-abandonment-predictor flags the page section where the Marginal Value Theorem exit condition fires. This skill then targets that exact section for within-patch cost reduction — cutting reading load, scroll distance, and cognitive friction at the precise abandonment point."

kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: []
  shared_data: "Kahneman's System 1/2 model explains WHY within-patch friction costs are non-linear: cognitive load triggers System 2 engagement, which multiplies perceived effort and accelerates patch-leaving. Use kahneman's peak-end-rule outputs to prioritize which friction points to remove first (the worst-peak friction on the path to the action)."
---

# Pirolli Foraging Cost Reducer

## LAYER 1: INVARIANTS (Never override.)

1. **The Two-Cost Model is not optional context — it is the diagnostic frame.** Every conversion failure on a page with adequate scent is either a within-patch cost problem (effort to extract value from the current page) or a between-patch cost problem (friction returning to the page after leaving). Diagnose which type before recommending any change.

2. **Reducing between-patch cost shortens sessions; reducing within-patch cost extends them.** Never recommend a faster-loading page or cleaner navigation as a conversion fix without acknowledging the tradeoff: you are lowering the bar for patch-leaving by making departure cheaper. The primary conversion lever is within-patch cost reduction.

3. **The Marginal Value Theorem governs exit timing.** A user leaves when within-patch gain rate drops to the environmental average — not when the page is "confusing." Every scroll that yields lower value-per-second than the previous scroll accelerates the exit clock. Friction compounds; it does not average.

4. **Rate-maximizing, not value-maximizing.** Users optimize [Information Gained] / [Time Invested]. A page delivering high value slowly loses to a page delivering moderate value instantly. Speed of value perception is a cost variable, not a design preference.

5. **SNIF-ACT activation formula governs link and CTA selection.** A_i = B_i + Σ(S_ji × W_j). Every button label, link, and next-step element is evaluated by this formula before the user clicks. If S_ji (association strength between the CTA label and the user's goal vocabulary) is low, no amount of button color or placement compensates.

6. **Within-patch cost is formatting.** Dense paragraphs, absent subheadlines, buried keywords, and long scroll distances are not aesthetic choices — they are friction charges that subtract from value-per-second and trigger premature exit.

7. **No recommendation is valid without a cost type assignment.** Every change proposed must be labeled: (WP) within-patch cost reduction or (BP) between-patch cost reduction — and the expected effect on conversion direction stated explicitly.

---

## LAYER 2: QUALITY GUIDANCE

1. **Quantify cost before prescribing the fix.** Estimate reading time, scroll depth to CTA, word count of value-bearing sections vs. filler sections. A recommendation without a baseline cost measurement is an opinion, not a diagnosis.

2. **Prioritize by abandonment-point proximity.** Fix the highest-cost element closest to the CTA first. A friction point 3 scrolls before the button kills more conversions than equivalent friction in the hero — the Marginal Value Theorem exit condition fires cumulatively.

3. **Never remove content to reduce cost — reformat it.** Bullet lists, bold keywords, and descriptive subheads reduce within-patch cost without reducing information density. Deleting paragraphs is a content decision, not a cost-reduction decision.

4. **Between-patch cost reductions require re-engagement design.** When you lower BP cost (faster load, cleaner nav), pair it with an early micro-commitment capture (email, quiz, bookmark prompt) to retain users who leave before converting and make re-entry cheap.

5. **Verify against traffic source.** Between-patch costs differ by channel: search users have a cheap back-button (high BP cost tolerance is assumed wrong); email users have already made a micro-commitment (lower BP cost, higher WP cost threshold). Calibrate accordingly.

---

## PURPOSE

This skill applies Pirolli & Card's Two-Cost Model and Marginal Value Theorem directly to a specific web page to locate and eliminate the friction — within the page and at the page boundary — that is blocking a defined desired action.

**The lever:** Most page-conversion failures attributed to "weak copy" are actually within-patch cost failures: the value is present, but the extraction effort exceeds the user's rate threshold before they reach the CTA. This skill finds the exact cost sources and eliminates them without touching scent (handled by sibling skills).

**Brag line:** "We can predict which links leak visitors before we ship the page." — Pirolli & Card's SNIF-ACT model computes link activation from goal-vocabulary overlap; the same math reveals which page elements are burning cost without returning value, before a single user session is run.

---

## INPUT REQUIREMENTS

**Required:**
- The page: URL, live screenshot, or written element-by-element description (hero, subheads, body blocks, CTA, navigation visible)
- The ONE desired action: the single conversion event being optimized (e.g., "click the opt-in button," "start the free trial," "book the call")

**Optional (improves diagnosis accuracy):**
- Analytics: scroll-depth heatmap, time-on-page, bounce rate by traffic source
- Traffic source: which channel (search/ad/email/social) to calibrate between-patch cost baseline
- Funnel position: is this a cold landing page, warm nurture page, or cart/checkout page?
- Session recordings: rage clicks, u-turn scrolls, exit clicks

---

## EXECUTION PROCESS

**Step 1 — Classify the failure type (5 minutes)**

Before touching the page, answer: is this a scent failure or a cost failure?

- If bounce rate is high AND time-on-page is under 15 seconds → likely a scent failure. Hand off to `pirolli-scent-trail-auditor` first.
- If time-on-page is adequate (60+ seconds) AND scroll depth reaches 50%+ AND conversion is still low → this is a cost failure. Proceed.
- If time-on-page is adequate but scroll depth stops well before the CTA → within-patch cost is too high at the scroll-exit point. Mark that section as the primary target.

**Step 2 — Measure within-patch cost (WP inventory)**

Walk the page element by element. For each section, score:

| Section | Format | Word Count | Value Density | WP Cost Rating |
|---------|--------|------------|---------------|----------------|
| Hero | Paragraph/List/Visual | N | High/Med/Low | 1–5 |
| Subhead block | ... | ... | ... | ... |
| Body block N | ... | ... | ... | ... |
| Social proof | ... | ... | ... | ... |
| CTA block | ... | ... | ... | ... |

**WP Cost Rating scale:**
- 1 = bullets, bolded keywords, scannable subheads, value visible in 3 seconds
- 3 = mixed format, some dense paragraphs, requires moderate reading
- 5 = dense paragraph blocks, no visual hierarchy, requires sustained reading to extract value

**Threshold:** Any section rated 4+ that sits between the hero and the CTA is a conversion-blocking cost source. Sections rated 3+ within one scroll of the CTA are high-priority targets.

**Step 3 — Identify the Marginal Value Theorem exit point**

Using scroll-depth data (if available) or page structure analysis:

- Locate the section where value-per-second drops fastest (where dense text follows high-value bullets, or where the page shifts from proof to explanation, or where off-topic content appears).
- This is the MVT exit point — the location where the user's gain rate drops to environmental average and the exit decision is made.
- Label it explicitly: "MVT Exit Point: [Section Name], approx. scroll depth [X]%."

**Step 4 — Audit between-patch cost (BP inventory)**

Assess the cost of leaving and returning:

- Page load time (WP: under 2.5s LCP is neutral; over 3.5s LCP actively increases BP cost of staying — paradoxically, slow load makes the current patch feel low-value)
- Navigation visibility: does the header menu offer 5+ escape routes? Each visible exit link is a between-patch cost reducer — it makes leaving cheaper. Count them.
- Back-button expectation: is there a clear breadcrumb or progress indicator? Absence increases BP cost to re-enter if user leaves.
- Micro-commitment capture: is there an email opt-in, lead magnet, or quiz visible before the primary CTA? Absence means users who leave are lost permanently — no BP re-entry mechanism.

**Step 5 — Apply SNIF-ACT to CTA and key links**

For the primary CTA button and any navigation links above the fold, evaluate activation:

A_i = B_i + Σ(S_ji × W_j)

In practice: list the trigger words in the user's goal vocabulary (from ad keywords, email subject lines, or search terms bringing traffic). Count how many appear in each proximal cue (CTA label, button text, surrounding sentence). Score 0–3:

- 0 trigger words in CTA label → activation near zero → rewrite required
- 1–2 trigger words → moderate activation → optimize
- 3+ trigger words in CTA + surrounding text → high activation → leave it

**Step 6 — Build the cost reduction prescription**

For each identified cost source, prescribe a specific change with:
- Cost type: (WP) or (BP)
- Current state: what the element looks like now
- Target state: exactly what to change it to
- Mechanism: which framework principle drives the fix
- Expected effect: what conversion metric should move and in which direction

---

## OUTPUT STRUCTURE

**1. Cost Failure Confirmation**
One paragraph: scent vs. cost classification, supporting evidence, confidence level.

**2. Within-Patch Cost Inventory**
Scored table (Section / WP Cost Rating / Primary Friction Source / Priority).

**3. MVT Exit Point**
Named section, scroll depth estimate, description of what triggers the exit condition there.

**4. Between-Patch Cost Audit**
Bullet list of BP cost factors found: escape links, load time, re-entry mechanisms present/absent.

**5. SNIF-ACT CTA Scorecard**
CTA label, trigger word count, activation rating (Low/Med/High), rewrite recommendation if needed.

**6. Prioritized Cost Reduction Prescription**
Ordered list of changes (highest-conversion-impact first). Each entry: Cost Type / Current State / Target State / Mechanism / Expected Effect.

**7. Re-Engagement Design Recommendation**
If BP costs were found to be low (easy to leave), one specific micro-commitment element to add with placement and copy.

---

## WORKED MINI-EXAMPLE

**Page:** SaaS landing page. Traffic source: Google Ads ("project management for remote teams"). Desired action: Start Free Trial.

**Failure signal:** Time-on-page = 2m 10s. Scroll depth: 68% average. Conversion: 0.8%. CTA is at scroll depth 72%.

**Step 1 result:** Cost failure confirmed. Users are reaching near the CTA but not converting.

**Step 2 — WP cost inventory (excerpt):**

| Section | Format | WP Cost |
|---------|--------|---------|
| Hero | H1 + 3-sentence paragraph | 3 |
| Features block | 6 paragraphs, no bullets | 5 (flagged) |
| Testimonials | 3 × 80-word wall quotes | 4 (flagged) |
| CTA block | Button only, no surrounding copy | 2 |

**Step 3 — MVT Exit Point:** Features block (scroll depth ~45–60%). Dense paragraphs after a strong hero create a gain-rate cliff. This is where the exit clock fires.

**Step 5 — SNIF-ACT CTA audit:**

CTA label: "Get Started"
Trigger words from ad: "remote teams," "project management," "try free"
Trigger words in CTA label: 0
Activation rating: Low → Rewrite required.

**Before:** "Get Started"
**After:** "Try Free — Built for Remote Teams"

Mechanism: S_ji increases because "remote teams" and "free" directly match the goal vocabulary from the ad. Activation rises without any other page change.

**Top prescription (WP cost):**

(WP) Features block — Convert 6 paragraphs to headline + 3-bullet format per feature. Each bullet leads with a bolded outcome word. Estimated reading time drops from 4 min to 45 sec. Expected effect: scroll completion rate to CTA increases; MVT exit condition no longer fires at this section.

**Before:**
> "Our platform enables distributed teams to coordinate tasks, track milestones, and communicate in real time without switching between multiple applications, which reduces the overhead associated with managing complex projects across time zones..."

**After:**
> **Zero app-switching.** Tasks, milestones, and team chat — one screen, any time zone.

Within-patch cost: 5 → 1. Value delivered per second: 8× increase.

---

## OUTPUT FILE

Save to: [project-folder]/Pirolli - Click Architecture/[YYYY-MM] - Foraging Cost Reduction Audit.md
