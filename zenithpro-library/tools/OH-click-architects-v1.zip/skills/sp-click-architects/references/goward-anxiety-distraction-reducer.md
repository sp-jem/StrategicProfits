---
name: goward-anxiety-distraction-reducer
description: Use when a landing page has visible trust signals, a form, or competing links — diagnose and eliminate the two LIFT drag forces (Anxiety + Distraction) that suppress conversion below the value-prop ceiling.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Chris Goward (You Should Test That, 2012; LIFT Model, 2009) — Click Architecture (Skill 4 of 7)"
interface:
  invoke: "/goward-anxiety-distraction-reducer"
  calls: []
  called_by: [user, goward-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Trust badge relevance, nav structure, and audience anxiety triggers shift with market conditions and competitor claims."

goward_lift_integration:
  feeds_from: goward-value-prop-fulcrum-auditor
  feeds_to: goward-hypothesis-generator
  shared_data: "LIFT score for Anxiety + Distraction sub-factors; list of anxiety sources surfaced by qualitative research"

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: goward-hypothesis-generator
  shared_data: "Loss-aversion framing in risk copy; System 1 triggers that raise or lower perceived cost in the cost-benefit equation"

fogg_integration:
  feeds_from: fogg-field-intelligence
  feeds_to: goward-urgency-architect
  shared_data: "Ability sub-factors that overlap with distraction (complexity, effort signals); motivation levers that counteract anxiety"
---

# Goward: Anxiety & Distraction Reducer

## LAYER 1: INVARIANTS (Never override.)

1. Value Proposition is the ceiling; Anxiety and Distraction are floor drains. Fixing drag never raises the ceiling — it only captures more of what the value prop already earned.
2. The conversion decision is a subconscious cost-benefit equation: Perceived Benefits minus Perceived Costs. Every element that raises perceived cost (risk, effort, social risk, price ambiguity) is an anxiety drag. Remove or reframe before adding urgency or clarity.
3. Distraction is any page element that competes with the single desired action. Navigation menus, outbound links, secondary CTAs, and competing headlines all split attention and reduce conversion probability. Identify by asking: "Does this element serve the macro conversion or serve something else?"
4. Trust badges can increase anxiety when poorly placed. A badge that draws the eye toward the concept of security also draws attention to the possibility of a threat. Placement and size must be tested, not assumed.
5. Qualitative research surfaces anxiety sources that analytics cannot. Heuristic scoring alone misses hidden barriers. Use user testing with emotional probing (Motivation Lab style) to find non-obvious fears before writing hypotheses.
6. No universal best practices — only tested hypotheses. An element that reduces anxiety for sophisticated buyers may signal low quality to price-sensitive buyers. Context overrides conventions.
7. Test the macro conversion metric only. Optimizing for secondary micro-conversions (scroll depth, time on page) while Anxiety and Distraction suppressors are active produces misleading conclusions.

## LAYER 2: QUALITY GUIDANCE

1. Score every anxiety and distraction element before writing a single hypothesis. The LIFT audit must precede the test roadmap (this is Step 2 of the Kaizen Method — heuristic site analysis before prioritized focal areas).
2. Rank hypotheses by maximum return on effort. Address the two or three highest-scoring drag factors first. Do not test micro-copy polish while a nav menu is leaking 30% of visitors.
3. Always include one "left field" variation per test round — a never-before-tested structural change (e.g., removing the entire sidebar, relocating the form above the fold). If it wins, it opens a new testing direction. Run 2-5 variations maximum.
4. Run tests to statistical significance, not to calendar deadlines. Duration depends on traffic volume. For sites below 1M monthly visitors, use fractional factorial Design of Experiments (DOE) to achieve multivariate insight without multivariate traffic requirements.
5. Post-test analysis is mandatory. A losing variation on anxiety reduction still reveals how visitors process risk. Document the behavioral insight, not just the winner.

## PURPOSE

This skill applies Chris Goward's LIFT Model to a specific web page and desired action, targeting the two conversion drag forces — Anxiety and Distraction — that suppress the conversion rate below the ceiling set by the value proposition. Using the Kaizen Method's heuristic analysis step and the Infinity Optimization Process's Explore-phase diagnostics, it produces a prioritized list of concrete, testable page changes.

Brag line: "We can score any landing page on 6 conversion forces before testing — and know exactly which two are costing you the most revenue right now."

## INPUT REQUIREMENTS

Required:
- The page (live URL, screenshot, or written description with key sections quoted)
- The ONE desired macro conversion action (e.g., "submit the lead form," "click Add to Cart," "start free trial")

Optional but high-value:
- Traffic source(s) (Google Ads, email, organic) — affects message match diagnosis
- Analytics data: bounce rate, form abandonment rate, scroll depth, exit pages
- Qualitative data: user test recordings, support tickets, objections from sales calls
- Audience profile: sophistication level, purchase stage, prior brand exposure
- Funnel position: cold traffic vs. retargeted vs. logged-in

## EXECUTION PROCESS

### Step 1: Scope the macro conversion and drag ceiling

State the single conversion action. Note the value prop ceiling score from goward-value-prop-fulcrum-auditor if available — this bounds how much drag reduction can actually move the needle. If no prior LIFT score exists, do a 2-minute heuristic pass on the full LIFT six-factor grid before proceeding.

### Step 2: Anxiety audit — score all 27+ sub-factors for the Anxiety dimension

For each page element, ask: does this raise perceived cost (risk, effort, time, social risk, price ambiguity)?

Score each anxiety source on a 1-3 scale:
- 1 = minor friction (small form field label ambiguity, generic placeholder text)
- 2 = moderate drag (missing security indicator near payment field, vague cancellation policy)
- 3 = severe drag (form asks for phone number with no explanation, no privacy statement near email field, trust badge placed so large it highlights threat)

**Anxiety sub-factor checklist:**

| Sub-factor | Where to look | Score (1-3) |
|---|---|---|
| Privacy / data risk | Near form, footer | |
| Payment security | Near price, checkout | |
| Commitment risk | CTA label, terms | |
| Social risk | Testimonials absent | |
| Effort cost | Field count, steps | |
| Reversal / refund | Near CTA | |
| Legitimacy signals | About, contact, SSL | |
| Badge placement | Form vicinity | |
| Price ambiguity | Pricing section | |

Threshold: any sub-factor scoring 3 is a Priority 1 fix. Any two sub-factors each scoring 2 are collectively Priority 1.

### Step 3: Distraction audit — map every element competing with the macro conversion

List every interactive or visually prominent element on the page that is NOT the primary CTA path. For each:
- Is this navigation? (nav menu, header links, footer links)
- Is this a secondary CTA? (social share, "read more," newsletter signup that is not the macro conversion)
- Is this an outbound link? (social icons, partner logos with links, footnote citations)
- Is this visual noise? (rotating carousel, auto-play video unrelated to offer, stock photo that competes for gaze)

Score distraction load: total competing clickable elements as a ratio to the primary CTA. Threshold:
- 0-2 competing elements: low distraction
- 3-5 competing elements: moderate drag
- 6+ competing elements: severe drag — remove before any other optimization

### Step 4: Prioritize drag removals by cost-benefit equation impact

Rank all identified anxiety and distraction items using the cost-benefit equation lens:

  Conversion lift potential = (severity of drag) x (frequency of visitor exposure to this element) x (proximity to the decision moment)

Elements near the CTA, seen by all visitors, with a severity score of 3 are Priority 1. Elements below the fold, seen by 20% of visitors, with severity 1 are low priority.

### Step 5: Generate concrete hypotheses (one per drag source)

For each Priority 1 and Priority 2 item, write a hypothesis in this form:

  "Because [visitor segment] experiences [specific anxiety/distraction], changing [specific element] from [current state] to [proposed state] will increase [macro conversion] by reducing perceived cost / competing attention."

Apply Goward's on-page tactics directly:
- Navigation removal: strip header nav and footer links on dedicated landing pages
- Trust badge repositioning: move badge adjacent to the specific form field or button it addresses (SSL badge next to the submit button, not in the footer)
- Form field justification: add inline micro-copy explaining why each sensitive field is needed
- Phone field removal or optional labeling: test removing phone entirely vs. marking optional
- CTA label reframe: shift from command ("Submit") to benefit-action ("Get My Free Audit") to reduce commitment anxiety
- Refund/cancellation statement: add one sentence in close proximity to the CTA stating terms plainly

### Step 6: Sequence tests using Kaizen Method prioritization

Output a ranked testing roadmap:
1. Structural changes first (nav removal, form field changes, layout shifts) — highest leverage
2. Trust signal repositioning second
3. Copy changes (CTA labels, micro-copy) third
4. Visual changes (badge size, color) last

Run 2-5 variations per test. Always include one "left field" structural variant.

## OUTPUT STRUCTURE

**Section 1: LIFT Drag Score Summary**
- Anxiety score: X/3 (overall), with top 3 sub-factors ranked
- Distraction score: competing element count + severity rating
- Combined drag suppression estimate: "This page is likely capturing X% of its value-prop ceiling"

**Section 2: Anxiety Audit Table**
Six-column max. Columns: Element | Location | Drag Type | Severity | Visitor Exposure | Priority

**Section 3: Distraction Map**
List of all competing elements with type, location, and removal/suppression recommendation.

**Section 4: Prioritized Hypothesis Queue**
Hypotheses in rank order. Each includes: element, current state, proposed state, expected mechanism, test type (A/B vs. DOE).

**Section 5: Left-Field Variation**
One structurally novel test variant that has not been tried on this page category. Include rationale.

**Section 6: Measurement Protocol**
Single macro conversion metric defined. Statistical significance requirement stated. DOE recommendation if traffic below 1M/month.

## WORKED MINI-EXAMPLE

**Page:** SaaS free trial landing page. URL: app.example.com/trial
**Desired action:** Submit email for free trial (no credit card required)

**Before (current state):**
- Header nav with 6 links (Home, Features, Pricing, Blog, About, Login)
- Form: First Name, Last Name, Email, Company, Phone (required), Company Size (dropdown)
- Trust badge (large, 200px wide) centered above the form headline: "Norton Secured"
- Footer with 12 links including social icons
- CTA button: "Submit"

**LIFT Drag Scores:**
- Anxiety: Phone required = 3, Norton badge size/placement = 2, "Submit" label = 2 → Priority 1: phone + badge
- Distraction: 6 nav links + 12 footer links + social icons = 19 competing elements → Severe drag

**After (proposed test variation A — structural):**
- Nav stripped to logo only
- Footer reduced to Privacy Policy and Terms (no links out)
- Form: First Name, Email only (phone removed, company size removed)
- Micro-copy under email field: "We never sell your data. Unsubscribe anytime."
- Trust badge repositioned: 80px, placed immediately below the CTA button
- CTA button: "Start My Free Trial"

**Hypothesis:** Removing 19 competing elements and the required phone field eliminates the two highest-severity drag sources. Visitors experience lower perceived commitment cost and fewer exit paths. Expected outcome: form completion rate increases by 15-40% (consistent with Goward's nav-removal case studies showing 10-50% lift).

**Left-field variant B:** Move form to left column, hero image/social proof to right column — a layout inversion rarely tested in SaaS trials. If it wins, it signals the current layout's visual hierarchy is misaligned with how visitors process the page.

## OUTPUT FILE

Save to: [project-folder]/Goward - Click Architecture/[YYYY-MM] - Anxiety-Distraction-Reducer.md
