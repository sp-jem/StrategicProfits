---
name: gigerenzer-risk-literacy-reframer
description: Use when a page uses percentage or relative-risk claims that visitors misread or discount — rewrites all probability framing as natural frequencies and structures proof hierarchy so Take-the-Best fires at the CTA
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Gerd Gigerenzer (Simple Heuristics That Make Us Smart, 1999; Natural Frequencies, 1995; Adaptive Toolbox) — Click Architecture (Skill 4 of 7)"
interface:
  invoke: "/gigerenzer-risk-literacy-reframer"
  calls: []
  called_by: [user, gigerenzer-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Conversion claims, testimonial counts, and risk statistics on a live page change with every campaign cycle; stale counts produce incorrect natural-frequency rewrites"

gigerenzer_take_the_best_integration:
  feeds_from: gigerenzer-take-the-best-sequencer
  feeds_to: gigerenzer-risk-literacy-reframer
  shared_data: "Validity-ranked cue list — Take-the-Best supplies the ordered cue set; this skill converts the top cue's proof claim into a natural-frequency statement placed first and alone above the fold"

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: gigerenzer-risk-literacy-reframer
  shared_data: "Loss vs. gain frame direction — Kahneman identifies whether the page should run prevention or promotion framing; this skill then expresses the chosen frame in natural-frequency format to maximize comprehension"

iyengar_integration:
  feeds_from: gigerenzer-risk-literacy-reframer
  feeds_to: iyengar-choice-set-auditor
  shared_data: "Option count audit — after frequency reframing collapses the proof hierarchy to one lead claim, Iyengar audits the remaining option set to confirm stopping-rule conditions are met before the CTA"
---

# Gigerenzer Risk Literacy Reframer

## LAYER 1: INVARIANTS (Never override.)

1. **Natural frequencies always replace percentages in visitor-facing claims.** No exception. A claim like "80% success rate" must become "8 of 10 customers achieved X" before the page ships.
2. **Relative risk is always accompanied by the absolute count.** "25% risk reduction" is incomplete; the output must state "reduces from 6 to 5 per 1,000" or equivalent. Reference class must be named explicitly.
3. **The single highest-validity cue (strongest proof point or recognition signal) runs first and alone.** Do not bury it in a list. The visitor's Take-the-Best heuristic fires on the first discriminating cue — diluting it with adjacent claims prevents the stopping rule from resolving at the CTA.
4. **Never improve comprehension by exploiting cognitive blindspots.** Per Gigerenzer's Boosting framework: interventions must be transparent and autonomy-preserving. Do not use frequency framing to manufacture false precision — only reformat what the data actually supports.
5. **Option count cap at the decision node.** The CTA section may not present more choices than the visitor needs to make one binary decision (act / not act). Fast-and-frugal tree logic: one discriminating question, one exit.
6. **Do not add proof claims that do not exist on the page.** This skill rewrites format and hierarchy; it does not fabricate statistics.
7. **Recognition signal must precede conversion ask.** If the visitor cannot recognize the brand or authority signal before the CTA, the Recognition Heuristic is unavailable to them. Reorder if needed.

## LAYER 2: QUALITY GUIDANCE

1. **Comprehension check threshold:** A rewritten frequency claim passes if a 6th-grader can answer "how many people is that?" without a calculator. If not, simplify the reference class (round to 10, 100, or 1,000 as appropriate).
2. **Less-Is-More discipline:** If the product is already the recognized option in its category, do not add feature detail after the recognition signal. Additional specs shift the visitor to analytical mode where unknown competitors can compete on numbers. Confirm recognized status before deciding whether to expand or compress detail.
3. **Stopping rule audit:** Walk the page top-to-bottom and mark the first node where a visitor with the page's typical prior knowledge would encounter a discriminating signal strong enough to act. If that node is not directly connected to the CTA, the page has a stopping-rule leak. Fix the information path.
4. **Boost, do not nudge:** Every frequency rewrite must be legible to the visitor as an honest count, not a rhetorical trick. If the rewrite makes a weak claim sound stronger than the underlying data supports, flag it for copy team — do not publish.
5. **Fast-and-frugal tree validation:** After restructuring, trace the page as a tree. Each branch node should ask one yes/no discriminating question. If any node requires the visitor to hold two or more conditional facts in working memory simultaneously, simplify.

## PURPOSE

This skill takes a real web page (URL, screenshot, or written description) plus one stated desired action and applies Gigerenzer's Natural Frequencies framework and Adaptive Toolbox logic to rewrite every probability and risk claim into comprehension-ready frequency formats — then restructures the proof hierarchy so the visitor's Take-the-Best heuristic stops at the CTA rather than continuing to search.

**The core mechanism:** Gigerenzer and Hoffrage (1995) demonstrated that natural frequency formats ("5 in 1,000") yield correct Bayesian inference in 24% of subjects vs. 4% for conditional probability formats ("0.5%") — an odds ratio of 7.1. On a conversion page, this gap means visitors who read "8 of 10 customers saw results" can actually evaluate the claim; visitors who read "80% success rate" mostly cannot. Comprehension is a prerequisite for action.

**Brag line:** "We design WITH the mental shortcuts instead of fighting them."

This skill operates exclusively in the lane of risk/evidence framing and proof hierarchy. It does not redesign layout (Fitts), optimize cue ordering across the full page (Take-the-Best Sequencer), or audit option set size (Iyengar). Hand off to siblings when those domains are triggered.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description of current copy and structure
- The ONE desired action (e.g., "click Buy Now," "submit opt-in form," "book call")

**Useful but optional:**
- Current conversion rate and traffic source
- Audience's prior familiarity with the product category (affects Less-Is-More decision)
- Funnel position (cold traffic vs. warm retargeting changes reference class sizing)
- Any A/B test data on existing claims

## EXECUTION PROCESS

**Step 1 — Inventory all probability and risk claims (5 min)**

Extract every claim on the page that uses:
- A percentage ("80% of users," "3x faster," "save 40%")
- A relative comparison without an absolute anchor ("twice as effective," "significantly reduces")
- A conditional probability ("if you have X, there is a 1-in-10 chance of Y")
- A vague frequency ("most customers," "rarely," "often")

List each claim in a table: Original Claim | Type (%, relative, vague) | Reference Class (known/unknown).

**Step 2 — Assign reference class and rewrite as natural frequency**

For each claim:
1. Identify the denominator (out of how many? users? trials? months?). If unstated, flag as "Reference class unknown — copy team must supply."
2. Convert to the most legible round denominator. Prefer 10, 100, or 1,000.
   - Formula: count = rate × denominator. Round to nearest integer.
   - "80% success rate" + reference class "customers in past 12 months" → "8 of 10 customers in the past year achieved X"
   - "25% risk reduction" (relative) → absolute rewrite requires baseline: if baseline is 8/1,000, rewrite as "reduces from 8 to 6 per 1,000" (not "25% reduction")
3. Verify the rewrite: can a visitor answer "how many people is that?" without calculation? If yes, pass. If no, simplify denominator further.

**Step 3 — Rank proof claims by validity (Take-the-Best prep)**

Score each proof claim on three criteria (1-5 each):
- **Specificity:** Is the claim tied to a named outcome, count, or timeframe? (vague = 1, precise = 5)
- **Source credibility:** Is the claim attributed to a recognized source, named customer, or third-party study? (anonymous = 1, recognized = 5)
- **Relevance to desired action:** Does this claim directly predict success on the ONE desired action? (tangential = 1, direct = 5)

Sum scores. Rank descending. The top-ranked claim is the lead cue.

Threshold: Any claim scoring below 6 total should not appear above the fold. Candidates below 4 should be cut or moved to FAQ.

**Step 4 — Audit recognition signal placement**

Identify all recognition signals on the page: brand name, media logos, partner logos, known customer names, award seals. Confirm at least one recognition signal is visible within the first scroll viewport AND appears before the first CTA button. If not, flag for repositioning. Without recognition, the Recognition Heuristic cannot function — the visitor has no shortcut to trust.

**Step 5 — Map the page as a fast-and-frugal tree**

Trace visitor path from landing to CTA. At each decision node, ask: what is the one discriminating question the visitor is answering here? Label each node. Check:
- Does each node ask only ONE question?
- Is there an action exit (CTA) available within two nodes of the first discriminating signal?
- Does the highest-validity claim (Step 3 output) appear at the first node?

If any node requires the visitor to hold two or more facts simultaneously, mark it as a stopping-rule leak. Propose a split (move secondary facts to a later node or FAQ).

**Step 6 — Check Less-Is-More applicability**

Is this product/brand the recognized option in its comparison set for the target visitor? If YES: do not add feature detail after the recognition signal. Additional specs activate analytical mode where unrecognized competitors can compete on specifics. Recommend trimming detail after the recognition node.

If NO (unknown brand): recognition must be built before conversion is attempted. Flag for recognition-building elements (social proof, media mentions, known customer names) to be added above the fold.

**Step 7 — Compile rewrite package**

Deliver: (a) full table of original vs. rewritten claims, (b) recommended proof hierarchy (ordered cue list), (c) fast-and-frugal tree diagram (text-based), (d) recognition signal placement recommendation, (e) option-count audit at CTA node.

## OUTPUT STRUCTURE

### 1. Claims Inventory
Table: Original | Type | Reference Class | Rewritten (Natural Freq) | Pass/Flag

### 2. Validity-Ranked Proof Hierarchy
Split into two tables to keep each within 5 columns.

Scores table: Rank | Claim (rewritten) | Spec | Cred | Rel | Total
Placement table: Rank | Claim (rewritten) | Total | Placement Rec

Legend: Spec = Specificity (1-5), Cred = Source Credibility (1-5), Rel = Relevance to desired action (1-5), Total = sum (max 15), Placement Rec = above fold / below fold / cut

### 3. Fast-and-Frugal Tree
Text diagram of page decision path. Each node labeled. Stopping-rule leaks marked.

### 4. Recognition Audit
Status (signal present / absent / misplaced) + specific repositioning instruction if needed.

### 5. Less-Is-More Ruling
Recognized vs. unrecognized assessment + detail trim or recognition-build recommendation.

### 6. Priority Change List
Ordered list of changes by expected comprehension-to-action impact, highest first. Each item: what to change, where on page, what the natural-frequency rewrite is.

### 7. Stopping-Rule Leak Log
Any nodes requiring multi-fact simultaneous processing + proposed resolution.

## WORKED MINI-EXAMPLE

**Page:** SaaS landing page for a forecasting tool. Desired action: start free trial.

**Before (current copy above the fold):**
- Headline: "Improve forecast accuracy by up to 40%"
- Sub: "Over 500 companies trust our platform"
- Social proof block: logos of 12 partner brands (small, mid-page)
- CTA: "Start Free Trial" (below three feature columns)

**After (Gigerenzer reframe):**

Step 2 rewrite:
- "40% improvement" — reference class unknown. Flag. If data exists: "Teams using our tool corrected 4 of 10 forecast errors that manual methods missed."
- "500 companies" already a natural frequency — keep, move earlier.

Step 3 validity rank (sample):
- "Corrected 4 of 10 forecast errors" — Specificity 4, Cred 3 (needs source), Rel 5 = 12
- "500 companies trust" — Specificity 3, Cred 4 (verifiable count), Rel 4 = 11
- Feature column claims — all score <7, move below fold

Step 4 recognition audit: 12 partner logos present but placed mid-page. Move top-3 most recognized logos to first viewport, above the feature columns, before CTA.

Fast-and-frugal tree: Node 1 = "Can I trust this?" (recognition signal) → YES: Node 2 = "Does it solve my specific error problem?" (lead claim) → YES: Exit = CTA. Current page inserts a 3-column feature comparison between Node 1 and the CTA, creating a stopping-rule leak. Recommendation: collapse feature columns to one sentence each, or move to accordion below the CTA.

**Net result:** Visitor reaches CTA after two discriminating nodes instead of five. Top proof claim is in natural-frequency format, comprehensible without calculation. Recognition signal precedes ask.

## OUTPUT FILE

Save to: [project-folder]/Gigerenzer - Click Architecture/[YYYY-MM] - Risk Literacy Reframe.md
