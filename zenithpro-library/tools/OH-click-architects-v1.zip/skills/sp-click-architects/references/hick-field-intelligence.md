---
name: hick-field-intelligence
description: Use when you have run 4 or more individual Hick-Hyman skills on the same page and need to synthesize convergence zones, resolve contradictions, identify the single highest-leverage intervention, and integrate decision-entropy findings with the broader Click Architects network (Fitts, Pirolli, Laja, Eisenberg, Fogg, Thaler, Iyengar, and others).
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "William Hick & Ray Hyman (Hick-Hyman Law, 1952-1953; Shannon Entropy Extension; Wifall et al. S-R Uncertainty Split, 2015) — Field Intelligence (Skill 7 of 7)"
interface:
  invoke: "/hick-field-intelligence"
  calls: [hick-decision-load-calculator, hick-option-pruning-auditor, hick-categorization-architect, hick-progressive-disclosure-designer, hick-single-decision-enforcer, hick-default-path-designer]
  called_by: [user, click-architects]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Offer structures, navigation counts, and CTA layouts change with every redesign cycle. Entropy scores calibrated to a previous page version misfire on current pages. Reassess after any layout or offer change, and quarterly at minimum."
fitts_integration:
  feeds_from: [fitts-field-intelligence]
  feeds_to: [fitts-target-cost-auditor]
  shared_data: "Fitts quantifies motor cost (time-to-click = log((2D/W)+1)). Hick quantifies cognitive cost (RT = a + b×log₂(n+1)). Combined: total click cost = cognitive decision latency + motor acquisition latency. A page may have a large, easy-to-click button (low Fitts cost) but five competing CTAs (high Hick cost) — and the decision delay exceeds the motor gain. The synthesis reveals the true total cost of a conversion action and where the bottleneck lives: in the hand or the mind."
pirolli_integration:
  feeds_from: [pirolli-field-intelligence]
  feeds_to: [pirolli-scent-trail-auditor]
  shared_data: "Pirolli maps information scent — the perceived value of following a link vs. abandoning. Hick maps decision latency when multiple scent trails compete. Combined: a page with strong scent but three competing links of equal salience creates an entropy spike that delays the foraging decision. Reducing competing scent sources is not just a Hick intervention — it is a scent clarity intervention. The synthesis identifies pages where scent is present but bifurcated, and collapsing n from 3 to 1 both reduces Hick RT and concentrates scent signal."
eisenberg_integration:
  feeds_from: [eisenberg-field-intelligence]
  feeds_to: [eisenberg-conversion-trinity-builder]
  shared_data: "Eisenberg's conversion trinity (relevance × value × call to action) requires the CTA to be unambiguous. Hick's Law shows that ambiguity in action options is entropic — multiple CTAs of equal visual weight create measurable processing delay. Combined: the Eisenberg CTA requirement and the Hick single-response requirement are the same intervention seen from different frames. When Eisenberg flags a weak CTA, Hick explains WHY it is weak: response uncertainty (the dominant coefficient) is elevated. Fix: one dominant CTA eliminates entropy and satisfies the conversion trinity simultaneously."
kohavi_integration:
  feeds_from: []
  feeds_to: []
  shared_data: "Kohavi's A/B testing framework turns Hick's theoretical predictions into measured revenue impact. The formula RT = a + b×log₂(n+1) generates a directional hypothesis; Kohavi's controlled experiment confirms or refutes it with statistical confidence. Combined: Hick identifies WHICH n-reduction to test and predicts the direction of effect. Kohavi determines whether the magnitude is real and worth shipping. This pairing prevents both over-pruning (removing options that users needed) and under-pruning (leaving entropy on the table because nobody tested). Every Hick recommendation is, at bottom, a Kohavi test spec."
laja_integration:
  feeds_from: [laja-field-intelligence]
  feeds_to: [laja-friction-telemetry-reader]
  shared_data: "Laja's ResearchXL framework isolates friction sources through heuristic walkthrough, session recording, and qualitative interviews. Hick's Law provides the quantitative mechanism behind one class of friction: decision entropy. Combined: when Laja's friction map surfaces 'choice paralysis' or 'users hesitate at the CTA section,' Hick provides the mathematical model explaining why and the specific intervention (reduce n, establish visual hierarchy, pre-select a default). Laja finds the friction; Hick proves the mechanism and sizes the fix."
norman_integration:
  feeds_from: [norman-field-intelligence]
  feeds_to: [norman-affordance-signifier-auditor]
  shared_data: "Norman's affordance-signifier model determines whether a user knows a control is clickable. Hick's Law determines how long they take to pick which control to click. Combined: perfect Norman affordance (every CTA is obviously clickable) with high Hick entropy (six equally-obvious CTAs) still produces decision paralysis. The synthesis reveals pages where Norman compliance is high but Hick entropy is also high — the fix is not better signifiers but fewer response options. Conversely, bad affordances inflate perceived n because users cannot tell which elements are actionable, artificially raising entropy."
nielsen_integration:
  feeds_from: []
  feeds_to: []
  shared_data: "Nielsen's usability heuristics include 'recognition over recall' and 'user control and freedom,' both of which interact with Hick. Recognition-based interfaces reduce the cognitive load of each option (lower b coefficient); freedom/escape links add navigation n (raise entropy). Combined: the Nielsen 5-7 navigation heuristic is Hick-derived — it is not arbitrary but maps to the inflection point where log₂(n+1) begins accelerating steeply. The synthesis provides the mathematical grounding for Nielsen usability violations that involve option overload."
eyal_integration:
  feeds_from: [eyal-field-intelligence]
  feeds_to: [eyal-hook-loop-designer]
  shared_data: "Eyal's Hook Model requires a trigger → action → reward → investment loop. The action step is where Hick fires: high n at the action stage breaks the hook loop before reward delivery. Combined: Hick's single-response rule is not a conversion principle alone — it is a habit-loop preservation principle. When the desired action is part of a recurring hook sequence, keeping n=1 at each action stage protects loop integrity across sessions. Eyal identifies which actions must be protected; Hick quantifies the entropy cost if they are not."
brignull_integration:
  feeds_from: [brignull-field-intelligence]
  feeds_to: [brignull-dark-pattern-scanner]
  shared_data: "Brignull's dark patterns include 'roach motel' (easy in, hard out), 'confirmshaming,' and 'misdirection' — all of which manipulate Hick dynamics. Misdirection artificially raises n for the escape action while lowering n for the desired (manipulative) action. Combined: Hick is the mechanism underlying many dark patterns. The synthesis distinguishes legitimate entropy reduction (removing genuinely irrelevant options) from dark-pattern entropy manipulation (selectively raising n for options the user should have access to). Hick intelligence without Brignull awareness produces designs that are optimized but unethical."
fogg_integration:
  feeds_from: [fogg-field-intelligence]
  feeds_to: [fogg-ability-auditor]
  shared_data: "Fogg's B=MAP model places ability as a co-equal lever alongside motivation and prompt. Hick's response uncertainty is the cognitive component of ability — it reduces the simplicity score of ANY action surrounded by competing options. Combined: when Fogg's Ability Auditor flags cognitive load as the bottleneck, Hick's Law specifies the mechanism (entropy from n options) and the remedy (reduce n to lower RT and raise ability). The synthesis: Hick is the precision instrument for the cognitive-load dimension of Fogg's ability axis."
cialdini_integration:
  feeds_from: [cialdini-field-intelligence]
  feeds_to: [cialdini-pre-suasion-strategist]
  shared_data: "Cialdini's pre-suasion principle: attention directed at an object increases its perceived importance and probability of choice. Hick's entropy formula shows WHY pre-suasion works mechanically: pre-directing attention to one option elevates its p(i), which lowers H = -Σp(i)×log₂p(i), which reduces RT for that option. Combined: Cialdini pre-suasion is an entropy-reduction technique operating through probability weighting. Every Cialdini attention-direction tactic has a Hick-measurable effect: it changes the probability distribution across options and reduces total decision entropy."
kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: [kahneman-framing-engineer]
  shared_data: "Kahneman's System 1 / System 2 model predicts that high-entropy decision environments force System 2 (slow, deliberate, effortful) engagement. Hick quantifies the threshold: as n rises above 7, log₂(n+1) begins accelerating, and the processing demand exceeds System 1 capacity. Combined: Hick's Law is the mathematical operationalization of System 1 overload. Keeping n ≤ 3 at conversion points preserves System 1 processing for the desired action. Exceeding n=7 guarantees System 2 engagement — slower, more skeptical, more likely to abandon. The synthesis: Hick thresholds ARE System 1/2 thresholds with numbers attached."
thaler_integration:
  feeds_from: [thaler-field-intelligence]
  feeds_to: [thaler-default-detector]
  shared_data: "Thaler's default effect: pre-set choices are accepted at dramatically higher rates than equivalent opt-in choices, because the cognitive cost of changing a default is perceived as a loss. Hick's response uncertainty for a default field = 0: no decision required. Combined: Thaler defaults eliminate Hick entropy at the field level — they are the most powerful single-point entropy reduction available. Every checkout field with a smart default is a zero-entropy input. The synthesis: Thaler default design IS Hick optimization taken to its logical extreme — the desired response requires no decision at all."
iyengar_integration:
  feeds_from: [iyengar-field-intelligence]
  feeds_to: [iyengar-choice-set-auditor]
  shared_data: "Iyengar's jam study established the empirical baseline: 24 options → 3% purchase; 6 options → 30% purchase. This is Hick's Law rendered in revenue terms. Iyengar identifies the behavioral outcome (choice paralysis, deferral, non-purchase); Hick provides the mechanistic formula that predicts the threshold at which it occurs. Combined: Iyengar's research calibrates the Goldilocks bounds (≤6 for product catalogs, ≤3 for pricing tiers) that Hick's formula predicts — the synthesis turns theoretical thresholds into empirically-validated design rules."
---

# Hick-Hyman Field Intelligence

---

## LAYER 1: INVARIANTS (Never override.)

1. **Field Intelligence is synthesis, not summary.** This skill does NOT recap what individual Hick skills found. It identifies PATTERNS ACROSS skills — convergence zones, contradictions, amplification opportunities, and the single highest-leverage intervention. If the output reads like a summary of six reports, it has failed.

2. **Convergence detection is mandatory.** When 3+ individual Hick-Hyman skills point at the same intervention or entropy source: that is a convergence zone. Every convergence zone must be explicitly identified and named.

3. **Contradictions must be surfaced, not hidden.** When one skill recommends removing options and another recommends progressive disclosure of those same options: this is signal, not noise. Resolve by specifying which mechanism dominates at which page stage.

4. **The Single Move is non-negotiable.** Every Field Intelligence briefing must produce exactly ONE recommended action — the highest-leverage page change. Not options. Not a list. ONE move with a predicted conversion impact.

5. **The Mirror is non-negotiable.** The business's own design biases must be examined. Where is the team adding options to demonstrate value? Where is the product roadmap adding choices that reduce conversions?

6. **Cross-system intelligence is the highest-value section.** Hick's Law intersects with motor cost (Fitts), information scent (Pirolli), friction telemetry (Laja), persuasion architecture (Eisenberg), defaults (Thaler), choice overload (Iyengar), dark patterns (Brignull), and testing (Kohavi). That intersection is where the most powerful and least obvious insights live.

7. **Freshness gate: 45 days.** Flag any individual Hick skill output older than 45 days as potentially stale. A page redesign invalidates all prior entropy scores immediately.

---

## LAYER 2: QUALITY GUIDANCE

8. **Name every convergence zone.** Give each pattern a memorable label that captures the intervention (e.g., "The Entropy Wall" for convergence around a navigation section, "The Response Fog" for convergence around equal-weight CTAs).

9. **Quantify with the formula.** Where n is known, compute RT = a + b×log₂(n+1) using b=0.155s. Compare before vs. after n-reduction. Attach a decision-latency delta and an estimated conversion impact.

10. **The 90-Day Projection must be specific.** Not "things should improve." Instead: "If The Single Move is implemented in week 1, by day 30 checkout completion should shift from X% to Y%."

---

## PURPOSE

Individual Hick-Hyman skills each diagnose one dimension of on-page decision entropy. The Decision Load Calculator computes RT across all choice points. The Option Pruning Auditor identifies which options to cut. The Categorization Architect reduces effective n through chunking. The Progressive Disclosure Designer stages option revelation by decision phase. The Single Decision Enforcer locks conversion zones to one primary action. The Default Path Designer eliminates entropy at the field level.

Field Intelligence goes one level beyond. It finds convergence zones across all six analyses, detects contradictions that reveal competing page dynamics, identifies amplification opportunities where combined interventions create outsized impact, delivers The Single Move, holds up The Mirror to the business itself, and integrates Hick-Hyman intelligence with the complete Click Architects network. The result is not just an entropy reduction plan — it is decision-latency intelligence situated within the full understanding of motor cost, information foraging, persuasion architecture, behavioral design, and choice science.

**The brag:** "We cut decision time by removing options, and we can prove the math."

---

## INPUT REQUIREMENTS

**Required:**
- Page URL, screenshot, or written description (same page across all skills)
- Stated desired action (click / opt-in / purchase / next-step)
- Outputs from at least 4 of 6 individual Hick-Hyman skills

**Optimal:**
- All 6 individual Hick-Hyman skill outputs
- Field Intelligence outputs from: fitts, pirolli, eisenberg, laja, norman, fogg, cialdini, kahneman, thaler, iyengar, brignull, kohavi
- Session recording or heatmap data showing hesitation patterns
- Current baseline conversion rate and time-to-click metrics

---

## EXECUTION PROCESS

### Step 1: Component Synthesis

For each available Hick-Hyman skill output:
- **Skill name and date run**
- **Freshness:** Current (≤45 days) / Aging (45-60 days) / Stale (>60 days)
- **Key findings:** Top 3 entropy sources identified
- **Recommendations made:** Specific n-reduction or disclosure actions
- **Confidence level:** Based on whether n was measured or estimated

### Step 2: Convergence Detection

Cross-skill pattern matching:

**Convergence scoring:**
- 2 skills: Notable alignment
- 3 skills: Convergence zone — name it
- 4 skills: Strong convergence
- 5-6 skills: Critical convergence — this is where The Single Move lives

**For each convergence zone:**
- **Name:** Memorable label capturing the entropy pattern
- **Contributing skills:** Which analyses point here
- **Entropy calculation:** Current n → current RT → proposed n → projected RT → delta in milliseconds
- **Conversion implication:** Estimated lift based on benchmark data
- **Implied intervention:** The specific n-reduction or disclosure change

**Common Hick convergence patterns to watch for:**
- Multiple skills flag the same navigation section as overloaded (>7 items)
- Single Decision Enforcer + Option Pruning Auditor both flag the same CTA zone
- Progressive Disclosure Designer + Categorization Architect both propose restructuring the same product listing
- Decision Load Calculator finds peak entropy at the same page section that Default Path Designer has not yet addressed
- All six skills flag the checkout or pricing page as the primary entropy source

### Step 3: Contradiction Detection

Cross-skill conflict identification:

**Common Hick-Hyman contradiction patterns:**
- Option Pruning Auditor recommends removing plan tier C → Categorization Architect needs tier C to complete the chunking structure
- Progressive Disclosure Designer hides spec table → Single Decision Enforcer needs spec comparison to justify the one recommended option
- Default Path Designer pre-selects annual → Option Pruning Auditor recommends removing monthly entirely (users still want to see it)
- Decision Load Calculator finds peak entropy in nav → Categorization Architect's chunked solution adds a level of nav depth

**For each contradiction:**
- The tension: what each skill recommends and why
- Resolution: which mechanism dominates at this specific decision stage
- Implementation that honors both insights

### Step 4: Amplification Opportunities

Where combining interventions creates outsized impact:

- **Hyman Entropy + Visual Hierarchy:** Pre-select the recommended option (Hyman probability weighting) AND visually badge it "Most Popular" (Cialdini social proof) AND remove the bottom tier (Option Pruning) = p(i) of the desired option dominates the entropy sum from three directions simultaneously
- **Default Path + Fitts Motor Optimization:** Zero-entropy default fields AND large, well-placed CTA button = Hick response uncertainty = 0 AND Fitts motor cost minimized — the two largest components of total click cost addressed in one pass
- **Progressive Disclosure + Pirolli Scent:** Reveal options progressively AND ensure each revealed level has stronger scent signal than the previous = entropy stays low AND information value density rises — users are faster AND more confident at each stage
- **Single CTA + Kohavi Test:** Lock conversion zone to one CTA AND A/B test the specific CTA text/color — Hick removes the decision between CTAs, Kohavi optimizes the single remaining choice
- **Chunked Nav + Norman Affordances:** Chunked nav (Hick) with clear signifiers on each chunk parent (Norman) — users know where to look AND know the chunk is clickable

### Step 5: The Single Move

ONE recommendation addressing the most convergence zones:

- **What to do:** The specific change (page element, option count, default setting, disclosure gate)
- **Why this is THE move:** Which convergence zones it addresses simultaneously
- **How it works in Hick-Hyman terms:** Which element of RT = a + b×log₂(n+1) it changes, and by how much
  - State current n, current RT estimate, proposed n, projected RT, delta in ms
  - Map RT delta to estimated conversion lift using benchmark: each additional CTA above 1 costs ~1.6% conversion
- **Implementation steps:** Specific, sequential, no ambiguity
- **Expected outcome:** Metric change predicted with timeframe
- **What it does NOT address:** Honest about limitations

**Worked example (pricing page, 4 tiers → 3 tiers with "Recommended" badge):**
- Before: n=4, RT = 0.200 + 0.155×log₂(5) = 0.200 + 0.360 = 0.560s decision latency
- After: n=3 with one pre-selected, effective p(recommended)=0.65, H = -(0.65×log₂0.65 + 0.175×log₂0.175 + 0.175×log₂0.175) ≈ 1.31 bits vs. 2.00 bits flat; RT ≈ 0.200 + 0.155×1.31 = 0.403s
- Delta: -0.157s decision latency (-28%), aligned with HubSpot's reported 35% lift from 4→3 tiers

### Step 6: The Mirror

Where the business's own design biases operate:

- **Option inflation as value demonstration:** Team adds plan features, nav links, and product variants to SHOW value, without recognizing each addition raises n and raises RT. The customer interprets "more options" as confusion, not abundance.
- **Designer's log-blindness:** The team thinks option 8 and option 2 feel equally different because they ARE different. Hick shows the cognitive cost of option 8 is log₂(9)=3.17 bits vs. log₂(3)=1.58 bits — option 8 costs twice the cognitive processing of option 2, invisible to the team.
- **CTA proliferation as hedging:** Adding a secondary CTA ("or learn more") is treated as reducing commitment pressure. It actually raises response uncertainty, which is the dominant coefficient in the Hick-Hyman equation, costing more conversion than it saves in objection reduction.
- **Progressive disclosure deferred indefinitely:** Features that SHOULD be hidden behind a disclosure gate remain on the primary view because the product team is proud of them. Pride overrides entropy management.
- **No measurement of time-to-click:** The team tracks conversion rate but not decision latency. Hick's Law operates on time before the click; if time-to-click is not in the analytics stack, entropy problems are invisible until they show up as drop-off.

### Step 7: Cross-System Intelligence

**Hick × Fitts — Total Click Cost Model:**
Total click cost = RT(decision) + MT(motor). Fitts tells you if the button is hard to aim at. Hick tells you if the decision to click it is hard to reach. Diagnose both before recommending any CTA change. A small, mis-placed button with one option still beats a large, perfectly-placed button among five competitors.

**Hick × Pirolli — Scent Bifurcation Tax:**
Multiple links of equal scent value create Hick entropy on top of foraging cost. Reduce n OR differentiate scent strength. A 3:1 scent-strength differential between the primary link and secondary links changes the probability distribution enough to cut H by ~0.8 bits, reducing RT by ~0.12s without removing any options.

**Hick × Eisenberg — Conversion Trinity Lock:**
Eisenberg's CTA must be relevant, valuable, and singular. Hick proves the "singular" requirement is not a style preference — it is a response-uncertainty mandate. Every Eisenberg CTA audit that finds multiple competing actions is a Hick audit finding an entropy spike. Fix both with one move.

**Hick × Kohavi — Hypothesis-First Testing:**
Never test "fewer options vs. more options" without a Hick prediction attached. State n_control, n_treatment, predicted RT delta, predicted conversion delta. A Kohavi test run without a Hick hypothesis is a black-box experiment. A Kohavi test run WITH a Hick hypothesis is a mechanism-confirming experiment that generates learning, not just a result.

**Hick × Laja — Friction Source Classification:**
Laja's friction taxonomy (FUD: fear, uncertainty, doubt) maps onto Hick's response uncertainty. Uncertainty (U) is mechanically produced by high n. When Laja session recordings show hesitation at a multi-CTA zone, Hick tells you the hesitation is not emotional — it is entropic. The fix is not copy (removing fear/doubt language); the fix is n-reduction.

**Hick × Norman — Affordance vs. Entropy:**
Norman ensures controls are recognizable. Hick ensures there are few enough controls to decide between. Both are necessary; neither is sufficient alone. A Norman-perfect page with 12 affordances still has Hick entropy. An n=1 page with no affordances still fails to convert. Sequence: Norman first (can users find the action?), then Hick (can users decide on the action without delay?).

**Hick × Eyal — Hook Loop Preservation:**
Eyal's habit loop requires a frictionless action step. Hick's entropy at the action step IS the friction that breaks the loop. For recurring-use products, protect n=1 at every habitual action step not just at conversion — habit formation depends on consistent, low-latency action execution.

**Hick × Brignull — Ethical Entropy Management:**
Brignull flags designs that manipulate Hick dynamics (artificially raising n for escape paths, artificially lowering n for upsell paths). The rule: Hick optimization is legitimate when it reduces entropy for the user's STATED desired action. It is a dark pattern when it reduces entropy for a business-desired action that conflicts with user intent. Always audit against Brignull after applying Hick.

**Hick × Fogg — Ability Axis Precision:**
Fogg's ability axis has six simplicity factors; cognitive load is one. Hick's Law specifies the cognitive-load factor as RT = a + b×log₂(n+1), where b=0.155s. This makes ability quantifiable at the cognitive-load dimension. When Fogg says "ability is the bottleneck," Hick tells you exactly how many bits of entropy are consuming it and what n-reduction would clear it.

**Hick × Cialdini — Entropy-Adjusted Pre-Suasion:**
Cialdini pre-suasion elevates one option's p(i) through attention direction. Hick's Hyman entropy formula shows this is mechanically equivalent to reducing effective n: H drops when one p(i) dominates. Combine: direct attention to the desired option (Cialdini) AND remove competing options (Hick pruning) for a double entropy reduction — attention shifts the probability distribution AND n-reduction narrows it.

**Hick × Kahneman — System 1 Threshold Map:**
n ≤ 3: System 1 handles it. n = 4-7: System 1/2 boundary, conversion vulnerable. n > 7: System 2 dominant, deliberation mode, highest drop-off risk. Kahneman's framework provides the behavioral prediction; Hick provides the exact n boundaries. Together they define the three conversion risk zones for every decision point on the page.

**Hick × Thaler — Zero-Entropy Defaults:**
Thaler's default effect = Hick response uncertainty = 0 for that field. The highest-leverage Hick intervention is not reducing n from 5 to 3 — it is reducing n from 1 to 0 through a smart default. Every form field that can be pre-filled should be. Every pricing tier that can be pre-selected should be. Zero-entropy defaults are the most powerful single-point Hick optimization available.

**Hick × Iyengar — Goldilocks Calibration:**
Iyengar's jam study proves the behavioral consequence; Hick's formula explains the mechanism. The Goldilocks bounds (≤3 for pricing, ≤6 for catalog, 5-7 for navigation) are not arbitrary — they are the n values at which log₂(n+1) remains in the System 1 range and decision satisfaction stays positive. Below 3 options: perceived constraint. Above 6: entropy acceleration. The Hick-Iyengar combined model gives both the formula AND the behavioral validation.

**Cross-system convergence — highest-confidence findings:**
When Fitts + Hick + Fogg all flag the same page zone (motor cost, decision entropy, AND low ability), that zone is the primary conversion lever. Fix it first. When Kohavi testing is available, a Hick-Iyengar combined hypothesis (n-reduction + pre-selection + visual hierarchy) is the highest-expected-value test in any conversion optimization program.

### Step 8: Coherence Map

Score the overall entropy management coherence:

| Dimension | Score (1-10) | Notes |
|-----------|--------------|-------|
| Internal coherence | — | Do all 6 Hick skills recommend compatible n-reductions? |
| Cross-system coherence | — | Does entropy reduction align with Fitts, Fogg, Thaler insights? |
| Implementation coherence | — | Is there a non-conflicting path to the target page state? |
| Resilience | — | Will n stay low after the next product roadmap addition? |

Legend: Internal = no contradictions across 6 skills; Cross = compatible with other Click Architects findings; Impl = clear execution sequence; Resilience = entropy won't creep back without a governance rule.

**Coherence gaps:** Identify the dimension with the lowest score and specify what would raise it.

### Step 9: 90-Day Conversion Projection

**Days 1-30:**
- Implement The Single Move
- Instrument time-to-first-click in session recording tool
- Baseline: current conversion rate + current median time-to-click at the target zone
- Expected signal by day 15: time-to-click reduction visible in heatmap; conversion movement may not yet be statistically significant

**Days 31-60:**
- If The Single Move confirmed: run Kohavi-spec A/B test on the next-highest entropy zone
- If The Single Move inconclusive: re-examine n measurement — was effective n calculated using Hyman entropy (probability-weighted) or flat n? Flat n underestimates if options have unequal visual weight.
- Expected metric range: 8-35% conversion lift on target action depending on starting entropy level

**Days 61-90:**
- Full entropy map reflects post-intervention state
- Identify entropy creep: new options added since day 1 that were not present in original audit
- Establish governance rule: no new CTA or option added to conversion zones without an entropy impact assessment
- Predicted next bottleneck: if decision entropy has been addressed, the next bottleneck is typically motor cost (Fitts) or ability at a different page stage (Fogg). Trigger the relevant field-intelligence skill.

---

## OUTPUT STRUCTURE

**Section 1: Input Status and Freshness**
All Hick-Hyman skill outputs with freshness assessment and confidence level.

**Section 2: Convergence Map**
Named convergence zones with contributing skills, entropy calculations (before/after n), and implied interventions.

**Section 3: Contradiction Analysis**
Resolved tensions between competing recommendations with stage-specific resolutions.

**Section 4: Amplification Opportunities**
Combined interventions that create outsized impact, with mechanism explanation.

**Section 5: The Single Move**
One highest-leverage action with RT calculation, implementation steps, and predicted conversion outcome.

**Section 6: The Mirror**
Business's own entropy-generation biases examined with specific behavioral patterns named.

**Section 7: Cross-System Intelligence**
Interactions with Fitts, Pirolli, Eisenberg, Kohavi, Laja, Norman, Eyal, Brignull, Fogg, Cialdini, Kahneman, Thaler, and Iyengar — with the specific insight that emerges from each pairing.

**Section 8: Coherence Map**
Four-dimension scored assessment; lowest-scoring dimension gets a specific improvement recommendation.

**Section 9: 90-Day Conversion Projection**
Specific predictions by day 30 / 60 / 90 with decision points and next-bottleneck identification.

---

## OUTPUT FILE

Save complete briefing to:
`[project-folder]/Hick-Hyman - Field Intelligence/[YYYY-MM] - Decision Entropy Intelligence Briefing.md`
