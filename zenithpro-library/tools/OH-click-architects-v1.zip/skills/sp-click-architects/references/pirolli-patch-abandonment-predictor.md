---
name: pirolli-patch-abandonment-predictor
description: Use when a page is built but not yet launched, or when analytics show unexpected drop-off — identifies every point where scent decays below the foraging threshold and predicts bail before users arrive.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peter Pirolli & Stuart Card (Information Foraging Theory 1999; SNIF-ACT 2007; Marginal Value Theorem applied to web pages) — Click Architecture (Skill 2 of 7)"
interface:
  invoke: "/pirolli-patch-abandonment-predictor"
  calls: []
  called_by: [user, pirolli-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic source vocabulary shifts with ad copy changes, SEO rank drift, and seasonal intent — scent-goal congruence analysis expires when the upstream trigger changes."

pirolli_scent_trail_auditor_integration:
  feeds_from: [pirolli-scent-trail-auditor]
  feeds_to: []
  shared_data: "Scent-trail auditor scores the whole page; abandonment predictor uses those scores to locate the specific fold or element where gain rate drops below the exit threshold. Run auditor first to generate per-element scent scores, then run this skill to sequence them into a decay curve and flag the bail point."

kahneman_integration:
  feeds_from: [kahneman-peak-end-architect]
  feeds_to: []
  shared_data: "Kahneman's Peak-End Rule governs what users remember about the patch experience. Feed abandonment-predictor bail-point data into kahneman-peak-end-architect to ensure the final impression before predicted exit is a peak moment, not a trough — converts exits into positive memory traces that drive return visits."

fogg_integration:
  feeds_from: []
  feeds_to: [fogg-ability-auditor]
  shared_data: "Within-patch cost (reading load, scroll depth, cognitive friction) is the primary driver of early bail. Abandonment-predictor flags high-cost zones; fogg-ability-auditor converts those flags into specific ability-reduction fixes (word count, layout, progressive disclosure)."

thaler_integration:
  feeds_from: [thaler-mental-accounting]
  feeds_to: []
  shared_data: "Users mentally budget attention-time per patch before arriving. Thaler's mental accounting predicts when the perceived time-cost of remaining on the page exceeds the pre-allocated budget. Use remaining-budget estimates from thaler-mental-accounting to calibrate how aggressive within-patch cost cuts need to be at each fold."
---

# Pirolli — Patch Abandonment Predictor

## LAYER 1: INVARIANTS (Never override.)

1. **Exit is a gain-rate decision, not a dissatisfaction decision.** Users do not leave because the page is bad — they leave the moment the expected gain rate from staying drops to what they could get elsewhere. Diagnosis must compute rate, not just quality.
2. **The Marginal Value Theorem sets the threshold.** A user abandons this patch when within-patch gain rate = environmental average gain rate. As between-patch travel cost decreases (fast search, mobile back-button), the threshold rises. Pages must deliver value faster than they used to.
3. **Every scroll is a new foraging decision.** Each fold presents new proximal cues. The user re-evaluates "stay vs. leave" at each new content block. A single scent decay event mid-page is sufficient to trigger bail — strong opens do not inoculate against weak middles.
4. **Proximal cue vocabulary is the scent carrier.** Link text, headlines, subheads, image subjects, button labels, and surrounding paragraph text are the only signal the user has about distal value. Any element that fails to carry the user's trigger-word vocabulary contributes zero scent and is a bail-risk node.
5. **Within-patch cost is the primary lever.** Once the user is on the page, between-patch costs are fixed. The only live variable is within-patch cost. Dense text, decorative images, vague headers, and cognitive overload are cost inflators — each one moves the gain-rate calculation toward exit.
6. **Scent decay is cumulative and directional.** Users track a running expectation. A sequence of three weak-scent elements in a row compounds — the decay is not linear. Model it as a decay curve, not a sum.
7. **The bail point is predictable pre-launch.** SNIF-ACT demonstrates that link activation scores (derived from semantic overlap between cues and goal vocabulary) predict navigation behavior with high accuracy. A pre-launch audit using this model identifies bail points before any user touches the page.

## LAYER 2: QUALITY GUIDANCE

1. **Work from the actual traffic source.** The user's goal vocabulary is set by whatever brought them here — ad copy, email subject, search query, social post. Map that vocabulary first. Scent is only measurable relative to that entry trigger.
2. **Score elements in reading order.** Users experience the page sequentially. Do not assess elements in isolation. Score each block as a continuation of the running scent level, not in a vacuum.
3. **Threshold is context-dependent.** Environmental average gain rate is higher for competitive commercial queries (many alternatives) than for long-tail informational queries (fewer alternatives). Calibrate the exit threshold accordingly.
4. **Flag bail-point clusters, not just individual weak elements.** Three consecutive weak elements are far more dangerous than any single weak element. Report clusters.
5. **Distinguish recoverable decay from terminal decay.** Some mid-page scent dips can be recovered by a strong subsequent element. Terminal decay occurs when a high-friction element (captcha, confusing form, off-topic section) forces a cognitive reset — after which most users do not re-engage regardless of what follows.

## PURPOSE

Pirolli and Card showed that users treat every web page as a food patch: they arrive with a goal-derived vocabulary (their "trigger words"), they estimate value from proximal cues on the page, and they leave the moment the expected gain rate falls to what they could get by clicking away. This skill operationalizes that model as a pre-launch audit tool — it walks the page element by element, scores the running scent level against the user's entry vocabulary, locates the fold where gain rate crosses the exit threshold, and delivers specific fix instructions before the page ships.

**Brag-line:** "We can predict which links leak visitors before we ship the page."

This is Skill 2 of 7 in the pirolli-* cluster (G2: Information Scent & Foraging).

## INPUT REQUIREMENTS

**Required:**
- The page — URL (live or staging), screenshot sequence, or written description with all visible text and element structure
- The ONE desired action (purchase / opt-in / click-through / download / call)
- Traffic source + entry trigger — the exact ad copy, email subject line, search query, or link label that will bring users to this page

**High-value optional:**
- Analytics: scroll depth heatmap, per-section exit rate, session recordings
- Audience goal vocabulary: search keywords, review mining phrases, support ticket language
- Funnel position: cold/warm/hot traffic, first touch vs. retargeted

## EXECUTION PROCESS

### Step 1 — Extract Entry Vocabulary (2 min)
List every distinct trigger word and phrase from the traffic source entry point. These are the user's active goal vocabulary — the semantic tokens they are trying to match on the page.

Example: Ad copy "Cut your tax bill by 40% — guaranteed" yields trigger vocabulary: {cut, tax bill, 40%, guaranteed, reduce, savings}.

### Step 2 — Inventory Page Elements in Reading Order (5 min)
List every above-fold and below-fold content block in scroll sequence:
- Page title / browser tab text
- Hero headline + sub-headline
- Hero image (describe subject, not style)
- Opening paragraph (first 2 sentences)
- Each subhead (H2, H3) in order
- Body paragraph blocks (summarize topic)
- Testimonial / social proof blocks
- CTA button labels (every instance)
- Form field labels (if present)
- Footer navigation links (if visible before action)

### Step 3 — Score Each Element: Scent Contribution (SC)
For each element, compute SC using the SNIF-ACT proxy:

**SC formula (simplified for audit use):**
SC = (# of trigger words present in element) / (total trigger words in goal vocabulary) × (element salience weight)

**Salience weights:**
- Hero headline: 2.0
- Subheadlines: 1.5
- CTA button text: 1.8
- Body paragraph: 1.0
- Image (descriptive relevance): 1.2
- Testimonial: 0.8

**Thresholds:**
- SC ≥ 0.4: strong scent — user continues without hesitation
- SC 0.2–0.39: moderate scent — user slows, continues tentatively
- SC < 0.2: weak scent — bail risk; user re-evaluates exit
- SC = 0.0: no scent — active bail trigger

### Step 4 — Build the Scent Decay Curve
Plot SC scores in reading order (element 1 → N). Identify:

- **Peak scent point:** highest SC element (usually above-fold if page is well-built)
- **First decay event:** first element where SC drops >0.15 below the prior element
- **Bail-risk zone:** any sequence of 3+ consecutive elements all scoring below 0.2
- **Terminal decay point:** element after which SC never recovers above 0.3

The predicted **primary bail point** is the first element in the first bail-risk zone.

### Step 5 — Apply Marginal Value Theorem Exit Test
Estimate the environmental average gain rate (EAGR) for this traffic source:

| Traffic Source | EAGR Calibration |
|---------------|-----------------|
| Branded search | Low — user chose this destination; threshold lenient |
| Non-branded commercial | High — many competing patches; threshold strict |
| Cold social/display | Very high — user was interrupted; threshold strictest |
| Email (warm list) | Medium — pre-existing trust lowers threshold slightly |
| Retargeted | Medium-low — prior exposure provides scent memory |

If SC at predicted bail point < EAGR calibration threshold, confirm bail prediction. Flag as HIGH CONFIDENCE.

### Step 6 — Diagnose Each Bail Point
For each flagged element, report:
- Current element text / description
- SC score
- Reason for low SC (wrong vocabulary, decorative image, vague copy, jargon, off-topic)
- Specific fix instruction (exact replacement vocabulary, format change, element removal)

### Step 7 — Generate Priority Fix List
Rank fixes by: (predicted % of sessions reaching element) × (SC deficit severity).
Top 3 fixes = highest ROI pre-launch interventions.

## OUTPUT STRUCTURE

**Section 1 — Entry Vocabulary Map**
Table: Trigger word | Source element | Goal relevance (high/med/low)

**Section 2 — Element Scent Scorecard**
Table: # | Element | SC Score | Scent Level | Status

| # | Element | SC | Level | Status |
|---|---------|-----|-------|--------|
| 1 | Hero headline | 0.72 | Strong | Pass |
| 2 | Hero image | 0.15 | Weak | Bail risk |

Legend: SC = Scent Contribution (0–1 scale); Level = Strong/Moderate/Weak/None; Status = Pass/Bail Risk/Terminal

**Section 3 — Decay Curve Summary**
- Peak scent: [element name], SC [score]
- First decay event: [element name], drop of [X] from prior
- Primary predicted bail point: [element name], fold position [N]
- Terminal decay point (if present): [element name]
- Confidence: HIGH / MEDIUM based on EAGR calibration

**Section 4 — Bail Point Diagnoses**
Per flagged element: current state → root cause → specific fix

**Section 5 — Priority Fix List**
Ranked top 3 interventions with expected scent recovery per fix.

## WORKED MINI-EXAMPLE

**Page:** Landing page for a B2B SaaS payroll tool
**Desired action:** Start free trial
**Traffic source:** Google ad — "Automated payroll for small businesses — no setup fees"
**Entry vocabulary:** {automated, payroll, small business, no setup fees, free, instant}

**Scent Scorecard (abbreviated):**

| # | Element | SC | Status |
|---|---------|-----|--------|
| 1 | H1: "Smarter Workforce Solutions" | 0.05 | Terminal |
| 2 | Hero image: stock handshake photo | 0.00 | Terminal |
| 3 | Sub-head: "Trusted by 10,000 companies" | 0.10 | Bail risk |
| 4 | Body: "Our platform streamlines HR workflows" | 0.08 | Bail risk |
| 5 | CTA: "Get Started" | 0.05 | Bail risk |

**Decay curve:** Scent is terminal from element 1. No recovery. Primary bail point: H1 (fold 1).
**Confidence:** HIGH — non-branded commercial query, EAGR threshold strict (0.35+).

**Fixes:**
1. H1 BEFORE: "Smarter Workforce Solutions" → H1 AFTER: "Automated Payroll for Small Businesses — Zero Setup Fees" (SC: 0.05 → 0.90)
2. Hero image BEFORE: stock handshake → Hero image AFTER: screenshot of payroll dashboard with dollar amounts visible (SC: 0.00 → 0.55)
3. CTA BEFORE: "Get Started" → CTA AFTER: "Start My Free Payroll Trial" (SC: 0.05 → 0.70)

**Predicted result:** Primary bail point eliminated. Entry vocabulary carried from ad to H1 to CTA without break. Scent trail continuous.

## OUTPUT FILE
Save to: [project-folder]/Pirolli - Click Architecture/[YYYY-MM] - Patch Abandonment Prediction.md
