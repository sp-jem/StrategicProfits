---
name: eisenberg-buying-modality-classifier
description: Use when a page has unknown or mismatched audience temperament — classifies the dominant buying modality of the arriving traffic and outputs the non-negotiable page requirements for that type
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Bryan & Jeffrey Eisenberg (Call to Action 2005; Always Be Testing 2008; The Four Buying Modalities framework) — Click Architecture (Skill 4 of 7)"
interface:
  invoke: "/eisenberg-buying-modality-classifier"
  calls: []
  called_by: [user, eisenberg-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic source mix shifts with campaigns; dominant modality changes as media buy evolves; stale classification misdirects page investment"

eisenberg_persona_pathway_integration:
  feeds_from: eisenberg-persona-pathway-mapper
  feeds_to: eisenberg-landing-anatomy-architect
  shared_data: "Dominant modality label + secondary modality stack rank; persona storyboard lane assignments"

fogg_behavior_integration:
  feeds_from: fogg-ability-auditor
  feeds_to: fogg-prompt-designer
  shared_data: "Modality-specific friction points (Methodical = cognitive load from missing specs; Spontaneous = any extra form field); Fogg ability score per modality"

kahneman_framing_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: eisenberg-conversion-trinity-builder
  shared_data: "System 1 vs System 2 activation per modality (Spontaneous/Humanistic = System 1 triggers; Methodical/Competitive = System 2 triggers); framing variant per lane"
---

# Eisenberg Buying Modality Classifier

## LAYER 1: INVARIANTS (Never override.)

1. The four modalities are fixed by buyer temperament — you cannot alter a visitor's modality. You serve it or you lose them.
2. The two axes are non-negotiable: Logic/Emotion (vertical) and Fast/Slow (horizontal). All four quadrants derive from exactly these two axes. Do not invent a fifth category.
3. Modality is determined by the TRAFFIC SOURCE first, analytics behavior second, and page copy third. A checkout-abandonment retargeting audience is not the same modality as a cold display audience even if they land on the same URL.
4. The dominant modality (highest revenue-weighted segment) owns above-the-fold. Secondary modalities are layered below the fold in descending revenue weight. No content above the fold serves a secondary modality at the expense of the primary.
5. Methodical buyers (45% baseline share) are destroyed by hype, urgency, and superlatives without hard proof. Any urgency element above the fold when Methodical is dominant modality is a direct conversion suppressant.
6. The Conversion Trinity is the evaluation gate before modality-specific fixes apply: Relevance → Value → CTA. Modality determines WHAT proof satisfies each gate, not whether the gate is required.
7. Persuasion-layer optimization (modality copy, urgency, testimonials) is invalid if functional, accessibility, or usability failures exist. Fix the Hierarchy of Optimization bottom-up first.

## LAYER 2: QUALITY GUIDANCE

1. Every modality diagnosis must cite at least one behavioral or source signal, not just stated audience assumptions.
2. The pre-mortem step (Buyer Legends Process) is required — list every reason that modality would NOT click the CTA from the current page state.
3. A page recommendation is only complete when it includes the CTA language variant, the proof type, and the above-fold element list for the classified modality.
4. Never prescribe urgency/scarcity elements without first confirming the dominant modality is Spontaneous or Competitive. Adding urgency to a Methodical-dominant page decreases conversion.
5. When analytics are unavailable, apply the baseline population weights (Methodical 45%, Spontaneous 25-35%, Humanistic 10-15%, Competitive 5-10%) as the default prior and state that explicitly in the output.

## PURPOSE

This skill classifies the dominant buying modality of the traffic arriving at a specific web page, then outputs the exact page requirements — headline type, proof format, CTA language, above-fold element list — that modality demands to convert.

Bryan and Jeffrey Eisenberg built the Four Buying Modalities from two empirically grounded axes: Logic/Emotion and Fast/Slow. The result is four non-negotiable temperament profiles. Misreading the modality is the single most common cause of wasted A/B test budget — optimizing for Spontaneous buyers when 45% of your traffic is Methodical produces a page that feels like a hype-fest to the majority and tanks trust.

**Brag line (carry to any peer):** "You cannot change a buyer's modality — you must identify which one is arriving and build the page around what THEY need to say yes, not what you think looks persuasive."

## INPUT REQUIREMENTS

**Required:**
- The page (URL, screenshot, or written description — enough to assess above-fold headline, body copy, CTA, and proof elements)
- The ONE desired action (click / opt-in / purchase / next step)

**Strongly recommended:**
- Traffic source(s) feeding this page (paid search, email list, retargeting, organic, cold display)
- Any available analytics: scroll depth heatmap, exit rate by section, comparison/pricing page engagement, testimonial page engagement
- Funnel position (cold top-of-funnel vs. warm consideration vs. hot bottom-of-funnel)

**Optional:**
- Existing A/B test history and which variants won/lost
- Stated customer persona profiles

## EXECUTION PROCESS

### Step 1 — Classify Dominant Modality (5 minutes)

Map each traffic source to its baseline modality using the signal table:

| Source Signal | Likely Dominant | Basis |
|---|---|---|
| Branded paid search | Methodical | Researching, comparing |
| Cold display / social | Spontaneous | Impulse trigger |
| Email list (warm) | Humanistic | Trust relationship |
| Competitive terms (vs. X) | Competitive | Feature comparison |
| Retargeting (cart abandon) | Methodical/Comp | Near-decision, logic check |
| Organic long-tail informational | Methodical | Deep research mode |

If analytics exist, apply the behavioral confirmation test:
- Heavy comparison/pricing page engagement → Methodical confirmed
- High above-fold CTA click rate before scroll → Spontaneous confirmed
- Testimonial/story section drives most exits AND returns → Humanistic
- Competitive comparison table engagement is primary scroll trigger → Competitive

Score each signal. Assign primary modality (highest weight), secondary modality (second weight). State population baseline if no data.

### Step 2 — Run Conversion Trinity Audit (10 minutes)

For the classified dominant modality, evaluate the existing page against all three gates:

**Gate 1 — Relevance:** Does the headline echo the exact trigger phrase from the source ad/email/search result? (Information Scent test: score 0-3: 0=no match, 1=theme match, 2=near-verbatim, 3=verbatim key phrase match.) Threshold for pass: score ≥ 2.

**Gate 2 — Value:** Does the body copy explain WHY this is the right solution for this modality's dominant question?
- Methodical dominant question: "What is the evidence this works?"
- Competitive dominant question: "How is this provably better than the alternative I am considering?"
- Spontaneous dominant question: "Will this feel good right now and is it fast?"
- Humanistic dominant question: "Can I trust the people behind this?"

Score value clarity 0-3. Threshold for pass: score ≥ 2.

**Gate 3 — CTA:** Is the desired action unambiguous and does the CTA language match this modality's motivation register? Score 0-3. Threshold: ≥ 2.

Any gate scoring < 2 is a required fix before modality-specific enhancements apply.

### Step 3 — Pre-Mortem (Buyer Legends) (10 minutes)

Walk through the page as the classified dominant modality buyer. List every reason they would NOT take the desired action. Use the pre-mortem format:

"As a [Modality] buyer arriving from [Source], I would not convert because..."

Each listed reason maps directly to a required page fix. Rank by revenue proximity (items blocking the CTA path outrank items in supporting sections).

### Step 4 — Hierarchy of Optimization Check (5 minutes)

Before prescribing persuasion fixes, confirm the page clears the bottom three levels:

1. **Functional** — Does the page load? Do all links and forms work? Is the desired action mechanically completable?
2. **Accessible** — Does the page work for screen readers, keyboard navigation, slow connections?
3. **Usable** — Is there any UX friction (confusing navigation, unclear form fields, missing error states)?

If any Level 1-3 failure exists, flag it as Priority 0. Persuasion optimization is blocked until resolved.

### Step 5 — Generate Modality-Specific Page Requirements

Output the non-negotiable element list for the classified dominant modality:

**Methodical (slow + logical, ~45%):**
- Headline: factual, specific, data-anchored (e.g., "Reduces onboarding time by 34% — verified by [Source]")
- Proof required: hard data, percentages, case studies with documented outcomes, transparent pricing with feature limits
- CTA language: low-pressure, evidence-referenced ("See the full data", "Download the comparison")
- Remove: urgency timers, superlatives without proof, hype adjectives
- Above-fold elements: headline with specific claim, one data point, CTA to deeper evidence

**Competitive (fast + logical, ~5-10%):**
- Headline: superlative backed by named proof source ("Highest-rated by G2, 2024")
- Proof required: named comparison chart, third-party rankings, achievement metrics
- CTA language: winning/advantage register ("Get the advantage", "See how we compare")
- Above-fold elements: headline + comparison trigger + achievement badge

**Spontaneous (fast + emotional, ~25-35%):**
- Headline: emotional benefit + immediacy ("Feel confident in your next pitch — today")
- Proof required: social proof volume (star count, customer count), vivid outcome imagery
- CTA language: low-friction, instant-access ("Start free", "Try it now", "Instant access")
- Add: urgency/scarcity if legitimate, visual dynamism
- Remove: long forms, multi-step friction before the desired action
- Above-fold elements: emotional headline, social proof signal, single prominent CTA

**Humanistic (slow + emotional, ~10-15%):**
- Headline: mission/purpose or real-person story ("We built this because we watched our clients' teams burn out")
- Proof required: authentic testimonials with real names/photos/context, mission statement, team photos
- CTA language: belonging/community register ("Join the community", "Meet the team first")
- Above-fold elements: human headline, one authentic testimonial, team signal

### Step 6 — Multi-Modality Page Layout (if secondary modality ≥ 20% share)

When a second modality exceeds 20% of qualified traffic:
- Primary modality content: above fold (0-viewport)
- Secondary modality content: fold 2 (first scroll), introduced with a transitional headline that does not contradict the above-fold message
- Never place content that contradicts the primary modality's proof requirements above the fold to serve a secondary modality

### Step 7 — CTA Language Variants Table

Produce one CTA variant per detected modality present, ranked by revenue weight.

## OUTPUT STRUCTURE

1. **Modality Classification** — Dominant + secondary, with signal evidence cited
2. **Conversion Trinity Audit** — Gate scores (0-3) with specific pass/fail on current page
3. **Pre-Mortem List** — Reasons the dominant modality would not convert, ranked by revenue proximity
4. **Hierarchy of Optimization Flags** — Any Level 1-3 blockers (Priority 0)
5. **Required Page Changes** — Non-negotiable element list for dominant modality (headline type, proof format, CTA language, above-fold sequence)
6. **Multi-Modality Layout** — Only if secondary modality ≥ 20%; fold assignment for each
7. **CTA Variant Table** — One variant per detected modality, ranked

## WORKED MINI-EXAMPLE

**Page:** SaaS project management tool landing page, traffic from Google paid search on "project management software for agencies"
**Desired action:** Start free trial (form submit)

**Before:**
- Headline: "Work Smarter. Move Faster. Do More." (generic, no scent match to search query)
- Body: 3 animated feature screenshots, no data
- CTA: "Get Started" (ambiguous)
- Form: 5 fields (name, company, team size, role, email)
- Above fold: hero image of smiling team

**Modality classification:** Search query is research-mode ("project management software for agencies" = comparison intent) → Methodical dominant (confirmed by 67% comparison page engagement in analytics).

**Conversion Trinity scores:** Relevance = 0 (no agency mention, no scent match), Value = 1 (features shown but no documented outcome data), CTA = 1 (ambiguous language, 5-field form suppresses Spontaneous secondary)

**Pre-mortem (Methodical buyer):** "I searched for agency-specific software. The headline says nothing about agencies. There's no data showing it works. I don't know pricing. The form wants 5 fields before I've seen evidence. I'm leaving to compare alternatives."

**After:**
- Headline: "Project management built for agencies — 38% fewer missed deadlines, per 2024 customer study" (scent match + data)
- Body: comparison table vs. top 2 alternatives, one case study with named agency and documented outcome
- CTA: "See the full comparison" (Methodical motivation register) → leads to gated PDF that collects email in 2 fields
- Form reduced to email + company name (2 fields)
- Above fold: data-anchored headline, one proof statistic, low-friction CTA

**Projected impact:** Relevance score 3, Value score 3, CTA score 2. Pre-mortem list cleared for Methodical dominant. Spontaneous secondary served by friction reduction (2-field form).

## OUTPUT FILE

Save to: [project-folder]/Eisenberg - Click Architecture/[YYYY-MM] - Buying Modality Classification.md
