---
name: eyal-trigger-architect
description: Use when a page has a desired action but no return habit — engineers internal (emotion) and external (page/notification) triggers that start and reload the Hook loop.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Nir Eyal (Hooked, 2014; Internal/External Trigger Taxonomy, Hook Model, B=MAP embedded) — Click Architecture (Skill 2 of 7)"
interface:
  invoke: "/eyal-trigger-architect"
  calls: []
  called_by: [user, eyal-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Internal trigger associations shift with audience segment, season, and competitive alternatives; owned-trigger assets (email cadence, push) decay as inboxes evolve."

eyal_hook_loop_integration:
  feeds_from: eyal-hook-loop-designer
  feeds_to: eyal-variable-reward-designer
  shared_data: "Hook phase map (which phase the page occupies), habitual-user Habit Path sequence, internal trigger emotion label for this audience"

fogg_integration:
  feeds_from: fogg-behavior-system-designer
  feeds_to: eyal-trigger-architect
  shared_data: "B=MAP convergence point — the scarcest simplicity resource (Time/Money/Effort/Brain/Social/Non-routine) identified by fogg-ability-auditor becomes the primary Action friction target for this skill's external trigger design"

pirolli_integration:
  feeds_from: pirolli-scent-trail-auditor
  feeds_to: eyal-trigger-architect
  shared_data: "Information-scent diagnostic identifies where visitors abandon the path; these drop-off nodes map to missing or misfired external triggers that this skill then repairs"
---

# Eyal Trigger Architect

## LAYER 1: INVARIANTS (Never override.)

1. **Every trigger — external or internal — must point at ONE desired action.** A page with two trigger systems produces zero habits. Name the single desired action before designing anything.
2. **External triggers exist only to install internal ones.** If a trigger cannot plausibly build a lasting emotional association (e.g., "I feel bored → I open this page"), it is an acquisition tactic, not a Hook trigger. Label it correctly.
3. **Internal triggers are named emotions, not demographics.** "25-34 female professionals" is not a trigger. "Uncertainty about whether today's decisions are good enough" is. The copy must address the emotion by name.
4. **The Trigger-Action gap is a friction problem, not a motivation problem.** If users see the trigger and do not act, run the Six-Element Simplicity audit before adding persuasion copy. The scarcest resource blocks more behavior than weak motivation.
5. **CTA labels are external triggers — every word is diagnostic.** A label that describes the user's current state AND the next action AND the emotional relief outperforms a label that does only one of those three.
6. **Owned triggers (email, push, retargeting) must carry user-generated data.** A notification that shows the user their own progress, metrics, or status delivers value before the click and dramatically outperforms broadcast messaging.
7. **Loaded triggers are the exit of Investment, not the entry of Trigger.** Do not add trigger-loading steps early in the funnel. Investment comes last; it loads the next external trigger only after the user has already completed a full pass through the loop.

## LAYER 2: QUALITY GUIDANCE

1. **Anchor every headline to the Internal Trigger Narrative template.** Draft the sentence "Every time [user] feels [emotion], they [desired action]" first. Every headline, subhead, and image must reinforce one clause of that sentence.
2. **Score trigger–action proximity.** Measure the distance (scrolls, clicks, seconds) between where the external trigger fires and where the action is taken. Compress to the minimum. A trigger 4 scrolls above the CTA loses most of its force.
3. **Use the 5% habitual-user threshold as the habit-formation verdict.** After three sessions, if fewer than 5% of users take the target action without external prompting, the trigger has not installed an internal association — diagnose which phase is failing before optimizing copy.
4. **Separate conversion optimization from habit-formation optimization.** Conversion rate measures phase-1 pass-through. Return visit rate within 7 days (without a new external trigger) measures whether an internal trigger installed. Both metrics are required.
5. **Never allow trigger redundancy to create noise.** Three different CTAs on one page, each with a different emotional frame, cancels the association-building the Hook loop requires. One emotion, one action, one loop.

## PURPOSE

This skill operates on a single web page to engineer the Trigger phase of Eyal's Hook Model — the phase where an emotion or environmental cue initiates the behavior cycle. It uses the Internal/External Trigger Taxonomy, the B=MAP Simplicity lever inside the Action phase, and the Internal Trigger Narrative template to diagnose why visitors see the page but do not act (or act once but never return). Every output is a concrete on-page change: rewritten headlines, re-labeled CTAs, owned-trigger copy, friction removal instructions, and a habit-path shortcut plan.

**Brag line (PURPOSE):** "Our product builds a return habit, by design."

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description of current above-the-fold + CTA + any email/notification trigger assets
- The ONE desired action (click / opt-in / purchase / specific next step)

**Strongly recommended:**
- Audience description: who is visiting, what funnel position they are in (cold / warm / customer)
- Any existing analytics: bounce rate, scroll depth, session recordings, return visit rate within 7 days
- Current owned-trigger assets: email subject lines, push notification copy, retargeting ad copy

**Optional:**
- Competitor pages for Internal Trigger benchmarking
- Survey data on audience emotional state

## EXECUTION PROCESS

### Step 1 — Name the Internal Trigger (5 min)

Write the Internal Trigger Narrative sentence:
> "Every time [target user] feels [specific emotion], they [desired action on this page]."

Rules:
- The emotion must be negative and already present before they arrive (boredom, loneliness, uncertainty, frustration, FOMO, inadequacy). Positive emotions are rewards, not triggers.
- If you cannot write this sentence in one attempt, you do not yet know your audience's internal trigger. Stop and survey or review session recordings before proceeding.
- Every element of the page diagnosis in Steps 2-5 is evaluated against whether it reinforces this sentence.

### Step 2 — External Trigger Audit (15 min)

Classify every external trigger currently on the page into Eyal's four categories:

| Type | Definition | On-page examples |
|------|-----------|-----------------|
| Paid | Purchased placement | Display ad, paid social |
| Earned | Editorial/press | PR mention, SEO result |
| Relationship | Person-to-person | Referral, share, word of mouth |
| Owned | Brand-controlled | Email, push, retargeting, page icon |

Score each trigger on two dimensions (1-5):
- **Emotion Match** — Does this trigger name or imply the internal trigger emotion from Step 1?
- **Action Clarity** — Does this trigger tell the user exactly what happens next AND imply emotional relief?

Any trigger scoring below 3 on either dimension is a priority repair.

**CTA Label Diagnostic — the three-clause test:**
A maximum-strength CTA label contains:
1. User's current state acknowledgment OR action verb
2. Specific next action (what will happen in the next 10 seconds)
3. Implied emotional relief (what they will feel after)

Score current CTA labels 0-3. Rewrite any label scoring below 2.

Before → After example:
- Before: "Submit" (score: 0 — no state, no relief)
- After: "Get My Free Clarity Report" (score: 2 — action + implied relief; add state clause for 3: "Yes, Show Me What's Blocking Me")

### Step 3 — Six-Element Simplicity Audit (10 min)

Identify which of the six resources is scarcest for YOUR visitor at THIS moment. This is the friction to eliminate first — not all six simultaneously.

| Element | Diagnosis question | Cold traffic default |
|---------|-------------------|---------------------|
| Time | How many seconds to complete action? | High friction if >30 sec visible |
| Money | Is there a cost at this step? | N/A for opt-ins |
| Physical effort | Typing, clicking, scrolling required? | Low for digital |
| Brain cycles | How much must user understand before acting? | **Usually #1 bottleneck** |
| Social deviance | Does action feel embarrassing or abnormal? | **Usually #2 bottleneck** |
| Non-routine | Does action interrupt existing habits? | High for new behaviors |

**Cold traffic rule:** Brain cycles and Non-routine are almost always the top two. Reduce cognitive load (fewer words, shorter headlines, single CTA) before adding persuasion. Use social proof to reduce Social Deviance ("Join 47,000 marketers who...").

**Measurement:** Count words above the fold. If above 150, brain-cycle friction is almost certainly the primary bottleneck. Target: 80 words or fewer above fold for the first external trigger to fire cleanly.

### Step 4 — Trigger–Action Proximity Compression (10 min)

Measure the gap between where the external trigger fires (the first headline that names the emotion) and where the desired action is taken (the CTA button).

- Count scrolls (desktop: one scroll = ~600px viewport)
- Count clicks to reach the action
- Count seconds of reading required before the action is visible

**Threshold:** Trigger-to-action distance greater than 1.5 scrolls on mobile degrades conversion. CTA must be visible or reachable within one swipe of the primary trigger headline.

Compression tactic: Duplicate the CTA immediately below the primary trigger headline AND at the natural scroll endpoint. Use the same label — do not introduce a second emotional frame.

### Step 5 — Internal Trigger Installation Plan (10 min)

The goal: after 3+ passes through the loop, the user self-triggers without the owned external trigger.

Write the owned-trigger sequence (email/push) that loads the next external trigger after each Investment action. Each message must contain:
- The user's own data (progress, status, metric) — not broadcast copy
- A single action prompt pointing back to the page
- Subject line or push title that names the internal trigger emotion

**Owned trigger copy template:**
> "[User's metric/progress data] — [emotion-named question or statement] — [single action link]"

Example:
> "You've set 3 goals this week. Most people at this stage feel stuck on which one to start. Here's what your data says → [link]"

This triggers "uncertainty" (internal) via owned channel (external), routes back to the page, and adds a data-load that increases the next trigger's relevance.

### Step 6 — Habit Path Shortcut (5 min)

Identify the minimum action sequence your best converters share (via heatmap, session recording, or funnel analysis). This is the Habit Path.

Map the Habit Path as a numbered sequence:
1. [First interaction — e.g., read headline]
2. [Second interaction — e.g., scroll to proof block]
3. [Third interaction — e.g., click CTA]

Strip every page element not on this path from above-the-fold view. Move distracting elements (nav links, secondary CTAs, social sharing) below the fold or remove entirely.

**5% threshold check:** If return-visit rate without external trigger is below 5% after 3 sessions, the Habit Path has not been installed. Run a phase-failure diagnosis: which of the four Hook phases (Trigger / Action / Variable Reward / Investment) shows the highest drop-off?

## OUTPUT STRUCTURE

The skill produces a single dated markdown file with these sections:

**1. Internal Trigger Narrative** — The one sentence. Locked before all else.

**2. External Trigger Audit Table** — Current triggers scored on Emotion Match + Action Clarity, with priority flags.

**3. CTA Rewrite Table** — Before/after for every CTA on the page, scored on the three-clause test.

**4. Simplicity Audit** — Scarcest resource identified, specific friction removal instructions, word-count above fold.

**5. Trigger-Action Proximity Map** — Current distance measured, compression recommendation.

**6. Owned Trigger Sequence** — 3-touch email/push copy using the user-data template.

**7. Habit Path Shortcut** — Numbered sequence + elements to strip from above-fold.

**8. Metrics to Track** — Specific measurements with thresholds for habit-formation verdict.

## WORKED MINI-EXAMPLE

**Page:** B2B SaaS opt-in for a free "Revenue Leak Audit" tool. Cold traffic from LinkedIn ad.
**Desired action:** Email opt-in.

**Before state:**
- Headline: "Revenue Leak Audit — Find What's Costing You" (features product, no emotion)
- CTA label: "Get Started" (no state, no next action, no relief — score: 0/3)
- Form: 5 fields (name, email, company, revenue range, industry)
- 3 other CTAs on page (demo, pricing, blog)
- No owned trigger sequence post-opt-in

**Internal Trigger Narrative (Step 1):**
> "Every time a B2B founder feels the anxiety of not knowing where revenue is leaking, they open the Revenue Leak Audit."

**Emotion identified:** Anxiety about invisible loss.

**After changes:**
- Headline: "Most founders lose $40K-$200K/year in revenue they can't see. This audit shows you exactly where." (names anxiety + implies relief)
- CTA label: "Show Me Where I'm Losing Revenue" (score: 3/3 — state + action + relief)
- Form reduced to 1 field: email only. Revenue range and industry collected post-opt-in as Investment step.
- All secondary CTAs moved below fold; single Habit Path above fold
- Owned trigger email day 3: "Your audit found 2 potential leak points. Most founders in your range feel uncertain which to fix first. Here's your priority order → [link]"

**Predicted outcome (B=MAP lens):** Brain-cycle friction (understanding what the product does) dropped by removing 4 of 5 form fields and collapsing the value prop to one anxiety-naming sentence. Social deviance reduced by "most founders" framing. Trigger-action distance: 0 scrolls (CTA is inline with headline). Return-visit trigger: day-3 owned email carries user's own audit data, naming the same internal trigger (uncertainty) to reload the loop.

## OUTPUT FILE

Save to: [project-folder]/Eyal - Click Architecture/[YYYY-MM] - Trigger Architect - [Page Name].md
