---
name: pirolli-link-diagnosticity-scorer
description: Use when a page has links, CTAs, nav items, or button labels that may be leaking visitors — scores every clickable element for information scent strength (diagnosticity) and rewrites weak ones using Pirolli & Card's SNIF-ACT model.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peter Pirolli & Stuart Card (Information Foraging Theory 1999; SNIF-ACT 2007; Proximal Cue Model 2004) — Click Architecture (Skill 4 of 7)"
interface:
  invoke: "/pirolli-link-diagnosticity-scorer"
  calls: []
  called_by: [user, pirolli-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Audience trigger-word vocabulary shifts with traffic source and campaign language; stale scent scores misfire against current visitor goal-states."

pirolli_scent_trail_integration:
  feeds_from: pirolli-scent-trail-auditor
  feeds_to: pirolli-scent-gradient-designer
  shared_data: "Trigger-word list extracted by scent-trail-auditor is used here as the scoring vocabulary; diagnosticity scores feed gradient-designer to sequence link placement by scent strength."

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: kahneman-framing-engineer
  shared_data: "System 1 label readability (availability heuristic) overlaps with scent diagnosticity — high-scent labels are also low-cognitive-load labels; shared trigger-word rewrites serve both tools."

fogg_integration:
  feeds_from: fogg-ability-auditor
  feeds_to: fogg-prompt-designer
  shared_data: "Fogg's Ability axis includes 'non-routine' friction; a low-diagnosticity CTA raises perceived effort cost (within-patch cost). Shared output: the rewritten CTA label that simultaneously raises scent and lowers perceived effort."
---

# Pirolli Link Diagnosticity Scorer

## LAYER 1: INVARIANTS (Never override.)

1. **Diagnosticity is the only measure that matters.** A link label's quality is not its word count, cleverness, or brand voice — it is the probability that a forager correctly predicts the distal destination's relevance to their current goal before clicking. If the prediction is wrong or uncertain, the label fails regardless of aesthetics.

2. **Trigger-word match drives SNIF-ACT activation.** Per SNIF-ACT: A_i = B_i + Σ(S_ji × W_j). Association strength S_ji between a proximal cue j and destination chunk i is near-zero when the cue contains none of the user's active goal vocabulary. Base-level activation B_i alone is insufficient to drive clicks. Every label must contain ≥1 high-weight trigger word to register above threshold.

3. **"Click here," "Learn more," "Submit," and "Explore" score zero.** These labels contain no trigger words, predict no specific destination, and generate zero SNIF-ACT association strength. They are invisible to the forager's scent-detection system. Never leave them in a final audit.

4. **Scent must be consistent with the destination.** Diagnosticity is not just pre-click — it must hold post-click. A high-scent label that leads to a low-relevance page trains users to distrust all labels on the site (scent calibration collapse). Score the label against the actual destination content, not just the page context.

5. **Within-patch cost compounds low diagnosticity.** A weak label forces the forager to compensate by clicking speculatively and reading the destination to verify relevance — this is extra within-patch cost per Pirolli's Two-Cost Model. The goal is zero speculative clicks: every link predicts its destination accurately enough that no verification read is needed.

6. **One desired action governs the entire score.** All diagnosticity scores are relative to the page's ONE desired action. Links that compete with or diverge from that action are scored for their distraction potential, not just their inherent scent strength.

7. **Proximal cues are additive — audit all of them.** Link text, button label, surrounding paragraph, image alt text, URL slug, and page subhead all contribute to SNIF-ACT activation. A weak label can be partially rescued by strong surrounding cues; a strong label can be undercut by contradicting copy nearby. Score the label in context.

---

## LAYER 2: QUALITY GUIDANCE

1. **Use the visitor's exact vocabulary, not internal terminology.** Trigger words come from search queries, ad copy, email subject lines, and support tickets — not from the brand's naming conventions. "Access the Portal" scores lower than "Download Your 7-Day Plan" when users searched "7-day plan."

2. **Score ≥3 diagnostic dimensions per link.** Use the Diagnosticity Scorecard (see Execution Process, Step 3). A single dimension (e.g., goal-word presence) is insufficient — scent is multi-cue.

3. **Rewrite before declaring a label unfixable.** A label that scores 2/10 can often reach 7/10 with one vocabulary substitution. Attempt the rewrite before recommending removal or structural changes.

4. **Flag competing links as diagnosticity interference.** Multiple high-scent labels pointing away from the desired action create a "patch forking" problem — the forager faces competing forward paths, which is equivalent to scent dilution. Identify and neutralize these even if their individual scores are high.

5. **Validate rewrites against the destination's H1 and above-the-fold copy.** A rewritten label that contradicts destination page vocabulary creates a post-click scent mismatch — the user lands, perceives a patch boundary, and exits. Match the rewrite vocabulary to the actual destination headline.

---

## PURPOSE

This skill applies Pirolli & Card's Information Foraging Theory — specifically the SNIF-ACT cognitive model and Proximal Cue framework — directly to every clickable element on a web page. It scores each link, CTA, nav item, and button for **diagnosticity**: the degree to which its label accurately predicts the distal destination and goal-relevance for a user in a specific foraging state.

**The lever:** Every link label is a proximal cue that the forager's cognitive system pre-evaluates before clicking. Low-diagnosticity labels fail the SNIF-ACT activation threshold — the link becomes invisible to motivated foragers and generates speculative (costly) clicks from uncertain ones. High-diagnosticity labels produce confident forward movement directly toward the desired action.

**The brag line:** "We can predict which links leak visitors before we ship the page."

This skill does not audit overall page scent (that is pirolli-scent-trail-auditor's job). It operates at the link/CTA/label level: scoring each element, ranking leakage risk, and delivering rewritten labels grounded in the visitor's trigger-word vocabulary.

---

## INPUT REQUIREMENTS

**Required:**
- The page — URL, screenshot, or written description of all visible link/CTA/nav text
- The ONE desired action (e.g., "click the Get Instant Access button," "opt in to the email list," "proceed to checkout")
- The traffic source(s) — the ad copy, email subject, or search query that brought visitors here (this defines the trigger-word vocabulary)

**Optional but high-value:**
- Analytics: click-through rates per link, heat map, scroll depth data
- The destination page's H1 and above-the-fold copy (for post-click consistency check)
- Audience goal-state description (what specific information need are they trying to satisfy?)
- Competing links count (navigation, sidebars, footer)

---

## EXECUTION PROCESS

**Step 1 — Extract all proximal cues (5 min)**

List every clickable element on the page:
- Navigation items (header, footer, sidebar)
- In-body hyperlinks
- Button labels
- Image alt text on clickable images
- URL slugs visible in hover text
- Form field labels that function as directional cues

Group by: (A) PRIMARY — elements that point toward the desired action; (B) COMPETING — elements that point away from the desired action; (C) NEUTRAL — elements with indeterminate direction.

**Step 2 — Identify the trigger-word vocabulary (3 min)**

From the traffic source (ad, email, search query), extract the 5-8 highest-intent words the visitor carried to this page. These are the vocabulary items active in W_j (attentional weight) in the SNIF-ACT equation.

Example: If the Google ad said "Free 7-Day Keto Meal Plan — Download Instantly," trigger words = {free, 7-day, keto, meal plan, download, instant}.

**Step 3 — Score each label on the Diagnosticity Scorecard**

Score each link/CTA on 5 dimensions, 0–2 each (max 10):

| Dim | Criterion | 0 | 1 | 2 |
|-----|-----------|---|---|---|
| TW | Trigger-word hit | 0 words | 1 word | ≥2 words |
| DS | Destination specificity | Generic | Category | Exact outcome |
| GA | Goal-action alignment | Opposes | Neutral | Reinforces |
| CX | Contextual cue support | Contradicts | Neutral | Amplifies |
| PC | Post-click consistency | Mismatch likely | Uncertain | Confirmed match |

**Legend:** TW = Trigger-Word Hit, DS = Destination Specificity, GA = Goal-Action Alignment, CX = Contextual Cue Support, PC = Post-Click Consistency

**Thresholds:**
- 9–10: Optimal scent — do not change
- 7–8: Strong — minor refinement optional
- 5–6: Moderate — rewrite recommended
- 3–4: Weak scent — rewrite required; label is leaking visitors
- 0–2: Dead label — zero diagnosticity; replace immediately

**Step 4 — Rank leakage risk**

For competing links (Group B), multiply their diagnosticity score by a Distraction Weight (DW):
- DW = 1.5 if the link appears above the fold
- DW = 1.2 if the link appears within 2 scroll depths of the desired action CTA
- DW = 1.0 otherwise

A competing link with score 7 × DW 1.5 = 10.5 leakage risk outranks a primary link with score 4. Flag all competing links with adjusted leakage risk ≥ 8 for removal or neutralization.

**Step 5 — Rewrite weak primary labels**

For every primary link scoring ≤ 6:
1. Pull 2–3 trigger words from Step 2
2. State the exact outcome the destination delivers
3. Compress to ≤6 words
4. Verify the rewrite against the destination's H1 (post-click consistency check)
5. Re-score the rewrite — it must reach ≥8

Formula for a high-diagnosticity label:
**[Trigger Verb] + [Exact Outcome] + [Optional: Time/Specificity Modifier]**

Examples:
- "Download" → "Download Your Free 7-Day Keto Plan"
- "Learn More" → "See How to Cut Your Tax Bill by 40%"
- "Get Started" → "Start Your Free 14-Day Trial Today"
- "Submit" → "Send My Application"

**Step 6 — Address competing-link leakage**

For each competing link with leakage risk ≥ 8:
- Option A: Remove the link from this page
- Option B: Reduce its diagnosticity deliberately (rewrite it to be vaguer, lower-scent) so it does not attract foragers away from the desired action — this is strategic negative-scent design per Pirolli's Proximal Cue Model
- Option C: Relocate it below the desired-action CTA fold so it only reaches users who have already completed the primary action

**Step 7 — Final scent-trail consistency check**

Confirm the rewritten primary labels form an unbroken scent trail: the trigger words from the traffic source appear in the headline → subheads → body links → CTA button. If any element breaks the chain, flag it for the pirolli-scent-trail-auditor.

---

## OUTPUT STRUCTURE

**Section 1: Trigger-Word Vocabulary**
List of 5–8 trigger words extracted from the traffic source. This is the scoring baseline.

**Section 2: Full Link Inventory & Diagnosticity Scores**
Table: Label | Group (A/B/C) | TW | DS | GA | CX | PC | Total | Leakage Risk

**Section 3: Critical Leakage Findings**
Ranked list of links scoring ≤ 6 (primary) or leakage risk ≥ 8 (competing). One sentence per finding stating the mechanism of failure (which SNIF-ACT dimension collapsed and why).

**Section 4: Rewritten Labels**
For each weak primary label: Before → After, with the new diagnosticity score and the trigger words embedded. Note post-click consistency status.

**Section 5: Competing-Link Remediation**
For each high-risk competing link: recommended action (remove / reduce / relocate) with one-line rationale.

**Section 6: Integration Flags**
If the full page's scent trail shows systemic vocabulary breaks → flag to pirolli-scent-trail-auditor.
If CTA label rewrites surface Fogg ability-cost issues → flag to fogg-ability-auditor.
If label framing could leverage loss/gain asymmetry → flag to kahneman-framing-engineer.

---

## WORKED MINI-EXAMPLE

**Page:** Landing page for a tax-savings course. Traffic source: Google Ad — "Reduce Business Taxes by 40% — Legal Strategies CPAs Use."

**Trigger words extracted:** {reduce, business taxes, 40%, legal, strategies, CPAs, use}

**Current above-the-fold CTA:** "Get Started Today"

**Diagnosticity score — current label:**
- TW: 0 (no trigger words) → 0
- DS: 0 (no destination specificity — "Get Started" at what?) → 0
- GA: 1 (not opposing, but neutral) → 1
- CX: 1 (surrounding copy mentions taxes, partial rescue) → 1
- PC: 0 (destination is a checkout page; label predicts nothing about it) → 0
- **Total: 2/10 — Dead label**

**Rewritten CTA:** "Show Me the 40% Tax-Reduction Strategies"

**Diagnosticity score — rewrite:**
- TW: 2 ("40%" and "Tax-Reduction Strategies" match ad copy directly) → 2
- DS: 2 (exact outcome stated: tax reduction strategies) → 2
- GA: 2 (directly advances the purchase of the course) → 2
- CX: 2 (surrounding copy confirms tax-savings framing) → 2
- PC: 2 (destination page H1: "40% Less in Business Taxes — Here's the System") → 2
- **Total: 10/10**

**Competing link flagged:** Navigation item "About Our Firm" — score 6, DW 1.5 (above fold), leakage risk 9. Recommendation: relocate to footer or reduce to text-only link with no visual emphasis.

---

## OUTPUT FILE
Save to: [project-folder]/Pirolli - Click Architecture/[YYYY-MM] - Link Diagnosticity Scores.md
