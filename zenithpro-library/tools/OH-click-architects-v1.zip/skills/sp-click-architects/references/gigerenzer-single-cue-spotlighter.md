---
name: gigerenzer-single-cue-spotlighter
description: Use when a page buries its strongest proof in a list of 12 competing claims — isolates the single highest-validity discriminating cue so Take-the-Best fires at the CTA before the visitor finds an exit.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Gerd Gigerenzer (Simple Heuristics That Make Us Smart, 1999; Take-the-Best, 1996; Natural Frequencies, 1995) — Click Architecture (Skill 6 of 7)"
interface:
  invoke: "/gigerenzer-single-cue-spotlighter"
  calls: []
  called_by: [user, gigerenzer-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Proof points age — testimonials, stats, and recognition signals shift validity rank as market awareness changes. Re-audit when social proof volume doubles or offer repositions."

gigerenzer_less_is_more_integration:
  feeds_from: gigerenzer-less-is-more-auditor
  feeds_to: gigerenzer-single-cue-spotlighter
  shared_data: "Audit flags overloaded attribute lists; Spotlighter receives that list, ranks by cue validity, and strips all but #1 from the hero block."

take_the_best_integration:
  feeds_from: gigerenzer-take-the-best-sequencer
  feeds_to: gigerenzer-single-cue-spotlighter
  shared_data: "TTB Sequencer orders the full cue set by validity across the page; Spotlighter focuses that ranked list onto the single above-the-fold cue — their jobs do not overlap (sequence vs. spotlight)."

kahneman_integration:
  feeds_from: kahneman-anchoring-designer
  feeds_to: gigerenzer-single-cue-spotlighter
  shared_data: "Kahneman anchoring sets the reference quantity; Spotlighter converts that anchor to natural frequency format (N of M) so it survives fast System-1 processing without Bayesian distortion."

iyengar_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: gigerenzer-single-cue-spotlighter
  shared_data: "Iyengar audits total option count; Spotlighter identifies which single discriminating cue should replace a multi-option matrix in fast-and-frugal tree position 1."
---

# Gigerenzer Single-Cue Spotlighter

## LAYER 1: INVARIANTS (Never override.)

1. **One cue leads.** The highest-validity discriminating cue appears first, alone, above any secondary claims. No cue list — a list signals that no single cue is decisive.
2. **Natural frequencies, never percentages.** Every stat on the page converts to N-of-M format before output. "80% success rate" becomes "8 of 10 customers." Odds ratio of 7.1 on Bayesian comprehension (Gigerenzer & Hoffrage, 1995).
3. **Absolute counts, never relative risk.** "25% more effective" is prohibited until the reference class is explicit and stated as absolute counts ("1 additional person protected per 200").
4. **Recognition precedes conversion.** If the visitor cannot recognize the brand or named authority, no conversion-asking copy runs until a recognition-building element is placed earlier on the page. Recognition Heuristic (2002): unrecognized options lose by default — you cannot recover this with feature lists.
5. **Stopping rule must fire at the CTA.** The page structure places the top cue immediately before the call to action so Take-the-Best's stopping rule exits the search at the desired action, not at a competing exit.
6. **Uncertainty context = simplicity wins.** When the visitor faces genuine uncertainty (new category, unfamiliar product), feature matrices are prohibited in position 1 — they create false precision. Fast-and-frugal tree structure (one discriminating question at a time) is the replacement.
7. **No Less-Is-More sabotage.** If this brand/product is the recognized option vs. an unknown competitor, adding more feature detail to the hero is a validity violation — it shifts the visitor from recognition to analytic mode where the unknown can compete on specs.

## LAYER 2: QUALITY GUIDANCE

1. **Validity rank must be computed, not guessed.** Score each candidate cue on two axes: (a) historical conversion lift for this offer type or market, (b) discriminating power (does it separate yes/no visitors?). The highest scorer is the spotlight cue.
2. **The spotlight cue must be falsifiable.** Vague claims ("industry-leading quality") have zero validity — they do not discriminate because every competitor makes the same claim. Require a specific, verifiable number or named proof point.
3. **Test the stopping rule.** Read the page as if encountering it cold. At what point does a question get answered decisively? If the answer comes after scrolling past secondary claims, the stopping rule fires too late. Move the cue up.
4. **Natural frequency audit is binary.** Each stat either passes (N of M, absolute count, named reference class) or fails (percentage, relative risk, vague descriptor). No partial credit.
5. **Output includes a before/after rewrite for every flagged element,** not just a diagnosis list. Diagnosis without rewrite is incomplete.

## PURPOSE

This skill takes a real page (URL, screenshot, or written description) plus one desired action (click / opt-in / purchase), diagnoses which single cue has the highest validity for triggering Take-the-Best at that action, then rewrites the page hierarchy and all statistical claims to match.

**The specific Gigerenzer lever:** Gigerenzer's Adaptive Toolbox shows every fast-and-frugal decision has a Search Rule, a Stopping Rule, and a Decision Rule. Visitors arrive with these rules running. The page either feeds them or fights them. A page that leads with 12 features tells the visitor's Stopping Rule "keep searching — no discriminating cue found yet." A page that leads with ONE high-validity cue fires the Stopping Rule immediately and channels it toward the desired action.

Most pages fight the Adaptive Toolbox: they list features, show percentage statistics that require normalization operations no visitor performs, and bury the strongest proof in a feature grid where it competes with weaker cues for attention.

This skill restores ecological rationality — it matches page structure to the statistical structure of how visitors actually decide.

**Brag line:** "We design WITH the mental shortcuts instead of fighting them."

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description of current content and layout
- The ONE desired action: what specific behavior constitutes conversion on this page

**Optional (improves validity scoring):**
- Analytics: bounce rate, scroll depth, heatmap, click data
- Audience profile: how familiar are visitors with this brand/category? (Recognition Heuristic calibration)
- Funnel position: cold traffic, warm list, retargeted — changes which cue type has highest validity
- Existing A/B test results: any known lift data on specific proof points

## EXECUTION PROCESS

**Step 1 — Inventory all cues currently on page.**
List every distinct claim, proof point, statistic, testimonial, feature, and recognition signal. Assign a position (hero / body / footer). Note current format: percentage, relative claim, absolute count, or natural frequency.

**Step 2 — Score each cue on Validity × Discriminating Power.**
Use a 1-5 scale on each axis:
- Validity (1=generic claim, 5=specific verifiable number or named authority with measurable outcome)
- Discriminating Power (1=visitor already assumes this of all competitors, 5=true differentiator for this offer vs. alternatives)

Multiply the two scores. The cue with the highest product is the Spotlight Cue.

Threshold: if no cue scores above 12/25, flag that the page lacks a sufficient proof point and note what type of proof would score above 12 (specific stat, named client result, media recognition).

**Step 3 — Check Recognition Heuristic status.**
Ask: does the target visitor recognize this brand, product, or authority by name? If recognition confidence is below 70% (unknown brand, new product launch, cold traffic campaign), the page MUST place a recognition-building element (media logos, known authority endorsement, familiar partner name) before the Spotlight Cue. Recognition is a prerequisite; the heuristic only works in your favor once you are the recognized option.

**Step 4 — Convert all statistics to natural frequency format.**
For every percentage or relative claim currently on the page:

| Current format | Natural frequency replacement |
|---|---|
| 80% success rate | 8 of 10 customers achieved X |
| 25% risk reduction | Drops from 4 to 3 cases per 100 |
| 3x more likely | 3 of 10 vs. 1 of 10 in comparison group |
| 20% of users | 1 in 5 people who tried X |

Reference class rule: every natural frequency must name WHO the N-of-M refers to (customers like you / members in this program / clinical trial participants).

**Step 5 — Map current page to Fast-and-Frugal Tree structure.**
A page's information hierarchy should operate like an FFT: position 1 asks the most valid discriminating question. If yes (cue discriminates in visitor's favor), exit at desired action. If no (visitor is still uncertain), move to position 2 with the second-highest cue.

Diagnosis: draw the current implicit tree. Find where the first exit node is placed. If it arrives after more than 2 scrolls or 3 competing claims, the tree is broken — the visitor exits to "research more" before reaching your CTA.

**Step 6 — Write the revised hierarchy.**
Structure:
1. Recognition signal (if required by Step 3) — max 1 element, logos or named authority
2. Spotlight Cue in natural frequency format — headline or sub-headline
3. Desired action (CTA) — immediately below the Spotlight Cue, before any other claims
4. Supporting cues in validity order — below the fold, for visitors who did not stop at Step 3

**Step 7 — Write before/after rewrites for every flagged element.**
For each stat, claim, or structure change: show original line, show replacement line, state which framework applies (Natural Frequencies, Take-the-Best, Recognition Heuristic, etc.).

## OUTPUT STRUCTURE

**Section 1: Cue Inventory + Validity Scores**
Table: Cue | Pos | Format | Val | Disc | Score
(Legend: Pos=current position, Val=validity 1-5, Disc=discriminating power 1-5, Score=Val×Disc)

**Section 2: Spotlight Cue Declaration**
- Named cue, score, why it outranks alternatives
- Recognition status: does visitor recognize brand/authority? Y/N + evidence
- If recognition gap: specify the recognition element required before spotlighting

**Section 3: Natural Frequency Conversions**
Before/after table for every stat on the page.

**Section 4: Fast-and-Frugal Tree Diagnosis**
Current implicit tree (described). Revised tree (described). Where the stopping rule fires now vs. where it fires after revision.

**Section 5: Revised Page Hierarchy**
Written description of revised layout order, position by position.

**Section 6: Concrete Rewrites**
Before/after for every changed element. Label each with the Gigerenzer mechanism applied.

**Section 7: Validity Gap Flag (if applicable)**
If no cue scores above 12/25: what proof type is missing and how to obtain it before re-running this audit.

## WORKED MINI-EXAMPLE

**Page:** Online coaching program landing page, desired action: opt-in to free training.

**Current hero:**
"Join 10,000+ entrepreneurs. 94% satisfaction rate. 3x ROI on average. Award-winning curriculum. Used by Fortune 500 companies. 47 expert modules. 6 months of support."

**Step 2 Scoring (abbreviated):**

| Cue | Val | Disc | Score |
|---|---|---|---|
| 10,000+ entrepreneurs | 3 | 2 | 6 |
| 94% satisfaction | 2 | 1 | 2 |
| 3x ROI on average | 3 | 3 | 9 |
| Award-winning | 1 | 1 | 1 |
| Fortune 500 | 3 | 3 | 9 |
| 47 modules | 1 | 1 | 1 |
| 6 months support | 2 | 2 | 4 |

Spotlight Cue candidates: "3x ROI on average" and "Fortune 500" both score 9. "3x ROI" wins because it is directly about outcome for the visitor; Fortune 500 builds recognition for unknown visitors.

**Step 3:** Cold traffic, brand unknown — recognition gap. Fortune 500 logos must precede the Spotlight Cue.

**Step 4 — Natural frequency conversions:**
- "94% satisfaction rate" → "47 of 50 clients said they would recommend this to a peer"
- "3x ROI on average" → "In our last cohort of 200 clients, 3 in 4 reported recovering their full investment within 90 days"

**Revised hero (after):**
"As seen in: [Fortune 500 logos]
3 of 4 clients in our last cohort recovered their full investment within 90 days.
[Get free training — CTA]"

Everything else moves below the fold. The visitor's Take-the-Best heuristic hits one discriminating cue, fires the stopping rule, and exits at the CTA — not at "research more."

## OUTPUT FILE

Save to: [project-folder]/Gigerenzer - Click Architecture/[YYYY-MM] - Single-Cue Spotlight Audit.md
