---
name: norman-mapping-auditor
description: Use when a page's controls, layout, or tab order don't obviously correspond to their effects — audit natural mapping so every action is self-evident without instructions.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Don Norman (The Design of Everyday Things, 1988; Natural Mapping + Four-Type Constraint Architecture) — Click Architecture (Skill 4 of 7)"
interface:
  invoke: "/norman-mapping-auditor"
  calls: []
  called_by: [user, norman-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page layouts, CTAs, and form structures change; mapping quality degrades with every A/B test that shifts element positions without re-auditing correspondence."

fitts_integration:
  feeds_from: fitts-field-intelligence
  feeds_to: norman-mapping-auditor
  shared_data: "Fitts supplies target-size and click-path data; mapping audit uses it to confirm spatial proximity of controls matches their intended effects (close controls = related effects)."

eisenberg_integration:
  feeds_from: norman-mapping-auditor
  feeds_to: eisenberg-micro-action-sequencer
  shared_data: "Mapping audit identifies which controls are mis-sequenced; Eisenberg's micro-action sequencer rebuilds the action chain in the corrected order."

gulf_of_execution_integration:
  feeds_from: norman-gulf-of-execution-reducer
  feeds_to: norman-mapping-auditor
  shared_data: "Gulf-of-execution audit surfaces where visitors can't find the right action; mapping audit diagnoses whether the root cause is spatial mismatch, metaphor failure, or constraint absence."
---

# Norman Mapping Auditor

## LAYER 1: INVARIANTS (Never override.)

1. Natural mapping is the only lever audited here. Do not audit signifier stacks, feedback timing, or gulf-of-evaluation issues — those belong to sibling skills. Stay in lane.
2. Every mapping failure must be traceable to one of Norman's three operational patterns: spatial similarity failure, metaphorical similarity failure, or behavioral similarity failure (The Design of Everyday Things, 1988).
3. Tab order is a mapping. If keyboard tab sequence does not match top-to-bottom / left-to-right reading order, flag it as a mapping violation — not a UI bug.
4. Constraint absence is a mapping failure. A form submit button active before required fields are complete means the control's effect (submission) does not correspond to the visitor's readiness — that is a logical constraint gap, not a styling issue.
5. Cognitive load increase from poor mapping is measurable via Fitts & Seeger (1953): response time rises when stimulus and response locations do not correspond. Threshold: if a visitor must move attention more than 150px between a control and its labeled effect, flag as high-severity mapping break.
6. The Four-Type Constraint Architecture (physical, semantic, cultural, logical) is the remediation toolkit. Every fix recommendation must cite which constraint type closes the mapping gap.
7. Never recommend copy changes to solve a mapping problem. Mapping is spatial and structural. If copy alone would fix it, it was a signifier problem — route to norman-affordance-signifier-auditor.

## LAYER 2: QUALITY GUIDANCE

1. Score each element on all three mapping pattern dimensions (spatial, metaphorical, behavioral). A control can pass spatial but fail metaphorical (e.g., a "down" arrow that expands content upward).
2. Prioritize mapping breaks on the conversion path first (CTA, form fields, checkout steps), then secondary elements. Do not treat a footer nav mapping gap as equal severity to a submit-button mismatch.
3. When diagnosing tab-order violations, test against WCAG 2.1 SC 1.3.2 (Meaningful Sequence) as a secondary check — natural mapping compliance and accessibility compliance overlap here.
4. Every recommendation must include a before/after description precise enough that a developer can implement it without a design meeting.
5. Flag any mapping fix that requires copy change as out-of-scope; note the sibling skill to handle it (norman-affordance-signifier-auditor or norman-gulf-of-execution-reducer).

## PURPOSE

This skill audits a web page for natural mapping failures: places where the spatial layout, metaphorical direction, or behavioral response of controls does not correspond to their effects — forcing visitors to guess, pause, or fail. Norman's principle (1988): "When the relationship between controls and their results is arbitrary, you have to memorize it. When there is a natural relationship, you don't." On a conversion page, any guessing is abandonment.

The skill applies Norman's Natural Mapping framework (three operational patterns) and his Four-Type Constraint Architecture to produce a ranked violation list with concrete spatial/structural fixes — no copy, no signifier work, pure correspondence repair.

Brag line: "Every action on our page is obvious and every click confirms itself."

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written structural description (element-by-element layout)
- The ONE desired action: e.g., "opt-in to email list," "click Buy Now," "complete checkout Step 2"

**Optional (improves diagnosis):**
- Heatmap or click-map data (shows where visitors actually click vs. intended target)
- Session recordings flagging rage-clicks or hover hesitation
- Tab-order trace (browser DevTools → Tab through page, screenshot sequence)
- Funnel drop-off data by step (identifies which mapping break costs most)
- Device split (desktop vs. mobile — spatial mappings shift on small screens)

## EXECUTION PROCESS

### Step 1 — Inventory All Controls on the Conversion Path (5 min)

List every interactive element between page load and desired action completion. Include: CTAs, form fields, dropdowns, checkboxes, progress indicators, navigation, modals, accordions. Exclude purely decorative elements.

Format each as: [Element Name | Type | Position on page (top/mid/bottom, left/center/right)]

### Step 2 — Spatial Similarity Audit

Norman's first pattern: layout of controls must mirror layout of effects.

For each control, identify its effect and ask: **Does the control's position on the page correspond to where the effect occurs or where the visitor's eye needs to go next?**

Threshold flags:
- Control and its effect label separated by >150px = HIGH severity
- Tab order reversal (element B tabbed before element A, but A appears above B visually) = HIGH severity
- Multi-column form where left-column field logically precedes right-column field but tab goes left→right across rows instead of down columns = MEDIUM severity

Score: Pass / Fail / Warning per element.

### Step 3 — Metaphorical Similarity Audit

Norman's second pattern: "up is more," progress fills forward, hierarchy stacks tallest = highest value.

For each directional or hierarchical element ask: **Does the metaphorical direction of this control match the cultural expectation for its effect?**

Check list:
- Progress bars: do they fill left-to-right and increase upward? Flag any right-to-left or downward fill.
- Pricing tiers: is the highest-value tier visually tallest or rightmost? Flag inversion.
- Expandable sections: does clicking an arrow pointing right expand to the right or downward? Arrow direction must predict expansion direction.
- Sliders: does dragging right = more/higher? Flag any left=more configuration.
- Step indicators: does the completed state appear behind/left of current, and next step appear ahead/right? Flag any reversed sequence.

Score: Pass / Fail / Warning per element.

### Step 4 — Behavioral Similarity Audit

Norman's third pattern: interface response mimics natural gesture.

For interactive elements ask: **Does the system's response to the user's gesture match what the gesture physically implies?**

Check list:
- Drag elements: can the visitor drag in the natural direction (right to advance, down to scroll reveal)?
- Click targets: does clicking the center of a button trigger the action, or must the visitor click a specific sub-region (icon vs. label)?
- Form submission: does pressing Enter in the last field submit the form (behavioral expectation from physical keyboard use)?
- Mobile swipe: does swipe-left advance to next item, swipe-right go back (matches native app convention)?

Score: Pass / Fail / Warning per element.

### Step 5 — Four-Type Constraint Gap Analysis

For every Fail or Warning from Steps 2-4, identify which constraint type is absent or misconfigured:

| Type | What it does | Page example |
|------|-------------|--------------|
| Physical | Makes wrong action impossible | Input mask on phone field |
| Semantic | Meaning inhibits error | Red color on destructive action |
| Cultural | Learned signal guides behavior | Green checkmark = valid |
| Logical | Systemic coherence shows state | "2 of 3 steps" indicator |

For each violation: state which constraint type would close the mapping gap and exactly how to implement it.

### Step 6 — Severity Ranking and Fix Queue

Score each violation:

- **CRITICAL** — On the direct conversion path, visitor cannot complete desired action without guessing. Fix before any other change.
- **HIGH** — On conversion path, causes hesitation and measurable rage-click or hover-pause. Fix this sprint.
- **MEDIUM** — Secondary path or supporting element. Fix next sprint.
- **LOW** — Off conversion path. Backlog.

Rank the fix queue by: Severity (desc) × Estimated lift (% of visitors affected) ÷ Implementation effort (1-5 scale).

### Step 7 — Constraint Fix Specs

For each CRITICAL and HIGH item, write a fix spec:

```
Element: [Name]
Violation: [Spatial / Metaphorical / Behavioral] — [1-sentence description]
Constraint fix: [Physical / Semantic / Cultural / Logical]
Implementation: [Exact change — position, size, direction, color, disable state]
Expected outcome: [What visitor now does without guessing]
```

## OUTPUT STRUCTURE

**Section 1 — Mapping Inventory**
Full element list with position and effect correspondence (Step 1 output).

**Section 2 — Violation Register**
Table: Element | Mapping Type Fail | Severity | Constraint Gap

Legend: Sptl=Spatial, Meta=Metaphorical, Bhvl=Behavioral, Phys=Physical, Sem=Semantic, Cult=Cultural, Lgcl=Logical

**Section 3 — Ranked Fix Queue**
Ordered list of fixes, CRITICAL first. Each fix spec formatted per Step 7 template.

**Section 4 — Quick Wins**
3-5 fixes implementable in <1 hour that eliminate the highest-severity mapping breaks on the conversion path.

**Section 5 — Knowledge-in-World Score**
Estimate: what % of conversion-critical information is externalized on the page (field labels visible, step count shown, CTA outcome stated) vs. requires visitor memory? Target: >90% externalized. State current estimate and gap.

## WORKED MINI-EXAMPLE

**Page:** Webinar registration page. Desired action: submit email opt-in form.

**Before — Mapping violations found:**

1. Form has three fields: First Name (left column), Last Name (right column), Email (below, full width). Tab order goes First Name → Email → Last Name (DOM order ≠ visual order). SPATIAL FAIL / CRITICAL. Visitor tabbing to fill form lands in Email before Last Name — expects First → Last → Email.

2. Submit button label: "Submit." Arrow on button points left. METAPHORICAL FAIL / HIGH. "Submit" communicates nothing about next step; left-pointing arrow implies going backward.

3. Required field asterisks appear after field label text: "Email *" — but the asterisk legend ("* Required") appears only at the bottom of the form below the submit button, not visible without scrolling. LOGICAL CONSTRAINT GAP / HIGH. Visitor cannot confirm which fields are required without memory or scrolling.

**After — Mapping fixes applied:**

1. Tab order corrected to match visual sequence: First Name → Last Name → Email. Implemented via `tabindex` attribute. Zero layout change required.

2. Submit button label changed to "Reserve My Spot" (signifier fix — routed to norman-affordance-signifier-auditor). Arrow removed; replaced with forward-progress indicator (right-pointing chevron, cultural constraint). Arrow direction now implies advancement.

3. "(Required)" label placed inline after each required field label, above the field. Asterisk legend removed. Logical constraint now visible at point of use — visitor never needs memory.

**Net effect:** Tab-order rage-clicks eliminated; submit-button hover hesitation reduced (behavioral correspondence restored); form error rate on required fields projected -30% based on inline label placement (Norman: shift knowledge into the world).

## OUTPUT FILE

Save to: [project-folder]/Don Norman - Click Architecture/[YYYY-MM] - Natural Mapping Audit.md
