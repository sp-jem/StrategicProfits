---
name: hick-categorization-architect
description: Use when a page presents more than 7 options flat (nav, catalog, pricing add-ons, form fields) — chunks option sets into labeled categories to cut effective log₂(n) without removing real choice
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "William Hick & Ray Hyman (Hick-Hyman Law 1952–1953; Chunking/Categorization Reduction; Hyman Entropy Extension) — Click Architecture (Skill 3 of 7)"
interface:
  invoke: "/hick-categorization-architect"
  calls: []
  called_by: [user, hick-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Navigation structures, catalog layouts, and pricing tiers change with product updates; entropy calculations go stale within 1–2 sprint cycles"

hick_option_pruning_integration:
  feeds_from: hick-option-pruning-auditor
  feeds_to: hick-progressive-disclosure-designer
  shared_data: "Pruning auditor identifies which options cannot be removed; categorization architect receives that residual set and chunks it; progressive-disclosure designer then stages those chunks across decision screens"

iyengar_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: hick-default-path-designer
  shared_data: "Iyengar's jam-jar conversion data (6 items = 30% conversion vs 24 items = 3%) validates the maximum-per-category threshold; category counts inform default-path designer which parent category to pre-select"

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: hick-single-decision-enforcer
  shared_data: "Kahneman System 1 load benchmarks calibrate how many category labels a user parses without effortful processing; categorization output feeds single-decision-enforcer to confirm each category has exactly one primary response path"
---

# Hick Categorization Architect

## LAYER 1: INVARIANTS (Never override.)

1. **Two-level sequential cost < flat cost.** When n > 7, chunking into C categories of K items is always faster than flat presentation. Total bits = log₂(C+1) + log₂(K+1); flat bits = log₂(n+1). Apply whenever n > 7.
2. **Category count cap: 5–7.** The first-level chunk set must itself obey Hick-Hyman. Capping at 7 keeps first-level bits ≤ log₂(8) = 3.0 bits. If C > 7, you have a meta-chunking problem: chunk the chunks.
3. **Per-category item cap: 6.** Hick-Hyman + Iyengar's jam study converge: 6 items per group yields log₂(7) ≈ 2.8 bits at the second level and maintains purchase conversion. Above 6, second-level entropy rises sharply.
4. **Category labels reduce entropy only if they carry genuine signal.** A label like "Other" or "More" adds a node without reducing Hyman entropy H = -Σ p(i)log₂(p(i)) because users cannot assign a prior probability. Labels must uniquely predict what's inside.
5. **Chunking is not hiding.** Every option in the flat list must appear in exactly one category. No option is removed; effective n is cut, total n is preserved.
6. **Response uncertainty > stimulus uncertainty (Wifall 2015).** The category architecture must also cut the number of response actions per category view, not just the number of visible items. Each category landing/panel should surface one primary CTA.
7. **Chunk the response path, not just the display.** If a category expansion reveals a sub-list with its own competing CTAs, you have not solved the response-uncertainty problem — you have deferred it one level. Each level must end in one expected action.

## LAYER 2: QUALITY GUIDANCE

1. **Entropy-test each label.** After naming categories, ask: "Can a first-time visitor assign ≥70% probability to which item belongs in which category?" If not, rename or restructure.
2. **Verify the math is better.** Compute flat bits and chunked bits (formula in Step 3). Only ship the chunked architecture if it reduces total bits by ≥0.5 bits at the primary decision point.
3. **One recommended category.** Apply Hyman's probability-weighting principle: badge one category as "Most Popular" or "Start Here" so its p(i) dominates the entropy sum, lowering H below the uniform-distribution baseline.
4. **Match cognitive chunks to user mental models.** Use card-sort data, search query clusters, or support ticket language to name categories. Imposed categories that contradict user mental models increase, not decrease, effective entropy.
5. **Measure time-to-first-click before and after.** Hick-Hyman predicts chunking will reduce time-to-first-click on the primary CTA by a calculable factor. If session-recording data post-launch shows no change, the categories are not reducing Hyman entropy — they are decorative groupings.

## PURPOSE

This skill operationalizes the Hick-Hyman Chunking/Categorization Reduction framework on a live web page. When a page cannot remove options outright (product catalog, feature comparison, navigation, pricing add-ons), the architect computes the flat decision cost in bits, designs a two-level chunk architecture that mathematically lowers that cost, labels each category so it carries genuine Hyman entropy reduction, and prescribes the response-action structure within each chunk.

**Brag line:** "We cut decision time by removing options, and we can prove the math."

The mechanism: 30 flat options = log₂(31) ≈ 4.95 bits. Five categories of 6 = log₂(6) + log₂(7) ≈ 2.58 + 2.81 = 5.39 bits raw BUT users process the two levels sequentially, with the first-level decision completed in ~0.25 seconds before the second begins. Empirical RT savings: first-level decision at 5 categories ≈ 0.39 s vs flat 30 ≈ 0.77 s. That 0.38-second reduction is a measurable predictor of drop-off reduction. This is not intuition — it is the law.

## INPUT REQUIREMENTS

**Required:**
- The page (URL, screenshot, or written description)
- The ONE desired action this page must drive (e.g., "click Add to Cart," "start free trial," "submit lead form")
- The full flat option list as it currently appears (copy-paste the nav items, product tiles, form fields, or pricing features)

**Optional but high-signal:**
- Session-recording time-to-first-click data on the current primary CTA
- Drop-off rates at this page in the funnel
- Any existing card-sort, search-query, or support-ticket data
- Number of options users typically select (for probability weighting)
- Current A/B test results, if any

## EXECUTION PROCESS

**Step 1 — Inventory the flat option set.**
Extract every option currently visible at this decision point. Count n. Include navigation items, CTA variants, form fields, filter options, pricing tiers, or catalog items depending on page type. Note any options that are visually identical in weight (competing CTAs count as competing response options, not just competing stimuli).

**Step 2 — Compute flat decision cost.**
Flat bits = log₂(n + 1)

| n (options) | Flat bits | Approx RT delta (×0.155 s/bit) |
|-------------|-----------|-------------------------------|
| 4           | 2.32      | 0.36 s                        |
| 7           | 3.00      | 0.47 s                        |
| 12          | 3.70      | 0.57 s                        |
| 20          | 4.39      | 0.68 s                        |
| 30          | 4.95      | 0.77 s                        |

Record: current flat bits = ___. Target: reduce by ≥ 0.5 bits at the first-level decision.

**Step 3 — Design the two-level chunk architecture.**
Find C (category count) and K (items per category) such that:
- C ≤ 7 (first-level Hick compliance)
- K ≤ 6 (second-level Iyengar + Hick compliance)
- C × K ≥ n (every option placed)

Chunked bits = log₂(C + 1) + log₂(K_avg + 1)

Example: n = 24 options → C = 4 categories × K = 6 items
Chunked bits = log₂(5) + log₂(7) = 2.32 + 2.81 = 5.13 bits total BUT first-level decision = 2.32 bits (vs 4.58 flat bits for n=24). First decision is 49% cheaper. That is the lever.

If options split unevenly across categories, use K_max for the worst-case second-level calculation.

**Step 4 — Name each category for Hyman entropy compliance.**
For each proposed category:
a. Write the label candidate.
b. Ask: "Can a first-time visitor predict ≥70% of items in this group from the label alone?"
c. If no: the label fails entropy reduction. It adds a node without lowering H. Rename or reorganize.
d. Good labels: outcome-oriented ("Grow Revenue," "Fix Retention"), audience-oriented ("For Teams," "For Solo Founders"), stage-oriented ("Getting Started," "Advanced"), format-oriented ("Templates," "Live Sessions").
e. Bad labels: "Misc," "Other," "More," vague adjectives ("Great Options"), or exact duplicates of the product names inside.

**Step 5 — Apply Hyman probability-weighting to one category.**
Badge the category containing the highest-probability desired path as "Most Popular," "Recommended," or "Start Here." Per Hyman's entropy formula, when p(i) for that category rises toward 0.8, H collapses from the uniform-distribution max toward zero regardless of the other categories' presence. This is the entropy-suppression effect that makes highlighted options convert faster even inside a larger set.

**Step 6 — Set response-action structure within each category.**
Per Wifall (2015): response uncertainty is the dominant coefficient. Each category view/panel must present:
- One primary CTA (the desired action for users in this category)
- At most one secondary escape link ("Compare all" or "See details")
- No competing primary buttons at the same visual weight

**Step 7 — Diagnose current page against architecture.**
Score each dimension on a 1–3 scale (1=failing, 2=partial, 3=compliant):

| Dimension        | Scoring rule                                         |
|------------------|------------------------------------------------------|
| Flat n           | 1 if n>12, 2 if 8–12, 3 if ≤7                       |
| Chunk levels     | 1 if none, 2 if 1 level but C>7, 3 if compliant     |
| Label entropy    | 1 if labels non-predictive, 2 if partial, 3 if pass  |
| Recommended badge| 1 if absent, 2 if present but wrong item, 3 if correct|
| Response actions | 1 if ≥3 CTAs/panel, 2 if 2, 3 if 1 per panel        |

Score ≤ 10 = rebuild required. 11–13 = targeted fix. 14–15 = optimize copy only.

**Step 8 — Produce the before/after specification.**
For each changed element, state: current state → prescribed state + the bit-reduction rationale.

## OUTPUT STRUCTURE

**Section 1: Flat Option Inventory**
Full list of current options; n count; flat-bit calculation; RT delta estimate.

**Section 2: Chunk Architecture Design**
Table: Category label | Items assigned | Item count K | Hyman entropy pass/fail

**Section 3: Entropy Audit**
Label-by-label entropy test. Flag any label that fails the 70% predictability test. Prescribe replacement label.

**Section 4: Hyman Probability-Weighting Recommendation**
Which category gets the badge, why (it contains the primary desired-action path), and predicted H reduction.

**Section 5: Response-Action Prescription**
Per category: which CTA is primary, what secondary link (if any) is permitted, what must be removed.

**Section 6: Scoring Scorecard**
The 5-dimension 1–3 table. Total score. Verdict.

**Section 7: Before → After Spec**
Element-by-element: current → prescribed, with bit-reduction delta per change.

**Section 8: Measurement Targets**
Time-to-first-click benchmark (current vs projected). A/B test variable prescription. Leading indicator thresholds.

## WORKED MINI-EXAMPLE

**Page:** SaaS pricing page. 18 add-on features listed flat below three pricing tiers. Desired action: "Start Free Trial" on the Pro tier.

**Before:**
- 18 add-on features displayed as a flat vertical list
- Flat bits = log₂(19) = 4.25 bits
- Time-to-first-click on CTA: 14 seconds (session recording)
- Conversion: 6.2%

**Chunk architecture:**
- Category A: "Core Productivity" — 6 items (scheduling, templates, reminders, exports, integrations, API)
- Category B: "Team Collaboration" — 6 items (roles, comments, sharing, notifications, audit log, SSO)
- Category C: "Analytics & Reporting" — 6 items (dashboards, custom reports, funnels, cohorts, exports, white-label)
- C = 3, K = 6
- Chunked first-level bits = log₂(4) = 2.0 bits (vs 4.25 flat) — 53% reduction at first decision
- Badge "Core Productivity" as "Most Used" — it contains the 3 features mentioned in the headline

**Response-action fix:**
Each accordion panel reveals its 6 items + one CTA: "Start Free Trial — includes all [Category] features." Secondary escape: "See full feature list." Competing "Contact Sales" button removed from panel level (moved to page footer only).

**After (projected):**
- First-level decision bits: 2.0 (from 4.25) — 53% reduction
- Estimated time-to-first-click: ~8 seconds (from 14)
- Expected conversion lift: 15–25% (consistent with Hick-Hyman RT-to-conversion correlation in SaaS pricing literature)

**Measurement:** A/B test — variant with 3 chunked accordions vs control flat list. Primary metric: time-to-CTA-click. Secondary: trial start rate. Run 2 weeks minimum.

## OUTPUT FILE

Save to: [project-folder]/Hick-Hyman - Click Architecture/[YYYY-MM] - Categorization Architect Audit.md
