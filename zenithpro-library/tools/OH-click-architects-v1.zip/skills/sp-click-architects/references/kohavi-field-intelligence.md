---
name: kohavi-field-intelligence
description: Meta-synthesis across all Kohavi page-action skills + the Click Architects network. Produces the single highest-confidence conversion move after all 6 experiment-validity tools have spoken.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Ronny Kohavi — Trustworthy Online Controlled Experiments (2020); A/B Testing; OEC; SRM — Field Intelligence (Skill 7 of 7)"
interface:
  invoke: "/kohavi-field-intelligence"
  calls: [kohavi-oec-definer, kohavi-experiment-validity-auditor, kohavi-srm-guard, kohavi-twyman-anomaly-detector, kohavi-test-prioritization-designer, kohavi-rollout-decision-architect]
  called_by: [user, click-architects]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Audience composition, traffic patterns, and competitive dynamics shift the OEC denominator and SRM baseline continuously. Experiment outputs older than 45 days may reflect populations or page states no longer live."

pirolli_integration:
  feeds_from: [pirolli-field-intelligence]
  feeds_to: [pirolli-scent-trail-auditor]
  shared_data: "Pirolli maps information-scent strength between page elements and desired destinations. Kohavi quantifies whether a scent change actually moved the needle. Combined: Pirolli diagnoses WHICH scent signal to strengthen; Kohavi validates the true causal impact via controlled experiment rather than analyst intuition. Without Kohavi, every scent fix is opinion. Without Pirolli, every test is blind to the mechanism."

eisenberg_integration:
  feeds_from: [eisenberg-field-intelligence]
  feeds_to: [eisenberg-micro-action-sequencer]
  shared_data: "Eisenberg maps the persuasion architecture (buying modality × conversion trinity). Kohavi runs the validity check on whether that architecture change produced a real OEC lift. Combined: Eisenberg says which persuasion lever to pull; Kohavi's OEC + SRM framework confirms the pull was real. The synthesis kills HiPPO-driven persuasion decisions — every architecture change becomes a measurable hypothesis."

fitts_integration:
  feeds_from: [fitts-field-intelligence]
  feeds_to: [fitts-target-cost-auditor]
  shared_data: "Fitts quantifies motor-cost per click (target size × distance). Kohavi experiments confirm whether reducing motor-cost actually increases the action rate — and by how much in revenue terms. Combined: Fitts identifies the highest-cost click on the page; Kohavi's OEC translates cost reduction into dollars. Motor cost × OEC weight = true conversion leverage per CTA. Fitts finds the candidate; Kohavi validates the change."

hick_integration:
  feeds_from: [hick-field-intelligence]
  feeds_to: [hick-option-pruning-auditor]
  shared_data: "Hick quantifies decision-load cost (log2 of choices). Kohavi validates whether reducing that load moved the OEC. Combined, they form a Total Click-Cost model: Hick's decision milliseconds + Fitts's motor milliseconds = full cognitive + physical cost of a conversion action. Kohavi experiments confirm which cost component dominated. Removing the wrong cost (cognitive vs. motor) is invisible without OEC measurement."

norman_integration:
  feeds_from: [norman-field-intelligence]
  feeds_to: [norman-affordance-signifier-auditor]
  shared_data: "Norman diagnoses gulfs of execution and evaluation — interface elements visitors cannot interpret correctly. Kohavi converts those diagnosis findings into controlled variants. Combined: Norman identifies the signifier failure; Kohavi's experiment validates the re-signaled element against guardrail metrics (latency, error rate) and OEC. Norman alone produces redesign. Norman + Kohavi produces redesign with causal proof."

nielsen_integration:
  feeds_from: [nielsen-field-intelligence]
  feeds_to: [nielsen-heuristic-evaluation]
  shared_data: "Nielsen's heuristic evaluation surfaces usability violations (visibility, error prevention, recognition). Kohavi's SRM guard and experiment-validity audit ensure that fixing those violations didn't introduce measurement contamination. Combined: Nielsen finds what's broken from a usability standpoint; Kohavi prevents the fix from generating a false positive (SRM, bot-filter drift, redirect error). Nielsen diagnoses; Kohavi verifies the cure is real."

laja_integration:
  feeds_from: [laja-field-intelligence]
  feeds_to: [laja-friction-telemetry-reader]
  shared_data: "Laja's ResearchXL and friction telemetry identify the highest-pain points via qualitative + quantitative user research. Kohavi's OEC framework converts those findings into testable hypotheses with pre-defined practical significance thresholds. Combined: Laja identifies the friction point worth testing; Kohavi's Six-Scenario Launch Matrix decides whether the experiment result actually justifies shipping. Research without OEC is guessing. OEC without research is testing the wrong thing."

gigerenzer_integration:
  feeds_from: [gigerenzer-field-intelligence]
  feeds_to: [gigerenzer-risk-literacy-reframer]
  shared_data: "Gigerenzer's fast-and-frugal heuristics show which single cue dominates visitor decisions. Kohavi's Rule of Thumb 2 (only 1-in-500 ideas are breakthroughs; p≈0.05 = ~3% true-positive probability) calibrates overconfidence in any winning test. Combined: Gigerenzer identifies the recognition cue to test; Kohavi prevents premature declaration of a winner. The synthesis is statistical humility applied to conversion optimization."

eyal_integration:
  feeds_from: [eyal-field-intelligence]
  feeds_to: [eyal-hook-loop-designer]
  shared_data: "Eyal's Hook model designs the trigger-action-reward-investment loop for engagement. Kohavi's Twyman's Law anomaly detection catches suspiciously large reward-lift claims. Combined: Eyal designs the retention loop; Kohavi flags when the engagement metric spike is too good to be true (bot traffic, novelty effect, SRM). Without Kohavi's anomaly check, hook-loop 'wins' routinely evaporate at scale."

brignull_integration:
  feeds_from: [brignull-field-intelligence]
  feeds_to: [brignull-dark-pattern-scanner]
  shared_data: "Brignull identifies dark patterns — manipulative friction engineered into page flows. Kohavi's guardrail metric framework flags when 'conversion gains' come at the cost of trust metrics (unsubscribe rate, support tickets, return rate). Combined: Brignull audits the ethics of the conversion method; Kohavi's OEC formula (Revenue - s × unsubscribe_lifetime_loss) / n makes the cost of dark patterns visible in the experiment scorecard. Good OEC design kills dark patterns automatically."

goward_integration:
  feeds_from: [goward-field-intelligence]
  feeds_to: []
  shared_data: "Goward (WiderFunnel LIFT model) prioritizes conversion elements by Value Proposition, Relevance, Clarity, Anxiety, Distraction, and Urgency. Kohavi's Test Prioritization Designer scores the same candidates by OEC impact × SRM-clean probability × traffic power. Combined: LIFT gives the qualitative reason to test; Kohavi's prioritization framework gives the statistical power check before committing resources. LIFT without power analysis leads to under-powered tests that produce noise."

fogg_integration:
  feeds_from: [fogg-field-intelligence]
  feeds_to: [fogg-prompt-designer]
  shared_data: "Fogg's B=MAP model engineers which behaviors are prompted at peak motivation × minimum ability cost. Kohavi's Trigger Analysis (triggered experimentation) ensures only the affected sub-population is measured — preventing dilution of true treatment effects. Combined: Fogg designs the optimal prompt moment; Kohavi's triggered analysis ensures the experiment measures precisely who was touched. Fogg without triggering over-dilutes results. Kohavi triggering without Fogg misses the behavioral mechanism."

cialdini_integration:
  feeds_from: [cialdini-field-intelligence]
  feeds_to: [cialdini-ethical-influence-system-designer]
  shared_data: "Cialdini's influence principles (social proof, scarcity, authority) generate testable page-element hypotheses. Kohavi's SRM guard and validity audit ensure the experiment measuring those changes is trustworthy. Combined: Cialdini supplies the influence lever; Kohavi confirms the lever moved the OEC by more than practical significance threshold. Without Kohavi's Six-Scenario Launch Matrix, a statistically significant social-proof test might not cross the practical significance bar and still gets shipped."

kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: [kahneman-framing-engineer]
  shared_data: "Kahneman's prospect theory, framing effects, and peak-end rule generate specific page-copy and UX hypotheses. Kohavi's Slowdown Experiment Methodology proves that seemingly small changes (a color, a word, a delay) can have non-linear revenue impact. Combined: Kahneman predicts WHICH cognitive shortcuts to target; Kohavi's Rule of Thumb 1 (small changes = big impact) calibrates how seriously to test even cosmetic framing variants. A $10M/year color change at Bing is the joint proof of concept."

thaler_integration:
  feeds_from: [thaler-field-intelligence]
  feeds_to: [thaler-nudge-auditor]
  shared_data: "Thaler's choice architecture and default design create structural nudges. Kohavi's Progressive Deployment Strategy ramps those default changes at 2% → 100% to catch guardrail violations before full exposure. Combined: Thaler engineers the default; Kohavi's rollout protocol ensures the default change doesn't degrade trust metrics (return rate, support volume) at scale. Every Thaler nudge becomes a Kohavi ramp, not a big-bang launch."

iyengar_integration:
  feeds_from: [iyengar-choice-set-auditor]
  feeds_to: []
  shared_data: "Iyengar's choice overload research determines the optimal choice-set size for conversion. Kohavi's metric taxonomy (goal / driver / guardrail / debug metrics) tracks the full downstream cost of choice proliferation — not just conversion rate but return rate, satisfaction, and repeat purchase. Combined: Iyengar specifies the optimal number of options; Kohavi's guardrail framework catches when reducing choice options increases short-term conversion but damages long-term revenue. OEC captures both."
---

# Kohavi Field Intelligence

---

## LAYER 1: INVARIANTS (Never override.)

1. **Field Intelligence is synthesis, not summary.** This skill does NOT recap what individual skills found. It identifies PATTERNS ACROSS skills — convergence zones, contradictions, amplification opportunities, and the single highest-leverage intervention. A report that recaps six tool outputs has failed.

2. **Convergence detection is mandatory.** When 3+ Kohavi skills point at the same page element, experiment design gap, or OEC problem: that's a convergence zone. Name it. Convergence zones are the highest-confidence findings.

3. **Contradictions must be surfaced, not hidden.** When the OEC Definer says maximize revenue and the Twyman Anomaly Detector flags that revenue spike as suspicious: that tension is data. Resolve by identifying which force dominates in this specific context.

4. **The Single Move is non-negotiable.** One highest-leverage page change. Not options. Not a list. ONE move that addresses the most convergence zones simultaneously and is supported by a valid OEC.

5. **The Mirror is non-negotiable.** The business's own experiment-design biases must be examined — where HiPPO-driven decisions replace controlled evidence, where confirmation bias shapes variant selection, where stat sig is confused with practical significance.

6. **Cross-system intelligence is the highest-value section.** Every other Click Architect's finding becomes a testable hypothesis under Kohavi's framework. That is the core claim of this skill: Kohavi converts opinion into evidence.

7. **Freshness gate: 45 days.** Flag any individual Kohavi skill output older than 45 days as potentially stale.

---

## LAYER 2: QUALITY GUIDANCE

8. **Name the convergence zones.** Give each pattern a memorable label (e.g., "The Metric Void" for convergence around missing OEC; "The SRM Shadow" for convergence around instrumentation distortion).

9. **Quantify where Kohavi's benchmarks apply.** Use the actual numbers from the dossier: 100ms delay = -1% revenue (Amazon); 250ms = -1.5% (Bing); color palette = +$10M/yr (Bing); 70-90% of expert ideas fail; p≈0.05 = ~3% true-positive probability.

10. **The 90-Day Projection must be specific.** Not "results should improve." Instead: "If The Single Move (OEC redefinition + triggered analysis) is implemented in week 1, by day 30 the test false-positive rate should drop from ~40% (10 metrics, no adjustment) to <5%. By day 90, winning tests should have a 3× higher actual implementation success rate."

---

## PURPOSE

**Brag:** "We know our winner is real, not a 1-in-20 false positive."

Individual Kohavi skills each enforce one guard on a page experiment: the OEC Definer locks the decision variable; the Validity Auditor checks threats to internal validity; the SRM Guard catches traffic allocation contamination; the Twyman Anomaly Detector flags results too good to be true; the Test Prioritization Designer sequences the queue by power-adjusted OEC impact; the Rollout Decision Architect applies the Six-Scenario Launch Matrix before shipping.

Field Intelligence goes one level beyond. It finds where all six guards converge on the same page problem, detects contradictions that reveal competing forces, identifies the amplification stack (OEC + SRM + Twyman + Prioritization = experiment immune system), delivers The Single Move, holds up The Mirror to the business's own confirmation bias, and — most critically — converts every other Click Architect's qualitative finding into a Kohavi-validated, OEC-backed experiment. The result is not a testing calendar. It is page-intelligence with causal proof.

---

## INPUT REQUIREMENTS

**Required:** Outputs from at least 4 of 6 individual Kohavi skills, all run against the same page and desired action.

**Optimal:** All 6 Kohavi skill outputs + Field Intelligence outputs from Pirolli, Eisenberg, Fitts, Hick, Norman, Nielsen, Laja, Gigerenzer, Eyal, Brignull, Fogg, Cialdini, Kahneman, Thaler, Iyengar.

**Also accept:** Performance data (conversion rate, revenue/user, latency), analytics exports, existing experiment logs.

---

## EXECUTION PROCESS

### Step 1: Component Synthesis

For each available Kohavi skill output:

| Field | Content |
|-------|---------|
| Skill | Name + run date |
| Age | Current (≤45d) / Aging (46-60d) / Stale (>60d) |
| Finding | 3-5 key conclusions |
| Flag | Any validity threat surfaced |
| Conf | High / Medium / Low |

### Step 2: Convergence Detection

Cross-skill pattern matching. Scoring:
- 2 skills: Notable alignment
- 3 skills: **Convergence zone — name it**
- 4 skills: Strong convergence
- 5-6 skills: Critical convergence (act immediately)

**For each convergence zone:**
- **Name:** Memorable label
- **Contributing skills:** Which tools pointed here
- **Shared finding:** What each found
- **System implication:** Why this pattern matters beyond any single tool
- **Implied intervention:** What the convergence demands on the page

**Common Kohavi convergence patterns to detect:**
- *The Metric Void:* OEC Definer + Validity Auditor + Prioritization Designer all find no composite OEC — tests are being decided on single metrics. Every test is gaming-vulnerable.
- *The SRM Shadow:* SRM Guard + Twyman Detector + Validity Auditor all flag the same experiment — the traffic split is contaminated, results are inverted, scorecard must be hidden.
- *The Power Gap:* Prioritization Designer + Rollout Architect + Validity Auditor converge on insufficient sample size — test is underpowered before it starts, any result is noise.
- *The Latency Blind Spot:* Validity Auditor + Twyman Detector + OEC Definer all surface performance degradation not captured in the OEC — a conversion gain is hiding a speed cost.
- *The Guardrail Breach:* Rollout Architect + OEC Definer + Validity Auditor converge on a guardrail metric violation that the primary metric masked — the winner is actually a loser.

### Step 3: Contradiction Detection

Cross-skill conflict identification. Common Kohavi contradictions:

- OEC Definer says maximize revenue per user ↔ Rollout Architect flags unsubscribe-rate guardrail breached (Amazon email case: >50% of campaigns net-negative once lifetime loss included)
- Prioritization Designer ranks test A as highest expected value ↔ SRM Guard invalidates test A's prior results — power estimate is corrupted data
- Twyman Detector clears an anomaly ↔ Validity Auditor finds a Simpson's Paradox threat in the same segment breakdown
- Rollout Architect recommends launch (Scenario 2) ↔ Validity Auditor identifies a novelty effect — the gain will decay within 2 weeks

**For each contradiction:** State the tension, why both tools are correct in their own frame, and the resolution specific to this page context.

### Step 4: Amplification Opportunities

Combined Kohavi interventions that create outsized certainty:

- **Experiment Immune System:** OEC composite + triggered analysis + SRM check + Twyman screen = test that cannot produce a false positive without detection
- **Power-First Queue:** Prioritization Designer power check before any variant is designed = eliminate under-powered tests before spending traffic
- **Progressive Rollout + Guardrail Stack:** 2% ramp + latency guardrail + revenue guardrail + unsubscribe guardrail = ship confidently without big-bang risk
- **Latency-First Protocol:** Slowdown experiment first → quantify latency-to-revenue slope → all subsequent tests control for speed → OEC includes latency as a constrained variable

### Step 5: The Single Move

ONE recommendation addressing the most convergence zones.

- **What:** The specific page change (name the element, the direction, the variant)
- **Why this is THE move:** Which convergence zones it resolves
- **Mechanism:** Which Kohavi framework governs (OEC, SRM, Twyman, Trigger Analysis, etc.)
- **Implementation:** Sequential steps — OEC definition → power calculation → variant design → triggered population → SRM check at 24h → Twyman screen at 48h → Scenario Matrix decision
- **Expected outcome:** Specific metric change with Kohavi benchmark reference (e.g., "If latency is the primary driver, a 100ms reduction should produce 0.6-1.0% revenue increase per Bing benchmarks")
- **What it does NOT address:** Honest limitations

**Worked example (checkout page, desired action: complete purchase):**

Before: Page has coupon code field above credit card entry. Test shows +3% CVR. OEC = CVR only. SRM = clean. Ship it.

After (Kohavi immune system applied): OEC Definer adds revenue/user AND unsubscribe equivalent (return rate). Twyman flags the +3% CVR as anomalously large for a form-field test. Validity Auditor finds Simpson's Paradox: mobile users (60% of traffic) show -2% CVR; desktop drives the aggregate +3%. Rollout Architect applies Scenario 3 (stat sig, not pract sig on corrected OEC). Decision: do NOT ship. Single Move: remove the coupon field entirely (per Bing coupon case: field below credit card = -2.8% revenue; popup = -7.8%; absence = baseline).

### Step 6: The Mirror

Where the business's own experiment-design biases operate:

- **HiPPO Inertia:** The highest-paid person's opinion overrides experiment results. Present the Six-Scenario Matrix as a forcing function — the matrix, not the VP, makes the launch decision.
- **Metric Proliferation:** Teams track >10 metrics per experiment. At 10 independent metrics, the probability that at least one is significant by chance = 40%. Enforce the 5-metric cap from Kohavi's Metric Taxonomy.
- **p-value Fetishism:** Declaring winners at p<0.05 without practical significance threshold. Rule of Thumb 2: when p≈0.05, the probability of a true effect is ~3.1%. Pre-define the minimum detectable effect BEFORE seeing data.
- **Sample Size Optimism:** Launching with traffic below the ~200,000 minimum for detecting 5% effects. The Prioritization Designer's power check must run before any test is approved.
- **Big-Bang Launches:** Shipping 100% instead of using progressive 2% ramp. A single SRM event at full traffic cannot be rolled back.
- **Single-Metric OEC:** Revenue alone, CTR alone, or signup rate alone — without guardrails. The coupon field experiment is the canonical case: CVR up, revenue down.

### Step 7: Cross-System Intelligence

Each Click Architect thinker's finding becomes a Kohavi-testable hypothesis. That is the structural claim of this integration.

**Kohavi × Pirolli:** Pirolli identifies weak information-scent links. Kohavi's Triggered Analysis isolates only the users who encountered the scent element — preventing dilution of the true treatment effect by visitors who never reached that link. Scent strengthening becomes measurable at precise OEC impact, not analyst estimate.

**Kohavi × Eisenberg:** Eisenberg's persuasion architecture (buying modality matrix) generates specific variant hypotheses. Kohavi's Rule of Thumb 2 (70-90% fail) calibrates which architecture changes are worth testing vs. which need more qualitative pre-work. The synthesis: prioritize tests by Eisenberg modality fit × Kohavi traffic power — high fit + high power = first in queue.

**Kohavi × Fitts + Hick (Total Click Cost):** Fitts gives motor-cost per CTA (size × distance). Hick gives decision-cost (log2 of choices). Kohavi experiments validate which cost component drove conversion delta. Total Click Cost = motor ms + decision ms. Reducing the wrong cost produces no OEC lift — Kohavi's experiment reveals which cost dominated.

**Kohavi × Norman:** Norman diagnoses gulf-of-execution failures (visitor cannot figure out how to act). Kohavi's guardrail framework checks that re-signaling an affordance doesn't degrade latency or error rates. Norman says what to fix; Kohavi confirms the fix is safe and causal.

**Kohavi × Nielsen:** Nielsen's heuristics surface visibility and error-prevention failures. Kohavi's SRM Guard ensures the experiment fixing those failures has clean traffic allocation — heuristic fixes that introduce redirect errors will produce SRM, invalidating the experiment.

**Kohavi × Laja:** Laja's ResearchXL framework produces the friction hypothesis. Kohavi's Prioritization Designer scores that hypothesis by OEC impact × power × SRM-clean probability. Only hypotheses that survive both the qualitative friction audit AND the quantitative power check enter the test queue.

**Kohavi × Gigerenzer:** Gigerenzer's recognition heuristic identifies the single dominant cue visitors use to decide. Kohavi's Rule of Thumb 3 (your mileage WILL vary — external case studies are idea generators only) prevents applying Gigerenzer findings from other industries without testing. Every recognition cue claim requires a controlled experiment on THIS page with THIS audience.

**Kohavi × Eyal:** Eyal's variable-reward mechanism can produce anomalously high engagement spikes. Kohavi's Twyman Anomaly Detector flags these: if a hook-loop intervention shows >15% engagement gain in week 1, suspect novelty effect. Kohavi's Trigger Analysis separates users who entered the hook loop from those who didn't — preventing dilution and novelty contamination simultaneously.

**Kohavi × Brignull:** Brignull identifies dark patterns. Kohavi's OEC formula — (Revenue - s × unsubscribe_lifetime_loss) / n — makes the long-term cost of dark patterns visible in the experiment scorecard. A dark-pattern test that shows short-term CVR gain but elevated churn-equivalent will fail the guardrail and be killed before launch. OEC is the ethical forcing function.

**Kohavi × Fogg:** Fogg's B=MAP model identifies the behavior to engineer. Kohavi's Triggered Experimentation analyzes only users who received the prompt — not all page visitors. If 10% of users see a Fogg-optimized CTA and show 10% improvement, the aggregate OEC impact is ~1%, not 10%. Fogg's mechanism + Kohavi's segment dilution principle = accurate ROI forecast before committing to a build.

**Kohavi × Cialdini:** Cialdini's influence principles generate the copy and social-proof variants. Kohavi's Six-Scenario Launch Matrix decides which results justify shipping. A social-proof test that reaches statistical significance but doesn't cross the pre-defined practical significance threshold (Scenario 3) gets killed, not shipped. The matrix, not the Cialdini win, makes the decision.

**Kohavi × Kahneman:** Kahneman's framing effects and loss aversion predict which copy variants should outperform. Kohavi's Rule of Thumb 1 (small changes can have big impact) prevents underestimating cosmetic copy variants — a single word change framing a loss vs. a gain can move revenue by +$10M/yr at Bing scale. Kahneman identifies the frame; Kohavi validates the magnitude.

**Kohavi × Thaler:** Thaler's defaults and nudges are structural page changes. Kohavi's Progressive Deployment ramps those structural changes at 2% → 100%, catching guardrail degradation before full exposure. Every Thaler default-change proposal gets a Kohavi ramp plan before launch, not a big-bang ship.

**Kohavi × Iyengar:** Iyengar's choice-reduction findings predict that fewer options increase conversion. Kohavi's Metric Taxonomy (goal / driver / guardrail / debug) tracks the downstream cost: does fewer choices increase short-term CVR but increase return rate (quality mismatch)? The guardrail catches what the primary metric hides.

**Cross-system convergence (highest-confidence zone):** When Pirolli, Eisenberg, Norman, and Laja all identify the same page element as friction — and Kohavi's power check confirms sufficient traffic to detect a 5% OEC effect — that test is the highest-certainty investment in the entire optimization queue. Four qualitative systems + one quantitative power check = near-certain priority.

### Step 8: Coherence Map

Score the overall experiment design coherence (1-10 each):

| Dimension | Score | Notes |
|-----------|-------|-------|
| Internal | ? | Do all 6 Kohavi tools agree? |
| Cross-sys | ? | Do Click Architects + Kohavi align? |
| Implement | ? | Clear path from current to tested? |
| Resilience | ? | Survives SRM, Twyman, novelty? |

**Coherence gaps:** Where scores are lowest and what would raise them (e.g., Internal=4 because OEC not defined → define OEC before any test proceeds).

### Step 9: 90-Day Conversion Projection

**Days 1-30:**
- Define composite OEC (revenue/user + guardrail metrics)
- Run SRM baseline A/A test to validate instrumentation
- Power-calculate the top 3 candidates from Prioritization Designer
- Launch highest-power test at 10% traffic with 2% progressive ramp
- Decision point at day 15: if SRM detected → halt and investigate instrumentation before proceeding

**Days 31-60:**
- First test reaches statistical significance; apply Six-Scenario Matrix
- Ship only Scenario 2 or Scenario 5 results
- Begin second test in queue with Trigger Analysis in place
- Guardrail metrics should be stable (latency within ±5ms, error rate flat)
- Expected: 1-2 validated page changes live

**Days 61-90:**
- Third test in queue running
- OEC trend should show cumulative improvement from shipped changes
- Twyman screen has caught at least 1 anomaly (if not, the screen is misconfigured)
- Coherence Map re-scored; gaps addressed
- Predicted bottleneck: SRM causes at scale (bot filtering, redirect logic) — investigate 40+ SRM cause taxonomy proactively

---

## OUTPUT STRUCTURE

### Experiment Intelligence Briefing

**Section 1: Input Status & Freshness**
All 6 Kohavi skill outputs with freshness assessment and validity flags.

**Section 2: Convergence Map**
Named convergence zones with contributing skills and implied page interventions.

**Section 3: Contradiction Analysis**
Resolved tensions — state which force dominates in this page context.

**Section 4: Amplification Opportunities**
Stacked Kohavi protocols (immune system, power-first, progressive ramp + guardrails).

**Section 5: The Single Move**
One highest-leverage page change with OEC definition, power check, and Six-Scenario outcome path.

**Section 6: The Mirror**
Business's own experiment-design biases — HiPPO inertia, metric proliferation, p-value fetishism.

**Section 7: Cross-System Intelligence**
Each Click Architect finding converted into a Kohavi-testable hypothesis with OEC mapping.

**Section 8: Coherence Map**
Scored 4-dimension assessment with gap analysis.

**Section 9: 90-Day Conversion Projection**
Specific, milestone-bound predictions tied to Kohavi's benchmark numbers.

---

## OUTPUT FILE

Save complete briefing to:
`[project-folder]/Ronny Kohavi - Field Intelligence/[YYYY-MM] - Experiment Intelligence Briefing.md`
