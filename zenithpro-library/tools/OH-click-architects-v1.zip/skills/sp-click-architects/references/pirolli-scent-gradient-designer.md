---
name: pirolli-scent-gradient-designer
description: Use when a page has a conversion goal but visitors drop before acting — designs an increasing-scent path so every step smells more like the goal than the last.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peter Pirolli & Stuart Card (Information Foraging Theory 1999; SNIF-ACT 2007) — Click Architecture (Skill 5 of 7)"
interface:
  invoke: "/pirolli-scent-gradient-designer"
  calls: []
  called_by: [user, pirolli-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic source vocabulary drifts; ad copy rotates; search query sets shift — scent-match assumptions expire within one campaign cycle."

pirolli_scent_trail_auditor_integration:
  feeds_from: pirolli-scent-trail-auditor
  feeds_to: []
  shared_data: "Scent-trail audit identifies which links leak scent; this skill uses those leak points as the design brief for gradient reconstruction."

kahneman_integration:
  feeds_from: []
  feeds_to: kahneman-field-intelligence
  shared_data: "Trigger-word density decisions intersect with System 1 fluency (Kahneman): high-scent pages are also low cognitive load; share vocabulary audit output with kahneman for dual validation."

fogg_integration:
  feeds_from: fogg-field-intelligence
  feeds_to: []
  shared_data: "Fogg's motivation + ability axes map onto IFT's information value / within-patch cost axes; share path-step ability scores to prioritize where scent boosts are highest leverage."
---

# Pirolli-Card: Scent Gradient Designer

## LAYER 1: INVARIANTS (Never override.)

1. **Monotonic scent rule.** Every element on the path from page entry to the desired action must carry equal or higher scent than the element before it. A single scent dip triggers the Marginal Value Theorem exit condition. No exceptions.
2. **Trigger-word primacy.** The user's goal vocabulary — drawn from the source cue that brought them here (ad copy, search query, email subject) — is the only valid vocabulary for proximal cues. Synonyms are scent breaks. Internal brand terms are scent breaks.
3. **Above-the-fold is the entire foraging decision.** Headline + hero image + first 30 words must collectively answer "am I in the right patch?" The gradient starts here; if it fails here, no downstream element recovers it.
4. **Decorative images contribute negative scent.** Every image is a proximal cue. If it cannot be described with a trigger word, it dilutes cue space without adding activation. Replace or remove.
5. **Within-patch cost is a gradient variable.** Formatting is not aesthetic; it controls extraction rate. Dense paragraphs lower gain rate and advance the Marginal Value Theorem exit threshold. Bullets, bolded trigger words, and scannable subheads are scent infrastructure.
6. **CTA label = final proximal cue.** "Submit" has zero scent. The button must contain the reward vocabulary the user arrived with. It is the last link in the SNIF-ACT activation chain — highest-stakes proximal cue on the page.
7. **One traffic source = one gradient design.** Scent-match is source-specific. A page receiving Google search traffic and retargeting ads simultaneously needs separate gradient validation per source.

## LAYER 2: QUALITY GUIDANCE

1. Pull trigger words verbatim from the source cue (ad headline, email subject line, search query). Do not paraphrase. Scent is a lexical match, not a semantic one — SNIF-ACT computes association strength S_ji between exact surface forms.
2. Validate the gradient by scoring each page zone (hero, subhead, body, proof block, CTA) independently for trigger-word density. The score must be non-decreasing from top to bottom.
3. Never optimize scent for one segment at the cost of routing confusion for another. If multiple audiences land on the same page, use deliberate negative scent (absent trigger words) to route non-target segments away cleanly.
4. Proof elements (testimonials, results screenshots, stats) are scent amplifiers only when they use target-audience trigger vocabulary. Generic social proof contributes nothing to the activation function.
5. Flag any page element that introduces new vocabulary not present in the traffic source cue — each is a candidate scent break requiring justification or removal.

## PURPOSE

This skill designs an **increasing-scent path** — a monotonically rising sequence of proximal cues from page entry to desired action — grounded in Pirolli and Card's Information Foraging Theory (1999) and the SNIF-ACT cognitive model (2007). It operationalizes the core IFT insight: users navigate like optimal foragers, continuously computing (Information Value) / (Cost to Obtain It). The moment that ratio dips below the environmental average they can get elsewhere, they leave. The gradient designer ensures that ratio never dips.

**Brag line:** "We can predict which links leak visitors before we ship the page."

The specific page-action lever: scent-goal congruence. Every proximal cue — headline, subhead, image, body paragraph, proof block, button — must use exact trigger-word vocabulary from the source cue that brought the user to the page, creating an unbroken activation chain through the SNIF-ACT function A_i = B_i + Σ(S_ji × W_j). Maximum A_i on the desired action = conversion.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, live screenshot, or written element-by-element description
- The ONE desired action (click / opt-in / purchase / next step)
- The traffic source cue: exact ad copy, email subject line, or search query that drives traffic here

**Strongly recommended:**
- Analytics: scroll depth heatmap, exit rate by page section, click map on CTAs
- Audience goal statement: what problem the user is trying to solve, in their own words (support tickets, reviews, survey verbatims)

**Optional:**
- Funnel position (top-of-funnel vs. warm retargeting)
- Competing pages users might visit instead (sets the environmental gain rate benchmark)

## EXECUTION PROCESS

**Step 1 — Extract the trigger-word set.**
Pull the source cue (ad, email, search query). Identify every content word the user's goal vocabulary contains. These are the trigger words. List them explicitly. Example: source cue = "Cut your tax bill by 40% without an accountant" → trigger words: {tax bill, cut, 40%, without accountant, save}.

**Step 2 — Map the page into gradient zones.**
Divide the page into sequential zones in scroll order:
- Zone 1: Hero (headline + subheadline + hero image)
- Zone 2: Value statement / problem agitation block
- Zone 3: Mechanism / proof block (how it works, testimonials, results)
- Zone 4: Pre-commitment / sample value block
- Zone 5: CTA block (button label + surrounding copy)

For pages with unique structures, create custom zones that reflect actual scroll sequence.

**Step 3 — Score each zone for trigger-word density (TWD).**
For each zone, count the number of trigger-word instances divided by total word count in that zone.

  TWD(zone) = (# trigger-word instances in zone) / (total words in zone)

Threshold: TWD >= 0.08 (8%) is passing. Below 0.05 is a scent hole. Record TWD per zone.

**Step 4 — Verify monotonic gradient.**
Plot TWD scores in zone order (Z1 → Z5). The gradient must be non-decreasing. Any zone where TWD(n) < TWD(n-1) is a **gradient inversion** — a predicted exit point per Marginal Value Theorem. Flag every inversion.

**Step 5 — Run the SNIF-ACT activation check on the CTA.**
The CTA button is the terminal link. Compute qualitative activation: list every trigger word present in the button label and surrounding 20-word context. A button with zero trigger words has near-zero predicted click probability regardless of upstream scent. The button must contain at least 2 trigger words or direct reward vocabulary.

**Step 6 — Audit proximal cues for vocabulary breaks.**
Scan all link labels, image alt text/subjects, subheadlines, and button labels. Flag any element using:
- Synonyms not present in the trigger-word set
- Brand-invented terms (internal jargon)
- Generic action words (Submit, Click Here, Learn More, Get Started)

Each flagged item is a scent-match failure requiring rewrite.

**Step 7 — Assess within-patch cost per zone.**
For each zone, identify formatting that raises extraction cost: unbroken paragraphs >3 sentences, no bolded trigger words, no subheadlines per 150 words. Rate each zone: Low Cost / Medium Cost / High Cost. High Cost zones reduce effective gain rate and advance the MVT exit trigger.

**Step 8 — Generate the gradient design specification.**
Output a zone-by-zone redesign table: current TWD → target TWD, specific rewrites for each element, trigger words to inject, formatting changes to reduce within-patch cost.

**Step 9 — Pre-ship leak prediction.**
For each gradient inversion or vocabulary break found in Steps 4-6, state: "Predicted exit rate elevation at [zone] due to [specific scent break]. Fix: [specific rewrite]." This is the deliverable Pirolli and Card's SNIF-ACT model makes possible before any user ever sees the page.

## OUTPUT STRUCTURE

**Section 1: Trigger-Word Set**
Extracted from source cue. Explicit list. Used as validation vocabulary for all downstream sections.

**Section 2: Zone-by-Zone Gradient Audit**

| Zone | TWD Now | TWD Target | Pass/Fail | Primary Break |
|------|---------|------------|-----------|---------------|
| Z1 Hero | 0.04 | >=0.10 | FAIL | Headline uses synonym |
| Z2 Value | 0.07 | >=0.09 | FAIL | No trigger words in subhead |
| Z3 Proof | 0.11 | >=0.12 | PASS | — |
| Z4 Sample | 0.09 | >=0.12 | FAIL | Inversion vs Z3 |
| Z5 CTA | 0.14 | >=0.15 | PASS | Button label: 1 trigger word |

Legend: TWD = Trigger-Word Density. Target is monotonically >= prior zone. Inversion = gradient failure.

**Section 3: Proximal Cue Rewrites**
Element-by-element: [Current text] → [Rewritten text] + reason citing IFT principle.

**Section 4: Within-Patch Cost Reduction**
Zone-by-zone formatting changes. Specific: "Add bolded trigger word every 2 sentences in Z2. Break Z3 proof paragraph into 3-item bullet list."

**Section 5: Pre-Ship Leak Predictions**
Numbered list: predicted exit elevations with specific causal mechanism and fix.

**Section 6: CTA Activation Report**
Trigger-word count in CTA + surrounding context. Pass/fail + rewrite if needed.

## WORKED MINI-EXAMPLE

**Page:** Landing page for a tax-savings software tool.
**Desired action:** Email opt-in for free audit.
**Source cue (Google ad):** "Cut your tax bill by 40% — free 5-minute audit"
**Trigger words:** {tax bill, cut, 40%, free, 5-minute, audit}

**Before — Zone 1 Hero:**
Headline: "Smart Financial Solutions for Business Owners"
TWD: 0/12 words = 0.00. Zero trigger words. SNIF-ACT activation on this page: near zero. Predicted immediate exit.

**After — Zone 1 Hero:**
Headline: "Cut Your Tax Bill by 40% — Free 5-Minute Audit"
TWD: 6/10 = 0.60. Exact mirror of source cue. Every trigger word present. SNIF-ACT activation: maximum. User reads: "I'm in the right patch."

**Before — Zone 5 CTA:**
Button: "Get Started Today"
TWD: 0 trigger words. Activation: near zero despite any upstream scent.

**After — Zone 5 CTA:**
Button: "Run My Free 5-Minute Tax Audit"
TWD: 3 trigger words ({free, 5-minute, audit}). Activation: high. Gradient reaches its peak at the moment of action — the IFT-optimal design.

**Gradient before:** 0.00 → 0.03 → 0.06 → 0.04 → 0.00 (two inversions, CTA collapse)
**Gradient after:** 0.60 → 0.18 → 0.20 → 0.22 → 0.30 (monotonically rising at every zone)

## INTEGRATION NOTES

**Sibling handoffs within the pirolli-* cluster:**
- `pirolli-scent-trail-auditor` runs first — identifies which specific links are leaking. Feed its leak report as the design brief for Step 8 of this skill.
- `pirolli-patch-abandonment-predictor` runs after — takes the gradient design and predicts the remaining abandonment probability per zone under the new configuration.
- `pirolli-link-diagnosticity-scorer` provides the SNIF-ACT activation scores for individual link options; import those scores to validate Step 5 (CTA activation check) with quantitative backing.

**Cross-cluster handoffs:**
- `fogg-ability-auditor`: within-patch cost (Step 7) and Fogg's ability axis measure the same thing from different angles. If Fogg flags a step as high-effort, treat that zone as a guaranteed gradient inversion candidate.
- `kahneman-field-intelligence`: trigger-word density intersects with processing fluency (System 1). Zones passing TWD >= 0.08 that still test poorly likely have a fluency problem, not a scent problem — route to kahneman for diagnosis.
- `iyengar-choice-set-auditor`: pages with too many navigation options or CTAs reduce scent directionality. If the gradient is correct but the desired action is still not the highest-activation option, iyengar's choice-set reduction may be the fix.

## OUTPUT FILE
Save to: [project-folder]/Pirolli-Card - Click Architecture/[YYYY-MM] - Scent Gradient Design.md
