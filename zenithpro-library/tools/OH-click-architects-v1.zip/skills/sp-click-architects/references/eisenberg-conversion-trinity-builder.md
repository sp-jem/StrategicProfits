---
name: eisenberg-conversion-trinity-builder
description: Use when a page fails to convert qualified visitors — audits and rebuilds the Conversion Trinity (Relevance -> Value -> CTA) to maximize one desired action on a specific web page
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Bryan & Jeffrey Eisenberg (Call to Action 2005; Always Be Testing 2008; The Conversion Trinity + Four Buying Modalities) — Click Architecture (Skill 5 of 7)"
interface:
  invoke: "/eisenberg-conversion-trinity-builder"
  calls: []
  called_by: [user, eisenberg-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic mix shifts (new ad campaigns, organic ranking changes) alter which buying modality dominates — Trinity diagnosis goes stale when the dominant modality changes"

eisenberg_scent_integration:
  feeds_from: eisenberg-scent-continuity-auditor
  feeds_to: eisenberg-micro-action-sequencer
  shared_data: "Scent-audit surfaces the trigger phrase from the ad/email — Trinity-builder embeds that phrase in the Relevance headline and passes the confirmed CTA language to micro-action-sequencer"

pirolli_integration:
  feeds_from: pirolli-scent-trail-auditor
  feeds_to: pirolli-link-diagnosticity-scorer
  shared_data: "Information-foraging scent score for the ad-to-page transition; Trinity Relevance score and headline rewrite feed back into pirolli link-diagnosticity scoring for follow-on pages"

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: kahneman-peak-end-architect
  shared_data: "Framing audit identifies System 1 / System 2 signals present in existing copy; modality-matched Value rewrite uses appropriate frame (loss/gain) per buying temperament; peak-end architect receives CTA moment as the page's peak"
---

# Eisenberg Conversion Trinity Builder

## LAYER 1: INVARIANTS (Never override.)

1. **Trinity sequence is non-negotiable.** Relevance must be confirmed before Value lands; Value must be established before CTA is actionable. Fixing the CTA before fixing Relevance produces zero measurable lift. Diagnose in order.
2. **Scent precedes everything.** The landing-page headline must echo the trigger phrase from the referring ad/email/search result verbatim or near-verbatim. A visitor whose scent breaks in the first 3 seconds has already decided to leave — no CTA fix recovers that bounce.
3. **Conversion Rate denominator = qualified intentional visitors only.** CR = (# who took desired action) / (# who INTENDED to take that action). Segment by traffic source before computing. A 2% blended CR may mask a 15% CR from one qualifying segment and 0.1% from a broken segment. Optimize the broken segment, not the average.
4. **Hierarchy of Optimization is strictly bottom-up.** Functional errors -> Accessibility -> Usability -> Intuitive flow -> Persuasion copy. If functional or usability failures exist, persuasion copy changes will not produce reliable lift. Fix lower levels first.
5. **Buying modality cannot be changed.** You serve the modality — Methodical (45%), Spontaneous (25-35%), Humanistic (10-15%), Competitive (5-10%). You do not talk a Methodical buyer into being Spontaneous. Mismatched copy is a conversion tax, not a preference.
6. **Test Trinity units, not isolated variables.** Headline + hero image = one Relevance unit. Body copy = one Value unit. Form + button + surrounding copy = one Action unit. Testing a button color while leaving a broken Relevance headline produces noise, not signal.
7. **Every successful conversion test improves at least one Trinity node.** If a test winner cannot be explained by Relevance, Value, or CTA improvement, the test was underpowered or confounded. Re-examine before scaling.

## LAYER 2: QUALITY GUIDANCE

1. Produce a scored Trinity audit (R/V/CTA each 0-10) before writing any rewrites — diagnosis drives prescription.
2. Every rewrite must be labeled by modality it serves (Methodical / Spontaneous / Humanistic / Competitive) and by Trinity node (R / V / CTA).
3. If the page serves multiple modalities, place primary-modality content above the fold; secondary modality layers go below, sequenced so they do not contradict the primary message.
4. Validate all recommendations against the Hierarchy of Optimization — flag any functional/usability issues that must be resolved before persuasion rewrites will work.
5. Do not propose CTA button-copy tests until Relevance score >= 7 and Value score >= 6. Premature CTA optimization is the most common wasted test budget.

## PURPOSE

This skill audits and rebuilds the three elements that control whether a qualified visitor converts on a single web page: Relevance (does this page confirm the visitor is in the right place?), Value (does it explain why THIS solution is the right answer?), and a Clear Call to Action (is the next step unmistakable and friction-free?). Every Eisenberg conversion test in history traces its lift to improvement in at least one of these three nodes — nothing else moves the needle reliably.

The Eisenberg brag-line: "Our ad and our page tell one unbroken story — scent never breaks."

Tell a peer: "I ran the Conversion Trinity audit — we found the headline was breaking scent from the ad, the value prop was written for Methodical buyers but 65% of our traffic is Spontaneous, and the CTA had three competing buttons. Fixed all three. Conversion rate moved."

## INPUT REQUIREMENTS

**Required:**
- The page — URL, screenshot, or written description of every visible element above and below the fold
- The ONE desired action (click / opt-in / purchase / book call / download)
- The referring source — ad copy, email subject/body, organic search query, or link text that delivered traffic to this page

**Strongly recommended:**
- Analytics segment: which traffic source drives the most qualified visitors to this page
- Scroll-map or heatmap data (identifies where engagement drops — proxies for Value failure)
- Form abandonment rate (if the action involves a form)
- Any prior A/B test results on this page

**Optional:**
- Audience profile or buying modality hypothesis
- Funnel position (top / mid / bottom of funnel — affects Value depth required)

## EXECUTION PROCESS

### Step 1 — Scent Audit (Pre-Trinity Gate)

Extract the exact trigger phrase from the referring source (ad headline, email subject line, search query, link anchor text).

Find the landing page headline. Score scent continuity 0-10:
- 9-10: Trigger phrase echoed verbatim or near-verbatim in headline
- 6-8: Same theme, partially matched language
- 3-5: Related topic, different framing
- 0-2: No recognizable connection

If scent score < 6: **stop here.** Rewrite the headline to echo the trigger phrase before proceeding. Scent repair is the highest-leverage single change on any page with a broken ad-to-headline connection.

### Step 2 — Hierarchy of Optimization Check

Audit the page against the five levels in order. Mark PASS / FAIL:

| Level | Check | Threshold |
|-------|-------|-----------|
| Functional | Page loads, links work, forms submit | Zero errors |
| Accessible | Screen-reader labels, color contrast >= 4.5:1 | WCAG AA |
| Usable | No broken navigation, clear layout | No confusion points |
| Intuitive | Visitor can complete action without instructions | Task success unaided |
| Persuasive | (Trinity audit lives here) | Addressed in Steps 3-5 |

Flag any FAIL at levels 1-4. These are pre-conditions — fix them before Trinity rewrites will produce clean test results.

### Step 3 — Identify Dominant Buying Modality

Determine the primary modality from available signals. If analytics are available:
- High above-fold conversion rate, low time-on-page for converters -> Spontaneous dominant
- Heavy engagement on specs/pricing/comparison pages, long session -> Methodical dominant
- High testimonial/story page engagement -> Humanistic dominant
- Competitive comparison or review page as top entry -> Competitive dominant

If no analytics: default to Methodical as the safest assumption (45% of buyers; also most punished by missing evidence).

Score how well the current page serves that modality 0-10 using the modality requirements table:

**Modality Requirements (non-negotiable elements)**

| Modality | Share | Must Have Above Fold | Proof Type | CTA Language |
|----------|-------|---------------------|------------|--------------|
| Methodical | 45% | Data, specs, clear logic | Hard numbers, case studies | "See the full comparison" |
| Spontaneous | 25-35% | Emotional benefit, urgency | Social proof volume, scarcity | "Try free / Start now" |
| Humanistic | 10-15% | Mission, real people | Personal testimonials, story | "Join us / We believe..." |
| Competitive | 5-10% | Superlatives + named source | Rankings, awards, comparison | "Get the advantage" |

### Step 4 — Trinity Audit (Score Each Node 0-10)

**Node R — Relevance**
Elements: Headline, hero image, subheadline, page title.
Questions: Does the headline echo the trigger phrase? Do the hero image and headline form a single coherent promise? Does the visitor know in 3 seconds they are in the right place?

Scoring threshold: R >= 7 required before Value work is meaningful.

**Node V — Value**
Elements: Body copy, bullets, social proof, offer description, pricing.
Questions: Does the copy explain WHY this is the right solution for this visitor specifically? Is the value proposition explicit, not implied? Is proof the right type for the dominant modality?

Scoring threshold: V >= 6 required before CTA optimization produces reliable lift.

**Node CTA — Clear Call to Action**
Elements: Button label, button position, form fields, surrounding copy, visual contrast.
Questions: Is there ONE dominant action (not three competing buttons)? Does the button stand out in grayscale? Is form length minimized to only essential fields? Does button copy name the outcome, not the action ("Get my free audit" vs. "Submit")?

CTA friction test: render the page in grayscale. If the primary CTA does not dominate visually, it will not dominate in color.
Form length test: count fields. Spontaneous buyers convert at 2x rate on single-field vs. three-field forms. Every non-essential field is a measurable conversion tax.

### Step 5 — Buyer Legends Pre-Mortem

For the dominant modality, walk the page as that buyer and produce a list of all reasons they would NOT click the CTA. Each identified reason = a required page fix.

Pre-mortem prompts by modality:
- Methodical: "Where is the evidence? Why should I believe the claim? What if their numbers are wrong? I need to compare — where is the comparison?"
- Spontaneous: "This feels complicated. Is there a faster way to try it? What if I don't like it? Why should I act now?"
- Humanistic: "Do I trust these people? Are these testimonials real? What do they stand for? Am I just a number to them?"
- Competitive: "How does this stack up against [alternative]? Where's the proof that claim is true? What do industry rankings show?"

### Step 6 — Trinity Rewrite Package

Produce rewrites organized by Trinity node, labeled by modality:

**R Rewrite**: New headline that (a) echoes trigger phrase verbatim or near-verbatim, (b) makes the primary promise for the dominant modality, (c) pairs with a recommended hero image description.

**V Rewrite**: Restructured body copy / bullet set that (a) leads with dominant-modality proof type, (b) makes value proposition explicit in one sentence ("We help [who] achieve [outcome] without [obstacle]"), (c) layers secondary modality content below.

**CTA Rewrite**: (a) Single dominant button — copy names the outcome, (b) form reduced to minimum essential fields, (c) visual contrast direction (button color vs. background must produce >= 3:1 contrast ratio in grayscale), (d) removal of competing links within 200px of the primary CTA.

### Step 7 — Test Prioritization

Rank the three Trinity nodes by estimated revenue impact:
- Highest-broken node (lowest score) = Test #1
- Middle node = Test #2
- Strongest node = Test #3 (confirm, do not break)

State which node to fix first and why, citing the score differential.

## OUTPUT STRUCTURE

### Trinity Audit Summary
| Node | Score | Primary Failure | Fix Priority |
|------|-------|-----------------|--------------|
| Relevance | 0-10 | [diagnosis] | 1 / 2 / 3 |
| Value | 0-10 | [diagnosis] | 1 / 2 / 3 |
| CTA | 0-10 | [diagnosis] | 1 / 2 / 3 |

### Scent Score: [0-10] | Dominant Modality: [type] | Modality Fit Score: [0-10]

### Hierarchy of Optimization: [PASS/FAIL per level, flags for levels 1-4]

### Buyer Legends Pre-Mortem (dominant modality): [bulleted list of reasons they would not convert]

### Trinity Rewrite Package
- R Rewrite: [headline + hero image direction]
- V Rewrite: [restructured value copy]
- CTA Rewrite: [button copy + form + visual contrast direction]

### Test Sequence: [Node 1 first, rationale] -> [Node 2] -> [Node 3]

### Segment Recommendation: [which traffic segment to optimize first, with CR formula applied]

## WORKED MINI-EXAMPLE

**Page:** B2B SaaS landing page. Ad headline: "Cut your sales cycle in half." Landing page headline: "Welcome to [Product] — The Modern CRM."

**Scent Score: 2/10.** Ad trigger phrase "cut sales cycle in half" does not appear. Visitor arrives expecting evidence for a time-reduction claim; page presents a generic CRM welcome.

**Trinity Audit:**
- R: 3/10 — headline does not echo trigger phrase; hero image shows a dashboard with no connection to "sales cycle"
- V: 5/10 — body copy lists features (Methodical content) but traffic is 70% Spontaneous (short sessions, high bounce)
- CTA: 6/10 — single button, but copy says "Request Demo" (Methodical language for a Spontaneous audience)

**Dominant Modality: Spontaneous.** Analytics show 70% of conversions happen above the fold in under 90 seconds.

**R Rewrite:**
Before: "Welcome to [Product] — The Modern CRM."
After: "Cut your sales cycle in half — starting this week." (Trigger phrase echoed; outcome + urgency for Spontaneous)

**V Rewrite:**
Before: Feature list (pipeline management, reporting, integrations).
After: Lead with outcome + social proof volume: "847 teams closed deals 52% faster in their first 30 days. No training required. No IT ticket needed." Methodical feature detail moves below fold.

**CTA Rewrite:**
Before: "Request Demo" (friction: implies a sales call, future commitment)
After: "Start free — no card required" (Spontaneous: immediate, low-commitment, outcome-named)

**Projected impact:** R and CTA were the two lowest-scoring nodes. Fixing both in a single A/B test (headline + CTA as paired units) is Test #1. V refinement is Test #2 once scent and CTA are confirmed.

## OUTPUT FILE

Save to: [project-folder]/Eisenberg - Click Architecture/[YYYY-MM] - Conversion Trinity Audit.md
