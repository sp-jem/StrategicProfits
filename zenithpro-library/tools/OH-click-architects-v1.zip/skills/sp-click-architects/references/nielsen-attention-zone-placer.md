---
name: nielsen-attention-zone-placer
description: Use when a landing page, product page, or lead-gen page has a value prop or CTA that isn't converting — diagnoses whether placement violates empirically mapped attention zones and outputs specific coordinate-level moves to fix it.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Jakob Nielsen & Kara Pernice (Eyetracking Web Usability 2010; F-Pattern 2006; Four Scanning Patterns 2017; Page Fold Attention Gradient 2010/2018) — Click Architecture (Skill 4 of 7)"
interface:
  invoke: "/nielsen-attention-zone-placer"
  calls: []
  called_by: [user, nielsen-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page layout, above-fold content, and visitor scanning behavior shift with device-mix changes and A/B test deployments; a 45-day stale diagnosis will mismap fold position and ignore new scan-pattern data."

nielsen_f_pattern_integration:
  feeds_from: nielsen-f-pattern-layout-auditor
  feeds_to: nielsen-scannability-optimizer
  shared_data: "Identified scanning pattern (F / Spotted / Layer-Cake / Commitment) informs which zone receives primary fixations; scannability optimizer then structures copy within those zones."

pirolli_integration:
  feeds_from: pirolli-scent-trail-auditor
  feeds_to: pirolli-foraging-cost-reducer
  shared_data: "Information scent strength above fold determines whether users extend attention to below-fold CTA zones; weak scent = attention never reaches placed CTA regardless of zone quality."

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: kahneman-peak-end-architect
  shared_data: "Aesthetic first-impression at 50ms (Nielsen UX Time-Scale) maps directly to Kahneman System 1 trust formation; credibility-zone placement must survive both the 50ms filter and the 10-second patience window."
---

# Nielsen & Pernice — Attention Zone Placer

## LAYER 1: INVARIANTS (Never override.)

1. **Fold gradient is non-negotiable.** 57,453 fixations across 541 pages: content above fold receives 102% more views than content 100px below fold. Value prop and primary CTA must appear within the first screenful. No exceptions for "beautiful design."
2. **Left rail always wins the vertical stem.** F-Pattern eyetracking: users scan the left edge vertically after two horizontal passes. Right-column CTAs are invisible — they occupy the ad-blindness zone. CTA placement right of center is a conversion leak.
3. **The 10-second patience window is the placement deadline.** Nielsen UX Time-Scale: users allocate ~10 seconds to decide if a page is worth their time. If the value proposition is not scannable within 10 seconds, they leave. Placement that requires scrolling past fold 1 to see the value prop violates this threshold.
4. **Banner-blindness visual signatures kill CTAs.** Any CTA using colored borders, rounded-corner button styling inside a bordered box, or right-column placement triggers learned ad-skip. The CTA must not look like a display ad.
5. **CTA label is a promise, not a direction.** Nielsen's "Get Started" study: generic imperative CTAs produce high clicks then competitor visits. The label must match precisely what appears behind the click. Mismatch = abandonment after click, not before.
6. **Above-fold scent determines whether below-fold zones matter at all.** Information Foraging: users scroll only when above-fold content signals that value exists below. Placing a secondary CTA at fold 2 without a strong above-fold scent produces zero additional conversions.
7. **50ms aesthetic gate precedes all content processing.** Lindgaard et al. (cited by Nielsen): visual trustworthiness is judged in 1/20th of a second. Cluttered, low-contrast, or visually inconsistent above-fold zones fail the aesthetic gate before any headline is read.

## LAYER 2: QUALITY GUIDANCE

1. Diagnose the active scanning pattern (F / Spotted / Layer-Cake / Commitment) before placing anything — the optimal zone shifts by pattern.
2. For every proposed CTA placement, verify it passes the banner-blindness checklist: no colored border box, no right-column position, no animation, no background that visually resembles a leaderboard or rectangle ad unit.
3. Confirm fold position for the page's primary device mix (mobile fold ~600px, desktop fold ~700–900px depending on resolution). Do not assume; ask for analytics or use browser DevTools screenshot.
4. Apply the Inverted Pyramid test: value proposition first, proof second, detail third — in that vertical order within the attention zone.
5. After every placement recommendation, state the specific fold and the attention-gradient differential it exploits (e.g., "moves CTA from fold 3 to fold 1, capturing the 102% fixation advantage").

## PURPOSE

Nielsen and Pernice's eyetracking corpus — 57,000+ fixations, thousands of page visits, decades of lab and remote studies — maps exactly where human eyes land on a web page before conscious decision-making begins. This skill translates that map into precise placement instructions for one page and one desired action.

The lever: most conversion pages place CTAs and value props where designers want them, not where eyes actually go. This skill closes that gap using the Page Fold Attention Gradient, the Four Scanning Patterns, the Information Scent model, and the UX Time-Scale patience window.

**Brag line: "We place CTAs where eyes actually land, not where we hope."**

This is Skill 4 of 7 in the nielsen-* cluster (G3 Attention & Perception Topography). It does not audit layout structure (that is nielsen-f-pattern-layout-auditor) or optimize copy density (nielsen-scannability-optimizer). It outputs one deliverable: where on the page to place the value prop and CTA, with pixel-range guidance and before/after rationale.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description with approximate layout (header height, hero section depth, CTA current position)
- The ONE desired action: click / opt-in / purchase / schedule / next step

**Strongly recommended:**
- Device/resolution split from analytics (determines fold position)
- Current CTA position in pixels or fold number
- Any heatmap or scroll-depth data (Hotjar, Clarity, etc.)

**Optional:**
- Audience trust level (cold / warm / hot) — affects which scanning pattern to trigger
- Funnel position (awareness / consideration / decision) — affects how much scent is needed above fold

## EXECUTION PROCESS

**Step 1 — Map the page's attention gradient.**
Identify fold 1 boundary for the primary device (default: desktop 768px, mobile 600px). Mark three zones:
- Zone A: above fold 1 (highest fixation density; 102% more views than Zone B)
- Zone B: fold 1 to fold 2 (74% of total viewing time in first two screenfuls)
- Zone C: fold 2 and below (negligible without strong scent signal)

**Step 2 — Diagnose the active scanning pattern.**
Evaluate the current page structure to predict which of Pernice's four patterns fires:
- F-Pattern trigger: unbroken text blocks, no subheadings, no bold keywords → worst for conversion
- Spotted Pattern trigger: bold/linked/colored words scattered in body → eyes jump to styled words only
- Layer-Cake trigger: clear subheadings breaking sections → users dip below relevant headings
- Commitment Pattern trigger: highly personal relevance, trusted source, motivated visitor → sequential read

State which pattern fires on the current page. Then state which pattern the desired action requires.

**Step 3 — Locate the value prop.**
Find where the primary value proposition currently sits (fold number, left/center/right alignment, above or below primary image). Score against three thresholds:
- Threshold A: Value prop visible within 10 seconds without scrolling? (Yes / No)
- Threshold B: Value prop in left-aligned or center-aligned position? (Left/Center = pass; Right = fail)
- Threshold C: Value prop in Zone A or early Zone B? (Zone A = pass; Zone B = marginal; Zone C = fail)

**Step 4 — Locate the CTA.**
Assess the current CTA position and visual signature. Run the banner-blindness checklist:
- [ ] No colored border box surrounding the button
- [ ] No right-column placement
- [ ] No animation or flashing
- [ ] No background that resembles an ad unit (leaderboard, rectangle)
- [ ] Label describes what happens after click (not a generic imperative)
- [ ] Minimum 44x44px touch target (mobile)

Score: 6/6 = passes. 4-5/6 = marginal. <4/6 = banner-blindness risk.

**Step 5 — Run the scent-gradient check.**
If any CTA is in Zone B or C: does above-fold content produce strong information scent?
Scent signal inventory:
- Headline: specific outcome language (strong) vs. category/brand language (weak)
- Hero image: shows the result/use state (strong) vs. abstract graphic (weak)
- Subhead or bullet: mentions the visitor's specific problem (strong) vs. generic benefit (weak)

Scent score: 3/3 = scroll-inducing; 2/3 = marginal; <2/3 = Zone B/C CTAs are invisible — must move them up or strengthen scent before adding them below fold.

**Step 6 — Apply the 50ms aesthetic gate.**
Evaluate Zone A for visual clutter at first impression. Flag any of:
- More than 3 competing visual focal points above fold
- Background color contrast below WCAG AA (4.5:1 for body text)
- Mismatched font weights or sizes that create visual noise
- Primary CTA button color that does not contrast with background by at least 3:1

**Step 7 — Output placement instructions.**
For each element (value prop, primary CTA, secondary CTA if applicable):
- Current position: Zone + alignment + fold number
- Recommended position: Zone + alignment + pixel range
- Rationale: which Nielsen/Pernice finding drives the move
- Scanning pattern this position is designed to intercept
- Attention-gradient differential gained (quantified)

## OUTPUT STRUCTURE

### 1. Attention Zone Map
Three-zone diagram (text-based) showing fold boundaries for stated device mix. Current element positions marked.

### 2. Scanning Pattern Diagnosis
Active pattern on current page. Target pattern for desired action. Gap between them.

### 3. Value Prop Placement Audit
Three-threshold score (A/B/C). Current position. Recommended position. Move rationale.

### 4. CTA Placement Audit
Banner-blindness checklist (6 items). Current score. Recommended position. Label audit (promise principle).

### 5. Scent-Gradient Check
Scent inventory score (3 items). Verdict on whether below-fold CTAs are reachable. Specific language changes if scent is weak.

### 6. 50ms Aesthetic Gate
Focal-point count. Contrast score. Clutter flags. Pass/fail.

### 7. Placement Instructions Table

| Element | Current Zone | Rec. Zone | Alignment | Fold Delta | Gain |
|---------|-------------|-----------|-----------|------------|------|
| Value prop | C | A | Left | +2 folds | 102% fixation |
| Primary CTA | B-right | A-center | Center | +1 fold | Exits ad-blind zone |

*Legend: Fold Delta = folds moved up; Gain = attention differential or blindness fix*

### 8. CTA Label Rewrite (if needed)
Before label → After label. One sentence explaining the promise-principle fix.

## WORKED MINI-EXAMPLE

**Page:** SaaS project management tool, desktop-primary audience, desired action: start free trial.

**Current state:**
- Hero headline: "Streamline Your Workflow" (Zone A, centered)
- Value prop paragraph: "Our platform helps teams collaborate more effectively with real-time updates and seamless integrations." (Zone A, centered, 3 lines)
- Primary CTA button: "Get Started" (Zone B, right column, inside a blue-bordered box)
- Scanning pattern triggered: F-Pattern (unbroken paragraph, no subheadings)

**Diagnosis:**
- Value prop threshold: A=No (too vague to process in 10s), B=Center (pass), C=Zone A (pass). Fails on specificity, not placement.
- CTA: 2/6 on banner-blindness (right column + bordered box = two failures). Invisible.
- Scent score: 1/3 (headline is category language; image is abstract; subhead absent). Zone B CTA unreachable.
- 50ms gate: 4 competing focal points above fold. Fails.

**Placement instructions:**
- Move CTA from Zone B right-column to Zone A below the headline. Remove bordered box. Change background to high-contrast solid button.
- Rewrite value prop: "Cut meeting time by 40% — teams on [Tool] ship 2x faster." (specific outcome, Zone A, left-aligned under hero image)
- Add one subheading below fold 1: "How it works in 3 steps" — triggers Layer-Cake pattern so Zone B content becomes scannable.

**Before CTA label:** "Get Started"
**After CTA label:** "Start my free 14-day trial — no card needed"
**Promise principle fix:** Label now matches landing state (trial, no payment friction). Stops post-click abandonment.

**Attention gain:** CTA moves from Zone B right-column (ad-blind, below fold, right-rail) to Zone A center (102% fixation advantage, exits banner-blindness zone). Scent score moves from 1/3 to 3/3, making any future Zone B elements reachable.

## OUTPUT FILE

Save to: [project-folder]/Nielsen-Pernice - Click Architecture/[YYYY-MM] - Attention Zone Placement Audit.md
