---
name: pirolli-scent-trail-auditor
description: Use when an ad, email, or search click lands on a page with high bounce or low CTA engagement — audits the full scent trail from click origin to desired action and pinpoints exactly where proximal cues stop signaling the prey.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peter Pirolli & Stuart Card (Information Foraging Theory 1999; SNIF-ACT 2007; Proximal Cue Model 2004) — Click Architecture (Skill 1 of 7)"
interface:
  invoke: /pirolli-scent-trail-auditor
  calls: []
  called_by: [user, pirolli-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic source vocabularies, ad copy, and landing page copy change continuously — scent mismatches that didn't exist at audit time appear with every A/B test or campaign refresh."

pirolli_patch_abandonment_integration:
  feeds_to: pirolli-patch-abandonment-predictor
  shared_data: per-fold scent-score array and vocabulary overlap matrix
  note: "Patch-abandonment predictor uses this audit's fold-by-fold scent decay curve as its input signal — run scent-trail-auditor first."

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  shared_data: trigger-word list; above-the-fold value framing
  note: "Kahneman's focusing illusion determines which single attribute the user over-weights above the fold; Pirolli determines whether the proximal cue for that attribute is present at all."

fogg_integration:
  feeds_from: fogg-prompt-designer
  feeds_to: fogg-ability-auditor
  shared_data: CTA label vocabulary; within-patch friction score
  note: "Fogg's ability dimension maps onto Pirolli's within-patch cost; high within-patch friction suppresses action even when motivation is high. Share friction-score output with fogg-ability-auditor."

eisenberg_integration:
  feeds_to: eisenberg-field-intelligence
  shared_data: scent-gap locations; CTA label diagnosticity scores
  note: "Eisenberg's persuasion architecture relies on scent continuity as its structural prerequisite; hand off gap locations for conversion sequence redesign."
---

# Pirolli — Scent Trail Auditor

## LAYER 1: INVARIANTS (Never override.)

1. **Scent = vocabulary overlap, nothing else.** Information scent is the semantic intersection between the user's active goal vocabulary (the words they used or responded to) and the proximal cues on this page (headline, subhead, image subjects, link labels, button text, URL slug). Gut feel about "clarity" or "good design" is not scent measurement.

2. **The scent trail is a chain, not a score.** A single vocabulary break anywhere in the ad → headline → body → CTA chain triggers the Marginal Value Theorem exit condition regardless of how strong the other links are. Audit every link; report the weakest.

3. **Source-to-page match is non-negotiable first.** The first question is always: does the page headline contain at least two of the exact trigger words from the click origin (ad copy, email subject, search snippet)? If no, the audit is already red before any other element is examined.

4. **Above-the-fold is the foraging decision, not a teaser.** Users decide patch-stay vs. patch-leave within seconds. If the distal value (what this page delivers) cannot be inferred from visible proximal cues without scrolling, the patch-leave decision is already in motion.

5. **Generic images carry zero scent.** Stock photography that does not depict the specific outcome or product contributes nothing to the proximal cue model and consumes above-the-fold attention budget. Treat as a negative if it displaces goal-relevant text cues.

6. **SNIF-ACT activation logic applies to every clickable.** Each link/button is a mini foraging decision. Activation A_i = B_i + sum(S_ji * W_j). Any CTA label lacking trigger words from the user's goal vocabulary has low S_ji — it will be deprioritized or ignored regardless of visual prominence.

7. **Within-patch cost is measured in extractions per minute, not readability scores.** Dense paragraphs with no bolded keywords, no scannable subheads, and no bullets increase extraction cost and accelerate marginal-value decay. Formatting is foraging economics.

## LAYER 2: QUALITY GUIDANCE

1. Pull the exact trigger words from the actual click origin (screenshot the ad; copy the email subject; note the search query). Do not infer what the user "probably" searched. Imprecision here corrupts the entire audit.

2. Score scent at each fold (above fold, fold 2, fold 3, CTA zone) separately. A page can have strong entry scent and complete mid-page scent decay — both must be reported.

3. When prescribing fixes, provide the exact rewrite (before → after) using the identified trigger words. "Improve the headline" is not an output. "Change 'Smart Tax Strategies' → 'Cut Your Tax Bill by 40%' (matches ad trigger words 'tax bill' and '40%')" is an output.

4. Distinguish scent gaps (wrong vocabulary) from scent voids (no vocabulary at all — e.g., decorative image block with no caption).

5. Rank gaps by impact: above-the-fold mismatches outweigh mid-page mismatches; CTA label mismatches are second-highest priority because they are the terminal proximal cue before the desired action.

## PURPOSE

This skill applies Peter Pirolli and Stuart Card's Information Foraging Theory directly to a specific web page to audit the unbroken scent trail from click origin to desired action. Every element of the page is treated as a proximal cue contributing to or degrading the user's estimate of distal value. The output is a ranked list of vocabulary breaks in the trail with exact rewrites.

**Brag line:** "We can predict which links leak visitors before we ship the page."

The lever: scent-goal congruence across the complete path. When every proximal cue on the page (headline, subhead, image, link text, CTA button) uses the exact vocabulary the user arrived with, forward movement is automatic. When that chain breaks, the Marginal Value Theorem triggers exit. This audit finds and closes every break.

## INPUT REQUIREMENTS

**Required:**
- The page: URL (will be fetched), screenshot, or written description of every visible element by fold
- The ONE desired action (e.g., "click 'Start Free Trial'", "opt-in to email list", "purchase")
- The click origin: exact ad copy, email subject line, or search query/snippet that drove traffic

**Strongly recommended:**
- Analytics: bounce rate, scroll depth heatmap, click map on CTAs
- Audience: what goal vocabulary does this segment use? (search queries, support ticket language, survey verbatims)
- Funnel position: cold traffic, warm list, retargeting — determines expected base-level activation (B_i)

**Optional:**
- Competing pages/patches the user might return to (sets the environmental gain-rate baseline)

## EXECUTION PROCESS

**Step 1 — Extract the trigger-word set from the click origin.**
List every content word (nouns, verbs, adjectives) from the ad/email/search snippet. These are the user's active goal vocabulary. Flag the 3-5 highest-weight trigger words (typically the value claim, the outcome, and the audience identifier).

Example: Ad = "Cut your tax bill by 40% — strategies for small business owners"
Trigger words: [tax bill, 40%, cut, strategies, small business, owners]
High-weight: [tax bill, 40%, cut]

**Step 2 — Audit the source-to-headline match (Gate 1).**
Count exact trigger-word matches between the click origin and the page headline. Threshold:
- 2+ high-weight trigger words in headline: PASS
- 1 high-weight trigger word: WEAK (yellow)
- 0 high-weight trigger words: FAIL (red) — stop and flag before proceeding

Compute vocabulary overlap ratio: (trigger words appearing in headline) / (total trigger words). Target >= 0.40.

**Step 3 — Score proximal cues above the fold.**
Elements to audit: headline, hero image subject, hero subhead, any visible body text.
For each element, score:
- Trigger-word presence: count exact trigger words (not synonyms) appearing in element
- Scent contribution: High (2+ trigger words) / Medium (1) / None (0) / Negative (decorative image consuming attention budget)
- Report: above-fold composite scent = (sum of trigger word hits) / (number of above-fold elements). Target >= 1.5 hits per element average.

**Step 4 — Walk the page fold-by-fold for scent decay.**
For each fold (above fold, fold 2, fold 3, CTA zone):
- List all proximal cue elements visible at that scroll depth
- Count trigger-word hits per element
- Calculate fold scent score: total trigger-word hits / elements in fold
- Plot the decay curve: [fold 1 score, fold 2 score, fold 3 score, CTA zone score]

Red flag: any fold score < 50% of fold 1 score = scent decay event. Flag the fold and the specific elements responsible.

**Step 5 — Audit the CTA label (Gate 2).**
The CTA button/link is the terminal proximal cue. Apply SNIF-ACT logic:
- List trigger words in CTA label
- List trigger words from the desired action frame (what the user gets immediately upon clicking)
- Diagnosticity score = trigger-word hits in CTA label / total trigger words relevant to the reward

Threshold: CTA diagnosticity < 0.30 = rewrite required. "Submit," "Click Here," "Learn More" = 0.00.

**Step 6 — Identify image scent status.**
For each image above the fold and adjacent to primary CTAs:
- Classify: Informational (depicts the outcome/product/user result) or Decorative (generic, atmospheric, non-specific)
- Informational images: does subject matter match trigger-word domain? (tax strategy page should show numbers/documents/relieved business owner, not generic city skyline)
- Any decorative image in prime attention zones = flag as scent void

**Step 7 — Compile the scent gap register.**
Build a ranked table of all gaps found:

| # | Location | Gap Type | Impact | Trigger Fix |
|---|----------|----------|--------|-------------|
| 1 | Headline | Mismatch | High | [before → after] |
| 2 | CTA label | Void | High | [before → after] |
| 3 | Fold 2 subhead | Decay | Med | [before → after] |

Impact: High = above-fold or CTA zone; Med = mid-page; Low = below-fold.
Rank by Impact, then by fold position (earlier = higher priority).

**Step 8 — Compute overall scent trail score.**
Scent Trail Score = weighted average across gates:
- Gate 1 (source-to-headline): weight 0.35
- Above-fold composite: weight 0.25
- Mid-page decay (worst fold score / fold 1 score): weight 0.20
- Gate 2 (CTA diagnosticity): weight 0.20

Score ranges: 0.80+ = Strong trail / 0.60-0.79 = Leaking / below 0.60 = Broken trail (expect >60% bounce)

**Step 9 — Prescribe the minimum-intervention fix set.**
Order rewrites by leverage (Gate 1 fix first, Gate 2 second, worst mid-page fold third). Provide exact before→after copy for each. Do not prescribe design changes without copy anchors.

## OUTPUT STRUCTURE

**1. Trigger-Word Map**
The extracted goal vocabulary from the click origin, ranked by weight.

**2. Gate Status Summary**
| Gate | Element | Status | Score |
|------|---------|--------|-------|
| G1 | Source→Headline | Pass/Weak/Fail | overlap% |
| G2 | CTA Label | Pass/Weak/Fail | diagnosticity |

**3. Fold-by-Fold Scent Decay Curve**
Fold scores plotted as a simple list: Fold 1: X | Fold 2: X | Fold 3: X | CTA Zone: X
Flag any fold where score < 50% of fold 1.

**4. Scent Gap Register**
Full ranked table (per Step 7 format) of every gap with before→after fix.

**5. Image Scent Audit**
Each above-fold and CTA-adjacent image classified and flagged if decorative.

**6. Overall Scent Trail Score**
Single composite score with interpretation and confidence level.

**7. Priority Rewrite List**
The 3-5 highest-leverage copy changes, written out in full, ready to implement.

## WORKED MINI-EXAMPLE

**Page:** Landing page for a B2B tax software product.
**Desired action:** Click "Start Free Trial"
**Click origin (Google Ad):** "Cut your business tax bill by 40% — automated deductions for LLCs"
**Trigger words:** [cut, tax bill, 40%, automated, deductions, LLC]

**Gate 1 audit:**
Current headline: "Smart Financial Tools for Modern Business Owners"
Trigger-word hits: 0 of 6. Overlap ratio: 0.00. STATUS: FAIL.

**Above-fold audit:**
- Headline: 0 hits (generic)
- Hero image: generic office photo, no financial/tax context — Decorative, scent void
- Subhead: "Save time with our intelligent platform" — 0 hits
- Above-fold composite scent: 0.0

**CTA label:** "Get Started"
Diagnosticity score: 0/6 = 0.00. STATUS: FAIL.

**Scent Trail Score:** 0.10 (Broken trail — predicted bounce >70%)

**Priority rewrites:**

Headline:
- Before: "Smart Financial Tools for Modern Business Owners"
- After: "Cut Your LLC's Tax Bill by 40% — Automated Deductions, Done for You"

CTA label:
- Before: "Get Started"
- After: "Start Cutting My Tax Bill — Free Trial"

Hero image:
- Before: Generic office stock photo
- After: Screenshot of deduction dashboard showing dollar amounts saved, or image of LLC owner reviewing reduced tax statement

Subhead:
- Before: "Save time with our intelligent platform"
- After: "Our software finds every deduction LLCs miss — automatically"

Projected Scent Trail Score after rewrites: 0.84 (Strong trail).

---
*Legend for gap register — Gap Types: Mismatch = wrong vocabulary; Void = no vocabulary (decorative/generic); Decay = vocabulary present early, absent in this fold. Impact levels: High = above fold or CTA zone; Med = mid-page scrollable; Low = below primary CTA.*

## OUTPUT FILE

Save to: [project-folder]/Pirolli - Click Architecture/[YYYY-MM] - Scent Trail Audit - [Page Name].md
