---
name: hick-single-decision-enforcer
description: Use when a conversion page has multiple competing actions, cluttered CTAs, or unclear primary intent — audits response uncertainty and strips everything competing with the single desired action using Hick-Hyman Law and Hyman's entropy formula.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "William Hick & Ray Hyman (Hick 1952, Hyman 1953; Hick-Hyman Law + Hyman Entropy Extension) — Click Architecture (Skill 5 of 7)"
interface:
  invoke: "/hick-single-decision-enforcer"
  calls: []
  called_by: [user, hick-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "CTA layouts, nav structures, and conversion rates shift with every redesign cycle; an audit older than 45 days reflects a page that may no longer exist."

hick_option_pruning_integration:
  feeds_from: hick-option-pruning-auditor
  feeds_to: hick-default-path-designer
  shared_data: "Option inventory (raw n count) produced by pruning-auditor becomes the input n for this skill's response-uncertainty split; default-path-designer then pre-selects the surviving primary action."

iyengar_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: hick-progressive-disclosure-designer
  shared_data: "Iyengar's catalog-display curation (6-12 items max) feeds the n value this skill validates; progressive-disclosure-designer receives the stage-gated option sets that survive single-decision enforcement."

kahneman_integration:
  feeds_from: kahneman-framing-engineer
  feeds_to: hick-decision-load-calculator
  shared_data: "Kahneman System 1 framing primes the user toward the expected response, reducing Hyman entropy H even before n is pruned; decision-load-calculator uses the post-framing effective H as its input score."
---

# Hick-Hyman Single-Decision Enforcer

## LAYER 1: INVARIANTS (Never override.)

1. **One primary CTA per conversion zone.** Every conversion page gets exactly one primary action button in the conversion zone. A second button at the same visual weight doubles response uncertainty — the Hick-Hyman b coefficient fires on response alternatives, not stimulus alternatives.
2. **Response uncertainty is the dominant term.** Per Wifall et al. (2015), response uncertainty carries a larger coefficient than stimulus uncertainty. Cutting available response actions (buttons, links, forms) from n=5 to n=1 removes more decision latency than reducing visible navigation items alone.
3. **The primary CTA must be the highest-p(i) option on the page.** Hyman's entropy formula H = -Σ p(i)×log₂p(i) shows that a visually dominant CTA — largest, highest contrast, above fold — carries the highest implied probability of being clicked and therefore contributes the minimum entropy per option.
4. **Time-to-first-click > 12 seconds signals n is too high.** This is the Hick-Hyman operational threshold on a conversion page. If session recording shows time-to-click on the primary CTA exceeds 12 seconds from page load, competing response options must be cut before optimizing copy or imagery.
5. **Competing links on a conversion page are measured, not assumed.** Count every clickable element that is NOT the primary CTA. Each one raises effective n. Navigation links, social icons, secondary offer buttons, and footer menus all count.
6. **Never remove information to reduce n — gate it.** Progressive disclosure moves information behind expandable elements; it does not delete it. Options that are genuinely necessary for trust (FAQ, testimonials, guarantee) go below the fold or behind a "Learn more" toggle.
7. **This skill enforces the single-decision architecture. It does not redesign the decision sequence.** Sequential step architecture (task decomposition across screens) belongs to hick-progressive-disclosure-designer.

## LAYER 2: QUALITY GUIDANCE

1. **Ground every removal recommendation in the response-uncertainty split.** State which response options are being cut, the before/after n count, and the estimated RT reduction using RT = a + b×log₂(n+1) with b ≈ 0.155 s.
2. **Check Hyman entropy, not just raw count.** If the page has 4 options but the primary CTA is visually dominant (large, colored, centered), effective H may already be low. Do not recommend cuts that are cosmetic — only cuts that materially reduce H.
3. **Separate the conversion zone from the informational zone.** Links and content in the hero/CTA zone are high-cost (raise conversion-zone n). Links below the fold in a features section carry lower weight because user intent has not yet crystallized.
4. **Validate with measurement, not assumption.** Require session recording data (heatmap click distribution, time-to-click) before issuing a final enforcement score. If no data is available, flag the audit as provisional.
5. **Log before-and-after clickable element count and predicted RT delta.** This is the output artifact that survives the page redesign and justifies the decision.

## PURPOSE

This skill takes a specific web page and a stated desired action, then applies the Hick-Hyman Law and Hyman Entropy Extension to diagnose response uncertainty and strip every element that competes with the primary action. It operates at the response-options layer — the dominant coefficient in the Hick-Hyman equation — because cutting response alternatives from n=5 to n=1 eliminates more decision latency than any copy or color optimization.

**Brag-line:** "We cut decision time by removing options, and we can prove the math."

The lever: RT = a + b×log₂(n+1). With b ≈ 0.155 s, moving from n=5 competing response options to n=1 reduces predicted decision time by ~0.36 seconds. On a conversion page handling 10,000 sessions/month, that RT reduction compounds into measurable lift because faster decisions drop off less. Landing pages with 1 CTA convert at ~13.5%; adding a second CTA drops conversion to ~11.9%; five or more CTAs fall below 10.5%.

Cluster position: Skill 5 of 7. The option-pruning-auditor (Skill 2) identifies which options to cut from the full option inventory. This skill enforces the outcome — exactly one primary action survives in the conversion zone — and hands the enforced architecture to the default-path-designer (Skill 6) for pre-selection of the survivor.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, live screenshot, or written description covering (a) all visible CTAs and buttons, (b) navigation elements, (c) links in the hero/conversion zone, (d) form fields if present.
- The ONE desired action: the single conversion event this page is designed to produce (e.g., "click Buy Now," "complete opt-in form," "start free trial").

**Strongly recommended:**
- Session recording data: time-to-first-click on primary CTA, heatmap click distribution across all page elements.
- Current conversion rate and/or abandonment rate at this step.
- Funnel position: is this a cold traffic landing page, a retargeting page, a checkout step, or a pricing page?

**Optional:**
- Audience familiarity level (first exposure vs. warm list) — affects acceptable n (warmer audiences tolerate slightly higher n).
- Current A/B test results if any variant has already reduced CTA count.

## EXECUTION PROCESS

### Step 1 — Response Option Inventory

List every clickable element on the page that is NOT the primary CTA. Assign each to a zone:

| Zone | Definition |
|------|-----------|
| C | Conversion zone (hero, above fold, CTA section) |
| I | Informational zone (features, testimonials, FAQ) |
| F | Footer/navigation |

Count n_C = number of competing clickable elements in zone C.
Count n_total = all competing clickable elements site-wide on this page.

**Threshold:** n_C > 1 is an automatic enforcement flag. n_C = 0 is target state.

### Step 2 — Hick-Hyman RT Calculation

Compute predicted decision time for current state and target state:

```
RT_current = a + b × log₂(n_C + 1 + 1)   [+1 for primary CTA]
RT_target  = a + b × log₂(1 + 1)           [primary CTA only]
RT_delta   = RT_current - RT_target
```

Use a = 0.20 s (baseline), b = 0.155 s.

**Worked formula for n_C = 4:**
RT_current = 0.20 + 0.155 × log₂(6) = 0.20 + 0.155 × 2.585 = 0.20 + 0.40 = 0.60 s
RT_target  = 0.20 + 0.155 × log₂(2) = 0.20 + 0.155 × 1.00  = 0.20 + 0.155 = 0.355 s
RT_delta   = 0.245 s saved per visitor

### Step 3 — Hyman Entropy Audit

For each competing clickable element in zone C, estimate its implied click-probability p(i) based on visual weight (size, color, placement). Compute:

H = -Σ p(i) × log₂(p(i))   [across all zone-C clickable elements including primary CTA]

**Interpretation:**
- H < 0.50 bits: primary CTA already dominates; entropy is low; enforce visual dominance, minimal structural cuts needed.
- H 0.50–1.00 bits: moderate entropy; cut 1-2 competing elements, increase primary CTA contrast ratio.
- H > 1.00 bits: high entropy; hard enforcement required; conversion zone must be restructured.

Note: Hyman's finding is that response uncertainty — how many ways the user can respond — contributes more to H than stimulus uncertainty. Even if navigation shows 7 items (stimulus), if only 1 response button exists in the conversion zone, effective decision latency is low.

### Step 4 — Enforcement Triage

For each flagged competing element, assign one of four dispositions:

| Code | Action |
|------|--------|
| REMOVE | Delete from page entirely |
| GATE | Move behind accordion / "Learn more" toggle |
| RELOCATE | Move below fold, out of conversion zone |
| KEEP | Retain — trust-critical with low visual weight |

**Rules for disposition:**
- Navigation header on conversion/landing page: REMOVE or collapse to logo-only.
- Secondary offer button ("Or, see plans"): RELOCATE below primary CTA with reduced visual weight.
- Social proof links, external case studies: GATE behind expandable.
- Footer links on squeeze page: REMOVE entirely.
- Guarantee / privacy policy text link (legal trust signal): KEEP — small font, low contrast.

### Step 5 — Visual Entropy Reduction Plan

Beyond cutting elements, enforce that the primary CTA is the highest-p(i) option visually:

- **Color contrast:** Primary CTA button must have a contrast ratio ≥ 3:1 against any adjacent competing button. If no competing buttons remain, contrast against background ≥ 4.5:1 (WCAG AA).
- **Size differential:** Primary CTA must be the largest interactive element in the conversion zone by at least 20% in surface area.
- **Placement:** Primary CTA above the fold, centered or right-aligned (F-pattern terminus). Hyman's entropy formula: making the CTA the "expected" response lowers its p(i) entropy contribution.
- **Repetition:** On long-form pages, repeat the identical CTA every 400-600px of scroll. Repetition elevates implied p(i) of that action across the full page entropy sum.

### Step 6 — Measurement Setup

Specify the two tracking metrics to validate enforcement:

1. **Time-to-first-click on primary CTA** (session recording / FullStory / Hotjar): target < 8 seconds from page load after enforcement. Current baseline vs. post-enforcement comparison required after 500+ sessions.
2. **Click distribution shift** (heatmap): post-enforcement, primary CTA should capture ≥ 70% of all above-fold clicks. Anything below 60% means a competing element is still drawing attention.

**A/B test parameter:** If enforcing is a major structural change, run 1-CTA variant vs. current as primary variable. Minimum 1-week baseline. Expected lift: 1.4–2.5 percentage points in conversion rate for pages moving from 3+ CTAs to 1.

## OUTPUT STRUCTURE

The skill produces a single enforcement report with these sections:

**1. Response Option Inventory Table**
All clickable elements by zone, current n_C, n_total.

**2. Hick-Hyman RT Calculation**
Current RT, target RT, RT_delta in seconds.

**3. Hyman Entropy Score**
Current H in bits, interpretation band (low/moderate/high), primary CTA visual dominance rating.

**4. Enforcement Triage Table**
Each competing element with its disposition code (REMOVE / GATE / RELOCATE / KEEP) and the rationale tied to its zone and visual weight.

**5. Visual Entropy Reduction Checklist**
Contrast ratio, size differential, placement, and repetition specs for the primary CTA.

**6. Measurement Setup**
Time-to-first-click baseline, heatmap click-distribution target, A/B test parameters if warranted.

**7. Predicted Outcome**
RT_delta, expected conversion rate change range, and the single sentence the client can use to explain the change to stakeholders.

## WORKED MINI-EXAMPLE

**Page:** SaaS pricing page. Desired action: "Start free trial."

**Before:**
- Nav bar: 6 links (Home, Features, Pricing, Blog, Login, Contact) → n_C = 6 in header
- Hero zone: "Start Free Trial" button (primary), "Schedule a Demo" button (same size, adjacent), "See all features" text link → n_C = 2 competitors in conversion zone
- Footer: 12 links

n_C (conversion zone) = 2. Total competing response options in hero = 3 (including 2 competitors + primary).

RT_current = 0.20 + 0.155 × log₂(3+1) = 0.20 + 0.155 × 2.00 = 0.51 s
RT_target  = 0.20 + 0.155 × log₂(1+1) = 0.20 + 0.155 × 1.00 = 0.355 s
RT_delta   = 0.155 s

Hyman H estimated: "Start Free Trial" p = 0.50, "Schedule Demo" p = 0.35, "See features" p = 0.15
H = -(0.50×log₂0.50 + 0.35×log₂0.35 + 0.15×log₂0.15) = -(−0.50 + −0.53 + −0.41) = 1.44 bits → HIGH

**Enforcement:**
- "Schedule a Demo": RELOCATE — move to a smaller text link below the primary CTA, reduce font size and remove button styling.
- "See all features": GATE — move behind an expandable "What's included" accordion below the fold.
- Nav header: RELOCATE to logo-only strip on this page (conversion landing variant).

**After:**
n_C = 0 competitors. Single "Start Free Trial" button dominates conversion zone.
RT_target = 0.355 s. H drops to near 0 (one option, p → 1.0).
Expected conversion lift: 1.5–2.0 percentage points based on 1-CTA vs. 3-CTA benchmark data.

## OUTPUT FILE

Save to: [project-folder]/Hick-Hyman - Click Architecture/[YYYY-MM] - Single Decision Enforcement - [Page Name].md
