---
name: goward-lift-scorer
description: Use when you have a landing page URL, screenshot, or written description and one desired conversion action — scores the page on all 6 LIFT factors and 27+ sub-factors into a single diagnostic grid before any test is run.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Chris Goward (You Should Test That, 2012; LIFT Model 2009; Kaizen Method 2012) — Click Architecture (Skill 1 of 7)"
interface:
  invoke: "/goward-lift-scorer"
  calls: []
  called_by: [user, goward-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic source copy, offer framing, and competitive context shift; a 45-day-old LIFT audit may miss new anxiety sources or relevance gaps that appeared after a campaign pivot."

goward_siblings_integration:
  feeds_from: [goward-field-intelligence]
  feeds_to: [goward-value-prop-fulcrum-auditor, goward-clarity-relevance-optimizer, goward-anxiety-distraction-reducer, goward-urgency-architect, goward-hypothesis-generator]
  shared_data: "LIFT grid scores + top-3 drag factors passed as prioritized input to sibling skills. goward-hypothesis-generator consumes the full 27-factor breakdown to produce ranked test hypotheses."

eisenberg_integration:
  feeds_from: [eisenberg-buying-modality-classifier]
  feeds_to: [eisenberg-micro-action-sequencer]
  shared_data: "Visitor modality (competitive/spontaneous/humanistic/methodical) refines the Relevance and Urgency factor scores. Methodical visitors tolerate more complexity; spontaneous visitors penalize it under Distraction."

kahneman_integration:
  feeds_from: [kahneman-prospect-theory-architect]
  feeds_to: [kahneman-framing-engineer]
  shared_data: "Anxiety sub-factor scores map to loss-aversion triggers. Perceived-cost items in the Value Proposition Cost-Benefit Equation (risk, social risk, effort) are surfaced to kahneman-framing-engineer for reframing."

iyengar_integration:
  feeds_from: [iyengar-choice-set-auditor]
  feeds_to: []
  shared_data: "Distraction factor score cross-validated against iyengar-choice-set-auditor's choice-overload score. Overlapping findings elevate priority of simplification hypotheses."
---

# Goward LIFT Scorer — Full Diagnostic Grid

## LAYER 1: INVARIANTS (Never override.)

1. Value Proposition is scored first and treated as the ceiling. No amount of urgency, clarity, or reduced distraction rescues a mis-stated or weak VP. If VP < 6, the entire page requires a VP-first hypothesis before anything else.
2. The desired action is fixed at the start and never changed mid-audit. Every sub-factor score is relative to that single macro conversion event.
3. LIFT factors are not equally weighted: Value Proposition is the fulcrum (sets the ceiling); Anxiety and Distraction are inhibitors (must be reduced before drivers are amplified); Clarity, Relevance, and Urgency are drivers (raise what you capture of the ceiling).
4. Sub-factor scores are hypotheses about visitor perception, not designer intent. Score what a first-time visitor experiences, not what the page builder intended.
5. A score of 1-3 on any factor is a mandatory test candidate. Do not subordinate a red-score factor to a higher-score factor's optimization.
6. POPs/PODs/POIs audit is required before scoring Relevance and Value Proposition. Without knowing what competitors can and cannot claim, both scores are guesswork.
7. Output is a diagnostic grid, not a redesign. Prescribe what to test, not what the final page should look like.

## LAYER 2: QUALITY GUIDANCE

1. Cite the specific LIFT sub-factor that every finding maps to. Generic observations ("the headline is weak") are invalid without a named sub-factor anchor.
2. Score each sub-factor on 1-10 before aggregating to the factor score. Averaging without sub-factor breakdown hides the specific lever.
3. Distinguish drag from driver. An element that reduces Clarity is a driver failure; an element that adds Anxiety is an inhibitor. The fix is different in each case.
4. Separate analytics observations (what users did) from LIFT observations (why they did it). Both are inputs; conflating them produces false diagnoses.
5. Do not score more than one page per run. LIFT analysis requires visitor-context specificity; blending two pages into one audit destroys diagnostic accuracy.

## PURPOSE

This skill encodes Chris Goward's LIFT Model — the six-factor influence framework he developed in 2009 after analyzing thousands of A/B tests — to score any landing page before a single test is run. It identifies which conversion forces are lifting the page toward the desired action and which are dragging it away, producing a ranked diagnostic grid with 27+ sub-factors and a prioritized test queue.

**Brag line:** "We can score any landing page on 6 conversion forces before testing."

The LIFT Model treats every page element as belonging to one of six categories: Value Proposition (the ceiling), and five modifiers — three that lift (Clarity, Relevance, Urgency) and two that drag (Anxiety, Distraction). The practitioner's job is to diagnose the ceiling, eliminate the drags, then amplify the drivers — in that sequence.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description of all visible above-the-fold and below-the-fold content
- The ONE desired action (macro conversion): e.g., "submit a lead form," "click Add to Cart," "start free trial"

**Optional but improves scores:**
- Traffic source(s) feeding this page (ad copy, email CTA, organic keyword)
- Audience description or persona
- Competitor page descriptions (needed for POPs/PODs/POIs)
- Analytics: bounce rate, scroll depth, click maps, form abandonment rate
- Funnel position: cold traffic / warm retargeting / existing customer upsell

## EXECUTION PROCESS

### Step 1 — Lock the Conversion Goal
State the single macro conversion event. Everything scored below is measured against this event. If the page has multiple CTAs, identify the primary one; all others are Distraction candidates.

### Step 2 — Value Proposition Audit (POPs/PODs/POIs)
Before scoring, run a rapid POPs/PODs/POIs three-column analysis:
- **POPs** (Points of Parity): what prospects need that competitors also offer — these are table stakes; emphasizing them is "a strategy to fail."
- **PODs** (Points of Difference): what prospects need that competitors cannot claim — these are the conversion levers. The strongest POD should be in the headline.
- **POIs** (Points of Irrelevance): features on the page that prospects do not want — cut them (they add noise to Distraction).

### Step 3 — Score All 6 Factors (1-10 per sub-factor, then average to factor score)

**Factor 1: Value Proposition (fulcrum)**
Sub-factors:
- VP-1: Is the primary POD visible in the headline or first sentence? (1=buried, 10=prominent)
- VP-2: Cost-Benefit Equation — do perceived benefits visibly outweigh perceived costs (price, effort, risk, social risk)? (1=costs dominate, 10=benefits dominate)
- VP-3: Is the VP specific and differentiated, or generic ("high quality," "trusted," "easy")? (1=generic, 10=specific and owned)
- VP-4: Is the VP consistent from traffic source to page (message match)? (1=mismatch, 10=exact match)
- VP-5: Does the VP address the visitor's primary desired outcome, not the company's feature list? (1=feature-led, 10=outcome-led)

**Factor 2: Clarity (driver)**
Sub-factors:
- CL-1: Can a first-time visitor state the desired action within 5 seconds? (1=no, 10=yes)
- CL-2: Is the primary CTA button copy action-oriented and first-person? ("Download My Guide" > "Submit") (1=generic, 10=specific/1st-person)
- CL-3: Is the visual hierarchy directing attention toward the desired action? (1=scattered, 10=laser-focused)
- CL-4: Are instructions unambiguous — no jargon, no assumed knowledge? (1=confusing, 10=instantly understood)
- CL-5: Is the page free of competing calls to action? (1=multiple competing CTAs, 10=single dominant CTA)

**Factor 3: Relevance (driver)**
Sub-factors:
- RE-1: Does the headline language match the exact terminology of the traffic source? (1=mismatch, 10=exact echo)
- RE-2: Is the offer framed for this visitor's specific stage of awareness (cold/warm/hot)? (1=mismatched, 10=precise)
- RE-3: Does the page signal the visitor's channel identity above the fold (source icon, personalized headline)? (1=no signal, 10=explicit signal)
- RE-4: Is the imagery of people/context congruent with the target audience's self-image? (1=generic stock, 10=specific and recognizable)

**Factor 4: Urgency (driver)**
Sub-factors:
- UR-1: Is there a credible reason to act now (not vague "limited time")? (1=no urgency or fake urgency, 10=credible and specific)
- UR-2: Is urgency congruent with brand and audience sophistication (no countdown timers for premium buyers)? (1=incongruent, 10=audience-matched)
- UR-3: Is the cost of inaction made concrete and visible? (1=no consequence framing, 10=vivid consequence)

**Factor 5: Anxiety (inhibitor — lower score = more drag)**
Sub-factors:
- AN-1: Are security indicators positioned to reassure without drawing attention to threats? (1=badges increasing anxiety, 10=native SSL + unobtrusive badges)
- AN-2: Is the commitment level of the desired action made explicit (no hidden fees, cancellation easy)? (1=ambiguous commitment, 10=explicit and low-friction)
- AN-3: Is social proof (testimonials, case studies, logos) specific and verifiable, not generic? (1=unspecific or missing, 10=named/verifiable)
- AN-4: Are form fields minimal and each field's purpose explained by context? (1=unexplained fields, 10=every field earns its presence)
- AN-5: Is the page free of language that triggers doubt (weasel words, excessive disclaimers up-front)? (1=doubt-triggering, 10=confidence-building)

**Factor 6: Distraction (inhibitor — lower score = more drag)**
Sub-factors:
- DI-1: Is navigation removed or suppressed on this conversion page? (1=full site nav present, 10=no nav)
- DI-2: Are outbound links other than the CTA absent? (1=multiple exits, 10=CTA-only exits)
- DI-3: Is the page free of POIs (irrelevant features that dilute the VP)? (1=POIs present, 10=only relevant content)
- DI-4: Is the visual noise low — white space, focused imagery, no competing animations? (1=noisy, 10=clean and focused)
- DI-5: Is the page free of secondary offers, pop-ups, or social widgets that compete with the macro conversion? (1=multiple competing offers, 10=single offer)

### Step 4 — Build the Diagnostic Grid

Produce this table (6 rows, 5 columns — no wider):

| Factor | Score | Direction | Top Sub-Factor Issue | Priority |
|--------|-------|-----------|----------------------|----------|
| Value Prop | X/10 | Ceiling | [worst sub-factor] | [1-6] |
| Clarity | X/10 | Lift | [worst sub-factor] | [1-6] |
| Relevance | X/10 | Lift | [worst sub-factor] | [1-6] |
| Urgency | X/10 | Lift | [worst sub-factor] | [1-6] |
| Anxiety | X/10 | Drag | [worst sub-factor] | [1-6] |
| Distraction | X/10 | Drag | [worst sub-factor] | [1-6] |

**Legend:** Score = average of sub-factor scores (1-10). Direction = whether this factor lifts or drags conversion. Priority = test sequencing rank (1 = test first). Score < 4 = Red (mandatory test). 4-6 = Yellow (high-opportunity). 7+ = Green (maintain).

**Sequencing rule:** Priority order follows the LIFT sequence — VP always rank 1 if Red; then Anxiety and Distraction (inhibitors, ranks 2-3); then Clarity, Relevance, Urgency (drivers, ranks 4-6). Within each tier, rank by lowest score.

### Step 5 — Top 3 Test Candidates

List the three highest-leverage interventions, each anchored to a named sub-factor:
- Factor name + Sub-factor ID
- Current state (observed on the page)
- Hypothesized change
- Expected LIFT direction and mechanism

Pass this list to goward-hypothesis-generator for full test card development.

## OUTPUT STRUCTURE

1. **Conversion Goal** — one sentence stating the single macro conversion event
2. **POPs/PODs/POIs Summary** — three-column table (max 5 rows each), POD column highlighted
3. **Sub-Factor Scores** — all 27+ sub-factor scores with one-line rationale each
4. **LIFT Diagnostic Grid** — the 6-row table (see Step 4 format)
5. **Top 3 Test Candidates** — sub-factor-anchored hypotheses
6. **Inhibitor Alert** — if Anxiety or Distraction score < 4, flag as "fix before amplifying drivers"
7. **VP Ceiling Note** — if VP < 6, state that all driver optimizations are capped until VP is addressed

## WORKED MINI-EXAMPLE

**Page:** SaaS project management tool free-trial page. Desired action: start free trial (no credit card).

**VP Score: 4.2/10.** VP-3 sub-factor = 2 ("Better collaboration for teams" is a POPs claim every competitor makes; the real POD — "connects Slack, Jira, and Asana in one view without exporting" — is buried in bullet 7). VP-4 = 3 (Google Ad said "all your tools in one place"; headline says "Simplify teamwork" — terminology mismatch).

**Distraction Score: 3.1/10.** DI-1 = 2 (full site navigation present including Pricing, Blog, Careers links above the fold). DI-2 = 3 (three outbound resource links in the body copy).

**Anxiety Score: 4.8/10.** AN-2 = 4 ("No credit card required" is present but small, below the CTA button rather than inline with it).

**Prioritized grid:**

| Factor | Score | Direction | Top Sub-Factor Issue | Priority |
|--------|-------|-----------|----------------------|----------|
| Value Prop | 4.2 | Ceiling | VP-3: POD buried in bullet 7 | 1 |
| Distraction | 3.1 | Drag | DI-1: full site nav present | 2 |
| Anxiety | 4.8 | Drag | AN-2: "no CC" below CTA | 3 |
| Clarity | 6.1 | Lift | CL-2: CTA says "Get Started" | 4 |
| Relevance | 5.4 | Lift | RE-1: ad/headline mismatch | 5 |
| Urgency | 5.9 | Lift | UR-1: no reason to act now | 6 |

**Before:** Headline = "Simplify teamwork." CTA = "Get Started." Full nav visible. POD buried.

**After (Test 1 hypothesis):** Headline = "Connect Slack, Jira & Asana in one view — free trial, no credit card." Nav suppressed. "No credit card required" moved inline with CTA. CTA = "Start My Free Trial."

Mechanism: VP-3 and VP-4 corrected (POD in headline, message match restored) + DI-1 removed + AN-2 repositioned. Expected: VP ceiling rises; inhibitor drag drops; driver scores become meaningful for the first time.

## OUTPUT FILE

Save to: [project-folder]/Goward - Click Architecture/[YYYY-MM] - LIFT Diagnostic Grid - [Page Name].md
