---
name: fitts-field-intelligence
description: Meta-synthesis across all Fitts page-action skills + the Click Architects network. Finds convergence zones, surfaces the single highest-leverage motor-cost reduction, and cross-wires Fitts's Law with every adjacent thinker.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Paul Fitts — Field Intelligence (Skill 7 of 7)"
interface:
  invoke: "/fitts-field-intelligence"
  calls:
    - fitts-target-cost-auditor
    - fitts-primary-action-dominance-scorer
    - fitts-thumb-zone-mapper
    - fitts-edge-magnet-designer
    - fitts-target-spacing-optimizer
    - fitts-click-path-minimizer
  called_by: [user, click-architects]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Layout shifts, new above-fold content, A/B test results, and device-mix changes all alter D and W for the primary CTA. Audits older than 45 days are likely stale."

integration_hooks:
  - thinker: hick-field-intelligence
    feeds_from: fitts
    feeds_to: hick
    shared_data: "Fitts yields motor-cost ID per target; Hick yields decision-cost RT per choice-set. Sum them: Total Click Cost = Fitts MT + Hick RT. Eliminating a competing button near the CTA simultaneously lowers ID (Fitts W protection) and cuts Hick n. The combined metric is Total Friction Units — a single number that collapses motor + cognitive cost."
  - thinker: pirolli-field-intelligence
    feeds_from: pirolli
    feeds_to: fitts
    shared_data: "Pirolli's Information Scent predicts which element the user will pursue next. Fitts's Law predicts how fast they can get there. If scent points to element X but X has high ID, the user follows the scent then stalls at the motor bottleneck. Feed Pirolli's highest-scent element into fitts-target-cost-auditor to confirm the scent trail is also a low-ID trail."
  - thinker: kohavi-field-intelligence
    feeds_from: fitts
    feeds_to: kohavi
    shared_data: "Every Fitts recommendation is a testable hypothesis: 'Doubling button width reduces MT by ~1 bit.' Kohavi's A/B rigor converts that prediction into a p-value. Fitts supplies the treatment design; Kohavi supplies the valid measurement. Never ship a Fitts change without a Kohavi test plan."
  - thinker: eisenberg-field-intelligence
    feeds_from: fitts
    feeds_to: eisenberg
    shared_data: "Eisenberg's persuasion architecture scores whether the page moves the visitor through buying stages. Fitts scores whether the stage-transition CTA is physically reachable. A high-persuasion page with a high-ID CTA is a cocked gun with the safety on. Feed Eisenberg's stage map into fitts-click-path-minimizer to ensure each stage-exit CTA is also a low-ID target."
  - thinker: norman-field-intelligence
    feeds_from: fitts
    feeds_to: norman
    shared_data: "Norman's affordances govern whether the button looks clickable; Fitts governs whether it is physically reachable. A button with strong affordance but high ID creates desire without delivery — a conversion-destroying gap. Align Norman affordance signals with Fitts-optimal placement: the button should look important AND be easy to hit."
  - thinker: nielsen-field-intelligence
    feeds_from: fitts
    feeds_to: nielsen
    shared_data: "Nielsen's usability heuristics include error prevention and efficiency of use. Fitts's Speed-Accuracy Trade-off is the mechanical source of button misclicks. High-ID CTAs force the SAT: users either slow down (friction) or mis-click (error). Nielsen error-prevention and Fitts SAT reduction share the same cure: larger, well-separated targets."
  - thinker: goward-field-intelligence
    feeds_from: fitts
    feeds_to: goward
    shared_data: "Goward's conversion heuristics include relevance, value, urgency, friction, anxiety, distraction. Fitts quantifies the 'friction' component as Index of Difficulty. Feed fitts-primary-action-dominance-scorer output into Goward's friction slot to replace gut-feel with a bit-count."
  - thinker: gigerenzer-field-intelligence
    feeds_from: fitts
    feeds_to: gigerenzer
    shared_data: "Gigerenzer's fast-and-frugal heuristics say users use one-reason decision rules under uncertainty. The user's one-reason rule for 'where to click' is proximity + size — exactly Fitts's D and W. Design for the ecological heuristic: the biggest, closest button IS the CTA."
  - thinker: laja-field-intelligence
    feeds_from: fitts
    feeds_to: laja
    shared_data: "Laja's CRO methodology stresses qualitative research to identify friction. Fitts provides the quantitative friction measure. Run Laja's user interviews to learn WHERE users want to click, then run Fitts's audit to confirm the ID at that spot. The intersection is the fix."
  - thinker: eyal-field-intelligence
    feeds_from: eyal
    feeds_to: fitts
    shared_data: "Eyal's Hook model: Trigger → Action → Reward → Investment. Fitts governs the Action step: the trigger fires but if the Action CTA has high ID, the hook breaks at step 2. fitts-thumb-zone-mapper should audit the trigger-to-action path for every Eyal hook on the page."
  - thinker: brignull-field-intelligence
    feeds_from: fitts
    feeds_to: brignull
    shared_data: "Brignull's dark patterns (confirm-shaming, roach motels) often exploit Fitts in reverse: make the escape/unsubscribe button tiny and distant (high ID) while making the confirmation button large and nearby (low ID). Fitts-auditing both directions exposes asymmetric ID as a dark-pattern signal."
  - thinker: fogg-field-intelligence
    feeds_from: fogg
    feeds_to: fitts
    shared_data: "Fogg's Behavior Model: B = MAP (Motivation × Ability × Prompt). Fitts is the mechanical floor of Ability: even infinite Motivation cannot compensate for a CTA the user physically cannot acquire efficiently. Fogg's ability axis bottoms out at Fitts's MT. Ensure Fogg Ability ≥ low-ID before boosting Motivation copy."
  - thinker: cialdini-field-intelligence
    feeds_from: cialdini
    feeds_to: fitts
    shared_data: "Cialdini's influence principles drive the motivation to click. Fitts governs whether the motivated user can complete the click. Scarcity and social proof copy placed far from the CTA creates motivation that decays during the motor travel. Place influence triggers within the CTA's 200px radius to minimize the distance between impulse and action."
  - thinker: kahneman-field-intelligence
    feeds_from: kahneman
    feeds_to: fitts
    shared_data: "Kahneman System 1 processes the button's visual salience; Fitts governs System 1's motor execution. A System 1-salient button in a Fitts-hard position (small, far) still fails. A System 1-invisible button in a Fitts-easy position also fails. Optimal CTA = high salience (Kahneman) × low ID (Fitts)."
  - thinker: thaler-field-intelligence
    feeds_from: thaler
    feeds_to: fitts
    shared_data: "Thaler's default effect: the path-of-least-resistance option gets chosen. Fitts defines 'least resistance' physically: lowest MT = lowest ID = lowest D/W ratio. Design the default (pre-selected, largest, nearest) option to be the conversion CTA. The Fitts-easiest target should be the Thaler default."
  - thinker: iyengar-choice-set-auditor
    feeds_from: iyengar
    feeds_to: fitts
    shared_data: "Iyengar's choice overload: more options → paralysis → abandonment. Each extra option near the CTA also raises effective D (forces precise targeting to avoid mis-clicks). Iyengar and Fitts both argue for fewer options; their costs (cognitive + motor) are additive. Prune options; each pruned element reduces both Hick RT and Fitts ID."
---

# Fitts Field Intelligence

## LAYER 1: INVARIANTS

1. Synthesis not summary. Find PATTERNS across the 6 skills' outputs; do not recap each in sequence.
2. Convergence detection mandatory — name each zone where two or more skills flag the same page element.
3. Contradictions surfaced not hidden — when skills disagree, explain the mechanical reason and resolve it.
4. The Single Move is non-negotiable — one highest-leverage page change, stated as a specific instruction.
5. The Mirror — examine the business's own page-design biases that systematically raise ID.
6. Cross-System Intelligence with other Click Architects is the highest-value section of every run.
7. Freshness gate 45 days — flag any output older than this before synthesizing.

## LAYER 2: QUALITY GUIDANCE

- All findings must cite Fitts's exact equation (MT = a + b × log₂(1 + D/W)) or a named framework from the dossier (SAT, Two-Phase Movement, Prime Pixel, Infinite Targets).
- Every recommendation must specify what changes: D (distance), W (width/hit area), or both, and estimate the ID delta in bits.
- Tables: max 6 columns, abbreviated headers, legend below. No horizontal scroll.
- Voice: tight, operational, no fluff. One sentence per insight. Worked example required.

---

## PURPOSE

Fitts Field Intelligence is the synthesis layer that runs after all 6 Fitts tools have audited the same page. It finds convergence zones (where multiple tools flag the same high-ID element), resolves contradictions between tool outputs, identifies the single highest motor-cost reduction available, and cross-wires Fitts's equation with every adjacent Click Architect thinker.

**Brag:** "Our primary button is mathematically the easiest thing to hit on the page."

---

## INPUT REQUIREMENTS

Run at least 4 of the 6 Fitts tool skills on the same page before invoking field intelligence:

| Tool | What It Contributes |
|------|---------------------|
| fitts-target-cost-auditor | Raw ID scores for each interactive element |
| fitts-primary-action-dominance-scorer | Dominance delta: CTA ID vs. nearest competitor ID |
| fitts-thumb-zone-mapper | Mobile zone heat map; thumb-reach penalty per element |
| fitts-edge-magnet-designer | Edge/corner infinite-target opportunities |
| fitts-target-spacing-optimizer | Spacing between adjacent targets; SAT risk zones |
| fitts-click-path-minimizer | Cumulative MT across multi-step flows |

Minimum inputs: outputs from 4 tools + page URL or screenshot + stated desired action.

---

## EXECUTION PROCESS

### Step 1 — Component Synthesis

Collect all tool outputs. For each flagged element, record: element name, which tools flagged it, ID score (bits), and the Fitts variable at fault (D too large, W too small, or both).

Build the Master ID Table (max 6 cols):

| Element | ID (bits) | D fault | W fault | Tools | Priority |
|---------|-----------|---------|---------|-------|----------|
| Primary CTA | — | Y/N | Y/N | list | H/M/L |

Abbreviation legend: ID = Index of Difficulty; D fault = distance exceeds 200px from prime pixel; W fault = hit area below 44px (mobile) or 60px (desktop); Tools = tool skills that flagged this element; Priority = H(igh)/M(ed)/L(ow).

### Step 2 — Convergence Detection

A Convergence Zone exists when 2+ tool skills flag the same element. Name each zone:

- **Zone CTA-D**: Primary CTA flagged by both target-cost-auditor (high ID) and click-path-minimizer (late in flow). Fix: move CTA up-page or add sticky instance.
- **Zone THUMB-EDGE**: Thumb-zone-mapper and edge-magnet-designer both find the mobile CTA is placed at screen-top (edge hazard on touch, infinite-target on desktop). Resolution: sticky bottom bar on mobile, sticky top bar on desktop.
- **Zone CROWD**: Target-spacing-optimizer and primary-action-dominance-scorer both flag a cluster of buttons near the CTA. Fix: remove or visually suppress competitors within 200px radius.

State each detected zone as: Zone [Name] — elements involved — convergent diagnosis — single fix.

### Step 3 — Contradiction Resolution

When tools disagree (e.g., edge-magnet-designer recommends top-edge sticky CTA, thumb-zone-mapper flags top-edge as a thumb-stretch zone):

State the contradiction explicitly. Resolve by device: apply edge-magnet logic to desktop viewport; apply thumb-zone logic to mobile viewport. Responsive layout satisfies both. Never suppress a contradiction.

### Step 4 — Amplification

For the top 3 convergence zones, estimate the ID reduction in bits and translate to a conversion projection:

- Rule of thumb: each 1-bit ID reduction ≈ 8-12% MT reduction on that target.
- Worked example: CTA at D=320px, W=40px → ID = log₂(1 + 320/40) = log₂(9) ≈ 3.17 bits. After fix: D=80px, W=120px → ID = log₂(1 + 80/120) = log₂(1.67) ≈ 0.74 bits. Delta: 2.43 bits. Estimated MT drop: ~70%. Expected click-through lift on this element: 15-25% (conservative; test via Kohavi to validate).

### Step 5 — The Single Move

State the one page change that produces the largest ID reduction for the primary CTA. Format:

**Single Move:** [Specific instruction. E.g., "Pin a full-width CTA button to the bottom of the mobile viewport at 56px height, replacing the current inline CTA at mid-page."] This changes D from [X]px to [Y]px and W from [X]px to full-screen width, reducing ID from [X] bits to [Y] bits — the largest single motor-cost reduction available on this page.

### Step 6 — The Mirror

Examine the business's systematic design biases that repeatedly raise ID across their pages:

- Do they consistently place CTAs above-the-fold but far from the content that creates desire (large D)?
- Do they use branded small-button aesthetics that systematically undersize W?
- Do they default to centered, narrow-column layouts that waste the edge-magnet opportunity?
- Do their multi-step flows add fields instead of removing them?

Name the pattern. Estimate how many pages it affects. Prescribe the design-system fix (e.g., "Add a 'CTA placement' rule to your design system: primary CTA must appear within 120px of the last persuasive element the user reads, never as a standalone above-fold hero button separated from benefit copy.").

### Step 7 — Cross-System Intelligence

For each integrated thinker, state the new insight that emerges when Fitts's lever combines with theirs. Select the 4-6 most relevant for this specific page, based on what the tool outputs revealed.

**Fitts × Hick (Total Click Cost):** Fitts MT + Hick RT = Total Friction Units. If this page has 8 nav items AND a distant CTA, both clocks are running. Fix both simultaneously: prune nav and move CTA closer. Reporting Total Friction Units (motor + cognitive) to the client is more persuasive than reporting ID alone.

**Fitts × Fogg (Ability Floor):** Fogg's Ability axis has a physical floor set by Fitts's MT. No amount of motivation copy overcomes a CTA with ID > 3 bits. If the page has strong copy but low conversion, check MT before adding more persuasion.

**Fitts × Cialdini (Impulse Decay):** Social proof or scarcity placed far from the CTA creates motivation that decays during motor travel. The fix is co-location: place the influence trigger within 100px of the CTA, not at the top of the page.

**Fitts × Kahneman (System 1 + Motor):** System 1 salience (color, contrast) gets the user's attention; Fitts's MT determines if they can complete the action before attention shifts. Both conditions must be met. Audit salience and ID together.

**Fitts × Thaler (Default = Lowest ID):** The Thaler default should be the Fitts-easiest target. Audit: is the pre-selected or most prominent option also the lowest-ID option? If not, the default is fighting the motor system.

**Fitts × Kohavi (Test, Don't Guess):** Every ID-reduction recommendation is a falsifiable hypothesis. Attach a Kohavi A/B test plan to each Single Move before shipping. Predicted MT reduction becomes the expected effect size for power calculation.

**Fitts × Brignull (Asymmetric ID as Dark Pattern Detector):** Compute ID for primary CTA and ID for the escape/decline path. If ID(escape) >> ID(CTA) by more than 2 bits, this is a dark-pattern flag. Ethical design requires symmetric ease between acceptance and refusal.

**Fitts × Pirolli (Scent Trail Must Be Low-ID):** Pirolli's highest-scent link should be the lowest-ID target on the page. If scent and ID are misaligned, the user follows the scent then stalls. Feed Pirolli's scent map into fitts-target-cost-auditor as a cross-check.

**Fitts × Eisenberg (Stage Exit Must Be Easy):** Each Eisenberg buying-stage exit has a CTA. Fitts audits each one. The highest-ID stage-exit CTA is the conversion bottleneck for the entire funnel — fix it first.

**Fitts × Iyengar (Prune = Double Win):** Removing an option reduces Iyengar choice load AND removes a competing click target that was inflating effective D. Every pruned option is worth double.

**Fitts × Laja (Quantify the Friction Qualitative Research Found):** Laja's interviews surface where users feel friction. Fitts quantifies that friction as bits of ID. The combination gives the client a number to argue for design investment: "Users say it feels hard to find the button. Fitts confirms: ID = 3.4 bits vs. an optimal 0.8 bits — 4× harder than it needs to be."

**Fitts × Norman (Affordance + Reachability):** Norman affordance makes the button look clickable. Fitts makes it physically reachable. Audit both in one pass: does this button look like a button AND have ID < 1.5 bits? Both required.

**Fitts × Nielsen (SAT = Usability Error Source):** High-ID CTAs trigger the Speed-Accuracy Trade-off: users mis-click or abandon. Nielsen's error-prevention heuristic and Fitts's SAT reduction share one cure — widen and separate targets. Report SAT risk from fitts-target-spacing-optimizer as a Nielsen heuristic violation.

**Fitts × Gigerenzer (Ecological Heuristic):** Users use one-reason rules: "Click the biggest, closest thing." Design so the biggest, closest interactive element IS the primary CTA. If another element is bigger or closer, Gigerenzer predicts users will click it instead regardless of copy intent.

**Fitts × Eyal (Hook Action Step):** Eyal's Trigger fires, but if the Action CTA has high ID, the Hook breaks before the Reward. Audit every Hook's Action CTA with fitts-thumb-zone-mapper. A Hook with ID > 2 bits at the Action step is a broken Hook.

### Step 8 — Coherence Map

Produce a single table showing how each tool output connects to the Single Move:

| Tool | Key Finding | Supports Single Move? | Notes |
|------|-----------|-----------------------|-------|
| target-cost-auditor | CTA ID = 3.1 bits | Yes — reduces to 0.8 | — |
| dominance-scorer | CTA vs. competitor delta = 0.4 bits | Yes — delta target ≥ 2 bits | — |
| thumb-zone-mapper | CTA in top-center (stretch zone) | Yes — move to bottom | — |
| edge-magnet-designer | Bottom edge unused | Yes — anchor there | — |
| spacing-optimizer | 3 buttons within 80px of CTA | Yes — remove 2 | — |
| click-path-minimizer | Step 3 of 4 has highest ID | Partial — also fix step 3 | Secondary fix |

### Step 9 — Conversion Projection

State the projected lift from implementing the Single Move, with the calculation shown:

Format: "ID reduction of [X] bits on the primary CTA. At [Y] bits/second throughput (TP), MT drops from [A]ms to [B]ms. Based on historical benchmarks, a [Z]% MT reduction on a primary CTA correlates to [range]% click-through lift. Recommend Kohavi A/B test with [N] visitors at 80% power to confirm."

---

## OUTPUT STRUCTURE

```
## Fitts Field Intelligence Report
### Page: [URL or description]
### Desired Action: [stated action]
### Date: [YYYY-MM-DD]
### Tools Run: [list]

---
### Master ID Table
[table]

### Convergence Zones
[Zone Name] — [elements] — [diagnosis] — [fix]

### Contradictions
[contradiction + resolution]

### Single Move
[specific instruction + ID before/after + projected lift]

### The Mirror
[systematic bias + design-system fix]

### Cross-System Intelligence
[4-6 thinker intersections most relevant to this page]

### Coherence Map
[table]

### Conversion Projection
[calculation + test plan]
```

---

## OUTPUT FILE

Save to: `[client-output-folder]/fitts-field-intelligence-[YYYY-MM-DD].md`

If client-output-folder is not specified, save to:
`~/click-architects-output/[client-slug]/fitts-field-intelligence-[YYYY-MM-DD].md`
