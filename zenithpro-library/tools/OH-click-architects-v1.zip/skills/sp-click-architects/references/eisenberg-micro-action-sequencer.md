---
name: eisenberg-micro-action-sequencer
description: Use when a page has a macro-conversion goal (opt-in, purchase, next step) but visitor drop-off suggests the ladder of micro-yeses is broken — sequences the micro-actions that build momentum toward the macro-conversion using Persuasion Architecture modality mapping and Conversion Trinity audit
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Bryan Eisenberg & Jeffrey Eisenberg (Call to Action 2005; Always Be Testing 2008; Buyer Legends 2014; Persuasion Architecture 2003-2006; Four Buying Modalities; Conversion Trinity) — Click Architecture (Skill 6 of 7)"
interface:
  invoke: "/eisenberg-micro-action-sequencer"
  calls: []
  called_by: [user, eisenberg-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic mix, ad copy, and audience intent shift; modality dominance and scent-break patterns expire with campaign rotations"

eisenberg_scent_integration:
  feeds_from: eisenberg-scent-continuity-auditor
  feeds_to: eisenberg-conversion-trinity-builder
  shared_data: "Scent-continuity audit confirms whether the entry headline echoes the upstream trigger; micro-action sequencer uses that finding to set the Relevance gate before sequencing the ladder"

pirolli_foraging_integration:
  feeds_from: pirolli-scent-trail-auditor
  feeds_to: pirolli-patch-abandonment-predictor
  shared_data: "Pirolli's information scent gradient identifies where visitors abandon the page; micro-action sequencer maps those abandonment nodes to the broken micro-yes in the PA ladder and prescribes the fix"

fogg_behavior_integration:
  feeds_from: fogg-ability-auditor
  feeds_to: fogg-prompt-designer
  shared_data: "Fogg ability score per micro-action step feeds friction assessment; high-friction steps correlate with Methodical/Humanistic drop-off in the modality map and require CTA simplification"
---

# Eisenberg Micro-Action Sequencer

## LAYER 1: INVARIANTS (Never override.)

1. **Scent-before-sequence rule.** The entry headline must match the trigger phrase of the upstream ad/email/search result verbatim or near-verbatim. Until scent is confirmed, no downstream micro-yes ladder matters — the visitor has already left mentally.
2. **Conversion Trinity is the audit sequence, not a checklist.** Evaluate Relevance first, Value second, CTA third. In that strict order. Fixing CTA language while Relevance is broken wastes test cycles.
3. **Pyramid order is non-negotiable.** Per the Hierarchy of Optimization: functional errors, then accessibility, then usability friction, then intuitive flow, then — and only then — persuasion micro-action sequencing. Sequencing micro-yeses on a broken or confusing page has zero ROI.
4. **You cannot change a buyer's modality; you must serve it.** Identify the dominant modality from behavioral data (analytics, heatmaps, scroll depth) and design the above-fold zone for that type. Secondary modalities are served lower on the page in a coherent sequence.
5. **CR denominator is intentional visitors, not raw sessions.** CR = (actions taken) / (visitors who intended to take that action). Segment by traffic source and intent signal before measuring micro-action performance.
6. **Every micro-action must reduce the cognitive distance to the next micro-action.** The sequence is a ladder, not a list — each rung must feel like a natural half-step, not a leap.
7. **Test headlines + images as a single Relevance unit. Test body copy as a single Value unit. Test form + button + CTA language as a single Action unit.** Never isolate variables across Trinity layers.

## LAYER 2: QUALITY GUIDANCE

1. Run the PA pre-mortem for the dominant modality before writing any copy fix: walk the page as that buyer and name every reason they would NOT click the CTA. Each named reason is a required fix, not a suggestion.
2. For multi-modality pages: state explicitly which modality owns above-fold and which modalities are served at which scroll depth. Ambiguity here produces pages that serve no one well.
3. Assign a dollar-proximity score (high / medium / low) to every page element based on how directly it connects to the conversion action. Place high-dollar-proximity elements in positions of highest visual availability.
4. Validate the CTA in grayscale before finalizing: if the button does not dominate in grayscale, it will not dominate in color. Contrast is the visual proxy for conversion priority.
5. Flag any form with more than two fields above the fold as a Spontaneous modality friction risk. For Spontaneous buyers, every non-essential field is a conversion leak.

## PURPOSE

This skill sequences the micro-yeses — the small, low-resistance actions that accumulate visitor momentum — so that the macro-conversion (opt-in, purchase, booking, next step) becomes the natural next move rather than a leap of faith.

Bryan and Jeffrey Eisenberg's mechanism is Persuasion Architecture: each visitor arrives through a persona-pathway shaped by one of four buying modalities (Competitive, Spontaneous, Methodical, Humanistic). Each modality has non-negotiable information requirements at each step. When those requirements are met in the right order, micro-yeses compound automatically. When they are missing or out of sequence, the ladder collapses regardless of copy quality.

The primary page lever is dual: (1) unbroken information scent from the upstream source to the page headline, and (2) modality-matched proof and language at each step of the conversion sequence.

**Brag line (carry this to peers):** "Our ad and our page tell one unbroken story — scent never breaks."

## INPUT REQUIREMENTS

**Required:**
- The page — URL, screenshot, or written description including visible headline, subhead, body copy, form/CTA, and any trust elements
- The ONE desired macro-conversion action (e.g., "email opt-in," "book a call," "purchase $97 course")

**Strongly recommended:**
- The upstream source — ad copy, email subject/body, search result snippet, or link anchor text that delivers visitors to this page
- Analytics or behavioral data — scroll depth, heatmap, drop-off points, traffic source breakdown
- Audience profile — if known buying modality distribution or psychographic data exists

**Optional but useful:**
- Funnel position (top-of-funnel cold traffic vs. retargeted warm vs. existing customer upsell)
- Previous A/B test history on this page

## EXECUTION PROCESS

**Step 1 — Hierarchy of Optimization gate (2 min)**
Before sequencing anything, confirm the page clears all four lower levels:
- Functional: page loads, links work, no broken elements
- Accessible: readable font sizes, alt text on key images, no color-only information
- Usable: navigation is self-evident, no confusing UI patterns
- Intuitive: page flow matches expected reading pattern (F-pattern or Z-pattern for Western readers)
If any level fails, stop and report the failure. Persuasion sequencing on a broken or confusing page is wasted work.

**Step 2 — Scent audit (5 min)**
Compare the upstream trigger (ad headline, email subject, link anchor) to the page headline word-for-word.
- PASS: the page headline contains the trigger phrase verbatim or near-verbatim within the first seven words
- WEAK: the page headline addresses the same topic but uses different vocabulary
- FAIL: the page headline introduces a new theme, offer frame, or visual register that the upstream trigger did not establish

Threshold: any FAIL = fix headline before proceeding. A WEAK scent score = propose verbatim-match variant for testing.

**Step 3 — Conversion Trinity audit (10 min)**
Evaluate the page in layer order:

Layer 1 — Relevance (headline + hero image):
Does the headline confirm to this visitor that they are in the right place for their stated intent? Score: Yes / Partial / No.
"Partial" = headline addresses the category but not the specific desire or pain the upstream source named.

Layer 2 — Value (body copy, proof, features-benefits):
Does the body copy explain WHY this specific offer is the right solution for this visitor — not just what it is?
Check: Is there a value proposition sentence? Is the primary benefit named in the first 50 words? Is proof present (data, testimonials, demonstration)?

Layer 3 — CTA (form, button, surrounding copy):
Is the next action so obvious that a ten-year-old could identify it without reading the body copy?
Check: Button contrast (grayscale test), button copy specificity ("Get the Guide" vs. "Submit"), form field count, proximity of button to benefit statement.

**Step 4 — Dominant modality identification (5 min)**
Classify the dominant buying modality from behavioral evidence:

| Signal | Likely dominant modality |
|--------|--------------------------|
| High above-fold conv rate | Spontaneous or Competitive |
| Heavy pricing/compare page | Methodical |
| High testimonial/story scroll | Humanistic |
| Short session, high bounce | Spontaneous unserved or scent break |
| Long session, low conv | Methodical unserved (missing specs/proof) |

If no analytics: default to Methodical as the plurality (45% of buyers) — missing data, specs, or comparison charts is the most common Methodical failure mode.

**Step 5 — Modality-specific micro-action prescription**

For each modality present in the audience, prescribe the page elements that satisfy their dominant question:

Competitive (5-10% of buyers, fast + logical):
- Dominant question: "How is this provably better than alternatives?"
- Required elements: superlative claim + named evidence source (e.g., "Highest-rated by G2, Spring 2025"), comparison chart, achievement-language CTA ("Get the advantage," "Claim your edge")
- Micro-yes ladder: superlative claim → named proof → comparison → CTA

Spontaneous (25-35%, fast + emotional):
- Dominant question: "Will this feel good right now?"
- Required elements: emotional benefit headline, urgency/scarcity signal, visual dynamism (contrast, movement, color), friction-free CTA ("Try free," "Start now," "Instant access"), max 1-2 form fields
- Micro-yes ladder: emotional hook → immediate benefit → urgency → one-click CTA

Methodical (45%, slow + logical):
- Dominant question: "What is the evidence?"
- Required elements: hard data, percentages, detailed specs, transparent pricing with specific feature limits, case study with documented result, zero hype language
- Micro-yes ladder: problem acknowledgment with data → mechanism explanation → proof (case study/data) → spec comparison → low-pressure CTA ("See full details," "Download the breakdown")
- Warning: urgency or hype language actively suppresses Methodical conversion — remove it from Methodical-dominant pages

Humanistic (10-15%, slow + emotional):
- Dominant question: "Can I trust the people behind this?"
- Required elements: mission/purpose statement, real human faces (team or customers), authentic testimonials with full name and context (not logos), social-impact language, "We believe..." framing
- Micro-yes ladder: mission/belief statement → human story → authentic social proof → trust-building CTA ("Join us," "Become part of")

**Step 6 — Multi-modality page layout sequence**
If the page must serve multiple modalities:
- Above fold: dominant revenue modality (serve their proof type and CTA language first)
- 1-2 screen-lengths down: secondary modality content block (does not contradict above-fold message)
- Never place Methodical spec tables above the fold on a Spontaneous-dominant page — this increases cognitive load for the majority while serving the minority

**Step 7 — Micro-action ladder map**
Produce a numbered sequence of every micro-yes required before the macro-conversion, keyed to page position:

Format:
1. [Micro-action name] | [Page position] | [Element responsible] | [Modality served] | [Pass/Fail on current page]

Threshold: any Fail in the first three micro-actions is a conversion priority fix. Fails below micro-action 5 are optimization opportunities.

**Step 8 — Pre-mortem for dominant modality**
Walk the page as the dominant modality buyer. For each micro-action step, state the specific reason that buyer type would NOT proceed. Each named reason = a required page change.

**Step 9 — Segmented CR diagnostic**
Using the correct denominator (CR = actions / intentional visitors):
- Segment visitors by upstream source (paid search, email, social, organic)
- Identify which segment has the worst CR
- Map that segment's traffic to its likely modality (paid search = Competitive/Methodical, email = Methodical/Humanistic, social = Spontaneous/Humanistic)
- Prioritize page fixes for the broken segment, not the average CR

## OUTPUT STRUCTURE

**1. Hierarchy Gate Result** — Pass/Fail per level; blocking issues identified

**2. Scent Score** — Pass / Weak / Fail with the exact trigger phrase vs. headline comparison

**3. Conversion Trinity Audit** — Relevance / Value / CTA scored with specific gaps named

**4. Dominant Modality Classification** — Which modality, what evidence, confidence level

**5. Micro-Action Ladder** — Numbered ladder with Pass/Fail per step and responsible page element

**6. Modality-Specific Fix Prescriptions** — Concrete copy/layout changes per modality, in priority order

**7. Pre-Mortem Findings** — Dominant-modality objections at each step + required fixes

**8. Segmented CR Diagnosis** — Which segment is broken, why, and what modality-fix addresses it

**9. Test Sequence** — Which Trinity unit to test first (Relevance, Value, or CTA) and the specific variant hypothesis

## WORKED MINI-EXAMPLE

**Page:** Email opt-in landing page for a free productivity guide.
**Upstream ad:** "Stop losing 3 hours a day to email — download the 7-minute inbox system."
**Desired action:** Email opt-in.
**Analytics:** 78% mobile, 3.2% CR overall. Scroll-depth data shows 60% of visitors never scroll past headline.

**Step 2 — Scent:**
- Ad trigger: "Stop losing 3 hours a day to email"
- Current headline: "Boost Your Productivity With Our Free Guide"
- Score: FAIL — headline introduces "productivity" and "free guide"; upstream trigger named "3 hours" and "email." Visitor confirmation is broken at entry.
- Fix: "Stop Losing 3 Hours a Day to Email — Download the 7-Minute Inbox System Free"

**Step 3 — Trinity:**
- Relevance: Fail (headline mismatch — fixed above)
- Value: Partial — benefit named but no data or mechanism visible above fold
- CTA: Weak — button says "Download Now" (generic); form has 3 fields (name, email, phone)

**Step 4 — Dominant modality:**
- 78% mobile + social traffic source = Spontaneous dominant
- 60% bounce at headline confirms scent failure compounding Spontaneous abandonment

**Step 5 — Spontaneous micro-action ladder (after scent fix):**
1. Emotional hook confirmed (headline echoes ad) | Above fold | Headline | Spontaneous | FIXED
2. Immediate benefit stated ("7 minutes") | Hero subhead | Subhead | Spontaneous | ADD: "In 7 minutes a day, your inbox is done"
3. Zero friction path to action | Form | CTA block | Spontaneous | FIX: remove phone field; keep email only
4. Urgency signal | Below headline | Scarcity line | Spontaneous | ADD: "Downloaded by 12,400 professionals this month"
5. Macro-conversion | Button | CTA | Spontaneous | FIX: "Get My Inbox System Free" (specific + possessive)

**Before:** CR = 3.2% | Headline: generic | Fields: 3 | Button: "Download Now"
**After prescription:** Headline matches trigger | Fields: 1 | Button: specific possessive | Urgency social-proof added
**Expected CR lift range:** 40-80% (based on Eisenberg benchmark: scent + modality fix + form reduction each independently average 20-35% lift)

## OUTPUT FILE
Save to: [project-folder]/Eisenberg - Click Architecture/[YYYY-MM] - Micro-Action Sequence Audit.md
