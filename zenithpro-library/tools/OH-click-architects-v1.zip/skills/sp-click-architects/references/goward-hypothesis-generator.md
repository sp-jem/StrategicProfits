---
name: goward-hypothesis-generator
description: Use when LIFT audit findings exist and need to become a prioritized, testable A/B hypothesis queue — converts page diagnoses into ranked experiments ready for Kohavi-style validation.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Chris Goward (You Should Test That, 2012; LIFT Model 2009; Infinity Optimization Process 2014) — Click Architecture (Skill 6 of 7)"
interface:
  invoke: "/goward-hypothesis-generator"
  calls: []
  called_by: [user, goward-field-intelligence, goward-lift-scorer]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic patterns, audience composition, and competitive context shift — hypotheses tied to stale LIFT findings misfire."

goward_lift_scorer_integration:
  feeds_from: goward-lift-scorer
  feeds_to: kohavi-field-intelligence
  shared_data: "LIFT factor scores (Value Prop, Clarity, Relevance, Urgency, Anxiety, Distraction) + sub-factor flags that become hypothesis inputs here; ranked hypothesis queue passes to Kohavi for experimental design selection."

kohavi_integration:
  feeds_from: goward-hypothesis-generator
  feeds_to: kohavi-field-intelligence
  shared_data: "Prioritized hypothesis queue with effect-size estimates, traffic requirements, and LIFT factor tags; Kohavi selects test type (A/B vs. fractional factorial DOE) based on traffic volume thresholds declared here."

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: goward-hypothesis-generator
  shared_data: "Peak-End, Framing, and Loss Aversion diagnostics feed hypothesis copy-angle column; hypotheses that target Anxiety factor often require kahneman-prospect-theory-architect framing to flip perceived-cost calculus."
---

# Goward Hypothesis Generator — Click Architecture

## LAYER 1: INVARIANTS (Never override.)

1. **Value Proposition first, always.** The VP sets the conversion ceiling. No hypothesis targeting Clarity, Relevance, Urgency, Anxiety, or Distraction ships before at least one VP hypothesis is queued. If the LIFT audit scores VP < 7/10, VP hypotheses are Tier 1 by definition.
2. **One primary metric per test.** Each hypothesis names exactly one macro conversion event (purchase, lead, signup). Micro-conversions (scroll depth, click-through) are tracked but never used as the success criterion. Testing toward secondary metrics produces misleading results.
3. **Diagnose before you prescribe.** Hypotheses must be traceable to a specific LIFT factor + sub-factor flag. "Test a red button" with no LIFT grounding is not a hypothesis — it is a guess. Reject it.
4. **Inhibitors before drivers.** Remove Anxiety and Distraction hypotheses before adding Clarity, Relevance, or Urgency treatments. Amplifying urgency on an anxious page worsens conversion. Sequencing is a constraint, not a preference.
5. **Left-field variation required.** Every test batch must contain at least one "wild card" variation that isolates an untested structural hypothesis (layout shift, radical copy reframe, form field addition). Wild cards expose new testing directions when incremental variants plateau.
6. **Statistical significance is not optional.** Every hypothesis must declare a minimum detectable effect (MDE) and estimated traffic requirement before it enters the queue. Underpowered tests are not tests — they are noise that consumes traffic budget.
7. **Redesigns get tested before rollout.** Any hypothesis proposing a full-page layout change must be validated against the control in a live A/B test before permanent deployment. Redesigns do not guarantee improvement.

## LAYER 2: QUALITY GUIDANCE

1. Hypotheses that can be traced to a POD (Point of Difference from POPs/PODs/POIs audit) score highest — they address what prospects want AND what competitors cannot match, maximizing both relevance and lift ceiling.
2. Copy hypotheses should include a first-person button variant ("Get My [X]") and a curiosity-gap variant ("Find out if you qualify") alongside the control. Default to testing these two angles before elaborate creative variants.
3. For sites under 1M monthly visitors, flag hypotheses that can be bundled into a fractional factorial DOE batch — this achieves multivariate insight without multivariate traffic requirements. Signal clearly which hypotheses are bundle-eligible.
4. Every hypothesis queue should sequence from highest-structural-impact to lowest: value proposition > layout > headline > body copy > CTA > trust elements > form fields. Start big, then tighten.
5. Post-test learning extraction is part of the hypothesis lifecycle. Each hypothesis must pre-specify what will be learned if it wins AND what will be learned if it loses. Losing tests that teach something still advance the Infinity Optimization Process.

## PURPOSE

This skill converts LIFT Model audit findings into a prioritized, structured A/B hypothesis queue — transforming diagnostic scores into experiments Kohavi can actually run. It applies Chris Goward's Kaizen Method sequencing and Infinity Optimization Process logic to decide which hypotheses get tested first, in what order, and at what traffic threshold.

The operative lever: **We can score any landing page on 6 conversion forces before testing** — and those scores directly rank which experiments will move revenue the most.

This skill operates AFTER goward-lift-scorer produces factor scores. It does NOT re-score the page. It takes scores + sub-factor flags as inputs and outputs a ranked, test-ready hypothesis backlog.

## INPUT REQUIREMENTS

**Required:**
- The page (URL, screenshot, or written description)
- The ONE desired action (e.g., "click Add to Cart," "submit lead form," "start free trial")
- LIFT factor scores (1-10 per factor: Value Prop, Clarity, Relevance, Urgency, Anxiety, Distraction) — from goward-lift-scorer or manual audit
- Sub-factor flags: which specific elements dragged or boosted each score

**Optional but high-value:**
- POPs/PODs/POIs competitive audit (sharpens VP hypotheses)
- Analytics data: bounce rate, scroll depth, form-field drop-off, traffic source breakdown
- Qualitative research: user test quotes, heatmap observations, survey responses
- Audience segment and funnel position (top-of-funnel opt-in vs. bottom-of-funnel purchase behave differently)
- Monthly visitor volume (determines A/B vs. DOE bundling eligibility)

## EXECUTION PROCESS

**Step 1 — Ingest LIFT scores and flag the conversion ceiling.**

Accept the six LIFT scores. Compute the Conversion Ceiling Score:
- VP score sets the ceiling. If VP < 6, flag: "VP is a hard blocker — ceiling is low regardless of other factor improvements."
- Inhibitor Drag Score = average of (10 - Anxiety score) + (10 - Distraction score). Higher = more drag to remove.
- Driver Headroom Score = average of (10 - Clarity score) + (10 - Relevance score) + (10 - Urgency score). Higher = more headroom to capture.

Threshold rule: If Inhibitor Drag Score > Driver Headroom Score, the queue must lead with Anxiety + Distraction hypotheses before adding driver treatments.

**Step 2 — Run the POPs/PODs/POIs audit (if not already done).**

Three-column table:

| Prospect Need | Competitors Have | This Page Claims |
|---|---|---|
| [need] | [yes/no/partial] | [yes/no/how stated] |

Identify every row where "Competitors Have = no" AND "Prospect Need = high." These are PODs. Flag them as Priority VP hypothesis material. Any POD not in the headline or hero copy is an immediate Tier 1 hypothesis.

If POPs dominate the above-the-fold copy ("we're easy to use, fast, and trusted") and PODs are buried or absent, add hypothesis: "Move POD language to headline — test against current."

**Step 3 — Generate hypotheses per LIFT factor.**

For each factor scored below 8/10, generate 2-4 hypotheses. Template per hypothesis:

```
H[N]: [Factor] | [Sub-factor flag] | [Predicted direction]
Rationale: [Why this element creates drag or missed lift, grounded in LIFT sub-factor]
Variation A: [Control — describe exactly]
Variation B: [Treatment — describe exactly, specific copy/layout change]
Wild Card: [Yes/No — if Yes, describe the structural shift]
MDE: [Minimum detectable effect, e.g., +10% conversion rate]
Traffic needed: [Estimated visitors for 95% significance at stated MDE]
DOE-eligible: [Yes/No — can bundle with other element tests if site < 1M/mo]
```

**Step 4 — Apply sequencing rules.**

Assign each hypothesis to a tier:

- **Tier 1 (Test first):** VP score < 7 OR any POD absent from headline. Also: any Anxiety or Distraction sub-factor flagged as "severe" (pulling more than 2 points off the score).
- **Tier 2 (Test second):** Inhibitor drag > driver headroom. Anxiety/Distraction hypotheses that are moderate (1-2 point drags). Navigation elimination, trust badge repositioning, form field rationalization.
- **Tier 3 (Test third):** Clarity, Relevance, Urgency improvements after inhibitors are reduced. Headline copy variants, button copy tests (first-person vs. action-gap), traffic-source message match.
- **Tier 4 (Optimization):** Micro-refinements — color, layout micro-adjustments, supporting copy — tested only after Tier 1-3 wins are validated and a new baseline is established.

**Step 5 — Bundle DOE candidates (for sites < 1M monthly visitors).**

For any hypotheses in the same tier that test different page elements (e.g., headline copy + button copy + trust badge placement), flag them as bundle-eligible for fractional factorial DOE. This allows multivariate insight at A/B traffic cost.

Bundle rule: Maximum 4 elements per DOE batch. Each element must have exactly 2 variants (control vs. treatment). Declare the fractional factorial design (e.g., L4 orthogonal array for 3 elements) in the output.

**Step 6 — Write the pre-test learning declaration.**

For each Tier 1 and Tier 2 hypothesis, complete:
- "If this wins, we learn: [specific behavioral insight about how this audience decides]"
- "If this loses, we learn: [specific counter-insight, and what we test next]"

This is the Infinity Optimization Process handoff — every result, win or lose, seeds the next Explore phase.

**Step 7 — Output the ranked queue.**

Produce the hypothesis backlog table (see Output Structure) and the recommended first test with full variation specs.

## OUTPUT STRUCTURE

**Section 1: Conversion Ceiling Summary**
- VP score + ceiling call ("VP is a hard blocker" / "VP is adequate, headroom available")
- Inhibitor Drag Score vs. Driver Headroom Score
- Sequencing call: "Lead with inhibitor removal" or "Lead with driver capture"

**Section 2: PODs Identified**
- Table: Prospect Need | Competitors Have | This Page Claims | POD Status
- List of untested PODs that become Tier 1 VP hypotheses

**Section 3: Hypothesis Queue**

| # | Tier | Hypothesis [Factor] | MDE | Traffic | DOE? |
|---|------|---------------------|-----|---------|------|
| H1 | 1 | Move POD to headline [VP] | +15% | 4,200 | No |
| H2 | 1 | Remove nav links [Anxiety] | +8% | 8,000 | Yes |
| ... | | | | | |

Legend: Factor tag in brackets — VP/Clarity/Relevance/Urgency/Anxiety/Distraction. MDE = minimum detectable effect (% lift); Traffic = estimated unique visitors for 95% sig; DOE = bundle-eligible for fractional factorial.

**Section 4: Full Specs — Tier 1 Hypotheses**
Variation A / Variation B / Wild Card / Win-learns / Loss-learns for each Tier 1 item.

**Section 5: DOE Bundle Specs (if applicable)**
Orthogonal array, elements, variants, and traffic requirement for any bundled batch.

**Section 6: Infinity Optimization Handoff**
One paragraph: what qualitative research (user testing, Motivation Lab probes) should run in parallel to seed the next Explore phase. Which LIFT factors remain unaddressed and why.

## WORKED MINI-EXAMPLE

**Page:** SaaS free-trial landing page. Desired action: Start Free Trial (form submit).

**LIFT scores received from goward-lift-scorer:**
- VP: 5/10 (headline says "Powerful Project Management Software" — a POP, not a POD)
- Clarity: 7/10
- Relevance: 6/10 (traffic source is Google Ads "remote team software" — headline doesn't mirror)
- Urgency: 4/10 (no temporal or scarcity frame)
- Anxiety: 5/10 (credit card required field, no "cancel anytime" signal)
- Distraction: 4/10 (top nav with 6 links intact on page)

**Ceiling call:** VP = 5 — hard blocker. Inhibitor Drag = (5 + 6) = 11. Driver Headroom = (3 + 4 + 6) = 13. Roughly even — remove inhibitors AND lift VP simultaneously in Tier 1.

**POD found:** Competitor analysis shows no other tool offers async video comments inside tasks. Page buries this in paragraph 4.

**Tier 1 hypotheses generated:**

H1 | VP | Headline replaces "Powerful Project Management Software" with "The only project tool with async video comments — so remote teams stop scheduling meetings to explain things."
- Control: "Powerful Project Management Software"
- Treatment: POD headline (above)
- MDE: +15% | Traffic: 5,000 | DOE: No (structural)
- Win-learns: POD resonates as primary motivator for remote audience
- Loss-learns: POD is not primary decision criterion — probe what is via user testing

H2 | Anxiety | Remove "Credit Card Required" label; add "Cancel any time, no questions" below CTA
- Control: Current form with CC label
- Treatment: CC label removed, cancel-anytime copy added
- MDE: +12% | Traffic: 6,200 | DOE: Yes (bundle with H3)

H3 | Distraction | Strip top navigation from page
- Control: 6-link nav present
- Treatment: Nav removed, logo only
- MDE: +8% | Traffic: 9,300 | DOE: Yes (bundle with H2)

DOE Bundle: H2 + H3 use L4 orthogonal array (2 elements × 2 variants = 4 test cells). Traffic requirement: 9,300 (driven by the lower-effect hypothesis, H3).

**Before headline:** "Powerful Project Management Software"
**After (treatment):** "The only project tool with async video comments — so remote teams stop scheduling meetings to explain things."

Result expected: VP ceiling rises from 5 to 7+; Anxiety drag falls; Distraction drag falls. Net: three LIFT factors improved across two test rounds.

## OUTPUT FILE

Save to: [project-folder]/Goward - Click Architecture/[YYYY-MM] - Hypothesis Queue - [Page Name].md
