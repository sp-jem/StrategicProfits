---
name: brignull-dark-pattern-scanner
description: Use when you need to audit a live page for deceptive design — scans for all 16 named dark patterns, scores each instance by severity, and outputs a prioritized remediation list grounded in Brignull's taxonomy and the Disclosure Test.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Harry Brignull (deceptivedesign.org, 2010–2023; The 16-Pattern Deceptive Design Taxonomy + Mathur et al. 2019 + Disclosure Test) — Click Architecture (Skill 1 of 7)"
interface:
  invoke: "/brignull-dark-pattern-scanner"
  calls: []
  called_by: [user, brignull-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "A/B tests, pricing logic, and copy rotate frequently — a page clean last month may have a new countdown timer or preselected upsell today."

brignull_cluster_integration:
  feeds_from: [brignull-field-intelligence]
  feeds_to: [brignull-sludge-auditor, brignull-consent-integrity-checker, brignull-ethical-line-mapper, brignull-fair-pattern-designer]
  shared_data: "Pattern inventory list (pattern name, element ID/selector, severity score) — downstream skills consume this list without re-scanning the page."

fogg_integration:
  feeds_from: [fogg-behavior-mapper]
  feeds_to: [fogg-prompt-designer]
  shared_data: "Motivation + ability map. Brignull scanner flags when an interface lever exploits an ability deficit (confusion, friction) rather than a genuine motivation signal — Fogg's ability axis is the diagnostic bridge."

thaler_integration:
  feeds_from: [thaler-default-detector, thaler-nudge-auditor]
  feeds_to: [thaler-choice-architect]
  shared_data: "Default and framing inventory. Thaler's defaults are ethical when they serve user welfare; Brignull's preselection pattern is the same mechanism turned predatory. Shared data: list of every default/preselection with a pass/fail against the Disclosure Test."

kahneman_integration:
  feeds_from: [kahneman-framing-engineer]
  feeds_to: [kahneman-anchoring-designer]
  shared_data: "Cognitive-bias exploitation map. Dark patterns are engineered bias exploits (anchoring, loss aversion, social proof). Brignull scanner labels each pattern with the bias it targets — Kahneman tools then decide whether the lever is ethical or manipulative in context."
---

# Brignull Dark Pattern Scanner

## LAYER 1: INVARIANTS (Never override.)

1. **Scan against all 16 named pattern types** from Brignull's taxonomy every run. Never skip a category because it "probably isn't there." Omission is how dark patterns survive audits.
2. **Apply the Disclosure Test to every flagged element.** Ask: if a fully-informed user heard an accurate plain-language description of what this element does, would they still complete the desired action? If yes — persuasion, leave it. If no — dark pattern, flag it.
3. **Severity is determined by three axes:** (a) reversibility of harm (can the user undo?), (b) financial or data impact, (c) prevalence on the page. Never collapse to a single-axis "high/medium/low" without all three.
4. **Do not suggest removing a lever just because it feels aggressive.** Fake urgency is a dark pattern; real urgency (genuine cohort deadline) is not. Distinguish mechanism from ethics, not intensity from ethics.
5. **Report pattern name, exact location on page (element, section, or selector), and the manipulation mechanism** — not just "this looks bad." Brignull's taxonomy has names for a reason: they communicate precisely to developers and regulators.
6. **Flag compounding combinations.** A single preselected checkbox is a pattern. A preselected checkbox + trick wording + visual interference stacked on the same element is a compounded exploit — score it separately and higher.
7. **The Roach Motel parity test is mandatory.** Count clicks-to-convert vs. clicks-to-exit. Asymmetry >= 2 extra clicks to exit = automatic HIGH severity.

## LAYER 2: QUALITY GUIDANCE

1. **Name the bias each pattern exploits.** Use Conti-Sobiesk's five axes (Coercion, Confusion, Distraction, Interruption, Obfuscation) as a second-lens label on every finding — this adds precision beyond the taxonomy name alone.
2. **Provide a before/after rewrite for every copy-based pattern** (confirmshaming, trick wording, nagging). The rewrite must pass the Disclosure Test and the "regulator reads it aloud in court" test.
3. **Prioritize by legal exposure first, conversion impact second.** The FTC's 2024 click-to-cancel rule and EU GDPR/DSA enforcement are live enforcement risk — Roach Motel and Hidden Subscription findings go to the top of the priority stack regardless of conversion delta.
4. **Do not pad the finding list.** A real audit on a well-designed page may surface zero patterns. That is a valid output. Do not manufacture warnings to seem thorough.
5. **Every remediation recommendation must be implementable by a developer or copywriter without additional research.** Vague guidance ("improve clarity") is not a deliverable.

## PURPOSE

This skill encodes Harry Brignull doing his best work on a live web page: running a systematic 16-pattern forensic audit, scoring each instance against the Disclosure Test, and producing a prioritized remediation list that eliminates manufactured compliance while preserving genuine persuasion levers.

**Brag line: "We use the strongest levers known — and we know exactly where the line is."**

The operational value: every conversion optimization tactic is somewhere on Brignull's Honesty Spectrum (transparent disclosure → omission → deliberate deception). This scan locates every lever on that spectrum so the team can keep what is genuinely persuasive, fix what is accidentally deceptive, and remove what is deliberately manipulative — before a regulator does it for them.

## INPUT REQUIREMENTS

**Required:**
- The page: URL (live), screenshot(s), or written element-by-element description
- The ONE desired action: what the page is trying to get the user to do (e.g., "submit email," "start free trial," "complete purchase")

**Optional (increases precision):**
- Analytics: exit rates, drop-off points, rage-click heatmap data
- Audience: first-time vs. returning, cold vs. warm traffic
- Funnel position: top-of-funnel awareness vs. checkout vs. upsell
- Regulatory context: US (FTC), EU (GDPR/DSA), or UK (CMA) enforcement priority

## EXECUTION PROCESS

### Step 1 — Element Inventory (5 min)
List every interactive and informational element on the page: CTAs, checkboxes, toggles, countdown timers, scarcity messages, review/activity signals, price displays, decline links, fine print, and form fields. Assign each a short label (e.g., "CTA-1," "CB-1," "TIMER-1"). This is the audit surface.

### Step 2 — 16-Pattern Scan
For each element, test against all 16 pattern types. Mark each as PRESENT / ABSENT / NEEDS-VERIFICATION.

| Pattern | Trigger Condition |
|---|---|
| Comparison Prevention | Bundled pricing that blocks apples-to-apples compare |
| Confirmshaming | Decline copy shames or mocks the user |
| Disguised Ads | Ad styled as editorial/native content |
| Fake Scarcity | Stock/seat limit not tied to real inventory |
| Fake Social Proof | Fabricated or filtered reviews/activity signals |
| Fake Urgency | Countdown resets on refresh; deadline is invented |
| Forced Action | Desired action bundled with unwanted obligation |
| Hard to Cancel | Exit path requires more steps or friction than entry |
| Hidden Costs | Final price > first-seen price by more than 10% |
| Hidden Subscription | Auto-enrollment without explicit affirmative consent |
| Nagging | Dismissed request resurfaces within same session |
| Obstruction | Deliberate friction on a user-desired path (unsubscribe, refund) |
| Preselection | Consequential option checked/on by default |
| Sneaking | Critical info withheld until post-commitment |
| Trick Wording | Double negative, ambiguous, or self-contradictory copy |
| Visual Interference | Key info smaller/lower-contrast than CTA it qualifies |

*Legend: Compare Prev = Comparison Prevention; Fake Soc = Fake Social Proof; Fake Urg = Fake Urgency; Force Act = Forced Action; Hard Cancel = Hard to Cancel; Hidden Cost = Hidden Costs; Hidden Sub = Hidden Subscription; Trick Word = Trick Wording; Visual Int = Visual Interference.*

### Step 3 — Disclosure Test (Per Flagged Element)
For each PRESENT finding, apply the Disclosure Test:
> "If this user heard: '[plain-language description of what this element actually does]' — would they still take the desired action?"

Score: PASS (persuasion, keep) | FAIL (dark pattern, remediate).

### Step 4 — Conti-Sobiesk Axis Label
Label each failing element with its primary attack vector:
- **Coercion** — forces action (Forced Action, Hard to Cancel)
- **Confusion** — creates ambiguity (Trick Wording, Comparison Prevention)
- **Distraction** — pulls attention from critical info (Disguised Ads, Visual Interference)
- **Interruption** — blocks task flow (Nagging)
- **Obfuscation** — hides information (Sneaking, Hidden Costs, Hidden Subscription)

### Step 5 — Severity Scoring
Score each flagged pattern on three axes (1–3 each), sum for total (max 9):

| Axis | 1 | 2 | 3 |
|---|---|---|---|
| Reversibility | User can undo | Costly to undo | Irreversible |
| Impact | UX annoyance | Financial/data | Regulatory risk |
| Prevalence | Single instance | Repeated on page | Structural/systemic |

Threshold: 7–9 = CRITICAL (remediate before next traffic push); 4–6 = HIGH; 1–3 = MEDIUM.

### Step 6 — Roach Motel Parity Test
Count clicks-to-desired-action (e.g., sign up). Count clicks-to-exit (cancel/unsubscribe/delete). If exit requires 2+ more clicks than entry, or requires phone/chat/email: CRITICAL finding, automatic score 9. Apply FTC click-to-cancel standard: cancellation must be as simple as enrollment.

### Step 7 — Prioritized Remediation List
Sort all FAIL findings by severity score (descending). For each:
- Pattern name + element label
- Conti-Sobiesk axis
- Severity score (with three-axis breakdown)
- Exact remediation instruction (copy rewrite, code change, or design change)
- Disclosure Test status

## OUTPUT STRUCTURE

### 1. Page Header
Page URL / description | Desired action | Scan date | Auditor (Brignull framework v2023)

### 2. Element Inventory
Numbered list of all audited elements.

### 3. Pattern Findings Table

| # | Pattern | Element | C-S Axis | Sev | Action |
|---|---|---|---|---|---|
| 1 | [name] | [label] | [axis] | [1-9] | [fix] |

*C-S = Conti-Sobiesk axis; Sev = severity score (max 9)*

### 4. Disclosure Test Summary
Each flagged element: plain-language description written out + PASS/FAIL verdict.

### 5. Prioritized Remediation List
Critical → High → Medium, with exact implementable instructions.

### 6. Copy Rewrites (if applicable)
Before/after for every confirmshaming, trick wording, or nagging instance.

### 7. Roach Motel Report
Click-count comparison table: entry path vs. exit path.

### 8. Clean Score
"X of 16 pattern types absent. Y instances flagged. Z instances CRITICAL."

## WORKED MINI-EXAMPLE

**Page:** SaaS free-trial signup page. **Desired action:** Submit email to start trial.

**Scan surfaces three findings:**

**Finding 1 — Confirmshaming (CRITICAL, score 8)**
- Element: CB-DECLINE (decline link below CTA reads "No thanks, I don't want to grow my business")
- C-S Axis: Coercion
- Severity: Reversibility=1, Impact=2 (brand/trust), Prevalence=3 (structural copy) = 6 → plus regulatory optics = 8
- Disclosure Test: "This decline link is written to make you feel foolish for not signing up." — FAIL
- Before: "No thanks, I don't want to grow my business"
- After: "No thanks, I'll pass for now"
- Regulator test: passes. Neutral. Factual.

**Finding 2 — Preselection (HIGH, score 6)**
- Element: CB-1 (pre-checked "Send me weekly tips and offers")
- C-S Axis: Obfuscation
- Severity: Reversibility=2, Impact=2, Prevalence=2 = 6
- Disclosure Test: "This box is pre-checked so you consent to marketing emails without noticing." — FAIL
- Remediation: Uncheck by default. Rewrite label: "Yes, send me weekly tips and offers (optional)."

**Finding 3 — Visual Interference (MEDIUM, score 4)**
- Element: FINE-1 ("Auto-renews at $97/mo after trial" in 9px gray below fold)
- C-S Axis: Distraction
- Severity: Reversibility=2, Impact=2, Prevalence=1 = 4 (but escalates to HIGH if recurring billing)
- Disclosure Test: "The renewal price is visually hidden to prevent you from seeing it before you commit." — FAIL
- Remediation: Move auto-renewal disclosure to within 20px of the CTA button, minimum 13px, contrast ratio >= 4.5:1. Display as: "Free 14 days, then $97/month. Cancel anytime."

**Clean score after remediation: 3 of 16 patterns present → 0 after fixes. No Roach Motel asymmetry detected (cancel = 2 clicks = signup).**

## OUTPUT FILE
Save to: [project-folder]/Brignull - Click Architecture/[YYYY-MM] - Dark Pattern Scan - [Page Name].md
