---
name: gigerenzer-recognition-cue-architect
description: Use when a page suffers low conversion because visitors don't recognize the brand/product or face too many unfamiliar claims — maps and amplifies recognition signals so the Recognition Heuristic fires before the visitor's search process finds an exit.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Gerd Gigerenzer (Ecological Rationality 1999; Recognition Heuristic 2002; Adaptive Toolbox) — Click Architecture (Skill 2 of 7)"
interface:
  invoke: "/gigerenzer-recognition-cue-architect"
  calls: []
  called_by: [user, gigerenzer-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Recognition assets (logos, media placements, partner names) change; stale audits miss new signals or recommend retired ones."

gigerenzer_heuristic_fit_integration:
  feeds_from: gigerenzer-heuristic-fit-designer
  feeds_to: gigerenzer-take-the-best-sequencer
  shared_data: "Heuristic-fit score determines whether recognition or another cue is the highest-validity discriminator; pass the validity-ranked cue list to Take-the-Best for sequencing."

cialdini_integration:
  feeds_from: cialdini-social-proof-optimizer
  feeds_to: cialdini-field-intelligence
  shared_data: "Social proof logos and authority signals are recognition assets; cialdini-social-proof-optimizer surfaces the raw inventory; this skill scores them by recognition power and places them in the pre-CTA recognition block."

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: kahneman-availability-strategist
  shared_data: "Recognized names trigger System 1 availability bias; pre-load recognition before analytical copy so the visitor's fast system has already decided before slow deliberation begins."
---

# Gigerenzer Recognition Cue Architect

## LAYER 1: INVARIANTS (Never override.)

1. **Recognition is a prerequisite, not a nice-to-have.** The Recognition Heuristic (2002) requires one object to be recognized and the other not. An unrecognized brand competing against a recognized one loses the heuristic by default — no copy tactic compensates for missing recognition.
2. **Less-Is-More Effect (LIME) is real and directional.** Once a visitor recognizes your brand, adding more feature detail dilutes the recognition advantage by pulling them into analytical comparison mode. Never pile features onto a page that has already won on recognition.
3. **The stopping rule must fire at your CTA.** The Adaptive Toolbox Search/Stop/Decide cycle stops at the first discriminating cue. Your highest-validity recognition signal must appear before competing exits (nav links, competitor mentions, option overload) trigger an early stop elsewhere.
4. **Natural frequency framing is non-negotiable for any numeric claim.** "8 of 10 customers" (natural frequency) produces 7.1x better comprehension than "80% success rate" (conditional probability). Percentage framing stays off the page.
5. **One recognition block, placed above the fold, before any CTA.** Recognition signals scattered through the page do not prime the heuristic. Concentrated exposure before the ask does.
6. **Do not manufacture recognition you do not own.** Only assets with genuine recognition value in this visitor segment qualify. Logos of organizations the audience does not know are noise, not signals.
7. **Environmental design precedes persuasion copy.** Ecological Rationality: a heuristic is rational to the degree it fits the information environment. Fix the environment first (remove clutter, concentrate signals), then optimize copy.

## LAYER 2: QUALITY GUIDANCE

1. **Score every recognition asset against the specific audience segment.** A logo recognized by CMOs may be invisible to solopreneurs. Run a quick validity check: "Would 70%+ of this page's actual visitors recognize this name/logo?" Assets below threshold are cut.
2. **Audit for recognition saboteurs.** Unfamiliar brand names, jargon badges, internal-facing logos, and competitor comparisons in the opening screen all break or redirect the heuristic. Flag each one.
3. **Test the LIME condition before adding more signals.** If the page already has strong recognition (brand well-known to audience), resist the urge to add more proof — check whether conversion data shows analytical drop-off after the fold instead.
4. **Pair recognition placement with a clean stopping condition.** After the recognition block, there must be one unambiguous CTA. Do not follow recognition with a nav menu or secondary offer — the visitor's stopping rule must have only one favorable exit.
5. **Re-audit at max 45 days.** Media logos, partner names, and social proof assets age. A stale "As Seen On" block with outdated logos signals the brand is not currently active, reversing the recognition benefit.

## PURPOSE

This skill operates on a specific web page with a specific desired action. It applies Gigerenzer's Recognition Heuristic and Ecological Rationality to audit and redesign the page's recognition environment so visitors' fast-and-frugal search process stops at your brand and decides in your favor before it finds an exit.

The lever: familiar = chosen. The visitor's cognitive system does not compare every option — it stops the moment it recognizes a discriminating signal. This skill maps, scores, places, and formats every recognition asset on the page so that stopping rule fires at the CTA.

**Brag line: "We design WITH the mental shortcuts instead of fighting them."**

The Recognition Heuristic is the only conversion mechanism that works before the visitor reads a single word of copy. Win recognition first; copy closes the deal second.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written section-by-section description
- The ONE desired action (click / opt-in / purchase / next-step)
- The specific visitor segment (who arrives at this page and what do they already know)

**Optional (improves output):**
- Analytics: heatmaps, scroll depth, exit rate by section
- Current recognition assets inventory (logos, media mentions, authority names in use)
- Competitor pages (to assess relative recognition advantage)
- Funnel position (cold traffic vs. retargeting vs. warm list)

## EXECUTION PROCESS

### Step 1 — Segment Recognition Baseline
Before touching the page, define the recognition landscape for this specific visitor segment.

Threshold rule: An asset qualifies as a recognition signal only if **>= 70% of this segment** would recognize it on sight. Use this test for every candidate asset:

| Asset | Recognition test | Pass (>=70%) |
|-------|-----------------|--------------|
| Brand name | "Have they heard of us?" | Yes/No |
| Media logo | "Do they read/watch this outlet?" | Yes/No |
| Partner name | "Do they use/know this brand?" | Yes/No |
| Person name | "Do they follow/know this person?" | Yes/No |

Assets that fail the 70% test are removed from the recognition block — they are not recognition signals for this segment, they are noise.

### Step 2 — Map the Current Recognition Inventory
Scan the full page (above fold → below fold → footer) and catalog every asset that could function as a recognition signal. For each:

- Location on page (section name + approximate pixel depth)
- Asset type: brand name / media logo / authority name / social proof label / partner badge / most-popular tag
- Estimated segment recognition rate (0-100%)
- Current prominence: hero / inline / footer / hidden

Recognition inventory score = sum of (recognition rate x prominence weight) across all assets. Prominence weights: hero = 1.0, above fold = 0.8, first screen scroll = 0.5, below fold = 0.3, footer = 0.1.

### Step 3 — Identify Recognition Saboteurs
Scan for elements that disrupt or redirect the heuristic:

- **Unknown names competing for attention** with known names (dilutes discrimination)
- **Jargon badges** the segment does not recognize ("ISO 9001 Certified" to a consumer audience)
- **Competitor name mentions** in the opening screen (activates recognition for the competitor, not you)
- **Option overload** before the CTA (forces the visitor into multi-cue analytical mode, disabling Take-the-Best)
- **Cluttered logo bars** mixing recognized and unrecognized assets (unknown logos contaminate recognized ones)

Flag each saboteur with: location / type / recommended action (remove / relocate / replace).

### Step 4 — Score and Rank Assets by Validity
Rank all assets that passed the 70% recognition threshold by validity — their power to discriminate "this brand is worth choosing" in this segment's mind:

Validity score = (segment recognition rate) x (authority weight for this segment)

Authority weights by asset type (calibrate to segment):
- Tier 1 (weight 1.0): Category-defining media (e.g., WSJ, Forbes for business audience); dominant platform names (e.g., Apple, Google as partners)
- Tier 2 (weight 0.8): Industry publications; well-known influencers in segment
- Tier 3 (weight 0.6): Regional media; niche authorities
- Tier 4 (weight 0.3): General social proof counts ("10,000 customers") — recognized concept, no name value

The top-ranked asset is the **primary recognition anchor**. It gets hero placement, largest size, most visual prominence.

### Step 5 — Design the Recognition Block
Build one concentrated recognition block to appear **above the fold, before the primary CTA**. Structure:

1. Primary anchor (highest validity asset) — displayed alone or dominant
2. Secondary cluster (Tier 2-3 assets, max 5-6 logos/names) — displayed together in one row
3. Social frequency signal in natural frequency format (see Step 6)

Block placement rule: The recognition block must load within the first full viewport. If the page opens with hero copy and the CTA before any recognition signal, move the recognition block above or immediately below the hero headline — not after the CTA.

LIME check: If the brand is already well-known to this segment (recognition rate >85% for the brand name alone), skip adding more logos. The Less-Is-More Effect means additional signals pull the visitor into analytical mode where you lose the heuristic advantage. In this case, your job is to ensure the brand name is prominent and to clean saboteurs — not to add proof.

### Step 6 — Convert All Numerics to Natural Frequency Format
Every number on the page that supports the recognition/credibility claim must be reformatted:

Before/After conversion table:

| Original (probability) | Rewritten (natural frequency) |
|------------------------|-------------------------------|
| "80% success rate" | "8 of 10 customers saw X" |
| "Join 20,000+ members" | "20,000 people already inside" |
| "25% faster results" | "Results in 3 days vs. 4" |
| "Reduces churn by 30%" | "3 fewer customers lost per 10" |

Rule: always state the reference class explicitly. "Percent of what?" must be answerable from the sentence itself.

### Step 7 — Write the CTA Environment
After the recognition block fires the heuristic, the CTA must be the only available stopping exit. Audit:

- Remove secondary nav options from the CTA section
- Ensure CTA copy states ONE reason (Take-the-Best principle: the highest-validity cue only)
- CTA button label = action + the primary recognition anchor if possible ("Join [Primary Anchor Partner]'s network" or "Get in — as seen on [Anchor]")

CTA copy pattern: "[Action verb] + [one-reason decision support]"
Not: "Start your free trial and get access to 14 features including..."
Yes: "Start free — trusted by [recognized name]"

### Step 8 — Assemble Prioritized Change List
Output a ranked change list (highest recognition impact first):

Scoring: Impact = (recognition inventory score delta) x (funnel position weight)
Funnel position weights: cold traffic = 1.5x (recognition most critical), retargeting = 1.0x, warm list = 0.7x

## OUTPUT STRUCTURE

**Section 1: Recognition Baseline**
Segment definition + 70% threshold test results for every candidate asset. Pass/fail table.

**Section 2: Recognition Inventory Score**
Full asset catalog with location, type, recognition rate, prominence weight, and calculated score. Current total score.

**Section 3: Saboteur Report**
Every recognition disruptor on the page: location, type, impact, recommended action.

**Section 4: Validity-Ranked Asset List**
Assets ranked by validity score. Primary anchor identified. LIME check result.

**Section 5: Recognition Block Specification**
Exact placement, order, and size hierarchy of the new recognition block. Markup-ready description.

**Section 6: Natural Frequency Rewrites**
Table of every numeric claim on the page with original vs. rewritten version.

**Section 7: CTA Environment Edits**
Specific changes to the CTA section: removals, copy rewrites, button label.

**Section 8: Prioritized Change List**
Ranked actions with estimated recognition impact score delta. Quick wins (above fold, high delta) listed first.

## WORKED MINI-EXAMPLE

**Page:** Course landing page for a business productivity program. Desired action: opt-in for free training.

**Visitor segment:** Solopreneur business owners, warm-ish cold traffic from Facebook ad.

**Before (current state):**
- Hero: "The System That Transforms Your Business" (generic headline, no recognition signals)
- CTA: "Get Instant Access" button (appears immediately below hero, before any proof)
- Below fold: logos of Forbes, Inc., Entrepreneur (valid recognition assets, but buried)
- Below fold: "Join 12,000+ entrepreneurs" (percentage nowhere, but this is actually natural frequency — keep)
- Copy: "Our 80% completion rate proves this works" (probability format)

**Recognition inventory score (current):**
Forbes (hero) = n/a — not in hero; Forbes (below fold) = 0.85 x 0.3 = 0.26
Inc. (below fold) = 0.75 x 0.3 = 0.23
Total score: ~0.49 (weak — all recognition buried below fold)

**Problems identified:**
- Saboteur: CTA appears before any recognition signal — stopping rule fires on unfamiliarity, not recognition
- Saboteur: Generic hero headline activates no recognition
- Numeric: "80% completion rate" is probability format, low comprehension
- LIME condition: Not triggered — brand unknown to segment, needs more signals not fewer

**After (recognition block redesign):**
- Hero: Headline unchanged (it tests well) BUT immediately below headline, before CTA:
  - Recognition block: "As seen in [Forbes logo] [Inc. logo] [Entrepreneur logo]" — moved above fold
  - Natural frequency social proof: "12,000 business owners already inside" (was below fold, move up)
- CTA repositioned below recognition block: "Join them free — get the training"
- Copy fix: "80% completion rate" → "8 of 10 students complete every module"

**Recognition inventory score (after):**
Forbes (above fold) = 0.85 x 0.8 = 0.68
Inc. (above fold) = 0.75 x 0.8 = 0.60
Entrepreneur (above fold) = 0.70 x 0.8 = 0.56
Total score: ~1.84 (3.7x improvement, all from placement — same assets)

**Net change:** Zero new assets created. Same logos. Same social proof number. Placement moved three recognition signals from below fold (score weight 0.3) to above fold (weight 0.8). The visitor's Recognition Heuristic now has discriminating input before it hits the CTA. Stopping rule fires on your brand, not on unfamiliarity.

## OUTPUT FILE

Save to: [project-folder]/Gigerenzer - Click Architecture/[YYYY-MM] - Recognition Cue Audit.md
