---
name: hick-progressive-disclosure-designer
description: Use when a page presents too many choices at once and visitors stall before the primary CTA — stages option revelation across screens/accordions to minimize effective n at each decision point and cut conversion-killing cognitive latency.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "William Hick & Ray Hyman (Hick-Hyman Law 1952-1953; Progressive Disclosure Framework; Hyman Entropy Extension) — Click Architecture (Skill 4 of 7)"
interface:
  invoke: "/hick-progressive-disclosure-designer"
  calls: []
  called_by: [user, hick-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Conversion benchmarks, CTA count baselines, and funnel drop-off norms shift with platform updates and audience behavior; stale audit findings lead to wrong-directional changes."

hick_option_pruning_integration:
  feeds_from: hick-option-pruning-auditor
  feeds_to: hick-progressive-disclosure-designer
  shared_data: "Option count per decision zone (n values) and pruning candidates; pruning auditor eliminates options that should not exist, disclosure designer stages the ones that legitimately remain."

iyengar_integration:
  feeds_from: iyengar-choice-set-auditor
  feeds_to: hick-progressive-disclosure-designer
  shared_data: "Catalog display count recommendations (Jelly Jar data — 6 vs 24 flavors); Iyengar surfaces the optimal visible set size, Hick disclosure maps how to gate the remainder."

thaler_integration:
  feeds_from: thaler-default-detector
  feeds_to: hick-progressive-disclosure-designer
  shared_data: "Smart default selections that pre-fill high-probability choices; Thaler smart defaults set response uncertainty = 0 for pre-filled fields, compounding the entropy reduction achieved by staged disclosure."
---

# Hick-Hyman Progressive Disclosure Designer

## LAYER 1: INVARIANTS (Never override.)

1. **One primary CTA per conversion zone.** Response uncertainty is the dominant coefficient in the Hick-Hyman equation. A page with 5 competing action buttons carries multiple additional bits of processing latency regardless of how few options appear elsewhere. Remove before staging.

2. **Effective n at any single decision point must not exceed 7.** The law: RT = a + b × log₂(n+1). At n=7, log₂(8) = 3 bits — already 3× the cognitive cost of n=1. Beyond 7, decision time escalates steeply with no conversion benefit. This is a hard ceiling, not a guideline.

3. **Stage decisions sequentially, never flatten them.** Two sequential decisions each at n=5 cost log₂(6) + log₂(6) ≈ 5.2 bits. One flat decision at n=25 costs log₂(26) ≈ 4.7 bits numerically but produces perceived overwhelm that drives abandonment — the math underestimates the behavioral impact of all-at-once presentation.

4. **Every staged screen presents exactly one logical decision.** Contact info. Shipping. Payment. Confirmation. Mixing decision types on one screen raises effective n even when field count appears low.

5. **Advanced/secondary options live behind progressive gates — accordions, tabs, 'Learn more' — never in the primary view.** Gated options do not contribute to the entropy calculation H = -Σ p(i) × log₂(p(i)) until the user actively expands them. Only visible competing responses generate processing load.

6. **Pre-fill the highest-probability choice at every opportunity.** A smart default sets that field's response uncertainty = 0. The user's decision load is to confirm or override, not to choose from scratch.

7. **Measure time-to-first-click on the primary CTA as a leading indicator.** Hick-Hyman predicts this correlates with log₂(n) of competing clickable elements. If median time-to-click exceeds 8-12 seconds from page load, n is above threshold before A/B results are available.

---

## LAYER 2: QUALITY GUIDANCE

1. **Do not confuse option removal with progressive disclosure.** Removal (the pruning auditor's job) eliminates options that should not exist. Disclosure stages options that legitimately belong in the system but belong at a later decision point. Never delete valid options in the name of disclosure — gate them.

2. **Each disclosed stage must have its own clear progress signal.** Step indicators ("Step 2 of 3"), breadcrumbs, or progress bars reduce perceived decision weight of the full journey. Hyman's entropy extension shows that predictable, pattern-confirmable sequences lower effective response uncertainty at each stage.

3. **Benchmark before and after each staging change with time-to-click AND conversion rate.** These are separate metrics: faster decisions that don't convert indicate a disclosure sequence that accelerates users toward the wrong action. Both metrics must move together.

4. **Apply Goldilocks Calibration at the top of every staged funnel.** Pricing tiers: maximum 3. Navigation top-level: 5-7. Form fields per screen: maximum 3-5. Below 3 pricing options, users distrust the offer. Above 7 navigation items, marginal decision cost escalates sharply. These thresholds are empirically grounded, not aesthetic.

5. **Highlight one option per staged choice using 'Most Popular' or 'Recommended' badging.** Hyman's entropy extension: a high-probability expected option — visually marked — becomes the dominant p(i) term in H = -Σ p(i) × log₂(p(i)), reducing total entropy even when competitors remain visible.

---

## PURPOSE

This skill operates directly on a web page to minimize decision-latency at each conversion step by revealing choices in stages rather than all at once. The mechanism is the Hick-Hyman Law: RT = a + b × log₂(n+1). Every additional option at a single decision point adds a measurable increment of cognitive processing time — time that directly predicts drop-off. Progressive disclosure keeps effective n low at each screen without removing total option depth from the system.

The Hyman Entropy Extension adds the second lever: when options are not equally probable, decision time is governed by H = -Σ p(i) × log₂(p(i)). Making the desired action the highest-probability expected response — through visual hierarchy, placement, pre-selection, and "Recommended" badging — reduces its entropy cost even when competing options remain on screen.

**Brag line (carry this to a peer): "We cut decision time by removing options, and we can prove the math."**

This skill does not duplicate the pruning auditor (which eliminates options) or the categorization architect (which chunks flat lists). Its lane is staging: determining WHEN options are revealed across the conversion journey to minimize n at each point of action.

---

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description of current layout and all visible elements
- The ONE desired action: click / opt-in / purchase / next-step (stated explicitly)

**Strongly recommended:**
- Session recording or heatmap data (time-to-first-click on primary CTA, rage clicks, scroll depth)
- Current conversion rate and step-by-step funnel drop-off rates
- Number of form fields, CTA buttons, nav items, and pricing tiers currently on the page

**Optional:**
- Audience profile (sophistication level affects how much pre-filtering to do vs. how much to expose)
- Funnel position (top-of-funnel pages tolerate more exploration; bottom-of-funnel conversion pages must apply maximum staging discipline)

---

## EXECUTION PROCESS

### Step 1 — Decision Inventory (audit current effective n)

Map every visible interactive element on the page that could receive a click or input. Count them as n. Classify each as:
- **Primary action** (the desired conversion action)
- **Competing CTA** (another button/link at comparable visual weight)
- **Navigation escape** (nav bar, footer links, external links)
- **Form field** (each distinct input)
- **Option selector** (pricing tier, plan variant, product option)

Compute current effective n = count of all elements in all classes combined at first viewport.

**Threshold check:** If n > 7 at first viewport on a conversion page, disclosure architecture is required. If primary CTA is not the lone item in its class, competing CTAs must be removed or subordinated before staging work begins (use pruning auditor output if available).

### Step 2 — Entropy Diagnosis (Hyman Extension)

For each option class identified in Step 1, estimate the probability distribution a typical visitor assigns to clicking each item. Use heatmap click-share data if available; otherwise estimate from visual hierarchy and placement.

Compute approximate H for the CTA zone:
H = -Σ p(i) × log₂(p(i))

**Example:** 3 CTAs with observed click share 65% / 25% / 10%:
H = -(0.65×log₂0.65 + 0.25×log₂0.25 + 0.10×log₂0.10) ≈ 1.30 bits

Target: H < 0.5 bits for primary CTA zone (achieved when one option dominates at p ≥ 0.85). If H > 1.0 bits, competing CTAs are fragmenting attention and must be addressed via visual hierarchy or removal before disclosure staging.

### Step 3 — Stage Map Design

Decompose the full conversion journey into discrete logical stages. Each stage = one decision screen. Apply the rule: one decision type per screen.

For a typical sales/opt-in funnel:
- Stage A: Value decision (do I want this?) — primary CTA only, one offer
- Stage B: Configuration (which variant?) — max 3 options, one pre-selected
- Stage C: Contact (who are you?) — max 3 fields visible, others post-conversion
- Stage D: Payment — pre-filled defaults, one method prominent
- Stage E: Confirmation — zero new decisions

For a product catalog page:
- Stage A: Category selection (5-7 top-level chunks)
- Stage B: Curated set display (6-12 items, not full catalog)
- Stage C: Item detail with single primary CTA

Gate all secondary information (specs, FAQs, alternative plans, add-ons) behind accordions or tabs accessible from Stage B/C — they do not appear in the initial n count.

### Step 4 — Staging Mechanics Selection

Choose the appropriate disclosure mechanism per stage transition:

| Trigger | Mechanism | n reduction |
|---------|-----------|-------------|
| Spec detail | Accordion | Removes from n until expanded |
| Advanced options | Tab panel | Reduces primary n by tab count |
| Multi-step form | Sequential screens | Isolates each step's n |
| Catalog depth | Filter/search gate | Caps visible n at 6-12 |
| Add-ons | Post-CTA upsell | Removes from pre-CTA n entirely |

**Legend:** n = number of competing response options at decision point

### Step 5 — Default and Badging Layer

For every option set that remains visible after staging:
1. Identify the highest-conversion or most-recommended option
2. Apply "Most Popular" or "Recommended" badge
3. Pre-select it in any radio/checkbox/tab context

This exploits Hyman's entropy reduction: the badged option becomes the dominant p(i), collapsing H toward 0 even when alternatives remain visible.

For every form field in the staged flow:
- Pre-fill country from IP geolocation
- Pre-select most common shipping tier
- Pre-select most common subscription frequency
- Each pre-filled field drops response uncertainty to 0 for that input

### Step 6 — Competing Links Audit (Conversion Page)

On any page where Stage A occurs (the value/offer decision):
- Count all links in the body and header
- Conversion pages: maximum 2 links total (primary CTA + one secondary escape such as "Compare plans")
- Each additional link adds to n and increases probability that response lands on non-conversion behavior
- Navigation bars on conversion pages should be removed or collapsed to logo-only

### Step 7 — Measurement Plan

Define tracking before implementing:

| Metric | Tool | Target |
|--------|------|--------|
| Time-to-CTA click | Session recording | < 8 sec from page load |
| CTA click-through rate | Analytics | Baseline + 15% lift minimum |
| Step drop-off | Funnel report | < 20% loss per staged step |
| Entropy H (CTA zone) | Heatmap click-share | H < 0.5 bits |

A/B test variables in priority order: (1) number of CTAs, (2) number of form fields per screen, (3) number of pricing tiers, (4) nav presence/absence on conversion page. Do not test copy until decision architecture is optimized.

---

## OUTPUT STRUCTURE

**1. Decision Inventory Table** — All interactive elements mapped, classified, effective n at first viewport computed.

**2. Entropy Diagnosis** — H calculation for CTA zone with current click-share estimates; gap to target H < 0.5 bits.

**3. Stage Map** — Numbered stages with: decision type, options visible, n per stage, gates used to hold remaining options.

**4. Staged Screen Specifications** — Per stage: which elements are visible, which are gated, default/badge assignments, field pre-fill instructions.

**5. Competing Links Removal List** — Specific links to remove or suppress from conversion-page body and header.

**6. Measurement Plan** — Metrics, tools, targets, A/B test sequence.

**7. Expected Lift Calculation** — Using RT = a + b × log₂(n+1): show current RT estimate (b ≈ 0.155 sec per option) vs. post-staging RT estimate. Translate to expected conversion lift using benchmark: each field removed from a 5+ field form lifts completion ~18%; collapsing from 4 to 3 pricing tiers lifts trial-to-paid ~17% (Zoho benchmark).

---

## WORKED MINI-EXAMPLE

**Page:** SaaS pricing page. Current state: 4 pricing tiers displayed flat, each with 12 feature bullets, one "Start Free Trial" CTA per tier (4 CTAs total), full navigation bar with 7 links, a comparison table below the fold with 2 add-on checkboxes.

**Desired action:** Start free trial on mid-tier plan.

**Step 1 — Current effective n:** 4 CTAs + 7 nav links + 2 add-on checkboxes = n ≈ 13 at first viewport.

**Step 2 — Entropy diagnosis:** CTA click share estimated 15% / 40% / 30% / 15% across tiers.
H ≈ -(0.15×log₂0.15 + 0.40×log₂0.40 + 0.30×log₂0.30 + 0.15×log₂0.15) ≈ 1.85 bits. Target: < 0.5 bits.

**Step 3-6 — Staged redesign:**
- Collapse to 3 tiers (remove highest tier; move enterprise to "Contact us" link below fold)
- Badge mid-tier "Most Popular"; pre-select it
- Remove nav bar from pricing page (logo only)
- Move add-ons to post-trial-start onboarding screen
- Gate 12 feature bullets behind "See all features" accordion; show 3 bullets per tier in primary view
- Result: n at first viewport = 3 CTAs + 0 nav links = 3. H ≈ 1.46 bits → with "Most Popular" pre-selection driving p(mid) to ~0.65: H ≈ 1.30 → 0.87 bits after visual hierarchy applied.

**Expected impact (Hick-Hyman RT reduction):**
- Before: RT ≈ a + 0.155 × log₂(14) ≈ a + 0.58 sec
- After: RT ≈ a + 0.155 × log₂(4) ≈ a + 0.31 sec
- Decision latency reduction: ~0.27 sec per visitor. At 10,000 visitors/month, this predicts material drop in abandonment at decision moment.
- Benchmark lift: 4-to-3 tier reduction → ~17% trial-to-paid improvement (Zoho data). Nav removal on conversion page → reduces competing-link n from 10 to 1 → additional ~12-15% CTA CTR lift (CRO benchmark).

---

## OUTPUT FILE

Save to: [project-folder]/Hick-Hyman - Click Architecture/[YYYY-MM] - Progressive Disclosure Design.md
