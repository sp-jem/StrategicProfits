---
name: goward-field-intelligence
description: Use when you have outputs from at least 4 of 6 goward-* skills on the same page and desired action — synthesizes convergence zones, surfaces contradictions, delivers The Single Move and a 90-day conversion projection across the full Click Architects network.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Chris Goward (LIFT Model, 2009; Kaizen Method, 2012; Infinity Optimization Process, 2014; You Should Test That!, 2013) — Field Intelligence (Skill 7 of 7)"
interface:
  invoke: "/goward-field-intelligence"
  calls: [goward-lift-scorer, goward-value-prop-fulcrum-auditor, goward-clarity-relevance-optimizer, goward-anxiety-distraction-reducer, goward-urgency-architect, goward-hypothesis-generator]
  called_by: [user, click-architects]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Conversion dynamics shift with traffic source mix, offer evolution, and competitive landscape. LIFT scores older than 45 days may reflect an outdated audience-value-prop match. Reassess quarterly minimum, immediately after any major offer or traffic-source change."
pirolli_integration:
  feeds_from: [pirolli-field-intelligence]
  feeds_to: [pirolli-scent-gradient-designer]
  shared_data: "Pirolli's information foraging theory maps how visitors assess cost-to-benefit of following a scent trail. Goward's Clarity and Relevance factors are the on-page expression of scent strength — a high-scent page has clear, relevant copy that matches the visitor's information goal. Combined: Pirolli's scent diagnosticity score predicts which LIFT dimension is dragging most. If scent is breaking because the headline doesn't match the referral query, that's a Relevance problem (fix: match terminology exactly). If scent is breaking because the value prop is buried, that's a Clarity problem (fix: surface the POD paragraph). The synthesis reveals which LIFT fix most restores the foraging path."
kohavi_integration:
  feeds_from: [kohavi-field-intelligence]
  feeds_to: [kohavi-trustworthy-experiment-designer]
  shared_data: "Kohavi's trustworthy online experimentation framework is the validation layer for every Goward LIFT hypothesis. Goward diagnoses; Kohavi decides whether the test design will actually produce a reliable answer. Combined: every LIFT hypothesis must pass Kohavi's OEC (Overall Evaluation Criterion) test — is there a single, revenue-driving metric the test is optimizing for? Kohavi's minimum detectable effect threshold governs which LIFT-derived hypotheses are worth running given site traffic. Low-traffic sites must use Goward's fractional factorial DOE approach, not full MVT. The synthesis produces hypotheses that are both diagnostically valid (Goward) and statistically trustworthy (Kohavi)."
eisenberg_integration:
  feeds_from: [eisenberg-field-intelligence]
  feeds_to: [eisenberg-scent-continuity-auditor]
  shared_data: "Eisenberg's buying modalities (Competitive, Spontaneous, Methodical, Humanistic) map visitor decision styles that cross-cut Goward's LIFT factors. A Methodical visitor needs high Clarity and evidence-backed Value Prop. A Spontaneous visitor needs high Urgency and minimal Distraction. Combined: LIFT scores must be segmented by buying modality — what drags conversion for a Methodical visitor (insufficient detail = Clarity gap) is the opposite of what drags for a Competitive visitor (too much detail = Distraction). The synthesis reveals which LIFT interventions serve which modality and where one fix for one segment worsens another. Eisenberg's persuasion architecture maps the scent trail; Goward's POPs/PODs audit identifies what the trail should carry."
fitts_integration:
  feeds_from: [fitts-field-intelligence]
  feeds_to: [fitts-primary-action-dominance-scorer]
  shared_data: "Fitts's Law quantifies motor cost to reach the CTA: time = a + b·log2(distance/size + 1). Goward's Distraction factor captures everything that competes with CTA attention. Combined: total click cost = Fitts motor cost + Hick choice cost + Goward Distraction score. A page can have a large, well-positioned CTA (low Fitts cost) but still convert poorly because Distraction from navigation links and competing offers forces the visitor into choice paralysis. The synthesis identifies whether the CTA problem is physical (fix with Fitts: enlarge, reposition) or perceptual (fix with Goward: remove competing links, isolate the action). When both are suboptimal, address Distraction first — a fast path to a wrong destination still misses the macro conversion."
gigerenzer_integration:
  feeds_from: [gigerenzer-field-intelligence]
  feeds_to: [gigerenzer-single-cue-spotlighter]
  shared_data: "Gigerenzer's take-the-best heuristic reveals that visitors make decisions on ONE dominant cue when cognitive load is high. Goward's Value Proposition fulcrum is the candidate for that single cue. Combined: if the page presents multiple competing claims (Distraction), the visitor defaults to the wrong single cue — often price — rather than the POD that would tip the decision. The synthesis rule: identify the single most diagnostically valid cue (via POPs/PODs/POIs audit) and make it the only prominent element. Gigerenzer predicts that reducing the cue set to one increases conversion speed and reduces anxiety — both LIFT improvements. Test the Gigerenzer-derived single-cue version against the Goward multi-proof version for your specific audience."
laja_integration:
  feeds_from: [laja-field-intelligence]
  feeds_to: [laja-researchxl-diagnostic]
  shared_data: "Laja's ResearchXL framework combines six research methods (analytics, mouse tracking, qualitative surveys, user testing, live chat, copy testing) to surface conversion barriers invisible to heuristic analysis. Goward's LIFT Model is a heuristic framework — fast, expert-based, hypothesis-generating. Combined: LIFT is the diagnosis; ResearchXL is the verification. Every LIFT Anxiety or Distraction finding should be stress-tested against Laja's voice-of-customer data before committing test budget. If LIFT says Anxiety is the drag but customer survey language says 'too complicated to understand,' that's a Clarity problem, not Anxiety. ResearchXL stops expensive tests from optimizing the wrong LIFT dimension. Together: Goward generates the hypothesis fast, Laja confirms the root cause before the test runs."
norman_integration:
  feeds_from: [norman-field-intelligence]
  feeds_to: [norman-gulf-of-execution-reducer]
  shared_data: "Norman's gulf of execution (visitor can't figure out how to act) and gulf of evaluation (visitor can't tell if they acted successfully) map directly onto Goward's Clarity and Distraction factors. A gulf-of-execution failure is a Clarity problem — the desired action is not visible, labeled, or sequenced clearly. A gulf-of-evaluation failure creates Anxiety — did my form submit? is my cart saved? Combined: Norman's feedback-state design eliminates post-click Anxiety that Goward's LIFT audit often misses (LIFT focuses on pre-click, Norman focuses on the action and confirmation moment). The synthesis: audit pre-click LIFT factors with Goward, audit action/confirmation states with Norman. Both must pass before declaring a page optimized."
hick_integration:
  feeds_from: [hick-field-intelligence]
  feeds_to: [hick-option-pruning-auditor]
  shared_data: "Hick's Law: decision time = b·log2(n+1) where n is the number of equally weighted choices. Goward's Distraction factor captures the conversion drag from competing links and CTAs. Combined: total decision cost = Hick choice cost (from number of options) + Goward Distraction score (from salience competition). The critical synthesis: Hick says reducing options from 5 to 2 cuts decision time by ~60%. Goward says every non-CTA link on a conversion page is Distraction. Together: remove all navigation, reduce to one CTA, and verify via Goward's LIFT that the remaining Distraction (trust badges, social proof blocks, secondary copy) is net-positive for conversion rather than attention-splitting. The BabyAge.com layout test confirms: radical simplification of option count plus strategic repositioning of single CTA produced a significant revenue lift."
nielsen_integration:
  feeds_from: [nielsen-field-intelligence]
  feeds_to: [nielsen-f-pattern-layout-auditor]
  shared_data: "Nielsen's F-pattern and banner blindness research show how visitors scan vs. read pages. The F-pattern predicts which content gets attention — the top horizontal band and left vertical margin. Goward's Clarity factor depends on visitors actually reading the Value Proposition. Combined: if the POD statement (Goward's highest-leverage copy element) falls outside the F-pattern's primary attention zone, it will be missed regardless of how clear the writing is. The synthesis: first map the F-pattern for the page, then place the POD headline at the top of the first horizontal scan, and verify that Distraction elements (navigation, sidebars) are not competing with the primary F-pattern attention zones. Nielsen diagnoses where attention goes; Goward determines what must be there."
eyal_integration:
  feeds_from: [eyal-field-intelligence]
  feeds_to: [eyal-hook-loop-designer]
  shared_data: "Eyal's Hook Model (Trigger → Action → Variable Reward → Investment) applies to repeat visits and engagement sequences, not single-page conversion. Goward's LIFT Model optimizes the first-conversion moment. Combined: the Urgency factor in LIFT handles the single-session urgency trigger. But for retargeted visitors or email-driven traffic, Eyal's investment escalator predicts that visitors who have already taken a micro-action (downloaded a lead magnet, viewed a video) have higher variable reward anticipation — their internal trigger is primed. This means LIFT's Urgency factor can be reduced for warm traffic (they're already triggered) and Anxiety-reduction becomes the dominant lever. The synthesis: segment LIFT audits by traffic temperature. Cold traffic needs strong Value Prop + Urgency. Warm/retargeted traffic needs Anxiety reduction + Clarity of next step."
brignull_integration:
  feeds_from: [brignull-field-intelligence]
  feeds_to: [brignull-ethical-line-mapper]
  shared_data: "Brignull's dark pattern taxonomy identifies conversion-rate optimizations that exploit rather than persuade — confirmshaming, hidden costs, misdirection, trick questions. Goward's LIFT Model includes Urgency and Anxiety factors that can be implemented ethically or deceptively. Combined: every Goward Urgency tactic must pass Brignull's dark pattern audit. Countdown timers with real deadlines = ethical urgency (LIFT-positive). Fake countdown timers that reset = dark pattern that temporarily boosts conversion while destroying trust and LTV. Goward's own caution about premium-audience urgency backlash confirms this: sophisticated buyers detect manufactured scarcity. The synthesis rule: apply Goward's LIFT Urgency only when it is credible and brand-congruent; run Brignull's audit on every urgency element before testing."
fogg_integration:
  feeds_from: [fogg-field-intelligence]
  feeds_to: [fogg-prompt-designer]
  shared_data: "Fogg's B=MAP (Behavior = Motivation × Ability × Prompt) maps the behavioral substrate of every LIFT factor. Goward's Value Proposition is the motivation ceiling; Goward's Clarity and Distraction factors directly control ability (simpler page = higher ability); Goward's Urgency factor is the Spark prompt type (motivator-in-disguise). Combined: LIFT audits reveal WHICH behavioral factor is the bottleneck. High-Anxiety pages fail because the perceived cost side of Fogg's ability equation rises (effort + risk + social risk). High-Distraction pages fail because prompts get lost in noise. The synthesis: resolve LIFT factor priorities using Fogg's constraint — whatever reduces the highest ability bottleneck fastest is the first test, regardless of how compelling the Value Prop or Urgency improvements look."
cialdini_integration:
  feeds_from: [cialdini-field-intelligence]
  feeds_to: [cialdini-influence-audit]
  shared_data: "Cialdini's six influence principles map to LIFT factors: Social Proof reduces Anxiety (others have done this safely); Authority reduces Anxiety and lifts Value Prop credibility; Scarcity creates Urgency; Reciprocity creates pre-commitment that reduces Distraction; Commitment/Consistency anchors post-click behavior; Liking builds Relevance through persona-match. Combined: a LIFT audit that scores Anxiety as the primary drag should prescribe specific Cialdini social-proof and authority elements, not generic 'add testimonials.' The synthesis: map each LIFT gap to its Cialdini antidote, then test them as a unit (e.g., Anxiety drag + Authority deficit = expert-credentials block as the test variant)."
kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: [kahneman-prospect-theory-architect]
  shared_data: "Kahneman's prospect theory shows that losses loom larger than equivalent gains (~2× weight). Goward's Value Prop Cost-Benefit Equation (Perceived Benefits minus Perceived Costs) is systematically distorted by this asymmetry — every visible cost element (price, effort, risk) is overweighted by System 1. Combined: reducing Anxiety (cost-side of the equation) produces a larger conversion lift per unit of change than adding equivalent benefit-side Value Prop improvements. The synthesis: audit the Anxiety factors first in every LIFT run, not as an afterthought. Kahneman's framing research also predicts that reframing costs as opportunity costs ('what you get' vs. 'what you pay') reduces their psychological weight — a testable LIFT hypothesis."
thaler_integration:
  feeds_from: [thaler-field-intelligence]
  feeds_to: [thaler-nudge-auditor]
  shared_data: "Thaler's choice architecture (defaults, anchoring, mental accounting) operates at the structural level above Goward's element-level LIFT factors. Combined: a page's default state is itself a LIFT element — what loads first, what is pre-selected, what pricing tier is highlighted. Mental accounting predicts that segmenting the cost into smaller units (per-day pricing, installment framing) lowers perceived cost weight in the Value Prop Cost-Benefit Equation. The synthesis: Goward's POPs/PODs/POIs audit should include a Thaler-layer analysis of how the offer is structured, not just how the copy presents it. The highest-leverage LIFT-plus-Thaler test is changing the default framing of the offer, not the headline."
iyengar_integration:
  feeds_from: [iyengar-choice-set-auditor]
  feeds_to: [iyengar-tier-calibrator]
  shared_data: "Iyengar's choice overload research proves that reducing option sets increases both conversion rate and satisfaction. Goward's Distraction factor captures intra-page option overload (too many CTAs, links, offers). Combined: Iyengar quantifies what Goward qualifies. The synthesis: if a LIFT audit scores Distraction as a primary drag, run Iyengar's choice-set audit to count decision points, then apply the tier-calibrator to reduce to 3 options or fewer. Iyengar's jam study finding (24 options → 3% conversion; 6 options → 30% conversion) sets the benchmark for how much Distraction reduction is possible — before testing, estimate the conversion uplift ceiling using Iyengar's choice-set multiplier."
---

# Goward Field Intelligence

---

## LAYER 1: INVARIANTS (Never override.)

1. **Field Intelligence is synthesis, not summary.** This skill does NOT recap what individual skills found. It identifies PATTERNS ACROSS skills — convergence zones, contradictions, amplification opportunities, and the single highest-leverage intervention. If the output reads like a summary of six reports, it has failed.

2. **Convergence detection is mandatory.** When 3+ individual Goward skills point at the same intervention, element, or LIFT factor: that is a convergence zone. Convergence zones are the highest-confidence findings. Every convergence zone must be explicitly identified and named.

3. **Contradictions must be surfaced, not hidden.** When one skill recommends X and another recommends the opposite: this is signal. Contradictions reveal where LIFT factors have competing dynamics. Resolve by identifying which force dominates for this specific audience and offer.

4. **The Single Move is non-negotiable.** Every Field Intelligence briefing must produce exactly ONE recommended page change — the single intervention addressing the most convergence zones simultaneously. Not a list. Not options. ONE move.

5. **The Mirror is non-negotiable.** The business's own page-design biases must be examined. Where is the business defaulting to LIFT-negative patterns in its own page creation — over-indexing on copy cleverness when Value Prop clarity is weak, adding urgency to pages where Anxiety is already the primary drag, building pages for their own aesthetic preferences rather than visitor cognition?

6. **Cross-system intelligence is the highest-value section.** The intersections between Goward's LIFT lever and the broader Click Architects network produce insights unavailable within any single framework. These are the non-obvious findings.

7. **Freshness gate: 45 days.** Flag any individual Goward skill output older than 45 days as potentially stale before synthesizing.

---

## LAYER 2: QUALITY GUIDANCE

8. **Name the convergence zones.** Give each pattern a memorable label (e.g., "The Buried Fulcrum" for convergence around a Value Prop hidden below the fold, "The Trust Trap" for convergence where Anxiety-reducing trust badges are paradoxically increasing Anxiety by drawing attention to risk).

9. **Use the Cost-Benefit Equation directionally.** Every convergence zone should be scored: does it increase perceived benefits, decrease perceived costs, or both? The magnitude of the expected conversion shift depends on which direction and which side of the equation is being moved.

10. **The 90-Day Projection must be specific.** Not "conversion should improve." Instead: "If The Single Move (eliminate navigation, move POD paragraph to H1) is live by week 2, by day 30 we should see CVR shift from X% to Y% based on the Iron Mountain 404% benchmark for lead-gen pages. By day 90, if the first test confirms, run the DOE to isolate which of the three combined changes drove the lift."

---

## PURPOSE

Individual Goward skills each audit one dimension of the LIFT Model on a specific page targeting a specific desired action. The Lift Scorer produces the full six-factor score. The Value Prop Fulcrum Auditor finds whether the Value Proposition ceiling is high enough to support conversion at all. The Clarity-Relevance Optimizer surfaces the headline, copy, and traffic-match gaps. The Anxiety-Distraction Reducer identifies cost-side inhibitors. The Urgency Architect finds whether internal or external urgency is present, absent, or counterproductive. The Hypothesis Generator translates all findings into ranked A/B test hypotheses with predicted lift ranges.

Field Intelligence goes one level beyond the Hypothesis Generator. It finds convergence zones across all six Goward analyses, detects contradictions that reveal competing LIFT dynamics, identifies amplification opportunities where combined interventions create outsized lift, delivers The Single Move, holds up The Mirror to the business's own design biases, and — most critically — integrates the LIFT-derived intelligence with EVERY other Click Architect in the network. The result is not just a ranked test backlog — it is page-action intelligence situated within the complete understanding of how visitors decide, navigate, perceive, and act.

**Brag:** "We can score any landing page on 6 conversion forces before testing — and tell you which one to fix first."

---

## INPUT REQUIREMENTS

**Required:**
- Outputs from at least 4 of 6 individual Goward skills, all run on the same page and desired action

**Optimal:**
- All 6 individual Goward skill outputs
- Field Intelligence outputs from other Click Architects (Pirolli, Kohavi, Eisenberg, Fitts, Laja, Norman, Hick, Nielsen, Gigerenzer, Eyal, Brignull)
- Owned canon outputs (Fogg, Cialdini, Kahneman, Thaler, Iyengar)
- Page analytics: CVR, bounce rate, scroll depth, heatmap, session recordings
- Traffic source breakdown (organic, paid, email, referral)

**Minimum viable:** URL or written description of the page + the desired action + 4 skill outputs.

---

## EXECUTION PROCESS

### Step 1: Component Synthesis

For each available Goward skill output:

- **Skill name and date**
- **Freshness:** Current (≤45 days) / Aging (45-60 days) / Stale (>60 days)
- **LIFT factor addressed:** Which of the six factors this skill examined
- **Primary finding:** The one most impactful diagnosis
- **Recommended intervention:** Specific page change suggested
- **Confidence:** High (data-backed) / Medium (heuristic) / Low (inferred)

### Step 2: Convergence Detection

Cross-skill pattern matching on the LIFT Model:

**Convergence scoring:**
- 2 skills point at same LIFT factor or page element: Notable alignment
- 3 skills: Convergence zone — name it
- 4 skills: Strong convergence
- 5-6 skills: Critical convergence

**For each convergence zone:**
- **Name:** Memorable label capturing the insight
- **Contributing skills:** Which analyses point here
- **LIFT factor(s) implicated:** Which of the six factors are involved
- **What each found:** Specific findings that converge
- **System-level implication:** Why this matters as a pattern, not just an observation
- **Implied intervention:** What the convergence recommends changing on the page

**Common Goward convergence patterns to watch for:**
- "The Buried Fulcrum": Lift Scorer + Value Prop Auditor + Clarity Optimizer all flag that the clearest explanation of the offer is NOT in the headline — it is in a paragraph midway or below the fold. Intervention: extract that paragraph, make it the H1.
- "The Trust Trap": Anxiety Reducer + Urgency Architect both find that trust badges and countdown timers are competing for attention in the same visual zone, creating paradoxical Anxiety. Intervention: separate urgency from trust elements spatially.
- "The Relevance Mismatch": Clarity Optimizer + Hypothesis Generator both surface that traffic-source terminology does not match on-page terminology. Intervention: create traffic-source-specific landing pages with matched language.
- "The Distraction Tax": Lift Scorer + Anxiety Reducer + Hick (if available) all flag navigation links and competing CTAs as the primary drag. Intervention: strip page to single-purpose conversion layout.

### Step 3: Contradiction Detection

Cross-skill conflict identification:

**Common Goward contradiction patterns:**
- Urgency Architect recommends adding a countdown timer ↔ Anxiety Reducer finds that existing anxiety is already the primary drag (timer would amplify anxiety, not create urgency)
- Clarity Optimizer recommends shorter, simpler copy ↔ Value Prop Auditor finds the POD is not yet clearly articulated (cutting before the POD is communicated destroys the fulcrum)
- Hypothesis Generator ranks Urgency test as highest-ROI ↔ Lift Scorer shows Value Prop factor is below threshold (no amount of urgency rescues a weak value proposition)
- Anxiety Reducer recommends adding trust badges ↔ Lift Scorer finds Distraction is already a primary drag (more visual elements would worsen Distraction before reducing Anxiety)

**For each contradiction:**
- The tension between the two skill recommendations
- Why both are correct in their own frame
- Resolution logic for this specific page, audience, and offer
- Implementation approach that honors the deeper insight from both

### Step 4: Amplification Opportunities

Where combining Goward interventions creates outsized lift:

**LIFT amplification combinations:**
- Elevating Value Prop clarity (move POD to H1) + Removing top navigation (Distraction) + Adding one specific trust signal matched to primary Anxiety = triple-LIFT improvement from one page session
- Matching headline to traffic source (Relevance) + First-person CTA copy ("Get My Free Guide") + Isolating CTA button (remove competing links) = clarity + relevance + distraction addressed simultaneously
- POPs/PODs/POIs audit → isolate single strongest POD → test as standalone headline with all other elements removed = maximum signal on value proposition ceiling test
- Goward's DOE approach: test dramatically different layout + matched traffic copy + single trust signal as a fractional factorial — achieves multivariate insight at A/B traffic cost

**Cross-thinker amplification:**
- Goward Value Prop isolation + Gigerenzer single-cue simplification = highest-signal value prop test possible
- Goward Distraction removal + Hick option reduction + Fitts CTA sizing = total click cost minimization
- Goward Anxiety audit + Cialdini social proof selection + Norman confirmation feedback = end-to-end anxiety elimination (before, during, after the action)

### Step 5: The Single Move

ONE page change addressing the most convergence zones:

- **What to change:** The specific element and how it changes (before state → after state)
- **Why this is THE move:** Which convergence zones it addresses, how many LIFT factors it improves
- **Mechanism:** Which side of the Cost-Benefit Equation it moves (benefits up / costs down) and by which LIFT factor
- **Implementation:** Exact steps to execute the change on the page
- **Worked example:** Before: "Sign Up Now" as the H1 with three navigation options visible. After: "[Your POD sentence extracted from paragraph 4]" as the H1, navigation removed, single CTA button. Expected shift: CVR moves from baseline toward the Iron Mountain benchmark of 404% lift for lead-gen pages if Value Prop was the primary drag.
- **What it does NOT address:** Honest scope — state which LIFT factors remain unaddressed and which test should follow

### Step 6: The Mirror

Where the business's own page-design biases create LIFT-negative patterns:

- **Value Prop blindness:** The team that built the offer cannot see that the POD is obvious to them but invisible to visitors. They bury it because it feels too simple to feature. ("That paragraph at the bottom often is the most beautiful thing. We just take that, put it at the top." — Goward)
- **Urgency as default:** Adding countdown timers and deadline language to every page because urgency is a known conversion lever — without diagnosing whether Anxiety is the actual primary drag. Urgency on high-Anxiety pages worsens conversion.
- **Aesthetic distraction:** Designing pages for the brand's visual identity rather than for conversion. Navigation that reinforces brand architecture competes directly with the macro conversion CTA.
- **Testing small:** Running micro-element tests (button color, headline word changes) before testing dramatically different layouts and value prop framings. Goward's explicit guidance: start with higher-level, dramatically different approaches.
- **Analytics ≠ insight:** Using conversion rate as a post-hoc metric rather than diagnosing LIFT factors before building test hypotheses. The LIFT Model is the Kaizen Method's heuristic analysis step — it precedes test design, not follows it.
- **Redesign confidence:** Assuming a full site redesign improves conversion without A/B testing the new design against the current site. Redesigns frequently destroy conversion rates. Goward: validate every redesign before launch.

### Step 7: Cross-System Intelligence

**Goward × Pirolli:** LIFT Clarity and Relevance factors are the on-page expression of information scent. When scent breaks, visitors exit before the Value Prop is encountered — no amount of headline clarity recovers a visitor who left on page load because the referral copy didn't match. Diagnose scent failure (Pirolli) before diagnosing LIFT factor failures (Goward).

**Goward × Kohavi:** Every Goward LIFT hypothesis is only as good as the experimental design that tests it. Kohavi's minimum detectable effect and OEC selection govern which hypotheses are testable at current traffic volumes. LIFT diagnosis without Kohavi experimental rigor produces a backlog of tests that may never achieve statistical significance.

**Goward × Eisenberg:** LIFT factors must be scored per buying modality. A Methodical visitor's Clarity threshold is higher (needs more proof, more detail). A Spontaneous visitor's Distraction threshold is lower (exits faster on competing visual elements). Scoring LIFT as a single aggregate obscures segment-level dynamics.

**Goward × Fitts + Hick:** Total click cost = Fitts motor cost (distance/size to CTA) + Hick choice cost (log of competing options) + Goward Distraction score (attention competition). Eliminate Distraction first (highest leverage), then minimize Hick, then optimize Fitts. All three must be addressed to reach the click-cost floor.

**Goward × Gigerenzer:** The take-the-best heuristic predicts that visitors under cognitive load decide on one dominant cue. The POPs/PODs/POIs audit identifies which cue should dominate. Combining both: clear the field of competing cues (Distraction removal) and put the single strongest POD cue in the dominant position (F-pattern top).

**Goward × Laja:** LIFT is fast heuristic diagnosis. ResearchXL is slow empirical validation. Never run a test based solely on LIFT findings without Laja's voice-of-customer verification that the diagnosed LIFT factor matches actual visitor language. Misidentified LIFT factors produce expensive failed tests.

**Goward × Norman:** Goward optimizes the pre-click decision. Norman optimizes the action moment and confirmation feedback. A page can have a perfect LIFT score and still kill conversion at the form-submit or checkout-confirm stage because of a gulf-of-evaluation failure. Always apply Norman's feedback-state audit after Goward's LIFT audit.

**Goward × Hick:** Option count is a LIFT Distraction sub-factor. Hick provides the quantitative model for how much each additional option costs in decision time. Use Hick's law to calculate the expected decision-time reduction from specific Distraction removals before testing.

**Goward × Nielsen:** F-pattern placement determines whether the Value Prop — however clear — is actually seen. LIFT Clarity without Nielsen placement is wasted copy quality. The POD must land in the first horizontal scan band or it functions as if it were not there.

**Goward × Eyal:** Traffic temperature segmentation for LIFT. Cold traffic: maximize Value Prop + Urgency (they need motivation). Warm/retargeted traffic: maximize Clarity + minimize Anxiety (they're already motivated; reduce friction). The LIFT audit must know which traffic type it is scoring to prescribe the right intervention order.

**Goward × Brignull:** The ethical boundary for LIFT Urgency and Anxiety manipulation. Every urgency element must pass Brignull's credibility test. Manufactured scarcity and fake countdowns are dark patterns that temporarily inflate CVR while destroying customer LTV and brand trust. Goward's own premium-audience urgency warning is a Brignull-compatible constraint.

**Goward × Fogg:** LIFT factors map to B=MAP components. Value Prop determines motivation ceiling. Clarity/Distraction determine ability (perceived effort cost). Urgency determines prompt type (Spark vs. Facilitator). Every LIFT audit is simultaneously a B=MAP audit — use whichever framework produces the sharper diagnosis for the specific constraint.

**Goward × Cialdini:** Six influence principles map to six LIFT antidotes. Use this mapping to prescribe specific Cialdini elements for each LIFT gap rather than generic "add testimonials": Anxiety → Social Proof + Authority; Weak Value Prop → Scarcity + Reciprocity (pre-commit); Relevance → Liking (persona-match messaging); Urgency absence → Scarcity (credible constraint).

**Goward × Kahneman:** Prospect theory mandates: audit Anxiety (cost-side) before auditing Value Prop benefit additions. Loss weighting (~2×) means every visible cost element drags twice as hard as an equivalent benefit element lifts. Prioritize LIFT Anxiety and Distraction reduction over Value Prop enhancement whenever both are present.

**Goward × Thaler:** The offer structure is itself a LIFT element. Mental accounting and default-setting operate above the copy level. Before testing LIFT factor improvements, audit whether the offer framing, pricing tier display, and default selections are structurally sound via Thaler's choice architecture lens.

**Goward × Iyengar:** Distraction factor quantification. Iyengar's choice-set research sets the benchmark: more than 6-7 options produces choice paralysis. Count every decision point on the page (links, CTAs, navigation items, form fields, pricing tiers). If the count exceeds 6, run Iyengar's tier-calibrator before running LIFT Distraction removal — the structural fix is larger than copy-level cleanup.

**Cross-system convergence (highest-confidence findings):**
When LIFT Distraction drag aligns with Hick choice overload, Fitts CTA obscurity, Nielsen F-pattern violation, and Gigerenzer cue competition simultaneously: the page has a structural attention architecture failure, not a copy problem. The Single Move in this case is a layout redesign (validated against current via A/B), not a headline test.

When LIFT Value Prop weakness aligns with Eisenberg Methodical-modality Clarity gap, Pirolli scent break, and Kahneman loss-salience: the POD is not visible, not credible, and not specific enough. The Single Move is the POPs/PODs/POIs audit followed by a headline test using the strongest POD as the only claim.

### Step 8: Coherence Map

Score the overall conversion optimization coherence:

| Dimension | Score | Assessment |
|-----------|-------|------------|
| LIFT internal | 1-10 | Do the 6 LIFT factors function as a system? |
| Cross-system | 1-10 | Do Click Architect findings align with LIFT? |
| Test sequence | 1-10 | Is there a non-conflicting test roadmap? |
| Audience fit | 1-10 | Does the LIFT diagnosis match traffic type? |

*Legend: LIFT internal = how well the six factors interact on this specific page; Cross-system = alignment between Goward findings and other Click Architects; Test sequence = whether the test backlog is ordered by constraint, not by opinion; Audience fit = whether the LIFT audit accounts for the specific traffic source and buying modality.*

**Coherence gaps:** Where scores are lowest and which specific change would raise them most.

### Step 9: 90-Day Conversion Projection

Specific, measurable predictions based on LIFT factor magnitudes and Click Architects benchmarks:

**Days 1-30:**
- Which test launches first (The Single Move)
- Metric: macro conversion rate on the target desired action
- Expected signal timeline: high-traffic sites see significance in 7-14 days; low-traffic sites using DOE in 21-30 days
- Early failure signal: if CVR moves in the wrong direction by day 7 with high confidence, the diagnosed LIFT factor was misidentified — run Laja VoC before proceeding

**Days 31-60:**
- First test winner implemented
- Second-priority LIFT factor test launches (the next convergence zone after The Single Move)
- Goward's Infinity Optimization loop enters VALIDATE phase
- Expected cumulative CVR lift vs. baseline

**Days 61-90:**
- Full first testing cycle complete
- Transition to Kaizen Method for next quarter: re-run analytics investigation, customer research review, stakeholder interviews
- Predicted next bottleneck: which LIFT factor, now that the primary drag is resolved, becomes the new conversion ceiling
- ROI estimate: Goward benchmark range is 100-2000% ROI on testing programs; project the low-end (100%) and the high-end given traffic volume and CVR baseline

---

## OUTPUT STRUCTURE

### Conversion Intelligence Briefing

**Section 1: Input Status and Freshness**
All Goward skill outputs with freshness assessment and LIFT factor coverage map.

**Section 2: LIFT Coverage Map**
Which of the six factors have been scored and at what confidence level.

**Section 3: Convergence Map**
Named convergence zones with contributing skills and implied interventions.

**Section 4: Contradiction Analysis**
Resolved tensions between competing LIFT recommendations.

**Section 5: Amplification Opportunities**
Combined interventions producing outsized lift.

**Section 6: The Single Move**
One highest-leverage page change with before/after example and expected metric shift.

**Section 7: The Mirror**
Business's own page-design biases examined against LIFT criteria.

**Section 8: Cross-System Intelligence**
Interactions with all Click Architects and owned canon in the network.

**Section 9: Coherence Map**
Scored assessment across four dimensions with gap analysis.

**Section 10: 90-Day Conversion Projection**
Specific predictions by 30/60/90 day milestones with decision points.

---

## OUTPUT FILE

Save complete briefing to:
`[project-folder]/Chris Goward - Field Intelligence/[YYYY-MM] - Conversion Intelligence Briefing.md`
