---
name: pirolli-information-diet-mapper
description: Use when you need to identify what specific information "prey" each visitor segment is hunting — and diagnose whether the page's proximal cues match that diet or repel the forager before they commit.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peter Pirolli & Stuart Card (Information Foraging Theory, 1999; SNIF-ACT, 2007; Proximal Cue Model, 2004) — Click Architecture (Skill 3 of 7)"
interface:
  invoke: "/pirolli-information-diet-mapper"
  calls: []
  called_by: [user, pirolli-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Visitor goal vocabulary shifts with traffic source mix, seasonality, and competitor messaging; diet maps built on stale search query or ad data mismatch what foragers arrive expecting."

pirolli_scent_trail_integration:
  feeds_from: pirolli-scent-trail-auditor
  feeds_to: pirolli-link-diagnosticity-scorer
  shared_data: "Trigger-word vocabulary lists per segment; scent-decay coordinates on page (fold, element type); forager goal states by traffic source."

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: pirolli-patch-abandonment-predictor
  shared_data: "System-1 snap-judgments on landing map to IFT's patch-stay/leave decision; peak-end rule informs which within-patch moments carry highest foraging weight."

fogg_integration:
  feeds_from: fogg-field-intelligence
  feeds_to: pirolli-foraging-cost-reducer
  shared_data: "Fogg's Ability axis (perceived ease) translates directly to Pirolli's within-patch cost; motivation-wave timing informs when foragers are high-willingness / low-patience and need fastest possible diet delivery."

eisenberg_integration:
  feeds_from: eisenberg-field-intelligence
  feeds_to: pirolli-scent-gradient-designer
  shared_data: "Eisenberg's buying-mode stages (unaware → purchase) map to distinct information diet profiles; diet maps segment by stage so the page serves the right prey to the right forager."
---

# Pirolli Information Diet Mapper

## LAYER 1: INVARIANTS (Never override.)

1. **Segment before mapping.** A page serves multiple forager types simultaneously. Mapping diet at the aggregate level produces an average that serves no one. Identify each distinct visitor segment first; then map each segment's prey separately.
2. **Diet = goal vocabulary, not demographic.** Information diet is operationally defined as the exact vocabulary a segment uses to describe the information they need. Age, gender, and job title are irrelevant; their trigger words are everything.
3. **Proximal cues are the diet delivery vehicle.** A segment's diet is only satisfied if the page's proximal cues — headline, subheads, link labels, image subjects, button copy, URL slug — use that segment's exact trigger words. Synonyms do not register as scent. Exact vocabulary match is required.
4. **Rate maximization governs all diet decisions.** Per IFT's Rate-Maximizing Heuristic, foragers do not consume all available nutrition — they harvest at maximum [Value Gained] / [Time Invested]. A diet map must specify *how fast* the page delivers each segment's core prey, not just whether it delivers it at all.
5. **Within-patch cost determines diet extraction rate.** Dense paragraphs, buried keywords, and poor visual hierarchy increase within-patch cost and reduce the effective diet delivery rate even when the right content is present. Diet mapping must score both *content presence* and *extraction speed*.
6. **SNIF-ACT activation formula governs link priority.** For each clickable element on the page, compute relative activation: A_i = B_i + Σ(S_ji × W_j), where S_ji is the association strength between proximal cue j and segment i's goal vocabulary, and W_j is attentional weight on cue j. Elements with low A_i for the target segment are dead zones — they absorb dwell time without advancing the forager.
7. **Diet mismatch at fold 1 is unrecoverable.** If the above-the-fold zone does not deliver at least the primary prey item for the dominant segment, the Marginal Value Theorem exit condition is met immediately. No content below the fold compensates for a failed first-fold diet signal.

## LAYER 2: QUALITY GUIDANCE

1. **Pull trigger words from actual forager language.** Acceptable sources: search query reports (GSC, paid search terms), review mining (1-star and 5-star reviews), support ticket language, ad copy that converts, forum threads. Inferred or assumed vocabulary is low-quality diet data.
2. **Score diet delivery at each page fold, not just globally.** A page that opens with strong diet delivery but weakens at fold 3 will lose mid-funnel foragers at exactly the moment the Marginal Value exit threshold is crossed. Map fold-by-fold.
3. **Distinguish primary prey from secondary prey.** Primary prey = the information item whose absence causes immediate exit (e.g., "does this work for my situation?"). Secondary prey = items that increase confidence but whose absence alone does not trigger exit (e.g., detailed methodology). Prioritize primary prey delivery above the fold; secondary prey can appear mid-page.
4. **Validate segment diet maps against at least two independent data sources.** A trigger-word list built from one source (e.g., only ad keywords) may be biased by copywriter choices rather than true forager vocabulary.
5. **Test diet-map predictions against behavioral data.** A correctly mapped diet predicts which sections of the page get high scroll-depth and dwell; which get skipped; and at which fold exit rate spikes. If analytics contradict the diet map, revise the map before changing the page.

## PURPOSE

Information Foraging Theory (Pirolli & Card, 1999) establishes that website visitors are not readers — they are foragers executing a micro-economic optimization: maximize information value gained per unit of time invested. The specific information each forager segment hunts is their *information diet*. A page succeeds when it matches its proximal cues (every word, image, and label a user can see without clicking) to the exact diet of the dominant segment landing on that page.

This skill maps the prey each visitor segment is hunting, scores how well the page's current proximal cues deliver that diet, and outputs a prioritized rewrite prescription tied to specific page elements — not general advice.

**Brag line (carry this to a peer):** "We can predict which links leak visitors before we ship the page."

This is not an audit of what the page *says*. It is a foraging economics analysis: for each segment, does the page deliver the right prey at the right rate, with low enough within-patch extraction cost, to keep the forager in the patch long enough to commit to the desired action?

## INPUT REQUIREMENTS

**Required:**
- The page — URL, live screenshot, or written section-by-section description
- The ONE desired action (click / opt-in / purchase / call booking / scroll to anchor)

**High-value optional inputs:**
- Traffic source breakdown (which ads, search terms, referrers land on this page)
- Analytics: scroll depth, exit rate by fold, heatmap, session recordings
- Search query report for the page (GSC or paid search terms)
- Review or support ticket language from the target audience
- Funnel position (cold traffic / warm retargeting / existing customer)

## EXECUTION PROCESS

### Step 1 — Identify Forager Segments (10 min)

List every distinct visitor segment reaching this page. A segment is defined by a *different goal state*, not a demographic. Typical sources:

- Traffic source audit: Google organic (query intent varies by keyword cluster), paid (segment by ad set), email (list segment), social (platform + campaign)
- Funnel position: cold (no prior brand exposure), warm (ad-retargeted), hot (returning, considering)

For each segment, write one sentence: "This forager arrives asking: [exact question]."

**Output:** Segment table (max 4-5 segments; if more, collapse the lowest-volume ones).

| Segment | Traffic Source | Arrival Question | Volume Est. |
|---------|---------------|-----------------|-------------|
| S1 | | | |

### Step 2 — Map the Information Diet Per Segment (15 min)

For each segment, identify:

- **Primary prey:** The single information item whose absence causes immediate exit. Usually: "Does this solve exactly my problem?" or "Is this for someone like me?"
- **Secondary prey:** Items that raise confidence once primary prey is satisfied (pricing transparency, proof format they trust, mechanism explanation).
- **Poison prey:** Information items that, if encountered, trigger exit for this segment (competitor comparisons, jargon from a different category, price anchors that feel out of range).
- **Trigger words:** The exact vocabulary this segment uses for primary prey. Pull from search query reports, reviews, or ad copy. Not synonyms — exact words.

**Diet Profile per Segment:**

```
Segment: [Name]
Primary prey: [Information item]
Trigger words: [exact phrases, comma-separated]
Secondary prey: [2-3 items, ranked]
Poison prey: [1-2 items to avoid or route away]
Diet delivery speed required: [above fold / within 2 scrolls / mid-page acceptable]
```

### Step 3 — Audit Proximal Cue Inventory (20 min)

Catalog every proximal cue on the page — every element visible without clicking:

| Cue # | Element Type | Current Text / Description |
|-------|-------------|---------------------------|
| C1 | H1 headline | |
| C2 | Hero image subject | |
| C3 | First subhead | |
| C4 | Body P1 | |
| C5 | CTA button | |
| C6 | Nav links | |
| … | … | |

### Step 4 — Score Diet Delivery (SNIF-ACT Approximation)

For each segment × each proximal cue, score association strength S_ji on a 0–3 scale:
- **3** = Cue contains exact trigger word(s) for this segment's primary prey
- **2** = Cue is semantically related but not exact vocabulary match
- **1** = Cue is neutral — neither confirms nor disconfirms diet relevance
- **0** = Cue is irrelevant or actively contradicts this segment's goal vocabulary (poison cue)

**Threshold rules:**
- Above-fold zone (C1–C4 typically): dominant segment must score ≥ 2.5 average across all above-fold cues. Below 2.5 = fold-1 diet failure.
- Page total: dominant segment must score ≥ 2.0 average across all cues. Below 2.0 = chronic scent decay.
- Any individual proximal cue scoring 0 for the dominant segment is a scent breach — flag for rewrite or removal.

**Diet Delivery Scorecard:**

| Cue | Type | S(S1) | S(S2) | S(S3) | Note |
|-----|------|-------|-------|-------|------|
| C1 | H1 | | | | |
| C2 | Hero img | | | | |

*Legend: S(Sx) = association strength 0-3 for segment Sx*

**Fold-by-fold rate analysis:**

For each page fold, compute: Diet Rate = (Σ S scores for cues in this fold) / (estimated reading time for fold in seconds).

A declining Diet Rate fold-over-fold predicts where the Marginal Value Theorem exit condition will be triggered. Flag any fold where Diet Rate drops >30% from the previous fold.

### Step 5 — Within-Patch Cost Audit

Score the page's extraction friction for the dominant segment:

| Factor | Score 1-5 | Issue |
|--------|-----------|-------|
| Scannable formatting | | |
| Keyword bolding | | |
| Subhead descriptiveness | | |
| Paragraph density | | |
| Image informativeness | | |
| CTA label clarity | | |

*1 = severe friction (high within-patch cost), 5 = frictionless extraction*

Any factor scoring ≤ 2 is a within-patch cost blocker — increases extraction cost, reduces effective Diet Rate, advances the Marginal Value exit trigger.

### Step 6 — Gap Analysis and Rewrite Prescription

For each gap identified (missing trigger words, scent breaches, within-patch cost blockers, fold-rate declines):

1. Name the specific element (e.g., "H1 headline")
2. State the diet failure mode (e.g., "scores 1 for S1 — contains no S1 trigger words")
3. Write the rewrite using S1's exact trigger vocabulary
4. Predict the impact: "Raises S1 fold-1 average from 1.8 to 2.7 — clears the ≥ 2.5 threshold"

## OUTPUT STRUCTURE

**Section 1 — Segment Forager Profiles**
One diet profile per segment (primary prey, trigger words, secondary prey, poison prey, delivery speed required).

**Section 2 — Proximal Cue Inventory**
Full cue catalog with element types and current copy/description.

**Section 3 — Diet Delivery Scorecard**
SNIF-ACT approximation table (segments × cues, 0-3 scores) with fold averages and Diet Rate trend.

**Section 4 — Within-Patch Cost Audit**
Six-factor friction scorecard with scores and flagged blockers.

**Section 5 — Ranked Rewrite Prescription**
Prioritized list of specific element rewrites, each containing: current state → rewrite → diet mechanic → predicted score change. Ranked by impact on dominant segment's above-fold score first, then mid-page score.

**Section 6 — Integration Flags**
Items to pass to sibling skills: scent-trail-auditor (vocabulary list for full trail audit), link-diagnosticity-scorer (low-activation cues), patch-abandonment-predictor (fold-rate decline coordinates).

## WORKED MINI-EXAMPLE

**Page:** Email opt-in landing page for a keto meal planning app.
**Desired action:** Email opt-in.
**Dominant segment (S1):** Google organic traffic arriving via query "easy keto meal plan for beginners."

**Step 2 — S1 Diet Profile:**
- Primary prey: "Will this make keto simple enough for someone who doesn't know where to start?"
- Trigger words: "easy," "beginners," "meal plan," "keto," "simple," "step-by-step"
- Poison prey: "Advanced macros," "ketosis optimization," "biomarkers"

**Step 4 — Current H1 audit:**
- Current H1: "Fuel Your Body with Science-Backed Nutrition Protocols"
- S1 score: **0** — No trigger words. "Science-backed," "protocols," "nutrition" are not S1 vocabulary. Active diet mismatch.

**Rewrite:**
- New H1: "The Beginner's 7-Day Keto Meal Plan — Simple, Step-by-Step, No Guesswork"
- S1 score: **3** — Contains "beginner," "keto," "meal plan," "simple," "step-by-step" — exact S1 trigger words.
- Fold-1 average before rewrite: 1.4 (fail — below 2.5 threshold)
- Fold-1 average after H1 rewrite + hero image swap (from abstract food photo to labeled meal-prep containers): projected 2.8 (pass)

**Within-patch cost blocker caught:**
- Body paragraph 1 was 87 words, dense prose, no bolding.
- Rewrite: 3 bullets with bolded trigger words per bullet, each ≤ 18 words.
- Extraction cost drops from score 2 → 4; Diet Rate for fold 2 rises ~40%.

## OUTPUT FILE

Save to: [project-folder]/Pirolli - Click Architecture/[YYYY-MM] - Information Diet Map - [Page Name].md
