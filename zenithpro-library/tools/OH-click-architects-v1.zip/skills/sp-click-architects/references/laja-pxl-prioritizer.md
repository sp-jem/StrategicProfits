---
name: laja-pxl-prioritizer
description: Use when you have a list of conversion hypotheses and need to sequence them — scores each idea with the PXL binary matrix so the highest-impact, fastest-winning tests run first and nothing gets queued by gut feel.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peep Laja (CXL Institute, 2015; PXL Prioritization Framework) — Click Architecture (Skill 2 of 7)"
interface:
  invoke: "/laja-pxl-prioritizer"
  calls: []
  called_by: [user, laja-field-intelligence, laja-researchxl-diagnostic]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic mix, device split, and funnel architecture change; a hypothesis scored 6 months ago may now sit on a low-traffic page or have already been 'just-do-it' fixed."

researchxl_integration:
  feeds_from: laja-researchxl-diagnostic
  feeds_to: laja-pxl-prioritizer
  shared_data: "ResearchXL produces a raw problem list from six research spokes. PXL ingests that list and returns it ranked by score. The spoke that surfaced each problem (user testing, qualitative, analytics, mouse tracking) directly determines 3–4 of the 10 PXL binary questions — so ResearchXL output must be passed verbatim, not summarized."

fogg_integration:
  feeds_from: laja-pxl-prioritizer
  feeds_to: fogg-ability-auditor
  shared_data: "PXL high scorers that target friction (Q3: removing an element; Q8: analytics-sourced) map directly to Fogg Ability audits. After PXL ranks the queue, route friction-reduction winners to fogg-ability-auditor for mechanism diagnosis before writing the test variant."

kahneman_integration:
  feeds_from: laja-pxl-prioritizer
  feeds_to: kahneman-framing-engineer
  shared_data: "PXL high scorers that target motivation (Q4: designed to increase motivation) are candidates for Kahneman framing work. Pass those specific hypotheses to kahneman-framing-engineer to identify whether prospect-theory, loss-aversion, or peak-end framing best executes the winning variant."
---

# Laja PXL Prioritizer

## LAYER 1: INVARIANTS (Never override.)

1. Every hypothesis gets scored on ALL 10 PXL questions. Partial scoring is invalid — it produces false rankings that defeat the framework's core promise of analyst-to-analyst reproducibility.
2. PXL questions are binary or fixed-point only. No 1-10 scores. No partial credit. The moment you introduce subjective decimals you have re-built PIE/ICE, which PXL exists to replace.
3. Do not score "fix obvious bugs" as test candidates. Laja's Three-Tier Testing Strategy is unambiguous: Tier 1 (clear broken elements) = just fix it. PXL queues only Tier 2 (A/B tests) and Tier 3 (concept tests). Mixing in Tier 1 items inflates the queue and wastes test bandwidth.
4. Source attribution is mandatory for Q6–Q9. If you cannot identify which research spoke surfaced the hypothesis, those four questions default to 0. Unverified hypotheses should never jump the queue on unearned source points.
5. The Conversion Formula governs lever priority: C = 4M + 3V + 2(I-F) - 2A. Value-proposition hypotheses (V coefficient = 3) outrank incentive/friction parity (coefficient = 2) at equal PXL scores. Use this as the tiebreaker, not subjective opinion.
6. Traffic minimum is non-negotiable for Q5. "High-traffic page" = sufficient volume to reach 80% statistical power at your minimum detectable effect within 4 weeks. If the page cannot reach this threshold, flag it and deprioritize regardless of other scores.
7. Highest PXL score runs first. No exceptions for "stakeholder preference" or "easier to design." The matrix exists precisely to remove those inputs.

## LAYER 2: QUALITY GUIDANCE

1. Score independently then compare. If two analysts score the same hypothesis and land more than 2 points apart, re-examine Q3 (add vs. remove) and Q4 (motivation increase) — these are the two most commonly misread questions.
2. Flag "just-do-it" items explicitly in the output. The PXL queue should contain only testable hypotheses. Items that are clearly wrong (broken CTA, 404 on checkout) get routed to a separate "fix immediately" list before scoring begins.
3. Revisit scores when page architecture changes. A redesign that moves the primary CTA above the fold shifts Q1 and Q5 scores on every existing hypothesis on that page — re-score the full queue, not just new items.
4. Attach evidence snippets to Q6–Q9 answers. "Yes — Session replay SP-044 shows 68% of users stop scrolling at the pricing table" is valid. "Yes — someone mentioned it in a meeting" is not.
5. Cap the active queue at 10–15 hypotheses. Beyond that, the team cannot execute fast enough for the queue to remain valid. Backlog the rest and re-score quarterly.

## PURPOSE

This skill scores every conversion hypothesis on a real page against Laja's PXL matrix (2015) — the only CRO prioritization framework designed to produce the same ranking from two independent analysts. It eliminates gut-feel queue management and replaces PIE/ICE subjectivity with 10 binary or fixed-point criteria, producing a numbered run-order with explicit score breakdowns and implementation flags.

Brag line: "We find the real leak with 6 research lenses before we touch the page."

PXL's core insight: the single highest-leverage variable in the Conversion Formula is value-proposition clarity (V x3 coefficient). Most teams run tests in the order someone thought of them. PXL forces hypotheses with the highest win probability — above-fold, noticeable within 5 seconds, multi-source-validated — to the front of the queue and holds low-evidence ideas at the back until they earn their spot.

## INPUT REQUIREMENTS

Required:
- The page (URL, screenshot, or written description with funnel position)
- The ONE desired action this page is optimized for (click / opt-in / purchase / next step)
- A list of conversion hypotheses to score (minimum 3, maximum 20 per session)
- Research source tags for each hypothesis: which ResearchXL spoke(s) surfaced it (heuristic / technical / analytics / qualitative / user testing / mouse tracking)

Optional but improves accuracy:
- Monthly unique visitors to the page (for Q5 threshold calculation)
- Current conversion rate (to estimate MDE and test duration)
- Device/browser split from analytics (affects Q1 above-fold assessment)
- Whether the page has already had a round of Tier 1 fixes

## EXECUTION PROCESS

### Step 1 — Strip Tier 1 items before scoring

Separate the hypothesis list into:
- Tier 1 (Fix immediately, no test): broken elements, missing trust seals, 404 links, form errors, pages rendering blank on any browser with >5% traffic share. These go to a "just fix it" list. Do not score them.
- Tier 2/3 (Test candidates): everything else. These enter the PXL matrix.

Flag: "X items moved to fix-immediately list. Y items entering PXL scoring."

### Step 2 — Score each hypothesis on all 10 PXL questions

For each hypothesis, answer the following. Record 1 (yes) or 0 (no) for each binary question; use the fixed values shown for fixed-point questions.

| Q  | Question | Points if YES |
|----|----------|---------------|
| Q1 | Change is above the fold? | 1 |
| Q2 | Change is noticeable within 5 seconds? | 2 |
| Q3 | Change adds OR removes an element (not just restyling)? | 2 |
| Q4 | Designed to increase user motivation? | 1 |
| Q5 | Runs on a high-traffic page (power threshold reachable in <=4 wks)? | 1 |
| Q6 | Problem surfaced via user testing? | 1 |
| Q7 | Problem surfaced via qualitative feedback (surveys/polls)? | 1 |
| Q8 | Problem surfaced via digital analytics (funnel drop, segment)? | 1 |
| Q9 | Supported by mouse tracking / heatmaps / session replay? | 1 |
| Q10 | Easy to implement (<=1 dev day, no backend dependency)? | 1 |

Maximum possible score: 12 points.

Scoring notes:
- Q2 is worth 2 because above-fold changes have the highest base rate of winning tests in Laja's data. A change buried below the fold that is "noticeable if you get there" scores 0.
- Q3 is worth 2 because structural changes (adding social proof block, removing navigation, replacing hero) produce larger effect sizes than color/copy tweaks within the same element.
- Q6–Q9 are the evidence multiplier. A hypothesis with 4 research sources (4 pts) and otherwise equal scores beats a gut-feel idea with the same structural attributes.
- Q4 and Q10 are each 1 point — motivation framing and ease of implementation matter, but they do not override above-fold visibility and research grounding.

### Step 3 — Apply Conversion Formula tiebreaker

For hypotheses within 1 point of each other, apply the formula hierarchy:
C = 4M + 3V + 2(I-F) - 2A

Rank tied hypotheses by which coefficient their mechanism targets:
- Value proposition clarity (V, coefficient 3): rewriting the headline, hero subhead, CTA label — rank first among ties
- Anxiety reduction (A, coefficient 2): adding trust seals, removing form fields, clarifying privacy — rank second
- Friction reduction (F, coefficient 2): simplifying steps, reducing clicks — rank third
- Incentive (I, coefficient 2): adding urgency/bonus — rank fourth
- Motivation filtering (M, coefficient 4 but pre-existing): this is the user's state, not a page lever — do not rank-up hypotheses that only "target motivation" without changing page structure

### Step 4 — Classify each scored hypothesis

After scoring, tag each hypothesis with one of three implementation flags:

- RUN NOW: score >= 7, traffic threshold met, evidence from >= 2 research spokes
- QUEUE: score 4–6, or score >= 7 but missing multi-source evidence
- BACKLOG: score <= 3, or score >= 4 but page traffic too low for valid test

### Step 5 — Produce the ranked run-order

Sort all test candidates descending by PXL score. Within score ties, apply the Conversion Formula tiebreaker from Step 3. Output as a numbered table.

## OUTPUT STRUCTURE

**Section 1 — Fix-Immediately List**
Items removed from scoring with brief rationale.

**Section 2 — PXL Scored Matrix (split into two tables, joined by Hypothesis ID)**

**Table A — Hypothesis vs. structural signals (5 columns)**

| ID | Hypothesis | Q1 | Q2 | Q3 |
|----|-----------|----|----|----|

**Table B — More structural + evidence sources (6 columns)**

| ID | Q4 | Q5 | Q6 | Q7 | Q8 |
|----|----|----|----|----|-----|

**Table C — Remaining evidence, score, and flag (5 columns)**

| ID | Q9 | Q10 | Total | Flag |
|----|----|----|-------|------|

Legend: Q1=Above fold (1), Q2=Visible 5s (2), Q3=Add/remove (2), Q4=Motivation (1), Q5=Traffic (1), Q6=UserTest (1), Q7=Qualitative (1), Q8=Analytics (1), Q9=MouseTrack (1), Q10=Easy build (1). Flag = RUN NOW / QUEUE / BACKLOG. All three tables join on ID.

**Section 3 — Ranked Run-Order**
Numbered list of RUN NOW items with: score, primary Conversion Formula lever targeted, research spokes that sourced it, and one-sentence implementation note.

**Section 4 — Queue and Backlog**
Remaining hypotheses with score and the specific condition that needs to be met before promoting to RUN NOW (e.g., "needs qualitative validation — run a 50-response exit poll," "page needs 3x traffic before test reaches power").

**Section 5 — Next Research Gap**
Which of the six ResearchXL spokes is least represented in the Q6–Q9 scores across the queue. This is the spoke to run next to promote backlog items.

## WORKED MINI-EXAMPLE

Page: SaaS trial signup page. Desired action: start free trial.
Hypothesis pool: 3 ideas submitted.

Idea A — Replace hero headline "Powerful analytics for teams" with outcome-specific headline "See which pages are killing your conversions — free trial, no card."
- Q1: Yes (above fold) = 1
- Q2: Yes (headline is the first thing read) = 2
- Q3: Yes (replacing element, not restyling) = 2
- Q4: Yes (directly increases motivation by articulating outcome) = 1
- Q5: Yes (page gets 12,000 visitors/month, power reachable in 10 days) = 1
- Q6: Yes (user testing: 3 of 5 users said "I don't know what this does for me") = 1
- Q7: Yes (exit poll: top response to "what almost stopped you signing up?" = "wasn't sure if it would work for my use case") = 1
- Q8: Yes (analytics: 61% drop-off at this step vs. 38% industry benchmark) = 1
- Q9: No (heatmaps show clicks but no rage-click or confusion signal) = 0
- Q10: Yes (copy change only, 2-hour design task) = 1
Score: 11/12. Flag: RUN NOW. Lever: V (value proposition clarity, coefficient 3).

Before: "Powerful analytics for teams"
After: "See which pages are killing your conversions — free trial, no card."
Why it wins PXL: above fold + structural element change + 3 research sources = maximum evidence weight.

Idea B — Add "30-day money-back guarantee" badge below CTA button.
Score: Q1=1, Q2=1, Q3=2, Q4=0, Q5=1, Q6=0, Q7=1, Q8=0, Q9=1, Q10=1 = 8/12. Flag: RUN NOW. Lever: A (anxiety reduction, coefficient 2). Runs second.

Idea C — Change CTA button color from gray to orange.
Score: Q1=1, Q2=1, Q3=0 (restyle, not add/remove), Q4=0, Q5=1, Q6=0, Q7=0, Q8=0, Q9=0, Q10=1 = 4/12. Flag: QUEUE. Needs at least one research source before promoting.

Run-order: 1 → Idea A (11 pts), 2 → Idea B (8 pts), 3 → Idea C held in queue.

## OUTPUT FILE

Save to: [project-folder]/Laja - Click Architecture/[YYYY-MM] - PXL Priority Queue - [Page Name].md
