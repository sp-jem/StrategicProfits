---
name: eyal-field-intelligence
description: Meta-synthesis across all Nir Eyal (Skinner root) page-action skills + the Click Architects network. Identifies Hook Model convergence zones, resolves contradictions, and delivers the single highest-leverage page change to maximize one desired action.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Nir Eyal (with B.F. Skinner root) — Field Intelligence (Skill 7 of 7)"
interface:
  invoke: "/eyal-field-intelligence"
  calls: [eyal-hook-loop-designer, eyal-trigger-architect, eyal-variable-reward-designer, eyal-investment-escalator, eyal-habit-zone-tester, eyal-manipulation-matrix-guard]
  called_by: [user, click-architects]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Hook loops degrade as audiences habituate and competitive triggers multiply. Individual skill outputs older than 45 days may reflect outdated trigger-reward pairings. Reassess quarterly minimum."
fogg_integration:
  feeds_from: [fogg-field-intelligence]
  feeds_to: [fogg-behavior-system-designer]
  shared_data: "Fogg's B=MAP governs the Action phase of Eyal's Hook loop. When Eyal's trigger fires, Fogg determines whether the behavior executes. Motivation, Ability, and Prompt must all converge at the moment the trigger arrives. The synthesis reveals where Hook design fails not because the trigger is weak but because Ability is insufficient at trigger-time — and vice versa, where Fogg's system fires but no Hook loop captures the behavior into a return habit."
cialdini_integration:
  feeds_from: [cialdini-field-intelligence]
  feeds_to: [cialdini-commitment-ladder-designer]
  shared_data: "Cialdini's commitment/consistency principle IS Eyal's Investment phase, operationalized as influence. Social proof powers Rewards of the Tribe. Scarcity powers Rewards of the Hunt. The synthesis reveals which Cialdini principles are missing from the Hook loop, and where adding one principle would accelerate the shift from external to internal trigger — the goal of every Hook design."
kahneman_integration:
  feeds_from: [kahneman-field-intelligence]
  feeds_to: [kahneman-framing-engineer]
  shared_data: "Kahneman's System 1 is the target of every Hook. Variable rewards bypass System 2 deliberation — they are engineered for the automatic, associative system. Peak-end rule maps directly onto Hook reward design: the peak moment of variability and the ending Investment moment determine how the loop is remembered and whether it is re-entered. The synthesis reveals where Hook design inadvertently activates System 2 (scrutiny, resistance) and where it should stay in System 1 (automaticity, search mode)."
thaler_integration:
  feeds_from: [thaler-field-intelligence]
  feeds_to: [thaler-endowment-mapper]
  shared_data: "Thaler's endowment effect is the mechanism behind Eyal's stored-value Investment phase. Once a user's data, content, followers, or skill is embedded in a product, the loss of that investment is weighted more heavily than any gain from switching. The synthesis reveals which stored-value types are maximally loss-averse for this audience, and where the Investment phase should be redesigned to create stronger endowment lock-in."
iyengar_integration:
  feeds_from: [iyengar-choice-set-auditor]
  feeds_to: [iyengar-tier-calibrator]
  shared_data: "Iyengar's choice overload directly impairs the Action phase. When Eyal's trigger fires successfully, an overcrowded choice set at the action moment kills conversion. The synthesis reveals where paradox-of-choice is breaking the trigger-to-action bridge and where reducing the choice set would accelerate Hook loop completion."
pirolli_integration:
  feeds_from: [pirolli-field-intelligence]
  feeds_to: [pirolli-scent-trail-auditor]
  shared_data: "Pirolli's information foraging scent governs whether a visitor follows the trigger into the action path. High scent = the trigger's promise is visibly fulfilled on the destination page. Low scent = the visitor abandons before completing the action phase. The synthesis reveals where Hook triggers promise one thing and landing pages deliver another — the scent break that collapses the loop before it can capture investment."
fitts_integration:
  feeds_from: [fitts-field-intelligence]
  feeds_to: [fitts-click-path-minimizer]
  shared_data: "Fitts' motor cost is the physical-effort dimension inside Eyal's Six Elements of Simplicity. High motor cost (small targets, long travel distance) raises the scarcest ability resource at the action moment. The synthesis: Fitts' law quantifies exactly how much physical friction Eyal's Action phase is absorbing — and how much conversion recovers when target size doubles or distance halves."
hick_integration:
  feeds_from: [hick-field-intelligence]
  feeds_to: [hick-decision-load-calculator]
  shared_data: "Hick's law (choice × log) quantifies the brain-cycle cost inside Eyal's Six Elements of Simplicity. Every additional option increases decision time and reduces action probability. Total click cost = Fitts motor cost + Hick decision cost. The synthesis reveals the combined friction load at each action point and whether eliminating choices or reducing target distance produces faster conversion recovery."
eisenberg_integration:
  feeds_from: [eisenberg-field-intelligence]
  feeds_to: [eisenberg-micro-action-sequencer]
  shared_data: "Eisenberg's persuasion architecture maps the buying-mode sequence a visitor must traverse before acting. Eyal's trigger must land the visitor at the correct persuasion stage — a trigger arriving too early in the buying mode creates premature action requests that fail. The synthesis reveals which Hook triggers are stage-matched and which are firing into the wrong persuasion phase, generating clicks with no conversion."
kohavi_integration:
  feeds_from: [kohavi-field-intelligence]
  feeds_to: [kohavi-test-prioritization-designer]
  shared_data: "Kohavi's controlled experiment discipline is the verification layer for every Hook Model claim. Hook loop design produces hypotheses; Kohavi produces proof. The synthesis mandatory rule: every Single Move identified by eyal-field-intelligence becomes an A/B test hypothesis before deployment. Hook intuition is not evidence. Kohavi makes it evidence."
goward_integration:
  feeds_from: [goward-field-intelligence]
  feeds_to: [goward-value-prop-fulcrum-auditor]
  shared_data: "Goward's conversion research methodology reveals which visitor beliefs block action at the trigger and action phases. Hook design without belief-gap research is blind — triggers can fire perfectly and still fail because the underlying visitor belief invalidates the promised reward. The synthesis reveals which Hook phases require belief-gap intervention before behavioral design can work."
laja_integration:
  feeds_from: [laja-field-intelligence]
  feeds_to: [laja-researchxl-diagnostic]
  shared_data: "Laja's ResearchXL framework surfaces the specific friction, confusion, and anxiety points that Eyal's simplicity audit misses when it relies on designer assumptions. The synthesis: ResearchXL data feeds directly into Six-Element Simplicity scoring — replacing guesses about which resource is scarcest with evidence from actual user sessions."
norman_integration:
  feeds_from: [norman-field-intelligence]
  feeds_to: [norman-affordance-signifier-auditor]
  shared_data: "Norman's affordances and signifiers determine whether Eyal's external triggers are perceived as triggers at all. A CTA button with poor affordance (unclear it is clickable) fails before Eyal's action phase begins. The synthesis reveals where Hook trigger failures are actually affordance failures — the user never received the prompt because the design did not signal its clickability."
nielsen_integration:
  feeds_from: [nielsen-field-intelligence]
  feeds_to: [nielsen-heuristic-evaluation]
  shared_data: "Nielsen's usability heuristics surface the error-recovery and visibility-of-status failures that break Hook loops mid-sequence. A variable reward reveal that crashes, a form that loses data on error, or an Investment step that provides no confirmation feedback — all terminate loops that Eyal's design intended to complete. The synthesis reveals where usability failures are masquerading as motivation or trigger failures."
brignull_integration:
  feeds_from: [brignull-field-intelligence]
  feeds_to: [brignull-dark-pattern-scanner]
  shared_data: "Brignull's dark pattern taxonomy intersects Eyal's Manipulation Matrix Guard. When Hook design crosses into manipulation (creating habits users would not endorse on reflection), Brignull's patterns are the mechanism. The synthesis is the ethical checkpoint: identify which page elements the manipulation-matrix-guard flagged and cross-reference with Brignull's taxonomy to determine whether they constitute dark patterns or legitimate engagement design."
gigerenzer_integration:
  feeds_from: [gigerenzer-field-intelligence]
  feeds_to: [gigerenzer-heuristic-fit-designer]
  shared_data: "Gigerenzer's ecological rationality shows that the heuristics visitors use to evaluate Hook triggers are fast-and-frugal, not systematic. Visitors do not weigh all elements of a trigger — they apply one good reason (a recognition heuristic, a social cue, a fluency signal) and act or don't. The synthesis reveals which single cue in each Hook phase dominates the heuristic evaluation — and how to make that cue unambiguously strong."
---

# Nir Eyal Field Intelligence

---

## LAYER 1: INVARIANTS (Never override.)

1. **Synthesis not summary.** Do NOT recap what each skill found. Find PATTERNS across skills — convergence zones where multiple Hook phases point at the same intervention. If output reads like six mini-reports, it has failed.

2. **Convergence detection is mandatory.** When 3+ skills identify the same page element, phase failure, or intervention: that is a convergence zone. Name it. Convergence zones are the highest-confidence findings.

3. **Contradictions must be surfaced.** When trigger-architect recommends adding an owned trigger and habit-zone-tester flags that frequency is too low for habit formation: both are correct. Resolve through context, not deletion.

4. **The Single Move is non-negotiable.** One highest-leverage page change. Not a list. ONE move that addresses the most convergence zones simultaneously. It must produce a measurable increase in the desired action.

5. **The Mirror is non-negotiable.** Examine the business's own Hook design biases — where the product team is designing for habitual use that the Habit Zone test rules out, or engineering variable rewards that are actually predictable.

6. **Cross-system intelligence is the highest-value section.** The intersection of Eyal's Hook Model with other Click Architects thinkers produces insights unavailable from Eyal alone.

7. **Freshness gate: 45 days.** Flag any individual skill output older than 45 days as potentially stale.

---

## LAYER 2: QUALITY GUIDANCE

8. **Name convergence zones.** Give each a label that captures the mechanic, not just the location (e.g., "The Reward Collapse" — action fires but the post-action experience is fully predictable, killing search mode).

9. **Brag-test every recommendation.** Each page change must pass: "Would a marketer say 'we build a return habit, by design' after implementing this?" If the change is cosmetic, it fails.

10. **The 90-Day Projection must be specific.** Not "engagement should improve." Instead: "If The Single Move is implemented by day 7, return visit rate should shift from X% to Y% within 30 days, with investment-phase completion increasing from Z% to W% by day 60."

---

## PURPOSE

Each Eyal skill isolates one phase of the Hook loop on one page. Hook Loop Designer maps the full four-phase sequence. Trigger Architect diagnoses external-to-internal trigger failure. Variable Reward Designer audits whether post-action experience activates search mode or satisfaction mode. Investment Escalator identifies whether follow-on micro-commitments are loading the next trigger. Habit Zone Tester plots frequency × perceived utility to determine whether habit formation is even possible. Manipulation Matrix Guard ensures Hook design remains on the ethical side of the line.

Field Intelligence finds what none of those skills can find alone: where multiple phases are failing for the same root cause, where a single intervention repairs three phases at once, and where Hook design interacts with every other Click Architects thinker to produce insights unavailable from Eyal's framework in isolation.

**The brag:** "Our product builds a return habit, by design."

---

## INPUT REQUIREMENTS

**Required:** Outputs from at least 4 of 6 individual Eyal skills, all run on the same page targeting the same desired action.

**Optimal:** All 6 skill outputs + Field Intelligence from fogg, cialdini, kahneman, fitts, hick, pirolli. Performance data: return visit rate, action completion rate, Investment phase completion rate, internal trigger identification (session recording / user interviews).

**Minimum viable:** hook-loop-designer + trigger-architect + variable-reward-designer + one of (investment-escalator, habit-zone-tester, manipulation-matrix-guard).

---

## EXECUTION PROCESS

### Step 1: Component Synthesis

For each available Eyal skill output, record:

| Field | Content |
|-------|---------|
| Skill | Name |
| Date | Run date |
| Freshness | Current ≤45d / Aging 45-60d / Stale >60d |
| Key findings | 3 most important conclusions |
| Recommended changes | Specific page interventions |
| Confidence | High / Medium / Low |

### Step 2: Convergence Detection

Cross-skill pattern matching across all Hook phases:

**Convergence scoring:**
- 2 skills: Notable alignment
- 3 skills: Convergence zone — name it
- 4+ skills: Critical convergence — lead with it

**For each convergence zone:**
- **Name:** Memorable label capturing the mechanic
- **Contributing skills:** Which analyses converge
- **Specific findings:** What each skill flagged
- **System implication:** Why this is a pattern, not a coincidence
- **Implied intervention:** The page change the convergence demands

**Common Eyal convergence patterns to test:**
- Trigger fires, action fails → scarcest-resource friction in Action phase (test: does simplicity-audit from trigger-architect + hook-loop-designer + laja data agree on which resource?)
- Action fires, no return → variable reward is predictable (test: does variable-reward-designer + hook-loop-designer + investment-escalator all flag weak variability?)
- Investment phase absent → next trigger never loads (test: does investment-escalator + hook-loop-designer + trigger-architect all show the loop is open-ended?)
- High perceived utility, low frequency → Habit Zone issue, not Hook issue (test: does habit-zone-tester + hook-loop-designer agree that optimization target should be single conversion, not return loop?)

### Step 3: Contradiction Detection

Surface conflicts between skill recommendations:

**Common Eyal contradictions:**
- Trigger-architect recommends more external triggers → Habit-zone-tester flags frequency is already high enough that internal triggers should be forming (adding externals masks the real failure)
- Variable-reward-designer recommends surprise reveal → Manipulation-matrix-guard flags this audience would not endorse the surprise on reflection (reward is manipulative, not genuinely valuable)
- Investment-escalator recommends longer micro-commitment sequence → Hook-loop-designer flags that additional steps are dropping Action phase completion before investment is reached
- Hook-loop-designer recommends complete four-phase loop → Habit-zone-tester rules out habit formation (frequency × utility below threshold) — the loop design is overcomplicated for a single-conversion page

**For each contradiction:**
- State the tension explicitly
- Why both skills are correct in their own frame
- Resolution for this specific context and audience
- Implementation that honors the deeper insight from both

### Step 4: Amplification Opportunities

Where combining phase interventions produces outsized impact:

- Eliminating the scarcest Action-phase resource (Six Elements) + switching from predictable to variable reward = Trigger fires AND search mode activates — double lift
- Installing an Investment micro-commitment immediately post-action + making that investment load a personalized Owned trigger = Investment phase directly seeds next external trigger — closes the loop
- Naming the internal trigger in headline copy + making the CTA label describe the emotional relief + variable reveal on thank-you page = full Trigger-Action-Reward chain visible in 3 seconds

### Step 5: The Single Move

ONE page change that addresses the most convergence zones.

Structure:
- **What:** The specific change (rewrite X, remove Y, add Z)
- **Why this is THE move:** Which convergence zones it addresses (minimum 2)
- **Hook mechanics:** Which phase(s) it repairs and which element (Trigger type / Simplicity resource / Reward variability / Investment depth)
- **Before/After example:**
  - Before: CTA reads "Get Access" → fully predictable reward implied
  - After: CTA reads "See What Others Are Getting" → social variability implied before click
- **Implementation:** Concrete steps, sequential
- **Metric target:** Specific conversion or return-visit metric, predicted directional change
- **What it does NOT address:** Honest scope limitation

### Step 6: The Mirror

Where the business's own Hook design biases operate:

- **Habit Zone blindness:** Designing a Hook loop for a product the Habit Zone test rules out. Low-frequency products need single-conversion optimization, not loop engineering.
- **Predictable reward assumption:** The team believes the promised outcome IS the reward. Eyal's insight: variability IS the reward. A certain outcome creates satisfaction; an uncertain outcome creates search mode. Teams consistently underestimate how much predictability kills return behavior.
- **Investment-as-friction framing:** The team treats every post-action request as a conversion obstacle. Investment Escalator reframes micro-commitments as stored value that makes defection costly. Teams that skip Investment phase leave the loop open — users can leave with no psychological anchor.
- **External trigger dependency:** The business is spending on paid and earned triggers (ads, PR) without diagnosing whether internal triggers are forming. If internal triggers are not forming after 5+ external-trigger exposures to the same user, the Reward phase is failing — not the media budget.
- **Manipulation drift blindness:** Teams normalize Hook design tactics over time. The Manipulation Matrix Guard requires periodic re-evaluation because audience norms evolve. What was fair persuasion in year one may have crossed into manipulation as users became more sophisticated.

### Step 7: Cross-System Intelligence

Synthesize with other Click Architects thinkers where Field Intelligence exists:

**Eyal × Fogg:** Hook triggers are Fogg Prompts. The Action phase executes only when B=MAP converges. When Hook loops underperform, first test: is the Prompt (trigger) arriving when Motivation and Ability are simultaneously sufficient? If not, the Hook problem is actually a Fogg B=MAP timing problem. Eyal's simplicity audit and Fogg's ability audit are the same diagnosis from different angles — use both to triangulate the bottleneck resource.

**Eyal × Cialdini:** Commitment/consistency = Investment phase. Social proof = Rewards of the Tribe. Scarcity = Rewards of the Hunt. Authority = trigger credibility. When a Hook loop is underperforming, check which Cialdini principle is missing from each phase. Reciprocity in the trigger (give value before asking for action) dramatically lowers the Six-Element friction at the Action phase by pre-building goodwill.

**Eyal × Kahneman:** Variable rewards are System 1 mechanisms. Predictable rewards allow System 2 to deliberate — and deliberation enables objections. The peak-end rule governs how the Hook loop is remembered: engineer the peak moment of variability and the Investment step as the memorable endpoints of each loop pass, and the user's memory of the experience pulls them back.

**Eyal × Thaler:** Investment stored value IS the endowment effect. Once the user's playlist, profile, skill, or social graph lives in the product, loss aversion weights it far higher than equivalent gain from a competitor. Design Investment phase to maximize endowment load as fast as possible. The faster the endowment forms, the earlier churn-prevention begins.

**Eyal × Iyengar:** Choice overload at the Action phase collapses the Hook loop. When Iyengar's paradox-of-choice research shows >3 options killing conversion, the scarcest resource in Eyal's Six Elements at that moment is Brain Cycles. Reduce options at the Action moment to one clear next step. Reserve choice for the Investment phase, where selecting preferences is itself the stored value.

**Eyal × Pirolli:** Pirolli's information scent must be continuous from external trigger through action destination. A trigger that promises community and lands on a product page breaks scent and collapses the Hook before Action fires. Scent trail = the visible promise of reward along every step of the path. Eyal's Trigger-to-Action bridge is a scent-maintenance problem. Measure click-through rate from trigger to action as the scent score.

**Eyal × Fitts + Hick (total click cost):** Total action friction = Fitts motor cost (target size × distance) + Hick decision cost (log of option count). This is the quantified version of Eyal's Six Elements for the physical and cognitive resources. When Action phase is underperforming: measure both. A single dominant fix is usually available — either double the CTA target size (Fitts) or halve the visible options (Hick).

**Eyal × Eisenberg:** Hook triggers must arrive at the correct persuasion stage. Eisenberg's buying-mode sequence (unaware → aware → interested → evaluating → deciding) means a trigger landing on an Unaware visitor that asks for a purchase is phase-mismatched. Map where each trigger type (paid, earned, relationship, owned) lands visitors in the persuasion sequence. Design the Action phase to be appropriate for that stage — not the stage you wish they were at.

**Eyal × Kohavi:** Every convergence zone identified in this briefing is a hypothesis. Every Single Move is an A/B test. Kohavi's discipline: no Hook loop claim is valid until a controlled experiment confirms it. The synthesis rule: before shipping The Single Move, instrument the experiment design — control page, variant page, primary metric, minimum detectable effect, required sample size. Hook intuition becomes Hook evidence only through Kohavi's methodology.

**Eyal × Goward:** Visitor beliefs about the promised reward must be validated before Hook loop design is optimized. Goward's conversion research surfaces whether visitors trust the variable reward (do they believe the community is active? the resource is exclusive? the result is real?). If belief gaps exist, Hook loop optimization is premature — fixing the belief gap produces more lift than any loop re-engineering.

**Eyal × Laja:** ResearchXL session recordings and user interviews replace designer assumptions about which of the Six Elements of Simplicity is scarcest. Laja's methodology reveals exactly where visitors hesitate, where they abandon, and what objection or confusion terminated the action. Feed Laja data directly into the simplicity audit step of eyal-trigger-architect and eyal-hook-loop-designer.

**Eyal × Norman:** External triggers must be perceived as triggers. Norman's affordances: a CTA button that doesn't look clickable is not a trigger — it is invisible. A push notification that doesn't signify urgency is ignored. The synthesis: before optimizing trigger copy, verify that trigger affordances are unambiguous. Low click-through rates on triggers are often affordance failures, not copy failures.

**Eyal × Nielsen:** Usability failures break Hook loops mid-sequence. A variable reward page that 404s. An Investment form that loses data on submission error. A thank-you page with no next-step prompt. Nielsen's visibility-of-system-status heuristic: at every Loop phase transition, the user must know what just happened and what comes next. When Hook loops fail, check usability before blaming motivation or reward design.

**Eyal × Brignull:** The manipulation matrix guard is the first line of ethical defense. Brignull's dark pattern taxonomy is the second. Cross-reference: which elements the manipulation-matrix-guard flagged as potentially manipulative, and whether those elements match Brignull's classified patterns (confirm shaming, roach motel, trick questions, disguised ads). If they match, the design has crossed from Hook to dark pattern. Remediate before the regulatory or reputational cost arrives.

**Eyal × Gigerenzer:** Visitors evaluate Hook triggers using fast-and-frugal heuristics — one good reason, not systematic analysis. The recognition heuristic (have I seen this brand before?) dominates trigger evaluation for cold traffic. The fluency heuristic (does this look professional and credible?) dominates for warm traffic. Design triggers to win on the single dominant heuristic for this audience — not to maximize all credibility signals equally.

**Cross-system convergence:** The highest-confidence insight from combining multiple thinkers: when Pirolli scent break + Fitts high motor cost + Hick high decision cost + Eisenberg stage mismatch all occur simultaneously at the Action phase, conversion will fail regardless of trigger quality or reward design. The action bottleneck is structural, not motivational. The Single Move in this case is always Action-phase friction reduction, not trigger or reward optimization.

### Step 8: Coherence Map

Score the page's Hook design coherence across four dimensions (1-10 each):

| Dimension | Score | Meaning |
|-----------|-------|---------|
| Hook integrity | /10 | All 4 phases present + sequenced correctly |
| Habit viability | /10 | Frequency × utility supports habit zone |
| Ethical alignment | /10 | Manipulation guard + Brignull clear |
| Cross-system fit | /10 | Fogg, Cialdini, Kahneman findings aligned |

**Legend:** Hook integrity = loop completeness. Habit viability = Habit Zone test result. Ethical alignment = manipulation-matrix guard + Brignull. Cross-system fit = coherence with owned canon thinkers.

**Coherence floor:** Any dimension scoring below 5 blocks The Single Move from being a loop optimization. Scores below 5 indicate a structural failure that must be remediated first.

### Step 9: 90-Day Projection

**Days 1-30:**
- What gets implemented (The Single Move + any structural remediations)
- Which metric should move first (typically: Action phase completion rate or return visit rate)
- Early signal of success: measurable uptick in target action within 14 days of launch
- Decision point: if Action phase completion rate has not improved by day 14, the root bottleneck is likely not what the convergence zones identified — escalate to full Laja + Kohavi diagnostic

**Days 31-60:**
- Internal triggers should show early formation: return visits not traceable to owned or paid triggers
- Investment phase completion rate should be tracking upward as stored value accumulates
- Variable reward design should be generating social shares or word-of-mouth signals (Tribe rewards working)
- Metric target: return visit rate increasing toward habit frequency threshold for this product category

**Days 61-90:**
- Full Hook loop performance assessment vs. pre-intervention baseline
- Habit Zone confirmation: are habitual users (5%+ adoption threshold) on the identified Habit Path?
- Next bottleneck identified: which phase will limit further growth after the Single Move is absorbed
- Predicted next Single Move for the following 90-day cycle

---

## OUTPUT STRUCTURE

**Section 1: Input Status & Freshness**
All Eyal skill outputs with dates and freshness ratings.

**Section 2: Convergence Map**
Named convergence zones with contributing skills, specific findings, and implied interventions.

**Section 3: Contradiction Analysis**
Resolved tensions with explicit resolution logic for this context.

**Section 4: Amplification Opportunities**
Multi-phase combinations producing outsized lift.

**Section 5: The Single Move**
One page change. Before/After example. Metric target.

**Section 6: The Mirror**
Business's Hook design biases diagnosed.

**Section 7: Cross-System Intelligence**
Interactions with fogg, cialdini, kahneman, thaler, iyengar, pirolli, fitts, hick, eisenberg, kohavi, goward, laja, norman, nielsen, brignull, gigerenzer.

**Section 8: Coherence Map**
Four-dimension scoring table with legend. Flag any dimension below 5.

**Section 9: 90-Day Projection**
Specific predictions at 30/60/90 day milestones with decision points.

---

## OUTPUT FILE

Save complete briefing to:
`[project-folder]/Nir Eyal - Field Intelligence/[YYYY-MM] - Hook Model Intelligence Briefing.md`
