---
name: goward-value-prop-fulcrum-auditor
description: Use when a page is underperforming and you need to diagnose the root cause before testing anything — audits the Value Proposition as the LIFT Model fulcrum that sets the conversion ceiling.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Chris Goward (You Should Test That, 2013; LIFT Model 2009; POPs/PODs/POIs 2012) — Click Architecture (Skill 2 of 7)"
interface:
  invoke: "/goward-value-prop-fulcrum-auditor"
  calls: []
  called_by: [user, goward-field-intelligence, goward-lift-scorer]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Competitive POD landscape shifts; traffic source messaging changes invalidate scent-match diagnoses within 6 weeks."

goward_lift_scorer_integration:
  feeds_from: goward-lift-scorer scores the full six-factor LIFT pass; this skill receives the Value Proposition sub-score and drills into POPs/PODs/POIs decomposition
  feeds_to: goward-clarity-relevance-optimizer (hands off VP language as the anchor for clarity and relevance scoring); goward-hypothesis-generator (POD shortlist becomes primary hypothesis input)
  shared_data: LIFT VP score (0-10), POD candidates, Cost-Benefit equation delta

eisenberg_integration:
  feeds_from: eisenberg-buying-modality-classifier identifies whether visitors are spontaneous/competitive/methodical/humanistic — determines which VP framing angle to lead with
  feeds_to: eisenberg-scent-continuity-auditor verifies the diagnosed POD carries from ad scent through headline to CTA
  shared_data: dominant buying modality, headline framing angle, VP-to-CTA scent token

kahneman_integration:
  feeds_from: kahneman-framing-engineer flags whether current VP triggers loss or gain frame; inputs to Cost-Benefit equation calibration
  feeds_to: kahneman-prospect-theory-architect uses the VP audit's cost inventory to reframe perceived costs as avoided losses
  shared_data: perceived cost list, gain/loss frame status, isolation-effect candidates
---

# Goward Value Prop Fulcrum Auditor

## LAYER 1: INVARIANTS (Never override.)

1. **VP is the conversion ceiling.** Goward: "The vehicle that provides the potential for the Conversion Rate is the Value Proposition." No LIFT lever — Clarity, Relevance, Urgency — can push results above what the VP ceiling allows. Fix the VP before touching anything else.
2. **POPs are a strategy to fail.** Points of Parity (features important to prospects that competitors also offer) must never anchor the headline or primary claim. Competing on POPs signals commodity status and motivates price shopping, not conversion.
3. **Context kills universals.** There are no best practices, only hypotheses. Every VP diagnosis must be scoped to THIS page, THIS traffic source, THIS offer. Generic VP templates are explicitly rejected.
4. **Cost-Benefit equation governs every element.** Conversion is a subconscious equation: Perceived Benefits minus Perceived Costs. Every page element either adds to benefits or raises costs. A VP audit maps both sides of the ledger, not just the benefits.
5. **Validate before launch.** No redesign or VP rewrite ships without an A/B test against the incumbent. Redesigns routinely destroy conversion. The audit produces hypotheses; the test produces truth.
6. **Macro conversion only.** The audit is anchored to one revenue-driving action. Secondary metrics are tracked in analytics but never used as the optimization target.
7. **Buried clarity must surface.** The clearest VP explanation is almost always in body copy or a closing paragraph — not the headline. Extract it and move it to the top as the primary test candidate.

## LAYER 2: QUALITY GUIDANCE

1. **POD specificity gate.** A POD candidate must pass: "Is this important to the prospect?" AND "Can a named competitor credibly claim this?" If yes to both, it is a POP. Demote it. Only features that fail the second test qualify as PODs.
2. **First-person button test.** Any CTA copy audit must check whether first-person phrasing ("Download My Report") outperforms second-person ("Download Your Report"). Default hypothesis: first-person wins. Test both.
3. **Source-match verification.** Pull the exact language from the traffic source (ad, email, social post). Confirm the headline contains or closely mirrors that language. Any terminology mismatch is a Relevance drag coded as a VP delivery failure.
4. **Kaizen sequence discipline.** This audit is Step 4 of the Kaizen Method (heuristic analysis). Do not shortcut to hypothesis generation without Steps 1-3 (client questionnaire, analytics review, customer research). VP diagnoses made without customer research inputs are hypothesis-grade, not finding-grade.
5. **Single hypothesis priority.** The output is a ranked shortlist, not a laundry list. The audit must designate one primary VP test candidate with a predicted lift direction and a rationale tied to LIFT factor scores.

## PURPOSE

This skill runs Chris Goward's Value Proposition audit on a specific web page to identify whether the page's conversion ceiling is being set by a weak, mis-stated, or competitively undifferentiated VP — and to generate the highest-leverage headline and claim to test first.

The LIFT Model (2009) treats the VP as the fulcrum: three factors LIFT conversion (Clarity, Relevance, Urgency) and two factors DRAG it (Anxiety, Distraction), but the VP determines the ceiling all six factors operate beneath. A strong VP poorly expressed is a Clarity problem. A strong VP aimed at the wrong audience is a Relevance problem. A strong VP on the wrong page is an Anxiety or Distraction problem. A genuinely weak VP is the VP problem — and no amount of optimization fixes it.

**Brag line: "We can score any landing page on 6 conversion forces before testing."**

POPs/PODs/POIs (2012) is the competitive decomposition tool that finds what goes in the VP. The Cost-Benefit Equation (2009) is the scoring lens that determines whether that VP is landing or leaking.

## INPUT REQUIREMENTS

**Required:**
- The page (URL, screenshot, or written description of above-the-fold content + headline + subhead + primary CTA)
- The ONE desired action (click / opt-in / purchase / call / qualify)

**Required for full audit:**
- Traffic source and exact ad/email/post copy that drives visitors to this page
- Top 2-3 named competitors and their primary claims/headlines

**Optional but high-value:**
- Existing analytics: bounce rate, scroll depth, click map, funnel drop-off point
- Customer research excerpts (survey verbatims, sales call objections, support ticket language)
- Current A/B test results if any exist

## EXECUTION PROCESS

### Step 1 — Extract the Current VP Statement (10 min)

Read every text block on the page. Identify:
- **Declared VP:** what the headline claims
- **Buried VP:** the clearest explanation of what the offer does and for whom — often in a sub-section, bullet, or closing paragraph

Score the gap between declared and buried on a 1-5 scale:
- 1 = identical (VP is already above the fold)
- 3 = buried VP is meaningfully clearer or more specific than the headline
- 5 = buried VP is an entirely different and stronger claim

A score of 3+ is an immediate "surface and test" mandate: lift the buried VP verbatim into a headline variation.

### Step 2 — Run the POPs/PODs/POIs Matrix

Build a three-column table (max 5 rows each):

| Need | POP (both have) | POD (only you) | POI (no one wants) |
|------|-----------------|-----------------|---------------------|
| [Prospect need 1] | | | |
| [Prospect need 2] | | | |
| [Prospect need 3] | | | |

**How to populate:**
- Column 1: pull from customer research, sales call language, or review mining. These are the jobs-to-be-done the prospect walks in with.
- Column 2: features/claims the page makes that competitors can honestly replicate. Mark each POP that currently appears in the headline — these are conversion anchors to remove or demote.
- Column 3: features/claims the page makes (or could make) that named competitors cannot. These are the headline candidates.
- Column 4: claims the page makes that prospects do not rank as important. Cut or move below fold.

**Threshold:** If no PODs exist in Column 3, the VP audit produces a competitive repositioning brief, not a headline — the offer itself must be differentiated before copy testing can move the needle.

### Step 3 — Score the Cost-Benefit Equation

List the explicit and implicit costs the page creates:

| Cost Type | Current Signal | Severity (H/M/L) |
|-----------|----------------|------------------|
| Price | Is price visible, anchored, framed? | |
| Time | Time-to-value stated or implied? | |
| Effort | Complexity of next step? | |
| Risk | Money-back, guarantee, free trial? | |
| Social risk | Who sees they did this? Embarrassment? | |

Then list the explicit benefits the VP claims:

| Benefit Type | Stated | Specific/Vague |
|--------------|--------|----------------|
| Functional gain | | |
| Emotional gain | | |
| Status gain | | |

**Equation score:** Benefits specificity score (1-10) minus Cost signal severity score (1-10). A negative or near-zero score means the page is leaking conversion even before Clarity/Relevance/Urgency issues are addressed.

### Step 4 — LIFT VP Sub-Score

Assign a VP score 0-10 on each of three dimensions:

| Dim | Question | Score |
|-----|----------|-------|
| Strength | Is the POD real, important, and believable? | /10 |
| Clarity | Can a new visitor state the VP in 5 seconds? | /10 |
| Scent match | Does VP language mirror the traffic source? | /10 |

Average = VP LIFT sub-score. Interpret:
- 8-10: VP is not the primary drag; move to Anxiety/Distraction audit
- 5-7: VP is a moderate drag; one strong headline test likely moves 15-40%
- 0-4: VP is the primary drag; fix before any other LIFT lever; expect 40-200%+ lift from VP correction alone

### Step 5 — Traffic Source Scent Match

Pull exact language from the traffic source (ad headline, email subject, social post).

Check: Does the landing page headline contain the exact term or close synonym that the visitor just read?

- Match: pass
- Partial match: flag as Relevance drag; generate scent-corrected headline variation
- Mismatch: flag as critical; visitor experiences disorientation; bounce is the predicted outcome

Example: Ad says "free conversion audit." Page headline says "Grow Your Business." Full mismatch. Test: "Get Your Free Conversion Audit" as the H1.

### Step 6 — Rank Hypotheses and Write Test Candidates

From Steps 1-5, produce a ranked shortlist (max 3 items):

| Rank | Hypothesis | LIFT factor | Predicted dir | Test format |
|------|------------|-------------|---------------|-------------|
| 1 | [Primary test] | VP/Clarity | +CR | A/B |
| 2 | [Secondary] | VP/Relevance | +CR | A/B |
| 3 | [Structural] | VP/Distraction | +CR | A/B |

Primary test must be a headline or subhead — the VP carrier. Secondary tests must wait until primary is validated.

Note: For sites below 1M monthly visitors, use fractional factorial DOE if testing 3+ elements simultaneously. Do not run full multivariate on low-traffic pages.

## OUTPUT STRUCTURE

**1. VP Extraction Summary**
- Declared VP (current headline)
- Buried VP (best candidate from body copy)
- Clarity gap score (1-5)

**2. POPs/PODs/POIs Matrix**
- Full three-column table
- Diagnosis: which POPs are currently in the headline that should be removed
- POD shortlist: top 2 differentiators to test as headline claims

**3. Cost-Benefit Equation Audit**
- Cost inventory with severity ratings
- Benefit inventory with specificity ratings
- Equation balance score

**4. LIFT VP Sub-Score**
- Three dimension scores + average
- Interpretation: is VP the primary drag or not?

**5. Scent Match Report**
- Traffic source language vs. headline language
- Match/partial/mismatch verdict
- Corrected headline if mismatch detected

**6. Ranked Hypothesis Shortlist**
- Max 3 items, ranked by predicted impact
- Primary VP test candidate with before/after copy
- Kaizen Method note: flag if Steps 1-3 (questionnaire, analytics, customer research) were skipped and reduce confidence rating accordingly

## WORKED MINI-EXAMPLE

**Page:** SaaS landing page for a project management tool. Desired action: free trial signup.

**Traffic source ad headline:** "Never miss a deadline again"

**Current page headline:** "The Project Management Platform Built for Teams"

**Buried VP (found in paragraph 3):** "See every deadline, dependency, and blocker in one view — before they become problems."

**Clarity gap score:** 4 (buried VP is entirely different and stronger)

**POPs/PODs/POIs pass (abbreviated):**

| Need | POP | POD | POI |
|------|-----|-----|-----|
| See all deadlines | Every PM tool has this | — | — |
| Spot blockers early | Competitors claim this broadly | Real-time dependency graph surfacing blockers 48hr ahead | — |
| Team alignment | Generic claim | — | Color-coded avatars (no one cares) |

**POD identified:** "surfaces blockers 48 hours before they hit" — no named competitor makes this specific, time-bound claim.

**Scent match:** Ad said "never miss a deadline." Current headline says nothing about deadlines. Full mismatch.

**LIFT VP sub-score:**
- Strength: 8/10 (POD is real and specific)
- Clarity: 3/10 (buried; headline says nothing)
- Scent match: 1/10 (full mismatch with ad)
- Average: 4.0 — VP is primary drag

**Primary test candidate:**

Before: "The Project Management Platform Built for Teams"

After: "See Every Blocker 48 Hours Before It Hits — Never Miss a Deadline Again"

Rationale: surfaces the POD, mirrors ad scent token ("never miss a deadline"), and states the functional gain with a specific time horizon. Predicted direction: +CR. Format: A/B, single headline swap.

## OUTPUT FILE

Save to: [project-folder]/Goward - Click Architecture/[YYYY-MM] - Value Prop Fulcrum Audit.md
