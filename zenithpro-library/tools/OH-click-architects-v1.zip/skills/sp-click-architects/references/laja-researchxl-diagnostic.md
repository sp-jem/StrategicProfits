---
name: laja-researchxl-diagnostic
description: Use when a page has unexplained drop-off, conflicting hunches, or pre-test hypothesis debt — runs the 6-spoke ResearchXL audit to surface real conversion leaks before touching the page.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peep Laja (CXL Institute / Wynter; ResearchXL Model 2014; Four-Factor Heuristic Audit 2013; Conversion Formula) — Click Architecture (Skill 1 of 7)"
interface:
  invoke: "/laja-researchxl-diagnostic"
  calls: []
  called_by: [user, laja-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Traffic mix, offer positioning, and seasonal motivation shift rapidly; a 6-week-old heuristic audit no longer maps to the live page state."

laja_pxl_integration:
  feeds_to: laja-pxl-prioritizer
  shared_data: Ranked problem list with evidence-source tags (analytics / qualitative / replay / user-test) — PXL scoring requires these source flags to award points 6-9.

laja_heuristic_integration:
  feeds_to: laja-heuristic-walkthrough
  shared_data: Spoke 1 severity ratings (1-5 per axis per page) feed the sibling's deeper four-factor drill-down without re-running the full audit.

kohavi_integration:
  feeds_from: kohavi-field-intelligence
  feeds_to: kohavi-field-intelligence
  shared_data: Analytics drop-off data (Spoke 3) surfaces the measurement-validity questions Kohavi's trustworthy-experiment standard requires before a test is launched.
---

# Laja ResearchXL Diagnostic

## LAYER 1: INVARIANTS (Never override.)

1. **Data before opinion.** No hypothesis enters the test queue until at least two of the six spokes corroborate it. One source is anecdote.
2. **Motivation cannot be created, only filtered.** The Conversion Formula C = 4M + 3V + 2(I-F) - 2A assigns the highest coefficient (4x) to pre-existing user motivation — diagnose whether wrong traffic is arriving before blaming the page.
3. **Value proposition first.** V carries the 3x coefficient. Every spoke finding is weighed against whether it impairs clarity of "what is it, who is it for, why this." Fix V before layering I, F, or A.
4. **Open-ended survey questions only.** Multiple-choice bakes in your assumptions. Spoke 4 qualitative questions must be open-ended ("What was your biggest hesitation before buying?") — no answer options presented.
5. **Minimum traffic gates are hard.** Mouse-tracking analysis (Spoke 6) requires 2,000-5,000 visitors on the specific page variant before heatmap patterns are statistically readable. Do not interpret sparse maps.
6. **'Just-do-it' fixes are not tests.** Broken rendering, missing trust seals, 404 errors found in Spoke 2 are implemented immediately — do not consume test bandwidth on clearly wrong elements.
7. **Problem list, not tactic list.** Output names the leak and its evidence. Tactics and test designs belong to laja-pxl-prioritizer (Skill 2).

## LAYER 2: QUALITY GUIDANCE

1. Score Spoke 1 severity on the 1-5 scale (1=minor friction, 5=critical persuasion issue likely driving significant revenue shift). Only 4s and 5s appear in the final problem list.
2. For Spoke 3 analytics, compute actual drop-off percentages by funnel step, not just raw exit rates. A checkout page at 40% completion is a different diagnosis than a landing page at 40% completion.
3. Triangulate: a problem confirmed by analytics + qualitative + replay earns a HIGH confidence tag. Two sources = MEDIUM. One source = hypothesis only — note it but do not promote it to the test queue without additional confirmation.
4. For B2B pages, map survey findings to buyer role (title, pain metrics, vocabulary) using the B2B Message Layers Framework before writing recommendations. Layer 1 Clarity and Layer 2 Relevance failures are the most common and most costly.
5. Report findings as "The page fails to [user need] because [evidence]" — not as "add social proof" or "shorten the form." Diagnose first; prescription lives downstream.

## PURPOSE

This skill runs Peep Laja's ResearchXL Model — the six-spoke conversion research system that generates test hypotheses from triangulated data, not opinion.

**Brag line:** "We find the real leak with 6 research lenses before we touch the page."

Most CRO work fails because it starts with solutions. ResearchXL starts with structured evidence collection across six independent data sources. The spokes are deliberately sequenced: heuristics and technical QA first (fast, cheap), then analytics to locate the money leak, then qualitative and user testing to understand why, then mouse tracking to observe what. Each spoke reduces hypothesis space. The combined output is a ranked, evidence-tagged problem list — not a list of tactics — that feeds directly into PXL scoring (Skill 2, laja-pxl-prioritizer).

The skill operates exclusively on a specific page + desired action. It does not audit brand strategy or business model. It audits the gap between user arrival and desired action on this page today.

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description of every element visible above and below the fold
- The ONE desired action: what must a visitor do for this page to succeed (click, opt-in, purchase, schedule, download)

**Strongly recommended (provide what exists):**
- Analytics access or exported funnel data (sessions, bounce rate, conversion rate by device/browser)
- Any existing survey responses, chat transcripts, or customer support themes
- Ad/email creative that drives traffic to this page (for message-scent check)
- Audience definition: job title, pain metrics, stage of awareness

**Optional:**
- Heatmap or session replay exports
- User testing recordings
- Competitor page URLs (for differentiation context)
- Historical A/B test results on this page

## EXECUTION PROCESS

### PRE-AUDIT: Define the Conversion Event
State the desired action precisely. "Increase conversions" is not valid. Example: "Visitor clicks 'Start Free Trial' CTA on the SaaS pricing page." Every spoke finding is evaluated against this specific event.

---

### SPOKE 1 — Heuristic Analysis (Four-Factor Audit)
**Tool:** Expert walk-through. No data access required.
**Scope:** Desktop, mobile, and tablet renders of this page.

Score each of the four axes on a 1-5 severity scale:

| Axis | Question | 5 = Critical |
|------|----------|--------------|
| Clarity | "What is it? Who is it for? What do I do here?" answerable in 5 seconds? | Visitor cannot determine product category or desired action |
| Relevance | Pre-click ad/email language matches this page's headline + hero + CTA exactly? | Message scent broken — different promise or vocabulary |
| Friction | Anything slowing or blocking action: long forms, jargon, steps, premature data asks, slow load? | Form has 7+ fields before account creation or page load >3s |
| Distraction | One or two clearly defined most-wanted actions on the page? | Navigation, sidebars, or secondary links pull focus from primary CTA |

**Legend:** Clarity=Cl, Relevance=Re, Friction=Fr, Distraction=Di

Run the 5-second test mentally: cover everything below the fold. A visitor landing here cold — can they answer the three Clarity questions? If not, score Clarity 4 or 5.

Check message scent: paste the exact headline from the ad/email alongside the page headline. Do they use the same words and make the same promise? Disconnect = Relevance 4-5.

Count most-wanted actions. More than two = Distraction 4-5.

**Output:** Severity table by axis. Flag any axis scoring 4-5 as a confirmed problem.

---

### SPOKE 2 — Technical Analysis
**Tool:** BrowserStack or equivalent; Google PageSpeed Insights; manual QA checklist.

Check:
- Conversion rate segmented by browser (Chrome, Safari, Firefox, Edge) — a delta > 20% between browsers signals a rendering bug
- Conversion rate by device (desktop vs mobile vs tablet) — mobile CR 40%+ below desktop on a responsive page = mobile UX failure, not traffic problem
- Page load time: target < 2.5s LCP. Every 1s delay = 7% conversion drop (baseline)
- Broken images, missing trust seals, 404 on CTA links, form submission errors
- Mobile: tap target sizes, horizontal scroll, form keyboard behavior

**Threshold:** Any browser or device segment with CR > 20% below average = critical technical issue. Fix immediately; do not test.

**Output:** Device/browser CR table. List of bugs flagged for immediate fix (no test needed).

---

### SPOKE 3 — Digital Analytics
**Tool:** GA4, Heap, Mixpanel, or equivalent funnel report.

Diagnose where money is leaking:

Step 1: Map the conversion funnel step-by-step (e.g., Landing Page → Pricing Page → Checkout Step 1 → Checkout Step 2 → Confirmation).

Step 2: Compute drop-off % at each step. Formula: `Drop-off % = (Exits at Step N) / (Arrivals at Step N) × 100`

Step 3: Flag any step with drop-off > 50% as a primary leak. Flag any checkout page with completion < 70% as a major anxiety or friction signal.

Step 4: Segment by traffic source. A page converting at 4% on paid search and 1% on display is a relevance/message-scent problem, not a page problem.

Step 5: Behavioral-outcome correlation. Are users who scroll past 50% more likely to convert? Are users who hover the CTA but don't click a significant segment? (Use heatmap + analytics if available.)

Step 6: Verify measurement. Is the conversion event tagged correctly? Is the funnel excluding non-target segments (bots, internal traffic)? Bad measurement invalidates all optimization work.

**Output:** Funnel drop-off table. Top 1-3 leak pages identified. Traffic-source conversion segmentation if available.

---

### SPOKE 4 — Qualitative Research (On-Site Surveys)
**Tool:** Hotjar, Qualaroo, or post-purchase/post-signup email survey.

**Targeting:** Trigger on exit intent (non-converting visitors) and immediately post-conversion.

**Minimum:** 100-200 responses per question before drawing conclusions.

**Required questions (open-ended only — no answer options):**
- Non-converters: "What stopped you from [desired action] today?"
- Non-converters: "What's your biggest question about [product/offer]?"
- Converters: "What was your biggest hesitation before [action]?"
- Converters: "What almost stopped you from [action]?"
- Converters: "What made you confident enough to [action]?"

**Analysis:** Tally recurring themes. The top 3 hesitations from converters = anxiety items the page must address. The top 3 stoppers from non-converters = friction or clarity failures.

**B2B overlay:** Map responses to buyer role vocabulary. If visitor language differs from page language (e.g., visitor says "headcount waste," page says "inefficiency") — that is a Clarity/Relevance failure at the B2B Message Layer 2 (Relevance) level.

**Output:** Top 5 hesitation themes with response counts. Exact verbatim quotes (3+ per theme) suitable for copying into page copy as objection-handling language.

---

### SPOKE 5 — User Testing
**Tool:** UserTesting.com, Maze, or moderated sessions.
**Volume:** 5-15 representative users performing the primary task.

**Task script:** "You've arrived at this page looking for [product category]. Your goal is to [desired action]. Think aloud as you go."

**Observation protocol:**
- Timestamp every moment of hesitation, re-reading, or backward navigation
- Note the first element each user comments on above the fold
- Record every question users ask aloud ("I wonder if…", "Does this mean…")
- Flag every moment a user tries to click something that is not clickable

**Threshold:** If 3 of 5 users share the same point of confusion = confirmed friction/clarity issue, not outlier.

**Output:** Friction map by page section. Top 3 confusion moments with timestamps. User vocabulary list (exact phrases used to describe the product or their need).

---

### SPOKE 6 — Mouse Tracking Analysis
**Tool:** Hotjar, Microsoft Clarity, FullStory, or equivalent.
**Minimum:** 2,000-5,000 visitors on this page before interpreting heatmaps.

**Heatmap review:**
- Click map: are clicks landing on the primary CTA? If significant clicks land on non-interactive elements (images, headings), that is a false affordance or misaligned visual hierarchy
- Scroll map: what % of visitors reach the primary CTA? If CTA is below the fold and only 30% scroll that far, the above-fold section is failing to hook motivation

**Replay review (target: 20-50 sessions on non-converting visitors):**
- Find the timestamp of last engagement before exit
- Identify the element being viewed at exit — that element, or the absence of what should follow it, is the primary suspect
- Look for rage clicks (3+ clicks in rapid succession on same element) = broken interaction or unmet expectation

**Output:** Scroll depth at CTA location. Top 3 click-map anomalies. Top 3 replay exit moments with suspected cause.

---

### SYNTHESIS: Ranked Problem List

Compile findings across all six spokes into a single table.

| # | Problem | Spokes | Conf | Axis/Formula |
|---|---------|--------|------|--------------|
| 1 | [Description] | 1,3,4 | HIGH | Clarity / V |
| 2 | [Description] | 2,6 | MED | Friction / F |
| 3 | [Description] | 4,5 | MED | Anxiety / A |

**Legend:** Conf = Confidence (HIGH=3+ spokes, MED=2 spokes, HYP=1 spoke); Axis = Four-Factor axis; Formula = Conversion Formula variable impacted (M/V/I/F/A)

Confidence tags:
- HIGH: 3+ spokes confirm — promote to test queue
- MED: 2 spokes confirm — promote with caveat
- HYP: 1 spoke — hypothesis only, flag for additional research before testing

**Output:** Ranked table (max 10 items). This feeds directly to laja-pxl-prioritizer for scoring and sequencing.

## OUTPUT STRUCTURE

The skill delivers one document with these sections:

1. **Page + Action Definition** — Exact page and desired action scoped.
2. **Spoke Summaries** — One paragraph per spoke with key finding and evidence.
3. **Technical Bug List** — Immediate fixes (no test needed) with severity.
4. **Qualitative Verbatim Block** — Top 10 exact user phrases for copy mining.
5. **Ranked Problem List** — Numbered table (max 10 items) with confidence and formula-variable tags.
6. **Spoke Evidence Map** — Which spoke(s) support each problem (for PXL scoring input).
7. **Open Hypotheses** — HYP-confidence items that need one more corroborating source.

## WORKED MINI-EXAMPLE

**Page:** SaaS project management tool pricing page. Desired action: Click "Start Free Trial."
**Conversion rate:** 3.2% (industry benchmark for SaaS pricing pages: 5-8%).

**Spoke 1 (Heuristic):** Above-the-fold headline reads "Work smarter, not harder." No product category stated. Clarity score: 5. No plan comparison table visible without scrolling. Three navigation items compete with the CTA.

**Spoke 3 (Analytics):** Mobile CR = 1.1% vs desktop CR = 4.8%. Mobile = 55% of sessions. Drop-off: 61% leave this page without clicking anything.

**Spoke 4 (Qualitative):** Top converter hesitation (n=147): "I wasn't sure if it worked with Slack." Top non-converter stopper (n=89): "I didn't understand what the free trial included."

**Spoke 6 (Replay):** 34% of visitors scroll to the plan table. Rage clicks on "Compare plans" link (links to a separate page instead of expanding inline). Exit concentrated at plan table section.

**Ranked Problem List (excerpt):**

| # | Problem | Spokes | Conf | Axis |
|---|---------|--------|------|------|
| 1 | Headline states no product category — 5-sec test fails | 1, 3 | HIGH | Clarity/V |
| 2 | Mobile layout buries CTA — 1.1% mobile CR | 2, 3 | HIGH | Friction/F |
| 3 | Trial scope not stated — top non-converter stopper | 4, 6 | HIGH | Anxiety/A |
| 4 | Slack integration not visible — top converter hesitation | 4 | HYP | Anxiety/A |

**Before headline:** "Work smarter, not harder."
**After (Clarity fix):** "Project management for engineering teams — free 14-day trial, no card required."

Addresses: Clarity (what is it, who is it for), Anxiety (trial scope), and Relevance (engineering-team specificity). V coefficient improved before any other lever is touched.

## OUTPUT FILE
Save to: [project-folder]/Laja - Click Architecture/[YYYY-MM] - ResearchXL Diagnostic - [Page Name].md
