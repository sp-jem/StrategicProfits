---
name: pirolli-field-intelligence
description: >
  Meta-synthesis across all 6 Pirolli & Card page-action skills. Detects
  convergence zones, resolves contradictions, fires The Single Move, and
  connects Information Foraging Theory to the full Click Architects network.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peter Pirolli & Stuart Card — Field Intelligence (Skill 7 of 7)"
interface:
  invoke: "/pirolli-field-intelligence"
  calls:
    - pirolli-scent-trail-auditor
    - pirolli-patch-abandonment-predictor
    - pirolli-information-diet-mapper
    - pirolli-link-diagnosticity-scorer
    - pirolli-scent-gradient-designer
    - pirolli-foraging-cost-reducer
  called_by: [user, click-architects]
  outputs_to: [client-output-folder]

freshness_gate:
  max_age_days: 45
  reason: >
    Traffic sources, ad copy, and search-result snippets — all scent-origin
    signals — shift with campaign rotations and algorithm updates. Scent-match
    audits older than 45 days are stale.

integrations:
  - thinker: kohavi-field-intelligence
    feeds_from: kohavi
    feeds_to: pirolli
    shared_data: experiment_design
    insight: >
      Pirolli identifies the scent hypothesis; Kohavi tests it. A/B experiments
      on headline trigger-word density give causal proof of which vocabulary
      raises click-through — converting IFT predictions into measured lift.

  - thinker: eisenberg-field-intelligence
    feeds_from: pirolli
    feeds_to: eisenberg
    shared_data: persuasion_path_map
    insight: >
      Eisenberg's Persuasion Architecture sequences buyer modes (spontaneous →
      methodical → competitive → humanistic). Pirolli scent must be calibrated
      per mode: methodical visitors need spec-vocabulary scent; spontaneous
      visitors need outcome-vocabulary scent. Combining them produces a
      scent-layered page that satisfies multiple forager types.

  - thinker: fitts-field-intelligence
    feeds_from: pirolli
    feeds_to: fitts
    shared_data: click_cost_model
    insight: >
      Pirolli measures cognitive cost (scan time, vocabulary mismatch); Fitts
      measures motor cost (target distance × size). Total click cost =
      Pirolli within-patch cost + Fitts pointing time. Reducing both in
      tandem (high-scent CTA in a large, near target) minimises the full
      cost equation the Marginal Value Theorem acts on.

  - thinker: hick-field-intelligence
    feeds_from: pirolli
    feeds_to: hick
    shared_data: choice_elimination_log
    insight: >
      Hick's Law: reaction time rises logarithmically with choice count.
      Pirolli's patch-leaving trigger fires even faster when multiple equally
      scented links compete. Combining: strip competing links to one
      dominant scent trail — Hick reduces deliberation time, Pirolli ensures
      the surviving option wins the foraging decision.

  - thinker: goward-field-intelligence
    feeds_from: goward
    feeds_to: pirolli
    shared_data: conversion_research_briefs
    insight: >
      Goward's qualitative customer research surfaces the exact trigger words
      visitors use to describe their goal. Those words ARE the scent vocabulary.
      Feeding Goward research outputs directly into Pirolli's proximal cue
      audit closes the loop between what customers say and what the page labels.

  - thinker: gigerenzer-field-intelligence
    feeds_from: pirolli
    feeds_to: gigerenzer
    shared_data: heuristic_cue_audit
    insight: >
      Gigerenzer's fast-and-frugal heuristics: users rely on one good reason
      to stop foraging (take-the-best). Pirolli scent determines which cue wins
      that "one reason" slot. Designing for the take-the-best stopping rule
      means the highest-scent cue must also be the most prominent — not buried
      in body copy.

  - thinker: laja-field-intelligence
    feeds_from: laja
    feeds_to: pirolli
    shared_data: voice_of_customer_data
    insight: >
      Laja's conversion research methodology (Jobs-to-be-Done + friction
      interviews) produces verbatim goal language. That language is the
      canonical trigger-word set for scent matching. Pirolli without Laja's
      VOC data is guessing at vocabulary; Laja without Pirolli lacks a
      structural model for WHERE to place the words.

  - thinker: norman-field-intelligence
    feeds_from: norman
    feeds_to: pirolli
    shared_data: affordance_signal_map
    insight: >
      Norman's affordances make action possibilities perceivable; Pirolli's
      scent makes destinations valuable. A button that affords clicking but
      has weak scent label gets noticed but not pressed. Both signals must fire:
      perceived clickability (Norman) + perceived destination value (Pirolli).

  - thinker: nielsen-field-intelligence
    feeds_from: nielsen
    feeds_to: pirolli
    shared_data: usability_audit_findings
    insight: >
      Nielsen's usability heuristics (visibility, match with real world,
      recognition over recall) map cleanly onto Pirolli's proximal cue model.
      "Match with the real world" IS scent-matching: the page vocabulary must
      match the user's mental model vocabulary. Nielsen findings flag the
      usability violations; Pirolli explains WHY they cause abandonment
      (Marginal Value Theorem exit).

  - thinker: eyal-field-intelligence
    feeds_from: eyal
    feeds_to: pirolli
    shared_data: trigger_reward_map
    insight: >
      Eyal's Hook Model: external trigger → action → variable reward → investment.
      The external trigger IS the scent origin cue (ad, email, search result).
      Pirolli predicts whether the landing page sustains the trigger vocabulary
      through to action. Scent decay between trigger and reward = hook broken.

  - thinker: brignull-field-intelligence
    feeds_from: pirolli
    feeds_to: brignull
    shared_data: friction_pattern_inventory
    insight: >
      Brignull's dark patterns impose friction; Pirolli quantifies the foraging
      cost that friction creates. Combining them reveals whether "annoying
      friction" crosses the Marginal Value Theorem exit threshold — i.e., when
      manipulation becomes self-defeating because visitors leave rather than
      comply.

  - thinker: fogg-field-intelligence
    feeds_from: fogg
    feeds_to: pirolli
    shared_data: motivation_ability_map
    insight: >
      Fogg's B=MAP: behavior requires motivation × ability × prompt. Pirolli's
      within-patch cost reduction IS ability enhancement on the page. High
      scent raises motivation by signalling proximity to the goal. A
      Fogg-Pirolli combined audit checks: does the page's ability cost
      (Pirolli) match the motivation level triggered by the scent cues?

  - thinker: cialdini-field-intelligence
    feeds_from: cialdini
    feeds_to: pirolli
    shared_data: social_proof_placement_map
    insight: >
      Cialdini's social proof and authority signals function as
      scent-amplifying proximal cues. A testimonial using the exact trigger
      words of the visitor's goal doubles as both proof (Cialdini) and
      high-scent vocabulary (Pirolli). Place social proof inside the scent
      trail, not outside it.

  - thinker: kahneman-field-intelligence
    feeds_from: kahneman
    feeds_to: pirolli
    shared_data: cognitive_load_audit
    insight: >
      Kahneman's System 1 / System 2: high within-patch cost forces a System 2
      deliberation switch, slowing the rate-maximising heuristic and triggering
      abandonment. Pirolli's formatting prescriptions (bullets, bolded keywords,
      layer-cake structure) keep users in System 1 — faster value extraction,
      lower perceived cost, longer patch stay.

  - thinker: thaler-field-intelligence
    feeds_from: thaler
    feeds_to: pirolli
    shared_data: default_and_loss_frame_map
    insight: >
      Thaler's endowment effect: users weight losses more than gains.
      Framing the CTA as "don't lose access" rather than "get access" raises
      perceived value of the information patch — increasing the gain-rate
      numerator in Pirolli's (Value / Cost) ratio and extending patch stay.

  - thinker: iyengar-choice-set-auditor
    feeds_from: pirolli
    feeds_to: iyengar
    shared_data: option_set_audit
    insight: >
      Iyengar: too many options reduces conversion (paradox of choice). Pirolli:
      too many link options dilutes scent — the visitor cannot identify the
      highest-scent path. Iyengar's choice reduction and Pirolli's scent
      concentration are the same prescription arrived at from different models.
      Their joint finding: one dominant option + one dominant scent trail.
---

# Pirolli & Card Field Intelligence

## LAYER 1: INVARIANTS

1. Synthesis not summary. Detect cross-skill PATTERNS; do not recap each tool's output.
2. Convergence zones must be named and quantified where possible.
3. Contradictions are surfaced, not hidden. Competing diagnoses require explicit resolution.
4. The Single Move is mandatory — one highest-leverage page change, actionable today.
5. The Mirror — examine the client's own page-design biases before recommending.
6. Cross-system intelligence with other Click Architects is the highest-value section.
7. Freshness gate: outputs older than 45 days trigger a re-run flag.

## LAYER 2: QUALITY GUIDANCE

Strong synthesis names the *mechanism* connecting two findings, not just the finding.
Weak: "Both the auditor and the predictor found scent problems."
Strong: "The scent-trail-auditor found vocabulary mismatch at the headline; the patch-abandonment-predictor found exit rate spiking at the same scroll depth — the same Marginal Value Theorem exit signal appearing in two independent measurements. The fix is a single headline rewrite, not two separate interventions."

## PURPOSE

We can predict which links leak visitors before we ship the page.
Field Intelligence operationalizes that claim across all 6 tools, producing one coherent diagnosis and one executable move.

## INPUT REQUIREMENTS

Run at least 4 of the 6 tool skills on the SAME page + desired action before invoking this skill.
Required inputs:
- Page URL or full written description
- Desired action (click / opt-in / purchase / next step)
- Output files from >= 4 tools (pirolli-scent-trail-auditor, pirolli-patch-abandonment-predictor,
  pirolli-information-diet-mapper, pirolli-link-diagnosticity-scorer,
  pirolli-scent-gradient-designer, pirolli-foraging-cost-reducer)
- Traffic source (ad, email, organic search — determines the scent origin vocabulary)

Missing tools: acceptable, but note which convergence zones are blind.

## EXECUTION PROCESS

### Step 1 — Component Synthesis

For each tool output, extract:
| Tool | Primary Finding | Severity (H/M/L) | Page Location |
|------|----------------|------------------|---------------|
| scent-trail-auditor | ... | ... | ... |
| patch-abandonment-predictor | ... | ... | ... |
| information-diet-mapper | ... | ... | ... |
| link-diagnosticity-scorer | ... | ... | ... |
| scent-gradient-designer | ... | ... | ... |
| foraging-cost-reducer | ... | ... | ... |

Legend: H=High (exit-causing), M=Medium (friction-adding), L=Low (polish)

### Step 2 — Convergence Detection

Identify zones where >= 2 tools flag the same page location or mechanism.
Name each zone explicitly:

**Zone A — Headline Scent Break** (auditor + predictor both flag fold 1)
**Zone B — Mid-Page Foraging Collapse** (gradient + diet mapper agree on scroll depth X)
**Zone C — CTA Label Zero-Scent** (diagnosticity + cost reducer both flag the button)

Each convergence zone = a confirmed finding, not a hypothesis.
Each isolated finding (single tool only) = provisional — flag it as such.

### Step 3 — Contradiction Resolution

If two tools produce conflicting diagnoses:
- State both explicitly
- Apply the Marginal Value Theorem as the arbiter: which finding, if true, would trigger
  the faster exit? Prioritise that one.
- Flag the conflict for testing (hand off to Kohavi).

### Step 4 — Scent-Chain Reconstruction

Map the full scent trail from traffic source to CTA:
[Traffic Source Label] → [Page Headline] → [Hero Image Alt/Subject] → [Subhead 1] →
[Body Para 1] → [Testimonial] → [CTA Label]

Mark each link in the chain: HIGH / MEDIUM / LOW / BROKEN.
A BROKEN link is any vocabulary discontinuity — different terminology, synonym substitution,
brand-invented phrase. One BROKEN link is sufficient to trigger patch-leaving behaviour.

### Step 5 — Amplification Check

Would fixing the Single Move also fix convergence zones downstream?
IFT: fixing a headline scent break often resolves mid-page foraging collapse and CTA weakness
because the scent trail is a chain — restoring the first link propagates forward.
If yes: note the cascade; do not over-prescribe separate fixes for each zone.

### Step 6 — The Single Move

Format:
**Change:** [Exact element to change — headline / subhead / CTA / image]
**Current state:** [Verbatim existing copy or description]
**New state:** [Verbatim replacement]
**Mechanism:** [Which IFT framework makes this change effective]
**Predicted effect:** [Specific: e.g., "Raises scent-match score on the scent-trail-auditor
from 2/5 to 4/5; reduces patch-leaving probability at fold 1 by est. 15-25%"]

Worked example:
Page: SaaS trial landing page. Traffic source: Google ad headline "Cut invoice errors instantly."
Current H1: "Smarter Accounts Payable for Growing Teams."
Problem: zero trigger-word overlap with ad copy — scent break at fold 1.
Single Move: rewrite H1 to "Cut Invoice Errors Instantly — Automate AP in One Afternoon."
Mechanism: Proximal Cue Model — echoes exact ad vocabulary; SNIF-ACT activation A_i rises
because S_ji (cue-to-destination association) increases from near-zero to high.
Predicted effect: 20-35% reduction in immediate bounce; zero additional budget.

### Step 7 — The Mirror

Before delivering recommendations, examine the client's page-design pattern:
- Do they habitually use brand vocabulary over customer vocabulary?
- Do they treat images as decoration rather than informational cues?
- Do they front-load company story rather than goal-relevant value?

Name the bias. Each bias maps to a specific IFT failure mode (Proximal Cue Model failure,
Rate-Maximising Heuristic suppression, Within-Patch Cost inflation). Naming it prevents
the same failure mode from re-appearing in the next redesign.

### Step 8 — Cross-System Intelligence

Full integration logic lives in the YAML hooks above. For each run, select the 3-5 pairings
most relevant to this page's diagnosis and state: what Pirolli's finding implies for the
paired model, and one combined action.

Highest-impact pairings by failure pattern:

**Fold-1 bounce (scent break at headline):**
- Pirolli × Kohavi: ship Single Move as A/B Treatment; metric = scroll-to-CTA rate.
- Pirolli × Laja: verify trigger-word set came from VOC, not internal vocabulary.

**Mid-page dropout (scent decay below fold 1):**
- Pirolli × Kahneman: convert paragraphs > 3 sentences to bullets; bold every trigger word.
- Pirolli × Fogg: if motivation is high, dropout = within-patch cost problem, not copy problem.

**CTA failure (high scroll-depth, low click):**
- Pirolli × Fitts: confirm highest-scent CTA is also the largest, most proximal target.
- Pirolli × Hick: count CTAs above fold; reduce to 1 if > 2.
- Pirolli × Thaler: test loss-frame CTA ("Don't lose access") vs gain-frame ("Get access").

**Social proof not converting:**
- Pirolli × Cialdini: rewrite testimonials to use the same trigger words as the headline.
  Testimonials that use different vocabulary break the scent chain.

**Buyer-mode mismatch:**
- Pirolli × Eisenberg: calibrate trigger words to visitor mode — outcome-language for
  spontaneous, spec-language for methodical.

**Everything × Kohavi:** no projection is a fact until it has been tested. Hand every
Single Move to Kohavi before calling the diagnosis confirmed.

### Step 9 — Coherence Map

Confirm all recommendations are internally consistent:
- Single Move vocabulary must match the scent trail map from Step 4
- CTA label must be the highest-scent element on the page
- Image prescriptions must reinforce, not contradict, the trigger-word set
- Any Cialdini social-proof additions must use the same vocabulary

Flag any internal contradiction. Resolve before outputting to client.

### Step 10 — Conversion Projection

Express expected lift in concrete terms:
- Scent-break fixes at fold 1: 15-35% reduction in immediate bounce (IFT literature baseline)
- Mid-page scent decay fixes: 10-20% increase in scroll-to-CTA rate
- CTA label scent improvement: 5-15% increase in click-through on the CTA
- Combined (all zones): 25-50% improvement in page conversion rate

Caveat: these are model-based projections. Kohavi (A/B test) converts them to measured facts.
Always flag which zones are confirmed (multi-tool convergence) vs provisional (single tool).

## OUTPUT STRUCTURE

```
# Pirolli & Card Field Intelligence — [Page Name] — [Date]

## Page + Desired Action
[One paragraph: what page, what action, what traffic source]

## Component Synthesis Table
[Step 1 table]

## Convergence Zones
[Step 2 — named zones with evidence]

## Contradictions
[Step 3 — if any]

## Scent-Chain Map
[Step 4 — full chain with HIGH/MEDIUM/LOW/BROKEN labels]

## The Single Move
[Step 6 — change / current / new / mechanism / predicted effect]

## The Mirror
[Step 7 — named client bias + IFT failure mode it causes]

## Cross-System Intelligence
[Step 8 — top 3-5 relevant pairings for this specific page, not all 15]

## Coherence Check
[Step 9 — pass/fail per recommendation]

## Conversion Projection
[Step 10 — zone-by-zone + combined estimate]

## Recommended Next Run
[Which tool skills to re-run first, and in what order, after Single Move is implemented]
```

## OUTPUT FILE

Save to: `[client-output-folder]/pirolli-field-intelligence-[YYYY-MM-DD].md`

If client-output-folder is not specified, save to:
`~/click-architects-output/[Client or Page Name]/`

File naming: one file per page per run date. Do not overwrite prior runs — prior runs
are the baseline for measuring lift after Single Move implementation.
