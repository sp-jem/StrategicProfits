---
name: brignull-sludge-auditor
description: Use when a page has asymmetric exit friction, obstruction, or hidden costs that work against visitor interest — diagnoses and removes sludge to ensure conversion reflects genuine user preference.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Harry Brignull (deceptivedesign.org, 2010–2023; The Sludge Concept, Roach Motel Pattern, Mathur et al. Taxonomy) — Click Architecture (Skill 2 of 7)"
interface:
  invoke: "/brignull-sludge-auditor"
  calls: []
  called_by: [user, brignull-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Sludge patterns evolve as platforms update checkout flows, consent frameworks shift (GDPR/FTC), and A/B test cycles introduce new friction variants."

brignull_cluster_integration:
  feeds_from: [brignull-dark-pattern-scanner]
  feeds_to: [brignull-fair-pattern-designer, brignull-ethical-line-mapper]
  shared_data: "Roach Motel asymmetry score and Disclosure Test verdicts pass directly into fair-pattern-designer as pre-cleared friction inventory. Dark-pattern-scanner upstream findings narrow the sludge audit to confirmed obstruction loci."

thaler_integration:
  feeds_from: [thaler-nudge-auditor, thaler-default-detector]
  feeds_to: [thaler-choice-architect]
  shared_data: "Thaler's sludge framing (Sunstein/Thaler 2019) is the theoretical parent of this skill. Thaler-nudge-auditor surfaces default architecture; brignull-sludge-auditor surfaces deliberate anti-user friction. Combined: full asymmetry map (what pushes the user forward vs. what obstructs exit)."

fogg_integration:
  feeds_from: [fogg-ability-auditor]
  feeds_to: [fogg-prompt-designer]
  shared_data: "Fogg's Ability dimension (is the behavior too hard?) and Brignull's sludge concept are isomorphic on exit paths. Fogg-ability-auditor measures ability gaps; sludge-auditor identifies whether those gaps are manufactured. A low-ability score on the cancellation path = candidate sludge instance for Brignull audit."
---

# Brignull Sludge Auditor

## LAYER 1: INVARIANTS (Never override.)

1. **Sludge is friction against user interest, not friction per se.** A confirmation prompt before irreversible deletion is not sludge. Friction on cancellation that exceeds friction on signup is sludge. The directional test: does this friction serve the user or only the business?
2. **The Disclosure Test is the bright line.** For every friction element: would a fully-informed user, hearing an accurate plain-language description of what this element does, still accept it? If no: it is manipulation, not persuasion. Remove or redesign.
3. **The Roach Motel rule is absolute.** Cancellation click-count must be <= signup click-count. Unsubscribe steps must be <= subscribe steps. Any asymmetry beyond one step requires explicit Disclosure Test justification or it is removed.
4. **Hidden costs are disclosed at first price display, not checkout.** If the final price a user sees exceeds the first price they saw by more than 10%, the page has a hidden cost pattern. Threshold: 10%.
5. **All preselected checkboxes/toggles for consequential consent are off by default.** "Consequential" = any communication, upsell, subscription, or data-sharing opt-in. Positive affirmative action required per consent.
6. **Fake scarcity/urgency is removed entirely.** A timer that resets on refresh is a lie. A stock count that does not reflect real inventory is a lie. No redesign — delete.
7. **Sludge on an exit path that is discovered and documented cannot be relabeled as "friction the user chose."** The Honesty Spectrum test: if the page is Transparent (full disclosure upfront), the user chose. If the page is in Omission or Deliberate Deception territory, the user was not given the information needed to choose.

## LAYER 2: QUALITY GUIDANCE

1. **Score before recommending.** Every sludge instance gets a Severity rating (Critical / High / Medium) before prescription. Critical = illegal or FTC-actionable (Roach Motel, hidden subscription). High = conversion manufactured by exploiting bias. Medium = friction reducible without legal risk.
2. **Show the asymmetry delta numerically.** "Cancel requires 6 steps; signup requires 2 steps. Delta: +4. Threshold: 0–1." Numbers, not adjectives.
3. **One pattern, one fix.** Each sludge finding pairs with exactly one concrete page change — copy rewrite, element removal, step elimination, or visual reweight. No omnibus recommendations.
4. **Pass/Fail every candidate through the Disclosure Test.** State the test outcome explicitly. "Disclosure Test: FAIL — informed user would refuse this flow."
5. **Cite the Mathur superordinate category and the specific Brignull pattern name for every finding.** Forces precision and makes the audit legally defensible.

## PURPOSE

Brignull defines sludge as "a high-friction, viscous experience that by its nature causes people to become fatigued and give up" — applied deliberately on paths the user wants to take (cancel, refund, unsubscribe, opt out). This skill audits a specific web page for every instance of manufactured exit friction, hidden cost, preselected consent, asymmetric path design, and obstruction, then produces a prioritized removal list with the Disclosure Test verdict for each.

**Cluster role:** This skill handles friction-against-user-interest (sludge, Roach Motel, obstruction, hidden costs, preselection). The sibling brignull-dark-pattern-scanner handles the full 16-pattern taxonomy at a broader scan level. Brignull-confirmshaming-detector handles shame-loaded copy specifically.

**Brag line (carry to a peer):** "We use the strongest levers known — and we know exactly where the line is."

## INPUT REQUIREMENTS

**Required:**
- The page: URL, screenshot, or written description of every interactive element and copy string on the page.
- The ONE desired action: what do you want the visitor to do? (e.g., "complete checkout," "start free trial," "submit lead form")

**Strongly recommended:**
- Exit path for this conversion (how does a user cancel, unsubscribe, or back out after taking the desired action?)
- Analytics: drop-off rates at each funnel step, refund/chargeback rate, support ticket volume for cancellation requests
- Funnel position (top-of-funnel opt-in vs. checkout vs. post-purchase upsell)

## EXECUTION PROCESS

### Step 1 — Inventory Every Friction-Capable Element (5 min)

List every element on the page that adds cost to a user action:
- Checkboxes, toggles, radio buttons (default state?)
- Price displays (first price shown vs. final price at checkout — compute delta %)
- Countdown timers, stock/scarcity messages
- Activity notifications ("X people viewing")
- Decline links, "no thanks" copy
- Social proof: review counts, testimonials, activity signals
- Required fields (number and type)
- Account creation gates before primary action

Tag each: Entry Path element (assists desired action) vs. Exit Path element (appears on cancellation/unsubscribe/opt-out).

### Step 2 — Roach Motel Asymmetry Score

Map the entry funnel click-count (from landing to confirmed desired action) vs. the exit funnel click-count (from confirmed conversion to full cancellation/unsubscribe/opt-out).

**Compute:**
- Entry clicks: [N]
- Exit clicks: [M]
- Asymmetry delta: M - N
- Threshold: delta <= 1 = Pass. Delta >= 2 = Sludge (Roach Motel). Delta >= 4 = Critical (FTC click-to-cancel rule risk).

Also check: does exit require phone/chat/email that entry does not? If yes: Critical regardless of click count.

### Step 3 — Hidden Cost Test

For each price displayed on the page:
- First price shown to user: $[A]
- Final price at checkout confirmation: $[B]
- Delta: (B - A) / A × 100 = [%]
- Threshold: > 10% = Hidden Cost pattern (Mathur: Sneaking > Hidden Costs).

Identify where the gap-closing disclosure appears. Below the fold, fine print, or checkout-only = Visual Interference + Sneaking.

### Step 4 — Preselection Scrub

For each checkbox, toggle, or radio button on the page:
- What does affirmative state (checked/on) opt the user into?
- Is the default affirmative without explicit user action? If yes: preselection pattern.
- Categorize: newsletter (Medium), upsell/add-on (High), subscription/auto-renewal (Critical), data-sharing (Critical).

### Step 5 — Scarcity/Urgency Truth Test

For each countdown timer and stock/scarcity message:
- Reload the page after 60 seconds. Does the timer reset? If yes: Fake Urgency (Critical).
- Does the stock count change in real time based on actual inventory? If unverifiable or static: Fake Scarcity (High).
- Is there a genuine business deadline or inventory constraint that corresponds to the claim? If yes: ethical. Document the constraint source.

### Step 6 — Disclosure Test on Every Surviving Element

For each element that passed Steps 2–5 as borderline (not clearly removed):

State aloud: "This element works by [mechanism]. If I told the user exactly that before they saw it, would they still complete the desired action?"

- If YES: Pass. Persuasion. Keep.
- If NO: Fail. Manipulation. Remove or redesign.

Document verdict for every element.

### Step 7 — Conti-Sobiesk Attack Vector Classification

Map each confirmed sludge instance to its axis (for the remediation prescription):
- **Coercion** — user forced into unwanted action to complete desired action (Forced Action pattern)
- **Confusion** — ambiguous syntax blocks informed decision (Trick Wording, double negatives)
- **Distraction** — attention pulled from critical information (Visual Interference)
- **Interruption** — task flow broken by unwanted interferences (Nagging)
- **Obfuscation** — important information hidden or disguised (Hidden Costs, Hidden Subscription)

Attack vector determines the fix type: Coercion → unbundle. Confusion → rewrite to affirmative plain language. Distraction/Obfuscation → visual reweight or move disclosure. Interruption → frequency cap or remove.

### Step 8 — Prioritized Removal List

Output a scored table. Severity: Critical (illegal/FTC-risk) → High (conversion manufactured by bias exploitation) → Medium (reducible friction).

Each row: Pattern name | Mathur category | Conti-Sobiesk axis | Severity | Disclosure Test | Fix

## OUTPUT STRUCTURE

**Section 1: Roach Motel Asymmetry Report**
Entry click-count vs. exit click-count, delta, verdict (Pass/Sludge/Critical).

**Section 2: Hidden Cost Delta**
First price vs. final price, %, verdict.

**Section 3: Preselection Inventory**
Table of all preselected elements, what they opt into, severity.

**Section 4: Scarcity/Urgency Truth Audit**
Each timer/message, reload test result, verdict.

**Section 5: Sludge Findings Table**

| # | Pattern | Mathur Cat | C-S Axis | Sev | Fix |
|---|---------|------------|----------|-----|-----|
| 1 | ... | ... | ... | ... | ... |

Legend: Mathur Cat = Mathur et al. 2019 superordinate category. C-S Axis = Conti-Sobiesk attack vector. Sev = Severity (Critical/High/Medium). Disclosure Test verdict stated per row in the Fix cell as Pass/Fail prefix.

**Section 6: Prioritized Fix List**
Ordered Critical → High → Medium. Each fix is one sentence: what to change, where, what replaces it.

**Section 7: Honesty Spectrum Position**
Map the page overall: Transparent / Omission / Deliberate Deception. Cite which element(s) determine the rating.

## WORKED MINI-EXAMPLE

**Page:** SaaS subscription landing page. Desired action: start free trial.

**Roach Motel:** Signup = 3 clicks (email, password, confirm). Cancel = 6 clicks + required retention chat. Delta: +3. Verdict: Sludge. FTC click-to-cancel risk. Fix: reduce cancel to 3 steps; remove mandatory chat.

**Hidden Cost:** Page shows "$19/mo." Checkout shows "$22.99 (after tax + $1.99 processing fee)." Delta: 21%. Verdict: Hidden Costs (Critical). Fix: display "$22.99/mo (incl. tax + fees)" on the landing page price display.

**Preselection:** Checkbox pre-checked: "Yes, enroll me in the Partner Program (billed $9.99/mo separately)." Verdict: Preselection (Critical) — Hidden Subscription. Fix: uncheck by default; require explicit opt-in with plain-language label.

**Fake Urgency:** "Offer expires in 14:32" — resets on page reload. Verdict: Fake Urgency (Critical). Fix: remove timer entirely.

**After fixes:** Conversion reflects genuine preference. Disclosure Test: all surviving elements pass — informed user would still complete free trial.

## OUTPUT FILE
Save to: [project-folder]/Brignull - Click Architecture/[YYYY-MM] - Sludge Audit - [Page Name].md
