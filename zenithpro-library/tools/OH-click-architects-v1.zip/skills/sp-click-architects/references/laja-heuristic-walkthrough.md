---
name: laja-heuristic-walkthrough
description: Use when a page needs an expert-eye audit before running tests — runs Laja's Four-Factor Heuristic Audit (Clarity / Relevance / Friction / Distraction) plus Conversion Formula scoring to surface the highest-leverage leaks without touching analytics or qualitative data.
version: 1.0.0
author: Strategic Profits / Click Architects Series
source_thinker: "Peep Laja (CXL Institute / ResearchXL 2014; Four-Factor Heuristic Audit 2013; Conversion Formula adopted from MarketingExperiments) — Click Architecture (Skill 3 of 7)"
interface:
  invoke: "/laja-heuristic-walkthrough"
  calls: []
  called_by: [user, laja-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Page copy, layout, and offer terms change frequently; heuristic findings against a page state are stale after 45 days or any redesign."

laja_researchxl_integration:
  feeds_from: laja-researchxl-diagnostic
  feeds_to: laja-pxl-prioritizer
  shared_data: "ResearchXL Spoke 1 (Heuristic) is THIS skill's output. The diagnostic identifies which spoke to run first; the prioritizer scores the resulting problem list for sequencing."

fogg_integration:
  feeds_from: fogg-field-intelligence
  feeds_to: laja-pxl-prioritizer
  shared_data: "Fogg's Motivation axis maps directly to Laja's M coefficient (4x weight in Conversion Formula). Where Fogg flags motivation deficit, Laja's Friction and Anxiety axes explain why the page fails to convert even motivated visitors."

kahneman_integration:
  feeds_from: kahneman-field-intelligence
  feeds_to: laja-clarity-over-persuasion-auditor
  shared_data: "System 1 processing speed governs the 5-second clarity test. Kahneman's fluency / anchoring findings explain WHY distraction and unclear hierarchy kill conversions before persuasion gets a chance."
---

# Laja Heuristic Walkthrough

## LAYER 1: INVARIANTS (Never override.)

1. **Heuristic Audit is ResearchXL Spoke 1 — not a substitute for the full model.** Findings here generate hypotheses; they are validated by Spokes 2-6 before permanent page changes.
2. **Rate every page element on ALL four axes** (Clarity, Relevance, Friction, Distraction). Skipping an axis because it "seems fine" is how obvious leaks stay hidden.
3. **The Conversion Formula governs lever priority.** C = 4M + 3V + 2(I-F) - 2A. Value proposition clarity (V, weight 3) is always addressed before friction (F) or incentive (I).
4. **Motivation (M) cannot be created by the page — only filtered.** Never recommend page changes to "create" motivation. Recommend changes to filter for already-motivated visitors and remove barriers for them.
5. **One most-wanted action (MWA) per page, maximum two.** Any audit finding that leaves more than two primary CTAs on a page is incomplete.
6. **Severity is on a 1-5 scale per axis.** 1 = minor polish. 5 = critical persuasion issue likely to drive measurable revenue shift. Only severity 4-5 items generate immediate test or fix recommendations.
7. **'Just-do-it' fixes are not tests.** Broken rendering, missing trust seals, form errors — fix them immediately. Reserve A/B test budget for genuine behavioral hypotheses.

## LAYER 2: QUALITY GUIDANCE

1. Produce a concrete severity score (1-5) for EVERY axis on EVERY page section audited — no "TBD" or "seems okay." If data is insufficient to score, say what would be needed.
2. Every audit finding must include a specific rewrite or removal recommendation — no finding without a prescribed on-page change.
3. Cross-check Relevance (scent) by quoting the actual pre-click source (ad/email/SERP snippet) and the actual above-fold headline. If the user has not provided the traffic source, request it before scoring Relevance.
4. Flag Distraction items by listing every clickable element on the page — count them, name them, and identify which are not the MWA.
5. Output the Conversion Formula diagnosis with approximate coefficient weighting so the user sees WHY the prioritization order is what it is.

## PURPOSE

This skill conducts Peep Laja's structured expert walkthrough of a specific web page — Spoke 1 of the ResearchXL Model — to surface the highest-leverage conversion leaks before any test is designed or any qualitative data is gathered.

**The lever:** Value proposition clarity. The Conversion Formula weights it at 3x (C = 4M + 3**V** + 2(I-F) - 2A). No amount of persuasion, urgency, or traffic improvement compounds if a visitor cannot answer "what is it, who is it for, and what do I do here" within 5 seconds. This walkthrough finds that breakdown and every secondary leak beneath it.

**Brag line:** "We find the real leak with 6 research lenses before we touch the page."

This skill covers Laja's Spoke 1 only. It does not run analytics (Spoke 3), qualitative surveys (Spoke 4), or mouse tracking (Spoke 6) — those are handled by sibling skills in the laja-* cluster. The output of this walkthrough feeds directly into laja-pxl-prioritizer for sequenced test planning.

## INPUT REQUIREMENTS

**Required:**
- The page — URL, screenshot, or written description of the live page
- The ONE desired action (MWA): e.g., "opt-in to lead magnet," "purchase $97 course," "book a demo call"

**Strongly recommended (needed to score Relevance):**
- The traffic source — the exact ad headline, email subject line, or SERP snippet that brought visitors to this page

**Optional (improves scoring depth):**
- Current conversion rate and device breakdown (desktop/mobile/tablet split)
- Funnel position (cold traffic landing page vs. warm retargeting vs. cart/checkout)
- Audience segment: B2B buyer role or B2C demographic
- Known drop-off data from analytics

## EXECUTION PROCESS

### Step 1: Orient — Define the MWA and Funnel Position (2 min)

State explicitly:
- What is the ONE most-wanted action on this page?
- Is this cold, warm, or hot traffic?
- What is the funnel stage? (awareness / consideration / decision / checkout)

Cold traffic pages have lower baseline motivation (M is smaller) — the Conversion Formula demands heavier investment in Clarity and Anxiety reduction. Checkout pages with <70% conversion rate signal major Anxiety or Friction even for high-motivation visitors.

### Step 2: 5-Second Clarity Test — Score Clarity Axis

Read ONLY the above-the-fold section. Answer these three questions as a first-time visitor:
1. What is this product/service?
2. Who exactly is it for?
3. What am I supposed to do here?

If all three are answerable in 5 seconds: Clarity score 1-2.
If one question is unclear: score 3.
If two or more questions are unanswerable: score 4-5.

**Threshold:** Score 4+ = fix the headline before any other work. Write the rewrite using Laja's B2B Message Layers test: does Layer 1 (product category), Layer 2 (prospect's pain), and Layer 3 (desired future state) each activate on first read?

**Four-question value proposition audit** (answer explicitly from page copy):
- How does this product help me?
- What specific results does it deliver?
- Who is it for exactly?
- Why this over the obvious alternatives?

Mark each unanswered question as a Clarity severity-4+ finding.

### Step 3: Relevance — Score Scent Continuity

Quote the pre-click source verbatim (ad headline, email subject, SERP title).
Quote the above-fold page headline verbatim.

Score Relevance 1-5:
- Same core language + same promise: score 1
- Similar language, promise slightly shifted: score 2-3
- Different vocabulary, promise implied rather than stated: score 4
- Completely different frame or offer: score 5

**Threshold:** Relevance 4+ = rewrite headline to mirror pre-click language exactly. This is a "just-do-it" fix — no test needed when scent is broken.

Note: If no traffic source was provided, score Relevance as "unknown — requires source" and flag for user to supply before finalizing.

### Step 4: Friction Inventory — Score Friction Axis

List every friction element on the page, section by section:
- Form fields (count them; standard threshold: >3 fields for cold traffic = friction severity 3+)
- Number of steps to complete the MWA
- Jargon or abstract language ("powerful," "seamless," "robust") — replace with concrete outcomes
- Premature sensitive data requests (credit card before value is demonstrated)
- Load-speed issues (use PageSpeed Insights if URL provided; <3s target on mobile)
- Confusing or generic CTA button text ("Submit," "Click Here")

Score overall Friction 1-5. Each severity-4+ friction item gets a specific removal or simplification recommendation.

**Worked threshold:** Cold traffic opt-in form asking for First Name + Last Name + Email + Phone + Company = 5 fields, severity 4. Recommendation: remove Last Name, Phone, Company. Keep First Name + Email only until they've demonstrated intent.

### Step 5: Distraction Audit — Score Distraction Axis

Enumerate every clickable element on the page (links, nav items, secondary CTAs, social icons, footer links). Count them. Name them.

Score Distraction 1-5:
- 1 CTA visible, no competing links: score 1
- 1 CTA + 1-2 non-competing nav items: score 2
- Multiple CTAs or competing navigation: score 3-4
- More choices than a homepage; multiple primary CTAs at same visual weight: score 5

**Threshold:** Distraction 4+ = remove or visually subordinate every non-MWA element. On a landing page: suppress or delete navigation entirely. On a product page: gray out or move footer links below the fold.

List each element and its disposition: KEEP / REMOVE / SUBORDINATE.

### Step 6: Anxiety Scan — Score Anxiety (Conversion Formula A term)

Anxiety has a -2A coefficient — reducing it is equal in leverage to reducing friction. Scan for:
- Presence and placement of trust signals (testimonials, logos, guarantees, security badges)
- Proximity of trust signals to the CTA (must be adjacent, not buried below)
- Privacy policy language near email capture fields
- Social proof specificity: named people + specific outcomes vs. generic star ratings
- For checkout: is pricing transparent? Are unexpected fees absent? Is forced account creation avoided?

Score Anxiety 1-5. Severity-4+ items get specific placement or content changes.

### Step 7: Conversion Formula Diagnosis

Synthesize scores into the formula:

C = 4M + 3V + 2(I-F) - 2A

| Term | Variable | Score (est.) | Weight | Contribution |
|------|----------|--------------|--------|--------------|
| Motivation | M | /5 | x4 | |
| Value Prop Clarity | V | /5 | x3 | |
| Incentive | I | /5 | x2 | |
| Friction | F | /5 (inverted) | x2 | |
| Anxiety | A | /5 (inverted) | x2 | |

Legend: M=Motivation, V=Value clarity, I=Incentive, F=Friction, A=Anxiety. Scores are directional (1=low problem, 5=severe problem). Inverted = lower score is better for F and A.

Identify the lowest-scoring term. That term — not the most-discussed item — drives the test roadmap.

### Step 8: Problem List — Ranked by Severity + Formula Weight

Output a prioritized problem list (not a tactics list):

| # | Problem | Axis | Sev | Formula Term | Recommended Fix |
|---|---------|------|-----|-------------|-----------------|
| 1 | ... | Clarity | 5 | V | Rewrite headline to answer all 4 VP questions |
| 2 | ... | Friction | 4 | F | Remove 3 form fields |

Legend: Axis = audit axis; Sev = severity 1-5; Formula Term = which conversion formula variable this affects.

Max 8 columns avoided by splitting findings into two tables if needed. Severity 4-5 items only in the primary table — 1-3 items go in a "polish list" section.

Hand this list to laja-pxl-prioritizer to score each item for test sequencing.

## OUTPUT STRUCTURE

**Section 1: Page + MWA Statement**
State what page was audited, the MWA, funnel position, and traffic source.

**Section 2: Four-Axis Heuristic Scores**
Clarity / Relevance / Friction / Distraction — score + evidence for each.

**Section 3: Anxiety Scan**
Trust signal audit + proximity findings.

**Section 4: Conversion Formula Diagnosis**
Table showing estimated scores per term and the dominant leak identified.

**Section 5: Prioritized Problem List**
Severity-4-5 items with specific on-page fixes. Polish list for severity 1-3.

**Section 6: Just-Do-It Fixes**
Items to implement without testing (broken elements, missing trust seals, clear scent breaks).

**Section 7: Handoff Notes for Sibling Skills**
- Hypotheses ready for laja-pxl-prioritizer scoring
- Open questions requiring laja-voice-of-customer-miner or laja-friction-telemetry-reader

## WORKED MINI-EXAMPLE

**Page:** SaaS landing page for a project management tool. MWA: start free trial.
**Traffic source:** Google ad: "Stop missing deadlines — try [Tool] free."
**Above-fold headline:** "The platform that transforms your workflow."

**Clarity (score: 4)**
"Transforms your workflow" is abstract. Visitor cannot answer "what is it" in 5 seconds.
Fix: "Stop missing deadlines — [Tool] keeps every project on track. Free 14-day trial."

**Relevance (score: 4)**
Ad says "stop missing deadlines." Page says "transforms your workflow." Scent broken.
Fix: Mirror ad language in headline. Same words, same promise.

**Friction (score: 3)**
Trial form: Name, Work Email, Company Size, Job Title, Phone. 5 fields for cold traffic.
Fix: Remove Company Size, Job Title, Phone. Name + Work Email only.

**Distraction (score: 3)**
Nav bar: Features / Pricing / Blog / About / Login + hero CTA + "Watch Demo" secondary CTA.
Fix: Suppress nav on landing page variant. Remove "Watch Demo" or subordinate below fold.

**Anxiety (score: 2)**
One logo strip present but no testimonials near CTA. "No credit card required" present — good.
Fix: Add one named testimonial with specific outcome adjacent to trial button.

**Conversion Formula:**
V is the dominant leak (headline clarity). Fix it first. Then address Friction (form fields). Then Distraction. The Anxiety improvement is polish (severity 2).

**Before CTA text:** "Get Started"
**After CTA text:** "Start My Free 14-Day Trial — No Credit Card"

## OUTPUT FILE

Save to: [project-folder]/Laja - Click Architecture/[YYYY-MM] - Heuristic Walkthrough - [Page Name].md
