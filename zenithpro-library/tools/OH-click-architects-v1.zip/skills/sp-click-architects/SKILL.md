---
name: sp-click-architects
description: >
  Click Architects — 12 web-conversion thinkers, 84 surgical tools, and a master
  orchestrator in one skill. Analyze any web page against Fitts, Hick, Pirolli,
  Nielsen, Norman, Gigerenzer, Eisenberg, Goward, Kohavi, Laja, Eyal, and Brignull.
  Run the full council or invoke a single thinker's tool. Trigger: "Use when optimizing
  a web page for a specific desired action — clicks, opt-ins, purchases, sign-ups."
version: 1.0.0
author: Strategic Profits / Click Architects Series
interface:
  invoke: ["/sp-click-architects", "/click-architects"]
  called_by: [user]
  outputs_to: [client-output-folder]
---

# Click Architects

One skill, 12 thinkers, 84 tools — every lever that makes a visitor click.

## How to invoke

**Full council** (runs all 12 thinkers on a page):
```
/sp-click-architects
/click-architects
```

**Single thinker's full read** (field intelligence):
```
/sp-click-architects fitts
/sp-click-architects pirolli
/sp-click-architects nielsen
```

**Specific tool**:
```
/sp-click-architects fitts-target-cost-auditor
/sp-click-architects hick-option-pruning-auditor
/sp-click-architects brignull-dark-pattern-scanner
```

---

## Command routing

When invoked, determine the mode from the argument:

### No argument → Full orchestrator
Read `references/orchestrator.md` and follow its complete execution process.
The orchestrator reads all 12 field-intelligence references during its run.

### Thinker shorthand → Field intelligence
If the argument is a bare thinker name, read the corresponding field-intelligence reference:

| Argument | Read |
|----------|------|
| `fitts` | `references/fitts-field-intelligence.md` |
| `hick` | `references/hick-field-intelligence.md` |
| `pirolli` | `references/pirolli-field-intelligence.md` |
| `nielsen` | `references/nielsen-field-intelligence.md` |
| `norman` | `references/norman-field-intelligence.md` |
| `gigerenzer` | `references/gigerenzer-field-intelligence.md` |
| `eisenberg` | `references/eisenberg-field-intelligence.md` |
| `goward` | `references/goward-field-intelligence.md` |
| `kohavi` | `references/kohavi-field-intelligence.md` |
| `laja` | `references/laja-field-intelligence.md` |
| `eyal` | `references/eyal-field-intelligence.md` |
| `brignull` | `references/brignull-field-intelligence.md` |

### Specific tool name → Single tool
If the argument matches a tool name, read `references/<tool-name>.md` and follow it.

---

## Available tools by thinker

### Fitts (Click & Choice Cost — G1)
| Tool | What it does |
|------|-------------|
| `fitts-field-intelligence` | Full Fitts analysis — synthesizes all 6 tools |
| `fitts-target-cost-auditor` | Scores every CTA by Fitts's Law ID = log₂(1 + D/W) |
| `fitts-click-path-minimizer` | Diagnoses cumulative motor cost across multi-step flows |
| `fitts-primary-action-dominance-scorer` | Tests whether the primary CTA dominates by size/position |
| `fitts-edge-magnet-designer` | Designs edge-anchored and sticky CTAs for zero-D targeting |
| `fitts-target-spacing-optimizer` | Fixes spacing to eliminate mis-click interference |
| `fitts-thumb-zone-mapper` | Maps mobile thumb-reach zones and scores CTA placement |

### Hick (Click & Choice Cost — G1)
| Tool | What it does |
|------|-------------|
| `hick-field-intelligence` | Full Hick analysis — synthesizes all 6 tools |
| `hick-decision-load-calculator` | Computes RT = b·log₂(n+1) for every decision point |
| `hick-option-pruning-auditor` | Identifies options to remove to cut decision time |
| `hick-categorization-architect` | Groups options into categories to reduce perceived count |
| `hick-progressive-disclosure-designer` | Sequences choices across steps to avoid overload |
| `hick-single-decision-enforcer` | Ensures each screen presents exactly one decision |
| `hick-default-path-designer` | Designs smart defaults that pre-select the optimal path |

### Pirolli (Information Scent — G2)
| Tool | What it does |
|------|-------------|
| `pirolli-field-intelligence` | Full Pirolli analysis — synthesizes all 6 tools |
| `pirolli-scent-trail-auditor` | Audits scent continuity from traffic source through page |
| `pirolli-link-diagnosticity-scorer` | Scores each link's predictive value for what's behind it |
| `pirolli-patch-abandonment-predictor` | Predicts where visitors will leave based on diminishing returns |
| `pirolli-foraging-cost-reducer` | Reduces within-page cost of finding the desired information |
| `pirolli-scent-gradient-designer` | Designs increasing-scent paths toward the desired action |
| `pirolli-information-diet-mapper` | Maps the information diet visitors need before committing |

### Nielsen (Attention & Perception — G3)
| Tool | What it does |
|------|-------------|
| `nielsen-field-intelligence` | Full Nielsen analysis — synthesizes all 6 tools |
| `nielsen-heuristic-evaluation` | Runs the 10 usability heuristics on the page |
| `nielsen-f-pattern-layout-auditor` | Audits whether key content follows the F-pattern scan |
| `nielsen-banner-blindness-detector` | Identifies elements users will skip due to ad-like appearance |
| `nielsen-attention-zone-placer` | Places CTAs in empirically validated attention hotspots |
| `nielsen-scannability-optimizer` | Optimizes headings, bullets, and whitespace for scan reading |
| `nielsen-hallway-test-designer` | Designs quick usability tests for the page |

### Norman (Affordance & Friction — G4)
| Tool | What it does |
|------|-------------|
| `norman-field-intelligence` | Full Norman analysis — synthesizes all 6 tools |
| `norman-affordance-signifier-auditor` | Audits whether every interactive element looks clickable |
| `norman-gulf-of-execution-reducer` | Reduces the gap between intent and available actions |
| `norman-gulf-of-evaluation-reducer` | Reduces the gap between action taken and feedback received |
| `norman-mapping-auditor` | Checks that controls map naturally to their effects |
| `norman-feedback-state-designer` | Designs immediate feedback for every user action |
| `norman-error-recovery-architect` | Designs error states that guide users back to the happy path |

### Gigerenzer (Cognitive Fit — G5)
| Tool | What it does |
|------|-------------|
| `gigerenzer-field-intelligence` | Full Gigerenzer analysis — synthesizes all 6 tools |
| `gigerenzer-heuristic-fit-designer` | Matches page structure to the visitor's dominant heuristic |
| `gigerenzer-take-the-best-sequencer` | Orders cues by validity so the stopping rule fires early |
| `gigerenzer-recognition-cue-architect` | Designs recognition-based trust signals |
| `gigerenzer-less-is-more-auditor` | Identifies what to remove so heuristics work better |
| `gigerenzer-single-cue-spotlighter` | Highlights the one cue that should dominate the decision |
| `gigerenzer-risk-literacy-reframer` | Converts probability framing to natural frequency format |

### Eisenberg (Persuasion Architecture — G6)
| Tool | What it does |
|------|-------------|
| `eisenberg-field-intelligence` | Full Eisenberg analysis — synthesizes all 6 tools |
| `eisenberg-persona-pathway-mapper` | Maps navigation paths by buying modality |
| `eisenberg-scent-continuity-auditor` | Audits ad-to-page scent continuity |
| `eisenberg-landing-anatomy-architect` | Structures landing page zones for persuasion flow |
| `eisenberg-buying-modality-classifier` | Classifies traffic by competitive/spontaneous/methodical/humanistic |
| `eisenberg-conversion-trinity-builder` | Builds the Relevance → Value → CTA trinity |
| `eisenberg-micro-action-sequencer` | Sequences micro-commitments toward the desired action |

### Goward (Persuasion Architecture — G6)
| Tool | What it does |
|------|-------------|
| `goward-field-intelligence` | Full Goward/LIFT analysis — synthesizes all 6 tools |
| `goward-lift-scorer` | Scores page on 6 LIFT factors |
| `goward-value-prop-fulcrum-auditor` | Audits value proposition clarity and differentiation |
| `goward-clarity-relevance-optimizer` | Optimizes clarity and relevance of page messaging |
| `goward-anxiety-distraction-reducer` | Identifies and removes anxiety triggers and distractions |
| `goward-urgency-architect` | Designs genuine urgency (not manufactured scarcity) |
| `goward-hypothesis-generator` | Generates testable hypotheses from LIFT diagnosis |

### Kohavi (Experimentation Rigor — G7)
| Tool | What it does |
|------|-------------|
| `kohavi-field-intelligence` | Full Kohavi analysis — synthesizes all 6 tools |
| `kohavi-oec-definer` | Defines the Overall Evaluation Criterion for tests |
| `kohavi-experiment-validity-auditor` | Audits running experiments for validity threats |
| `kohavi-srm-guard` | Checks for Sample Ratio Mismatch in test data |
| `kohavi-twyman-anomaly-detector` | Flags too-good-to-be-true results |
| `kohavi-test-prioritization-designer` | Prioritizes the test queue by expected impact |
| `kohavi-rollout-decision-architect` | Designs rollout decisions from test results |

### Laja (Experimentation Rigor — G7)
| Tool | What it does |
|------|-------------|
| `laja-field-intelligence` | Full Laja/ResearchXL analysis — synthesizes all 6 tools |
| `laja-researchxl-diagnostic` | Runs the 6-spoke ResearchXL framework on the page |
| `laja-pxl-prioritizer` | Scores and ranks optimization hypotheses by PXL |
| `laja-heuristic-walkthrough` | Walks through the page as a first-time visitor |
| `laja-voice-of-customer-miner` | Mines VoC data for conversion-relevant language |
| `laja-friction-telemetry-reader` | Reads friction signals from analytics/recordings |
| `laja-clarity-over-persuasion-auditor` | Audits whether the page over-persuades at the expense of clarity |

### Eyal (Habit & Reward Loops — G8)
| Tool | What it does |
|------|-------------|
| `eyal-field-intelligence` | Full Eyal/Hook Model analysis — synthesizes all 6 tools |
| `eyal-hook-loop-designer` | Designs the Trigger → Action → Reward → Investment loop |
| `eyal-trigger-architect` | Designs external and internal triggers |
| `eyal-variable-reward-designer` | Designs variable-ratio reward schedules |
| `eyal-investment-escalator` | Designs investment escalation that increases switching cost |
| `eyal-habit-zone-tester` | Tests whether the product is in the Habit Zone |
| `eyal-manipulation-matrix-guard` | Ethical guard — classifies tactics on the Manipulation Matrix |

### Brignull (Ethics Boundary — G9)
| Tool | What it does |
|------|-------------|
| `brignull-field-intelligence` | Full Brignull analysis — synthesizes all 6 tools |
| `brignull-dark-pattern-scanner` | Scans for all 16 named dark patterns |
| `brignull-sludge-auditor` | Audits exit friction and hidden costs |
| `brignull-confirmshaming-detector` | Detects shame-loaded decline copy |
| `brignull-consent-integrity-checker` | Audits opt-in mechanisms for deceptive consent |
| `brignull-ethical-line-mapper` | Maps exactly where persuasion becomes manipulation |
| `brignull-fair-pattern-designer` | Designs ethical alternatives to flagged patterns |

---

## 9 mechanism groups

| Group | Name | Thinkers |
|-------|------|----------|
| G1 | Click & Choice Cost | Fitts, Hick |
| G2 | Information Scent & Foraging | Pirolli |
| G3 | Attention & Perception Topography | Nielsen |
| G4 | Affordance & Friction Legibility | Norman |
| G5 | Cognitive Fit & Heuristics | Gigerenzer |
| G6 | Persuasion Architecture & Page Anatomy | Eisenberg, Goward |
| G7 | Experimentation Rigor (Proof) | Kohavi, Laja |
| G8 | Habit & Reward Loops | Eyal |
| G9 | Ethics & Dark-Pattern Boundary | Brignull |

---

## Input (same for all modes)

**Required:**
- The page: URL (preferred), screenshot, or detailed written description
- The desired action: ONE specific action (e.g., "click the opt-in button," "add to cart," "start free trial")

**Optional:** Current conversion rate, traffic source, funnel position, heatmap data.

*Built by Strategic Profits · Click Architects Series · v1*
