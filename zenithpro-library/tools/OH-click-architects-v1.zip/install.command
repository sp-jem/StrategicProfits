#!/bin/bash
# Double-click this file on a Mac to install (it just runs install.sh).
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
bash "$DIR/install.sh"
echo ""
read -p "  Press Return to close this window."
