#!/bin/bash
# ============================================================
#  Click Architects — Skill Pack Installer (Mac / Linux)
#  Installs 85 page-conversion skills into your Claude Code.
#  Safe: it NEVER overwrites a skill you already have.
# ============================================================
set -u

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$DIR/skills"
DEST="$HOME/.claude/skills"

echo ""
echo "  Click Architects — installing into: $DEST"
echo "  ----------------------------------------------------"

if [ ! -d "$SRC" ]; then
  echo "  ERROR: could not find the 'skills' folder next to this installer."
  echo "  Make sure you unzipped the whole package before running."
  exit 1
fi

mkdir -p "$DEST"

installed=0
skipped=0
for d in "$SRC"/*/; do
  [ -d "$d" ] || continue
  name="$(basename "$d")"
  if [ -e "$DEST/$name" ]; then
    echo "  • skip (already have it): $name"
    skipped=$((skipped+1))
  else
    cp -R "$d" "$DEST/$name"
    echo "  ✓ installed: $name"
    installed=$((installed+1))
  fi
done

echo "  ----------------------------------------------------"
echo "  Done.  Installed: $installed   Skipped (already present): $skipped"
echo ""
echo "  ➜  Restart Claude Code, then type:  /click-architects"
echo "     (or run any single skill, e.g. /fitts-target-cost-auditor)"
echo ""
