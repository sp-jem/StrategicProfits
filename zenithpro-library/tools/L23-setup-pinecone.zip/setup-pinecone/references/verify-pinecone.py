#!/usr/bin/env python3
"""
Pinecone Verification Script
Validates: connection, index existence, stats, and integrated inference round-trip.
"""

import os
import sys
import time

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_api_key():
    """Load the Pinecone API key from environment or credentials file."""
    key = os.environ.get("PINECONE_API_KEY")
    if key:
        return key

    cred_path = os.path.expanduser("~/.claude/credentials/pinecone.env")
    if os.path.exists(cred_path):
        with open(cred_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith("PINECONE_API_KEY="):
                    return line.split("=", 1)[1].strip().strip("'\"")

    return None


def log_pass(msg):
    print(f"[PASS] {msg}")


def log_fail(msg):
    print(f"[FAIL] {msg}")


def log_info(msg):
    print(f"[INFO] {msg}")


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------

def check_connection(api_key):
    """Attempt to connect and list indexes."""
    from pinecone import Pinecone

    pc = Pinecone(api_key=api_key)
    indexes = pc.list_indexes()
    log_pass("Connected to Pinecone")
    return pc, [idx.name for idx in indexes]


def check_index_exists(index_names, target="business-operations"):
    """Confirm the target index is in the list."""
    if target in index_names:
        log_pass(f"Index '{target}' exists")
        return True
    else:
        log_fail(f"Index '{target}' not found. Available indexes: {index_names}")
        return False


def check_stats(pc, index_name="business-operations"):
    """Fetch and display index stats."""
    index = pc.Index(index_name)
    stats = index.describe_index_stats()
    log_info(f"Total vectors: {stats.total_vector_count}")
    ns = list(stats.namespaces.keys()) if stats.namespaces else []
    log_info(f"Namespaces: {ns if ns else '(none yet)'}")
    return index


def check_integrated_inference(pc, index_name="business-operations"):
    """
    Round-trip test: embed a string, upsert, query, then delete.
    Uses Pinecone integrated inference with llama-text-embed-v2.
    """
    index = pc.Index(index_name)
    test_namespace = "_verification_test"
    test_id = "verify-pinecone-test-vector"
    test_text = "This is a verification test for the Pinecone setup skill."

    # --- Embed ---
    try:
        embedding_response = pc.inference.embed(
            model="llama-text-embed-v2",
            inputs=[test_text],
            parameters={"input_type": "passage", "truncate": "END"},
        )
        vector = embedding_response.data[0].values
        log_pass("Test embed + upsert succeeded")
    except Exception as e:
        log_fail(f"Embedding failed: {e}")
        return False

    # --- Upsert ---
    try:
        index.upsert(
            vectors=[{"id": test_id, "values": vector}],
            namespace=test_namespace,
        )
    except Exception as e:
        log_fail(f"Upsert failed: {e}")
        return False

    # --- Wait for upsert to be queryable ---
    time.sleep(2)

    # --- Query ---
    try:
        query_embedding = pc.inference.embed(
            model="llama-text-embed-v2",
            inputs=[test_text],
            parameters={"input_type": "query", "truncate": "END"},
        )
        query_vector = query_embedding.data[0].values

        results = index.query(
            vector=query_vector,
            namespace=test_namespace,
            top_k=1,
            include_values=False,
        )

        if results.matches and results.matches[0].id == test_id:
            log_pass("Test query returned expected result")
        else:
            log_fail(f"Test query did not return expected vector. Got: {results.matches}")
            # Still try to clean up
    except Exception as e:
        log_fail(f"Query failed: {e}")
        # Still try to clean up

    # --- Cleanup ---
    try:
        index.delete(ids=[test_id], namespace=test_namespace)
        log_pass("Test vector cleaned up")
    except Exception as e:
        log_fail(f"Cleanup failed (non-critical): {e}")

    return True


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    failures = 0

    # Load key
    api_key = load_api_key()
    if not api_key:
        log_fail("No API key found. Set PINECONE_API_KEY or create ~/.claude/credentials/pinecone.env")
        sys.exit(1)

    # Import checks
    try:
        import pinecone  # noqa: F401
    except ImportError:
        log_fail("pinecone package not installed. Run: pip3 install pinecone")
        sys.exit(1)

    try:
        import dotenv  # noqa: F401
    except ImportError:
        log_fail("python-dotenv package not installed. Run: pip3 install python-dotenv")
        sys.exit(1)

    # Connection
    try:
        pc, index_names = check_connection(api_key)
    except Exception as e:
        log_fail(f"Connection failed: {e}")
        sys.exit(1)

    # Index existence
    if not check_index_exists(index_names):
        failures += 1
        print(f"\n--- {failures} CHECK(S) FAILED ---")
        sys.exit(1)

    # Stats
    try:
        check_stats(pc)
    except Exception as e:
        log_fail(f"Could not retrieve stats: {e}")
        failures += 1

    # Integrated inference round-trip
    try:
        if not check_integrated_inference(pc):
            failures += 1
    except Exception as e:
        log_fail(f"Integrated inference test failed: {e}")
        failures += 1

    # Summary
    print()
    if failures == 0:
        print("--- ALL CHECKS PASSED ---")
    else:
        print(f"--- {failures} CHECK(S) FAILED ---")
        sys.exit(1)


if __name__ == "__main__":
    main()
