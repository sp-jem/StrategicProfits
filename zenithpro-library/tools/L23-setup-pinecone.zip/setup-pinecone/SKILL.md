---
name: setup-pinecone
description: Guides Force Multiplier participants through setting up Pinecone vector database for their intelligence engine. Creates the account, configures API key, creates the index, and verifies the connection.
version: 1.1.0
tags: [setup, infrastructure, vector-database, intelligence-engine, force-multiplier]
---

# Setup Pinecone

## Purpose

This skill configures Pinecone as the vector database for your intelligence engine. It is designed for **Force Multiplier participants** who need a working vector store before their brain pipeline can operate.

**Problem it solves:** Without a properly configured Pinecone index, the intelligence engine has nowhere to store or retrieve embeddings. Every downstream capability (semantic search, daily briefings, feedback processing) depends on this setup being correct.

**What "done" looks like:**
- API key stored securely at `~/.claude/credentials/pinecone.env` with 600 permissions
- `business-operations` index live on Pinecone (1024 dimensions, cosine metric, AWS us-east-1)
- Verification script passes all checks (connection, index existence, inference round-trip)
- Zero test vectors left behind after verification

**Non-goals:**
- This skill does NOT populate the index with data (that is the bulk-seeding skill)
- This skill does NOT configure the brain pipeline (that is a separate setup skill)
- This skill does NOT handle Pinecone billing or plan upgrades

---

## Invariant Rules

These rules apply at ALL times during setup. Every rule names its consequence.

- **NEVER display the full API key** after it has been stored. Reference it as `$PINECONE_API_KEY` or show only the first 8 characters followed by `...`. *Consequence: Full key exposure in terminal history creates a credential leak that persists in shell logs.*
- **NEVER commit `pinecone.env` to git.** The `~/.claude/credentials/` directory MUST be in your global `.gitignore`. *Consequence: Committed credentials are visible to anyone with repo access and persist in git history even after deletion.*
- **NEVER hard-code the API key** in scripts or notebooks. Always load from the env file. *Consequence: Hard-coded keys break portability -- the script fails on any other machine and the key is exposed in source files.*
- **Do NOT delete the `business-operations` index** unless you are intentionally resetting your vector store. *Consequence: All embedded data is permanently lost. Re-embedding from scratch takes hours and costs inference credits.*
- **Do NOT modify the index dimensions or metric** after creation. Pinecone indexes are immutable on these settings. *Consequence: Dimension mismatch causes every upsert and query to fail silently or throw 400 errors. The only fix is delete and recreate, losing all data.*
- **Free tier limits:** 1 index, 5 GB, 100K vectors. Monitor usage in the Pinecone console under **Usage**. *Consequence: Exceeding limits returns 429/ResourceExhausted errors that block your entire pipeline with no warning.*

---

## Identity

You are a **setup assistant** guiding a Force Multiplier participant through infrastructure configuration. You execute each step precisely, verify the result before proceeding, and stop immediately if any step fails. You are NOT a general Pinecone consultant -- you configure exactly the setup described here and nothing else.

---

## Step 1: Check for Existing Configuration

Before doing anything, check if Pinecone is already configured:

```bash
if [ -f ~/.claude/credentials/pinecone.env ]; then
  echo "Pinecone credentials found at ~/.claude/credentials/pinecone.env"
  source ~/.claude/credentials/pinecone.env
  echo "API Key: ${PINECONE_API_KEY:0:8}..."
else
  echo "No Pinecone credentials found. Proceeding with setup."
fi
```

If credentials exist and the index is live, skip to **Step 8** to verify.

---

## Step 2: Create Pinecone Account

1. Go to **https://www.pinecone.io** and click **Sign Up Free**
2. Sign up with Google, GitHub, or email
3. You MUST select the **Starter (Free)** plan -- it includes:
   - 1 project
   - 5 GB storage
   - Integrated inference (embedding models hosted by Pinecone)
   - No credit card required
4. Complete email verification if prompted

**Checkpoint:** Confirm you can see the Pinecone dashboard (the console home page with "Indexes" in the left sidebar). Tell Claude: **"My Pinecone account is ready."** Do NOT proceed until this is confirmed.

---

## Step 3: Get Your API Key

1. In the Pinecone console, click **API Keys** in the left sidebar
2. A default key is created automatically with new accounts. If no key exists, click **Create API Key**
3. Copy the full API key value -- you will need the complete string

**Checkpoint:** Paste your API key when prompted. Claude MUST store it immediately (Step 4) and MUST NOT display it again after storage. Do NOT proceed to Step 5 until the key is stored and verified.

---

## Step 4: Store Credentials

Claude will store your key at `~/.claude/credentials/pinecone.env` with restricted permissions:

```bash
mkdir -p ~/.claude/credentials
cat > ~/.claude/credentials/pinecone.env << 'ENVEOF'
PINECONE_API_KEY=your-key-here
ENVEOF
chmod 600 ~/.claude/credentials/pinecone.env
```

After this step, the API key is referenced only by variable -- never displayed in plaintext.

---

## Step 5: Install Required Python Packages

Check if packages are installed, and install them if not. Both `pinecone` and `python-dotenv` are required:

```bash
pip3 show pinecone 2>/dev/null && echo "pinecone already installed" || pip3 install pinecone
pip3 show python-dotenv 2>/dev/null && echo "python-dotenv already installed" || pip3 install python-dotenv
```

Verify the installs:

```bash
python3 -c "import pinecone; print(f'pinecone {pinecone.__version__} installed')"
python3 -c "import dotenv; print('python-dotenv installed')"
```

**Validation gate:** Both import statements MUST succeed. If either fails, do NOT proceed to Step 6. Re-run the install command for the failing package.

---

## Step 6: Create the Index

Create the `business-operations` index. These parameters are NOT negotiable -- the intelligence engine pipeline depends on this exact configuration:

- **Index name:** `business-operations` (MUST match exactly)
- **Dimensions:** 1024 (matches `llama-text-embed-v2` output)
- **Metric:** cosine
- **Infrastructure:** serverless, AWS us-east-1

```python
import os
from pinecone import Pinecone
from dotenv import load_dotenv

# Load API key
api_key = os.environ.get("PINECONE_API_KEY")
if not api_key:
    load_dotenv(os.path.expanduser("~/.claude/credentials/pinecone.env"))
    api_key = os.environ.get("PINECONE_API_KEY")

if not api_key:
    raise RuntimeError("PINECONE_API_KEY not found. Re-run Step 4.")

pc = Pinecone(api_key=api_key)

index_name = "business-operations"

# Check if index already exists
existing = [idx.name for idx in pc.list_indexes()]
if index_name in existing:
    print(f"Index '{index_name}' already exists. Skipping creation.")
else:
    print(f"Creating index '{index_name}'...")
    pc.create_index(
        name=index_name,
        dimension=1024,
        metric="cosine",
        spec={
            "serverless": {
                "cloud": "aws",
                "region": "us-east-1"
            }
        }
    )
    print(f"Index '{index_name}' created successfully.")

# Connect and print status
index = pc.Index(index_name)
stats = index.describe_index_stats()
print(f"Total vectors: {stats.total_vector_count}")
print(f"Namespaces: {list(stats.namespaces.keys()) if stats.namespaces else '(empty)'}")
```

**Checkpoint:** The script MUST print "Index 'business-operations' already exists" or "created successfully" followed by "Total vectors: 0". If it throws any error, do NOT proceed. Consult the error table in Step 9.

---

## Step 7: Understand the Namespaces

The `business-operations` index uses 7 namespaces to organize your data:

| Namespace | Purpose | Population Method |
|-----------|---------|-------------------|
| `journals` | Daily journals and reflections | Bulk-seeded from vault |
| `psychology` | Psychological profiles, avatar data | Bulk-seeded from vault |
| `brand-dna` | Brand identity, voice, positioning | Bulk-seeded from vault |
| `core-context` | Business context, mission, strategy | Bulk-seeded from vault |
| `brain-daily` | Daily intelligence briefings | Auto-populated by brain pipeline |
| `feedback` | Customer feedback, call notes, Q&A | Auto-populated by brain pipeline |
| `stories` | Stories, case studies, testimonials | Auto-populated by brain pipeline |

**Namespaces 1-4** (`journals`, `psychology`, `brand-dna`, `core-context`) are **bulk-seeded** during initial setup. You will run a one-time ingestion from your Obsidian vault to populate these with your existing content.

**Namespaces 5-7** (`brain-daily`, `feedback`, `stories`) are **auto-populated** by your brain pipeline during daily operation. As new briefings are generated, calls are processed, and stories are captured, they flow into these namespaces automatically.

You do not need to create namespaces manually. Pinecone creates them on first upsert.

---

## Step 8: Verify the Connection

This is the final validation gate. The verification script MUST pass ALL checks before setup is considered complete.

Run the standalone verification script:

```bash
source ~/.claude/credentials/pinecone.env && python3 ~/.claude/skills/setup-pinecone/references/verify-pinecone.py
```

Or, if running from the curriculum copy:

```bash
source ~/.claude/credentials/pinecone.env && python3 "$(dirname "$0")/references/verify-pinecone.py"
```

The script performs 5 checks:
1. Connect to Pinecone using your stored API key
2. Confirm `business-operations` index exists
3. Get index stats (vector count, namespace list)
4. Run a test embed/upsert/query/delete cycle using integrated inference
5. Clean up test vectors

**Expected output for a fresh install:**

```
[PASS] Connected to Pinecone
[PASS] Index 'business-operations' exists
[INFO] Total vectors: 0
[INFO] Namespaces: (none yet)
[PASS] Test embed + upsert succeeded
[PASS] Test query returned expected result
[PASS] Test vector cleaned up
--- ALL CHECKS PASSED ---
```

**This step is non-negotiable.** If ANY check shows `[FAIL]`, the setup is NOT complete. Consult the error table in Step 9, fix the issue, and re-run verification. Do NOT tell the participant that setup is done until `--- ALL CHECKS PASSED ---` appears.

---

## Step 9: Error Handling

| Error | Cause | Fix |
|-------|-------|-----|
| `ApiKeyError` / `401 Unauthorized` | Invalid or missing API key | Re-check key in `~/.claude/credentials/pinecone.env` |
| `NotFoundException` / `Index not found` | Index does not exist | Re-run Step 6 to create it |
| `ForbiddenException` | Free plan limit reached | Delete unused indexes in the Pinecone console |
| `ServiceException` / `503` | Pinecone service is temporarily down | Wait 2-3 minutes and retry |
| `PineconeApiException: already exists` | Index creation attempted twice | Safe to ignore -- the script handles this |
| `ModuleNotFoundError: pinecone` | Python package not installed | Run `pip3 install pinecone` |
| `ConnectionError` / `Timeout` | Network issue or firewall | Check internet connection; Pinecone uses HTTPS on port 443 |
| `ResourceExhausted` | Too many requests on free plan | Wait 60 seconds and retry |

---

## Completion Criteria

Setup is COMPLETE when ALL of the following are true:

1. `~/.claude/credentials/pinecone.env` exists with permissions `600`
2. `business-operations` index is live on Pinecone (1024 dims, cosine, AWS us-east-1)
3. Verification script outputs `--- ALL CHECKS PASSED ---`
4. `pinecone` and `python-dotenv` Python packages are installed

If any of these are not true, setup is NOT complete. Identify which step failed and re-run from that step.

---

## Dependencies

| Dependency | Required? | Install |
|------------|-----------|---------|
| Python 3.8+ | YES | Pre-installed on macOS; `brew install python` otherwise |
| `pinecone` (Python) | YES | `pip3 install pinecone` |
| `python-dotenv` (Python) | YES | `pip3 install python-dotenv` |
| Pinecone account | YES | Free at https://www.pinecone.io |
| Internet connection | YES | HTTPS on port 443 to Pinecone API |
