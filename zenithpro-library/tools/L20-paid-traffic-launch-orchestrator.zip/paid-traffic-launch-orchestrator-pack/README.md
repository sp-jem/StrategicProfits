# Paid Traffic Launch Orchestrator — Install Pack
**Version:** 1.0.0 | **Program:** ZenithPro | **Certified:** 2026-03-26

---

## What This Is

End-to-end paid traffic launch orchestrator for students who already have their offer and funnel built. Takes them from "I have my offer" to "my ads are ready to launch" — covering audience research, Meta ad copy + creative, YouTube ad scripts + creative, optional video production, optional campaign setup, and a clean organized asset folder with a plain-English launch brief.

**Persona:** Kai Torres — paid traffic specialist who audits what exists before building anything.

---

## What's Included

| File | Purpose |
|------|---------|
| `paid-traffic-launch-orchestrator/SKILL.md` | The full orchestrator skill |

---

## Install Instructions

1. Copy the `paid-traffic-launch-orchestrator/` folder into your `.claude/skills/` directory
2. Restart Claude Code (or reload skills)
3. Trigger with: `/paid-traffic-launch-orchestrator` or "run paid traffic to my offer"

**Install path:**
```
~/.claude/skills/paid-traffic-launch-orchestrator/SKILL.md
```

---

## Trigger Phrases

- `/paid-traffic-launch-orchestrator`
- "run paid traffic to my offer"
- "launch my ads"
- "I have my funnel built and need traffic"
- "create Facebook ads for my offer"
- "create YouTube ads for my offer"
- "I already have my offer and need ads"
- "build my ad creative"

---

## What It Covers

**Pre-Flight:** Asset audit (find what exists), platform selection (Meta/YouTube/both), Voice DNA extraction, landing page review, proof inventory

**Phase 1:** Audience & Angles — pains/hopes/gap analysis, S/A/B/C tier angle rankings, test plan

**Phase 2:** Meta Ad Copy — 5-8 variations (feed, story, reel formats), Critic Gate (carlton-critic + truth-critic)

**Phase 3:** Meta Ad Creative — founder ad formula, hook taxonomy, static images, optional video production, Critic Gate (nick-shackelford-thumbstop-audit)

**Phase 4:** YouTube Ad Scripts — skippable + non-skippable + hook variations, Critic Gate (youtube-ad-script-critic + truth-critic)

**Phase 5:** YouTube Creative Production — optional (HeyGen talking head or Veo3 cinematic) or scripts + production brief only

**Phase 6:** Campaign Setup — optional Meta (Charley T Andromeda) or YouTube campaign structure

**Final Output:** Organized asset folder + plain-English launch brief

---

## Certification

- Adversarial Testing: 19 scenarios — PASS ✓
- Skill-grader: 4.45/5.0 — PASS ✓
- Prompt-architect: 0.602 constraint ratio, GOOD rating — CERTIFIED ✓
