# Demand Architect

A 9-step AI pipeline that produces market positioning so differentiated it cannot be replicated — because it is simultaneously built from the deepest psychological architecture of your prospect AND mapped against what every competitor already owns.

---

## What This Does For You

Most positioning work fails in one of two ways. Either you build something psychographically perfect — deeply resonant with how your market thinks and feels — but it lands in territory three competitors already occupy with identical messaging. Or you find genuinely open competitive ground — something no one else is saying — but it doesn't move your prospect because it doesn't connect to anything they actually want.

Demand Architect solves both problems at once. It runs 9 specialized AI skills in sequence, weaving René Girard's mimetic desire theory through every step as a competitive filter. By the time it's done, you have three documents: a Strategic Desire Map, a Demand Architecture Brief, and an Anti-Mimetic Positioning Statement — all cross-referenced and integrated into a single strategic picture.

The result is positioning that is psychologically true AND competitively uncontested. Not because you tried to be different. Because you mapped what every competitor mediates, and built around what they cannot own.

---

## What's Included

This package installs 10 skills into Claude Code:

| Skill | Role |
|-------|------|
| **demand-architect** | The orchestrator — runs all 9 steps in sequence |
| demand-desire-mapper | Maps the L1–L4 desire hierarchy of your market |
| psychographic-excavation | 14-phase deep psychological archaeology |
| avatar-excavation | 3–5 distinct avatar segments with shadow psychology |
| failure-pattern-forensics | Why your market keeps failing despite trying |
| core-concept-generator | 5 paradigm-shifting belief reframes |
| ideal-buying-mindset | The exact mental state required for purchase |
| belief-gap-analyzer | Every belief gap between Point A and Point B |
| usp-generator | Breakthrough USP from features to market position |
| mimetic-market-intelligence | Girard's theory applied to competitive desire mapping |

---

## How It Works

See `how-it-works.md` for visual diagrams. In plain English:

1. Live competitive research maps what every competitor already "owns" in the desire space
2. Deep psychological excavation reveals what your market actually wants — including what they'd never say publicly
3. Each step's findings filter through the competitive map — ensuring no insight lands on occupied territory
4. Three synthesis documents integrate everything into actionable positioning

---

## Requirements

- **Claude Code** installed (`claude` CLI available)
- **Web research access** in Claude Code (required for Step 1 — live competitive research)
- No API keys required beyond what Claude Code already uses

---

## Installation

### Mac / Linux (Terminal)

```bash
cd ~/Downloads/Demand-Architect
chmod +x install.sh
./install.sh
```

### Windows (PowerShell — run as Administrator)

```powershell
cd ~/Downloads/Demand-Architect
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\install.ps1
```

---

## What Gets Installed

All 10 skills are copied to `~/.claude/skills/`:

```
~/.claude/skills/
├── demand-architect/
├── demand-desire-mapper/
├── psychographic-excavation/
├── avatar-excavation/
├── failure-pattern-forensics/
├── core-concept-generator/
├── ideal-buying-mindset/
├── belief-gap-analyzer/
├── usp-generator/
└── mimetic-market-intelligence/
```

---

## How to Use

### Full Pipeline (recommended for new markets)

```
/demand-architect full [your market or business description]
```

Example:
```
/demand-architect full online business coaching for service providers
```

Runs all 9 steps in sequence. Produces 12+ linked documents. Takes significant time — this is deep work.

### Quick Mode (when you already have prior research)

```
/demand-architect quick [market]
```

Requires 4 pre-existing inputs from prior full runs:
- Competitive landscape (8+ competitors with desire mapping)
- Desire hierarchy (L1–L4 complete)
- Psychographic profile (all 14 phases)
- Avatar profiles (3+ avatars with mimetic model)

### Audit Mode (review existing positioning)

```
/demand-architect audit [existing positioning statement or offer]
```

Evaluates existing positioning against the Anti-Mimetic Test and Competitive Belief Audit.

---

## Output Files

All outputs save to your current project folder. A full run produces:

```
{project}/
├── Step-01-Competitive-Desire-Landscape.md
├── Step-02-Desire-Hierarchy.md
├── Step-03-Psychographic-Profile.md
├── Step-04-Avatar-Profiles.md
├── Step-05-Failure-Pattern-Report.md
├── Step-06-Core-Concept-Candidates.md
├── Step-07-Ideal-Buying-Mindset.md
├── Step-08-Belief-Gap-Blueprint.md
├── Step-09-USP-Report.md
├── Synthesis-01-Strategic-Desire-Map.md
├── Synthesis-02-Demand-Architecture-Brief.md
└── Synthesis-03-Anti-Mimetic-Positioning-Statement.md
```

---

## Troubleshooting

**"Skill not found" after installation**
Restart Claude Code after installing. Skills load at startup.

**Step 1 halts saying web research is unavailable**
This is correct behavior. Step 1 REQUIRES live research — it cannot use training data. Enable web search in Claude Code settings, or use a Claude Code session where web tools are active.

**"All 5 Core Concepts failed the Anti-Mimetic Test"**
This is not an error — it means the competitive landscape in Step 1 needs expansion. The skill will guide you through: re-running Step 1 with more competitors, attempting a reframe, or halting with a specific specification of what open territory looks like.

**Quick mode rejects my inputs**
Quick mode has minimum acceptance criteria for each input. If any prior output is below threshold, the skill will specify exactly what's missing and offer to run those steps in full mode first.

**Mac: `chmod: install.sh: No such file or directory`**
You're running the command from the wrong directory. `cd` into the Demand-Architect folder first.

**Windows: "running scripts is disabled on this system"**
Run this first:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```
Then re-run `.\install.ps1`.

**Windows: `python3` not found**
On Windows, Python runs as `python` not `python3`. This is handled automatically by the installer — no action needed.

---

*Packaged by Rich Schefren — Strategic Profits*
*Demand Architect v1.0.0*
