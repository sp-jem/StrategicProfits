# Demand Architect — Windows PowerShell Installer
# Installs demand-architect and all 9 dependency skills into ~/.claude/skills/

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillsSrc = Join-Path $ScriptDir "skills"
$SkillsDst = Join-Path $env:USERPROFILE ".claude\skills"

$Skills = @(
    "demand-architect",
    "demand-desire-mapper",
    "psychographic-excavation",
    "avatar-excavation",
    "failure-pattern-forensics",
    "core-concept-generator",
    "ideal-buying-mindset",
    "belief-gap-analyzer",
    "usp-generator",
    "mimetic-market-intelligence"
)

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Demand Architect Installer" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Verify source files exist
if (-not (Test-Path $SkillsSrc)) {
    Write-Host "ERROR: skills\ folder not found at $SkillsSrc" -ForegroundColor Red
    Write-Host "Please run this installer from inside the Demand-Architect folder."
    exit 1
}

# Create skills directory if needed
if (-not (Test-Path $SkillsDst)) {
    New-Item -ItemType Directory -Path $SkillsDst -Force | Out-Null
}

# Check for existing installations
$Existing = @()
foreach ($skill in $Skills) {
    $dst = Join-Path $SkillsDst $skill
    if (Test-Path $dst) {
        $Existing += $skill
    }
}

if ($Existing.Count -gt 0) {
    Write-Host "The following skills are already installed:" -ForegroundColor Yellow
    foreach ($skill in $Existing) {
        Write-Host "  - $skill"
    }
    Write-Host ""
    $Confirm = Read-Host "Overwrite existing skills? (y/N)"
    if ($Confirm -notmatch "^[Yy]$") {
        Write-Host "Installation cancelled."
        exit 0
    }
    Write-Host ""
}

# Install each skill
Write-Host "Installing skills..."
foreach ($skill in $Skills) {
    $src = Join-Path $SkillsSrc $skill
    $dst = Join-Path $SkillsDst $skill

    if (-not (Test-Path $src)) {
        Write-Host "  WARNING: $skill not found in package — skipping" -ForegroundColor Yellow
        continue
    }

    if (Test-Path $dst) {
        Remove-Item -Path $dst -Recurse -Force
    }

    Copy-Item -Path $src -Destination $dst -Recurse -Force
    Write-Host "  v $skill" -ForegroundColor Green
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Verification" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$Pass = 0
$Fail = 0
foreach ($skill in $Skills) {
    $skillMd = Join-Path $SkillsDst "$skill\SKILL.md"
    if (Test-Path $skillMd) {
        Write-Host "  v $skill" -ForegroundColor Green
        $Pass++
    } else {
        Write-Host "  X $skill — MISSING" -ForegroundColor Red
        $Fail++
    }
}

Write-Host ""
if ($Fail -gt 0) {
    Write-Host "WARNING: $Fail skill(s) failed to install." -ForegroundColor Yellow
} else {
    Write-Host "All $Pass skills installed successfully." -ForegroundColor Green
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  How to Use" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Restart Claude Code, then:"
Write-Host ""
Write-Host "  Full pipeline:"
Write-Host "  /demand-architect full [your market or business]"
Write-Host ""
Write-Host "  Quick mode (with prior research):"
Write-Host "  /demand-architect quick [market]"
Write-Host ""
Write-Host "  Audit existing positioning:"
Write-Host "  /demand-architect audit [positioning statement]"
Write-Host ""
Write-Host "Output files save to your current project folder."
Write-Host "See README.md for full documentation."
Write-Host ""
