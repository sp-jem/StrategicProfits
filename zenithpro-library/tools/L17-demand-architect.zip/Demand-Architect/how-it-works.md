# How Demand Architect Works

Visual diagrams of the pipeline architecture and data flow.

---

## Overview: The 9-Step Pipeline

```mermaid
flowchart TD
A[User Input<br>Market or Business] --> B[Step 1<br>Competitive Desire Landscape]
B --> C[Step 2<br>Desire Hierarchy]
C --> D[Step 3<br>Psychographic Profile]
D --> E[Step 4<br>Avatar Excavation]
E --> F[Step 5<br>Failure Pattern Forensics]
F --> G[Step 6<br>Core Concept Generation]
G --> H[Step 7<br>Ideal Buying Mindset]
H --> I[Step 8<br>Belief Gap Blueprint]
I --> J[Step 9<br>USP Report]
J --> K[Synthesis Phase]
K --> L[3 Final Documents]
```

---

## The Girard Integration Points

Three steps where competitive desire mapping is woven into the psychological analysis:

```mermaid
flowchart LR
B[Step 1<br>Competitive Map] -->|Girard Filter 1| G[Step 6<br>Core Concept]
B -->|Girard Filter 2| I[Step 8<br>Belief Audit]
B -->|Girard Filter 3| J[Step 9<br>USP]
G --> K[Anti-Mimetic Test<br>Hard Gate]
K -->|Pass| L[Proceed to Synthesis]
K -->|Fail| M[Expand Research<br>or HALT]
```

---

## The Constituent Skills

Each step delegates to a specialized skill:

```mermaid
flowchart TD
A[demand-architect<br>Orchestrator] --> B[mimetic-market-intelligence<br>Step 1]
A --> C[demand-desire-mapper<br>Step 2]
A --> D[psychographic-excavation<br>Step 3]
A --> E[avatar-excavation<br>Step 4]
A --> F[failure-pattern-forensics<br>Step 5]
A --> G[core-concept-generator<br>Step 6]
A --> H[ideal-buying-mindset<br>Step 7]
A --> I[belief-gap-analyzer<br>Step 8]
A --> J[usp-generator<br>Step 9]
```

---

## Synthesis: What Gets Produced

```mermaid
flowchart LR
A[9 Step Outputs] --> B[Synthesis 1<br>Strategic Desire Map]
A --> C[Synthesis 2<br>Demand Architecture Brief]
A --> D[Synthesis 3<br>Anti-Mimetic<br>Positioning Statement]
B --> E[Integrated<br>Positioning Strategy]
C --> E
D --> E
```

---

## File Output Structure

```mermaid
flowchart TD
A[Project Folder] --> B[Step-01 thru Step-09<br>9 Research Documents]
A --> C[Synthesis-01<br>Strategic Desire Map]
A --> D[Synthesis-02<br>Demand Architecture Brief]
A --> E[Synthesis-03<br>Anti-Mimetic Statement]
```

---

## Installation Flow

```mermaid
flowchart TD
A[Run install.sh<br>or install.ps1] --> B{Skill already<br>installed?}
B -->|Yes| C[Prompt before<br>overwrite]
B -->|No| D[Copy all 10 skills<br>to ~/.claude/skills/]
C --> D
D --> E[Verify installation]
E --> F[Print usage<br>instructions]
```
