#!/usr/bin/env bash
# Demand Architect — Mac/Linux Installer
# Installs demand-architect and all 9 dependency skills into ~/.claude/skills/

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILLS_SRC="$SCRIPT_DIR/skills"
SKILLS_DST="$HOME/.claude/skills"

SKILLS=(
  demand-architect
  demand-desire-mapper
  psychographic-excavation
  avatar-excavation
  failure-pattern-forensics
  core-concept-generator
  ideal-buying-mindset
  belief-gap-analyzer
  usp-generator
  mimetic-market-intelligence
)

echo ""
echo "========================================"
echo "  Demand Architect Installer"
echo "========================================"
echo ""

# Verify source files exist
if [ ! -d "$SKILLS_SRC" ]; then
  echo "ERROR: skills/ folder not found at $SKILLS_SRC"
  echo "Please run this installer from inside the Demand-Architect folder."
  exit 1
fi

# Create skills directory if needed
mkdir -p "$SKILLS_DST"

# Check for existing installations
EXISTING=()
for skill in "${SKILLS[@]}"; do
  if [ -d "$SKILLS_DST/$skill" ]; then
    EXISTING+=("$skill")
  fi
done

if [ ${#EXISTING[@]} -gt 0 ]; then
  echo "The following skills are already installed:"
  for skill in "${EXISTING[@]}"; do
    echo "  - $skill"
  done
  echo ""
  read -r -p "Overwrite existing skills? (y/N): " CONFIRM
  if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
    echo "Installation cancelled."
    exit 0
  fi
  echo ""
fi

# Install each skill
echo "Installing skills..."
for skill in "${SKILLS[@]}"; do
  SRC="$SKILLS_SRC/$skill"
  DST="$SKILLS_DST/$skill"

  if [ ! -d "$SRC" ]; then
    echo "  WARNING: $skill not found in package — skipping"
    continue
  fi

  rm -rf "$DST"
  cp -r "$SRC" "$DST"
  echo "  ✓ $skill"
done

echo ""
echo "========================================"
echo "  Verification"
echo "========================================"
echo ""

PASS=0
FAIL=0
for skill in "${SKILLS[@]}"; do
  if [ -f "$SKILLS_DST/$skill/SKILL.md" ]; then
    echo "  ✓ $skill"
    PASS=$((PASS + 1))
  else
    echo "  ✗ $skill — MISSING"
    FAIL=$((FAIL + 1))
  fi
done

echo ""
if [ $FAIL -gt 0 ]; then
  echo "WARNING: $FAIL skill(s) failed to install."
else
  echo "All $PASS skills installed successfully."
fi

echo ""
echo "========================================"
echo "  How to Use"
echo "========================================"
echo ""
echo "Restart Claude Code, then:"
echo ""
echo "  Full pipeline:"
echo "  /demand-architect full [your market or business]"
echo ""
echo "  Quick mode (with prior research):"
echo "  /demand-architect quick [market]"
echo ""
echo "  Audit existing positioning:"
echo "  /demand-architect audit [positioning statement]"
echo ""
echo "Output files save to your current project folder."
echo "See README.md for full documentation."
echo ""
