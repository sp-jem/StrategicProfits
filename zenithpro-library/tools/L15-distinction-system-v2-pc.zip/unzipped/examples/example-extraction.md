> **EXAMPLE OUTPUT:** This is a real extraction produced by the Distinction Finder skill, showing the output format for confirmed, needs-refinement, and rejected candidates.

# Distinction Extraction: Coding Distinctions (ChatGPT Conversation)

**Source:** Conversation about expert coder distinctions for non-coders
**Extracted by:** Distinction Finder
**Date:** 2026-02-07

---

## Source Context

A conversation asking for "the distinctions an expert coder would have" — the perceptual capacities that let non-coders see the world through expert eyes when directing AI coding agents. The source produced 8 numbered distinctions plus a "Core Reframe" and "Meta-Distinction."

**Critical note on source quality:** The source uses the word "distinction" liberally. Many entries are frameworks, taxonomies, advice, or information packaged as distinctions. This extraction applies the rigorous standard: a distinction must be a perceptual capacity created through language that permanently alters what you can see and therefore what you can do.

---

## Extraction Results Summary

| Category | Count |
|----------|-------|
| Confirmed (5-6/6) | 3 |
| Needs Refinement (3-4/6) | 4 |
| Rejected (0-2/6) | 3 |
| **Total candidates** | **10** |

---

## CONFIRMED (5-6/6)

---

### 1. Software as Layers vs. Software as Monolith

**Source:** Lines 47-92, "Distinction #1: Code Is Not Code — It's Layers"
**Type:** Perceptual
**Confidence:** High

**A side (default):** You see "software" or "the code" as one undifferentiated thing. When something breaks or needs building, you can only say "the app needs fixing" or "build me this." You have no vocabulary to locate where the problem actually lives.

**B side (with distinction):** You see five discrete layers (interface, logic, data, integration, infrastructure) each with a different job, different failure mode, and different cost profile. You can now point at exactly which layer is the bottleneck, which layer needs to change, and which layers should be left alone.

**Cost of not having it:** You treat every technical problem as equally mysterious. You can't triage, can't prioritize, can't direct AI agents to the right layer.

**Gain of having it:** You can say "the data layer is the bottleneck" or "the integration layer is where this will break." You become dangerous to build with because you can locate problems before they compound.

**Qualification Filters:**
1. Perceptual — YES. Once you see layers, you literally see software differently.
2. Binary — YES. "One thing" vs. "five distinct layers." Clean A/B boundary.
3. Automatic — YES. Once acquired, you scan for layers without thinking.
4. Domain-portable — YES. Applies to any software, any AI build, any conversation.
5. Action-enabling — YES. Opens questions ("which layer?") without prescribing answers.
6. Pre-framework — PARTIAL. The five specific layers are framework-ish, but "layers exist vs. monolith" is atomic.

**Score: 5/6**

---

### 2. Failure as Expected vs. Failure as Error

**Source:** Lines 283-332, "Distinction #6: Failure Is a Feature"
**Type:** Inversion
**Confidence:** High

**A side (default):** Failure means something went wrong. If the system fails, someone screwed up. You design for the happy path and treat errors as anomalies.

**B side (with distinction):** Failure is a guaranteed feature of all systems. The question is never "will it fail?" but "where and how will it fail?" You pre-see failure modes and design for them before they happen.

**Cost of not having it:** You build systems that work in demos and break in production. Every failure surprises you.

**Gain of having it:** You ask "what happens when the API is down?" before building. Your systems handle failure because you designed for the failure you know is coming.

**Qualification Filters:**
1. Perceptual — YES. Changes what you see when you look at any system.
2. Binary — YES. "Failure = error" vs. "Failure = expected feature."
3. Automatic — YES. Can't look at a system without scanning for failure modes.
4. Domain-portable — YES. Applies far beyond code: business processes, workflows, funnels.
5. Action-enabling — YES. Opens design questions without prescribing answers.
6. Pre-framework — YES. Atomic inversion.

**Score: 6/6**

---

## NEEDS REFINEMENT (3-4/6)

### 3. Naming as Power vs. Naming as Label

**Source:** Lines 333-380, "Distinction #7: Naming Is Power"
**Type:** Collapsed
**Confidence:** Medium

**A side:** Naming means labeling things for communication convenience.
**B side:** Naming creates new perceptual categories that enable action.

**What's missing:** The distinction is stated abstractly. Needs concrete examples of how naming something specifically (vs. generically) changes what you can do with AI. Currently more philosophical than perceptual.

**Score: 3/6** (Perceptual: Partial, Binary: Yes, Automatic: Unclear, Portable: Yes, Action-enabling: Unclear, Pre-framework: Yes)

---

## REJECTED (Not Distinctions)

### R1. "The Five Problem Archetypes"

**Source:** Lines 93-160, "Distinction #2"
**What it actually is:** A FRAMEWORK (taxonomy of 5 problem types). Useful, but it's a classification system, not a perceptual shift. Knowing there are 5 types doesn't change what you SEE — it gives you categories to sort things into after you've already seen them.

**Score: 2/6**

### R2. "State and Data Shape Awareness"

**Source:** Lines 161-220, "Distinction #3"
**What it actually is:** TECHNICAL INFORMATION about how data structures work. Knowing that "state" exists is information, not perception. A non-coder cannot spot state management issues by knowing the concept — they need the perceptual shift of "what persists vs. what's computed fresh."

**Score: 2/6**
