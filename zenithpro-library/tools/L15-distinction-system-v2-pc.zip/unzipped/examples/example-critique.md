> **EXAMPLE OUTPUT:** This is a real batch critique produced by the Distinction Expander Critic agent. It shows the scoring table, detailed per-file evaluations, constraint violation tracking, and batch-level observations. Study the scoring dimensions and SHIP/REVISE thresholds.

# Batch Critique Results

**Batch:** 10 teaching units (diffusion-strategy through edge-work)
**Critic:** Distinction Expander Critic
**Date:** 2026-02-08

---

## SCORING TABLE

| # | File | Gap | Ctr | Fla | Nam | App | Rnf | Vox | Adj | V |
|---|------|-----|-----|-----|-----|-----|-----|-----|-----|---|
| 1 | diffusion-strategy-vs-capability-strategy | 8.0 | 8.5 | 8.0 | 9.0 | 8.5 | 9.0 | +1 | 8.48 | SHIP |
| 2 | discovery-before-commitment | 9.0 | 9.0 | 9.0 | 9.0 | 9.0 | 9.5 | +1 | 9.13 | SHIP |
| 3 | discovery-vs-execution-work | 7.5 | 8.0 | 7.0 | 8.0 | 8.0 | 8.0 | +0.5 | 7.73 | REVISE |
| 4 | distributed-vs-individual-cognition | 8.5 | 8.5 | 8.0 | 8.0 | 8.5 | 8.5 | +1 | 8.48 | SHIP |
| 5 | distribution-vs-capability | 9.0 | 9.0 | 9.0 | 9.0 | 9.0 | 9.0 | +1 | 9.00 | SHIP |
| 6 | documents-vs-instruments | 8.5 | 8.5 | 8.5 | 9.0 | 8.5 | 8.5 | +1 | 8.58 | SHIP |
| 7 | doer-vs-designer | 9.5 | 9.0 | 9.5 | 9.0 | 9.0 | 9.0 | +1 | 9.25 | SHIP |
| 8 | doing-vs-modeling | 8.0 | 8.5 | 8.5 | 8.5 | 8.5 | 8.5 | +1 | 8.43 | SHIP |
| 9 | done-as-contract-vs-cue | 8.5 | 8.5 | 8.0 | 8.5 | 8.0 | 8.5 | +1 | 8.43 | SHIP |
| 10 | edge-work-vs-core-work | 8.5 | 9.0 | 9.0 | 8.5 | 9.0 | 9.0 | +1 | 8.83 | SHIP |

**SHIP Rate:** 9/10 (90%)
**Average Score:** 8.63

---

## DETAILED SCORES — EXEMPLAR FILE (Highest Score)

### doer-vs-designer.md
**Adjusted Score:** 9.25 | **SHIP**

**Dimension Scores:**
- Gap (20%): 9.5 — **EXEMPLAR.** "What if the problem was never the people?" holds uncertainty for 45 lines. Identity-level disruption with emotional specificity.
- Contrast (15%): 9.0 — Three clean pairs, money line perfect ("One is a person. The other is a force multiplier.").
- Flash (25%): 9.5 — **EXEMPLAR.** Three-act copywriter story with deep emotional specificity in Acts 1-2. "I was trying to hire a clone" hits hard. Backup angle (freedom calculation) adds dimension.
- Name (10%): 9.0 — "Doer vs Designer" clean, diagnostic question works.
- Application (15%): 9.0 — 24hr action (5-minute blueprint sketch), design session (30 min), teach-it with quality check.
- Reinforcement (15%): 9.0 — D/B marking system is brilliant daily trigger, peer mechanism present, program callback, relapse pattern, integration check.
- Voice: +1 — Pure voice. Story-driven, self-indicting, emotionally specific.

**Constraint Violations:** None. This is the gold standard.

**REVISE Notes:** None — use this as the template for Stance distinctions.

---

## DETAILED SCORES — REVISE FILE (Below 8.0 Threshold)

### discovery-vs-execution-work.md
**Adjusted Score:** 7.73 | **REVISE**

**Dimension Scores:**
- Gap (20%): 7.5 — Unanswerable question setup works but the two situations feel under-developed. Needs more weight.
- Contrast (15%): 8.0 — Binary clear, pairs work, but "loop vs task-completion" language is slightly technical.
- Flash (25%): 7.0 — **PROBLEM:** Two separate examples feel like fragments, not a full story. No three-act structure, no emotional depth. Backup angle is just an analogy — not a second full angle.
- Name (10%): 8.0 — Name works, diagnostic question clear.
- Application (15%): 8.0 — 24hr action produces artifact. Applications functional but generic.
- Reinforcement (15%): 8.0 — Daily trigger present, peer mechanism works, program callback included.
- Voice: +0.5 — Voice is present but thinner than typical depth.

**Constraint Violations:**
- C2: Flash lacks three-act story structure — two examples instead of one story with depth
- C2: No backup angle — just fragments
- Flash emotional specificity weak

**REVISE Instructions:**
1. **Rebuild Flash as single three-act story** — pick ONE example, go deep with three acts including Act 2 student-commitment moment
2. Add backup angle (7-10 lines) with different entry point
3. Deepen emotional specificity in Gap
4. Consider if this is actually two distinctions collapsed

---

## SUMMARY OBSERVATIONS

### Strengths Across Batch:
1. **Voice fidelity extremely high** — 9 of 10 files earned +1 voice bonus
2. **Application sections consistently strong** — 24-hour actions produce artifacts, teach-it scripts included
3. **Reinforcement architecture solid** — daily triggers, peer mechanisms, program callbacks present in all
4. **Gap strategies varied and effective** — good mix of recognized failure, unanswerable question, expert mystery

### Patterns:
1. **Three-act Flash structure** when present produces highest Flash scores (doer-vs-designer 9.5, edge-work 9.0)
2. **Historical validation in Gap** creates stronger identity-level disruption
3. **Financial/organizational backup angles** consistently add dimension

### The ONE REVISE File:

**discovery-vs-execution-work.md (7.73)** fails on Flash dimension due to:
- Two fragmented examples instead of one deep story
- No three-act structure
- Weak emotional specificity
- No true backup angle

This is recoverable with Flash rebuild. Core distinction is sound.

---

## RECOMMENDATIONS

1. **Ship 9 files immediately** — all scoring 8.0+ adjusted
2. **Revise discovery-vs-execution-work.md** following instructions above, then re-critique
3. **Use doer-vs-designer.md as template** for future Stance distinctions
4. **Use distribution-vs-capability.md as template** for future Inversion distinctions
5. **Use edge-work-vs-core-work.md as template** for Collapsed distinctions

---

**Batch Quality:** 8.63 average (STRONG)
**Ship Rate:** 90% (9/10)
**Voice Consistency:** 95% (+1 or +0.5 on all files)
