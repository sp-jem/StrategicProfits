> **EXAMPLE OUTPUT:** This is a real expanded teaching unit produced by the Distinction Expander skill. It scored 8.48 (SHIP) from the Expander Critic. Study the six-component landing sequence structure.

# Architectural Literacy vs. Coding Literacy

**Type:** Collapsed Distinction
**Severity:** Gateway (Must Land First)
**Cost of Collapse:** Paralysis or misdirection — you either never start or waste months on the wrong skill tree

---

## 1. THE GAP (Opening)

How many of you think you need to learn to code to be effective with AI?

Show of hands. Keep them up.

Now — how many of you have avoided building something because "I'm not technical"?

Most of the same hands.

Here's what just happened. You collapsed two completely different things into one word. You're using "coding" to mean both the hands that write the code AND the eyes that see what should be built. And that collapse is either keeping you paralyzed or sending you down the wrong learning path entirely.

Let me show you what I mean.

---

## 2. THE CONTRAST (A vs. B)

### A Side: Coding Literacy

This is what you think you need. The ability to write code. Syntax. Languages. Loops and functions and data structures. The craft of programming.

If you're going down this path, you're learning Python. You're doing tutorials. You're stuck on syntax errors.

And here's the thing — for 40 years, this WAS the prerequisite. If you wanted to build software, you had to learn to code. There was no other path.

But that bottleneck just disappeared.

### B Side: Architectural Literacy

This is what you actually need. The ability to SEE systems. To understand constraints, surfaces, flows, structures. To know what needs to exist and what must not exist. To direct builders.

Architects rarely build with their hands. They see invisible forces. They decide where the load-bearing walls go. They know what's possible and what's stupid. And they direct people who DO have hands-on skills.

That's what you need with AI. Not the ability to write code. The ability to see what should be built, why it should exist, what the constraints are, and how to direct an AI that CAN write code.

### The Money Line

**You don't need coding literacy. You need architectural literacy. And you already have the raw material for it — you just don't know how to activate it yet.**

---

## 3. THE FLASH (Self-Recognition)

Let me tell you what this looks like collapsed.

**Version 1: Paralysis**
You see someone build an AI agent that automates their client onboarding. And your first thought is: "I could never do that. I'm not technical."

So you don't even try. You stay in manual mode.

**Version 2: The Wrong Learning Path**
You decide you're going to learn Python. You buy a course. You spend three weeks learning how to manipulate lists and write functions.

Then you try to build something real. And you realize: the coding part isn't the problem. The problem is you have no idea what to build, how to structure it, or what's even possible. You learned syntax. You didn't learn sight.

**Here's the tell:**
If you've ever said "I can't build that, I'm not a developer," you're living in the collapse. You think the hands are the blocker. The hands are no longer the blocker. The eyes are the blocker.

And the good news? You can train your eyes a hell of a lot faster than you can train your hands.

---

## 4. THE NAME (Anchoring Language)

**Architectural Literacy vs. Coding Literacy**

Two completely different skill sets. Two different roles. Two different ways of seeing.

**Coding Literacy:** The craft of writing code. The builder's hands.
**Architectural Literacy:** The ability to see systems, constraints, and structures. The architect's eyes.

When you collapse them, you either freeze or you learn the wrong thing.

---

## 5. THE APPLICATION (Making It Real)

### Immediate Action (Do This Now)

Pick any tool you use daily — your CRM, email system, calendar. Write down:
- What are the core entities? (contacts, deals, tasks)
- What actions can you take? (create, update, search, delete)
- What are the constraints? (a deal can't exist without a contact)
- What are the surfaces? (where do you interact with it?)

You just did architectural thinking. You didn't write a line of code. You saw structure.

### Application 1 — Self-Diagnosis

List 3 things you've avoided building because "I'm not technical." For each one, write down: Is the real blocker that you can't write code, or that you can't see what should exist?

### Application 2 — Teach It

Explain this to someone on your team: "We used to need coding skills to build software. Now we need architectural skills. The difference is: coding is about writing the code. Architecture is about seeing what should exist and directing something that CAN write code."

If you can explain it, you've internalized it. If you can't, you're still collapsed.

---

## 6. THE REINFORCEMENT (Deepening)

**Daily Trigger:**
Every time you hear "I'm not technical" (from yourself or others), translate it: Are they saying "I can't code" or "I can't see systems"?

**Peer Mechanism:**
Ask your team: "Is this an architecture problem or an implementation problem?" Architecture = I don't know what should exist. Implementation = I don't know how to build it.

**Program Callback:**
This distinction resurfaces in Session 3 when you build your first system from scratch and discover that the bottleneck was always sight, not syntax.

**Language Signals:**
| Before (Collapsed) | After (Separated) |
|--------------------|--------------------|
| "I'm not technical" | "I need to see the structure" |
| "I can't build that" | "I need to architect that" |
| "I should learn Python" | "I should learn systems thinking" |

**Integration Check (30 days):**
1. When you encounter a technical problem, do you ask "which layer?" before anything else?
2. Have you stopped describing yourself as "not technical"?
3. Can you describe a system's architecture without knowing any code?

---

## TEACHING NOTES

**Delivery Priority:** Teach this FIRST. Before any other distinction. This is the permission slip.

**Emotional Hook:** Most of the room thinks they're not technical. This distinction flips that script. It says: "You already have what you need. You just didn't know it was the right thing."

**Flash Moment:** "If you've ever said 'I could never build that,' you're living in the collapse."

This distinction is weight-bearing. If it doesn't land, the rest of the program feels like "learning to code." If it lands, the rest feels like "activating a superpower I didn't know I had."
