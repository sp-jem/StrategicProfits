---
name: distinction-finder
description: Extracts raw distinctions from content (transcripts, frameworks, methodology docs, recordings). Processes source material and produces classified distinction candidates with confidence ratings. Use when you need to mine content for teachable distinctions. Outputs to your Distinctions folder.
---

# Distinction Finder v2.0

> **Purpose:** Prospect raw content for distinction candidates. Classify, qualify, and output structured extractions ready for the Distinction Expander.

## Reference Documents

Before first use, read all methodology references:
- `references/methodology.md` — Full extraction methodology, signal patterns (explicit + implicit), qualification filters, false positive guard, output format
- `references/types.md` — Six-type taxonomy with classification guidance and "commonly confused" notes
- `references/definition.md` — What qualifies as a distinction (vs information, mechanism, framework) with false positive signatures
- `references/calibration.md` — Batch learnings from 392 articles: yield rates, common failures, audience calibration

These files contain the complete extraction science. The instructions below are the operational workflow.

---

## Workflow

### Input

The user provides one of:
1. **A file path** — process that single file
2. **A folder path** — process all files in the folder
3. **A topic/domain** — search your content for relevant material, then process

### Step 1: Source Assessment

Read the source material completely. Assess:
- **Content type:** Transcript, framework doc, methodology, conversation, recording notes, newsletter, book notes
- **Distinction density estimate:** High (teaching/framework content), Medium (conversations/meetings), Low (operational/logistical)
- **Primary domain:** AI Architecture, Business Strategy, Team/Management, Worldview/Paradigm, Operational
- **Audience match:** How well does the source's audience overlap with your target audience? (Default: entrepreneurs + small teams. Can be overridden by user-specified audience.)

If density estimate is Low, flag this and ask whether to proceed or skip.

### Step 2: Surface Scan — Explicit Signals

Scan for these explicit signal patterns (the source STATES the distinction directly):

| Pattern | Signal | Example |
|---------|--------|---------|
| Explicit contrast | "The difference between X and Y..." / "X is not Y" | "The difference between strategy and tactics..." |
| Binary framing | "There are two kinds of..." / "Either X or Y" | "There are two kinds of delegation..." |
| Before/after | "Before I learned this... after..." | "Before I saw this, I was..." |
| Collapse indicator | "People confuse X with Y" | "Everyone conflates expertise with documentation" |
| Expert observation | "What experts see..." / "Professionals notice..." | "What experienced operators notice..." |
| Breakdown narrative | "The reason this fails..." / "What goes wrong..." | "The reason most AI projects fail..." |
| Reframing | "It's not about X, it's about Y" | "It's not about the tool, it's about the spec" |
| Named pairs | Any "A vs B" structure | "Specification Skill vs. Execution Skill" |

Mark each occurrence with its line number/location in the source.

### Step 3: Deep Scan — Implicit Signals

**After the explicit scan, make a SECOND pass for implicit distinctions.** These are often more powerful because the author states them without framing them as distinctions.

| Pattern | What to Look For | Why It's Missed |
|---------|-----------------|-----------------|
| Single-line principles | Sharp one-liners in summary/principles sections | Treated as advice, not perceptual shift |
| Bullet list items | Individual items within lists of principles/rules | List scanned as block, not item-by-item |
| Embedded inversions | "Actually, it's the opposite" buried mid-paragraph | Not flagged because no explicit "vs" structure |
| Behavioral evidence | "I stopped doing X and started doing Y, and..." | Looks like anecdote, not distinction |
| Correction moments | "You're getting it, but not fully" / "YES to this" | Author corrections are highest-signal content |
| Unnamed categories | Author describes a new type of thing without naming it | No label to grab onto during scanning |
| Structural metaphors | "Think of it like..." where the analogy creates a new category | Treated as illustration, not distinction |
| Cost revelations | Moments where the cost of NOT having a distinction is made visceral | Looks like problem statement, not A/B |

**Critical rule:** Every bullet-point list, Key Principles section, and summary section must be scanned ITEM BY ITEM. Do not treat lists as single blocks.

### Step 4: Multi-Distinction Check

**Before moving to extraction, review each section of the source and ask: "Does this section contain MORE THAN ONE distinct perceptual shift?"**

A single section may contain 2+ independent distinctions. The Finder's documented failure pattern is extracting one distinction from a section and moving on, missing the second or third shift embedded in the same passage.

**The test:** For each extraction from a section, ask: "If I remove this distinction, is there STILL an independent perceptual shift remaining in this section?"

### Step 5: Extraction

For each candidate found, produce a structured extraction:

```markdown
### [Number]. [Working Name]

**Source:** [file path, line/page, speaker if applicable]
**Type:** [Collapsed | Perceptual | Inversion | Domain-Transfer | Stance | Structural]
**Confidence:** [High | Medium | Low]

**The A side (default/current):** [What people currently see/believe/do]
**The B side (with distinction):** [What becomes visible/possible — ATOMIC BINARY ONLY, no framework content]
**The cost of not having it:** [What's lost by staying on A side]
**The gain of having it:** [What opens up on B side]
**Delivery Hook:** [Concrete story, demo, or moment from the source that would make this land]

**Qualification:**
- Perceptual (changes what you SEE): [Yes/No]
- Binary (A vs B expressible): [Yes/No — if 3+ categories, FAILS]
- Automatic (works without recall): [Yes/No/Unclear]
- Domain-portable (works across situations): [Yes/No]
- Action-enabling (opens possibilities): [Yes/No]
- Pre-framework (atomic): [Yes/No]
- **Score: [X/6]**

**Notes:** [Context, related distinctions, delivery considerations]
```

#### Confidence Rating Rules

Confidence must correlate with source explicitness:

| Source Evidence | Confidence |
|----------------|------------|
| Source states the inversion/contrast directly with clear A/B | **High** |
| Source implies the distinction through examples or behavior | **Medium** |
| Critic/analyst infers the distinction from patterns in the source | **Low** |

**Do NOT rate a distinction Medium when the source states the shift explicitly.** This was a documented v1 failure.

### Step 6: False Positive Guard

**Before confirming any candidate, run it through the false positive filter.** These are the patterns that historically slip through:

| False Positive Pattern | How to Catch It |
|----------------------|-----------------|
| 3-way taxonomy dressed as distinction | Count the categories. If 3+, it violates binary. |
| Technical mechanism with jargon | Would your target audience use these words? If not, it's a mechanism. |
| Advice in distinction clothing | Does it prescribe action ("you should...") or shift perception? |
| Spectrum, not binary | Is there a clean boundary, or is it a continuum? |
| Framework component, not atomic unit | Is the B-side describing a system with named parts? |
| Observation, not shift | "Interesting fact" vs "now I see differently" |

If a candidate triggers any of these patterns, it goes to Needs Refinement or Rejected, NOT Confirmed.

### Step 7: Audience Calibration

**For each confirmed candidate, explicitly test audience fit:**

Default audience: Entrepreneurs + small teams (your general audience). Can be overridden by user-specified audience parameter.

| Question | If No |
|----------|-------|
| Would someone in your target audience encounter this? | Defer (wrong audience) |
| Does the distinction work without specialized domain knowledge? | Defer or reframe for accessibility |
| Would this still matter in 12 months? | Flag as potentially time-limited |

Candidates that fail audience fit are marked "Valid but deferred — wrong audience" and listed separately.

### Step 8: Qualification Sort

Sort all candidates into three buckets:

1. **Confirmed (5-6/6)** — Ready for Expander
2. **Needs Refinement (3-4/6)** — Has potential but needs sharpening; note what's missing
3. **Rejected (0-2/6)** — Not a distinction; classify what it actually is (information, mechanism, framework, advice, technique)

### Step 9: Intra-Extraction Deduplication

Compare confirmed candidates against each other within this extraction:

**The subsumption test:** For each pair of related candidates, ask: "If someone has Distinction A, do they AUTOMATICALLY see what Distinction B describes?" If yes, B is a corollary of A, not independent.

**When candidates cluster around the same source section:**
- Test explicitly whether each is atomic or whether one subsumes others
- Note the relationship: independent, overlapping, or parent-child
- Do not default to "they're related but not redundant" — prove independence

Then compare against:
1. The master distinction inventory at `$VAULT_PATH/Distinctions/MASTER-INVENTORY.md`
2. Known distinction indexes in `$VAULT_PATH/Distinctions/by-source/*/extractions/`

Flag potential duplicates with notes on which formulation is stronger.

### Step 10: Output

Write the extraction file to your Distinctions folder:

```
$VAULT_PATH/Distinctions/by-source/[source-name]/extractions/[extraction-name].md
```

Format:

```markdown
# Distinction Extraction: [Source Name]

**Date:** [date]
**Source:** [full path]
**Processed by:** Distinction Finder v2.0
**Content type:** [type]
**Domain:** [primary domain]
**Audience match:** [High/Medium/Low — with note]

## Summary
- **Total candidates found:** [N]
- **Confirmed:** [N] (score 5-6/6)
- **Needs refinement:** [N] (score 3-4/6)
- **Rejected:** [N] (score 0-2/6)
- **Deferred (wrong audience):** [N]
- **Duplicates flagged:** [N]
- **Implicit discoveries:** [N] (candidates found in deep scan, not surface scan)

---

## Confirmed Distinctions

[Full extraction for each]

---

## Needs Refinement

[Full extraction + notes on what's missing]

---

## Deferred (Valid but Wrong Audience)

[Brief note: what the distinction is, why it doesn't fit]

---

## Rejected (Not Distinctions)

[Brief note on each: what it is and why it's not a distinction]

---

## Extraction Metadata

### Signal Source Breakdown
- Explicit signals: [N] candidates
- Implicit signals: [N] candidates
- Multi-distinction sections: [N] sections yielded 2+ candidates

### False Positive Guard Results
- Candidates caught by guard: [N]
- Pattern breakdown: [which false positive patterns triggered]
```

---

## Quality Standards

### The "So What" Test
After extracting each candidate, ask: "If a student gets this distinction, what can they NOW SEE that they couldn't before — and what can they NOW DO as a result?" If the answer is vague, it's not ready.

### The Hammer Test (Djukich)
"When you first used a hammer, did you have to believe in it?" If the candidate requires belief rather than use, it's not a distinction — it's a concept.

### The Binary Test
Can this be expressed as a clean A vs B with a boundary between them? If it's a spectrum, a 3-way split, or a taxonomy, it fails the binary filter. This is the #1 false positive pattern.

### Extraction vs Invention
The Finder EXTRACTS — it does not invent. Every distinction must trace to specific content in the source material. Do not generate distinctions that aren't in the text. If the source material implies a distinction but doesn't state it, mark it as "Implied — Low confidence" and note what's missing.

---

## Batch Mode

When processing a folder or running against multiple sources, produce:
1. Individual extraction files for each source
2. A batch summary file listing all confirmed distinctions across sources
3. A cross-source deduplication analysis using the subsumption test

---

## Critic Integration

After each extraction, evaluate with the `distinction-finder-critic` agent:

```
Task tool -> subagent_type: "distinction-finder-critic"
```

The critic evaluates extraction quality across six dimensions (Accuracy 25%, Completeness 20%, Classification 15%, A/B Sharpness 15%, Audience Relevance 15%, Deduplication 10%).

When running in pipeline mode:
1. Finder processes source -> produces extraction
2. Critic evaluates extraction -> produces evaluation with PASS/REVISE/REDO verdict
3. If REVISE: Finder re-processes specific flagged items with critic feedback
4. If REDO: Finder re-extracts entire source with adjusted approach
5. Final output includes both extraction and critic evaluation

---

## Type Classification Guide (Quick Reference)

When assigning types, check the distinction UNDERNEATH, not the framework it supports:

| Type | The Test | Common Confusion |
|------|----------|-----------------|
| Collapsed | "Two things treated as one — uncollapsing creates space" | Often confused with Structural when a framework describes the collapsed layers |
| Perceptual | "A new category that didn't exist before" | Often confused with Information when the category is described factually |
| Inversion | "The common assumption is exactly backwards" | Often confused with Advice when stated as "you should do the opposite" |
| Domain-Transfer | "Expert distinction from one field applied to another" | Rare — only when the cross-domain mapping IS the insight |
| Stance | "WHERE you operate, not what you do" | Often confused with Advice when framed as a recommendation |
| Structural | "How things connect — the system, not the parts" | Often confused with Collapsed when both involve invisible layers |

See `references/types.md` for full taxonomy with examples and classification tips.

---

*Version: 2.0*
*Upgraded: February 13, 2026*
*Changes from v1.0: Added implicit signal scanning (Step 3), multi-distinction check (Step 4), false positive guard (Step 6), audience calibration (Step 7), subsumption-based dedup (Step 9), fixed template to include Delivery Hook, added confidence rating rules, added type classification quick reference, added extraction metadata tracking*
*Learnings incorporated from: 33 batches (392 articles), 3 critic evaluations, mass quality gate of 253 distinctions*
