# Extraction Methodology Reference v2.0

## Signal Patterns — Explicit (Source STATES the distinction)

| Pattern | Signal | Example |
|---------|--------|---------|
| Explicit contrast | "The difference between X and Y..." / "X is not Y" | "The difference between strategy and tactics..." |
| Binary framing | "There are two kinds of..." / "Either X or Y" | "There are two kinds of delegation..." |
| Before/after | "Before I learned this... after..." | "Before I saw this, I was..." |
| Collapse indicator | "People confuse X with Y" | "Everyone conflates expertise with documentation" |
| Expert observation | "What experts see..." / "Professionals notice..." | "What experienced operators notice..." |
| Breakdown narrative | "The reason this fails..." / "What goes wrong..." | "The reason most AI projects fail..." |
| Reframing | "It's not about X, it's about Y" | "It's not about the tool, it's about the spec" |
| Named pairs | Any "A vs B" structure | "Specification Skill vs. Execution Skill" |

---

## Signal Patterns — Implicit (Source CONTAINS the distinction without framing it as one)

**These are often the most powerful distinctions.** The author states them as observations, principles, or asides — not as explicit contrasts. The Finder's #1 documented failure is missing these.

| Pattern | What to Look For | Why It's Missed | Real Example |
|---------|-----------------|-----------------|--------------|
| Single-line principle | Sharp one-liner in a summary or Key Principles section | Treated as advice restatement | "Every ambiguity is a decision the AI makes for you" — Inversion hiding in a principles list |
| Bullet list item | Individual item in a numbered/bulleted list of rules or principles | List scanned as a block, not item-by-item | "Add rules when things go wrong, not preemptively" — Inversion hiding in an 8-item list |
| Embedded inversion | "Actually..." or "it turns out..." buried mid-paragraph | No explicit "vs" triggers the scanner | "PRDs written from theory produce tools that work in theory" |
| Behavioral evidence | "I stopped doing X / I now do Y" | Looks like personal anecdote | "I stopped specifying upfront and started prototyping first" |
| Correction moment | Author correcting someone — "You're close, but..." | Treated as feedback, not distinction source | Corrections during review are the sharpest articulations |
| Unnamed category | Author describes a new type of thing without naming it | No label to flag during scanning | Describing "compounding tools" vs static ones without using those words |
| Structural metaphor | "Think of it like..." where the analogy creates a new perceptual category | Treated as illustration | "Think of your team's AI use as an orchestra, not a collection of soloists" |
| Cost revelation | A moment where the cost of NOT having a distinction is made visceral | Reads as a problem statement | "She spent 2.5 hours on every estimate" — the cost that makes the distinction land |
| Role/identity shift | "Your job is actually X, not Y" | Reads as career advice | "Your job isn't execution — it's translation" |
| Failure postmortem | "Here's why that project died..." with the root cause being a collapsed distinction | Reads as a case study | "The project failed because the coordinator was also building" |

### Scanning Rules for Implicit Signals

1. **Every bullet list gets item-by-item scanning.** Do not scan lists as single blocks. Each item in a Key Principles, Rules, or Lessons Learned section is a candidate.

2. **Summary sections get EXTRA attention, not less.** Summary/conclusion sections often contain the sharpest formulations because the author is distilling to essentials.

3. **Author corrections are the highest-signal content.** When the author says "you're getting it, but not fully" and then restates — that restatement IS the distinction in its sharpest form.

4. **Check for multiple distinctions per section.** After extracting one candidate from a section, go back and ask: "If I remove this distinction, is there still an independent perceptual shift in this passage?"

---

## Qualification Filters (ALL must pass for "Confirmed")

1. **Perceptual** — Changes what you SEE, not just what you KNOW
2. **Binary** — Expressible as A vs B at the core. **If 3+ categories exist, it FAILS this filter.** This is the #1 false positive pattern.
3. **Automatic** — Works without conscious recall once acquired
4. **Domain-portable** — Shows up in new situations without re-teaching
5. **Action-enabling** — Opens new possibilities (doesn't prescribe specific actions)
6. **Pre-framework** — Atomic (not built from other distinctions)

**Scoring:** 5-6/6 = Confirmed | 3-4/6 = Needs Refinement | 0-2/6 = Rejected

---

## False Positive Library (Documented Failures from 253 Distinctions)

These are the specific patterns that historically get confirmed when they shouldn't. Run every candidate through this list BEFORE confirming.

### Pattern 1: Three-Way Taxonomy
**The trap:** A 3+ part categorization system framed with "vs" in the name.
**How to catch:** Count the categories in the B-side. If there are 3 or more, it violates binary.

### Pattern 2: Technical Mechanism with Jargon
**The trap:** A valid technical insight expressed in language your target audience would never use.
**How to catch:** Would someone in your target audience say these words? If the terminology requires specialized training, it's a mechanism, not a distinction for this audience.

### Pattern 3: Advice in Distinction Clothing
**The trap:** A recommendation ("you should do X") framed as a perceptual shift.
**How to catch:** Does the candidate prescribe an action, or does it shift what you see? The test: "After hearing this, do I see something differently — or do I just have a new to-do?"

### Pattern 4: Spectrum, Not Binary
**The trap:** A continuum of possibilities labeled with two endpoints.
**How to catch:** Is there a clean boundary between A and B, or is it a sliding scale?

### Pattern 5: Framework Component
**The trap:** One element of a larger system extracted as if it's atomic.
**How to catch:** Is the B-side describing a system with named parts? Does it reference a parent framework?

### Pattern 6: Observation, Not Shift
**The trap:** An interesting fact about the world that doesn't change how you see anything.
**How to catch:** After reading this, do I perceive my own situation differently? Or did I just learn something?

---

## What Distinctions Are NOT

- **Information:** "AI can process 1000x more data" — fact, not perceptual shift
- **Advice:** "You should use Python for data work" — prescription, not distinction
- **Mechanism:** "Trained Incapacity" — explains HOW something works; becomes a distinction only when the person can spot it in real time
- **Framework:** "The 4 Ps of Marketing" — built FROM distinctions; sits higher in hierarchy
- **Technique:** "Use the STAR method" — procedural, not perceptual
- **Observation:** "AI adoption is accelerating" — true but doesn't change what you see in your own business

**The distinguishing test:** A distinction changes what you PERCEIVE. After acquiring it, you see things you literally couldn't see before. Information changes what you KNOW. After learning it, you have a new fact but your perception hasn't shifted.

---

## Audience Calibration

### Default Student Profile
- Entrepreneur or business owner
- Running a company with 1-50 people
- Cares about operational leverage, not technical architecture
- Needs distinctions that work in the NEXT 6-12 months

### Audience Fit Questions
For each confirmed candidate:
1. Would this person encounter the situation described in the A-side?
2. Can they apply the B-side without specialized knowledge?
3. Is this relevant to the current business environment?

### Wrong-Audience Markers (Defer, Don't Confirm)
- Investor/analyst insight (capital allocation, market thesis)
- Enterprise-only scale (organizational learning across 1000+ people)
- Industry-specific regulation (compliance as moat)
- Specialist knowledge required (pattern retrieval vs reasoning internals)

---

## The "So What" Test

After extracting each candidate: "If a student gets this, what can they NOW SEE that they couldn't — and what can they NOW DO?" Vague answer = not ready.

---

## Confidence Rating Rules

| Source Evidence | Rating |
|----------------|--------|
| Source states inversion/contrast directly | **High** |
| Source implies through examples/behavior | **Medium** |
| Analyst infers from patterns | **Low** |

**Documented failure:** v1 rated explicit inversions as Medium. When the source is explicitly stating the shift, the rating is High.

---

## Critic-Validated Extraction Rules (v2.0)

### Rule 1: Separate Distinctions from Frameworks in B-Sides
When a distinction comes packaged with a taxonomy (e.g., "five layers"), the B-side must describe the ATOMIC BINARY SHIFT, not the framework.

### Rule 2: Mine Corrections as Primary Signals
When the author says "You're getting it, but not fully" or "YES to this [passage]," treat what follows as the sharpest articulation of the distinction.

### Rule 3: Scan Every Section Independently
Bullet-point lists, Key Principles, and summary sections contain standalone distinctions. Scan each item individually.

### Rule 4: Check for MULTIPLE Distinctions Per Section
A single section may contain 2+ distinct perceptual shifts. Extract and evaluate each.

### Rule 5: When Source Author Names Categories, Each Gets Its Own Extraction
If the source explicitly names 4 shifts, verify each maps to a separate confirmed distinction.

### Rule 6: Score Duplicates Honestly
If a Needs Refinement candidate is "essentially the same distinction in different words," score it 1-2/6, not 3-4/6.

### Rule 7: Capture Delivery Hooks at Extraction Time
Add a "Delivery Hook" note to each Confirmed distinction: a concrete story, demo, or moment that would make it land.

### Rule 8: Note General vs. Specific Forms
When a source contains both a general principle and a specific instantiation, note both and explain the relationship.

### Rule 9: Audience-Calibrate Scoring
If a candidate requires domain knowledge the target audience doesn't have, weight that more heavily in confidence rating.

### Rule 10: Type the Distinction, Not the Framework
When a distinction lives inside a framework, type the DISTINCTION ("two things collapsed into one") not the FRAMEWORK ("how things connect").

### Rule 11: Test Subsumption Before Confirming Clusters
When 3+ candidates emerge from the same source section, explicitly test: "If someone has Distinction A, do they automatically see what B describes?"

### Rule 12: Implicit Signals Require a Second Pass
The explicit scan catches ~60-70% of distinctions. The remaining 30-40% hide in bullet lists, summary sections, one-liners, and behavioral descriptions.

---

## Extraction Template

```
### [Number]. [Working Name]
**Source:** [file, line, speaker]
**Type:** [Collapsed | Perceptual | Inversion | Domain-Transfer | Stance | Structural]
**Confidence:** [High | Medium | Low]
**A side (default):** [what people currently see/believe]
**B side (with distinction):** [what becomes visible — ATOMIC BINARY ONLY, no framework content]
**Cost of not having it:** [what's lost]
**Gain of having it:** [what opens up]
**Delivery Hook:** [concrete story/demo/moment from the source that would make this land]
**Score: [X/6]**
```

---

*Version: 2.0*
*Upgraded: February 13, 2026*
*Changes: Added implicit signal patterns (10 new), false positive library with 6 documented patterns, expanded extraction rules (3 new: #10-12), added audience calibration section, added confidence rating rules*
