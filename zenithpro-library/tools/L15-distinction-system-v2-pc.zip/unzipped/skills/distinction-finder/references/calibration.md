# Calibration Data — Batch Learnings from 392 Articles

> This file contains empirical data from a large extraction campaign (33 batches, 392 articles, 281 raw → 229 approved distinctions). Use it to calibrate expectations and catch patterns the Finder has historically missed.

---

## Yield Rates by Content Type

| Content Type | Articles | Confirmed | Per Article | Notes |
|-------------|----------|-----------|-------------|-------|
| Newsletter (AI/technical) | 392 | 281 raw | ~0.7 | High density — author writes in distinctions |
| Framework/methodology doc | 3 | 15 | ~5.0 | Highest density — concentrated teaching |
| Transcript (meeting) | TBD | TBD | TBD | Expected: 0.2-0.5 (buried in conversation) |
| Book notes | TBD | TBD | TBD | Expected: 1-3 (depends on author) |

**Calibration rule:** If you're extracting from a High-density source and finding fewer than 0.5 distinctions per article, you're probably missing implicit signals. Do a second pass focused on bullet lists and single-line principles.

---

## False Positive Rates

| Stage | Input | Output | Removed | Rate |
|-------|-------|--------|---------|------|
| Raw extraction | 392 articles | 281 confirmed | — | — |
| Deduplication | 281 | 253 unique | 28 | 10.0% |
| Finder Critic | 253 | 229 approved | 24 | 9.5% |
| — False positives | — | — | 13 | 5.1% |
| — Wrong audience | — | — | 11 | 4.3% |
| Borderline (pending) | — | 14 kept | — | 5.5% |

**What this means:** Expect roughly 1 in 20 extractions to be a false positive (not a real distinction) and another 1 in 25 to be wrong audience. The false positive guard in SKILL.md is designed to catch these before they reach the critic.

---

## Common Failure Patterns (Ranked by Frequency)

### 1. Missed Implicit Distinctions (~30-40% of total catch)
The explicit scan catches 60-70% of distinctions. The remaining 30-40% hide in:
- Bullet lists scanned as blocks
- Summary/principles sections treated as advice
- Single-line principles (the sharpest formulations, paradoxically)
- Behavioral evidence ("I stopped doing X")

**Fix:** The v2.0 workflow adds a dedicated implicit scan (Step 3) after the explicit scan.

### 2. Multiple Distinctions Per Section (~15% of sections)
About 15% of source sections contain 2+ independent distinctions. The Finder's habit is to extract one and move on.

**Fix:** The v2.0 workflow adds a multi-distinction check (Step 4).

### 3. Binary Filter Violations (~5% of confirmations)
13 out of 253 evaluated distinctions were false positives. Most common: 3-way taxonomies and frameworks dressed up with "vs" naming.

**Fix:** The v2.0 workflow adds a false positive guard (Step 6) with specific patterns documented from these failures.

### 4. Wrong Audience (~4% of confirmations)
11 out of 253 were valid distinctions aimed at the wrong audience.

**Fix:** The v2.0 workflow adds an audience calibration step (Step 7).

### 5. Type Misclassification (~3%)
The most common confusion: Collapsed vs Structural. The Finder types the framework instead of the distinction underneath.

**Fix:** The v2.0 types.md adds "commonly confused with" for each type plus a decision tree.

### 6. Confidence Underrating (~2%)
Explicit inversions rated Medium instead of High.

**Fix:** The v2.0 adds explicit confidence rating rules tied to source evidence.

---

## Distribution Baseline

### By Type (229 approved)
| Type | Count | % |
|------|-------|---|
| Perceptual | 67 | 29% |
| Collapsed | 66 | 29% |
| Inversion | 63 | 27% |
| Structural | 29 | 13% |
| Domain-Transfer | 2 | <1% |
| Stance | 2 | <1% |

**Red flags:** If your extraction produces >5% Domain-Transfer or >10% Stance, check classifications. These types are genuinely rare.

### By Gravity (232 gravity-scored)
| Gravity | Count | % | Meaning |
|---------|-------|---|---------|
| G1 | 42 | 18% | Lands cold — no prerequisites |
| G2 | 121 | 52% | Needs 1-2 prerequisites |
| G3 | 65 | 28% | Needs significant scaffolding |
| G4 | 4 | 2% | Capstone — needs full chain |

**Implication:** Most distinctions (52%) need 1-2 prerequisites to land. Only 18% can be taught standalone.

### By Audience (232 scored)
| Audience | Count | % |
|----------|-------|---|
| Both (owner + team) | 133 | 57% |
| Owner only | 73 | 31% |
| Team-applicable | 26 | 11% |

---

## Dedup Cluster Patterns

From 281 raw extractions, 28 duplicates were found (10% rate). The most common clustering patterns:

| Cluster Pattern | Count | Example |
|----------------|-------|---------|
| Same insight, different articles | 12 | Author revisits core themes across content |
| General + specific form | 8 | Broad principle + domain-specific instantiation |
| Parent + corollary | 5 | Core distinction + an implication that follows from it |
| Different angle, same shift | 3 | Two ways of framing the identical perceptual shift |

**The subsumption test catches parent+corollary clusters.** "If someone has A, do they automatically see B?" If yes, B is subsumed by A.

**The formulation test catches same-shift clusters.** "Do A and B describe the same perceptual boundary?" If yes, keep the sharper formulation.

---

*Created: February 13, 2026*
*Source: 33 batches (392 articles), Finder Critic Results, Approved Index, Gravity Index*
*Note: This file should be updated as new sources are extracted and new patterns emerge*
