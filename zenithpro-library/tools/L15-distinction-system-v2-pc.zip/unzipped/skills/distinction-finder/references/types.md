# Distinction Types — Quick Reference v2.0

## Type 1: Collapsed
Two different things treated as the same. Uncollapsing creates action space.
- **Signal:** "People confuse X with Y" / Same word, two meanings
- **Delivery key:** Show the COST of the collapse
- **Examples:** Freedom vs Relief, Strategy vs Tactics, Understanding vs Learning, Expertise vs Documentation
- **Commonly confused with:** Structural — when a framework reveals the collapse. The distinction is the collapse itself ("you're treating two things as one"), not the structure that reveals it.
- **Classification test:** "Would the phrase 'people confuse X with Y' or 'X and Y are NOT the same thing' capture the core insight?" If yes → Collapsed.

## Type 2: Perceptual
A new category that doesn't exist in the person's perceptual field.
- **Signal:** Expert sees something novice doesn't
- **Delivery key:** Name it so they see it everywhere
- **Examples:** Healthy vs sick tree, Stack layers, Owner vs Victim, Compounding Tool vs Static Tool
- **Commonly confused with:** Information — when the new category is described factually without the "now you'll see it everywhere" effect.
- **Classification test:** "After hearing this, will the person spontaneously notice examples in their daily work without being prompted?" If yes → Perceptual.

## Type 3: Inversion
A common assumption that's exactly backwards.
- **Signal:** "Everyone thinks X leads to Y" but X prevents Y
- **Delivery key:** Shock with the flip
- **Examples:** "Information is what's missing" (it's not — transformation is), "Confidence leads to action" (action leads to confidence)
- **Commonly confused with:** Advice — when the inversion is stated as a recommendation rather than a perceptual flip.
- **Classification test:** "Does this make the person's CURRENT assumption feel visibly backwards?" If yes → Inversion.

## Type 4: Domain-Transfer
Expert distinction from one domain applied to another.
- **Signal:** Expert domain maps perfectly to student's domain
- **Delivery key:** Make the analogy collapse into identity
- **Examples:** Architecture → AI leadership, Military force multiplier → Business AI
- **Commonly confused with:** Metaphor/illustration — a domain transfer is only a distinction when the CROSS-DOMAIN MAPPING is the insight itself.
- **Classification test:** "Is the cross-domain mapping itself the perceptual shift?" If the mapping IS the shift → Domain-Transfer.
- **Note:** This is the rarest type. When tempted to classify as Domain-Transfer, first check if it's really Inversion or Collapsed with a cross-domain illustration.

## Type 5: Stance
A distinction about WHERE you operate from, not what you do.
- **Signal:** Same situation, radically different results based on inner position
- **Delivery key:** Confront the current stance
- **Examples:** Overwhelmed vs Focused, Trying vs Committed, "How to" vs "Choose to"
- **Commonly confused with:** Advice — when the stance shift is framed as a recommendation.
- **Classification test:** "Does this change WHERE the person sees themselves operating, or just WHAT they do?" If where → Stance.

## Type 6: Structural
A distinction about how things connect — architecture, not content.
- **Signal:** Person sees pieces but misses the system
- **Delivery key:** Zoom out until the pattern appears
- **Examples:** Tool use vs System architecture, Tasks vs Pipelines, People vs Roles
- **Commonly confused with:** Collapsed — when the structural insight reveals hidden layers. If the A-side is "people see the pieces but miss how they connect," it's Structural.
- **Classification test:** "Does the shift come from seeing that two things are different (Collapsed), or from seeing how multiple things fit together into a system (Structural)?" System → Structural.

---

## Classification Decision Tree

When uncertain about type, work through this:

1. **Does it reveal that two things people treat as identical are actually different?** → Collapsed
2. **Does it flip a common assumption upside down?** → Inversion
3. **Does it create a new category the person will now see everywhere?** → Perceptual
4. **Does it change where the person operates from, not what they do?** → Stance
5. **Does it reveal how separate pieces connect into a system?** → Structural
6. **Does it import an insight from one domain to another, where the mapping IS the shift?** → Domain-Transfer

**If multiple types seem to fit:** Choose the type that best describes the DISTINCTION, not the framework or example used to deliver it.

---

## Distribution Baseline (from 229 Approved Distinctions)

| Type | Count | % | Notes |
|------|-------|---|-------|
| Perceptual | 67 | 29% | Most common |
| Collapsed | 66 | 29% | Nearly tied with Perceptual |
| Inversion | 63 | 27% | Very common in teaching content |
| Structural | 29 | 13% | Less common but high gravity |
| Domain-Transfer | 2 | <1% | Rare — be skeptical when tempted to use this type |
| Stance | 2 | <1% | Rare — often misclassified as Advice |

If your extraction is producing a distribution wildly different from this baseline, check your classifications.

---

*Version: 2.0*
*Upgraded: February 13, 2026*
*Changes: Added "commonly confused with" for each type, added classification tests, added decision tree, added distribution baseline*
