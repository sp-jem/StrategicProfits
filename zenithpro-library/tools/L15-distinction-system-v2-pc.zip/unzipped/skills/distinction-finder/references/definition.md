# What Is a Distinction — Quick Reference v2.0

A distinction is a **perceptual capacity created through language** that permanently alters what you can see — and therefore what you can do.

## Five Properties

1. **Perceptual, not informational** — changes seeing, not knowing
2. **Created in language** — the right words create new perceptual categories
3. **Binary at the core** — A vs Not-A; the boundary IS the distinction
4. **Irreversible once acquired** — like riding a bicycle
5. **Enables action without prescribing it** — shows what's there; you choose what to do

## The Hierarchy

```
DISTINCTIONS (atomic perceptual units)
    → MENTAL MODELS (connected sets)
        → FRAMEWORKS (structured systems)
            → METHODOLOGIES (complete operational systems)
```

## Key Quotes

> "Distinctions are not definitions or a new form of knowledge. They are tools to create the 'Now I see!' moment." — Djukich

> "Once you get it — like you get a joke — you don't have to think about it. It becomes a part of you." — Djukich

> "The number of distinctions you possess directly determines the number of opportunities you can perceive." — Rich Schefren

> "When you first used a hammer, did you have to believe in it?" — Djukich

---

## What Distinctions Are NOT (with False Positive Signatures)

Each category below includes the telltale signs that help catch it masquerading as a distinction.

### Information
A fact about the world that doesn't change perception.
- **Signature:** You learn something new but don't see your own situation differently.
- **Example:** "AI can process 1000x more data than humans"
- **Test:** "After hearing this, do I see my daily work differently?" If no → Information.

### Advice
A prescription for action.
- **Signature:** Contains "you should," "try," or "consider doing." Prescribes behavior rather than shifting perception.
- **Example:** "You should use Python for data work"
- **Test:** "Does this tell me what to DO, or does it change what I SEE?" If do → Advice.
- **Common disguise:** Framed as "X vs Y" where one side is clearly the "right answer" and the other is the "wrong answer." Real distinctions show you two genuine perceptual states; advice dressed as distinction shows you the "before" (wrong) and "after" (right).

### Mechanism
An explanation of HOW something works.
- **Signature:** Contains technical process description, causal chains, or system internals.
- **Example:** "Trained Incapacity" (explains how expertise becomes limitation)
- **Test:** "Does this explain a process, or does it create a perceptual shift?" A mechanism CAN become a distinction when the person can spot it in real time in their own behavior — but the mechanism itself isn't the distinction.
- **Common disguise:** Technical concepts named with "vs" (e.g., "Stateless Processing vs. Stateful Intelligence") that describe how systems work, not how the listener sees differently.

### Framework
A structured system built FROM multiple distinctions.
- **Signature:** Contains 3+ named components, steps, or categories. Describes a system, not a binary.
- **Example:** "The 4 Ps of Marketing"
- **Test:** "Can I decompose this into multiple independent perceptual shifts?" If yes → Framework. Extract the individual distinctions instead.
- **Common disguise:** A distinction whose B-side describes a multi-part system (e.g., "You see five discrete layers"). The B-side should describe the BINARY SHIFT, not enumerate the framework.

### Technique
A procedural method.
- **Signature:** Contains steps, instructions, or a process to follow.
- **Example:** "Use the STAR method for interviews"
- **Test:** "Is this about what to DO (steps) or what to SEE (perception)?" If steps → Technique.

### Observation
A true fact about trends or patterns that doesn't shift personal perception.
- **Signature:** Describes what's happening "out there" without changing how the listener sees their own situation.
- **Example:** "AI adoption is accelerating" / "Most companies are failing at AI"
- **Test:** "Does this change how I perceive my own business, or is it a comment about the market?" If market → Observation.
- **Common disguise:** Framed as "X vs Y" where both sides describe market conditions rather than personal perceptual states.

---

## The Binary Filter — Critical Gate

**This is the #1 false positive pattern.** From 253 evaluated distinctions, the binary filter caught more false positives than any other test.

### The Rule
A distinction must be expressible as a clean A vs B with a boundary between them.

### What Fails
- **3+ categories:** "X vs Y vs Z" — if there are three or more sides, it's a taxonomy, not a distinction
- **Spectrum/continuum:** If A and B are endpoints on a sliding scale with no clear boundary
- **No clear A side:** If you can't articulate what the person currently believes/sees BEFORE the distinction, the binary isn't clean
- **Framework B-side:** If the B-side requires enumerating 4+ components to make sense

### What Passes
- Clean A vs B with a visible boundary
- A vs B where most people are on A and the distinction moves them to B
- A vs B where the boundary IS the insight ("oh, these are two different things!")

---

*Version: 2.0*
*Upgraded: February 13, 2026*
*Changes: Added false positive signatures for each "not a distinction" category, added common disguises, added the Binary Filter as a dedicated critical gate section*
