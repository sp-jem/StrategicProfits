---
name: distinction-expander
description: Takes a raw distinction (from the Distinction Finder or manual input) and builds a complete teaching unit — gap setup, contrast delivery, naming, application design, and reinforcement plan. Use when you need to turn a raw distinction into something that will actually LAND with students. Outputs to your Distinctions folder.
---

# Distinction Expander v2.1

> **Purpose:** Transform a raw distinction into a fully designed teaching unit that produces a genuine perceptual shift — not just intellectual understanding.

## Reference Documents

Before first use, read:
- `references/landing-sequence.md` — The six-step sequence for making distinctions stick
- `references/delivery-by-type.md` — How delivery changes based on distinction type
- `references/your-patterns.md` — Your delivery patterns (customize this file for your voice)
- `references/richs-patterns-EXAMPLE.md` — Rich Schefren's delivery patterns (included as a reference example)

## Hard Constraints (v2.0 — Critic-Validated)

These constraints are non-negotiable. They come from 17 critic evaluations identifying recurring failures.

### C1: Flash Length Cap
Flash sections contain ONE primary example and at most ONE backup angle. Total Flash length must NOT exceed the Gap section length. If your Flash has more than two examples, you have violated this constraint. Delete until you have one story and one backup.

### C2: Flash Structure — Three-Act Story
The default Flash architecture is a three-act story where the student commits to the wrong answer:
- **Act 1:** Setup — the situation
- **Act 2:** The student's instinct (which is wrong) — they see themselves in this
- **Act 3:** Reveal — why their instinct created a WORSE problem

If a personal artifact exists (like a CLAUDE.md file, a system, a document), build the Flash around SHOWING the artifact and asking a pivot question that forces the student to test the distinction against their own experience. The answer to that question IS the flash.

### C3: No Five-Example Cascades
The "5 parallel case studies" pattern is BANNED in Flash sections. It produces agreement, not revelation. One story told with full emotional depth lands harder than five told as summaries.

### C4: Contrast Maximum — 3 Pairs
Contrast sections contain a maximum of three parallel A/B pairs plus one summation ("money line").

### C5: Application Leads with 24-Hour Action
The first element in every Application section is a concrete action the student does RIGHT NOW, before continuing. Requirements:
- Takes 5-10 minutes
- Produces a tangible artifact (a list, a map, a template — NOT a thought)
- Applies the distinction to the student's ACTUAL situation
- Is phrased as "Do this now, before you read further"

### C6: Exercises Produce Artifacts, Not Thoughts
Every application exercise must result in something the student can see, share, or revisit. "Ask yourself..." prompts without written output are prohibited.

### C7: Reinforcement is Designed Mechanics, Not Speeches
Every Reinforcement section must include:
1. **One daily environmental trigger** — fires on something the student encounters every day
2. **One peer mechanism** — specific prompt for sharing with team
3. **One program callback** — reference to a specific program day/module where this distinction resurfaces

Rhetorical paragraphs explaining why the distinction matters are BANNED in Reinforcement.

### C8: Name Section — 15 Lines Maximum, Weapon-Grade Quality
The Name section contains: the label, the sub-name (if any), one sentence of framing, the diagnostic question, and the usage pattern. Nothing else.

**The name must pass three tests:**
1. **Headline test:** Would this stop someone mid-scroll?
2. **Juxtaposition test:** Do you feel the tension between A and B before reading any explanation?
3. **Functional label check:** If the name merely DESCRIBES the distinction, it fails. Push past the descriptive name to find the one that hits.

### C9: Total Unit Length — 250-350 Lines
Hard cap. This forces tighter editing and eliminates redundancy.

### C10: Voice Guard — No Borrowed Terminology, No Safe Language
Replace academic, technical, or other-people's terminology with language native to you and your audience.

**Voice failures to watch for:**
- **"Correct but forgettable"** — Language that accurately describes but doesn't hit.
- **"Teaching voice" where "bar room voice" is needed** — Academic explanation vs. a friend explaining something that changed how they see the world.
- **"Consultant-speak results"** — Sanitized language that could apply to anything.
- **Generic phrasing** — If you swap in a different distinction name and the sentence still works, it's generic.

### C11: Microscript Attempt — First-Draft Viral Compression
Every teaching unit must include ONE microscript attempt: a ~5-8 word compression of the distinction that someone would naturally repeat to a friend. This is a DRAFT.

**The test:** Could someone say this at a dinner party and make the table stop?

### C12: Money Line Forge — Word-Level Craft Check
The money line in the Contrast section must pass a word-level craft check:

1. **Kill past tense** — Present tense hits harder.
2. **Kill dead articles** — Remove unnecessary "the."
3. **Kill weak/repeated verbs** — Use different, stronger verbs.
4. **Kill generic nouns** — Replace with specific, visceral words.
5. **Find rhythm** — Alliteration, parallel structure, or natural cadence.
6. **Compression test** — Can you remove a word without losing meaning?

**The standard:** "You're in good hands with Allstate." Can't take out a word. That's the target.

---

## Workflow

### Input

One of:
1. **A confirmed extraction** from the Distinction Finder (structured format)
2. **A raw distinction statement** (e.g., "Strategy vs tactics — most people collapse these")
3. **A distinction name + context** (e.g., "Owner vs Victim from Djukich, applied to AI adoption")

### Step 1: Understand the Raw Material

If coming from the Finder, read the full extraction. If manual input, first qualify it:
- Can it be expressed as A vs B?
- Is it perceptual (changes seeing, not just knowing)?
- What type is it? (Collapsed, Perceptual, Inversion, Domain-Transfer, Stance, Structural)

### Step 2: Build the Teaching Unit

Produce ALL six components of the landing sequence:

#### Component 1: THE GAP (Setup)

Design the moment BEFORE the distinction is named. The student must FEEL the absence.

Choose one gap strategy:
- **The Unanswerable Question** — Ask something that requires the distinction to answer.
- **The Recognized Failure** — Reference a common breakdown the audience has lived through.
- **The Expert Mystery** — Point to something an expert does effortlessly that they can't explain.

**Gap timing rule:** Do NOT reveal the distinction in the Gap.

```markdown
**Gap Strategy:** [Unanswerable Question | Recognized Failure | Expert Mystery]

**The Setup:**
[Actual script/framing — what you would say to create the gap]

**Expected Student State After Setup:**
[What the student is feeling/thinking — the felt absence]
```

#### Component 2: THE CONTRAST (Core Delivery)

The A vs B, delivered clean and binary. Maximum 3 parallel pairs + summation.

```markdown
**A Side (Default):** [What they currently see/believe — in their language]
**B Side (Distinction):** [What becomes visible — concrete, not abstract]
**The Sharpest Framing:**
[One sentence that captures the contrast with maximum clarity. This is the "money line."]
```

#### Component 3: THE FLASH (The "Now I See" Moment)

Design what produces the spontaneous recognition. This is ONE moment, not a chapter.

**Default architecture: Three-Act Story** (see Constraint C2)

```markdown
**Flash Architecture:** [Three-Act Story | Pivot Question]

**The Delivery:**
[Full script/narrative — ONE story with emotional specificity]

**Backup Angle:**
[5-7 lines, different entry point for a different audience segment]

**Signs It Landed:**
[What to watch for — specific behavioral indicators]
```

#### Component 4: THE NAME (Anchor)

Maximum 15 lines. Label it and move on.

```markdown
**Primary Name:** [2-4 words, captures the A vs B]
**Sub-Name:** [Optional — a "handle" version for casual use]
**Diagnostic Question:** [One question that invokes the distinction]
**Usage Pattern:** "That's a [Name] situation" or "Are you doing [A] or [B]?"
```

**Microscript (draft):**
[One ~5-8 word compression. See C11.]

#### Component 5: THE APPLICATION (Making It Stick)

**FIRST:** The 24-hour action. Before anything else.

```markdown
**Immediate Action (Do This Now):**
[Concrete, 5-10 minutes, produces a tangible artifact, applies to student's actual situation]
```

**THEN:** Two additional application moves:

```markdown
**Application 1 — Self-Diagnosis:**
[Prompt that forces identification of WHERE they've been on the wrong side — produces a written list]

**Application 2 — Teach It:**
[Script for explaining this to a partner/team member + quality check for their response]
```

#### Component 6: THE REINFORCEMENT (Preventing Fade)

No speeches. Only designed mechanics.

```markdown
**Daily Trigger:**
[Something the student encounters every day that forces the distinction to surface.]

**Peer Mechanism:**
[Specific prompt for THIS distinction's conversational entry point]

**Program Callback:**
[Specific program day/module where this distinction resurfaces and gets tested under pressure]

**Language Signals:**
[3-5 before/after phrase pairs showing integrated vs. collapsed language]

**Integration Check (30 days):**
[3-4 behavioral questions that cannot be faked with intellectual understanding]
```

### Step 3: Delivery Mode Selection

Based on the distinction type and program context:

| Mode | Best For | Context |
|------|----------|---------|
| Live Demo | Structural, Domain-Transfer | Days when you build live |
| Story + Reveal | Inversion, Stance | Opening sessions, paradigm shifts |
| Facilitated Discovery | Collapsed, Perceptual | Team exercise days |
| Direct Confrontation | Stance | VIP/coaching sessions |

### Step 4: Output

Write the complete teaching unit to:

```
$VAULT_PATH/Distinctions/by-source/[source-name]/expanded/[distinction-name].md
```

### Step 5: Self-Audit Before Submission

Before finalizing, run this checklist:

- [ ] Flash section has ONE primary example (not 2, not 3, not 5)
- [ ] Flash section is shorter than or equal to Gap section
- [ ] Contrast has 3 or fewer parallel pairs
- [ ] Application opens with a "do this now" 24-hour action
- [ ] Every exercise produces a written artifact (no pure "ask yourself" prompts)
- [ ] Reinforcement has a daily trigger, peer mechanism, and program callback
- [ ] Reinforcement contains NO rhetorical paragraphs about why this matters
- [ ] Name section is 15 lines or fewer
- [ ] Name is NOT a functional label — passes headline + juxtaposition tests (C8)
- [ ] Microscript attempt included — ~5-8 words, dinner party test (C11)
- [ ] Money line has been forged — no past tense, no dead articles, compression tested (C12)
- [ ] Total unit is 250-350 lines
- [ ] No borrowed terminology
- [ ] No "correct but forgettable" language — every sentence earns its place
- [ ] Voice check: reads like YOU teaching in a room, not a textbook
- [ ] Gap does NOT preview the answer
- [ ] Share test: would someone forward this to a friend unprompted?

## Quality Standards

### The Landing Test
Read the complete teaching unit and ask: "If I delivered this exactly as written to a room of 50 people in my audience, how many would GET IT?" Target: 35+ out of 50.

### The Djukich Hammer Test
"When you first used a hammer, did you have to believe in it?" If belief is required, the unit isn't tool-shaped yet.

### The Fade Test
"Will this distinction be active in 30 days without re-teaching?" If no, the Reinforcement lacks daily triggers.

### The Share Test
"Would someone read this and feel compelled to share it with a friend — unprompted?"

### The Functional Label Test
"Is this a functional description, or does it hit like a headline?"

## Critic Integration

After each expansion, submit to `distinction-expander-critic` for evaluation. The critic scores across six dimensions:
- Gap Quality (20%)
- Contrast Sharpness (20%)
- Flash Design (20%)
- Name Quality (10%)
- Application Design (15%)
- Reinforcement Design (15%)

Plus Voice Check (+1/0/-1 adjustment).

**Threshold: 8.0+ adjusted = SHIP. Below 8.0 = REVISE.**

## Batch Mode

When expanding multiple distinctions:
1. Process in dependency order (prerequisites first)
2. Track cross-references (distinctions that reinforce each other)
3. Map to program days to ensure balanced distribution
4. Each unit gets unique reinforcement — no recycled prompts across units
5. Produce a curriculum map showing distinction flow across the program

---

*Version: 2.1*
*Updated: February 13, 2026 — Integrated production learnings (28 distinctions): C8 upgraded (weapon-grade naming), C10 expanded (voice failures), C11 added (microscript attempt), C12 added (money line forge), Share Test + Functional Label Test added to quality standards*
