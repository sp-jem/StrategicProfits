# The Landing Sequence — Quick Reference (v2.1)

Six steps, in order. Skip none.

## Step 1: THE GAP (Setup)
Create the felt absence BEFORE naming the distinction.

**Three strategies:**
- **Unanswerable Question** — Ask something requiring the distinction to answer
- **Recognized Failure** — "Have you ever done X and gotten a result you didn't expect?"
- **Expert Mystery** — "What does that person see that you don't?"

**Timing rule:** Do NOT reveal the distinction in the Gap. Hold the tension for 60-90 seconds. If the Gap previews the answer, the Contrast loses its edge. The student should commit to the wrong answer before you show them why it's wrong.

**Output:** Script of what you would say. Expected student state after.

**Quality check:** The gap must CREATE the felt absence, not DESCRIBE it. "Many business owners confuse doing work with designing workflows" describes. "You spent ten years getting fast at the work. You never once stopped to see the decisions inside it." creates. If your gap reads like a problem statement, rewrite it as an experience.

## Step 2: THE CONTRAST (Core)
A vs B, binary, no nuance, no qualifications. **Maximum 3 parallel pairs + summation.**

**Rules:**
- A side = student's current language
- B side = concrete, visualizable
- "Money line" = one sentence capturing the contrast — quotable, portable, screenshot-worthy
- 3 pairs maximum. Pattern is obvious after 2; 3rd confirms. Extra pairs → Application.
- **Money line forge:** After writing the money line, apply the forge checklist. Kill past tense, dead articles, weak verbs, generic nouns. Find alliteration and rhythm. Test: can you remove a word? The standard: "You're in good hands with Allstate." Can't take out a word.

> "Dramatic, graphic opposites. No wiggle room." — Djukich

## Step 3: THE FLASH (The Moment)
The "Now I see!" moment. **ONE story, not a chapter.** Cannot be forced — only set up.

**Default: Three-Act Story**
- Act 1: Setup — the situation
- Act 2: Student's instinct plays out (wrong) — they identify with this
- Act 3: Reveal — their instinct was the actual problem

**Alternative: Pivot Question** (when artifact exists)
- Show the artifact → Ask the question → Student's own answer IS the flash

**Backup:** ONE alternate angle (5-7 lines) for students the primary misses.

**BANNED:** Five-example cascades. If you have 5 examples, you have 4 too many for Flash. Put the extras in Application.

**Self-check:** If Flash ends with "See it now?" or "Welcome to the other side" — delete it. Announced epiphanies aren't epiphanies.

**Signs it landed:** Sudden silence, laughter, "oh shit," immediate self-example
**Signs it didn't:** Nodding, note-taking, "that makes sense," moving on without pause

## Step 4: THE NAME (Anchor)
Give it a name IMMEDIATELY after the flash. **15 lines maximum.**

**Rules:** 2-4 words (max 7), embeds contrast, self-explanatory, usable in conversation
**Pattern:** "That's a [Name] situation" / "Are you doing [A] or [B]?"

**Quality tests:**
- **Bar test:** Would someone use this phrase 3 beers into a conversation?
- **Headline test:** Would this stop someone mid-scroll?
- **Juxtaposition test:** Do you feel the A vs B tension before reading explanation?
- **Functional label check:** If the name merely describes the distinction, push harder. "Doing Work vs. Designing Workflow" describes. "Expert Amnesia" performs.

**Microscript (draft):** After the name, include ONE ~5-8 word compressed version — a sentence someone would repeat at dinner that makes them sound smart. This is a draft. Example: "Knew every task. Couldn't name one decision."

Do NOT re-teach the distinction in the Name section. Label it and move on.

## Step 5: THE APPLICATION (Cement)
**FIRST:** 24-hour action — concrete, 5-10 minutes, produces artifact. "Do this now, before you continue."

**THEN:** Two moves:
1. **Self-Diagnosis** — Where in YOUR business are you on the wrong side? (produces a written list)
2. **Teach It** — Explain to a partner. Teaching = strongest consolidation. Include quality check.

**Rule:** Every exercise produces an artifact (list, map, template). No "ask yourself" prompts without written output.

## Step 6: THE REINFORCEMENT (Prevent Fade)
No speeches. Only designed mechanics.

- **Daily trigger** — tied to existing behavior (task list, inbox, calendar). Fires every day.
- **Peer mechanism** — specific to THIS distinction's conversational entry point. Not generic "share with 3 people."
- **Program callback** — specific program day/module where distinction resurfaces under pressure
- **Language signals** — 3-5 before/after phrase pairs
- **Integration check (30 days)** — behavioral questions that can't be faked with intellect

**BANNED:** Rhetorical paragraphs about why the distinction matters. The Flash made the case. Reinforcement engineers contact, not argument.
