# Your Teaching Patterns — Template

> **Instructions:** Fill in each section with YOUR teaching patterns. The Distinction Expander uses this file to match teaching units to your voice. See `richs-patterns-EXAMPLE.md` for a completed example.

## Pattern 1: [Name Your Primary Pattern]
[How do you typically introduce new ideas? Do you tell stories first? Ask questions? Show demonstrations? Describe your default approach here.]

## Pattern 2: [Name Your Second Pattern]
[What's your go-to structure when the first approach isn't right? Describe it.]

## Pattern 3: [Name Your Third Pattern]
[Add more patterns as needed. Most teachers have 3-6 recurring delivery patterns.]

---

## Your Voice Markers
- [How would students describe your teaching style?]
- [What words/phrases do you naturally repeat?]
- [Are you direct? Gentle? Confrontational? Story-driven? Data-driven?]
- [Do you use humor? Analogies? Personal stories?]
- [What makes YOUR teaching voice recognizable?]

## Voice Anti-Patterns (What Doesn't Sound Like You)
- [What language would sound wrong coming from you?]
- [What teaching styles are NOT yours?]
- [What phrases would your students find jarring or inauthentic?]

---

## Word-Level Forge Checklist

Apply this to money lines, names, and any sentence that needs to hit hard.

### Step 1: Kill Dead Weight
- **Past tense → Present tense.** "The answer came fast" → "Answers come fast."
- **Kill dead articles.** Remove unnecessary "the."
- **Kill weak/repeated verbs.** Use different, stronger verbs.
- **Kill generic nouns.** Replace with specific, visceral words.

### Step 2: Add Power
- **Find alliteration.** "Rot runs deep" — the R/R makes it stick.
- **Find natural phrases.** Use expressions people already say.
- **Find rhythm.** Short sentence. Short sentence. Longer sentence that resolves.
- **Find compression.** Can you remove a word? No? Done.

### Step 3: Test
- **Mouth test:** Say it out loud. Does it flow?
- **Bar room test:** Would someone say this 3 beers in?
- **Removal test:** Can you take out any word without losing meaning?
- **Screenshot test:** Would someone screenshot this and text it to a friend?

---

**The rule:** If the teaching unit doesn't sound like YOU said it, rewrite it.
