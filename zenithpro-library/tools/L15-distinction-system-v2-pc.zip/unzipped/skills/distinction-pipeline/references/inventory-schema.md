# Master Inventory Schema

> Three axes. Every distinction is tracked across all three.

---

## The Three Axes

### Axis 1: Idea Validation
**Question:** Is this a real distinction?

| Field | Values | Set By |
|-------|--------|--------|
| `qualification_score` | 0-6 (six-filter test) | Finder |
| `finder_critic_verdict` | PASS / REVISE / REDO | Finder Critic |
| `finder_critic_score` | 0.0-10.0 (weighted) | Finder Critic |
| `false_positive_flags` | List of triggered patterns, or "clean" | Finder |
| `confidence` | High / Medium / Low | Finder |
| `audience_fit` | High / Medium / Low / Deferred | Finder |

**Minimum to advance:** qualification_score >= 5, finder_critic_verdict = PASS, audience_fit != Deferred

### Axis 2: Expression Power
**Question:** Is the language powerful enough to land?

| Field | Values | Set By |
|-------|--------|--------|
| `expander_critic_score` | 0.0-10.0 (weighted) | Expander Critic |
| `expander_critic_verdict` | SHIP / REVISE / REBUILD | Expander Critic |
| `voice_adjustment` | +1 / 0 / -1 | Expander Critic |
| `adjusted_score` | score + voice_adjustment | Expander Critic |
| `name_quality` | weapon / functional_label / pending | Expander Critic |
| `microscript` | The draft microscript text, or "pending" | Expander |
| `money_line` | The forged money line text, or "pending" | Expander |
| `polisher_status` | not_started / in_progress / complete | Polisher |
| `polisher_score` | 0-10, or null | Polisher |

**Minimum to ship:** adjusted_score >= 8.0, name_quality != functional_label

### Axis 3: Curriculum Placement
**Question:** Where does this go in your program?

| Field | Values | Set By |
|-------|--------|--------|
| `program_day` | 1-10 (or however your program is structured), or "unassigned" | Curriculum mapping |
| `session_position` | opening / middle / closing, or "unassigned" | Curriculum mapping |
| `prerequisites` | List of distinction IDs that must land first | Expander / Manual |
| `gravity` | anchor / supporting / enrichment | Curriculum mapping |
| `domain` | Customize to your program's domains | Finder |
| `pillar` | Customize to your program's pillars | Manual |
| `delivery_mode` | live_demo / story_reveal / facilitated_discovery / direct_confrontation | Expander |

**Gravity definitions:**
- **anchor** — This distinction IS the session. The day is designed around it. Max 1-2 per day.
- **supporting** — Reinforces or extends an anchor. Can't stand alone but deepens the session.
- **enrichment** — Valuable but not load-bearing. Can be cut without damaging the day's arc.

---

## Core Identity Fields

Every distinction record includes:

| Field | Description | Set By |
|-------|-------------|--------|
| `id` | Unique ID: `[source]-[batch]-[number]` (e.g., `nj-b01-003`) | Pipeline |
| `name` | Current working name | Finder (initial), Expander (refined) |
| `type` | Collapsed / Perceptual / Inversion / Domain-Transfer / Stance / Structural | Finder |
| `a_side` | The default/current view | Finder |
| `b_side` | The distinction view | Finder |
| `source` | Source identifier (e.g., "nate-jones", "dan-sullivan") | Pipeline |
| `batch` | Batch identifier | Pipeline |
| `source_file` | Path to original source material | Finder |
| `extraction_file` | Path to extraction output | Pipeline |
| `teaching_unit_file` | Path to expanded teaching unit | Pipeline |
| `critique_file` | Path to latest critic evaluation | Pipeline |

---

## Status Tracking

| Field | Values | Description |
|-------|--------|-------------|
| `stage` | extracted / critic_approved / expanded / shipped / polished / placed | Current pipeline position |
| `quality_flag` | clean / revision_capped / needs_review / borderline | Any quality concerns |
| `dedup_status` | unique / duplicate_of:[id] / subsumes:[id] / subsumed_by:[id] | Deduplication result |
| `last_updated` | Date | When this record was last modified |

---

## Inventory File Format

The master inventory lives at:
```
$VAULT_PATH/Distinctions/MASTER-INVENTORY.md
```

### Header Section

```markdown
# Master Distinction Inventory

**Last Updated:** [date]
**Total Entries:** [N]
**By Stage:** extracted [N] | critic_approved [N] | expanded [N] | shipped [N] | polished [N] | placed [N]
**By Source:** [source]: [N] | [source]: [N] | ...

---
```

### Summary Table

The summary table provides the at-a-glance view. One row per distinction, sorted by source then ID.

**Column format (abbreviation → full name in legend):**

```markdown
## Inventory

| ID | Name | Src | Type | Stg | QS | FCS | ECS | Day | Grav | Flag |
|----|------|-----|------|-----|----|-----|-----|-----|------|------|
```

**Legend:**
- **ID** — Unique identifier
- **Name** — Working name (truncated to 40 chars in table; full name in detail record)
- **Src** — Source abbreviation
- **Type** — C=Collapsed, P=Perceptual, I=Inversion, DT=Domain-Transfer, St=Stance, Str=Structural
- **Stg** — Stage: ext=extracted, ca=critic_approved, exp=expanded, shp=shipped, pol=polished, pla=placed
- **QS** — Qualification Score (0-6)
- **FCS** — Finder Critic Score (0.0-10.0)
- **ECS** — Expander Critic adjusted score (0.0-10.0+voice)
- **Day** — Program day (1-10 or "-")
- **Grav** — Gravity: A=anchor, S=supporting, E=enrichment, "-"=unassigned
- **Flag** — Quality flag: clean="", rc=revision_capped, nr=needs_review, bl=borderline

### Detail Records

Below the summary table, each distinction has a full record:

```markdown
---

### [ID]: [Full Name]

**Type:** [full type name]
**Source:** [source] / [batch] / [source file]
**Stage:** [current stage]
**Last Updated:** [date]

**Idea Validation:**
- Qualification: [X/6]
- Finder Critic: [verdict] ([score])
- Confidence: [level]
- Audience Fit: [level]
- False Positive Flags: [flags or "clean"]

**Expression Power:**
- Expander Critic: [verdict] ([score], voice: [adj])
- Name Quality: [weapon/functional_label/pending]
- Microscript: [text or "pending"]
- Money Line: [text or "pending"]
- Polisher: [status]

**Curriculum Placement:**
- Day: [N or "unassigned"]
- Position: [position or "unassigned"]
- Gravity: [level or "unassigned"]
- Domain: [domain]
- Pillar: [pillar]
- Prerequisites: [list or "none"]
- Delivery Mode: [mode]

**A Side:** [current view]
**B Side:** [distinction view]

**Files:**
- Extraction: [path]
- Teaching Unit: [path]
- Critique: [path]

**Dedup:** [status]
**Quality Flag:** [flag]
```

---

## Update Rules

1. **Never delete an entry.** Mark duplicates with `dedup_status` and `stage: subsumed_by:[id]`.
2. **Always update `last_updated`** when changing any field.
3. **Stage can only advance forward** (extracted → critic_approved → expanded → shipped → polished → placed). Never move backward.
4. **Quality flags are sticky** — once flagged, it stays flagged until explicitly cleared by review.
5. **Cross-source duplicates:** When two sources produce the same distinction, keep both records. Link them with `dedup_status: duplicate_of:[id]`. Note which formulation is stronger.
6. **The summary table and detail records must stay in sync.** If you update a detail record, update the summary table row too.

---

## Source Abbreviations

| Source | Abbrev | ID Prefix |
|--------|--------|-----------|
| (Add your sources here) | | |

New sources get a 2-3 letter abbreviation added to this table.

---

*Version: 1.0*
*Created: February 13, 2026*
