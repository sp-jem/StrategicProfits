---
name: distinction-pipeline
description: End-to-end distinction pipeline. Takes a source (file or folder), runs Find → Finder Critic → Expand → Expander Critic, updates the master inventory. One command, full chain. Use when processing source material into production-ready teaching units.
---

# Distinction Pipeline v1.0

> **Purpose:** Run the complete distinction system in one command. Source material in, quality-gated teaching units + inventory updates out.

## Reference Documents

Before first use, read:
- `references/inventory-schema.md` — Master inventory structure and update rules

The pipeline also loads these skill/agent references at each stage:
- **Stage 1:** `~/.claude/skills/distinction-finder/SKILL.md` + all `references/`
- **Stage 2:** `~/.claude/agents/distinction-finder-critic/AGENT.md`
- **Stage 3:** `~/.claude/skills/distinction-expander/SKILL.md` + all `references/`
- **Stage 4:** `~/.claude/agents/distinction-expander-critic/AGENT.md`

---

## Input

The user provides one of:

| Input | What Happens |
|-------|-------------|
| **A file path** | Process that single file through the full pipeline |
| **A folder path** | Process all eligible files in the folder |
| **Multiple folders** | Process all folders in sequence. Cross-source dedup after all complete. |
| **"batch"** | Resume from wherever the PROCESSING-TRACKER left off |
| **A list of distinction names** | Skip Stage 1-2, start at Stage 3 (expand already-extracted distinctions) |

Optional flags (user can specify):
- **`--find-only`** — Run Stages 1-2 only (extract + critic). Stop before expansion.
- **`--expand-only`** — Run Stages 3-4 only. Requires extracted distinctions as input.
- **`--no-critic`** — Skip critic stages. (Not recommended. For speed runs only.)
- **`--dry-run`** — Show what would be processed without doing it.

---

## Multi-Folder Mode

When the user provides multiple folders:

### Before Starting

1. **List all folders and derive source names.** Present a confirmation table:

```markdown
## Pipeline Job: [N] Sources

| # | Folder | Source Name | Est. Files | Status |
|---|--------|-------------|-----------|--------|
| 1 | [folder path] | [source-name] | [count] | pending |
| 2 | [folder path] | [source-name] | [count] | pending |

Proceed with all [N] sources? (Will run until complete or context limit.)
```

If the user confirms, begin. If they adjust source names or remove folders, apply changes.

### Execution Order

Process sources **one at a time, fully** (all 5 stages per source) before moving to the next. This ensures each source's extractions are critic-approved before cross-source dedup.

```
Source 1: Find → Critic → Expand → Critic → Inventory
Source 2: Find → Critic → Expand → Critic → Inventory
Source 3: Find → Critic → Expand → Critic → Inventory
→ Cross-Source Dedup (subsumption test across all sources)
→ Final Inventory Update
→ Combined Pipeline Summary
```

### Context Window Strategy

Multi-folder jobs will likely exceed a single context window. The pipeline handles this:

1. **After completing each source**, save a checkpoint:
   ```
   $VAULT_PATH/Distinctions/pipeline-checkpoint.md
   ```
   Contains: which sources are done, which remain, cross-references found so far.

2. **At 70% context capacity**, stop processing and produce a handoff document:
   ```markdown
   ## PIPELINE HANDOFF
   **Job:** [description]
   **Completed:** Sources 1-2 of 5
   **Current source:** Source 3, Stage 2 (Finder Critic)
   **Remaining:** Sources 3-5
   **Checkpoint:** $VAULT_PATH/Distinctions/pipeline-checkpoint.md
   **To resume:** "Resume the distinction pipeline" (reads checkpoint automatically)
   ```

3. **On resume**, read `pipeline-checkpoint.md` and continue from where it left off. Do not reprocess completed sources.

### Cross-Source Deduplication

After ALL sources complete, run a final cross-source dedup:

1. Load all confirmed distinctions from all sources
2. For each pair of similar-sounding distinctions across sources:
   - Run the subsumption test: "If someone has Distinction A, do they automatically see B?"
   - If yes: link them in inventory with `dedup_status: duplicate_of:[id]`
   - Note which formulation is stronger
3. Update inventory with cross-source links
4. Produce a cross-source dedup report

### Combined Summary

After all sources + cross-source dedup, produce one combined summary:

```markdown
# Pipeline Job Summary

**Date:** [date]
**Sources processed:** [N]
**Total runtime:** [sessions if multi-session]

## Per-Source Results

| Source | Files | Extracted | Approved | Expanded | Shipped | Deferred |
|--------|-------|-----------|----------|----------|---------|----------|

## Cross-Source Deduplication
- Cross-source duplicates found: [N]
- Unique distinctions after dedup: [N]

## Inventory Impact
- New entries: [N]
- Total inventory: [N]

## Files Created
[All output files across all sources]
```

---

## Pipeline Stages

### Stage 1: FIND — Distinction Extraction

**Tool:** Distinction Finder v2.0 (`~/.claude/skills/distinction-finder/SKILL.md`)

1. Read the Finder SKILL.md and all references
2. Process source material through the 10-step Finder workflow
3. Output extraction to: `$VAULT_PATH/Distinctions/by-source/[source-name]/extractions/[extraction-name].md`
4. Update PROCESSING-TRACKER.md

**Output per source:** Structured extraction file with Confirmed, Needs Refinement, Rejected, and Deferred buckets.

**Pass-through to Stage 2:** Only Confirmed candidates (score 5-6/6) advance.

---

### Stage 2: FIND CRITIC — Extraction Quality Gate

**Tool:** Task tool → `subagent_type: "distinction-finder-critic"`

Spawn the critic as a sub-agent with this context:

```
Evaluate the following distinction extraction for accuracy, completeness,
classification quality, A/B sharpness, audience relevance, and deduplication.

Source: [source file path]
Extraction: [extraction file path]

Read the extraction file and the original source material. Score across
all 6 dimensions. Produce a full evaluation with PASS/REVISE/REDO verdict.
```

**Decision logic:**

| Verdict | Action |
|---------|--------|
| **PASS** (7.0+) | Advance all confirmed candidates to Stage 3 |
| **REVISE** (5.0-6.9) | Re-run Finder on flagged items only, incorporating critic notes. Then re-evaluate. Max 2 revision cycles. |
| **REDO** (below 5.0) | Re-extract entire source with adjusted approach based on critic feedback. Max 1 redo. |

**Output:** Critic evaluation file saved to `by-source/[source]/extractions/[name]-critique.md`

**Inventory update:** After PASS, register all confirmed candidates in the master inventory with `stage: extracted`, `idea_validation: critic_approved`.

---

### Stage 3: EXPAND — Teaching Unit Construction

**Tool:** Distinction Expander v2.1 (`~/.claude/skills/distinction-expander/SKILL.md`)

For each confirmed, critic-approved distinction:

1. Read the Expander SKILL.md and all references
2. Build the complete 6-component teaching unit (Gap, Contrast, Flash, Name, Application, Reinforcement)
3. Run the self-audit checklist (all 17 items)
4. Output to: `$VAULT_PATH/Distinctions/by-source/[source-name]/expanded/[distinction-name].md`

**Batch ordering:** When expanding multiple distinctions, process in dependency order (prerequisites first). Check cross-references between distinctions.

**Parallelization:** Independent distinctions (no prerequisite relationship) can be expanded in parallel using multiple Task agents.

---

### Stage 4: EXPAND CRITIC — Teaching Unit Quality Gate

**Tool:** Task tool → `subagent_type: "distinction-expander-critic"`

Spawn the critic as a sub-agent with this context:

```
Evaluate the following distinction teaching unit for landing probability.
Score across: Gap Quality (20%), Contrast Sharpness (20%), Flash Design (20%),
Name Quality (10%), Application Design (15%), Reinforcement Design (15%).
Apply voice check adjustment (+1/0/-1).

Teaching unit: [file path]
Raw extraction (for reference): [file path]

Produce a full evaluation with SHIP/REVISE/REBUILD verdict.
```

**Decision logic:**

| Verdict | Action |
|---------|--------|
| **SHIP** (8.0+ adjusted) | Mark as production-ready. Update inventory. |
| **REVISE** (6.0-7.9) | Re-expand with specific critic notes. Max 2 revision cycles. |
| **REBUILD** (below 6.0) | Complete redesign of the teaching unit. Max 1 rebuild. |

**Output:** Critic evaluation file saved to `by-source/[source]/expanded/critiques/[distinction-name]-critique.md`

**Inventory update:** After SHIP, update the distinction's inventory record:
- `stage: shipped`
- `expression_power: [critic score]`
- `voice_adjustment: [+1/0/-1]`

---

## Stage 5: INVENTORY UPDATE — Register Results

After all stages complete, update the master inventory at:
```
$VAULT_PATH/Distinctions/MASTER-INVENTORY.md
```

**For each distinction processed, ensure these fields are current:**

| Field | Updated At |
|-------|-----------|
| Source, batch, type, score | Stage 1 (Find) |
| Idea validation status | Stage 2 (Finder Critic) |
| Teaching unit path | Stage 3 (Expand) |
| Expression power score | Stage 4 (Expander Critic) |
| Curriculum placement | Stage 5 (manual or auto-suggested) |

See `references/inventory-schema.md` for full field definitions.

---

## Pipeline Output Summary

At the end of every pipeline run, produce a summary:

```markdown
# Pipeline Run Summary

**Date:** [date]
**Source:** [what was processed]
**Mode:** [full | find-only | expand-only]

## Results

| Stage | Input | Output | Pass | Revise | Fail |
|-------|-------|--------|------|--------|------|
| Find | [N] files | [N] candidates | [N] confirmed | [N] refinement | [N] rejected |
| Finder Critic | [N] candidates | [N] evaluated | [N] PASS | [N] REVISE | [N] REDO |
| Expand | [N] distinctions | [N] teaching units | — | — | — |
| Expander Critic | [N] units | [N] evaluated | [N] SHIP | [N] REVISE | [N] REBUILD |

## Inventory Impact
- New entries added: [N]
- Entries updated: [N]
- Total inventory size: [N]

## Files Created
[List all output files with paths]

## Issues / Escalations
[Any failures, retries exhausted, or items needing review]
```

Save this summary to: `$VAULT_PATH/Distinctions/by-source/[source-name]/pipeline-run-[date].md`

---

## Batch Mode

When processing a folder or running in batch mode:

1. **Check PROCESSING-TRACKER.md first** — never reprocess already-processed files
2. **Process Priority 1 files before Priority 2** (as defined in the tracker)
3. **Produce individual extraction files per source** + a batch summary
4. **Run cross-source deduplication** after all extractions complete using the subsumption test
5. **Expand only unique, non-duplicate distinctions** — flag duplicates in inventory with cross-references
6. **Update PROCESSING-TRACKER.md** after each file completes (not at end of batch)

---

## Error Handling

| Error | Response |
|-------|----------|
| Source file is empty or unreadable | Skip, log to summary, continue batch |
| Finder produces 0 candidates | Log "barren source" to summary and tracker. Move to next file. |
| Critic agent fails to spawn | Retry once. If still fails, save extraction without critic evaluation. Flag in summary. |
| Revision cycles exhausted (max 2) | Save best version. Flag in summary as "revision-capped — needs manual review." Update inventory with `quality_flag: revision_capped`. |
| Context window approaching limit | Save all progress to files. Produce handoff document. Do NOT attempt "one more expansion." |
| Duplicate detected against inventory | Do NOT expand. Log the match. Note which formulation is stronger. |

---

## Processing Tracker Integration

The pipeline reads and writes to:
```
$VAULT_PATH/Distinctions/by-source/[source-name]/PROCESSING-TRACKER.md
```

After each file is processed through Stage 1:
- Mark as PROCESSED with date, extraction file path, and candidate count
- Update SUMMARY counts

After Stage 4 (or after find-only):
- Add "Pipeline complete" note with link to run summary

---

## Workflow Example

User says: "Run the distinction pipeline on the Management Training folder."

Pipeline does:
1. Read PROCESSING-TRACKER.md — confirm these files are unprocessed
2. **Stage 1:** Run Finder on each of the module files → produce extraction files
3. **Stage 2:** Spawn finder-critic on each extraction → quality gate, revise if needed
4. Cross-source dedup across all extractions
5. **Stage 3:** Expand each unique confirmed distinction → produce teaching units
6. **Stage 4:** Spawn expander-critic on each unit → quality gate, revise if needed
7. **Stage 5:** Update master inventory with all results
8. Update PROCESSING-TRACKER.md
9. Produce pipeline run summary

---

*Version: 1.0*
*Created: February 13, 2026*
*Dependencies: distinction-finder v2.0, distinction-expander v2.1, distinction-finder-critic, distinction-expander-critic*
