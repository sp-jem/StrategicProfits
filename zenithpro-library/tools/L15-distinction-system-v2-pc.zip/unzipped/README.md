# Distinction System v2

> **Turn any content into teaching units that produce genuine perceptual shifts — not just understanding.**

This package contains a complete distinction extraction, expansion, and quality pipeline for Claude Code.

---

## What's New in v2

| Feature | v1 | v2 |
|---------|----|----|
| **Skills** | 2 (Finder, Expander) | 3 (Finder v2.0, Expander v2.1, Pipeline v1.0) |
| **Hard Constraints** | C1-C10 | C1-C12 (added Microscript + Money Line Forge) |
| **Pipeline Orchestration** | Manual (run each stage separately) | Automated (one command, full chain) |
| **Multi-Folder Mode** | Not available | Process multiple source folders with cross-source dedup |
| **Master Inventory** | Not included | Full inventory schema with 3-axis tracking |
| **Calibration Data** | Not included | Batch learnings from 392 articles |
| **Context Window Handling** | Manual | Automatic checkpoints and handoff documents |

---

## What's Inside

### Skills (3)

| Skill | What It Does |
|-------|-------------|
| **distinction-finder** (v2.0) | Extracts raw distinctions from content. 10-step workflow with implicit scanning, false positive guard, and audience calibration. |
| **distinction-expander** (v2.1) | Builds complete 6-component teaching units (Gap, Contrast, Flash, Name, Application, Reinforcement). 12 hard constraints. Self-audit checklist. |
| **distinction-pipeline** (v1.0) | Orchestrates the full chain: Find → Finder Critic → Expand → Expander Critic → Inventory Update. Multi-folder mode with cross-source dedup. |

### Critic Agents (2)

| Agent | What It Does |
|-------|-------------|
| **distinction-finder-critic** | Scores extractions across 6 dimensions (Accuracy 25%, Completeness 20%, Classification 15%, A/B Sharpness 15%, Audience Relevance 15%, Deduplication 10%). PASS/REVISE/REDO verdicts. |
| **distinction-expander-critic** | Scores teaching units across 6 dimensions + voice check. SHIP (8.0+) / REVISE / REBUILD verdicts. |

### Methodology (4 docs)
Background theory the skills and agents reference:
- `00-WHAT-IS-A-DISTINCTION.md` — Foundational definition, qualification test, hierarchy
- `01-TYPES-OF-DISTINCTIONS.md` — Six types with examples and delivery keys
- `02-HOW-DISTINCTIONS-LAND.md` — The six-step Landing Sequence
- `03-HOW-TO-FIND-DISTINCTIONS.md` — Where distinctions hide, extraction process

### Examples (3)
Real outputs showing what the system produces:
- `example-extraction.md` — Finder output with confirmed, refinement, and rejected candidates
- `example-teaching-unit.md` — Expander output (scored 8.48 SHIP)
- `example-critique.md` — Critic batch evaluation (10 units, 90% ship rate)

### Personas (3)
Specialized sub-agent personas for each pipeline stage:
- `ada-okafor-distinction-miner.md` — Mining persona (aggressive rejection of non-distinctions)
- `elena-vasquez-distinction-critic.md` — Critic persona (live delivery evaluation)
- `rafael-santos-distinction-architect.md` — Architect persona (Gap-to-Flash engineering)

### Other
- `loms-walkthrough.md` — How the system was built and evolved (lessons for your own systems)
- `your-patterns.md` — Template for YOUR teaching voice patterns (customize this)
- `richs-patterns-EXAMPLE.md` — Rich Schefren's patterns file as a completed example

---

## Installation

### Mac
```bash
chmod +x install.sh
./install.sh
```

### Windows (PowerShell)
```powershell
.\install.ps1
```

The installer will:
1. Ask for your Obsidian vault path
2. Install all 3 skills to `~/.claude/skills/`
3. Install both critic agents to `~/.claude/agents/`
4. Copy methodology, examples, and personas to your skills folders
5. Create the Distinctions folder structure in your vault
6. Replace placeholder paths with your actual vault path

---

## Quick Start

### Option 1: Full Pipeline (Recommended)
```
Run the distinction pipeline on [your source file/folder]
```
This runs the complete chain automatically.

### Option 2: Manual Steps

**Step 1 — Extract:**
```
Use the distinction-finder skill to extract distinctions from [source file]
```

**Step 2 — Critique extraction:**
The finder-critic agent evaluates the extraction. PASS (7.0+) advances to expansion.

**Step 3 — Expand:**
```
Use the distinction-expander skill to build a teaching unit for [distinction name]
```

**Step 4 — Critique teaching unit:**
The expander-critic agent scores across 6 dimensions. SHIP (8.0+) means it's ready.

**Step 5 — Iterate:**
REVISE verdicts come with specific fix instructions. Apply them and re-critique.

---

## Customization

### 1. Fill in your-patterns.md
The most important customization. Open `~/.claude/skills/distinction-expander/references/your-patterns.md` and fill in YOUR teaching patterns, voice markers, and anti-patterns. This is how the Expander matches output to your voice.

Use `richs-patterns-EXAMPLE.md` as a reference for the format.

### 2. Calibrate to your audience
The Finder's audience calibration defaults to "entrepreneurs + small teams." Update the audience description in the Finder SKILL.md if your audience is different.

### 3. Customize inventory domains
The inventory schema uses example domains (AI Architecture, Business Strategy, etc.). Replace these with your program's actual domains in the inventory-schema.md reference file.

---

## The Pipeline Flow

```
SOURCE MATERIAL (transcripts, articles, frameworks)
        |
   [FINDER v2.0]
   Scans → Extracts → Qualifies (6 filters)
   Output: Structured extraction with Confirmed/Refinement/Rejected
        |
   [FINDER CRITIC]
   Scores across 6 dimensions → PASS (7.0+) / REVISE / REDO
        |
   [EXPANDER v2.1]
   Builds 6-component teaching unit → Self-audits (17 checks)
   Output: Complete teaching unit (250-350 lines)
        |
   [EXPANDER CRITIC]
   Scores across 6 dimensions + voice → SHIP (8.0+) / REVISE / REBUILD
        |
   [INVENTORY UPDATE]
   Registers across 3 axes: Idea Validation, Expression Power, Curriculum Placement
```

---

## Quality Standards

### The Landing Test
"If delivered to 50 people, how many GET IT?" Target: 35+.

### The Hammer Test (Djukich)
"When you first used a hammer, did you have to believe in it?" If belief is required, the unit isn't tool-shaped yet.

### The Fade Test
"Will this distinction be active in 30 days without re-teaching?" If no, Reinforcement needs work.

### The Share Test
"Would someone read this and feel compelled to share it with a friend — unprompted?"

---

## Hard Constraints (C1-C12)

These are non-negotiable rules enforced by the Expander and checked by the Critic:

| # | Rule |
|---|------|
| C1 | Flash section <= Gap section in length |
| C2 | Flash uses three-act story structure |
| C3 | No five-example cascades in Flash |
| C4 | Maximum 3 contrast pairs + money line |
| C5 | Application leads with 24-hour action |
| C6 | Exercises produce artifacts, not thoughts |
| C7 | Reinforcement has daily trigger + peer mechanism + program callback |
| C8 | Name section 15 lines max, weapon-grade |
| C9 | Total unit 250-350 lines |
| C10 | No borrowed terminology |
| C11 | Microscript attempt required (~5-8 words) |
| C12 | Money line passes word-level forge check |

---

## File Structure

```
distinction-system-v2/
├── install.sh                    # Mac installer
├── install.ps1                   # Windows installer
├── README.md                     # This file
├── loms-walkthrough.md           # Build story + lessons
├── skills/
│   ├── distinction-finder/
│   │   ├── SKILL.md              # Finder v2.0
│   │   └── references/
│   │       ├── definition.md
│   │       ├── methodology.md
│   │       ├── types.md
│   │       └── calibration.md
│   ├── distinction-expander/
│   │   ├── SKILL.md              # Expander v2.1
│   │   └── references/
│   │       ├── landing-sequence.md
│   │       ├── delivery-by-type.md
│   │       ├── your-patterns.md          # YOUR voice (customize)
│   │       └── richs-patterns-EXAMPLE.md # Example patterns
│   └── distinction-pipeline/
│       ├── SKILL.md              # Pipeline v1.0
│       └── references/
│           └── inventory-schema.md
├── agents/
│   ├── distinction-finder-critic/
│   │   └── AGENT.md
│   └── distinction-expander-critic/
│       └── AGENT.md
├── methodology/
│   ├── 00-WHAT-IS-A-DISTINCTION.md
│   ├── 01-TYPES-OF-DISTINCTIONS.md
│   ├── 02-HOW-DISTINCTIONS-LAND.md
│   └── 03-HOW-TO-FIND-DISTINCTIONS.md
├── examples/
│   ├── example-extraction.md
│   ├── example-teaching-unit.md
│   └── example-critique.md
└── personas/
    ├── ada-okafor-distinction-miner.md
    ├── elena-vasquez-distinction-critic.md
    └── rafael-santos-distinction-architect.md
```

**Total: 28 files**

---

## Troubleshooting

### "The Finder isn't finding enough distinctions"
- Check your source material. Teaching transcripts and methodology docs have the highest distinction density.
- Try running with the Ada Okafor persona for more aggressive mining.
- Some sources are genuinely barren. Not everything contains distinctions.

### "Teaching units keep getting REVISE verdicts"
- Check the Flash section first — it's the most common failure point.
- Ensure the Flash is a three-act story (not a list of examples).
- Make sure the Flash is shorter than the Gap.
- Fill in your-patterns.md — voice mismatch causes -1 adjustments.

### "The Pipeline stops mid-run"
- Context window limit. The Pipeline saves checkpoints automatically.
- Say "Resume the distinction pipeline" and it picks up where it left off.

### "Critic agents won't spawn"
- Make sure the agents are installed at `~/.claude/agents/`
- Use the Task tool to spawn them (they need isolated context)

---

*Version: 2.0*
*Package date: February 2026*
*Contents: 3 skills, 2 critic agents, 4 methodology docs, 3 examples, 3 personas, README, walkthrough, installers*
