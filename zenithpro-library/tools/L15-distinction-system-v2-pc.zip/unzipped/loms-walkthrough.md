# How This System Was Built — A Look Over My Shoulder

> **This is the story of how the Distinction System was built in a single 14-hour session, then upgraded through production use.** It covers the design choices, the quality gate evolution, and the lessons that apply to any AI system you build.

---

## The Session

**Duration:** ~14 hours, 953 messages
**Date:** February 7, 2026
**What was built:** The core system — 2 skills, 2 critic agents, 3 personas, 6 methodology documents, and the pipeline that connects them.

**Post-build evolution:** After processing 392 articles through the pipeline, the system evolved. The Expander went from v1.0 to v2.1 (adding hard constraints C1-C12). A dedicated Pipeline skill was added to orchestrate the full chain. This v2 package includes everything from both the original build and the production upgrades.

---

## What Was Built

A complete distinction extraction, teaching, and quality pipeline:

### Skills (3)
- **distinction-finder** (v2.0) — Extracts raw distinctions from content (transcripts, frameworks, methodology docs)
- **distinction-expander** (v2.1) — Transforms raw distinctions into full teaching units designed to produce perceptual shifts
- **distinction-pipeline** (v1.0) — Orchestrates the full chain: Find → Critic → Expand → Critic → Inventory (NEW in v2)

### Critic Agents (2)
- **distinction-finder-critic** — Evaluates extractions for accuracy, completeness, classification quality
- **distinction-expander-critic** — Scores teaching units across 6 dimensions with hard constraints

### The Pipeline

```
SOURCE MATERIAL
    |
[DISTINCTION FINDER]
Scans for signal patterns -> Extracts candidates -> Qualifies (6 filters) -> Outputs structured extractions
    |
[DISTINCTION FINDER CRITIC]
Evaluates: Accuracy, Completeness, Classification, A/B Sharpness, Relevance, Deduplication -> Pass (7.0+) or Revise
    |
[DISTINCTION EXPANDER]
Builds teaching unit: Gap -> Contrast -> Flash -> Name -> Application -> Reinforcement (with C1-C12 hard constraints)
    |
[DISTINCTION EXPANDER CRITIC]
Scores: Gap Quality, Contrast Sharpness, Flash Design, Name Quality, Application, Reinforcement + Voice Check -> SHIP (8.0+) or Revise
    |
[INVENTORY UPDATE]
Registers results in master inventory across 3 axes: Idea Validation, Expression Power, Curriculum Placement
    |
TEACHING UNIT (ready for curriculum integration)
```

---

## Why It Matters

Distinctions are the atomic unit of teaching IP. They're not information, not frameworks, not techniques — they're perceptual capacities created through language that permanently alter what someone can see.

Without a systematic way to extract, evaluate, expand, and deliver these distinctions, they remain implicit — lost in transcripts, scattered across frameworks, trapped in your head. This system makes them explicit, reusable, and deliverable at scale.

---

## Key Design Choices

### 1. Finder extracts, doesn't invent
Every distinction must trace to specific content in source material. The Finder never generates distinctions that aren't there. This prevents hallucination and ensures every teaching unit has a real foundation.

### 2. Expander builds for LANDING, not understanding
The test is behavioral: "If you delivered this to 50 people in your audience, how many would GET IT?" Target: 35+. Units are designed to produce perceptual shifts, not intellectual agreement.

### 3. Critics enforce quality gates
No advancement without hitting threshold. Improvement signals from failed evaluations feed back into skill updates (e.g., Expander v1.0 → v2.1 added 12 hard constraints after 17 critic evaluations).

### 4. Hard constraints over soft guidelines
C1-C12 are non-negotiable. Any violation = automatic REVISE regardless of overall score. This prevents "good on average but fatally flawed" units from shipping.

### 5. Pipeline orchestrates the chain (NEW in v2)
Instead of manually running each stage, the Pipeline skill orchestrates the full chain. Feed it source material, and it runs Find → Critic → Expand → Critic → Inventory in one command. Handles multi-folder mode, context window handoffs, and cross-source deduplication.

---

## The Quality Gate Evolution

This is where the real lesson lives. The system didn't start with C1-C12. It evolved them through failure.

### Version 1 of the Expander
- Soft guidelines only ("the Flash should be a story")
- No line count constraints
- No voice checking
- Result: Teaching units that scored well on content but read like textbooks. They explained distinctions perfectly. They wouldn't land in a room.

### After 17 Critic Evaluations
Patterns emerged from repeated failures:
- Flash sections were too long (wandering stories that lost the audience)
- Too many examples diluted the impact (5-example cascades)
- Reinforcement sections used rhetorical speeches instead of designed mechanics
- Borrowed terminology signaled fake authority

### Version 2.1 (Current)
Each failure pattern became a hard constraint:
- C1: Flash must be shorter than or equal to Gap (prevents story bloat)
- C2: Flash must use three-act story structure (prevents fragmented examples)
- C3: No five-example cascades in Flash
- C4: Max 3 contrast pairs + money line
- C5-C7: Application and Reinforcement standards
- C8: Name section 15 lines max, weapon-grade quality
- C9: 250-350 lines total (prevents sprawl)
- C10: No borrowed terminology
- C11: Microscript attempt required (NEW in v2.1)
- C12: Money line forge — word-level craft check (NEW in v2.1)

**The lesson:** Critics don't just score — they identify patterns that update the creation system itself. The system got better by operating, not by being designed better upfront.

---

## Five Lessons for Your Own Systems

### 1. The Skill vs Agent Distinction
- **Skills** share conversational context — use when you want continuity, memory, iterative refinement
- **Agents (via Task tool)** operate in isolated context — use for critics, evaluators, quality gates where you want fresh perspective

The Finder and Expander are skills (they build on prior work in the session). The critics are agents (they evaluate without bias from the creation process).

### 2. Quality Gates as Non-Negotiables
Notice the hard constraints (C1-C12) in the Expander. These aren't guidelines — they're programmatic checks. Any violation = automatic failure. This prevents "mostly good" work from shipping with fatal flaws.

**Takeaway:** If quality matters, enforce it mechanically, not rhetorically.

### 3. Improvement Signals as System Updates
After 17 critic evaluations, patterns emerged. Those patterns became hard constraints in v2.0+ of the Expander skill.

**Takeaway:** Build your system, run it, collect failure data, then upgrade the system. Don't try to design the perfect system before running it.

### 4. Reference Files as Persistent Knowledge
The 4 methodology files in this package aren't instructions — they're the KNOWLEDGE BASE the skills and agents reference. When a skill says "read methodology.md before first use," that's not flavor text — it's how the system stays aligned to the theory.

**Takeaway:** Separate HOW (skill workflow) from WHY (reference methodology). Update them independently.

### 5. Personas Aren't Decoration
Each sub-agent was assigned a persona (Ada for mining, Elena for criticism, Rafael for construction). Personas encode philosophies, obsessions, methodologies, and blind spots — they're operating instructions, not character sketches.

**Takeaway:** A persona is a compression of expertise into a behavioral specification. "Be thorough" is a vague instruction. "Be Ada Okafor — find the buried binary the author doesn't know they're using" is an operating instruction.

---

## Results at Scale

After the system was built, it was run against a large content library:

| Metric | Value |
|--------|-------|
| Articles processed | 392 |
| Raw distinctions extracted | 253 |
| Teaching units expanded | 233 |
| SHIP-quality units (8.0+) | 200+ |
| Ship rate | ~86% |
| Average adjusted score | 8.5+ |
| Skill versions | Expander v1.0 → v2.1 |
| Hard constraints evolved | 12 (C1-C12) |

The pipeline is repeatable. Point it at new source material and it produces the same quality output — because the quality is designed into the system, not dependent on getting lucky with any single extraction or expansion.

---

## Your Turn

You have the same system. The skills, agents, personas, and methodology are all in this package. The pipeline works the same way for your content:

1. Feed your source material to the Distinction Finder (or use the Pipeline for the full chain)
2. Run the Finder Critic to verify extraction quality
3. Send confirmed distinctions to the Distinction Expander
4. Run the Expander Critic to verify teaching unit quality
5. Ship units that score 8.0+, revise the rest
6. Update your master inventory to track everything

The system improves every time you use it. Critic feedback tells you exactly what to fix. Pattern recognition across batches tells you what to add to your hard constraints.

Start with one source. Extract. Expand. Critique. Ship. Then do it again.

---

*Based on the February 7, 2026 build session + production upgrades through February 2026*
*For students learning systematic AI implementation*
