# Distinction System v2 — PC Installer (PowerShell)
# Installs 3 skills, 2 agents, and optionally copies personas + methodology

$ErrorActionPreference = "Stop"

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Distinction System v2 — Installer (PC)" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# Get the directory where this script lives
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Check for ~/.claude directory
$ClaudeDir = Join-Path $env:USERPROFILE ".claude"
if (-not (Test-Path $ClaudeDir)) {
    Write-Host "ERROR: $ClaudeDir directory not found." -ForegroundColor Red
    Write-Host "Make sure Claude Code is installed and has been run at least once."
    exit 1
}

# Create skills and agents directories if needed
$SkillsDir = Join-Path $ClaudeDir "skills"
$AgentsDir = Join-Path $ClaudeDir "agents"
New-Item -ItemType Directory -Force -Path $SkillsDir | Out-Null
New-Item -ItemType Directory -Force -Path $AgentsDir | Out-Null

Write-Host "Installing skills..."

# Install Distinction Finder
$FinderDest = Join-Path $SkillsDir "distinction-finder"
if (Test-Path $FinderDest) {
    Write-Host "  [SKIP] distinction-finder already exists (not overwriting)" -ForegroundColor Yellow
} else {
    Copy-Item -Recurse (Join-Path $ScriptDir "skills\distinction-finder") $FinderDest
    Write-Host "  [OK] distinction-finder installed" -ForegroundColor Green
}

# Install Distinction Expander
$ExpanderDest = Join-Path $SkillsDir "distinction-expander"
if (Test-Path $ExpanderDest) {
    Write-Host "  [SKIP] distinction-expander already exists (not overwriting)" -ForegroundColor Yellow
} else {
    Copy-Item -Recurse (Join-Path $ScriptDir "skills\distinction-expander") $ExpanderDest
    Write-Host "  [OK] distinction-expander installed" -ForegroundColor Green
}

# Install Distinction Pipeline
$PipelineDest = Join-Path $SkillsDir "distinction-pipeline"
if (Test-Path $PipelineDest) {
    Write-Host "  [SKIP] distinction-pipeline already exists (not overwriting)" -ForegroundColor Yellow
} else {
    Copy-Item -Recurse (Join-Path $ScriptDir "skills\distinction-pipeline") $PipelineDest
    Write-Host "  [OK] distinction-pipeline installed" -ForegroundColor Green
}

Write-Host ""
Write-Host "Installing agents..."

# Install Finder Critic
$FinderCriticDest = Join-Path $AgentsDir "distinction-finder-critic"
if (Test-Path $FinderCriticDest) {
    Write-Host "  [SKIP] distinction-finder-critic already exists (not overwriting)" -ForegroundColor Yellow
} else {
    Copy-Item -Recurse (Join-Path $ScriptDir "agents\distinction-finder-critic") $FinderCriticDest
    Write-Host "  [OK] distinction-finder-critic installed" -ForegroundColor Green
}

# Install Expander Critic
$ExpanderCriticDest = Join-Path $AgentsDir "distinction-expander-critic"
if (Test-Path $ExpanderCriticDest) {
    Write-Host "  [SKIP] distinction-expander-critic already exists (not overwriting)" -ForegroundColor Yellow
} else {
    Copy-Item -Recurse (Join-Path $ScriptDir "agents\distinction-expander-critic") $ExpanderCriticDest
    Write-Host "  [OK] distinction-expander-critic installed" -ForegroundColor Green
}

Write-Host ""

# Vault Path for Pipeline
Write-Host "The Distinction Pipeline needs a folder to store extractions, teaching units,"
Write-Host "and the master inventory. This is typically your Obsidian vault."
Write-Host ""
Write-Host "Enter the full path to your Obsidian vault (or working directory):"
Write-Host "  Example: C:\Users\yourname\Documents\Obsidian\MyVault"
Write-Host ""
$VaultPath = Read-Host "Vault path"

if (Test-Path $VaultPath) {
    # Create distinction folder structure
    New-Item -ItemType Directory -Force -Path (Join-Path $VaultPath "Distinctions\by-source") | Out-Null
    $InventoryFile = Join-Path $VaultPath "Distinctions\MASTER-INVENTORY.md"
    if (-not (Test-Path $InventoryFile)) {
        New-Item -ItemType File -Force -Path $InventoryFile | Out-Null
    }
    Write-Host "  [OK] Created Distinctions folder structure at $VaultPath\Distinctions\" -ForegroundColor Green
    Write-Host ""

    # Update the pipeline SKILL.md with the actual vault path
    $PipelineSkill = Join-Path $PipelineDest "SKILL.md"
    if (Test-Path $PipelineSkill) {
        (Get-Content $PipelineSkill) -replace '\$VAULT_PATH', $VaultPath | Set-Content $PipelineSkill
        Write-Host "  [OK] Pipeline skill configured with your vault path" -ForegroundColor Green
    }

    # Update the finder SKILL.md with the actual vault path
    $FinderSkill = Join-Path $FinderDest "SKILL.md"
    if (Test-Path $FinderSkill) {
        (Get-Content $FinderSkill) -replace '\$VAULT_PATH', $VaultPath | Set-Content $FinderSkill
        Write-Host "  [OK] Finder skill configured with your vault path" -ForegroundColor Green
    }

    # Update the expander SKILL.md with the actual vault path
    $ExpanderSkill = Join-Path $ExpanderDest "SKILL.md"
    if (Test-Path $ExpanderSkill) {
        (Get-Content $ExpanderSkill) -replace '\$VAULT_PATH', $VaultPath | Set-Content $ExpanderSkill
        Write-Host "  [OK] Expander skill configured with your vault path" -ForegroundColor Green
    }
} else {
    Write-Host "  [WARN] Directory does not exist: $VaultPath" -ForegroundColor Yellow
    Write-Host "  You can create it later and update the skills manually."
    Write-Host "  Look for `$VAULT_PATH in the SKILL.md files and replace with your path."
}

Write-Host ""

# Personas
Write-Host "Where should personas be installed?"
Write-Host "  1) $ClaudeDir\personas\ (accessible from any project)"
Write-Host "  2) Skip (I'll place them manually)"
Write-Host ""
$PersonaChoice = Read-Host "Choice [1/2]"

if ($PersonaChoice -eq "1") {
    $PersonaDest = Join-Path $ClaudeDir "personas"
    New-Item -ItemType Directory -Force -Path $PersonaDest | Out-Null
    Copy-Item (Join-Path $ScriptDir "personas\*.md") $PersonaDest
    Write-Host "  [OK] 3 personas installed to $PersonaDest" -ForegroundColor Green
} else {
    Write-Host "  [SKIP] Personas not installed. Copy from personas\ folder when ready." -ForegroundColor Yellow
}

Write-Host ""

# Methodology
Write-Host "Where should methodology docs be installed?"
Write-Host "  1) $ClaudeDir\methodology\ (accessible from any project)"
Write-Host "  2) Enter a custom path (e.g., your Obsidian vault)"
Write-Host "  3) Skip (I'll place them manually)"
Write-Host ""
$MethodChoice = Read-Host "Choice [1/2/3]"

if ($MethodChoice -eq "1") {
    $MethodDest = Join-Path $ClaudeDir "methodology"
    New-Item -ItemType Directory -Force -Path $MethodDest | Out-Null
    Copy-Item (Join-Path $ScriptDir "methodology\*.md") $MethodDest
    Write-Host "  [OK] 4 methodology docs installed to $MethodDest" -ForegroundColor Green
} elseif ($MethodChoice -eq "2") {
    $CustomPath = Read-Host "Enter full path"
    if (Test-Path $CustomPath) {
        $MethodDest = Join-Path $CustomPath "methodology"
        New-Item -ItemType Directory -Force -Path $MethodDest | Out-Null
        Copy-Item (Join-Path $ScriptDir "methodology\*.md") $MethodDest
        Write-Host "  [OK] 4 methodology docs installed to $MethodDest" -ForegroundColor Green
    } else {
        Write-Host "  [ERROR] Directory does not exist: $CustomPath" -ForegroundColor Red
        Write-Host "  Skipping methodology install. Copy from methodology\ folder when ready."
    }
} else {
    Write-Host "  [SKIP] Methodology not installed. Copy from methodology\ folder when ready." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Installation Complete" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "WHAT WAS INSTALLED:" -ForegroundColor White
Write-Host "  Skills:  distinction-finder, distinction-expander, distinction-pipeline"
Write-Host "  Agents:  distinction-finder-critic, distinction-expander-critic"
Write-Host ""
Write-Host "NEXT STEPS:" -ForegroundColor White
Write-Host "  1. Fill in your voice patterns:"
Write-Host "     $SkillsDir\distinction-expander\references\your-patterns.md"
Write-Host "     (See richs-patterns-EXAMPLE.md for a completed example)"
Write-Host ""
Write-Host "  2. Read the methodology docs (00-03) before your first extraction"
Write-Host ""
Write-Host "  3. Open Claude Code and try one of these:"
Write-Host ""
Write-Host "     SINGLE SKILL:"
Write-Host "     'Use the distinction-finder skill to extract distinctions from [your content]'"
Write-Host ""
Write-Host "     FULL PIPELINE:"
Write-Host "     'Use the distinction-pipeline skill to process [your source file or folder]'"
Write-Host ""
Write-Host "  The pipeline runs: Find -> Critic -> Expand -> Critic -> Inventory Update"
Write-Host "  all in one command."
Write-Host ""
Write-Host "  See README.md for the full Quick Start guide."
Write-Host ""
