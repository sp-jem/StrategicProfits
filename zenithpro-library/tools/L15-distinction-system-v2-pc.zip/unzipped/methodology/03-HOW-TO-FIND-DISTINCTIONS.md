> **METHODOLOGY DOCUMENT:** This is part of the Distinction System methodology library. It covers where distinctions hide in source material and the extraction process the Finder skill uses. The source priority section references a specific program — adapt it to your own content sources.

# How to Find Distinctions (Extraction Methodology)

> **Reference: The prospecting system for identifying raw distinctions in content.**
> This is the methodology the Distinction Finder skill will use.

---

## Where Distinctions Hide

Distinctions don't announce themselves. They're embedded in content, conversation, and experience. The Finder's job is to extract them from raw material. Here's where to look:

### 1. In Breakdowns

> "Distinctions arise from recurrent patterns of breakdown in concernful activity."

When something breaks — a project fails, a team member underperforms, a strategy backfires — there's usually a missing distinction at the root. The breakdown happened because someone couldn't see a difference that mattered.

**Extraction question:** "What did they NOT see that, if they had seen it, would have prevented this breakdown?"

### 2. In Expert Behavior

When an expert does something effortlessly that a novice finds impossible, there's a distinction the expert has that the novice doesn't.

**Extraction question:** "What is the expert seeing/categorizing/distinguishing that the novice treats as one undifferentiated thing?"

### 3. In Collapsed Language

When people use one word for two different things, there's a collapsed distinction.

**Extraction question:** "Is this word being used to mean two fundamentally different things? What happens if we separate them?"

Examples:
- "Strategy" used to mean both "long-term direction" and "clever tactic"
- "Customer" used to mean 5 different things depending on context
- "AI" used to mean both "tools I use" and "systems I build"

### 4. In Surprising Results

When someone gets unexpectedly good (or bad) results, there's usually a distinction at work — they either had one others lack (good results) or lacked one others have (bad results).

**Extraction question:** "What's the difference between the people who get results and the people who don't — and is that difference perceptual?"

### 5. In Your Own Teaching

If you teach, you naturally work in distinctions. Your transcripts, frameworks, and presentations are full of moments where you draw a line between two things your audience was treating as one.

**Extraction question:** "Where do you say 'the difference between X and Y is...' or 'most people think X, but actually...'?"

### 6. In A vs B Patterns

The simplest extraction: anywhere content presents two things as different that are commonly treated as the same.

**Extraction question:** "What's being contrasted? Is the contrast genuinely perceptual (seeing differently) or just informational (knowing more)?"

---

## The Extraction Process

### Pass 1: Surface Scan

Read through the source material looking for these patterns:

| Pattern | Signal Words/Structures |
|---------|------------------------|
| **Explicit contrast** | "The difference between X and Y..." / "X is not Y" / "Most people think X, but..." |
| **Binary framing** | "There are two kinds of..." / "Either you're X or you're Y" |
| **Before/after** | "Before I learned this... after I learned this..." |
| **Collapse indicator** | "People confuse X with Y" / "X is not the same as Y, even though..." |
| **Expert observation** | "What experts see is..." / "The professional notices..." / "Once you can spot..." |
| **Breakdown narrative** | "The reason this fails is..." / "What goes wrong is..." |
| **Reframing** | "It's not about X, it's about Y" / "The real question isn't X, it's Y" |
| **Named pairs** | "Strategy vs Tactics" / "Owner vs Victim" / Any "A vs B" structure |

### Pass 2: Extraction

For each candidate found in Pass 1, extract:

```markdown
## Raw Distinction: [Name or Description]

**Source:** [File, page, speaker]
**Type:** [Collapsed / Perceptual / Inversion / Domain-Transfer / Stance / Structural]

**The A side:** [What most people currently see/believe/do]
**The B side:** [What becomes visible with the distinction]
**The cost of not having it:** [What people lose by staying on the A side]
**The gain of having it:** [What opens up on the B side]

**Confidence:** [High / Medium / Low — is this genuinely a distinction or is it information/mechanism?]
**Notes:** [Any context needed]
```

### Pass 3: Qualification

Run each extracted candidate through the qualification test (from `00-WHAT-IS-A-DISTINCTION.md`):

| Filter | Question | Pass? |
|--------|----------|-------|
| Perceptual | Does it change what you SEE? | |
| Binary | Can it be expressed as A vs B? | |
| Automatic | Once acquired, does it work without recall? | |
| Domain-portable | Does it work across situations? | |
| Action-enabling | Does it open new possibilities? | |
| Pre-framework | Is it atomic? | |

**Scoring:**
- 6/6 passes = Confirmed distinction → send to Expander
- 4-5/6 passes = Probable distinction → needs refinement
- 3 or fewer = Likely mechanism, framework, or information → reclassify

### Pass 4: Deduplication

Multiple source materials will produce the same distinction in different language. After extraction:

1. Group candidates that describe the same underlying perceptual shift
2. Pick the strongest formulation (sharpest contrast, most concrete language)
3. Note alternative framings as secondary delivery options
4. Resolve conflicts (if two sources present the same distinction differently, determine which is more accurate for your target audience)

---

## Source Material Priority

Prioritize your sources by distinction density. Here's an example hierarchy:

### Tier 1: Distinction-Dense (Process First)
- **Teaching transcripts** — live sessions where you teach, coach, or consult. These contain the most implicit distinctions because you're teaching in real time.
- **Methodology documents** — your frameworks, processes, and systems. The distinctions that power your frameworks are often implicit.
- **Expert source material** — books, courses, interviews from experts in your domain.

### Tier 2: Supporting Sources
- **Marketing materials** — webinar scripts, sales pages, emails. Your positioning often contains collapsed distinctions.
- **Student Q&A and feedback** — breakdowns your students encounter reveal missing distinctions.
- **Research and case studies** — historical patterns and industry analysis.

### Tier 3: Already Extracted
- Any existing distinction lists or teaching materials you've already created.

---

## Extraction Heuristics (What the Finder Should Know)

### Not Everything Is a Distinction

The biggest risk is over-extraction — classifying information, mechanisms, and frameworks as distinctions. Keep the filters tight.

**Information that looks like a distinction but isn't:**
- "AI can process 1000x more data than a human" — this is a fact, not a perceptual shift
- "You should use Python for data work" — this is advice, not a new category of seeing
- "The market is shifting to AI" — this is a trend report, not a distinction

**Mechanisms that look like distinctions but need more work:**
- "Trained Incapacity" — explains how expertise becomes a prison, but the distinction needs to be: "the difference between expertise that liberates and expertise that imprisons"
- "The Liquidator" (Kern) — a marketing mechanism, not a perceptual distinction

### The "So What" Test

After extracting a candidate, ask: "If a student of your program gets this distinction, what can they NOW SEE that they couldn't see before — and what can they NOW DO as a result?"

If the answer is vague ("they'll understand better"), it's not a distinction yet.
If the answer is specific ("they'll be able to look at any AI project and immediately classify whether it's compute-heavy, data-heavy, or coordination-heavy, which determines the entire architecture"), it's a distinction.

### Domain Distribution (Example)

Here's an example domain distribution for an AI training program — adapt the domains and percentages to your own program:

| Domain | % of Total | Examples |
|--------|-----------|----------|
| **AI Architecture** | ~30% | Stack layers, problem classification, environments, data shapes |
| **Business Strategy** | ~20% | Strategy vs tactics, owner vs operator, leverage vs labor |
| **Team/Management** | ~20% | Managing AI vs managing people, delegation vs abdication, coaching vs telling |
| **Worldview/Paradigm** | ~15% | Execution infinite, complexity free, learning optional, ceiling gone |
| **Operational** | ~15% | System vs network, pipeline vs state machine, automation vs augmentation |

---

## Output Format

The Finder produces a raw extraction file for each source processed:

```markdown
# Distinction Extraction: [Source Name]

**Date:** [extraction date]
**Source:** [full file path]
**Total candidates extracted:** [number]
**Confirmed distinctions:** [number]
**Needs refinement:** [number]
**Rejected (not distinctions):** [number]

---

## Confirmed Distinctions

### 1. [Distinction Name]
[Full extraction template as shown above]

### 2. [Distinction Name]
...

---

## Needs Refinement

### [Candidate Name]
[Why it needs refinement and what's missing]

---

## Rejected

### [Candidate Name]
[Why it was rejected and what it actually is (information, mechanism, framework)]
```

These raw extractions feed into the Distinction Expander, which builds the full teaching unit for each confirmed distinction.

---

*Created: February 7, 2026*
*Part of the Distinction System methodology library*
