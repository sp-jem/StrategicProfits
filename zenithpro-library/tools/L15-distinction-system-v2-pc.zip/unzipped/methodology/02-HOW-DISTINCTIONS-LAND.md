> **METHODOLOGY DOCUMENT:** This is part of the Distinction System methodology library. It covers the six-step Landing Sequence that the Expander skill uses to build teaching units. Understanding this sequence is critical for evaluating and customizing expanded output.

# How Distinctions Land

> **Reference: The delivery science for making distinctions stick.**
> A distinction that's understood but not lived is worse than no distinction at all. This document covers how to move a distinction from concept to permanent perceptual shift.

---

## The Problem: Understanding Is Not Getting It

The single most dangerous failure mode in distinction delivery is when the student UNDERSTANDS the distinction but doesn't GET it. Every source in the collection warns about this:

> "Straight-line leaders do not simply 'understand' these distinctions and then process them as information. They LIVE the distinctions. So it's important to notice: 'Are you understanding it or are you living it?'" — Djukich

> "There is a difference between 'knowing it,' 'being able to use it,' and mastering it, having 'it use you.'" — Landmark tradition

> "Understanding implies that you can speak about something that you have observed or studied. However... when people actually learn something, they can then apply, implement, or get a result with what they've learned." — Djukich

**The test is behavioral, not intellectual.** If someone can explain the distinction but their actions haven't changed, they understood it but didn't get it. The distinction hasn't landed.

---

## The Landing Sequence

Based on the synthesis of all source materials plus proven teaching patterns, a distinction lands through a specific sequence:

### Step 1: Create the Gap (The Setup)

Before introducing the distinction, the student must FEEL the absence of it. They need to encounter a problem, confusion, or limitation that the distinction resolves.

**Methods:**
- **The question they can't answer** — ask something that requires the distinction to answer. Their inability to answer creates the gap.
- **The failure they've experienced** — reference a common breakdown that the audience recognizes. "Have you ever done X and gotten a result you didn't expect?" The breakdown IS the gap.
- **The expert move they admire but can't explain** — point to someone who does something effortlessly that they struggle with. "What does that person see that you don't?"

> "Distinctions arise from recurrent patterns of breakdown in concernful activity." — Landmark tradition

The gap is not artificial. It's REAL. The student is already living in it — you're just making them see it.

### Step 2: The Contrast (The Core)

The distinction itself is delivered as a CONTRAST — A vs B, old way vs new way, what most people think vs what's actually true.

**Critical principle:** The contrast must be BINARY and CLEAN. No nuance at this stage. Nuance kills distinctions. The boundary between A and B must be so sharp that the student can tell them apart instantly.

> "Distinctions are dramatic, graphic opposites, like life and death, day and night, profit and loss. I use this approach because opposites are easy to see. There's no hidden subtlety. There's no wiggle room." — Djukich

**The A vs B structure:**
- A = what they currently do/see/believe (the default)
- B = what becomes possible with the distinction (the upgrade)
- The GAP between A and B = what they've been missing and what it's cost them

### Step 3: The Flash (The "Now I See" Moment)

This is the moment the distinction LANDS — the student sees it. Djukich calls it the "Now I see!" moment and compares it to getting a joke:

> "Once you get it — and you get it like you get a joke... a spontaneous awakening — you don't have to think about it. Or try to remember it. It's a true jolting insight. ('In' 'sight'... something you see inside of you.) It literally becomes a part of you."

**You cannot force this moment.** You can only set it up properly (gap + contrast). The flash either happens or it doesn't. If it doesn't, the delivery was wrong — go back to step 1 and create a better gap or a sharper contrast.

**Signs it landed:**
- Sudden silence (processing)
- Involuntary laughter (recognition)
- "Oh shit" or equivalent
- Immediate self-diagnosis ("I've been doing the A thing my whole career")
- They can instantly give their own example (not just repeat yours)

**Signs it didn't land:**
- They nod and take notes (understanding, not getting)
- They ask "Can you explain that again?" (they need a different angle, not repetition)
- They say "That makes sense" (dangerous — sense ≠ shift)
- They move to the next topic without pause (it washed over them)

### Step 4: The Name (The Anchor)

Once the flash happens, IMMEDIATELY give it a name. The name is the handle that makes the distinction retrievable and usable.

**Naming principles:**
- Short (2-4 words ideal)
- Contrasting (captures the A vs B — "Owner vs Victim", "Strategy vs Tactics")
- Memorable (uses concrete language, not abstract)
- Self-explanatory (hearing the name should partially reconstruct the distinction)

> "What you can name, you can use." — Rich Schefren (Distinctions-Opportunity Matrix)

The name turns the flash into a TOOL. Without a name, the insight fades. With a name, it becomes something the student can invoke, share, teach to others, and recognize in the field.

### Step 5: The Application (Making It Stick)

This is where most distinction delivery fails. The flash happened, the name was given, but without immediate application, the distinction fades.

**Three application moves (in order of power):**

1. **Self-diagnosis** — Have the student identify where in their OWN business/life they've been operating on the wrong side of the distinction. Not hypothetical. Not "imagine if." Actually point to a specific real situation.

2. **Real-time use** — Put them in a situation (case study, exercise, live demo) where they must USE the distinction to produce a result they couldn't produce before.

3. **Teaching it** — Have them explain the distinction to someone else (partner, team member). Teaching is the strongest consolidation mechanism. If they can create the gap, deliver the contrast, and produce the flash in someone else — they own it.

> "When people can actually see that their behaviors in the past involved coming from what they should do as opposed to making fitness and health a must, they will drop their resistance." — Djukich

### Step 6: The Reinforcement (Preventing Fade)

Even after a genuine flash, distinctions can fade if not reinforced. A single flash is necessary but not always sufficient.

**Reinforcement mechanisms:**
- **Recurring encounters** — Structure the curriculum so students encounter the same distinction in different contexts
- **Language adoption** — Use the distinction's name consistently throughout the program. When students start using the name unprompted, it's integrated.
- **Peer reinforcement** — Create structures where students call out the distinction in each other's work. "That's an information move, not a transformation move."
- **Integration challenges** — At the end of each day, students identify which distinctions they used and where they applied them.

---

## Delivery Patterns

These are proven delivery patterns that work for distinction teaching:

### Revelation Over Declaration

Don't TELL students the distinction. Reveal it through experience. Show a before, walk them through a process, then show the after — and the distinction reveals itself in the gap between them.

### Before/After Inversion

Show the "before" state (which the audience recognizes as their own), then show the "after" state, and the distinction between them becomes self-evident.

### Identity-Based Self-Diagnosis

Help students see themselves in a category they didn't know existed, then show them the other categories. Three Camps framework — "Camp 1: [obviously wrong]. Camp 2: [common default]. Camp 3: [the answer]." Students self-select, then learn why Camp 3 wins.

### The Universal Lens

Take one distinction and apply it across multiple domains in rapid succession, showing it's not domain-specific but universal. By the third application, they own it.

---

## The Delivery Failure Modes

| Failure Mode | What Happens | How to Fix |
|-------------|--------------|------------|
| **Teaching without gap** | Student has no felt need for the distinction; it slides off | Create the gap FIRST — before naming or explaining |
| **Too much nuance** | The A/B contrast is muddied; student can't find the boundary | Sharpen to binary. Kill qualifications. "There is X and there is NOT-X." |
| **Flash without name** | Student had the insight but can't retrieve it later | Name it IMMEDIATELY after the flash |
| **Name without application** | Student can recite the name but can't use it in the field | Force real-time application within minutes of delivery |
| **Understanding-as-substitute** | Student processes it intellectually and thinks they "got it" | Ask them to find their OWN example. If they can't, they understood but didn't get it. |
| **One-shot delivery** | The distinction flashes once and then fades without reinforcement | Build recurring encounters across multiple program days |

---

## Delivery by Distinction Type

Different distinction types land through different primary mechanisms:

| Type | Primary Landing Move | Secondary Move |
|------|---------------------|----------------|
| **Collapsed** | Show the COST of keeping them collapsed | Have student identify a specific situation where the collapse hurt them |
| **Perceptual** | Name the category, then point to 5 rapid-fire examples | Have student scan their own business and count instances |
| **Inversion** | State the common belief, pause, then flip it | Show evidence that contradicts the common belief |
| **Domain-Transfer** | Tell the source-domain story in full, then reveal the target-domain mapping | Have student map it to their specific industry |
| **Stance** | Describe both stances, then ask "Which one are you in RIGHT NOW?" | Have student catch themselves in the disempowering stance in real time |
| **Structural** | Draw the structure (literally — visual), then show what's missing from the student's current setup | Have student diagram their own system using the structural distinction |

---

## The "Hammer Test" (Djukich)

The ultimate test of whether a distinction has been properly delivered:

> "When you first used a hammer, did you have to believe in it? Or did you just grasp it and start pounding a nail? The minute you grasp and apply one of these distinctions like a hammer, it will become a tool of yours for life."

If the student needs to BELIEVE in the distinction, it hasn't landed as a tool.
If the student needs to REMEMBER it, it hasn't been named properly.
If the student needs to be TOLD when to use it, it hasn't been applied properly.

A distinction that has fully landed is a hammer: pick it up, use it, put it down. No belief required. No recall required. No instructions required.

---

*Created: February 7, 2026*
*Part of the Distinction System methodology library*
