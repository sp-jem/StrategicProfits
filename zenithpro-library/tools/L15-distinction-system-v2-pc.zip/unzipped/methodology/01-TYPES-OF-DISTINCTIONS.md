> **METHODOLOGY DOCUMENT:** This is part of the Distinction System methodology library. The six types determine how each distinction should be delivered. The Expander skill references this to choose delivery strategy.

# Types of Distinctions

> **Reference: How to classify distinctions once extracted.**
> Not all distinctions work the same way. This taxonomy helps the Finder categorize and the Expander choose delivery strategy.

---

## Type 1: Collapsed Distinctions (Uncollapsing)

**What it is:** Two genuinely different things that people treat as the same thing. Uncollapsing them creates new action space.

**Signature move:** "You think X and Y are the same thing. They're not. Here's the difference — and here's what it costs you to keep them collapsed."

**Delivery energy:** Revelation. The person has been losing something real by treating these as identical.

### Examples

| Collapsed Pair | What People Think | The Distinction |
|----------------|-------------------|-----------------|
| Freedom vs Relief | Both feel like escape | Freedom is a stance; relief is temporary absence of pressure |
| Success vs Winning | Both mean achievement | Success is a way of being; winning is an event |
| Values vs Needs | Both drive behavior | Values guide direction; needs demand fulfillment |
| Attraction vs Seduction | Both draw people in | Attraction is effortless pull; seduction is effortful manipulation |
| Simplicity vs Reductionism | Both reduce complexity | Simplicity preserves essence; reductionism destroys it |
| Understanding vs Learning | Both involve knowledge | Understanding = can discuss it; Learning = can produce results with it |
| Strategy vs Tactics | Both are "plans" | Strategy is choosing where to play; tactics is how to win within that choice |
| Administration vs Management vs Leadership | All are "running things" | Administration maintains; management controls; leadership creates |

**Source tradition:** Thomas Leonard, Russell Ackoff, Rich Schefren

---

## Type 2: Perceptual Distinctions (New Categories)

**What it is:** A category that doesn't exist in the person's perceptual field. Once installed, they see instances of it everywhere — including in their own past behavior.

**Signature move:** "There's a thing happening here that has a name. Once you know the name, you'll see it everywhere — including in your own work."

**Delivery energy:** Recognition. "Oh — THAT'S what that is."

### Examples

| Distinction | Before | After |
|-------------|--------|-------|
| Healthy vs sick tree | All trees look the same | You scan for bark patterns, leaf color, growth direction automatically |
| Volatile vs stable zones (in code) | "Code is code" | You instantly assess which parts will change and which won't |
| Compute-heavy vs data-heavy vs state-heavy | "It's a tech project" | You classify the problem before choosing any tools |
| Owner vs victim | "Some people are motivated, some aren't" | You hear victim language and owner language in real time |
| Inner stance | "That's just who I am" | You see stance as a choice, not an identity |

**Source tradition:** Djukich (inner stances), coding distinctions conversation, Erhard (occurring)

---

## Type 3: Inversion Distinctions (Flipped Assumptions)

**What it is:** A common assumption that is exactly backwards. The distinction flips it, revealing that what people thought was the answer IS the problem.

**Signature move:** "Everyone thinks X leads to Y. But X is actually what's PREVENTING Y."

**Delivery energy:** Shock. The ground shifts.

### Examples

| Common Assumption | The Inversion |
|-------------------|---------------|
| "I need more information to succeed" | Information is not what's missing — transformation is |
| "Confidence leads to action" | Action leads to confidence (confidence is a byproduct, not a prerequisite) |
| "Goals drive results" | Where you COME FROM drives results more than where you're going TO |
| "Knowledge is power" | Knowledge without implementation is worse than ignorance (wasted resources + false confidence) |
| "You should do what you know" | Doing everything you know ≠ doing what's required. They're different lists. |
| "Coding skill is needed to build with AI" | Architectural literacy is what's needed — AI provides the hands |

**Source tradition:** Djukich (straight-line vs circular), Rich (knowledge trap), coding conversation

---

## Type 4: Domain-Transfer Distinctions (Expert Eyes)

**What it is:** A distinction from a specific domain (medicine, architecture, military, etc.) that applies to a different domain the student is in. The transfer itself is the insight.

**Signature move:** "Architects don't build. They see forces, constraints, and possibilities — then direct builders. That's exactly what you need to do with AI."

**Delivery energy:** Analogy that collapses. Not "this is like that" but "this IS that."

### Examples

| Source Domain | Distinction | Application Domain |
|---------------|-------------|-------------------|
| Architecture | Architect sees invisible forces, doesn't build with hands | AI leadership: see the system, let AI execute |
| Forestry | Healthy vs sick, fire-ready vs shelter-worthy | Business health: which parts of your business are alive and growing vs dying |
| Medicine | Symptoms vs root cause | Business problems: most people treat symptoms forever |
| Military | Force multiplier (one unit amplifying many) | AI teams: one person with AI multiplies the capability of the whole team |
| Coding | Stack layers (interface, logic, data, integration, infrastructure) | Business layers: customer-facing, rules/workflow, data, integrations, operations |

**Source tradition:** Coding conversation, Rich (forester analogy), Ackoff (producer-product vs cause-effect)

---

## Type 5: Stance Distinctions (Where You Come From)

**What it is:** A distinction about the POSITION from which you operate, not the actions you take. Changes the "where you're coming from" which then changes everything downstream.

**Signature move:** "The issue isn't what you're doing. It's WHERE you're operating from. Shift the stance, and the actions take care of themselves."

**Delivery energy:** Inner confrontation. You see your own stance.

### Examples

| Stance A (Disempowering) | Stance B (Empowering) | What Shifts |
|---------------------------|------------------------|-------------|
| Overwhelmed | Focused | Same workload, different internal position |
| Trying | Committed | "I'll try" → "I'm doing this" |
| Wishing/hoping | Creating | Passive orientation → generative orientation |
| Knowing | Implementing | "I know what to do" → "I'm doing it" |
| "How to" | "Choose to" | Seeking method → exercising will |
| Waiting | Creating | "When conditions are right" → "Now" |
| Expectations | Agreements | Unspoken assumptions → explicit commitments |

**Source tradition:** Djukich (primary source — this is his entire system), Erhard (stances as constitutive)

---

## Type 6: Structural Distinctions (System Seeing)

**What it is:** A distinction about how things are organized, connected, or structured — not about content but about architecture.

**Signature move:** "You're looking at the pieces. Look at how they're connected. That pattern IS the thing."

**Delivery energy:** Zoom out. The system becomes visible.

### Examples

| What People See | The Structural Distinction |
|-----------------|---------------------------|
| "I have employees" | You have a SYSTEM with roles, information flows, and decision points |
| "This is a piece of software" | This is 5 LAYERS, each with a different job (interface, logic, data, integration, infrastructure) |
| "We use AI tools" | You have an AI ARCHITECTURE — skills, agents, critics — each with a different function |
| "I do many things" | Your activities form a PIPELINE (input → transform → output) or a STATE MACHINE (steps + transitions) or an ORCHESTRATION (who does what, when) |

**Source tradition:** Coding conversation (stack layers, archetypes), Ackoff (analysis vs synthesis, system vs network), Rich (Strategic Builder Methodology)

---

## Classification Quick Reference

When extracting a distinction, classify it:

| Type | Core Question | Delivery Key |
|------|--------------|--------------|
| **Collapsed** | What two things are being treated as one? | Show the cost of the collapse |
| **Perceptual** | What new category needs to be created? | Name it so they see it everywhere |
| **Inversion** | What assumption is exactly backwards? | Shock them with the flip |
| **Domain-Transfer** | What expert domain maps perfectly here? | Make the analogy collapse into identity |
| **Stance** | Where are they coming from that limits them? | Confront the current stance |
| **Structural** | What system/architecture are they missing? | Zoom out until the pattern appears |

Most distinctions will have a PRIMARY type and a secondary flavor. A collapsed distinction might also be an inversion. A structural distinction might also be a domain transfer. Classify by the primary delivery mechanism — how it should LAND.

---

*Created: February 7, 2026*
*Part of the Distinction System methodology library*
