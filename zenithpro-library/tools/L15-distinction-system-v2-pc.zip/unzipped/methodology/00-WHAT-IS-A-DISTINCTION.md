> **METHODOLOGY DOCUMENT:** This is part of the Distinction System methodology library. It provides the foundational theory that the Finder and Expander skills reference. Read all four methodology docs (00-03) before your first extraction.

# What Is a Distinction?

> **Reference document for the Distinction System.**
> This is the foundational definition that all extraction and delivery work builds from.

---

## The Core Definition

A distinction is a **perceptual capacity created through language** that permanently alters what you can see — and therefore what you can do.

It is NOT:
- A vocabulary word (knowing the term "leverage" is not a distinction)
- A piece of information (knowing a fact doesn't change your perception)
- A technique or skill (you don't need to DO anything — you need to SEE differently)
- A belief (you don't need to believe in it — you use it like a hammer)
- A framework (frameworks are BUILT from distinctions — they sit higher in the hierarchy)

It IS:
- **A new category of perception** — you see things you literally could not see before
- **Created in language** — language doesn't describe reality, it creates what we can perceive within reality
- **Irreversible once truly acquired** — like learning to see healthy vs sick trees, you can't unsee it
- **Immediately actionable** — not because it tells you what to do, but because it reveals what's available
- **A tool, not a concept** — you use it like a hammer; it doesn't require belief, memory, or study

---

## The Forester Analogy

> "I could walk through a forest today and not see anything. But if tomorrow I walk through that same forest with a forester and they explain how to spot a healthy tree from a sick tree, which trees are great to make fires and which ones are great to live off of, then every walk through that forest from that day forward I would see things that I hadn't seen before. And because I had seen things that I hadn't seen before, I could do things that I hadn't done before."

This captures the three properties:
1. **Before** — you walk through the forest and see "trees"
2. **The distinction lands** — someone points out categories you didn't have
3. **After** — the same forest now contains information it didn't contain before, and that information enables action it didn't enable before

The forest didn't change. **You** changed. And you can't go back.

---

## How Distinctions Differ from Related Concepts

### Distinctions vs Information

**Information** tells you something exists.
**A distinction** makes you able to perceive it in the wild.

You can know intellectually that there are "healthy trees" and "sick trees." That's information. When you can SPOT one from fifty feet away by the bark pattern — that's a distinction. The difference is automatic perception vs stored knowledge.

**Test:** Information requires recall. Distinctions require no recall — they show up on their own in the field.

### Distinctions vs Mechanisms

A **mechanism** is a named system that explains HOW something works (e.g., "Trained Incapacity" — the process by which expertise becomes a prison). Mechanisms CAN become distinctions if you build them out fully — when someone can spot Trained Incapacity happening in real time without being told, the mechanism has become a distinction. But a mechanism on its own is an explanation, not a perceptual shift.

### Distinctions vs Frameworks

The hierarchy: **Distinctions → Mental Models → Frameworks**

Frameworks are MADE from mental models, which are made from distinctions. A Distinctions-Opportunity Matrix is a framework — it's built from underlying distinctions (perception creates opportunity, the gap between reality and what you see, etc.). The framework is the teaching vehicle. The distinctions are the atoms inside it.

### Distinctions vs Skills

**Skills** require practice and execution (hands).
**Distinctions** require only perception (eyes).

Example: "See through the eyes of an expert coder — without needing the hands of an expert coder." Students get the distinction layer, and AI provides the execution layer. This illustrates the fundamental architecture of a distinction-driven program.

---

## Five Properties of a True Distinction

### 1. Perceptual, Not Informational

A distinction changes what you can SEE, not what you KNOW. It creates a new category in your perceptual field. Once created, that category automatically processes incoming experience without conscious effort.

> "Our consciousness creates reality by making distinctions." — Niklas Luhmann

### 2. Created in Language

Distinctions are linguistic acts. The right words, in the right context, with the right contrast, create new perceptual categories. This is not metaphorical — language literally structures what humans can perceive.

> "Language does not describe a pre-existing world, but creates the world about which it speaks." — Landmark tradition

### 3. Binary at the Core (A vs Not-A)

Every distinction has a boundary. The simplest form is a contrast: healthy tree vs sick tree, owner vs victim, strategy vs tactics. Ackoff structured all 57 of his management distinctions as A vs B pairs. Djukich calls them "dramatic, graphic opposites." The boundary IS the distinction — it separates what was previously collapsed.

### 4. Irreversible Once Acquired

Like riding a bicycle — once you "get it," you can't unget it. Djukich: "You might remember when you first 'got it' that you could swim or roller skate. You had your 'now I see' moment and it was yours forever."

**Important caveat:** A single flash of insight doesn't automatically make it permanent. The insight can fade if it isn't anchored. This is why delivery design matters — the Distinction Expander must ensure each distinction STICKS, not just flashes.

### 5. Enables Action Without Prescribing It

A distinction doesn't tell you what to do. It shows you what's there. Once you can see healthy vs sick trees, you CHOOSE what to do with that — build fires, avoid poison, find shelter. The distinction creates the possibility space. Your agency fills it.

---

## The Ontological Foundation

The understanding of distinctions draws from the Landmark/Werner Erhard ontological tradition, which makes claims about the nature of reality itself:

**Reality arises in language.** What we call "the world" is not a fixed thing we observe — it's constituted through the distinctions we bring to it. More distinctions = more world.

**"Occurring" vs "is."** Things don't just "be" a certain way — they "occur" for us within our current set of distinctions. When we get a new distinction, the same situation occurs differently. The situation didn't change. Our occurring did.

**Three ways of knowing:**
1. **Understanding** — intellectual grasp (weakest — "I know about it")
2. **Experiencing** — felt encounter (stronger — "I've been through it")
3. **Creating** — generative capacity (strongest — "I can produce it at will")

Distinctions aim for level 3. Not "I understand the difference between strategy and tactics" but "I can't look at a business plan without seeing which is which."

---

## The Qualification Test

To determine whether something IS a genuine distinction (vs information, mechanism, framework, etc.), apply these filters:

| Filter | Question | Must Be |
|--------|----------|---------|
| **Perceptual** | Does this change what you can SEE (not just what you know)? | Yes |
| **Binary** | Can you express it as A vs Not-A or A vs B? | Yes, at the core |
| **Automatic** | Once acquired, does it work without conscious recall? | Yes |
| **Domain-portable** | Does it reveal things in new situations without re-teaching? | Yes |
| **Action-enabling** | Does it open new action space (not prescribe specific actions)? | Yes |
| **Pre-framework** | Is it atomic (not built from other distinctions)? | Ideally yes |

**Failed examples:**
- "The 4 Ps of Marketing" — this is a framework, not a distinction
- "Revenue was $50K last month" — this is information
- "Use the STAR method for interviews" — this is a technique
- "Trained Incapacity is when expertise becomes a prison" — this is a mechanism (can become a distinction when fully delivered)

**Passed examples:**
- Healthy tree vs sick tree
- Strategy vs tactics
- Owner vs victim
- Information vs transformation
- Having a problem vs doing a problem

---

## The Hierarchy: From Atoms to Architectures

```
DISTINCTIONS (atomic perceptual units)
    ↓ combine into
MENTAL MODELS (connected sets of distinctions that explain a domain)
    ↓ combine into
FRAMEWORKS (structured systems with names, steps, and applications)
    ↓ combine into
METHODOLOGIES (complete operational systems)
```

A well-designed program teaches at ALL four levels. But the distinction level is the foundation — without it, the frameworks are just instructions people can't use.

---

## Sources Synthesized Here

1. Rich Schefren — Distinctions-Opportunity Matrix (Pink Sheet 2.0)
2. Rich Schefren — BCP038: Distinctions and the Big Idea Process
3. Rich Schefren — Personal List of Distinctions
4. Werner Erhard / Landmark tradition — Multiple essays on ontological distinctions
5. Russell Ackoff — Differences That Make a Difference (57 management distinctions)
6. Dusan Djukich — Straight-Line Leadership (distinctions as tools for inner stances)
7. Thomas J. Leonard — Collapsed Distinctions
8. ChatGPT conversation — Coding Distinctions for Non-Coders
9. Ontological Distinctions glossary (Life Leadership)
10. Landmark Forum participant accounts (Distinctions Demystified)

---

*Created: February 7, 2026*
*Purpose: Foundation reference for Distinction Finder and Distinction Expander skills*
