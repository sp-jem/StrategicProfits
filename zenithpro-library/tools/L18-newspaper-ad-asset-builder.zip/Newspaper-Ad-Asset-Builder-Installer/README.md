# Newspaper Ad Asset Builder

Build newspaper-style ad images across all major formats -- carousel, story, reel, feed, email header, and OG/hero -- with automated safe zone compliance and platform-ready output.

---

## What This Skill Does

The Newspaper Ad Asset Builder turns your copy into professional newspaper-style ad creatives. It handles:

- **HTML/CSS design** -- Builds each ad as a self-contained HTML layout with serif fonts, column layouts, editorial mastheads, and the full newspaper aesthetic
- **High-res PNG capture** -- Uses Puppeteer to screenshot HTML at 2x retina resolution
- **Multi-format output** -- Generates variants for every major ad placement from a single source design
- **Safe zone enforcement** -- Automatically audits story/reel/carousel assets against platform UI overlay zones
- **Video reels** -- Builds slideshow reels from static frames using ffmpeg xfade transitions
- **Input gathering** -- Walks you through headline, body copy, CTA, and brand elements before building
- **Fabrication guardrails** -- Never invents testimonials, stats, or endorsements; uses placeholders for missing proof

---

## What You Need

- **Claude Code** -- The skill runs inside Claude Code
- **Node.js** -- Required for the Puppeteer capture scripts (`capture-html.js`, `safe-zone-audit.js`)
- **Puppeteer** -- Install with `cd /tmp && npm install puppeteer` (one-time per session)
- **ffmpeg** (optional) -- Only needed if you want to build video reels from static frames

If you don't have Node.js, you can still use the skill -- Claude will generate the HTML/CSS directly and you can screenshot manually. The scripts automate the capture process but aren't strictly required.

---

## Installation

### Mac / Linux

```bash
chmod +x install.sh
./install.sh
```

### Windows (PowerShell)

```powershell
.\install.ps1
```

### Manual Installation

1. Create the directory: `~/.claude/skills/newspaper-ad-asset-builder/`
2. Copy `skills/newspaper-ad-asset-builder/SKILL.md` to that directory
3. Copy the `scripts/` folder (contains `capture-html.js` and `safe-zone-audit.js`)
4. Copy the `references/` folder (contains `platform-specs.md`)
5. Create an empty `assets/` folder
6. Restart Claude Code

---

## How to Use

After installation, use natural language prompts in Claude Code:

**Basic:**
> "Create a newspaper-style ad for my coaching program"

**With details:**
> "Build a newspaper ad with the headline 'The Hidden Tax Costing You $47K/Year' -- target audience is business owners, CTA is 'Register free at example.com'"

**Multi-format:**
> "Create newspaper ad assets in carousel, story, and feed formats for my product launch"

**With brand elements:**
> "Build a newspaper ad using my brand colors (#1a1a4e and #c5960c), Playfair Display for headlines"

**Video reel:**
> "Turn my newspaper ad carousel into a 15-second reel with slide transitions"

The skill will walk you through any missing inputs before building.

---

## Output Formats

| Format | Dimensions (CSS) | Output @2x | Aspect Ratio | Best For |
|--------|-------------------|------------|--------------|----------|
| Carousel | 1080x1080 | 2160x2160 | 1:1 | Feed ads, multi-slide sequences |
| Story | 540x960 | 1080x1920 | 9:16 | Instagram/Facebook stories |
| Reel | 540x960 | 1080x1920 | 9:16 | Instagram/Facebook reels |
| Feed (vertical) | 1080x1350 | 2160x2700 | 4:5 | Maximum feed real estate |
| OG / Hero | 1200x630 | 2400x1260 | ~1.9:1 | Social cards, landing pages |
| Email Header | 600x auto | Variable | Variable | Email campaigns |

---

## What's Included

| File | Purpose |
|------|---------|
| `SKILL.md` | Complete skill instructions (302 lines) -- design principles, input protocol, workflow, format specs |
| `scripts/capture-html.js` | Puppeteer script to capture HTML layouts as high-res PNGs with viewport, scale, selector, and clip support |
| `scripts/safe-zone-audit.js` | Automated safe zone checker for story, reel, carousel, and feed formats -- returns pass/fail with violation details |
| `references/platform-specs.md` | Complete 2026 platform dimensions, safe zones, file limits, and CSS conversion reference |
| `assets/` | Output directory for generated assets |

---

## Works Best With

- **Ad Copy Creator** -- Generate the copy first, then use this skill to build the visual assets
- **Ad Image Creator** -- For photo-based ads (this skill is specifically for newspaper/editorial-style text-heavy ads)
- **Copy Arsenal** -- For polishing headlines and body copy before building the ad

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Fonts not loading in captures | Ensure `--wait 2000` (default) or increase for complex layouts |
| Puppeteer not found | Run `cd /tmp && npm install puppeteer` |
| Safe zone violations | Run `safe-zone-audit.js` and adjust content positioning |
| Output looks blurry | Always use `--scale 2` for retina output |
| Video reel too long | Use 3-5 frames at 3-5 seconds each; avoid zoompan |
