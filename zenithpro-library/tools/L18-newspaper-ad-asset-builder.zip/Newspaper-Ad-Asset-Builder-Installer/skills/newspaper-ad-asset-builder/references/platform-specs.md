# Platform Ad Specs & Safe Zones (2026)

## Format Dimensions

| Format | CSS Viewport | Device Scale | Output Pixels | Aspect |
|--------|-------------|-------------|---------------|--------|
| Carousel (feed) | 1080x1080 | 2 | 2160x2160 | 1:1 |
| Story ad | 540x960 | 2 | 1080x1920 | 9:16 |
| Reel | 540x960 | 2 | 1080x1920 | 9:16 |
| Feed (vertical) | 1080x1350 | 2 | 2160x2700 | 4:5 |
| Landing/OG card | 1200x630 | 2 | 2400x1260 | ~1.9:1 |
| Email header | 600-700xAuto | 2 | Variable | Variable |

## Safe Zones (actual pixels at output resolution)

### Story Ads (1080x1920)
- **Top**: 270px clear (profile pic, username, "Sponsored" label)
- **Bottom**: 380px clear (CTA button: "Learn More", "Shop Now", etc.)
- **Sides**: 65px each
- **Safe content area**: 950 x 1270px (centered)

### Reels (1080x1920)
- **Top**: 270px clear (same as stories)
- **Bottom**: 670px clear (like/comment/share buttons, caption, audio info)
- **Sides**: 65px each
- **Safe content area**: 950 x 980px (top-heavy — only top 65% reliable)

### Carousel Feed (1080x1080 at CSS scale)
- **All edges**: 100px from each edge (at CSS scale, 200px at 2x output)
- **Practically**: Minimal UI overlay on carousel cards in feed. Page indicator dots at bottom center only. The 100px guideline is conservative — 50-60px side margins acceptable for intentional edge-to-edge designs (newspapers, magazines)

### Feed Images
- **All edges**: 50px minimum from each edge
- **Bottom**: Username/caption appear below image, not overlaid

## Safe Zone CSS Conversion (at 2x scale)
- Story/Reel top: 270px actual = **135px CSS**
- Story bottom: 380px actual = **190px CSS**
- Reel bottom: 670px actual = **335px CSS**
- Sides: 65px actual = **32.5px CSS** (~33px)

## Design Strategy for Safe Zones

**DO**: Extend decorative backgrounds (solid colors, gradients) into danger zones. Place all TEXT within safe zone.

**DON'T**: Shrink content to fit safe zones by compressing into a tiny area. Instead:
- Reduce content volume (3 quotes instead of 5)
- Split across multiple frames
- Use centered layouts with `justify-content: center`

## File Size Limits
- Images: 30MB max (Meta)
- Video: 4GB max (Meta), recommended under 250MB
- Image format: PNG for text-heavy, JPG for photos
- Video codec: H.264, yuv420p, 30fps

## Video Reel Specs
- Resolution: 1080x1920
- Duration: 3-90 seconds (15-30s optimal for ads)
- Codec: H.264 High profile
- Pixel format: yuv420p
- Frame rate: 30fps
- Build from static frames with xfade transitions (0.3-0.5s)

## Sources
- https://adsuploader.com/blog/meta-ads-safe-zones
- https://insights.vaizle.com/instagram-story-dimensions/
- https://adsuploader.com/blog/meta-ads-size
- https://buffer.com/resources/facebook-ad-specs-image-sizes/
