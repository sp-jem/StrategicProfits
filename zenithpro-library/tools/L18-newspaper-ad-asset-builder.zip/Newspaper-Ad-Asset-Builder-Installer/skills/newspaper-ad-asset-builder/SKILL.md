---
name: newspaper-ad-asset-builder
version: 2.0
description: Build ad-ready creative assets from HTML/CSS newspaper-style designs. Captures HTML layouts as high-res PNGs via Puppeteer, generates multiple ad format variants (carousel, story, reel, feed, landing page hero, email header), enforces Instagram/Facebook/Reels safe zone compliance, builds video reels from static frames with ffmpeg. Use when asked to (1) build newspaper-style ad creatives, (2) convert HTML/CSS designs into ad-ready images, (3) build carousel slides, story frames, or reel videos from a design, (4) generate multiple ad format variants from a single source, (5) audit ad assets against platform safe zones, (6) create short video reels/slideshows from static image frames, or (7) capture high-res screenshots of HTML pages. Triggers on "newspaper ad", "build ads", "ad formats", "carousel slides", "story frames", "safe zone", "capture HTML", "screenshot HTML", "build a reel", "ad assets", "newspaper image".
---

# Newspaper Ad Asset Builder v2.0

Design and produce newspaper-style ad creatives across all Meta formats — from creative direction through platform-compliant asset delivery.

## Prerequisites

Ensure Puppeteer is installed: `cd /tmp && npm install puppeteer` (one-time per session).
Run all scripts with `NODE_PATH=/tmp/node_modules` prefix so Puppeteer resolves correctly.
Ffmpeg required for video reels (check `which ffmpeg` or `~/.local/bin/ffmpeg`).

## Newspaper Ad Design & Copy Principles

**This skill produces "newspaper-style" ads — a specific creative format with its own visual language and copywriting conventions.** Understand these principles before building.

### Why the Newspaper Format Works

The newspaper ad format borrows credibility from editorial media. Readers unconsciously associate the visual language of newspapers (columns, serif type, mastheads) with journalism, authority, and vetted information. This is the "advertorial" effect: an ad that looks like an article gets read like an article. The format converts skepticism into curiosity.

### Visual Language of Newspaper Ads

- **Serif fonts are mandatory for headlines** — Playfair Display, Georgia, Times New Roman, or similar. Serif type signals authority and editorial quality.
- **Column layouts** — Single or two-column body copy mimics newspaper editorial layout. Avoid full-width body text that looks like a web page.
- **Editorial feel** — Mastheads, datelines, bylines, pull quotes, and thin rule dividers create the newspaper illusion.
- **"Advertorial" style** — The best newspaper ads blur the line between editorial content and advertisement. Include a subtle "ADVERTISEMENT" disclaimer for FTC compliance while maintaining the editorial aesthetic.
- **White space is structural** — Generous margins, line spacing, and padding between elements. Cramped layouts destroy the editorial illusion.
- **High-contrast typography** — Bold/heavy headlines against lighter body copy. Size differential of at least 3:1 between headline and body.

### Copywriting Principles

- **Headline dominance** — The headline is the ad. 80% of readers will read the headline and nothing else. Spend 50% of creative effort here. Headlines should promise a specific benefit, provoke curiosity, or make a bold claim.
- **Benefit-driven body copy** — Lead with what the reader gets, not what the product is. Every paragraph must earn the next paragraph.
- **Short paragraphs** — 2-3 sentences max. Newspaper columns are narrow; long paragraphs become walls of text.
- **Strong, singular CTA** — One clear action. Not three options. "Call now," "Visit this URL," "Scan this code." Place at the bottom with visual emphasis.
- **Scannable structure** — Subheadings, bold key phrases, bullet points. Readers scan before they read.
- **Credibility markers** — Author byline, dateline, specific numbers, named sources. These reinforce the editorial framing.

### Common Newspaper Ad Mistakes to Avoid

- Using sans-serif fonts for headlines (breaks the newspaper illusion)
- Centering all text (newspapers use left-aligned or justified body copy)
- Too many CTAs competing for attention
- Stock photo look instead of editorial photography style
- Ignoring white space — cramming content edge-to-edge
- Making it look like a flyer instead of an article
- Forgetting the "advertorial" disclaimer

### Visual Design Direction

When building the HTML/CSS, apply these visual design principles to achieve the newspaper aesthetic:

**Image & Photo Suggestions:**
- **Vintage textures** — Subtle paper grain, aged parchment, or newsprint texture as background. Use CSS `background-image` with a low-opacity texture overlay.
- **Halftone effects** — Apply CSS halftone dot patterns to photos for a printed-press look. Use `filter: contrast(1.5) grayscale(0.3)` or SVG filters for authentic newsprint reproduction.
- **Black & white or desaturated photography** — Full-color photos break the newspaper illusion. Desaturate to 60-80% or go full grayscale.
- **Editorial-style photography** — Candid, documentary-style images over polished stock photos. If no images are available, the text-only newspaper format is equally effective.
- **Line art / engravings** — Small decorative illustrations in an etching or woodcut style reinforce the vintage editorial feel.

**Layout Composition Principles:**
- **Grid-based structure** — Use CSS Grid or Flexbox to create column layouts (1-column for story/reel, 2-column for wider formats like OG/Hero or Feed).
- **Hierarchy through size** — Headline at 3-5x body font size. Subheadline at 1.5-2x. Body at base size. CTA at 1.2-1.5x with visual emphasis (box, underline, bold).
- **Rule lines (thin borders)** — Use `border-top: 1px solid #333` between sections. Horizontal rules are a newspaper signature element.
- **Pull quotes** — Extract a compelling line from the body copy, display it in larger italic type with decorative quotation marks. Breaks up body copy and adds visual interest.
- **Masthead area** — Top of the ad should include a publication-style header (brand name styled as newspaper name, dateline, volume/issue numbers if applicable).

**Color Palette Recommendations:**
- **Primary newspaper palette:** Black (#000), Dark Gray (#333), Medium Gray (#666), Off-White/Cream (#f5f0eb or #faf8f5)
- **Accent options:** Deep Red (#8b0000) for highlights/CTAs, Navy (#1a1a4e) for subheadings, Gold/Amber (#c5960c) for premium feel
- **Avoid:** Bright/saturated colors, neon tones, gradients. These destroy the newspaper aesthetic.
- **Paper background:** Never use pure white (#fff). Use off-white (#f5f0eb), light cream (#faf8f5), or warm gray (#e8e4df) to simulate newsprint.
- If the student has brand colors, use them sparingly as accents within the newspaper palette — not as dominant background colors.

---

## Input Gathering Protocol

**Before building anything, gather these inputs from the student.** If the student says "make me a newspaper ad" with no details, you MUST ask these questions before proceeding. Do not skip this step or fill in gaps with assumptions.

### Required Inputs (must have before starting)

| Input | What to Ask | Example |
|-------|-------------|---------|
| **Headline** | "What's the main headline for your ad?" | "The Hidden Tax That's Costing You $47K/Year" |
| **Body copy / key message** | "What are the key points or body copy for the ad?" (bullet points acceptable) | 3-5 key benefit statements or a short paragraph |
| **Call to action** | "What should the reader do? (URL, phone, QR code, etc.)" | "Register at example.com/free" |

### Recommended Inputs (ask for, proceed with defaults if not provided)

| Input | What to Ask | Default if Not Provided |
|-------|-------------|------------------------|
| **Brand colors** | "Do you have brand colors? (hex codes ideal)" | Newspaper palette: black, dark gray (#333), off-white (#f5f0eb) |
| **Font preferences** | "Any specific fonts? (serif, sans-serif, or exact names)" | Classic newspaper: Playfair Display (headlines), Lora (body) |
| **Target audience** | "Who is this ad targeting?" | Use offer context to infer; flag assumption |
| **Brand voice** | "What tone — formal, casual, bold, authoritative?" | Default to authoritative/editorial (newspaper style) |

### Optional Inputs (ask once, don't block on)

| Input | Notes |
|-------|-------|
| Logo file/description | If provided, incorporate into header or footer |
| Specific dimensions | Default to full multi-format suite if not specified |
| Reference examples | Helpful for style matching |
| Platform targets | Determines which format variants to build |

### Brand Input Capture

When the student provides brand elements, capture them explicitly and apply consistently across ALL format variants:

- **Primary color:** ______ (hex)
- **Secondary color:** ______ (hex)
- **Accent color:** ______ (hex, optional)
- **Headline font:** ______
- **Body font:** ______
- **Logo:** [file path or description]
- **Voice/tone:** [formal / casual / bold / authoritative / other]

If the student's brand font is not available on Google Fonts, suggest the closest available alternative and confirm before proceeding.

---

## Pre-Flight Checklist (Input Validation)

Before starting production, verify you have minimum viable inputs. Run this checklist:

- [ ] **Headline exists** — at least one headline provided or generated and approved
- [ ] **Body copy exists** — key points, bullet points, or paragraph provided (not empty)
- [ ] **CTA exists** — clear action the reader should take
- [ ] **Brand colors captured** — provided by student OR defaults confirmed
- [ ] **Target audience identified** — provided or inferred and flagged

**If any REQUIRED input is missing:** Stop and ask the student. Do not proceed with placeholder content for required fields.

**If RECOMMENDED inputs are missing:** State your defaults, proceed, and note assumptions in your output summary.

---

## Fabrication Guardrails (MANDATORY)

**Newspaper-style ads are inherently persuasive formats. Fabrication risk is high. These rules are non-negotiable.**

- **Never invent testimonials.** If the ad needs a testimonial, the student must provide a real one. Use `[PLACEHOLDER: Need real testimonial from customer]` if missing.
- **Never fabricate statistics or data points.** No made-up percentages, dollar figures, or "studies show" claims. Use `[PLACEHOLDER: Need verified statistic for X]` if missing.
- **Never create fake endorsements.** No "as seen in Forbes/NYT/etc." unless the student confirms real media coverage. No invented expert quotes.
- **Never invent "as seen in" or media mentions.** These are verifiable claims that create legal liability.
- **Flag unverified student claims.** If the student provides claims you cannot verify (e.g., "our product increases revenue 300%"), include them but flag: *"I'll include this — make sure you can substantiate it before publishing."*
- **Use placeholders for missing proof elements.** Format: `[PLACEHOLDER: Need real testimonial/stat/proof point for X]`
- **FTC compliance note:** Advertising claims must be truthful and substantiated. Remind the student: *"Any specific results claims, testimonials, or endorsements in this ad must comply with FTC advertising guidelines. Ensure all claims are truthful and you have documentation to support them."*

Only use content the student provides. When in doubt, use a placeholder and flag it.

---

## Workflow

**Before starting production, complete these pre-production steps in order:**
1. Run the **Input Gathering Protocol** (above) -- collect all required, recommended, and optional inputs
2. Run the **Pre-Flight Checklist** (above) -- verify minimum viable inputs exist
3. Apply **Fabrication Guardrails** -- confirm all claims are student-provided; flag anything unverifiable
4. Check **Content Volume Guidelines** (below) -- evaluate text volume against target format limits before building

Only proceed to production when pre-flight checklist passes.

### 1. Design the HTML/CSS source

Build each ad variant as self-contained HTML with inline styles and Google Fonts imports. Set exact CSS dimensions matching the target viewport (e.g., `width:1080px; height:1080px` for carousel).

**During design, apply:**
- **Newspaper Ad Design & Copy Principles** (above) -- serif fonts, column layouts, editorial styling, headline dominance
- **Visual Design Direction** (above) -- image treatment, layout composition, color palette, typography hierarchy
- **Brand Input Capture** (above) -- student's colors, fonts, logo, and tone applied consistently across all variants
- **Content Volume Guidelines** (below) -- respect per-format word limits; do not shrink fonts to fit excess text

### 2. Capture as high-res PNG

Use `scripts/capture-html.js`:

```bash
node scripts/capture-html.js \
  --input design.html --output Slide-1.png \
  --width 1080 --height 1080 --scale 2
```

Key flags:
- `--scale 2` = retina (2x output: 1080 CSS → 2160px actual). Always use 2.
- `--selector "#slide-1"` = capture specific element only
- `--clip-h 420` = crop to height (for email headers)
- `--wait 2000` = font settle time (default, increase for complex layouts)

### 3. Audit safe zones (MANDATORY before delivery)

Use `scripts/safe-zone-audit.js`:

```bash
node scripts/safe-zone-audit.js \
  --input story-frame.html --format story
```

Formats: `story`, `reel`, `carousel`, `feed`. Returns exit code 1 if violations found.

For inline HTML (Puppeteer `setContent`), use the programmatic approach: call `getBoundingClientRect()` on all text elements and check against safe zone thresholds. See references/platform-specs.md.

**Never deliver story/reel assets without passing safe zone audit.**

### 4. Build video reels

Create slideshow reels from static frames using ffmpeg xfade:

```bash
ffmpeg -y \
  -loop 1 -t 4 -i frame1.png \
  -loop 1 -t 4 -i frame2.png \
  -loop 1 -t 4 -i frame3.png \
  -filter_complex \
    "[0:v]scale=1080:1920,setsar=1,fps=30[a]; \
     [1:v]scale=1080:1920,setsar=1,fps=30[b]; \
     [2:v]scale=1080:1920,setsar=1,fps=30[c]; \
     [a][b]xfade=transition=slideleft:duration=0.5:offset=3.5[ab]; \
     [ab][c]xfade=transition=slideleft:duration=0.5:offset=7[vout]" \
  -map "[vout]" -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -r 30 \
  output.mp4
```

Transitions: `fade`, `slideleft`, `slideright`, `slideup`, `slidedown`, `wipeleft`.
Duration formula: offset_N = offset_(N-1) + dur_N - fade_duration.
Target 10-30 seconds. 3-5 frames at 3-5 seconds each.

**Do NOT use zoompan** for converting static images to video — it inflates duration unpredictably. Use xfade between static frames instead.

## Ad Format Quick Reference

| Format | CSS Viewport | Output @2x | Notes |
|--------|-------------|-----------|-------|
| Carousel | 1080x1080 | 2160x2160 | 1:1, use element screenshots via --selector |
| Story | 540x960 | 1080x1920 | 9:16, safe zone critical |
| Reel | 540x960 | 1080x1920 | 9:16, bottom 35% has UI overlay |
| Feed vertical | 1080x1350 | 2160x2700 | 4:5, most screen real estate |
| OG/Hero | 1200x630 | 2400x1260 | Social card / landing page |
| Email header | 600-700xAuto | Variable | Crop with --clip-h |

## Content Volume Guidelines

**Evaluate content volume BEFORE building HTML.** Too much text is the #1 cause of cramped, ineffective ads. Guide the student to edit down or split across formats proactively.

| Format | Headline | Body Copy | CTA | Total Max Words |
|--------|----------|-----------|-----|-----------------|
| **Carousel slide** | 1 headline (8-12 words) | 3-5 lines / ~50 words max | 1 short CTA | ~70 words |
| **Story frame** | 1 headline (5-8 words) | 1-2 lines / ~30 words max | 1 CTA (button-style) | ~45 words |
| **Reel frame** | 1 headline (5-8 words) | 1-2 lines / ~25 words max | 1 CTA | ~40 words |
| **Feed post (4:5)** | 1-2 headlines (10-15 words) | 5-8 lines / ~150 words max | 1 CTA | ~175 words |
| **OG/Hero** | 1 headline (6-10 words) | 1 subheadline / ~20 words | 1 CTA optional | ~40 words |
| **Email header** | 1 headline + 1 subheadline | None (headline + subheadline only) | None | ~25 words |

**When the student provides too much text:**
1. Show them the volume guideline for their target format
2. Suggest splitting across carousel slides or story frames (e.g., "This is ~300 words — that's 6 carousel slides worth. Want to split it into a 5-slide carousel?")
3. Offer to help them edit down to the essentials
4. Never compress excess text by shrinking font size — this destroys readability

---

## Safe Zone Rules

**Story ads**: Top 270px, bottom 380px, sides 65px (actual pixels at 1080x1920)
**Reels**: Top 270px, bottom 670px, sides 65px
**Carousel**: 100px from all edges (at 1080 CSS scale) — conservative; 50-60px acceptable for intentional edge-to-edge designs

Design strategy: Extend decorative backgrounds into danger zones. Keep all TEXT within safe area. If content doesn't fit, reduce content volume or split across frames — never compress into a cramped space.

Full specs: See [references/platform-specs.md](references/platform-specs.md).

## Common Pitfalls

- **Fonts not loading**: Always `await page.evaluate(() => document.fonts.ready)` + 2000ms wait
- **Preview server dropping**: Use `file://` protocol instead of localhost for Puppeteer captures
- **Video too long**: Never use zoompan with static images; use xfade slideshow instead
- **Cramped safe zones**: Don't force 5 items into safe area — use 3 items with larger text, or split across frames
- **File:// CORS**: Add `--allow-file-access-from-files` to Puppeteer launch args

## Delivery Checklist

When delivering finished assets to the student, include a summary covering:

- [ ] **Formats produced** — List each format variant and its file path
- [ ] **Brand elements applied** — Confirm colors, fonts, logo usage (or note defaults used)
- [ ] **Safe zone audit results** — Confirm all story/reel assets passed safe zone audit
- [ ] **Assumptions made** — List any defaults or inferences (e.g., "Used newspaper palette since no brand colors provided")
- [ ] **Placeholders remaining** — List any `[PLACEHOLDER: ...]` tags that need student input before publishing
- [ ] **FTC reminder** — If the ad contains specific claims, testimonials, or endorsements, remind: *"Ensure all claims are truthful, substantiated, and FTC-compliant before publishing."*

---

## Resources

- **scripts/capture-html.js** — Puppeteer capture script with viewport, scale, selector, clip support
- **scripts/safe-zone-audit.js** — Automated safe zone checker (story/reel/carousel/feed formats)
- **references/platform-specs.md** — Complete platform dimensions, safe zones, file limits, CSS conversions
