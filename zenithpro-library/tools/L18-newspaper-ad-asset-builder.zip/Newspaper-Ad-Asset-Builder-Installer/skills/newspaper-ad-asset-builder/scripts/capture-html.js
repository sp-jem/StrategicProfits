#!/usr/bin/env node
/**
 * capture-html.js — Capture HTML/CSS layouts as high-res PNGs via Puppeteer
 *
 * Usage:
 *   node capture-html.js --input <html-file-or-url> --output <output.png> \
 *     --width 1080 --height 1080 [--scale 2] [--selector ".slide"] [--wait 2000]
 *
 * Options:
 *   --input      HTML file path or URL to capture
 *   --output     Output PNG file path
 *   --width      Viewport width in CSS pixels
 *   --height     Viewport height in CSS pixels
 *   --scale      Device scale factor (default: 2 for retina)
 *   --selector   CSS selector to screenshot (element only). Omit for full page.
 *   --wait       Additional wait in ms after fonts load (default: 2000)
 *   --clip-h     Clip height from top of element (for email header crops)
 */

const puppeteer = require('puppeteer');
const path = require('path');

function parseArgs() {
  const args = {};
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i += 2) {
    args[argv[i].replace(/^--/, '')] = argv[i + 1];
  }
  return args;
}

(async () => {
  const args = parseArgs();
  if (!args.input || !args.output) {
    console.error('Usage: node capture-html.js --input <file/url> --output <out.png> --width N --height N');
    process.exit(1);
  }

  const width = parseInt(args.width) || 1080;
  const height = parseInt(args.height) || 1080;
  const scale = parseInt(args.scale) || 2;
  const wait = parseInt(args.wait) || 2000;
  const selector = args.selector || null;
  const clipH = args['clip-h'] ? parseInt(args['clip-h']) : null;

  const browser = await puppeteer.launch({
    headless: 'new',
    executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args: ['--no-sandbox', '--allow-file-access-from-files']
  });

  const page = await browser.newPage();
  await page.setViewport({ width, height, deviceScaleFactor: scale });

  // Load content
  const input = args.input;
  if (input.startsWith('http') || input.startsWith('file://')) {
    await page.goto(input, { waitUntil: 'networkidle0', timeout: 30000 });
  } else {
    await page.goto(`file://${path.resolve(input)}`, { waitUntil: 'networkidle0', timeout: 30000 });
  }

  // Wait for fonts and additional settle time
  await page.evaluate(() => document.fonts.ready);
  await new Promise(r => setTimeout(r, wait));

  // Capture
  const screenshotOpts = { path: args.output, type: 'png' };

  if (selector) {
    const el = await page.$(selector);
    if (!el) {
      console.error(`Selector "${selector}" not found`);
      process.exit(1);
    }
    if (clipH) {
      const box = await el.boundingBox();
      await page.screenshot({
        ...screenshotOpts,
        clip: { x: box.x, y: box.y, width: box.width, height: Math.min(clipH, box.height) }
      });
    } else {
      await el.screenshot(screenshotOpts);
    }
  } else {
    await page.screenshot(screenshotOpts);
  }

  const outPath = path.resolve(args.output);
  console.log(`Captured: ${outPath} (${width * scale}x${height * scale}px @${scale}x)`);

  await browser.close();
})();
