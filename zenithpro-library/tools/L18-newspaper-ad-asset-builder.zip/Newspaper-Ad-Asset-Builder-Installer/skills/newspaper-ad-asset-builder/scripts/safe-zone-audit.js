#!/usr/bin/env node
/**
 * safe-zone-audit.js — Audit HTML content against platform safe zones
 *
 * Usage:
 *   node safe-zone-audit.js --input <html-file-or-url> --format <story|reel|carousel|feed>
 *     [--width 540] [--height 960] [--scale 2] [--selector ".slide"]
 *
 * Checks all text elements against platform-specific safe zones.
 * Returns exit code 0 if all pass, 1 if any violations found.
 */

const puppeteer = require('puppeteer');
const path = require('path');

// Platform safe zones in ACTUAL pixels (after device scale)
const SAFE_ZONES = {
  story: { top: 270, bottom: 380, sides: 65, width: 1080, height: 1920 },
  reel:  { top: 270, bottom: 670, sides: 65, width: 1080, height: 1920 },
  carousel: { edges: 100, width: 1080, height: 1080 },  // all 4 edges
  feed: { edges: 50, width: 1080, height: 1080 }
};

function parseArgs() {
  const args = {};
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i += 2) {
    args[argv[i].replace(/^--/, '')] = argv[i + 1];
  }
  return args;
}

(async () => {
  const args = parseArgs();
  if (!args.input || !args.format) {
    console.error('Usage: node safe-zone-audit.js --input <file/url> --format <story|reel|carousel|feed>');
    process.exit(1);
  }

  const format = args.format;
  const zone = SAFE_ZONES[format];
  if (!zone) {
    console.error(`Unknown format: ${format}. Use: story, reel, carousel, feed`);
    process.exit(1);
  }

  const scale = parseInt(args.scale) || 2;
  const width = parseInt(args.width) || (format === 'story' || format === 'reel' ? 540 : 1080);
  const height = parseInt(args.height) || (format === 'story' || format === 'reel' ? 960 : 1080);
  const selector = args.selector || null;

  const browser = await puppeteer.launch({
    headless: 'new',
    executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args: ['--no-sandbox', '--allow-file-access-from-files']
  });

  const page = await browser.newPage();
  await page.setViewport({ width, height, deviceScaleFactor: scale });

  const input = args.input;
  if (input.startsWith('http') || input.startsWith('file://')) {
    await page.goto(input, { waitUntil: 'networkidle0', timeout: 30000 });
  } else {
    await page.goto(`file://${path.resolve(input)}`, { waitUntil: 'networkidle0', timeout: 30000 });
  }

  await page.evaluate(() => document.fonts.ready);
  await new Promise(r => setTimeout(r, 1500));

  // Get bounding boxes of all text-bearing elements
  const boxes = await page.evaluate((sel) => {
    const root = sel ? document.querySelector(sel) : document.body;
    if (!root) return [];
    const rootRect = root.getBoundingClientRect();

    const textEls = root.querySelectorAll('h1, h2, h3, h4, h5, h6, p, div, span, blockquote, a, li, label');
    const results = [];

    for (const el of textEls) {
      const text = el.textContent.trim();
      // Skip empty, parents with children (avoid double-counting), and very short
      if (!text || text.length < 2) continue;
      if (el.children.length > 0 && el.tagName !== 'BLOCKQUOTE') continue;

      const r = el.getBoundingClientRect();
      results.push({
        text: text.substring(0, 50),
        top: r.top - (sel ? rootRect.top : 0),
        bottom: r.bottom - (sel ? rootRect.top : 0),
        left: r.left - (sel ? rootRect.left : 0),
        right: r.right - (sel ? rootRect.left : 0),
        tag: el.tagName
      });
    }
    return results;
  }, selector);

  // Check each element against safe zones
  let violations = 0;
  const maxBottom = zone.height / scale;
  const maxRight = zone.width / scale;

  console.log(`\n=== SAFE ZONE AUDIT: ${format.toUpperCase()} ===`);
  console.log(`Canvas: ${zone.width}x${zone.height}px (CSS: ${width}x${height}px @${scale}x)`);

  if (format === 'story' || format === 'reel') {
    const topSafe = zone.top / scale;
    const botSafe = (zone.height - zone.bottom) / scale;
    const sideSafe = zone.sides / scale;

    console.log(`Safe zone: top>${topSafe}px bottom<${botSafe}px sides>${sideSafe}px (CSS)\n`);

    for (const box of boxes) {
      const issues = [];
      if (box.top < topSafe) issues.push(`TOP (${Math.round(box.top)}px < ${topSafe}px)`);
      if (box.bottom > botSafe) issues.push(`BOT (${Math.round(box.bottom)}px > ${botSafe}px)`);
      if (box.left < sideSafe) issues.push(`LEFT (${Math.round(box.left)}px < ${sideSafe}px)`);
      if (box.right > maxRight - sideSafe) issues.push(`RIGHT (${Math.round(box.right)}px > ${maxRight - sideSafe}px)`);

      if (issues.length > 0) {
        violations++;
        console.log(`  \u274c "${box.text}" \u2014 ${issues.join(', ')}`);
      } else {
        console.log(`  \u2705 "${box.text}"`);
      }
    }
  } else {
    // Carousel/feed: uniform edge margin
    const edge = zone.edges;
    console.log(`Safe zone: ${edge}px from all edges (CSS)\n`);

    for (const box of boxes) {
      const issues = [];
      if (box.top < edge) issues.push(`TOP`);
      if (box.bottom > height - edge) issues.push(`BOT`);
      if (box.left < edge) issues.push(`LEFT`);
      if (box.right > width - edge) issues.push(`RIGHT`);

      if (issues.length > 0) {
        violations++;
        console.log(`  \u26a0\ufe0f  "${box.text}" \u2014 ${issues.join(', ')}`);
      }
    }
    if (violations === 0) console.log('  \u2705 All content within safe zone');
  }

  console.log(`\n${violations === 0 ? '\u2705 PASS' : `\u274c ${violations} VIOLATION(S) FOUND`}`);

  await browser.close();
  process.exit(violations > 0 ? 1 : 0);
})();
