# Newspaper Ad Asset Builder -- Installation Guide

---

## Before You Start

1. **Claude Code must be installed** -- This skill runs inside Claude Code. If you don't have it yet, install it first: https://claude.ai/claude-code
2. **Know your terminal** -- You'll need to open Terminal (Mac) or PowerShell (Windows) and navigate to this folder
3. **Node.js recommended** -- The capture scripts require Node.js. Download from https://nodejs.org if you don't have it. (The skill works without Node.js -- Claude generates HTML directly -- but the automated PNG capture and safe zone audit scripts need it.)

---

## Option A: Automated Install (Mac / Linux)

**Time: ~30 seconds**

1. Open Terminal
2. Navigate to this folder:
   ```bash
   cd "/path/to/Newspaper-Ad-Asset-Builder-Installer"
   ```
3. Make the script executable and run it:
   ```bash
   chmod +x install.sh
   ./install.sh
   ```
4. You should see:
   ```
   SUCCESS — newspaper-ad-asset-builder installed (302 lines)
     + scripts/capture-html.js
     + scripts/safe-zone-audit.js
     + references/platform-specs.md
   ```
5. **Restart Claude Code** (quit and reopen)

---

## Option B: Automated Install (Windows)

**Time: ~30 seconds**

1. Open PowerShell
2. Navigate to this folder:
   ```powershell
   cd "C:\path\to\Newspaper-Ad-Asset-Builder-Installer"
   ```
3. Run the installer:
   ```powershell
   .\install.ps1
   ```
   If you get an execution policy error, run this first:
   ```powershell
   Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
   ```
4. You should see:
   ```
   SUCCESS — newspaper-ad-asset-builder installed (302 lines)
   ```
5. **Restart Claude Code** (quit and reopen)

---

## Option C: Manual Install

**Time: ~2 minutes**

If the scripts don't work or you prefer manual setup:

1. **Create the skill directory:**
   - Mac/Linux: `~/.claude/skills/newspaper-ad-asset-builder/`
   - Windows: `%USERPROFILE%\.claude\skills\newspaper-ad-asset-builder\`

2. **Create subdirectories inside it:**
   - `scripts/`
   - `references/`
   - `assets/`

3. **Copy these files** from this installer's `skills/newspaper-ad-asset-builder/` folder:
   - `SKILL.md` --> into the skill root directory
   - `scripts/capture-html.js` --> into `scripts/`
   - `scripts/safe-zone-audit.js` --> into `scripts/`
   - `references/platform-specs.md` --> into `references/`

4. **Restart Claude Code** (quit and reopen)

---

## Verify Installation

After restarting Claude Code, test with this prompt:

> "Create a newspaper-style ad for my coaching program"

Claude should:
- Recognize the skill and load it
- Ask you for headline, body copy, CTA, and brand details (the Input Gathering Protocol)
- Build HTML/CSS with newspaper editorial styling
- Offer to capture as PNG and run safe zone audit

If Claude doesn't recognize the skill, check that `SKILL.md` exists at `~/.claude/skills/newspaper-ad-asset-builder/SKILL.md`.

---

## Troubleshooting

### "Permission denied" when running install.sh
```bash
chmod +x install.sh
```

### "Execution policy" error on Windows
```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

### Skill not recognized after install
- Confirm file is at `~/.claude/skills/newspaper-ad-asset-builder/SKILL.md`
- Make sure you fully quit and reopened Claude Code (not just closed the window)
- Check the file isn't empty: `wc -l ~/.claude/skills/newspaper-ad-asset-builder/SKILL.md` should show ~302 lines

### Puppeteer capture scripts fail
- Install Puppeteer: `cd /tmp && npm install puppeteer`
- Run scripts with: `NODE_PATH=/tmp/node_modules node scripts/capture-html.js ...`
- The skill works without Puppeteer -- Claude generates HTML directly. The scripts automate PNG capture.

### Safe zone audit fails
- This is expected behavior -- the audit catches content placed in platform UI overlay zones
- Adjust your design to keep text within the safe zone boundaries, then re-run the audit
- See `references/platform-specs.md` for exact safe zone dimensions per format
