#!/bin/bash
SKILL_NAME="newspaper-ad-asset-builder"
CLAUDE_DIR="$HOME/.claude/skills/$SKILL_NAME"
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)/skills/$SKILL_NAME"

echo ""
echo "=== Newspaper Ad Asset Builder — Installer ==="
echo "Installing skill: $SKILL_NAME"
echo ""

if [ ! -f "$SOURCE_DIR/SKILL.md" ]; then
    echo "ERROR: Cannot find $SOURCE_DIR/SKILL.md"
    exit 1
fi

mkdir -p "$CLAUDE_DIR/scripts"
mkdir -p "$CLAUDE_DIR/references"
mkdir -p "$CLAUDE_DIR/assets"

cp "$SOURCE_DIR/SKILL.md" "$CLAUDE_DIR/SKILL.md"
echo "Installed: SKILL.md"

if [ -d "$SOURCE_DIR/scripts" ]; then
    cp "$SOURCE_DIR/scripts/"* "$CLAUDE_DIR/scripts/" 2>/dev/null
    echo "Installed: scripts/"
fi

if [ -d "$SOURCE_DIR/references" ]; then
    cp "$SOURCE_DIR/references/"* "$CLAUDE_DIR/references/" 2>/dev/null
    echo "Installed: references/"
fi

if [ -f "$CLAUDE_DIR/SKILL.md" ]; then
    LINES=$(wc -l < "$CLAUDE_DIR/SKILL.md")
    echo ""
    echo "SUCCESS — $SKILL_NAME installed ($LINES lines)"
    echo "  + scripts/capture-html.js"
    echo "  + scripts/safe-zone-audit.js"
    echo "  + references/platform-specs.md"
    echo ""
    echo "IMPORTANT: Restart Claude Code for the skill to take effect."
    echo ""
    echo 'Test: "Create a newspaper-style ad for my coaching program"'
else
    echo "FAILED"
    exit 1
fi
