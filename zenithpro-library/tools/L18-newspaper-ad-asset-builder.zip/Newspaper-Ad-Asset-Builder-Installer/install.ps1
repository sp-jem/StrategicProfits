# Newspaper Ad Asset Builder — Installer (Windows)
$ErrorActionPreference = "Stop"

$SKILL_NAME = "newspaper-ad-asset-builder"
$CLAUDE_DIR = Join-Path $env:USERPROFILE ".claude\skills\$SKILL_NAME"
$SOURCE_DIR = Join-Path $PSScriptRoot "skills\$SKILL_NAME"

Write-Host ""
Write-Host "=== Newspaper Ad Asset Builder — Installer ==="
Write-Host "Installing skill: $SKILL_NAME"
Write-Host ""

if (-not (Test-Path (Join-Path $SOURCE_DIR "SKILL.md"))) {
    Write-Host "ERROR: Cannot find $SOURCE_DIR\SKILL.md" -ForegroundColor Red
    exit 1
}

# Create directory structure
New-Item -ItemType Directory -Force -Path (Join-Path $CLAUDE_DIR "scripts") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $CLAUDE_DIR "references") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $CLAUDE_DIR "assets") | Out-Null

# Copy SKILL.md
Copy-Item (Join-Path $SOURCE_DIR "SKILL.md") -Destination (Join-Path $CLAUDE_DIR "SKILL.md") -Force
Write-Host "Installed: SKILL.md"

# Copy scripts
$scriptsDir = Join-Path $SOURCE_DIR "scripts"
if (Test-Path $scriptsDir) {
    Copy-Item (Join-Path $scriptsDir "*") -Destination (Join-Path $CLAUDE_DIR "scripts") -Force
    Write-Host "Installed: scripts/"
}

# Copy references
$refsDir = Join-Path $SOURCE_DIR "references"
if (Test-Path $refsDir) {
    Copy-Item (Join-Path $refsDir "*") -Destination (Join-Path $CLAUDE_DIR "references") -Force
    Write-Host "Installed: references/"
}

# Verify
if (Test-Path (Join-Path $CLAUDE_DIR "SKILL.md")) {
    $lines = (Get-Content (Join-Path $CLAUDE_DIR "SKILL.md")).Count
    Write-Host ""
    Write-Host "SUCCESS — $SKILL_NAME installed ($lines lines)" -ForegroundColor Green
    Write-Host "  + scripts/capture-html.js"
    Write-Host "  + scripts/safe-zone-audit.js"
    Write-Host "  + references/platform-specs.md"
    Write-Host ""
    Write-Host "IMPORTANT: Restart Claude Code for the skill to take effect."
    Write-Host ""
    Write-Host 'Test: "Create a newspaper-style ad for my coaching program"'
} else {
    Write-Host "FAILED" -ForegroundColor Red
    exit 1
}
