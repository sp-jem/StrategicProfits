#!/usr/bin/env bash
# =============================================================================
# VO3 Cinematic Ad Creator — Install Script v1.1
#
# PURPOSE:
#   Installs the vo3-cinematic-ad-creator skill into Claude Code globally.
#   After installation, the skill is available in every Claude Code session
#   on this machine.
#
# USAGE:
#   bash install.sh
#   bash install.sh --force    # overwrite if already installed
#
# INSTALLS TO:
#   ~/.claude/skills/vo3-cinematic-ad-creator/SKILL.md
#
# IDEMPOTENT: Safe to run multiple times. Existing installation preserved
#             unless --force is passed.
#
# REQUIRES: bash 3.2+, Claude Code
# =============================================================================

set -euo pipefail

readonly SCRIPT_VERSION="1.1"
readonly SKILL_NAME="vo3-cinematic-ad-creator"
readonly INSTALL_DIR="$HOME/.claude/skills/$SKILL_NAME"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd)"
readonly SCRIPT_DIR
readonly SOURCE_DIR="$SCRIPT_DIR/$SKILL_NAME"

# ---------------------------------------------------------------------------
# COLOR OUTPUT
# ---------------------------------------------------------------------------

if [[ -t 1 ]]; then
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  YELLOW='\033[1;33m'
  BLUE='\033[0;34m'
  BOLD='\033[1m'
  RESET='\033[0m'
else
  RED='' GREEN='' YELLOW='' BLUE='' BOLD='' RESET=''
fi

print_success() { echo -e "  ${GREEN}OK${RESET}    $1"; }
print_warning() { echo -e "  ${YELLOW}WARN${RESET}  $1"; }
print_error()   { echo -e "  ${RED}ERR${RESET}   $1" >&2; }
print_info()    { echo -e "  ${BLUE}-->${RESET}   $1"; }

# ---------------------------------------------------------------------------
# INTERRUPT HANDLER
# ---------------------------------------------------------------------------

cleanup() {
  echo ""
  print_warning "Install interrupted. Run this script again to retry."
  echo ""
  exit 130
}
trap cleanup SIGINT SIGTERM

# ---------------------------------------------------------------------------
# ARGUMENT PARSING
# ---------------------------------------------------------------------------

FORCE=false

parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --force|-f)
        FORCE=true
        shift
        ;;
      --help|-h)
        echo ""
        echo "VO3 Cinematic Ad Creator — Install Script v${SCRIPT_VERSION}"
        echo ""
        echo "USAGE:"
        echo "  bash install.sh [--force]"
        echo ""
        echo "OPTIONS:"
        echo "  --force, -f   Overwrite existing installation"
        echo "  --help, -h    Show this help"
        echo ""
        echo "INSTALLS TO:"
        echo "  $INSTALL_DIR"
        echo ""
        exit 0
        ;;
      *)
        print_error "Unknown option: $1 (run with --help for usage)"
        exit 1
        ;;
    esac
  done
}

# ---------------------------------------------------------------------------
# PREREQUISITE CHECKS
# ---------------------------------------------------------------------------

check_prerequisites() {
  echo ""
  echo -e "${BOLD}Checking prerequisites...${RESET}"
  echo ""

  local all_ok=true

  # Claude Code
  if command -v claude &>/dev/null; then
    local ver
    ver="$(claude --version 2>/dev/null | head -1 || echo 'version unknown')"
    print_success "Claude Code installed ($ver)"
  else
    print_error "Claude Code is not installed."
    echo "         Download it at: https://claude.ai/download"
    all_ok=false
  fi

  # Source files
  if [[ -f "$SOURCE_DIR/SKILL.md" ]]; then
    print_success "Skill source found: $SOURCE_DIR/SKILL.md"
  else
    print_error "Skill source not found at: $SOURCE_DIR/SKILL.md"
    echo "         Make sure you are running this script from inside the"
    echo "         vo3-cinematic-ad-creator-v${SCRIPT_VERSION} folder."
    all_ok=false
  fi

  if [[ "$all_ok" == "false" ]]; then
    echo ""
    print_error "Prerequisites not met. Fix the issues above and try again."
    echo ""
    exit 1
  fi
}

# ---------------------------------------------------------------------------
# INSTALL
# ---------------------------------------------------------------------------

install_skill() {
  echo ""
  echo -e "${BOLD}Installing skill...${RESET}"
  echo ""

  # Check if already installed
  if [[ -d "$INSTALL_DIR" ]] && [[ "$FORCE" == "false" ]]; then
    print_warning "Already installed at: $INSTALL_DIR"
    print_info "Use --force to overwrite the existing installation."
    echo ""
    return
  fi

  # Create destination directory
  if ! mkdir -p "$INSTALL_DIR"; then
    print_error "Could not create directory: $INSTALL_DIR"
    echo "         Check that you have write permission to your home folder."
    exit 1
  fi

  # Copy skill files
  local copied=0

  for f in "$SOURCE_DIR"/*.md; do
    [[ -f "$f" ]] || continue
    local filename
    filename="$(basename "$f")"
    if cp "$f" "$INSTALL_DIR/$filename"; then
      print_success "$filename → $INSTALL_DIR/$filename"
      ((copied++)) || true
    else
      print_error "Failed to copy: $filename"
    fi
  done

  if [[ $copied -eq 0 ]]; then
    print_error "No files were copied. Check source directory: $SOURCE_DIR"
    exit 1
  fi
}

# ---------------------------------------------------------------------------
# VERIFICATION
# ---------------------------------------------------------------------------

verify_installation() {
  echo ""
  echo -e "${BOLD}Verifying installation...${RESET}"
  echo ""

  local all_ok=true

  if [[ -f "$INSTALL_DIR/SKILL.md" ]]; then
    local lines
    lines="$(wc -l < "$INSTALL_DIR/SKILL.md" | tr -d ' ')"
    print_success "SKILL.md installed ($lines lines)"
  else
    print_error "SKILL.md not found at: $INSTALL_DIR/SKILL.md"
    all_ok=false
  fi

  if [[ "$all_ok" == "false" ]]; then
    echo ""
    print_error "Verification failed. Run with --force to retry."
    exit 1
  fi
}

# ---------------------------------------------------------------------------
# COMPLETION
# ---------------------------------------------------------------------------

print_completion() {
  echo ""
  echo -e "${BOLD}${GREEN}════════════════════════════════════════════════════════${RESET}"
  echo -e "${BOLD}${GREEN}  VO3 Cinematic Ad Creator v${SCRIPT_VERSION} installed!${RESET}"
  echo -e "${BOLD}${GREEN}════════════════════════════════════════════════════════${RESET}"
  echo ""
  echo -e "  ${BOLD}Installed to:${RESET}"
  echo -e "  ${BLUE}$INSTALL_DIR${RESET}"
  echo ""
  echo -e "  ${BOLD}Restart Claude Code, then try:${RESET}"
  echo ""
  echo -e "    ${BLUE}\"Create a VO3 ad for [your product]\"${RESET}"
  echo -e "    ${BLUE}\"Cinematic video ad\"${RESET}"
  echo -e "    ${BLUE}\"Build a Veo 3 ad for [offer] targeting [audience]\"${RESET}"
  echo ""
  echo -e "  ${BOLD}You will need:${RESET}"
  echo -e "  Google Flow (flow.google.com) or AI Studio (aistudio.google.com)"
  echo -e "  DaVinci Resolve or CapCut for post-production"
  echo ""
}

# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

main() {
  echo ""
  echo -e "${BOLD}VO3 Cinematic Ad Creator — Installer${RESET} v${SCRIPT_VERSION}"
  echo "Google Veo 3 video ad production for non-videographers."
  echo ""

  parse_args "$@"
  check_prerequisites
  install_skill
  verify_installation
  print_completion
}

main "$@"
