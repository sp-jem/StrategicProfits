# =============================================================================
# VO3 Cinematic Ad Creator — Windows Install Script v1.1
#
# PURPOSE:
#   Installs the vo3-cinematic-ad-creator skill into Claude Code globally.
#   After installation, the skill is available in every Claude Code session
#   on this machine.
#
# USAGE:
#   .\install.ps1
#   .\install.ps1 -Force      # overwrite if already installed
#
# INSTALLS TO:
#   %USERPROFILE%\.claude\skills\vo3-cinematic-ad-creator\
#
# NOTE: If execution policy blocks this script, run first:
#   Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
# =============================================================================

param(
    [switch]$Force,
    [switch]$Help
)

$ScriptVersion = "1.1"
$SkillName = "vo3-cinematic-ad-creator"
$InstallDir = Join-Path $env:USERPROFILE ".claude\skills\$SkillName"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceDir = Join-Path $ScriptDir $SkillName

# ---------------------------------------------------------------------------
# COLORS
# ---------------------------------------------------------------------------

function Write-Success { param($Msg) Write-Host "  OK    $Msg" -ForegroundColor Green }
function Write-Warn    { param($Msg) Write-Host "  WARN  $Msg" -ForegroundColor Yellow }
function Write-Err     { param($Msg) Write-Host "  ERR   $Msg" -ForegroundColor Red }
function Write-Info    { param($Msg) Write-Host "  -->   $Msg" -ForegroundColor Cyan }

# ---------------------------------------------------------------------------
# HELP
# ---------------------------------------------------------------------------

if ($Help) {
    Write-Host ""
    Write-Host "VO3 Cinematic Ad Creator - Install Script v$ScriptVersion"
    Write-Host ""
    Write-Host "USAGE:"
    Write-Host "  .\install.ps1 [-Force] [-Help]"
    Write-Host ""
    Write-Host "OPTIONS:"
    Write-Host "  -Force   Overwrite existing installation"
    Write-Host "  -Help    Show this help"
    Write-Host ""
    Write-Host "INSTALLS TO:"
    Write-Host "  $InstallDir"
    Write-Host ""
    exit 0
}

# ---------------------------------------------------------------------------
# HEADER
# ---------------------------------------------------------------------------

Write-Host ""
Write-Host "VO3 Cinematic Ad Creator - Installer v$ScriptVersion" -ForegroundColor White -BackgroundColor DarkBlue
Write-Host "Google Veo 3 video ad production for non-videographers."
Write-Host ""

# ---------------------------------------------------------------------------
# PREREQUISITE CHECKS
# ---------------------------------------------------------------------------

Write-Host "Checking prerequisites..." -ForegroundColor White
Write-Host ""

$AllOk = $true

# Claude Code
$ClaudePath = Get-Command claude -ErrorAction SilentlyContinue
if ($ClaudePath) {
    $ClaudeVer = (claude --version 2>$null | Select-Object -First 1) ?? "version unknown"
    Write-Success "Claude Code installed ($ClaudeVer)"
} else {
    Write-Err "Claude Code is not installed."
    Write-Host "         Download it at: https://claude.ai/download" -ForegroundColor Gray
    $AllOk = $false
}

# Source files
$SkillSource = Join-Path $SourceDir "SKILL.md"
if (Test-Path $SkillSource) {
    Write-Success "Skill source found: $SkillSource"
} else {
    Write-Err "Skill source not found at: $SkillSource"
    Write-Host "         Make sure you are running this script from inside the" -ForegroundColor Gray
    Write-Host "         vo3-cinematic-ad-creator-v$ScriptVersion folder." -ForegroundColor Gray
    $AllOk = $false
}

if (-not $AllOk) {
    Write-Host ""
    Write-Err "Prerequisites not met. Fix the issues above and try again."
    Write-Host ""
    exit 1
}

# ---------------------------------------------------------------------------
# INSTALL
# ---------------------------------------------------------------------------

Write-Host ""
Write-Host "Installing skill..." -ForegroundColor White
Write-Host ""

# Check if already installed
if ((Test-Path $InstallDir) -and (-not $Force)) {
    Write-Warn "Already installed at: $InstallDir"
    Write-Info "Use -Force to overwrite the existing installation."
    Write-Host ""
} else {
    # Create destination directory
    try {
        New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    } catch {
        Write-Err "Could not create directory: $InstallDir"
        Write-Host "         Check that you have write permission to your user folder." -ForegroundColor Gray
        exit 1
    }

    # Copy all .md files from source
    $Copied = 0
    $MdFiles = Get-ChildItem -Path $SourceDir -Filter "*.md" -File

    foreach ($File in $MdFiles) {
        $Dest = Join-Path $InstallDir $File.Name
        try {
            Copy-Item -Path $File.FullName -Destination $Dest -Force
            Write-Success "$($File.Name) -> $Dest"
            $Copied++
        } catch {
            Write-Err "Failed to copy: $($File.Name)"
        }
    }

    if ($Copied -eq 0) {
        Write-Err "No files were copied. Check source directory: $SourceDir"
        exit 1
    }
}

# ---------------------------------------------------------------------------
# VERIFICATION
# ---------------------------------------------------------------------------

Write-Host ""
Write-Host "Verifying installation..." -ForegroundColor White
Write-Host ""

$SkillDest = Join-Path $InstallDir "SKILL.md"
if (Test-Path $SkillDest) {
    $Lines = (Get-Content $SkillDest | Measure-Object -Line).Lines
    Write-Success "SKILL.md installed ($Lines lines)"
} else {
    Write-Err "SKILL.md not found at: $SkillDest"
    Write-Host ""
    Write-Err "Verification failed. Run with -Force to retry."
    exit 1
}

# ---------------------------------------------------------------------------
# COMPLETION
# ---------------------------------------------------------------------------

Write-Host ""
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "  VO3 Cinematic Ad Creator v$ScriptVersion installed!" -ForegroundColor Green
Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "  Installed to:" -ForegroundColor White
Write-Host "  $InstallDir" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Restart Claude Code, then try:" -ForegroundColor White
Write-Host ""
Write-Host "    `"Create a VO3 ad for [your product]`"" -ForegroundColor Cyan
Write-Host "    `"Cinematic video ad`"" -ForegroundColor Cyan
Write-Host "    `"Build a Veo 3 ad for [offer] targeting [audience]`"" -ForegroundColor Cyan
Write-Host ""
Write-Host "  You will need:" -ForegroundColor White
Write-Host "  Google Flow (flow.google.com) or AI Studio (aistudio.google.com)" -ForegroundColor Gray
Write-Host "  DaVinci Resolve or CapCut for post-production" -ForegroundColor Gray
Write-Host ""
