---
name: vo3-cinematic-ad-creator
version: "1.1"
description: "Create professional cinematic video ads using Google Veo 3 (VO3). Transforms product/offer + target audience + emotional tone into production-grade video prompts with cinematic camera work, lighting, audio, and scene direction. Makes non-videographers produce video ads that look like they cost $500K. Triggers on: VO3 ad, cinematic video ad, Veo 3 ad, video commercial, AI video ad, cinematic ad."
---

# VO3 Cinematic Ad Creator

Turn any product, offer, or brand story into a cinematic video ad using Google Veo 3 — the kind that used to cost $500K to produce. This skill gives non-videographers the cinematic vocabulary and prompting framework to create professional-grade video ads from text prompts alone.

**Use this skill when:** You need a video ad that looks cinematic (not "AI-ish"), have a product/offer to promote, and want to create it with Veo 3 / Google Flow.
**Route here from:** Ad creative planning, content strategy, or any "I need a video ad" request.

> **Realistic expectations for first-time users:** Your initial outputs will not look like the examples in professional AI video showcases. Creators like PJ Ace have iterated through dozens (sometimes hundreds) of generations to produce their best work, and they bring years of cinematic directing experience to their prompts. Start simple, master the 7-Layer prompt formula, then increase complexity. Your first ad will look good. Your fifth will look great. The skill gives you the same toolkit the pros use — but skill with the toolkit develops through practice, not just reading.

---

## Why This Skill Exists

**The problem:**
1. Professional video ads cost $4,000–$500,000+ to produce
2. AI video tools exist, but most people get generic, obvious-AI results
3. Non-videographers don't know camera angles, lighting setups, or scene direction
4. Lisa tried Flow and "couldn't get it to do what I want — it just came out weird"
5. The difference between a $500 AI ad and a $500K shoot is the PROMPT, not the tool

**The solution:**
PJ Ace (former $500K pharmaceutical commercial director) proved you can create broadcast-quality video ads for ~$500 in Veo 3 credits. His secret: prompting with the same cinematic precision he used to direct live shoots. This skill packages that methodology so anyone can use it.

**What changed:** Veo 3/3.1 generates video WITH synchronized audio — dialogue, sound effects, ambient noise. This means complete commercial-quality ads from a single text prompt. No separate audio production needed.

---

## The PJ Ace Method (How $500 Beats $500K)

### The 5-Stage Workflow

```
STAGE 1: CONCEPT    → Use AI to develop your ad concept and script
STAGE 2: SHOT LIST  → Break script into individual scene prompts (5 at a time via Gemini)
STAGE 3: IMAGE-FIRST → Generate still images, iterate until perfect, THEN animate (optional but recommended)
STAGE 4: GENERATE   → Run prompts through Veo 3 (Fast mode $0.20 / Quality mode ~$3)
STAGE 5: SELECT     → Pick winners (expect 3:1-5:1 careful, 20:1+ fast production)
STAGE 6: ASSEMBLE   → Edit clips + bass boost audio + film grain + music in post
```

### Key Principles

1. **Each prompt is self-contained** — Veo 3 has NO memory between clips. Every prompt must fully describe the scene, character, setting, and tone as if it's the only instruction the model will ever see.

2. **Prompt like a director, not a writer** — Don't describe what happens narratively. Describe what the CAMERA SEES: angle, movement, lighting, subject position, action, audio.

3. **Simple beats complex** — PJ: "Veo doesn't need overly complex prompts. Action, character pose, shot type, camera, and dialogue are usually enough." Overloading kills quality.

4. **Generate in batches, select ruthlessly** — Generate ~30 clips to get 10 usable ones. For fast-paced production, PJ generates 300-400 clips to get 15 usable (Kalshi ad). Expect 3:1-5:1 ratio for careful work, up to 20:1+ when moving fast.

5. **Audio is automatic but directible** — Veo 3 generates synchronized audio. You control it through the prompt: specify dialogue, ambient sounds, and mood. Don't describe background music in the prompt (it'll mix too loud).

6. **Entertain first, brand second** — PJ: "ENTERTAIN FIRST. BRANDING SECOND." Comedy and entertainment neutralize audience skepticism about AI content. Lead with delight, not features. Audiences tolerate AI when they're laughing.

7. **Image-first when quality matters** — For premium work, generate static images FIRST (via Freepik, Rev, or Nano Banana), iterate until perfect, THEN animate with Veo 3. This prevents the "janky" look of raw text-to-video. Text-to-video is fine for fast production.

### Ethical Use & Content Integrity (Non-Negotiable)

These are hard rules — not guidelines. Violating them can result in FTC enforcement action, platform bans, and legal liability.

- **NEVER generate fake testimonials with AI-generated people giving fabricated endorsements.** FTC requires that endorsements reflect honest opinions. AI-generated "testimonials" are fabricated endorsements and violate FTC guidelines.
- **NEVER create deepfakes of real people without their explicit written consent.** Using someone's likeness without permission may violate their right of publicity, state deepfake laws, and platform terms of service.
- **NEVER produce deceptive before/after transformations that didn't actually happen.** Before/after visuals must represent real, achievable results — not AI-fabricated outcomes.
- **All AI-generated ad content should be clearly identifiable as such when required by platform policies.** Meta, YouTube, and TikTok all have disclosure requirements for AI-generated content in ads. Check current platform policies before publishing.
- **When in doubt, disclose.** If a reasonable viewer would believe the content shows a real person, real testimonial, or real result — and it doesn't — you need a disclaimer.

---

## The Master Prompt Template

### The 7-Layer Formula

```
[CAMERA + LENS]: [SUBJECT] [ACTION & PHYSICS],
in [SETTING + ATMOSPHERE], lit by [LIGHT SOURCE].
Style: [TEXTURE/FINISH]. Audio: [DIALOGUE/SFX/AMBIENCE].
```

### Layer Breakdown

| Layer | What It Controls | Example |
|-------|-----------------|---------|
| **Camera + Lens** | How we see the scene | "Slow dolly-in, 35mm lens, eye level" |
| **Subject** | Who/what is in frame + inner state | "A confident woman in her 40s, navy blazer, her expression reflecting quiet determination" |
| **Action & Physics** | What happens | "Sets down coffee cup, looks directly at camera" |
| **Setting + Atmosphere** | Where we are + atmospheric elements | "Modern corner office, city skyline through floor-to-ceiling windows, slight haze from morning light" |
| **Light Source** | How the scene is lit + shadow detail | "Soft daylight from side window casting gentle shadows across her jawline, natural falloff" |
| **Style/Texture** | Color palette + psychological effect | "Cinematic, warm amber and navy color grade reinforcing authority, shallow depth of field" |
| **Audio** | What we hear | "She says: 'The market doesn't wait. Neither do we.' Soft office ambience, distant city traffic" |

### PJ Ace's Extended Prompt Template

For maximum quality, extend the 7-Layer formula with these additional elements:

```
A [MOOD] [CAMERA SHOT TYPE] opens on [CHARACTER: age, look, outfit, emotion],
standing in [SETTING: textures, objects, mood].

The camera [CAMERA MOTION] as the character [ACTION]. Their [FACIAL EXPRESSION]
reflects [INNER STATE].

Lighting is [STYLE], casting [SHADOW DETAIL]. Environment has [ATMOSPHERIC CONDITIONS].

Color palette features [3–5 COLORS], reinforcing [PSYCHOLOGICAL EFFECT].

Background includes [RELEVANT OBJECTS], creating immersive context.

The camera [ADJUSTMENT] as the character delivers: "[DIALOGUE: max 10 words]"

Sound design includes [AUDIO CUES].

Negative: no text overlays, no subtitles.
```

**Style variables:** epic, dramatic, gritty, dreamlike, cinematic tone
**Atmospheric elements:** fog, smoke, rain, haze, dust particles, steam
**Textures:** rain-slick brick, rusted steel, velvet drapes, cracked stone

### Audio Formatting Rules

**CRITICAL — These rules prevent the most common failures:**

| Rule | Why | Example |
|------|-----|---------|
| Use colon format for dialogue | Prevents unwanted subtitles | `She says: 'Your line here.'` |
| Add `(no subtitles)` | Double-protection against text overlays | `(no subtitles)` at end |
| Keep dialogue under 8 seconds | One natural breath = one clip | ~15-20 words max |
| DON'T describe background music | Veo mixes it too loud | Omit music; add in post |
| DO specify ambient sounds | Grounds the scene in reality | "Soft cafe noise, espresso machine hissing" |
| Specify accents explicitly | Improves voice alignment | "speaks with a warm Southern accent" |
| Repeat accent requests multiple times | Single mention often ignored | "speaks with a British accent... his British accent deepens as he says:" |
| Keep dialogue in tight shots only | Wide shots produce garbled speech | Dialogue in medium shots and close-ups; use wide shots for action/atmosphere only |

### Negative Prompting (What to Exclude)

Add at the end of any prompt to block unwanted elements:

```
Negative: no text overlays, no subtitles, no sci-fi elements,
no stock footage look, no oversaturated colors.
```

---

## Camera Direction for Non-Videographers

You don't need to be a cinematographer. Use this translation table.

### "I Want It to Feel Like..." → Camera Direction

| What You Want | Camera Direction to Use | What It Does |
|---------------|------------------------|-------------|
| Intimate, personal | "Close-up, 85mm lens, shallow depth of field" | Blurs background, focuses on face |
| Grand, impressive | "Wide establishing shot, 16mm lens, slow drone push-in" | Shows scale, creates awe |
| Professional, corporate | "Medium shot, 35mm lens, camera locked at eye level" | Natural perspective, business feel |
| Energetic, exciting | "Handheld tracking shot, fast push-in" | Movement creates energy |
| Mysterious, dramatic | "Low angle, slow dolly-in, dramatic shadows" | Subject looks powerful |
| Casual, authentic (UGC) | "Selfie-style, arm's length, slight handheld shake" | Looks like real phone footage |
| Reveal/surprise | "Wide shot slowly dollying toward subject, then camera pushes through" | Builds anticipation |
| Trustworthy, relatable | "Eye-level medium close-up, camera locked" | Direct connection |

### Camera Movements (Plain English)

| Movement | What It Means | When to Use |
|----------|---------------|-------------|
| **Push-in / Dolly-in** | Camera moves toward the subject | Reveals, building emotion, focus |
| **Pull-out / Dolly-out** | Camera moves away | Context reveals, endings |
| **Orbit** | Camera circles the subject | Product showcase, 360 view |
| **Pan** | Camera turns left/right (stays in place) | Scanning a room, following action |
| **Tilt** | Camera looks up/down (stays in place) | Revealing height, looking up at someone |
| **Tracking** | Camera follows a moving subject | Walking scenes, lifestyle |
| **Crane** | Camera rises or descends | Grand reveals, overhead establishing |
| **Dutch angle** | Camera tilted on its side | Tension, disorientation, unease |
| **Locked / Static** | Camera doesn't move | Stability, confidence, authority |
| **Handheld** | Slight natural shake | Authenticity, documentary feel |

### Camera Position Hack

**Breakthrough technique:** Add `(that's where the camera is)` after describing camera position to force Veo to place the camera exactly where you want.

```
"Camera positioned behind the glass door looking into the office
(that's where the camera is), medium shot of the CEO at her desk..."
```

### Lens Selection (The Quick Version)

| Lens | Effect | Best For |
|------|--------|----------|
| **16mm** | Wide, expansive, slightly distorted edges | Establishing shots, showing environments |
| **35mm** | Natural perspective, what the eye sees | General scenes, dialogue, walking |
| **50mm** | Slight compression, flattering for faces | Interviews, talking head, mid-shots |
| **85mm** | Background blur, intimate, portrait-like | Close-ups, emotional moments, products |

---

## Lighting Direction for Non-Videographers

### The Rule: Always Name a Physical Light Source

**Why:** Giving Veo a real light source (window, lamp, neon sign, sunset) produces stable, realistic lighting. Abstract terms like "dramatic lighting" create inconsistent results.

| Mood You Want | Light Direction to Use |
|---------------|----------------------|
| Professional, clean | "Soft daylight from a large side window, gentle fill on opposite side" |
| Warm, inviting | "Golden hour sunlight streaming through window, warm 3200K practical lamps" |
| Dramatic, moody | "Single key light from above-left, deep shadows on opposite side, slight haze" |
| Premium, luxury | "Studio rim lighting from behind, subtle fill from front, dark background" |
| Casual, authentic | "Natural overhead lighting, mixed with window daylight" |
| Mysterious | "Single neon sign casting colored light, dark surroundings, lens flare" |
| Corporate, trustworthy | "Balanced office lighting, soft diffused overhead, monitor glow as accent" |
| Cinematic, filmic | "Motivated light from doorway, natural falloff across face, slight fog/haze" |

### Pro Tip: "Natural Falloff"
Adding "natural falloff across the face" or "natural light falloff" prevents flat, even lighting and creates dimension. This single phrase makes the biggest visual difference.

---

## Scene Templates for Ads

### Template 1: Problem → Solution (The Workhorse)

The most effective ad structure. Show the pain, then the transformation.

> **Integrity note:** Before/after visuals must represent real, achievable results. Do not use AI to fabricate transformations that haven't actually occurred. If the transformation shown is illustrative rather than based on a real outcome, add a "Dramatization" or "Results not typical" disclaimer in post-production.

**Scene A — The Problem (4 seconds):**
```
Close-up, 50mm lens, of a [demographic] sitting at [location],
[frustrated action — rubbing temples, staring at screen, sighing].
Cluttered desk, dim overhead lighting casting unflattering shadows.
[Character] says: '[Pain statement — one sentence].' (no subtitles)
Ambient sound of [environment-appropriate noise].
Negative: no text overlays, no subtitles.
```

**Scene B — The Transformation (4 seconds):**
```
Same [demographic], now in [better setting — bright, clean, organized].
Soft daylight from side window, warm color grade. Medium shot, 35mm lens,
slight push-in. [Character] smiles confidently and says:
'[Solution statement — one sentence].' (no subtitles)
Subtle uplifting ambient tone.
Negative: no text overlays, no subtitles.
```

**Example — Financial Coaching Ad:**
```
Scene A: Close-up, 50mm lens, of a man in his 50s at a kitchen table
late at night, papers and calculator spread out, rubbing his forehead
under harsh overhead light. He says: 'Another month, another plan
that didn't work.' (no subtitles) Quiet house at night, clock ticking.
Negative: no text overlays, no subtitles.

Scene B: Same man, now relaxed in a bright modern office, sitting
across from an advisor. Soft daylight from large window, warm color
grade. Medium shot, 35mm, gentle push-in. He smiles and says:
'Now I actually know where I stand.' (no subtitles)
Subtle warm ambient tone.
Negative: no text overlays, no subtitles.
```

---

### Template 2: The Aspirational Lifestyle (The Cabo Method)

Show the life your product/service makes possible. This is what Ashley used for "Launch This Week in Cabo."

**The Formula:**
```
[Cinematic wide shot / drone shot] of [aspirational setting],
[golden hour / beautiful lighting]. [Subject] in [aspirational wardrobe],
[relaxed luxury action — walking on beach, poolside with laptop,
toasting champagne, stepping off yacht].
Camera: [slow push-in or tracking shot], 35mm lens.
[Subject] looks at camera with relaxed confidence and says:
'[Aspirational statement].' (no subtitles)
Ambient sounds of [setting — ocean waves, pool splashing, etc.].
Cinematic color grade, warm tones, shallow depth of field.
Negative: no text overlays, no subtitles, no stock footage feel.
```

**Example — Business Retreat Offer:**
```
Slow drone push-in over a turquoise infinity pool overlooking the ocean
at golden hour. A woman in her 30s, white linen outfit, sits at a
poolside table with a laptop, sipping champagne. She looks up at
camera with relaxed confidence and says: 'I built my entire funnel
in three days. From a pool in Cabo.' (no subtitles)
Gentle ocean waves, distant resort ambiance, tropical birds.
Cinematic, warm color grade, luxury commercial aesthetic.
Negative: no text overlays, no subtitles.
```

---

### Template 3: Authority / Expert (The Founder Ad)

Founder or expert speaks directly to camera. Builds trust and credibility.

**The Formula:**
```
[Medium close-up], [50mm or 85mm lens], [eye level, camera locked].
[Expert description — age, attire, demeanor] in [credibility setting —
office with books, studio, modern workspace].
[Soft professional lighting — daylight from side window, gentle fill].
[Expert] looks directly at camera and says: '[Authority statement —
one clear insight or challenge to conventional thinking].' (no subtitles)
[Ambient office/studio sounds].
Cinematic, professional, shallow depth of field.
Negative: no text overlays, no subtitles.
```

**Example — Consulting Offer:**
```
Medium close-up, 85mm lens, eye level, camera locked.
A distinguished man in his 50s, charcoal sweater over collared shirt,
silver-framed glasses, in a study with bookshelves behind him.
Soft daylight from a side window with natural falloff across his face.
He looks directly at camera with calm authority and says:
'You don't have a marketing problem. You have a positioning problem.
And no amount of ad spend will fix it.' (no subtitles)
Quiet study ambiance, subtle room tone.
Cinematic, warm, shallow depth of field.
Negative: no text overlays, no subtitles.
```

---

### Template 4: UGC / Testimonial Style (Authenticity That Converts)

Designed to look like a real person filmed this on their phone. The highest-converting format for social ads.

> **WARNING: This template creates AI-generated video that looks like real person content.** Use ONLY for: (1) concept mockups to show real testimonial subjects what you're looking for, (2) stylistic references for your video editor, (3) clearly labeled AI demonstrations. **NEVER publish AI-generated testimonials as if they are real customer endorsements.** The FTC considers fabricated testimonials a deceptive practice regardless of how they were created. If you run AI-generated testimonial-style ads, you must disclose that the person and endorsement are AI-generated, or replace the AI character with a real customer giving a real testimonial (via face swap with consent + their actual words).

**The Formula:**
```
Selfie-style video, arm's length, slight natural handheld movement.
[Relatable person — age, casual attire] in [casual setting — kitchen,
living room, car, walking outside]. Natural lighting — [window light
or outdoor daylight]. [Person] looks directly at camera with
[genuine expression — excited, relieved, amazed] and says:
'[Testimonial — conversational, uses "I" and "you"].' (no subtitles)
Natural ambient sounds of [setting].
Authentic, raw, UGC aesthetic — NOT polished or produced.
Negative: no text overlays, no subtitles, no studio lighting,
no cinematic effects.
```

**Example — Course Testimonial:**
```
Selfie-style video, arm's length, slight handheld shake.
A woman in her 30s, messy bun, cozy sweater, sitting on her couch
in a bright living room. Natural window light from the side.
She looks at camera with genuine excitement and says:
'Okay so I was really skeptical, but I made my first sale in
literally four days. Four days.' (no subtitles)
Quiet apartment sounds, distant traffic.
Authentic UGC aesthetic, slightly imperfect framing.
Negative: no text overlays, no subtitles, no studio look.
```

---

### Template 5: Product Showcase (Premium Commercial)

A cinematic product reveal — premium feel, brand-building quality.

**The Formula:**
```
[Slow cinematic shot type — push-in, orbit, crane], [lens appropriate
to product size]. [Product] on [surface/setting that elevates it],
[dramatic or premium lighting — rim light, spotlight, gradual reveal].
Camera reveals [product detail — texture, material, unique feature].
Style: premium commercial, [color grade], shallow depth of field.
Audio: [subtle sound design — bass swell, ambient tone, material sound].
No dialogue. Cinematic product reveal.
Negative: no text overlays, no subtitles, no hands unless specified.
```

**Example — Headphone Launch:**
```
Slow push-in, 85mm lens, toward matte black wireless headphones
on a dark marble surface. Single spotlight from above gradually
brightens, rim lighting catches brushed aluminum accents.
Camera reveals ear cup texture and premium stitching.
Style: luxury tech commercial, cool blue-black color grade,
shallow depth of field, atmospheric particles in light beam.
Audio: deep cinematic bass swell, subtle electronic undertone.
Negative: no text overlays, no subtitles, no hands.
```

---

### Template 6: The Pharmaceutical / Parody Commercial

PJ Ace's format. Professional commercial aesthetic with potential for humor or satire. Works for legitimate products too.

**The Formula:**
```
[Professional commercial camera work — medium shot, 35mm, slight
push-in]. [Relatable protagonist] in [everyday setting — park, kitchen,
backyard, office]. [Warm, soft lighting — golden hour or soft daylight].
[Protagonist] engages in [activity that shows the product benefit]
while [voiceover or direct-to-camera delivery] says:
'[Product benefit statement — clear, specific, slightly formal].'
(no subtitles)
[Setting-appropriate ambient sounds — birds, children laughing, etc.].
Commercial broadcast quality, warm color grade.
Negative: no text overlays, no subtitles.
```

---

## Character Consistency Across Clips

### The Challenge
Veo 3 has no memory between generations. Your "confident woman CEO" in clip 1 will look completely different in clip 2 unless you manage consistency.

### The Solution: Subject Locking Checklist

For EVERY prompt in a multi-clip ad, include these IDENTICAL descriptors:

```
CHARACTER LOCK — Copy/paste into every prompt:
- Name/role: "The founder, Sarah"
- Age: "early 40s"
- Build: "athletic, medium height"
- Hair: "shoulder-length dark brown hair, side part"
- Skin: "warm olive complexion"
- Attire: "navy blazer over white silk blouse, small gold earrings"
- Demeanor: "confident, composed, slight smile"
```

### Character Sheet Creation (The 2-Shot Method)

**Do NOT use 3x3 grids** — they lose facial detail. Instead:

1. **Generate your character on an off-white background** with soft lighting FIRST (before any scene work)
2. **Create two high-resolution shots:** one close-up and one wide, stitched together side-by-side
3. **Use this character sheet as your reference** for all subsequent generations
4. **Generate plate shots first** (empty scenes/settings), then add the character for consistency

### The 4-Image Stack Method (Superior Consistency)

For maximum character consistency across angles (credit: @henrydaubrez). This is an image generation technique — you do it in Freepik, Midjourney, or Imagen BEFORE animating with Veo 3.

**What it is:** A single 9:16 image containing four landscape sub-frames of the same character — different angles, expressions, or poses — arranged in a 2×2 grid or vertical strip. Because it's one generation, the model understands the character's facial geometry consistently across all four sub-images.

**How to create it:**

1. **Open your image generator** (Freepik recommended — supports character references)
2. **Set canvas to 9:16 portrait format**
3. **Prompt for a 2×2 grid** — e.g.: *"2x2 grid of four frames showing [character description]: top-left: front-facing close-up; top-right: 3/4 angle; bottom-left: side profile; bottom-right: wide shot. Soft lighting, off-white background."*
4. **Generate** — the model produces one image with four consistent views of your character
5. **Save this as your character reference sheet**
6. **Upload to Freepik/Veo 3** as a reference image when generating video clips

**Why it works:** Single-generation consistency — all four views share the same underlying facial structure. Retains facial details significantly better than separate generations or 3x3 grid approaches.

### Clip Chaining Method (For Multi-Scene Ads)

For maximum consistency across clips:

1. **Generate a reference image** of your character using an image tool
2. **Use that image as a visual anchor** when generating Clip 1
3. **Use the final frame of Clip 1** as the starting frame for Clip 2
4. **Maintain identical character descriptions** across all prompts
5. **Stitch clips together** in your editor

### Face Swap Alternative (The Freepik Method)

> **Consent requirement:** Face swap requires written consent from the person whose likeness is being used. Using someone's face without consent may violate their right of publicity and platform terms of service. Many states have specific deepfake laws with civil and criminal penalties. Always get explicit permission before using anyone's likeness in AI-generated content.

Ashley's workflow for putting a real person's face/body into AI scenes:

1. **Generate the cinematic scene** with a generic character using Veo 3
2. **Use Freepik** (freepik.com) or a face swap tool to replace the generic face with the real founder/spokesperson
3. **Result:** Cinematic AI scene + real person's identity

**Best face swap tools (2026):**
- **Freepik** — Ashley's primary tool. Has AI image + video capabilities
- **Magic Hour** — Best-in-class realism, generous free tier
- **Runway** — Strong cinematic control
- **Pica AI** — Good for quick swaps

**Face swap tips:**
- Source video should have face visible 70%+ of the time
- Forward-facing shots work better than profiles
- Avoid videos with heavy face turning/movement
- Higher resolution source = better swap quality

---

## Multi-Clip Assembly: Think in Shots, Not Films

### The Rule
Veo 3 generates 8-second clips. Your ad is built from MULTIPLE clips edited together — just like a real commercial.

### Reference Photography (Critical for Quality)

PJ Ace: Real photos are "CRITICAL in getting near-perfect details."

- **Gather reference photos** of real locations, outfits, lighting setups, and props BEFORE writing prompts
- **Cross-reference photos in Figma** while writing your shot descriptions
- **Upload reference images** to your generation platform when using image-to-video mode
- **Create style reference collages** from your project showing varied lighting, time of day, and aesthetic choices to maintain visual cohesion

The difference between "good enough" and "broadcast quality" is almost always reference material.

### Shot List Planning

Before generating anything, plan your shots:

```
AD: [Product/Offer Name] — [Duration]s total
Platform: [Meta/YouTube/TikTok]
Aspect: [16:9 / 9:16 / 1:1]

SHOT 1 (0-3s): THE HOOK
- Purpose: Stop the scroll
- Shot type: [close-up / wide / POV]
- What happens: [action that creates curiosity]
- Dialogue: "[hook line — 5-7 words max]"

SHOT 2 (3-6s): THE PROBLEM / CONTEXT
- Purpose: Establish relatability
- Shot type: [medium / close-up]
- What happens: [show the pain or situation]
- Dialogue: "[pain statement]"

SHOT 3 (6-10s): THE SHIFT
- Purpose: Introduce the solution
- Shot type: [contrasting shot to previous]
- What happens: [transformation moment]
- Dialogue: "[solution statement]"

SHOT 4 (10-15s): THE PROOF / PAYOFF
- Purpose: Show the result
- Shot type: [aspirational / product reveal]
- What happens: [evidence of transformation]
- Dialogue: "[closing statement or CTA]"
```

### Visual Storyboarding (Optional but Powerful)

For multi-shot ads, organize your shot list visually:

- **Figma** — PJ's primary tool. Great for multi-person collaboration ($20/user/month). Lay out character refs, location references, shot descriptions, and multiple options per scene side by side.
- **Milanote** — Visual board with drag-and-drop. Good for solo work.
- **Miro** — Whiteboard format. Good for teams.

**Pro tips:**
- Use **colored borders** to mark "selects" (green = approved, red = rejected)
- Export Veo 3 clips as **GIFs** to communicate creative vision to clients/stakeholders before final production
- Include character reference sheets, location references, and shot numbers in your board

### The "Cut To" Function (Multi-Shot in One Generation)

Veo 3 supports built-in scene transitions within a single generation, reducing the need for multiple separate clips:

```
"[Character] says: 'I've been waiting for this.'
Cut to close-up shot of [same character] responding with a grin.
[Character] says: 'Let's go.'"
```

**When to use:** Two-shot conversations, reaction sequences, before/after reveals. This maintains character consistency between shots (since it's one generation) and reduces cost. Works best for simple A→B transitions; complex multi-scene sequences still need individual clips.

### Multi-Platform Shooting Strategy

Running the same ad on Meta (9:16) AND YouTube (16:9)? You have two options:

**Option A — Shoot once, crop twice (fastest):**
Generate all clips in **16:9** (landscape). In post-production, crop to 9:16 for Meta by centering the subject. This works if your subject is centered frame — check that nothing critical gets cut from the sides.

**Option B — Generate twice per clip (highest quality):**
For each scene, write two versions of the prompt: one with `16:9 horizontal framing, wide` and one with `9:16 vertical framing, close-up`. Generate both. Use 16:9 for YouTube and 9:16 for Meta. More generations, more cost, better result.

**Pro tip:** When writing prompts for multi-platform ads, keep subjects center-frame and avoid action at the extreme left/right edges. This makes Option A cropping clean.

### Duration Guide

| Platform | Optimal Duration | Clips Needed | Budget |
|----------|-----------------|--------------|--------|
| Meta Feed (15s) | 15 seconds | 2-3 clips | ~$10-20 |
| Meta Reels (30s) | 15-30 seconds | 2-4 clips | ~$10-30 |
| YouTube Pre-Roll (15s) | 6-15 seconds | 1-2 clips | ~$5-15 |
| YouTube Shorts (60s) | 15-30 seconds | 2-4 clips | ~$10-30 |
| TikTok (30s) | 15-30 seconds | 2-4 clips | ~$10-30 |
| Full Commercial (30s) | 30 seconds | 4-6 clips | ~$20-50 |

### Cost Math

**Two pricing tiers:**
- **Fast mode: ~$0.20 per generation** — Use for most shots (action, atmosphere, wide shots)
- **Quality mode: ~$3 per generation** — Reserve for dialogue scenes in tight shots

**Generation ratios (be honest with yourself):**
- **Careful work:** 3:1 to 5:1 ratio (generate 3-5 to get 1 good clip)
- **Fast production:** 20:1+ ratio (PJ generated 300-400 clips for 15 usable on the Kalshi ad)

**Realistic budgets:**

| Scenario | Fast Mode (mostly) | Quality Mode (all dialogue) | Mixed (recommended) |
|----------|-------------------|---------------------------|-------------------|
| 15s Meta ad (3 clips) | ~$2-6 | ~$20-45 | ~$8-20 |
| 30s commercial (6 clips) | ~$4-12 | ~$40-90 | ~$15-40 |
| 60s commercial (8 clips) | ~$6-16 | ~$60-120 | ~$20-60 |
| High-volume production (300+ gens) | ~$60-80 | ~$900-1200 | ~$100-300 |

**Monthly subscription:** Veo 3 Ultra = $250/month (US only). Google Flow offers unlimited generations.

---

## Before You Start (Prerequisites)

Confirm you have the following before beginning the workflow:

| Requirement | Status | Notes |
|-------------|--------|-------|
| **Veo 3 access** | REQUIRED | Google Flow (flow.google.com) or Google AI Studio (aistudio.google.com). Veo 3 Ultra requires Google One AI Premium ($250/month, US availability). Google Flow offers unlimited generations. Fal.ai and Replicate provide API access. |
| **Video editing software** | REQUIRED | You need an editor for post-production. Free options: **DaVinci Resolve** (professional-grade, best audio tools) or **CapCut** (beginner-friendly, good for social ads). Paid: Final Cut Pro, Premiere Pro. You cannot skip this step — raw Veo 3 clips need assembly, audio work, and branding. |
| **Image generation tool** | RECOMMENDED | Freepik, Midjourney, Flux, or equivalent. Used for the image-first workflow (generate still frames, iterate, then animate). Not required for text-to-video, but significantly improves quality for premium work. |
| **Audio tools** | OPTIONAL | Veo 3 generates native audio including dialogue. For more control over voiceover: ElevenLabs ($5-22/month). For audio cleanup: Audacity (free). DaVinci Resolve's Fairlight tab handles most audio post-production needs. |

**Budget expectation:** Expect to generate 3-5x more clips than your final edit needs. A 15-second ad typically costs $8-20 in mixed-mode generation credits. See the Cost Math section for detailed breakdowns.

**Time expectation:** A complete cinematic ad typically takes 2-4 hours from concept to final edit. This includes concept development, prompt writing, generation (with iteration), clip selection, and post-production. Your first ad will take longer as you learn the prompt formula.

---

## Execution Workflow

### Step 1: Gather Your Inputs

```
Required:
□ Product/offer name and description
□ Target audience (who is this ad for?)
□ Emotional tone (aspirational? urgent? authentic? premium?)
□ Platform (Meta, YouTube, TikTok)
□ Duration (15s, 30s, 60s)
□ Key message / CTA

Recommended:
□ ZenithPro outputs (avatar, desires, core concept, ad angles)
□ Copy Arsenal output (headlines, hooks, ad copy)
□ Pains & Hopes Gap Analyzer results (untapped angles)
□ Ad Prediction Machine results (top-scored angles)
```

### Step 2: Develop the Concept

Use AI (Claude, ChatGPT) to develop the ad concept:

```
I need a [duration]-second video ad for [platform].

PRODUCT: [name and what it does]
AUDIENCE: [who they are, what they care about]
TONE: [aspirational / urgent / authentic / premium / humorous]
KEY MESSAGE: [the one thing they should remember]
CTA: [what you want them to do]

Give me 3 different ad concepts, each with:
1. A hook (first 3 seconds — what stops the scroll)
2. The story/arc (middle — what builds the emotion)
3. The payoff (end — what drives the action)

Make them genuinely DIFFERENT approaches, not variations
of the same idea.
```

### Step 3: Build the Shot List

For your chosen concept, break it into individual scenes:

```
Take this ad concept and break it into a shot list.
Each shot should be 4-8 seconds (one Veo 3 clip).

For each shot, specify:
- Camera angle and movement
- Subject description (detailed, consistent)
- Action (what physically happens)
- Setting and atmosphere
- Lighting (name a real light source)
- Dialogue (if any — under 8 seconds, one breath)
- Ambient audio

Format each as a self-contained scene description.
The model has NO memory between shots — describe
everything fully each time.
```

### Step 4: Convert to Veo 3 Prompts

Transform each shot into the 7-Layer formula. PJ Ace uses **Gemini** (preferred) for this step — though Claude and ChatGPT work equally well. Gemini is PJ's preference because it lives in the same Google ecosystem as Veo 3 and has been trained on Veo-specific terminology, which means it tends to produce prompts that align more naturally with Veo 3's generation patterns. **If you're already in Claude, stay in Claude.** The 5-prompt rule applies regardless of which LLM you use.

**Critical rule: Request only 5 prompts at a time.** PJ: "I always tell it to return 5 prompts at a time — any more than that and the quality starts to slip." This is PJ's empirical finding from production experience, not a technical model limit.

```
For each shot in the shot list, write a Veo 3 prompt using
this exact structure:

[Camera + Lens]: [Subject] [Action & physics],
in [Setting + atmosphere], lit by [Light source].
Style: [Texture/finish]. Audio: [Dialogue/SFX/ambience].

Rules:
- Dialogue format: Character says: 'Line here.' (no subtitles)
- Always name a physical light source (window, lamp, sun)
- Add "natural falloff" for realistic lighting
- Keep each prompt self-contained (full character description)
- End with: Negative: no text overlays, no subtitles.
- Do NOT describe background music (add in post)
- ONLY generate 5 prompts per batch (quality drops beyond 5)
```

**Troubleshooting "Failed Generation" errors:** If Veo 3 returns a failed generation, paste the prompt into Gemini and ask it to identify which keywords may have triggered content filters. Modify the flagged language and regenerate.

### Step 5: Generate in Veo 3

**Where to access Veo 3:**
- **Google Flow** (flow.google.com) — Ashley's primary tool
- **Google AI Studio** (aistudio.google.com) — Direct access
- **Fal.ai** (fal.ai/models/fal-ai/veo3) — API access
- **Replicate** — API access for automation

**Generation settings:**
- Resolution: 1080p (default) or 4K
- Aspect ratio: Match your platform (16:9, 9:16, 1:1)
- Duration: 8 seconds per clip
- Generate in 4x mode for multiple variations per prompt

**Fast Mode vs Quality Mode:**
- **Fast mode ($0.20/generation):** Use for most shots. Delivers ~80% quality at ~20% cost. Best for action shots, wide shots, atmospheric clips, and anything without dialogue.
- **Quality mode (~$3/generation):** Reserve for dialogue scenes only. Delivers noticeably better lip sync, cleaner speech clarity, and tighter audio-visual alignment. Worth it when a character is speaking on camera.
- **Rule of thumb:** Use Fast mode by default. Switch to Quality mode only when a character is speaking in a tight shot.
- **⚠️ Do NOT use Fast mode for dialogue.** The specific failures are: degraded lip sync (mouth doesn't match the words), muffled or distorted speech audio, and audio-visual desync (audio continues after lips stop moving). These aren't subtle — they make the clip unusable. Budget pressure doesn't change this.

**Parallel Generation Strategy (The Leapfrog Method):**
1. Open **3 separate Veo 3 windows** simultaneously
2. Submit prompts across all 3 windows (max 5 prompts per batch)
3. While generations are processing, refine subsequent prompts in Gemini/ChatGPT
4. As results come back, review, select winners, and submit the next batch
5. This staggered workflow means you're never waiting idle

**Process:**
1. Submit prompts in parallel across multiple windows
2. Review output as it comes back
3. If character looks wrong → regenerate (adjust description)
4. If camera angle is off → adjust camera direction
5. If audio is wrong → adjust audio section of prompt
6. **Abandon after 10 failed generations** — reformulate the prompt entirely
7. Save all good takes — you'll pick winners in editing

### Step 6: Select & Assemble

**Selection criteria:**
- Does the character look consistent across clips?
- Is the camera movement smooth and intentional?
- Does the lighting match between shots?
- Is the dialogue clear and synced?
- Does it look cinematic (not "AI-generated")?

**Editing tools:**
- **Final Cut Pro** — PJ Ace's choice
- **CapCut** — Free, good for social ads
- **DaVinci Resolve** — Free, professional-grade
- **Descript** — Good for dialogue-heavy ads

**Post-production additions:**
- Background music (add in editor, NOT in Veo prompt) — use Epidemic Sound ($10-20/month) or Storyblocks
- Text overlays / supers (add in editor for control)
- Your logo / branding
- CTA card at the end

**Audio post-production (critical):**
Veo 3's native audio is "thin" — it needs help in post:

**If using DaVinci Resolve (free, recommended for audio):**
- Open **Fairlight** tab → select your dialogue clip
- Add **Compressor** from Effects → set Ratio 3:1, Threshold -18dB, Attack 5ms, Release 50ms
- Add **EQ** → boost 100-200Hz by +3dB for body, cut 300-500Hz slightly to reduce muddiness
- **Film grain:** Color tab → Gallery → apply a film grain LUT, or use OpenFX "Grain" at 10-15%

**If using CapCut (free, beginner-friendly):**
- CapCut does NOT have a native audio compressor. Workaround: use the **Voice Enhance** button on dialogue clips (applies automatic EQ and slight compression)
- For real compression control: export audio from CapCut → run through **Audacity** (free) → Effect → **Dynamics Processing → Compressor** → reimport (note: Audacity 3.2+ moved this from "Effect → Compressor" to this new path)
- **Film grain in CapCut:** Video clip → Effects → Video Effects → search "Film Grain" → add at 30-50% opacity

**All editors:**
- **Upscale from 720p** to 1080p+ via **Topaz Video AI** (Veo outputs at 720p natively)
- **Apply Remini or DaVinci color correction** to reduce the "AI uncanny valley" effect
- Do NOT use Veo 3's built-in music — substitute stock music from Epidemic Sound for superior cohesion

### Step 7: Face Swap (Optional)

If the ad needs a specific person's face:

1. Select the best clip from Step 6
2. Open Freepik (or Magic Hour, Runway)
3. Upload the AI-generated clip as the target video
4. Upload a clear photo of the real person (front-facing, good lighting)
5. Run the face swap
6. Review for quality — check lip sync, expression match
7. If needed, try a different source photo angle

**⚠️ Critical lip sync warning:** Face swapping a clip where a character is SPEAKING will break lip sync. The face swap replaces the face geometry AFTER Veo 3 already generated the lip movements for a different face. The new face's mouth won't match the words.

**Fix:** Use the **ai-talking-head** skill to re-sync dialogue after face swap. It can generate new lip movements matched to the audio for the swapped face. Alternatively: only face swap clips where the character is NOT speaking on camera (action shots, walking, reaction shots). Save speaking shots for Veo 3's native generation or use ElevenLabs to match the voice to the new character's appearance.

---

## Platform-Specific Optimization

### Meta (Facebook / Instagram)

```
Feed Ads:
- Aspect: 1:1 (square) or 4:5 (portrait) for maximum real estate
- Duration: 15 seconds optimal
- Hook in first 1-2 seconds (must stop the scroll)
- Design for sound-off viewing (the visual must tell the story)
- CTA: Add text overlay in post-production

Reels / Stories:
- Aspect: 9:16 (vertical)
- Duration: 15-30 seconds
- UGC/authentic style outperforms polished
- Native feel — don't over-produce
- Safe zones: keep key content center 60%
```

### YouTube

```
Pre-Roll (Skippable):
- Aspect: 16:9
- Duration: 15-30 seconds
- HOOK IN FIRST 5 SECONDS (skip button appears)
- Brand visible throughout
- Can be more produced/cinematic than Meta

Shorts:
- Aspect: 9:16
- Duration: 15-60 seconds
- Pattern interrupt in first 2 seconds
- Higher energy, faster pacing
```

### TikTok

```
- Aspect: 9:16
- Duration: 15-30 seconds
- MUST feel native — overly polished kills performance
- UGC/selfie style tends to outperform cinematic
- Hook: pattern interrupt or curiosity gap
- Trending audio integration in post-production
```

---

## Echoic Memory: Making Your Ad Unforgettable

Lisa's concept: create a spoken phrase so memorable people hear it in their head days later.

### What Makes Audio Stick

| Technique | Example | Why It Works |
|-----------|---------|-------------|
| **Unexpected contrast** | "I built a company from a hospital bed" | Breaks expectations |
| **Specific number** | "Four days. That's all it took" | Precision = credibility |
| **Rhetorical question** | "What if the problem isn't your marketing?" | Creates open loop |
| **Repetition** | "Not harder. Not smarter. Different." | Pattern creates memory |
| **Confession** | "I was wrong about everything" | Vulnerability = attention |
| **Short declarative** | "The market doesn't wait. Neither do we." | Rhythm = memorability |

### Echoic Memory Prompt Addition

Add to any template's dialogue section:
```
[Character] says: '[Memorable phrase — short, rhythmic, unexpected].'
Voice tone: [measured and deliberate / warm and conspiratorial /
calm authority]. Slight pause before the key word.
```

---

## Quality Checklist

### Cinematic Quality (What Makes It Look Professional)

- [ ] Named physical light source (not just "dramatic lighting")
- [ ] Natural light falloff visible on faces/subjects
- [ ] Shallow depth of field (background blur)
- [ ] Intentional camera movement (not random)
- [ ] Consistent color grade across clips
- [ ] No obvious AI artifacts (morphing, warping, extra fingers)
- [ ] Looks like a human directed it — every shot has PURPOSE

### Audio Quality

- [ ] Dialogue is clear and synced to lip movement
- [ ] Ambient sounds match the environment
- [ ] No unwanted background music (added in post)
- [ ] No subtitle text appearing on screen
- [ ] Natural speech rhythm (not robotic)

### Ad Effectiveness

- [ ] Hook in first 1-3 seconds (would YOU stop scrolling?)
- [ ] Clear single message (one idea per ad)
- [ ] Emotional arc (problem → solution, or curiosity → payoff)
- [ ] CTA is obvious (added in post-production)
- [ ] Platform-appropriate format and energy

### Character Consistency (Multi-Clip)

- [ ] Same person recognizable across all clips
- [ ] Wardrobe matches between scenes
- [ ] Lighting feels like same time of day
- [ ] Emotional progression makes sense
- [ ] No jarring appearance changes between cuts

---

## Common Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| Looks "AI-ish" / generic | Vague prompt, no cinematic direction | Add specific lens, named light source, "natural falloff" |
| Subtitles appearing | Wrong dialogue format | Use `says:` format + add `(no subtitles)` |
| Background music too loud | Described music in prompt | Remove all music description; add music in post |
| Character looks different each clip | No consistent description | Copy/paste identical character lock in every prompt |
| Dialogue sounds weird/robotic | Dialogue too long or unnatural | Keep under 8 seconds, write like speech not writing |
| Camera doesn't go where I want | Vague camera direction | Use `(that's where the camera is)` hack |
| Scene looks flat | No depth in lighting | Add "shallow depth of field" + side lighting + "natural falloff" |
| Wrong aspect ratio | Didn't specify in generation | Set aspect ratio BEFORE generating, not after |
| Face morphs during clip | Long or complex action | Keep action simple, one movement per clip |
| Audio hallucinations (random sounds) | Didn't specify ambient audio | Always describe expected background sounds explicitly |
| Audio sounds thin/weak | Veo 3's native audio lacks body | Apply bass boost + compression in post-production |
| "Failed Generation" error | Content filter triggered | Paste prompt into Gemini, ask it to identify flagged keywords, modify |
| Accent keeps changing | Single mention insufficient | Repeat accent specification 2-3 times throughout the prompt |
| Dialogue garbled in wide shot | Wide shots produce poor speech | Move dialogue to medium shots and close-ups only |
| Shot won't work after 10+ tries | Prompt is fundamentally flawed | Stop regenerating — rewrite the prompt from scratch |
| Video looks "AI-ish" / too clean | Raw text-to-video limitations | Use image-first workflow: generate still → iterate → animate |

---

## Iteration Strategy

### When the Clip Is Close But Not Right

**Targeted adjustments:**
```
Too dark → Change light source: "bright daylight" or add "well-lit"
Too bright → "Single key light, deep shadows" or "low-key lighting"
Wrong mood → Adjust lighting + color grade description
Camera too fast → Add "slow" before any movement
Camera too static → Add "gentle push-in" or "slight drift"
Person looks wrong → More specific physical description
Audio off → More specific ambient + dialogue direction
```

### When the Clip Is Completely Wrong

Don't iterate on a broken foundation:
1. Simplify the prompt dramatically (strip to core elements)
2. Try a different camera angle / setup entirely
3. Change the setting
4. Start from a different template

### The 3-Take Rule
If a prompt doesn't produce a usable clip after 3 regenerations, the prompt is the problem. Rewrite it, don't just regenerate.

---

## Integration with Your ZenithPro Skills

| Existing Skill | How It Feeds This Skill |
|----------------|------------------------|
| **Pains & Hopes Gap Analyzer** | Provides untapped ad angles → become Scene A "problem" statements |
| **Ad Prediction Machine** | Scores angles → pick the highest-scoring for your ad concept |
| **Creative Generator (L7)** | Headlines + hooks → become dialogue/opening lines |
| **Copy Arsenal** | Full ad copy → extract key lines for dialogue |
| **Content Engine** | Pillar content → repurpose key points as ad scripts |
| **Dara Denney Hook Taxonomy** | Hook structures → become Shot 1 of your ad |
| **Founder Ad Formula** | Founder ad scripts → feed directly into Template 3 |
| **ai-talking-head** | Lip-sync overlay → add specific speech to any clip |
| **ai-product-photo** | Product reference images → use as visual anchors in Veo |

### Workflow Example

```
1. Run Pains & Hopes Gap Analyzer → Get "The Course Graveyard" angle
2. Run Ad Prediction Machine → Scores it #1
3. Run Dara Denney Hook Taxonomy → Gets 5 hook variations
4. THIS SKILL: Build cinematic ad using Template 1 (Problem→Solution)
   - Hook: "I've spent $30K on courses. My business hasn't changed."
   - Problem scene: Frustrated entrepreneur at desk, late night
   - Solution scene: Same person in strategy session, confident
5. Generate in Veo 3 → Select best clips → Assemble
6. Optional: Face swap founder's face onto the character
7. Add music, CTA text, logo in editor
8. Upload to Meta → Run campaign
```

---

## Output Format

### Concept Presentation
```markdown
## Cinematic Ad Concept: [Name]

**Product/Offer:** [What's being advertised]
**Platform:** [Where it will run]
**Duration:** [Total seconds]
**Tone:** [Emotional approach]
**Target:** [Who sees this ad]

### The Concept
[2-3 sentence description of the ad's story/arc]

### Shot List

**Shot 1 — The Hook (0-3s)**
[Complete Veo 3 prompt using 7-Layer formula]

**Shot 2 — The Problem (3-6s)**
[Complete Veo 3 prompt using 7-Layer formula]

**Shot 3 — The Shift (6-10s)**
[Complete Veo 3 prompt using 7-Layer formula]

**Shot 4 — The Payoff (10-15s)**
[Complete Veo 3 prompt using 7-Layer formula]

### Post-Production Notes
- Music: [mood/genre suggestion for editor]
- Text overlays: [what to add where]
- CTA: [end card details]
- Face swap: [yes/no — whose face]

### Estimated Budget
- Veo 3 credits: ~$[X] ([Y] shots × $3 avg × 3:1 ratio)
- Generation time: ~[X] minutes
- Editing time: ~[X] minutes
```

---

## Quick Reference Card

### The Formula
```
[Camera + Lens]: [Subject] [Action],
in [Setting], lit by [Named Light Source + "natural falloff"].
Style: [Cinematic, color grade, shallow depth of field].
Audio: [Character] says: '[Line].' (no subtitles)
[Ambient sounds]. Negative: no text overlays, no subtitles.
```

### The 5 Commandments
1. **Every prompt is self-contained** — describe everything, every time
2. **Name your light source** — "window light," never just "dramatic"
3. **Use colon format** — `says:` not `says "` for dialogue
4. **Add (no subtitles)** — always, no exceptions
5. **Don't describe music** — add it in post-production

### The Budget
```
Fast mode: ~$0.20/gen | Quality mode: ~$3/gen
1 usable clip (Fast) = ~$1-4
1 usable clip (Quality) = ~$6-15
15-second ad (mixed) = ~$8-20
30-second ad (mixed) = ~$15-40
Full campaign (3 ads) = ~$50-150
High-volume (300+ gens) = ~$100-300
```

### Access Points
```
Google Flow: flow.google.com (Ashley's primary)
AI Studio: aistudio.google.com
Fal.ai: fal.ai/models/fal-ai/veo3
```
