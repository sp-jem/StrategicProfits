# VO3 Cinematic Ad Creator — Install Pack v1.1

Turn any product or offer into a cinematic video ad using Google Veo 3. The same methodology used by PJ Ace (former $500K pharmaceutical commercial director) — packaged so anyone can produce broadcast-quality video ads for ~$500 in credits.

**Author:** Ashley Shaw / Strategic Profits  
**Version:** 1.1  
**Tested:** 13/13 adversarial tests passed (February 2026)  
**Requires:** Claude Code, Google Flow or AI Studio access

---

## What This Pack Contains

| File | Type | Install Location | Role |
|------|------|-----------------|------|
| `vo3-cinematic-ad-creator/SKILL.md` | Skill | `~/.claude/skills/` | Full cinematic ad creation system |

**What the skill gives you:**
- The 7-Layer Prompt Formula (PJ Ace's core method)
- 6 production-ready scene templates (Problem→Solution, Aspirational Lifestyle, Founder Ad, UGC/Testimonial, Product Showcase, Pharma/Parody)
- Camera and lens direction for non-videographers
- Lighting direction with named light sources
- Character consistency system (Subject Locking + 4-Image Stack Method)
- Multi-clip assembly workflow with shot list planning
- Platform-specific optimization (Meta, YouTube, TikTok)
- Cost math and generation ratio guidance
- 20+ common issues + solutions

---

## Prerequisites

1. **Claude Code** installed ([claude.ai/download](https://claude.ai/download))
2. **Google Flow or AI Studio access** — [flow.google.com](https://flow.google.com) (Ashley's primary) or [aistudio.google.com](https://aistudio.google.com)
3. **Video editing software** — DaVinci Resolve (free, recommended) or CapCut (free, beginner-friendly)
4. Optional: Freepik or Midjourney for the image-first workflow

---

## Installation

### Option A — Auto Installer (Mac/Linux)

```bash
bash /path/to/vo3-cinematic-ad-creator-v1.1/install.sh
```

Replace the path with wherever you saved this folder.

### Option B — Auto Installer (Windows)

Open PowerShell and run:

```powershell
.\vo3-cinematic-ad-creator-v1.1\install.ps1
```

> If Windows blocks the script, first run:
> ```
> Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
> ```

### Option C — Manual (any OS)

```bash
cp -r vo3-cinematic-ad-creator ~/.claude/skills/
```

That's it. One folder, one location.

---

## After Installation

Restart Claude Code, then trigger the skill with any of:

- `"Create a video ad for [product]"`
- `"VO3 ad"`
- `"Cinematic video ad"`
- `"Veo 3 ad"`
- `"Video commercial"`
- `"AI video ad"`

Claude will ask for: product/offer, target audience, platform, tone, duration, and key message — then produce a complete shot list with production-ready Veo 3 prompts.

---

## Budget Reality Check

| Ad Length | Generation Mode | Estimated Cost |
|-----------|----------------|---------------|
| 15s Meta ad | Mixed (recommended) | ~$8–20 |
| 30s commercial | Mixed | ~$15–40 |
| 3-ad campaign | Mixed | ~$50–150 |

Fast mode (~$0.20/gen) for action/atmosphere. Quality mode (~$3/gen) for dialogue scenes only.

---

## What's in the Skill

The skill contains the complete PJ Ace methodology:

- **5-Stage Workflow** — Concept → Shot List → Image-First → Generate → Select → Assemble
- **7-Layer Prompt Formula** — Camera, Subject, Action, Setting, Light, Style, Audio
- **Character Consistency System** — Subject Locking Checklist, 4-Image Stack Method, Clip Chaining
- **6 Scene Templates** — Pre-built for the most common ad types
- **Platform Specs** — Meta (9:16, 1:1), YouTube (16:9), TikTok (9:16)
- **Audio Post-Production** — DaVinci Resolve and CapCut workflows
- **Ethical Use Rules** — FTC, deepfake, and platform disclosure requirements

---

## Test Results

This skill passed all 13 adversarial tests before release. See `vo3-cinematic-ad-creator/TEST-RESULTS.md` for the full report.

Test categories covered: missing inputs, contradictory tone, fabrication bait, math edge cases, platform/style mismatch, non-visual products, 8-clip character lock, authority override, rush job pressure, impossible budget, prohibited content, template mismatch, dialogue overflow.

---

## Version History

| Version | Date | Notes |
|---------|------|-------|
| 1.1 | 2026-02-24 | Added 4-Image Stack Method, Leapfrog generation, multi-platform shooting strategy, DaVinci/CapCut audio workflow, image-first guidance, "that's where the camera is" camera hack. 13/13 adversarial tests certified. |
| 1.0 | Initial release | Core 7-Layer formula + 5 templates |
