-- ============================================================
-- Intelligence Engine — Supabase Schema (19 tables)
-- Fully idempotent — safe to run multiple times.
-- Run in: Supabase Dashboard > SQL Editor > New Query > Run
-- ============================================================

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- 1. COMMITMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS commitments (
    id TEXT PRIMARY KEY,                        -- e.g. 'commit_20260309_002'
    person TEXT NOT NULL,                        -- who committed
    description TEXT NOT NULL,
    source TEXT,                                 -- source file path
    source_files TEXT[],                         -- array of source paths
    date_committed DATE,
    status TEXT NOT NULL DEFAULT 'open',         -- open, completed, resolved, dismissed, snoozed, delegated, invalid
    age_days INTEGER DEFAULT 0,
    urgency_level TEXT DEFAULT 'normal',         -- normal, aging, overdue, critical
    relationship TEXT,                           -- rich_owns, owed_to_rich
    completion_signals TEXT[],
    completed_date DATE,
    completed_by TEXT,
    resolved_date DATE,
    resolved_by TEXT,
    resolution_note TEXT,
    snooze_until DATE,
    delegated_to TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_commitments_status ON commitments(status);
CREATE INDEX IF NOT EXISTS idx_commitments_person ON commitments(person);
CREATE INDEX IF NOT EXISTS idx_commitments_relationship ON commitments(relationship);
CREATE INDEX IF NOT EXISTS idx_commitments_urgency ON commitments(urgency_level);

-- ============================================================
-- 2. DECISIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS decisions (
    id TEXT PRIMARY KEY,                        -- e.g. 'decision_20260309_001'
    description TEXT NOT NULL,
    source TEXT,
    decided_date DATE,
    execution_status TEXT DEFAULT 'pending',     -- pending, executed, stale, superseded
    days_since INTEGER DEFAULT 0,
    execution_evidence TEXT[],
    resolved_date DATE,
    resolved_by TEXT,
    superseded_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_decisions_status ON decisions(execution_status);
CREATE INDEX IF NOT EXISTS idx_decisions_date ON decisions(decided_date);

-- ============================================================
-- 3. DIRECTIVES (signals from user to team)
-- ============================================================
CREATE TABLE IF NOT EXISTS directives (
    id TEXT PRIMARY KEY,                        -- e.g. 'dir_20260309_001'
    person TEXT NOT NULL,                        -- who it's directed to
    description TEXT NOT NULL,
    deadline_text TEXT,
    deadline_inferred DATE,
    confidence REAL DEFAULT 0.0,
    source_quote TEXT,
    source_channel TEXT,
    date_issued DATE,
    age_days INTEGER DEFAULT 0,
    status TEXT DEFAULT 'open',                 -- open, aging, completed, dismissed
    urgency_level TEXT DEFAULT 'normal',
    needs_review BOOLEAN DEFAULT FALSE,
    linked_project TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_directives_status ON directives(status);
CREATE INDEX IF NOT EXISTS idx_directives_person ON directives(person);

-- ============================================================
-- 4. REQUESTS INBOUND (requests TO the user)
-- ============================================================
CREATE TABLE IF NOT EXISTS requests_inbound (
    id TEXT PRIMARY KEY,
    person TEXT NOT NULL,                        -- who's requesting
    description TEXT NOT NULL,
    deadline_text TEXT,
    deadline_inferred DATE,
    confidence REAL DEFAULT 0.0,
    source_quote TEXT,
    source_channel TEXT,
    date_received DATE,
    age_days INTEGER DEFAULT 0,
    status TEXT DEFAULT 'open',
    urgency_level TEXT DEFAULT 'normal',
    needs_review BOOLEAN DEFAULT TRUE,
    linked_project TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_requests_status ON requests_inbound(status);

-- ============================================================
-- 5. FOLLOW-UPS
-- ============================================================
CREATE TABLE IF NOT EXISTS follow_ups (
    id TEXT PRIMARY KEY,
    person TEXT NOT NULL,
    description TEXT NOT NULL,
    deadline_text TEXT,
    deadline_inferred DATE,
    confidence REAL DEFAULT 0.0,
    source_quote TEXT,
    source_channel TEXT,
    date_created DATE,
    age_days INTEGER DEFAULT 0,
    status TEXT DEFAULT 'open',
    urgency_level TEXT DEFAULT 'normal',
    needs_review BOOLEAN DEFAULT FALSE,
    linked_project TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_followups_status ON follow_ups(status);

-- ============================================================
-- 6. PATTERNS
-- ============================================================
CREATE TABLE IF NOT EXISTS patterns (
    id TEXT PRIMARY KEY DEFAULT 'pat_' || replace(gen_random_uuid()::text, '-', ''),
    category TEXT NOT NULL,                     -- behavioral, business, team, operational
    description TEXT NOT NULL,
    evidence TEXT[],
    first_observed DATE,
    last_observed DATE,
    occurrences INTEGER DEFAULT 1,
    severity TEXT,                              -- info, warning, critical
    recommendation TEXT,
    status TEXT DEFAULT 'active',               -- active, resolved, monitoring
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_patterns_category ON patterns(category);
CREATE INDEX IF NOT EXISTS idx_patterns_status ON patterns(status);

-- ============================================================
-- 7. PREDICTIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS predictions (
    id TEXT PRIMARY KEY,
    description TEXT NOT NULL,
    timeframe TEXT,
    confidence REAL DEFAULT 0.0,
    basis TEXT,                                  -- reasoning/evidence
    generated_date DATE,
    outcome TEXT,                                -- null until resolved, then 'correct'/'incorrect'/'partial'
    outcome_date DATE,
    outcome_note TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 8. PEOPLE MODEL
-- ============================================================
CREATE TABLE IF NOT EXISTS people_model (
    name TEXT PRIMARY KEY,                      -- e.g. 'Ashley', 'Nicole'
    role TEXT,                                  -- owner, team, external, vendor
    commitment_follow_through_rate REAL DEFAULT 0.0,
    typical_channels TEXT[],
    communication_style JSONB DEFAULT '{}',
    last_updated DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 9. PRIORITIES
-- ============================================================
CREATE TABLE IF NOT EXISTS priorities (
    id SERIAL PRIMARY KEY,
    rank INTEGER NOT NULL,
    name TEXT NOT NULL,
    declared DATE,
    source TEXT,
    type TEXT,                                  -- time_bound_event, strategic, operational
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_priorities_active ON priorities(active);

-- ============================================================
-- 10. PRIORITY CHANGE LOG
-- ============================================================
CREATE TABLE IF NOT EXISTS priority_change_log (
    id SERIAL PRIMARY KEY,
    description TEXT NOT NULL,
    old_priority TEXT,
    new_priority TEXT,
    evidence TEXT,
    detected_date DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_priority_changes_date ON priority_change_log(detected_date);

-- ============================================================
-- 11. ALIGNMENT HISTORY (daily alignment scores)
-- ============================================================
CREATE TABLE IF NOT EXISTS alignment_history (
    id SERIAL PRIMARY KEY,
    date DATE NOT NULL UNIQUE,
    window_days INTEGER DEFAULT 2,
    priority_alignment JSONB NOT NULL,          -- per-priority scores
    drift_score REAL,
    improvements TEXT[],
    deteriorations TEXT[],
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_alignment_date ON alignment_history(date);

-- ============================================================
-- 12. TIME-BOUND EVENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS time_bound_events (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    date DATE NOT NULL,
    days_until INTEGER,
    action_items_pending INTEGER DEFAULT 0,
    status TEXT DEFAULT 'on_track',             -- on_track, at_risk, behind, complete
    key_actions TEXT[],
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 13. DAILY SNAPSHOTS (complex nested — stored as JSONB)
-- ============================================================
CREATE TABLE IF NOT EXISTS daily_snapshots (
    date DATE PRIMARY KEY,
    work_blocks JSONB DEFAULT '[]',
    meetings JSONB DEFAULT '[]',
    communications JSONB DEFAULT '{}',
    revenue JSONB DEFAULT '{}',
    systems JSONB DEFAULT '{}',
    time_allocation JSONB DEFAULT '{}',
    effectiveness_verdict JSONB DEFAULT '{}',
    avoidance_flags JSONB DEFAULT '[]',
    predictions_generated JSONB DEFAULT '[]',
    autonomous_actions_taken JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 14. IMESSAGE DOCUMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS imessage_documents (
    id SERIAL PRIMARY KEY,
    sender TEXT,
    recipient TEXT,
    description TEXT,
    file_path TEXT,
    date_received DATE,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 15. UNFINISHED WORK
-- ============================================================
CREATE TABLE IF NOT EXISTS unfinished_work (
    id SERIAL PRIMARY KEY,
    description TEXT NOT NULL,
    context TEXT,
    source TEXT,
    detected_date DATE,
    status TEXT DEFAULT 'open',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 16. CORRECTIONS LOG (user corrections to brain judgments)
-- ============================================================
CREATE TABLE IF NOT EXISTS corrections_log (
    id SERIAL PRIMARY KEY,
    entity_type TEXT NOT NULL,                  -- commitment, decision, directive, etc.
    entity_id TEXT NOT NULL,
    correction_type TEXT NOT NULL,              -- dismiss, resolve, reassign, reclassify
    old_value JSONB,
    new_value JSONB,
    reason TEXT,
    corrected_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_corrections_entity ON corrections_log(entity_type, entity_id);

-- ============================================================
-- 17. METADATA (system-level state)
-- ============================================================
CREATE TABLE IF NOT EXISTS metadata (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed initial metadata (skip if rows already exist)
INSERT INTO metadata (key, value)
VALUES
    ('schema_version', '"2.0"'),
    ('total_days_accumulated', '0'),
    ('total_observations', '0'),
    ('vectorization', '{"last_seeded": null, "last_incremental": null, "total_vectors": 0}')
ON CONFLICT (key) DO NOTHING;

-- ============================================================
-- 18. PROACT OUTPUT (proactive action engine results)
-- ============================================================
CREATE TABLE IF NOT EXISTS proact_output (
    date DATE PRIMARY KEY,
    autonomous_actions JSONB DEFAULT '[]',
    needs_input_actions JSONB DEFAULT '[]',
    skipped_items JSONB DEFAULT '[]',
    items_analyzed INTEGER DEFAULT 0,
    learning_feedback JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 19. ACTIVITY LOG (audit trail of all brain actions)
-- ============================================================
CREATE TABLE IF NOT EXISTS activity_log (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    source TEXT NOT NULL,                       -- brain_daily, brain_hourly, user, mcp, etc.
    action TEXT NOT NULL,                       -- create, update, dismiss, resolve, snooze, etc.
    entity_type TEXT NOT NULL,                  -- commitment, decision, directive, etc.
    entity_id TEXT,
    description TEXT,
    before_value JSONB,
    after_value JSONB,
    reason TEXT,
    session_id TEXT,
    reversible BOOLEAN DEFAULT TRUE
);

CREATE INDEX IF NOT EXISTS idx_activity_log_timestamp ON activity_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_activity_log_source ON activity_log(source);
CREATE INDEX IF NOT EXISTS idx_activity_log_entity ON activity_log(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_activity_log_session ON activity_log(session_id);

-- ============================================================
-- ROW-LEVEL SECURITY (RLS)
-- Enable RLS and create policies idempotently
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE commitments ENABLE ROW LEVEL SECURITY;
ALTER TABLE decisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE directives ENABLE ROW LEVEL SECURITY;
ALTER TABLE requests_inbound ENABLE ROW LEVEL SECURITY;
ALTER TABLE follow_ups ENABLE ROW LEVEL SECURITY;
ALTER TABLE patterns ENABLE ROW LEVEL SECURITY;
ALTER TABLE predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE people_model ENABLE ROW LEVEL SECURITY;
ALTER TABLE priorities ENABLE ROW LEVEL SECURITY;
ALTER TABLE priority_change_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE alignment_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE time_bound_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE imessage_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE unfinished_work ENABLE ROW LEVEL SECURITY;
ALTER TABLE corrections_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE metadata ENABLE ROW LEVEL SECURITY;
ALTER TABLE proact_output ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;

-- Service role policies (full access for Python scripts / service_role key)
DO $$
DECLARE
    t TEXT;
BEGIN
    FOR t IN SELECT unnest(ARRAY[
        'commitments', 'decisions', 'directives', 'requests_inbound',
        'follow_ups', 'patterns', 'predictions', 'people_model',
        'priorities', 'priority_change_log', 'alignment_history',
        'time_bound_events', 'daily_snapshots', 'imessage_documents',
        'unfinished_work', 'corrections_log', 'metadata',
        'proact_output', 'activity_log'
    ])
    LOOP
        IF NOT EXISTS (
            SELECT 1 FROM pg_policies WHERE tablename = t AND policyname = 'service_role_all'
        ) THEN
            EXECUTE format(
                'CREATE POLICY service_role_all ON %I FOR ALL USING (auth.role() = ''service_role'')',
                t
            );
        END IF;
    END LOOP;
END $$;

-- Anon read policies (for dashboard queries if needed)
DO $$
DECLARE
    t TEXT;
BEGIN
    FOR t IN SELECT unnest(ARRAY[
        'commitments', 'decisions', 'directives', 'requests_inbound',
        'follow_ups', 'patterns', 'predictions', 'people_model',
        'priorities', 'priority_change_log', 'alignment_history',
        'time_bound_events', 'daily_snapshots', 'metadata',
        'proact_output', 'activity_log'
    ])
    LOOP
        IF NOT EXISTS (
            SELECT 1 FROM pg_policies WHERE tablename = t AND policyname = 'anon_read'
        ) THEN
            EXECUTE format(
                'CREATE POLICY anon_read ON %I FOR SELECT USING (auth.role() = ''anon'')',
                t
            );
        END IF;
    END LOOP;
END $$;

-- ============================================================
-- AUTO-UPDATE TIMESTAMPS
-- Trigger function + per-table triggers (idempotent)
-- ============================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers only if they don't already exist
DO $$
DECLARE
    tbl TEXT;
    trg TEXT;
BEGIN
    FOR tbl, trg IN SELECT unnest(ARRAY[
        'commitments',      'decisions',        'directives',
        'requests_inbound', 'follow_ups',       'patterns',
        'predictions',      'people_model',     'priorities',
        'time_bound_events','unfinished_work',  'metadata',
        'proact_output',    'activity_log'
    ]),
    unnest(ARRAY[
        'trg_commitments_updated',      'trg_decisions_updated',        'trg_directives_updated',
        'trg_requests_updated',         'trg_followups_updated',        'trg_patterns_updated',
        'trg_predictions_updated',      'trg_people_updated',           'trg_priorities_updated',
        'trg_events_updated',           'trg_unfinished_updated',       'trg_metadata_updated',
        'trg_proact_updated',           'trg_activity_updated'
    ])
    LOOP
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.triggers
            WHERE trigger_name = trg AND event_object_table = tbl
        ) THEN
            EXECUTE format(
                'CREATE TRIGGER %I BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION update_updated_at()',
                trg, tbl
            );
        END IF;
    END LOOP;
END $$;

-- ============================================================
-- DONE
-- Verify: SELECT table_name FROM information_schema.tables
--         WHERE table_schema = 'public' ORDER BY table_name;
-- Expected: 19 tables
-- ============================================================
