---
name: webinar-conversion-dashboard
description: Builds a self-contained "Webinar Conversion Intelligence" dashboard for ANY webinar from that webinar's real data. Produces a single shareable HTML file with 6 KPIs and 7 analysis tabs — Retention Curve, Funnel Waterfall, What to Change, Objection Map, Sales Velocity, Chat Sentiment, and a run-over-run comparison. Use when someone says "build a webinar dashboard," "turn this webinar's numbers into a conversion dashboard," "conversion intelligence dashboard," or hands you webinar attendance/sales/chat data and wants it visualized. NOT for live revenue dashboards or generic charts.
version: 1.0.0
---

# Webinar Conversion Intelligence Dashboard

Builds a webinar post-mortem dashboard for any webinar, from that webinar's real data —
the same format Strategic Profits uses for its own webinar post-mortems. The output is one
self-contained HTML file — no build step for the recipient, no server, no dependencies.
Open it anywhere (file:// or hosted).

**The architecture:** all data lives in one `DATA` JSON object. The template's renderers
draw every section from it. You never edit the template or the renderers — you only build
the data file and run the builder. Any section you omit from the data is dropped from the
dashboard automatically.

## What it produces

A dark-themed dashboard matching `examples/demo-webinar.html`:

- **Header** — title, version, status badges (baseline date, live date, cart close, revenue target), actuals line
- **6 KPI cards** — color-coded (green/amber/blue/purple/teal/red) with value, sub-text, optional up/down delta
- **7 tabs** (each optional — include only the ones you have data for):
  1. **Retention Curve** — minute-by-minute canvas line chart with phase shading, key-event dots, drop-off markers; benchmarks-vs-industry table; top drop-off triggers; content-performance heatmap
  2. **Funnel Waterfall** — visual funnel + full conversion table + revenue-split pie + purchase-tier breakdown
  3. **What to Change** — P1/P2/P3 ranked change cards, each with evidence + action + status pills
  4. **Objection Map** — objection cards (high/med/low) with verbatim quotes + fixes
  5. **Sales Velocity** — day-by-day velocity bars + replay-driver table + next-run status + registration velocity
  6. **Chat Sentiment** — sentiment-by-phase chips with star ratings + sentiment→conversion correlation table
  7. **Run-over-run** — compare this run to the prior run + revenue-model scenarios + pre-launch status

## CRITICAL RULES (read before building)

1. **NO FABRICATION.** Every number, quote, name, and date must come from a real source you
   actually read this session (CRM pull, attendance export, chat export, sales report).
   This is a *conversion intelligence* tool — fabricated data corrupts real decisions. If a
   metric isn't available, either **omit that section** or put an honest placeholder
   (e.g. status `{ "text": "Requires CRM pull", "color": "gray" }`). Never invent attendance
   counts, sales figures, or attendee quotes. See `references/data-sources-guide.md`.
   (The shipped `examples/demo-webinar.data.json` is clearly-labeled FICTIONAL demo data —
   it exists to teach the structure, never to be presented as real.)

2. **Mark estimates as estimates.** When you can't get exact figures, write "~12",
   "~$17.2K est.", "Requires CRM pull". Approximate numbers carry a `~` and the data note
   says where the exact figure lives. If your source numbers don't reconcile (e.g. tier
   revenues don't sum to headline revenue), use them verbatim and add a `tierNote`/`note`
   flagging the discrepancy — never silently "fix" a number to make it add up.

3. **You build the data file, not the HTML.** Copy the example data file as your starting
   structure, replace its values with the target webinar's real numbers, then run the builder.
   Do not hand-edit the generated HTML.

4. **Test before delivery (both contexts).** Verify the built file in a preview server AND
   open it directly in Chrome/your browser (file://), clicking through every tab. The
   template is built to be file:// safe (no external resources, no fetch) — but always confirm.

## How to build (step by step)

### 1. Gather the data (no shortcuts — real sources only)
Read `references/data-sources-guide.md`. The sources, for any webinar:
- **Attendance / retention** — your webinar platform's attendance export (Zoom/StreamYard/etc.), filter AI notetakers
- **Funnel + sales + AOV + tiers** — your CRM and payment processor (orders, transactions)
- **Registration velocity** — CRM registration timestamps or dated registration reports
- **Chat sentiment + objections + quotes** — the webinar chat transcript export
- **Sales velocity (day-by-day)** — dated sales reports across the promo window
- **What to change** — derive from the retention + objection + velocity data (evidence-backed only)
- **Run-over-run** — the prior run's dashboard data + the current run's plan

Produce a **consumption receipt**: list each metric and the exact source it came from. Flag
anything you couldn't source.

### 1b. Auto-ingest the video stats from Zoom (when a webinar ends)
The fastest path for attendance/retention/watch-time is the **Zoom reports**. When a
webinar finishes, export its three reports from Zoom (Account → Reports → Webinar, or the
Usage Reports → Past Meetings view): **Attendee**, **Performance**, and **Q&A** CSVs. Then run:

```bash
python3 zoom_ingest.py <attendee.csv> [performance.csv] [qa.csv]
```

`zoom_ingest.py` parses the raw Zoom export and prints a JSON object with everything the
`retention` tab + attendance KPIs need — all computed, nothing estimated:
- `registrants`, `attended`, `showUpRate` (from the Performance report)
- `uniqueViewers`, `totalSessions`, `maxConcurrentZoom`, `computedPeak {minute,count,clock}`
- `humanUniqueViewers` + `botSessionsFiltered` (notetakers like Fireflies/Otter auto-detected)
- `stayedToEnd`, `avgWatchMin`, `medianWatchMin`, `durationMin`, `startClock`, `qaQuestions`
- `retentionCurve` — minute-by-minute concurrency, sampled to ~24 points → drop straight into `retention.chart.data`

Map the output into the data file: `retentionCurve` → `retention.chart.data`; `maxConcurrentZoom`
→ `chart.maxAtt` + the Peak KPI; `computedPeak` → the peak event label; `showUpRate`/`attended`
→ the Show-Up KPI + benchmarks; `medianWatchMin`/`avgWatchMin` → the watch-time benchmarks.
Combine with your CRM/payment numbers (registrations, sales, revenue split) for the funnel +
velocity tabs. The one piece Zoom can't give is sales ($ and units) — pull that from your
CRM or payment processor.

### 2. Create the data file
Copy `examples/demo-webinar.data.json` to a new file named for the webinar, in a
`builds/` folder (this is your source-of-truth data file — keep it; `dist/` is for generated
output only). E.g. `builds/<webinar>.data.json`. Create the folders first if missing:
`mkdir -p builds dist`. Work through it section by section against
`references/data-schema.md`, replacing every value. Delete any tab object (and its
`tabs[]` entry) you don't have data for. For partial data, see
`examples/partial-data.data.json` — the 3-tab minimal pattern with honest gray placeholders.

### 3. Build
```bash
python3 build.py builds/<webinar>.data.json dist/<webinar>-dashboard.html
```
(run from the skill folder). The builder validates the JSON (fails loud on syntax errors),
reports KPI/tab counts, and warns about structural mistakes (a tab with no data block, a
data block not in `tabs[]`, or unknown color tokens) so you can fix them before the verify step.

### 4. Verify (mandatory)
- Open the built file directly in your browser (file://) and confirm: header, KPI count, each tab renders, the canvas chart draws, tab-switching works. Optionally also serve it (`python3 -m http.server`, then open `http://localhost:8000/dist/...`) — the template is built to work identically in both.
- Check the browser console for errors (there should be none).
- Re-check three numbers against your consumption receipt (headline revenue, show-up rate, buyer count).
- Heed any builder warnings — especially **demo residue**: any value still identical to `examples/demo-webinar.data.json` must be re-sourced or removed before the dashboard ships.

### 5. Deliver
Hand over the single HTML file (and optionally the `.data.json` so it can be updated later).
To host it: any static host works (Cloudflare Pages, GitHub Pages, S3) — it's one file.
If you have the Judgment System installed, run `/delivery-audit` on it before it ships —
the source gate will re-verify every number against your consumption receipt.

## Files in this skill
- `templates/dashboard-template.html` — the data-driven template (DO NOT EDIT to change data)
- `build.py` — injects a data file into the template → one HTML file (Python 3, stdlib only)
- `zoom_ingest.py` — parses Zoom Attendee/Performance/Q&A CSVs → attendance + retention-curve JSON
- `examples/demo-webinar.data.json` — FICTIONAL worked example (every value invented) — your starting structure
- `examples/demo-webinar.html` — the rendered fictional example (what the output looks like)
- `examples/partial-data.data.json` / `.html` — the minimal 3-tab pattern for incomplete data
- `references/data-schema.md` — every field, every section, fully documented
- `references/data-sources-guide.md` — exactly where to pull each metric
- `install.sh` / `README.md` — installer mechanics
