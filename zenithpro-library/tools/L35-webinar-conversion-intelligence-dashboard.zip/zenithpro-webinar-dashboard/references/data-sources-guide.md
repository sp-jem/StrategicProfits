# Data Sources Guide — Where Every Metric Comes From

The dashboard is only as trustworthy as its inputs. **Every number must trace to a real
source you read this session.** This guide maps each dashboard section to where its data
actually lives in a typical stack — swap in your own CRM/payment/webinar tools.

> Golden rule: if you can't source a number, omit the section or mark it `Requires <source>`.
> Never fabricate attendance counts, sales, AOV, quotes, or names.

---

## 1. KPIs + Funnel Waterfall (revenue, buyers, AOV, tiers, failed transactions)
**Source:** your payment/CRM system of record (e.g. GoHighLevel, Stripe, ThriveCart, Kajabi).
- Orders / opportunities → buyer count, revenue, AOV, multi-tier breakdown
- Transactions list → failed/declined transactions, revenue at risk
- AOV = total revenue ÷ buyer count. Tiers = group orders by product/price.
- Before stating a headline total, confirm it sums to its components (tiers, day splits).

## 2. Retention Curve (minute-by-minute attendance)
**Source:** the webinar platform's attendance/engagement export (Zoom, StreamYard, WebinarJam, etc.).
- Export the per-attendee join/leave timeline, bucket into minutes → `[minute, count]`.
- **Filter AI notetakers** (Fireflies, Otter, Read.ai, Fathom bots) — count *unique humans*.
  `zoom_ingest.py` does this automatically for Zoom exports.
- Mark `events` (key content moments) and `dropoffs` (price reveal, etc.) from the
  webinar timeline / script.
- If only summary stats exist (peak, 1hr, end), you can still build benchmarks +
  triggers + heatmap; approximate the curve and note it.

## 3. Registration Velocity
**Source:** CRM registration timestamps, or dated registration reports if that's what you have.
- Snapshot reg counts at several timestamps → the `reg` rows with deltas.

## 4. Sales Velocity (day-by-day)
**Source:** dated sales reports / order exports across the promo window.
- If you only have two snapshots, derive the windows between them and **mark estimates**
  with `~` and a note saying where the exact figure lives.

## 5. Chat Sentiment + Objection Map (quotes, names, objections)
**Source:** the webinar chat transcript export (+ any post-webinar discussion or sales-team feedback).
- Quotes must be **verbatim** with the real attendee name. Do not paraphrase into quotes.
- Bucket sentiment by phase, rate, and pull representative real quotes per phase.
- Objections: cluster repeated concerns, count instances, attach the real quotes, write a fix.
- Frequency claims ("4+ instances") must be countable in the transcript.

## 6. What to Change (recommendations)
**Derived, not sourced — but every recommendation must cite evidence from §2–5.**
- Rank by revenue impact (P1/P2/P3). Each card's "evidence" line references a real number
  (a drop %, an objection count, a revenue split). No generic best-practice advice.

## 7. Run-over-run comparison
**Source:** the prior run's dashboard data + the current run's plan/script/asset status.
- Pull live asset status from your project tracker / funnel pages rather than assuming.
  `rightType: "pending"` for anything not yet done; cite the date checked.

---

## Consumption receipt (produce this before building)
List every section and its source. Example:
```
KPIs/Funnel ........ CRM orders export (2026-06-02) + Stripe transactions
Retention .......... Zoom attendee report, 14 AI bots filtered (zoom_ingest.py)
Reg velocity ....... CRM opt-in timestamps
Sales velocity ..... Dated order exports (mid-window = estimate, marked ~)
Sentiment/Objections Chat transcript export (587 msgs)
Changes ............ derived from above (each card cites a number)
Compare ............ prior dashboard + current asset status (checked 2026-06-02)
UNSOURCED: <none>  ← if anything is here, omit it or mark it in the dashboard
```
