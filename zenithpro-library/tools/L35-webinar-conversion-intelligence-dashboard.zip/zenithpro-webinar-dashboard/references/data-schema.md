# Data Schema — Webinar Conversion Intelligence Dashboard

The dashboard renders entirely from one JSON object. This is the complete contract.
Start from `examples/demo-webinar.data.json` (fictional worked example) and replace values.

**Color tokens** (used everywhere a `color` is asked for): `green` `amber` `blue` `red`
`purple` `teal` `gray`. Canvas colors are raw hex/rgba.

**HTML fields:** any field ending in `HTML` (e.g. `quoteHTML`, `evidenceHTML`, `insightHTML`)
renders raw HTML — use it when you need `<br>`, `<strong>`, `<em>`. The non-HTML twin
(e.g. `quote`) is HTML-escaped at render time. Use one or the other.

> **Safety:** plain-text fields are escaped (`< > & "`), so you can paste **verbatim chat
> quotes** containing those characters straight in — they render literally and cannot inject
> markup. `meta.title` is also HTML-escaped before it's written into the `<title>` tag, so a
> title with `< > &` (or a stray `</title>`) is safe too. The builder additionally neutralizes
> any `</script>` inside the data. Only the documented HTML fields (`*HTML`, `note`, `kpi.sub`)
> render raw — never put untrusted/verbatim text there.

**Omitting sections:** remove a tab's object AND its entry in `tabs[]` to drop it. Remove a
sub-block (e.g. `revSplit`, `tiers`, `triggers`) to drop just that card.

---

## Top level
```
{
  "meta":   { ... },          // header
  "kpis":   [ ... ],          // KPI cards (any count; 6 in the demo example)
  "tabs":   [ {id,label} ],   // which tabs appear, in order
  "retention": { ... },       // tab id "retention"
  "waterfall": { ... },       // tab id "waterfall"
  "changes":   { ... },       // tab id "changes"
  "objections":{ ... },       // tab id "objections"
  "velocity":  { ... },       // tab id "velocity"
  "sentiment": { ... },       // tab id "sentiment"
  "compare":   { ... }        // tab id "compare"
}
```
A tab renders only if BOTH its `tabs[]` entry exists AND its data block exists.

---

## meta
```
"meta": {
  "title": "Demo Webinar — Conversion Intelligence",              // h1 + <title>
  "subtitle": "Run 1 post-mortem · built from sourced data",      // grey text after h1
  "badges": [ { "text": "Run 1 Baseline: May 14", "color": "green" }, ... ],
  "actualsLine": "Run 1 actual: $27,389 · 65% from replay ..."    // optional grey summary line
}
```

## kpis (array of cards)
```
{
  "color": "green",                  // border-top + class color
  "label": "Run 1 Revenue",          // small uppercase label
  "value": "$27.4K",                 // big number
  "sub": "$27,389 total<br>...",     // small sub-text (HTML allowed)
  "delta": { "dir": "up", "text": "↑ Above avg" }   // optional; dir = up|down
}
```

## tabs
```
[ { "id": "retention", "label": "Retention Curve" }, ... ]
```
Valid ids: `retention waterfall changes objections velocity sentiment compare`.

---

## retention
```
{
  "chartTitle": "...", "chartSub": "...",
  "badge": { "text": "Run 1 Baseline", "color": "blue" },  // optional, top-right of chart card
  "chart": {
    "maxMin": 90, "maxAtt": 800,                          // axis maxima
    "yLabel": "Live Attendees",
    "yTicks": [0,200,400,600,800], "xTicks": [0,15,30,45,60,75,90],  // optional; auto if omitted
    "data": [ [minute, attendance], ... ],                 // the line; first point usually [0,0]
    "phases": [ { "start":0,"end":8,"color":"rgba(34,197,94,0.06)","label":"Hook" }, ... ],
    "dropoffs": [ { "min":63,"label":"Price reveal" }, ... ],    // dashed red verticals
    "events": [ { "min":8,"att":545,"label":"Live demo starts","color":"#22C55E" }, ... ]  // dots
  },
  "benchmarks": [ { "metric":"Peak Attendance","actual":"690 (82% of uniq)",
                    "actualColor":"#4ADE80","industry":"60–70%","grade":"Excellent","gradeColor":"green" }, ... ],
  "triggers": [ { "trigger":"Price Reveal","color":"#FCA5A5","time":"Min 58–63",
                  "drop":"566→512","dropColor":"#F87171","cause":"Price lands with no payment-plan mention" }, ... ],
  "heatmapTitle": "Content Performance Heatmap ...",
  "heatmap": [ { "time":"Min 8–25","level":"excellent","text":"🔥 LIVE DEMO ...","score":"Peak builder · 545→690" }, ... ]
}
```
`level` (heatmap bar color): `excellent good neutral warning danger`.

## waterfall
```
{
  "title": "...", "sub": "...",
  "steps": [ { "label":"Registrants","count":"2,140","pct":100,"color":"#3B82F6" }, ... ],
       // pct drives bar HEIGHT only (0-100), not conversion — floor tiny stages (e.g. buyers
       // at 1.4%) at ~5 so the bar stays visible; the table carries the true conversion rate.
       // arrow:true draws a → before the column (omit on first)
  "table": [ { "stage":"Total Registrations","bold":true,"count":"2,140","countColor":"#60A5FA",
               "conv":"—","convColor":null,"rev":"—","revColor":null,"revBold":false,
               "perPerson":"—","insight":"...", "insightHTML":"<strong>65% ...</strong>" }, ... ],
  "revSplit": { "total":"$27.4K","label":"Run 1 Total",
                "slices":[ {"pct":0.35,"color":"#3B82F6","label":"Live Night ~35%"}, ... ] },  // pct = fraction 0-1
  "tiersTitle": "Purchase Tier Breakdown — Run 1",
  "tiers": [ { "seats":"Standard","price":"$497","buyers":"25","revenue":"$12,425" }, ... ],
  "tierNote": "Rows must sum to the headline revenue ..."
}
```

## changes
```
{
  "note": "Ranked by <strong>revenue impact</strong> ...",     // HTML allowed
  "groups": [ {
    "label": "P1 — Highest Impact (Do These First)",
    "items": [ {
      "priority": "p1",                                        // p1|p2|p3 → left-border color
      "title": "Move Price Reveal Earlier ...",
      "badge": { "text":"P1 · Offer Structure","color":"red" },
      "evidence": "Evidence: ...",                             // or evidenceHTML
      "action": "→ ...",                                       // or actionHTML (green text)
      "metas": [ { "text":"Planned for Run 2","color":"amber" }, ... ]      // pills
    }, ... ]
  }, ... ]
}
```

## objections
```
{
  "note": "All objections sourced from the run's chat transcript ...",
  "columns": [ {                                               // rendered as 2 columns
    "sectionLabel": "High Frequency / High Revenue Impact",
    "cards": [ {
      "sev": "high",                                           // high|med|low → left-border color
      "title": "🔴 Price / Payment Plan",
      "quoteHTML": "\"...\" — Name<br>\"...\" — Name",          // or quote (plain)
      "fix": "Fix: ...",                                       // or fixHTML
      "pills": [ { "text":"4+ instances in chat","color":"red" }, ... ]
    }, ... ]
  }, ... ]
}
```

## velocity
```
{
  "title": "Sales Velocity — Run 1 Day-by-Day", "sub": "...",
  "bars": [ { "label":"May 14 (Webinar night)","barLabel":"~11 sales","width":35,"color":"#3B82F6","value":"~$9,587" }, ... ],
       // width = bar % (0-100), value = right-aligned figure
  "note": "Exact day-by-day breakdown requires a CRM pull. ...",
  "driversTitle": "What Drove the Replay Window",
  "drivers": [ { "asset":"Replay page","role":"Entry point ...","status":{"text":"Live ...","color":"green"} }, ... ],
  "statusTitle": "Run 2 Replay Sequence Status",
  "statusList": [ { "asset":"Replay Emails (5)","status":{"text":"In progress","color":"amber"},
                    "priority":{"text":"Critical","color":"red","badge":false} }, ... ],
        // priority.badge:true renders as a solid badge instead of a pill
  "statusNote": "65% of Run 1 revenue ...",
  "regTitle": "Registration Velocity — Run 1",
  "reg": [ { "time":"May 7 (announce)","count":"612","delta":"—","deltaColor":"#4ADE80","note":"List email #1" }, ... ]
}
```

## sentiment
```
{
  "title": "Chat Sentiment Analysis — 587 Messages", "sub": "...",
  "phases": [ { "phase":"🔥 Live Demo (Min 8–25) — PEAK","stars":"⭐⭐⭐⭐⭐",
                "quoteHTML":"\"Brilliant.\" — Name<br>..." }, ... ],   // auto-split into 2 columns
  "corrTitle": "Sentiment → Conversion Correlation",
  "corr": [ { "event":"Live demo (\"exactly what I needed\")","eventColor":"#4ADE80",
              "impact":"545 → 690 (peak)","implication":"Lead with the demo. ..." }, ... ]
}
```

## compare (run-over-run, e.g. Run 1 vs Run 2)
```
{
  "note": "Run 2 = Sep 10. Target $40K ...",
  "title": "Key Changes: Run 1 → Run 2",
  "leftHeader": "Run 1 (May 14 Baseline)", "rightHeader": "Run 2 (Sep 10 Changes)",
  "rows": [ { "label":"Price Reveal Timing","left":"Min ~63",
              "rightLabel":"Run 2 Change","right":"Moved earlier ~Min 50","rightType":"better" }, ... ],
        // rightType: neutral | better (green) | worse (red) | pending (amber)
  "modelTitle": "Run 2 Revenue Model",
  "model": [ { "scenario":"Run 2 target","sales":"45","aov":"$884",
               "revenue":"$39,780","revColor":"#4ADE80","bold":true }, ... ],
  "modelNote": "...",
  "statusTitle": "Run 2 Pre-Launch Status",
  "statusList": [ { "item":"Reg Push Emails (5)","status":{"text":"Done","color":"green"} }, ... ]
}
```

---

## Validation checklist before building
- [ ] Every `tabs[]` id has a matching data block (and vice-versa).
- [ ] All numbers trace to a real source (consumption receipt done).
- [ ] Estimates carry `~` and a note says where the exact figure lives.
- [ ] Colors use the valid tokens; canvas colors are valid hex/rgba.
- [ ] `chart.data` is sorted by minute; `maxAtt` ≥ the largest attendance value.
- [ ] JSON is valid (the builder will reject it otherwise).
