# Webinar Conversion Intelligence Dashboard

Turn any webinar's real numbers into a professional conversion-intelligence dashboard —
the same post-mortem format Strategic Profits uses for its own webinars. The output is one
self-contained HTML file: no server, no build step, no dependencies for whoever you hand it
to. Open it anywhere.

---

## What This Does For You

After every webinar you run, the numbers that explain what happened — where people dropped
off, what they objected to, when the sales actually came in — are scattered across your
webinar platform, your CRM, and your chat log. By the time you've eyeballed them, the next
launch is already moving.

This skill turns those numbers into one dashboard with 6 KPIs and 7 analysis tabs:
Retention Curve, Funnel Waterfall, What to Change (ranked by revenue impact), Objection Map
(with verbatim quotes), Sales Velocity, Chat Sentiment, and a run-over-run comparison. It's
how you make run 2 beat run 1 with evidence instead of hunches — and the single HTML file
is presentation-ready for your team, a client, or a partner.

## What's in the box
```
zenithpro-webinar-dashboard/
├── SKILL.md                         # the skill (how to gather data + build)
├── README.md                        # this file
├── build.py                         # data file → dashboard HTML (Python 3, stdlib only)
├── zoom_ingest.py                   # Zoom CSV exports → attendance/retention JSON
├── install.sh                       # installs the skill into ~/.claude/skills/
├── templates/
│   └── dashboard-template.html      # data-driven template (renderers — don't edit)
├── references/
│   ├── data-schema.md               # every field documented
│   └── data-sources-guide.md        # where to pull each metric
└── examples/
    ├── demo-webinar.data.json       # FICTIONAL worked example — your starting structure
    ├── demo-webinar.html            # the rendered fictional example — open this first
    ├── partial-data.data.json       # minimal 3-tab pattern for incomplete data
    └── partial-data.html
```

**Open `examples/demo-webinar.html` first** to see what you're building. Every value in it
is invented — it's a teaching example, not a real webinar.

## Installation

### Mac (Terminal)
```bash
cd <the unzipped zenithpro-webinar-dashboard folder>
bash install.sh
```
Copies the skill into `~/.claude/skills/webinar-conversion-dashboard/`. Restart Claude Code,
then in any session: "build a webinar conversion dashboard for <webinar>" invokes it.

### Windows
No installer needed — you can use the builder directly (see Quick start). To use it as a
Claude Code skill, copy this folder to `%USERPROFILE%\.claude\skills\webinar-conversion-dashboard\`
and restart Claude Code.

## Quick start (build a dashboard by hand)
```bash
# 1. Copy the example data file and fill it with YOUR webinar's REAL numbers
mkdir -p builds dist                                              # Windows (PowerShell): md builds, dist
cp examples/demo-webinar.data.json builds/my-webinar.data.json    # Windows: copy examples\demo-webinar.data.json builds\my-webinar.data.json
#    ...edit builds/my-webinar.data.json per references/data-schema.md...

# 2. Build
python3 build.py builds/my-webinar.data.json dist/my-webinar-dashboard.html
#    (Windows: python instead of python3)

# 3. Open it
open dist/my-webinar-dashboard.html        # macOS — or double-click the file
```
For incomplete data (no chat export, summary-only attendance), start from
`examples/partial-data.data.json` instead — the 3-tab minimal pattern with honest
gray placeholders.

Got Zoom? After a webinar, export the Attendee/Performance/Q&A CSVs and run
`python3 zoom_ingest.py attendee.csv performance.csv qa.csv` — it computes the whole
retention tab for you (and filters out the AI notetaker bots).

## The one rule that matters

**Real data only.** This is a conversion-intelligence tool — fabricated attendance, sales,
or quotes corrupt real decisions. If a metric isn't available, omit that section or mark it
honestly (the template drops anything you leave out). The fictional demo example exists to
teach the structure — never present invented numbers as real.

## Troubleshooting

- **`python3: command not found` (Mac).** Install Python 3 (`brew install python3`). Nothing
  else to install — the builder uses the standard library only.
- **Windows:** use `python` instead of `python3`.
- **The builder rejects my file.** It validates the JSON and fails loud on syntax errors —
  the error message includes the line. Most common: a trailing comma or an unclosed quote.
- **A tab doesn't appear.** A tab renders only if BOTH its `tabs[]` entry AND its data block
  exist. Check both.
- **The skill doesn't trigger in Claude Code.** Restart Claude Code after installing — skills
  are discovered at session start.

## Requirements

- **Python 3** (standard library only — nothing to install)
- **Claude Code** only if you want it as a skill; `build.py` works standalone

---

*Packaged by Strategic Profits for ZenithPro.*
