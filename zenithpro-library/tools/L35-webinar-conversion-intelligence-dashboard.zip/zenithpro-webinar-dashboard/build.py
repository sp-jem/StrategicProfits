#!/usr/bin/env python3
"""
Webinar Conversion Intelligence Dashboard — Builder
----------------------------------------------------
Injects a webinar data file (JSON) into the data-driven template and writes a
single self-contained, shareable HTML dashboard. No build tools, no servers,
no dependencies beyond the Python standard library.

Usage:
    python3 build.py <data.json> [output.html]

Example:
    python3 build.py builds/my-webinar.data.json dist/my-webinar-dashboard.html

The data file must conform to references/data-schema.md. JSON is a strict subset
of JavaScript object literals, so the file drops directly into `const DATA = {...}`.
"""
import html as html_lib
import json
import re
import sys
import os

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, "templates", "dashboard-template.html")

# Unicode line separators that are valid in JSON but illegal inside JS string literals.
LINE_SEP = chr(0x2028)
PARA_SEP = chr(0x2029)


def build(data_path, out_path=None):
    with open(data_path, "r", encoding="utf-8") as f:
        raw = f.read()

    # Validate it's well-formed JSON (fail loud, fail early — never ship broken data)
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        sys.exit(f"✗ Data file is not valid JSON: {e}\n  Fix {data_path} and re-run.")

    title = (data.get("meta") or {}).get("title", "Webinar Conversion Intelligence")
    # The title is injected raw into <title>__PAGE_TITLE__</title>. HTML-escape it so a
    # title containing < > & " (or a malicious </title><script>) can't break out of the
    # title element. The visible H1 already escapes via esc() in the template; this guards
    # the document-title sink. (The DATA object has its own </script> neutralization below.)
    title_escaped = html_lib.escape(title, quote=True)

    # --- Non-fatal structural warnings (catch the common mistakes before the verify step) ---
    warnings = []
    KNOWN_TABS = {"retention", "waterfall", "changes", "objections", "velocity", "sentiment", "compare"}
    tab_ids = [t.get("id") for t in data.get("tabs", []) if isinstance(t, dict)]
    for tid in tab_ids:
        if tid not in KNOWN_TABS:
            warnings.append(f"tab id '{tid}' is not a known tab type {sorted(KNOWN_TABS)}")
        elif tid not in data:
            warnings.append(f"tab '{tid}' is listed but has no data block — it will render empty")
    for tid in KNOWN_TABS:
        if tid in data and tid not in tab_ids:
            warnings.append(f"data block '{tid}' exists but is not in tabs[] — it will never be shown")
    # Unknown color tokens (typos render unstyled)
    VALID = {"green", "amber", "blue", "red", "purple", "teal", "gray"}
    bad_colors = set()

    def _scan(node):
        if isinstance(node, dict):
            for k, v in node.items():
                if (k == "color" and isinstance(v, str) and v
                        and not v.startswith("#") and not v.startswith("rgb") and v not in VALID):
                    bad_colors.add(v)
                else:
                    _scan(v)
        elif isinstance(node, list):
            for x in node:
                _scan(x)
    _scan(data)
    if bad_colors:
        warnings.append(f"unknown color token(s) {sorted(bad_colors)} — valid tokens: {sorted(VALID)} (or hex/rgba for canvas)")

    # Demo-residue guardrail: half-edited demo data must never ship as real.
    # If this is NOT the shipped fictional example, flag any leftover demo sentinels —
    # they mean the file was started from examples/demo-webinar.data.json and not fully replaced.
    if "fictional" not in title.lower():
        residue = []
        if "fictional" in raw.lower():
            residue.append("'fictional' label text")
        for nm in ("Jamie", "Priya", "Marcus", "Dana"):
            if re.search(r"\b%s\b" % nm, raw):
                residue.append(f"demo name '{nm}'")
        for const in ("27,389", "$27.4K", "2,140", "$884", "39,780", "14,964", "12,425", "9,587"):
            if const in raw:
                residue.append(f"demo value '{const}'")
        if residue:
            warnings.append(
                "possible demo residue from examples/demo-webinar.data.json: "
                + ", ".join(residue[:8])
                + " — replace every demo value with your webinar's real, sourced data")

    with open(TEMPLATE, "r", encoding="utf-8") as f:
        tpl = f.read()

    # Re-serialize so output is normalized & safe (ensure_ascii=False keeps emoji/—)
    data_literal = json.dumps(data, ensure_ascii=False, indent=2)
    # The DATA object is embedded inside a <script> tag. Neutralize </script> breakout
    # (`<\/` is a valid JSON/JS escape for `/`, so it stays parseable) and the two Unicode
    # line separators that would otherwise terminate a JS string literal.
    data_literal = (data_literal
                    .replace("</", "<\\/")
                    .replace(LINE_SEP, "\\u2028")
                    .replace(PARA_SEP, "\\u2029"))

    html = tpl.replace("__DATA_OBJECT__", data_literal)
    html = html.replace("__PAGE_TITLE__", title_escaped)

    if "__DATA_OBJECT__" in html or "__PAGE_TITLE__" in html:
        sys.exit("✗ Template placeholder not replaced — template may be corrupted.")

    if out_path is None:
        base = os.path.splitext(os.path.basename(data_path))[0].replace(".data", "")
        out_dir = os.path.join(HERE, "dist")
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, base + "-dashboard.html")

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)

    # Sanity counts so the operator can eyeball completeness
    kpis = len(data.get("kpis", []))
    tabs = len(data.get("tabs", []))
    print(f"✓ Built: {out_path}")
    print(f"  Title: {title}")
    print(f"  KPIs: {kpis} · Tabs: {tabs} · Size: {len(html):,} bytes")
    if warnings:
        print(f"  ⚠ {len(warnings)} warning(s):")
        for w in warnings:
            print(f"    - {w}")
    return out_path


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    build(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
