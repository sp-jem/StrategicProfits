#!/usr/bin/env bash
# Installs the webinar-conversion-dashboard skill into ~/.claude/skills/
# Safe to run from anywhere. Idempotent.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="$HOME/.claude/skills/webinar-conversion-dashboard"

echo "Installing webinar-conversion-dashboard ..."
mkdir -p "$DEST"

# Copy everything except build artifacts
rsync -a --delete \
  --exclude 'dist/' \
  --exclude 'builds/' \
  --exclude '.git/' \
  "$SRC"/ "$DEST"/ 2>/dev/null || {
    # rsync absent — fall back to cp
    cp -R "$SRC"/* "$DEST"/
  }

# Sanity check
if [[ -f "$DEST/SKILL.md" && -f "$DEST/templates/dashboard-template.html" && -f "$DEST/build.py" ]]; then
  echo "✓ Installed to $DEST"
  echo "  Test it:  cd \"$DEST\" && python3 build.py examples/demo-webinar.data.json /tmp/test-dash.html && open /tmp/test-dash.html"
else
  echo "✗ Install incomplete — expected files missing in $DEST" >&2
  exit 1
fi
