#!/usr/bin/env python3
"""
Zoom Report → Webinar Dashboard data ingestion
-----------------------------------------------
Parses the 3 Zoom webinar reports (Attendee, Performance, Q&A) into the
attendance/retention numbers the webinar-conversion-dashboard needs — so a
dashboard can be built automatically the moment a webinar ends.

Usage:
    python3 zoom_ingest.py <attendee.csv> [performance.csv] [qa.csv]

Outputs a JSON object to stdout with:
  registrants, attended, showUpRate, uniqueViewers, totalSessions,
  maxConcurrentZoom (Zoom-reported), computedPeak {minute, count, clock},
  stayedToEnd, avgWatchMin, medianWatchMin, durationMin, startClock,
  retentionCurve [[minuteOffset, concurrent], ...]  (for the chart `data`),
  humanUniqueViewers + botSessionsFiltered (notetakers/bots removed),
  qaQuestions.

Everything is computed from the raw Zoom CSV — no estimates. Bot/notetaker
sessions are detected by name/email pattern and reported separately (never
silently dropped from the Zoom-official totals).
"""
import csv, sys, json, io, re
from datetime import datetime

def fmt_clock(dt):
    """%-I is glibc-only (crashes on Windows) — format portably."""
    return dt.strftime("%I:%M %p").lstrip("0")

BOT_PATTERNS = ("notetaker", "fireflies", "otter.ai", "otter ai", "fathom",
                "read.ai", "read ai", "[guest] ai", "ai notetaker", "tldv",
                "fellow.app", "supernormal", "circleback", "ai assistant")

def is_bot(name, email):
    s = (name or "").lower() + " " + (email or "").lower()
    return any(p in s for p in BOT_PATTERNS)

def parse_dt(s):
    s = (s or "").strip().strip('"')
    if not s:
        return None
    for fmt in ("%m/%d/%Y %I:%M:%S %p", "%m/%d/%Y %H:%M:%S",
                "%d/%m/%Y %I:%M:%S %p", "%d/%m/%Y %H:%M:%S"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None

def read_section(rows, header_startswith):
    """Return (header, data_rows) for the section whose header row starts with header_startswith."""
    for i, r in enumerate(rows):
        if r and r[0].strip() == header_startswith:
            header = r
            data = []
            for rr in rows[i+1:]:
                if rr and rr[0].strip() in ("Panelist Details", "Attendee Details", "Host Details"):
                    break
                if rr and rr[0].strip() in ("Yes", "No"):
                    data.append(rr)
            return header, data
    return None, []

def main():
    attendee_path = sys.argv[1]
    perf_path = sys.argv[2] if len(sys.argv) > 2 else None
    qa_path = sys.argv[3] if len(sys.argv) > 3 else None

    raw = open(attendee_path, encoding="utf-8-sig").read()
    rows = list(csv.reader(io.StringIO(raw)))

    # Summary line (row index 3): Topic, ID, Start, Duration, Registrants, Cancelled, UniqueViewers, TotalUsers, MaxConcurrent, ...
    try:
        summ = rows[3]
        topic = summ[0].strip().strip('"')
        webinar_id = summ[1].strip()
        start = parse_dt(summ[2])
        duration = int(float(summ[3]))
        registrants = int(summ[4])
        unique_viewers = int(summ[6])
        total_users = int(summ[7])
        max_concurrent = int(summ[8])
        if start is None:
            raise ValueError("unparseable start time: " + summ[2])
    except (IndexError, ValueError) as e:
        sys.exit(
            "!! Could not read the Attendee report summary (expected on row 4: "
            "Topic, ID, Start, Duration, Registrants, Cancelled, UniqueViewers, "
            "TotalUsers, MaxConcurrent). Export the standard Zoom Attendee report "
            "and check your Zoom date format. Detail: %s" % e
        )

    # Attendee Details section
    hdr, data = read_section(rows, "Attendee Details")
    # Column indices in attendee detail rows:
    # 0 Attended,1 User Name,2 First,3 Last,4 Email,5 Reg Time,6 Approval,7 Join,8 Leave,9 Time(min),10 Is Guest,...
    JOIN, LEAVE, MINS, NAME, EMAIL = 7, 8, 9, 1, 4

    sessions = []           # (join_offset_min, leave_offset_min, email, name, is_bot)
    watch_by_email = {}     # email -> total minutes (sum of sessions)
    bot_sessions = 0
    for r in data:
        if len(r) <= LEAVE:
            continue
        j, l = parse_dt(r[JOIN]), parse_dt(r[LEAVE])
        if not j or not l:
            continue
        name, email = r[NAME], r[EMAIL]
        bot = is_bot(name, email)
        if bot:
            bot_sessions += 1
        jo = (j - start).total_seconds() / 60.0
        lo = (l - start).total_seconds() / 60.0
        jo = max(0, min(duration, jo)); lo = max(0, min(duration, lo))
        sessions.append((jo, lo, email, name, bot))
        try:
            m = float(r[MINS])
        except (ValueError, IndexError):
            m = max(0, lo - jo)
        watch_by_email[email] = watch_by_email.get(email, 0) + m

    # Minute-by-minute concurrency (humans only, bots excluded).
    # Half-open [jo, lo): a session counts while live, not on the exact leave minute —
    # so the final minute reflects who was still in when the host closed, not 0.
    curve = []
    peak = (0, 0)  # (minute, count)
    for minute in range(0, duration):
        c = sum(1 for (jo, lo, em, nm, bot) in sessions if not bot and jo <= minute < lo)
        curve.append([minute, c])
        if c > peak[1]:
            peak = (minute, c)

    # Sample the curve down to ~24 points for the chart
    last_min = curve[-1][0]
    step = max(1, duration // 24)
    sampled = [[m, c] for (m, c) in curve if m % step == 0]
    if sampled[-1][0] != last_min:
        sampled.append(curve[-1])
    # ensure the peak point is represented
    if not any(m == peak[0] for m, _ in sampled):
        sampled.append([peak[0], peak[1]])
        sampled.sort()

    stayed_to_end = curve[-1][1]
    human_emails = {em for (_, _, em, nm, bot) in sessions if not bot}
    watches = sorted(v for em, v in watch_by_email.items() if em in human_emails and v > 0)
    avg_watch = round(sum(watches) / len(watches), 1) if watches else 0
    median_watch = watches[len(watches)//2] if watches else 0

    def clock(minoffset):
        from datetime import timedelta
        return fmt_clock(start + timedelta(minutes=minoffset))

    perf = {}
    if perf_path:
        praw = list(csv.reader(io.StringIO(open(perf_path, encoding="utf-8-sig").read())))
        for i, r in enumerate(praw):
            if r and r[0].strip() == "# Registrants" and i+1 < len(praw):
                vals = praw[i+1]
                perf = {"registrants": int(vals[0]), "attended": int(vals[1]), "attendanceRate": int(float(vals[2]))}

    # Q&A summary: locate the header cell matching "# Question(s)" positionally and
    # read the numeric value beneath it. If the layout doesn't match, omit the metric
    # entirely (never emit a fake 0).
    qa_count = None
    if qa_path:
        qrows = list(csv.reader(io.StringIO(open(qa_path, encoding="utf-8-sig").read())))
        for i, r in enumerate(qrows):
            hit = next((j for j, cell in enumerate(r)
                        if re.search(r"#\s*(of\s*)?questions?", cell, re.I)), None)
            if hit is not None and i + 1 < len(qrows) and len(qrows[i+1]) > hit \
               and qrows[i+1][hit].strip().isdigit():
                qa_count = int(qrows[i+1][hit].strip())
                break

    out = {
        "topic": topic, "webinarId": webinar_id,
        "startClock": fmt_clock(start), "durationMin": duration,
        "registrants": perf.get("registrants", registrants),
        "attended": perf.get("attended", unique_viewers),
        "showUpRate": perf.get("attendanceRate", round(100*unique_viewers/registrants)),
        "uniqueViewers": unique_viewers, "totalSessions": total_users,
        "maxConcurrentZoom": max_concurrent,
        "computedPeak": {"minute": peak[0], "count": peak[1], "clock": clock(peak[0])},
        "stayedToEnd": stayed_to_end,
        "avgWatchMin": avg_watch, "medianWatchMin": median_watch,
        "humanUniqueViewers": len(human_emails), "botSessionsFiltered": bot_sessions,
        "retentionCurve": sampled,
    }
    if qa_count is not None:
        out["qaQuestions"] = qa_count
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    main()
