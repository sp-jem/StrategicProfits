# Course Factory — PC Installer (PowerShell)
# Run as Administrator: Right-click PowerShell > Run as Administrator

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "================================================"
Write-Host "  COURSE FACTORY — PC Installer"
Write-Host "================================================"
Write-Host ""

$SkillDir = "$env:USERPROFILE\.claude\skills\course-factory"
$ScriptsDir = "$SkillDir\scripts"

# 1. Copy skill files
Write-Host "Installing skill files..."
New-Item -ItemType Directory -Force -Path $ScriptsDir | Out-Null
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Copy-Item "$ScriptRoot\SKILL.md" "$SkillDir\" -Force
Copy-Item "$ScriptRoot\scripts\*.py" "$ScriptsDir\" -Force
Copy-Item "$ScriptRoot\scripts\*.sh" "$ScriptsDir\" -Force
Write-Host "   Skill installed to $SkillDir"

# 2. Python dependencies
Write-Host ""
Write-Host "Installing Python dependencies..."
try {
    pip install google-genai deepgram-sdk scrapetube youtube-transcript-api yt-dlp --quiet
    Write-Host "   Python dependencies ready"
} catch {
    Write-Host "   WARNING: pip install failed. Make sure Python 3.10+ is installed."
    Write-Host "   Download Python from: https://python.org/downloads/"
}

# 3. Wrangler (Cloudflare)
Write-Host ""
Write-Host "Checking Wrangler (Cloudflare deploy)..."
$wranglerExists = Get-Command wrangler -ErrorAction SilentlyContinue
if (-not $wranglerExists) {
    try {
        npm install -g wrangler
        Write-Host "   Wrangler installed"
    } catch {
        Write-Host "   NOTE: Could not install Wrangler. Install Node.js from https://nodejs.org/"
        Write-Host "   Then run: npm install -g wrangler"
    }
} else {
    Write-Host "   Wrangler already installed"
}

# 4. API Keys
Write-Host ""
Write-Host "================================================"
Write-Host "  API KEY SETUP"
Write-Host "================================================"
Write-Host ""
Write-Host "You need two API keys. Both have free tiers."
Write-Host ""
Write-Host "  1. Gemini API:  https://aistudio.google.com/app/apikey"
Write-Host "  2. Deepgram:    https://console.deepgram.com/"
Write-Host "     (optional — skill works without it)"
Write-Host ""

$GeminiKey = Read-Host "Enter your Gemini API key"
if ([string]::IsNullOrWhiteSpace($GeminiKey)) {
    Write-Host "   Skipping — add your key later by editing $SkillDir\config.json"
    $GeminiKey = "YOUR_GEMINI_API_KEY_HERE"
}

$DeepgramKey = Read-Host "Enter your Deepgram API key (press Enter to skip)"
if ([string]::IsNullOrWhiteSpace($DeepgramKey)) {
    Write-Host "   Deepgram skipped — will use YouTube subtitle extraction instead"
    $DeepgramKey = "YOUR_DEEPGRAM_API_KEY_HERE"
}

$Config = @{
    GEMINI_API_KEY   = $GeminiKey
    DEEPGRAM_API_KEY = $DeepgramKey
} | ConvertTo-Json

Set-Content -Path "$SkillDir\config.json" -Value $Config

Write-Host ""
Write-Host "================================================"
Write-Host "  INSTALLATION COMPLETE"
Write-Host "================================================"
Write-Host ""
Write-Host "  Skill installed: $SkillDir"
Write-Host "  Config saved:    $SkillDir\config.json"
Write-Host ""
Write-Host "  To run: open Claude Code and type /course-factory"
Write-Host "  Or say: 'Use the course-factory skill'"
Write-Host ""
Write-Host "  First deploy? Run: wrangler login"
Write-Host ""
