# Course Factory — Installation Guide

Builds a complete online course from scratch using YouTube research. Produces:
- Full course curriculum (modules + lessons)
- Arena-quality sales copy (6 copywriting methodologies compete)
- Production-ready landing page
- Deployed live URL

---

## What You Need Before Installing

### Required Accounts & API Keys

| Service | Free Tier | Get Key At |
|---------|-----------|-----------|
| **Google Gemini API** | Yes (generous) | https://aistudio.google.com/app/apikey |
| **Deepgram** | $200 free credit | https://console.deepgram.com/ |
| **Cloudflare** | Yes (free) | https://dash.cloudflare.com/ |

### Required Software

- **Claude Code** (CLI) — you already have this
- **Python 3.10+** — check: `python3 --version`
- **Node.js 18+** — check: `node --version`
- **Chrome browser** — for YouTube cookie export (fixes rate limiting)

---

## Installation

### Mac
```bash
bash install.sh
```

### PC (PowerShell — run as Administrator)
```powershell
.\install.ps1
```

The installer will:
1. Copy the skill to `~/.claude/skills/course-factory/`
2. Install Python dependencies
3. Install Cloudflare Wrangler (for deployment)
4. Ask for your API keys and save them to config

---

## Running the Skill

After installation, in Claude Code:
```
/course-factory
```

Or just say:
```
Use the course-factory skill to build a [niche] course
```

---

## Output Location

All output lands on your Desktop:
```
~/Desktop/CourseFactory/output/{niche}-{timestamp}/
├── research/      — YouTube channels found
├── transcripts/   — All downloaded transcripts
├── course/        — Analysis, outline, sales copy
└── landing-page/  — Built HTML + deployed URL
```

---

## Troubleshooting

**"Scripts missing" error** — Re-run the installer.

**YouTube blocking** — The downloader auto-exports Chrome cookies. Make sure Chrome is installed and you're logged into YouTube.

**Deepgram fails** — Falls back to subtitle extraction automatically. Still works, slightly lower quality.

**Cloudflare deploy fails** — Run `wrangler login` in terminal first, then retry.
