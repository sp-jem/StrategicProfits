# Kling AI Video Producer — Windows PowerShell Installer

$SKILL_NAME = "kling-ai-video-producer"
$CLAUDE_DIR = Join-Path $env:USERPROFILE ".claude\skills\$SKILL_NAME"
$SOURCE_DIR = Join-Path $PSScriptRoot "skills\$SKILL_NAME"

Write-Host ""
Write-Host "=== Kling AI Video Producer — Installer ==="
Write-Host "Installing skill: $SKILL_NAME"
Write-Host ""

# Check source
$SourceFile = Join-Path $SOURCE_DIR "SKILL.md"
if (-not (Test-Path $SourceFile)) {
    Write-Host "ERROR: Cannot find $SourceFile" -ForegroundColor Red
    Write-Host "Make sure you're running this from the installer folder."
    exit 1
}

# Create directory
if (-not (Test-Path $CLAUDE_DIR)) {
    New-Item -ItemType Directory -Path $CLAUDE_DIR -Force | Out-Null
}
Write-Host "Created: $CLAUDE_DIR"

# Copy skill
Copy-Item -Path $SourceFile -Destination (Join-Path $CLAUDE_DIR "SKILL.md") -Force
Write-Host "Installed: SKILL.md"

# Verify
$InstalledFile = Join-Path $CLAUDE_DIR "SKILL.md"
if (Test-Path $InstalledFile) {
    $Lines = (Get-Content $InstalledFile | Measure-Object -Line).Lines
    Write-Host ""
    Write-Host "SUCCESS — $SKILL_NAME installed ($Lines lines)" -ForegroundColor Green
    Write-Host ""
    Write-Host "IMPORTANT: Restart Claude Code for the skill to take effect." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Test it by asking Claude:"
    Write-Host '  "I want to create a product demo video for my landing page"'
} else {
    Write-Host ""
    Write-Host "FAILED — file not found after copy" -ForegroundColor Red
    exit 1
}
