# Kling AI Video Producer — Skill Installer

## What This Skill Does

Turns Claude into your AI video production assistant using **Kling AI**. Give it a creative brief and it produces everything you need to create professional video content:

- **Product demo videos** for landing pages and sales pages
- **Video ads** for social media (TikTok, Instagram, YouTube, Facebook)
- **Book trailers** and promotional videos
- **Social content** clips and loops
- **Explainer videos** and brand storytelling

The skill covers the complete Kling workflow: prompt writing, model selection (2.1 through 3.0), image-to-video and text-to-video pipelines, character consistency methods, camera and lighting vocabulary, and post-production guidance.

---

## What You Need

- **Kling AI account** — Sign up at [app.klingai.com](https://app.klingai.com)
- **Kling subscription** — $9/month (Starter) to $99/month (Premier) depending on your production needs
  - $9/mo Starter — enough for simple projects (1-2 hero shots + supporting clips)
  - $29/mo Pro — standard production tier (multiple scenes, iteration room)
  - $99/mo Premier — heavy production or ongoing content needs
- **Video editing software** — Premiere Pro, DaVinci Resolve (free), CapCut (free), or Final Cut Pro

---

## Installation

### Mac / Linux
```bash
bash install.sh
```

### Windows (PowerShell)
```powershell
powershell -ExecutionPolicy Bypass -File install.ps1
```

### Manual Install
Copy the file `skills/kling-ai-video-producer/SKILL.md` to:
```
~/.claude/skills/kling-ai-video-producer/SKILL.md
```

After installing, **restart Claude Code** for the skill to take effect.

---

## How to Use

Once installed, just describe what you want to create. Example prompts:

- "Help me create a product video for my online course"
- "I want to make a book trailer using Kling AI"
- "Create a 30-second video ad for my coaching program"
- "I need social media video content for my product launch"
- "Help me plan a cinematic product demo for my landing page"

Claude will walk you through the full workflow: choosing the right Kling model, writing optimized prompts, setting up your generation, and assembling the final video.

---

## What You Get

For each project, the skill produces:

1. **Shot List** — Numbered shots with descriptions, model recommendations, and mood/lighting notes
2. **Still Image Prompts** — Complete prompts for generating starting frames (image-to-video workflow)
3. **Motion Prompts** — Animation prompts optimized for Kling (15-40 words, motion only)
4. **Negative Prompts** — Project-wide negative prompt to avoid common artifacts
5. **Production Notes** — Model selection rationale, face adherence settings, aspect ratio, duration
6. **Post-Production Guide** — Recommended tools for upscaling, audio, editing, and export

---

## Works Best With

- **VO3 Cinematic Ad Creator** — For Veo 3 as an alternative/complement to Kling for video generation
- **Newspaper Ad Asset Builder** — For static ad assets that pair with your video campaigns
