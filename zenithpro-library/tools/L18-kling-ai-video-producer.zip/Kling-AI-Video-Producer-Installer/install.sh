#!/bin/bash
# Kling AI Video Producer — Mac/Linux Installer

SKILL_NAME="kling-ai-video-producer"
CLAUDE_DIR="$HOME/.claude/skills/$SKILL_NAME"
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)/skills/$SKILL_NAME"

echo ""
echo "=== Kling AI Video Producer — Installer ==="
echo "Installing skill: $SKILL_NAME"
echo ""

# Check source
if [ ! -f "$SOURCE_DIR/SKILL.md" ]; then
    echo "ERROR: Cannot find $SOURCE_DIR/SKILL.md"
    echo "Make sure you're running this from the installer folder."
    exit 1
fi

# Create directory
mkdir -p "$CLAUDE_DIR"
echo "Created: $CLAUDE_DIR"

# Copy skill
cp "$SOURCE_DIR/SKILL.md" "$CLAUDE_DIR/SKILL.md"
echo "Installed: SKILL.md"

# Verify
if [ -f "$CLAUDE_DIR/SKILL.md" ]; then
    LINES=$(wc -l < "$CLAUDE_DIR/SKILL.md")
    echo ""
    echo "SUCCESS — $SKILL_NAME installed ($LINES lines)"
    echo ""
    echo "IMPORTANT: Restart Claude Code for the skill to take effect."
    echo ""
    echo "Test it by asking Claude:"
    echo '  "I want to create a product demo video for my landing page"'
else
    echo ""
    echo "FAILED — file not found after copy"
    exit 1
fi
