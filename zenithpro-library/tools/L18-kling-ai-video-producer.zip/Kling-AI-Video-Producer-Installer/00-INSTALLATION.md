# Kling AI Video Producer — Installation Guide

## Before You Start

1. **Claude Code must be installed** on your computer. If you haven't set up Claude Code yet, do that first.
2. **You do NOT need a Kling AI account to install the skill.** You only need the account when you actually use the skill to create videos.
3. **Know your terminal:**
   - **Mac:** Open Terminal (Applications > Utilities > Terminal)
   - **Windows:** Open PowerShell (search "PowerShell" in Start menu)

---

## Option A: One-Command Install (Recommended)

### Mac / Linux

1. Open Terminal
2. Navigate to this installer folder:
   ```bash
   cd /path/to/Kling-AI-Video-Producer-Installer
   ```
3. Run the installer:
   ```bash
   bash install.sh
   ```
4. You should see `SUCCESS` with a line count confirming the install

### Windows

1. Open PowerShell
2. Navigate to this installer folder:
   ```powershell
   cd C:\path\to\Kling-AI-Video-Producer-Installer
   ```
3. Run the installer:
   ```powershell
   powershell -ExecutionPolicy Bypass -File install.ps1
   ```
4. You should see `SUCCESS` in green text confirming the install

---

## Option B: Manual Install

If the scripts don't work or you prefer manual setup:

1. Find the file `SKILL.md` inside this installer at:
   ```
   skills/kling-ai-video-producer/SKILL.md
   ```

2. Create the destination folder:
   - **Mac/Linux:**
     ```bash
     mkdir -p ~/.claude/skills/kling-ai-video-producer
     ```
   - **Windows (PowerShell):**
     ```powershell
     New-Item -ItemType Directory -Path "$env:USERPROFILE\.claude\skills\kling-ai-video-producer" -Force
     ```

3. Copy `SKILL.md` into that folder:
   - **Mac/Linux:**
     ```bash
     cp skills/kling-ai-video-producer/SKILL.md ~/.claude/skills/kling-ai-video-producer/SKILL.md
     ```
   - **Windows (PowerShell):**
     ```powershell
     Copy-Item "skills\kling-ai-video-producer\SKILL.md" "$env:USERPROFILE\.claude\skills\kling-ai-video-producer\SKILL.md"
     ```

---

## Option C: Drag and Drop

1. Open Finder (Mac) or File Explorer (Windows)
2. Navigate to your home folder
3. Show hidden files:
   - **Mac:** Press `Cmd + Shift + .`
   - **Windows:** View > Show > Hidden items
4. Open `.claude` > `skills`
   - If the `skills` folder doesn't exist, create it
5. Create a new folder called `kling-ai-video-producer`
6. Copy `SKILL.md` from this installer's `skills/kling-ai-video-producer/` folder into that new folder

---

## Verify Installation

After installing, confirm the file is in place:

**Mac/Linux:**
```bash
cat ~/.claude/skills/kling-ai-video-producer/SKILL.md | head -5
```
You should see the skill's YAML frontmatter starting with `---` and `name: kling-ai-video-producer`.

**Windows (PowerShell):**
```powershell
Get-Content "$env:USERPROFILE\.claude\skills\kling-ai-video-producer\SKILL.md" | Select-Object -First 5
```

---

## After Installing

1. **Restart Claude Code** — The skill won't load until you start a new session
2. **Test it** — Ask Claude something like:
   - "I want to create a product demo video for my landing page"
   - "Help me make a book trailer using Kling AI"
3. Claude should respond with the full Kling production workflow (shot list, prompts, model recommendations)

---

## Troubleshooting

### "Command not found" or "bash is not recognized"
- **Mac:** Make sure you're using Terminal, not another app
- **Windows:** Make sure you're using PowerShell, not Command Prompt (cmd)

### "Cannot find SKILL.md" error
- Make sure you're running the installer FROM the installer folder
- Check that the `skills/kling-ai-video-producer/SKILL.md` file exists in the installer

### Skill doesn't seem to work after install
- Did you restart Claude Code? The skill only loads on startup
- Check the file exists: `~/.claude/skills/kling-ai-video-producer/SKILL.md`
- Make sure the file isn't empty (should be 500+ lines)

### "Permission denied" on Mac/Linux
- Try: `chmod +x install.sh` then run again
- Or use the manual install method (Option B)

### "Execution policy" error on Windows
- Make sure you included `-ExecutionPolicy Bypass` in the command
- Or use the manual install method (Option B)

### Still stuck?
Use the manual install (Option B) or drag-and-drop method (Option C). They all produce the same result — getting `SKILL.md` into `~/.claude/skills/kling-ai-video-producer/`.
