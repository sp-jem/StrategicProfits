---
name: kling-ai-video-producer
description: |
  Create cinematic AI video using Kling AI — from prompt writing to final production. Based on validated techniques from 5 top experts (Curious Refuge, Creative Pad Media, Theoretically Media, Delightful Design, SECourses) plus book trailer specialists. Use when the user says "kling video," "AI video," "kling prompt," "cinematic AI," "animate this image," "AI film," "book trailer," "product video," "kling production," "image to video," or "create a video with kling."

  Covers: universal prompt formula, model selection (2.1–3.0), image-to-video vs text-to-video workflows, character consistency methods, camera/lighting vocabulary, multi-shot sequences, and common mistake avoidance.
version: 1.2.0
source: Curious Refuge + Creative Pad Media + Theoretically Media + Delightful Design + SECourses + Mike Donohue + Ryan Williamson
---

# Kling AI Video Producer

**Sources:** 5 expert channels (Curious Refuge, Creative Pad Media, Theoretically Media, Delightful Design, SECourses) + 2 book trailer specialists. All techniques below are validated against multiple expert sources.

**Platform:** app.klingai.com

---

## STEP 0: Ethical Use Check

Before producing any video content, evaluate the request against these guardrails:

### Hard Limits — Do Not Proceed
- **NEVER** generate fake testimonials with AI-generated people saying fabricated praise. If a student asks for this: decline, explain FTC compliance issues (fabricated endorsements violate 16 CFR Part 255), and suggest using real customer footage or text-based testimonials instead.
- **NEVER** create deepfakes of real people without explicit written consent from the individual depicted.
- **NEVER** produce deceptive before/after transformations that didn't actually happen.
- **NEVER** generate content designed to impersonate a real person for fraudulent purposes.

### Flag and Redirect
- If content could deceive viewers into believing something false — flag it and suggest an honest alternative. Example: instead of fake AI testimonial videos, suggest B-roll of product use with real written testimonials overlaid as text.
- If a request involves generating realistic people endorsing a product they haven't used, treat this as a fake testimonial regardless of how it's framed.

### AI Disclosure
- Some platforms (Meta, TikTok, YouTube) require or recommend disclosure when content is AI-generated, especially ads featuring synthetic people. Note this to the student and recommend adding "Created with AI" disclosures where applicable.
- FTC guidelines increasingly scrutinize AI-generated endorsements. When in doubt, disclose.

### Cross-Reference
This check aligns with the vault's No Fabrication Rule: "Never make up quotes, numbers, stories, testimonials, or proof points." That rule applies here — video testimonials are testimonials regardless of medium.

---

## Before You Start — Prerequisites

Complete these before your first Kling generation:

### Required
- [ ] **Kling account** — Sign up at [app.klingai.com](https://app.klingai.com) with email, verify, and add a payment method
- [ ] **Budget tier selected** — Choose your plan based on project scope:
  - $9/mo Starter — enough for simple projects (1-2 hero shots + supporting clips)
  - $29/mo Pro — standard production tier (multiple scenes, iteration room)
  - $99/mo Premier — heavy production or ongoing content needs
- [ ] **Editing software** — You need at least one: Premiere Pro, DaVinci Resolve (free version works), CapCut (free), or Final Cut Pro. This is where you assemble clips, add text overlays, music, and export.

### Required for Image-to-Video Workflows
- [ ] **Source images prepared** — JPG or PNG format, highest resolution available (2048px+ recommended), clear subject with good lighting. Kling accepts standard image formats; avoid WebP.
- [ ] **Still image generator** — Midjourney, Flux, or Kling's built-in AI Images. You need at least one way to create starting frames.

### Optional but Recommended
- **TopazLabs Giga Pixel** — Upscale still images before animation (paid, improves quality noticeably)
- **Topaz Video AI** — Upscale final video output (paid, for premium/client-facing work)
- **Eleven Labs** — AI voiceover if your video needs narration (free tier available)
- **Soundly** — Free sound effects library

### Nice to Have
- **Nano Banana** — Advanced character consistency pipeline (see Method 4)
- **Higgsfield** — Character tagging for Kling 3.0 Omni workflows (see Method 5)

> **Bottom line:** At minimum you need a Kling account, a budget tier, and editing software. Everything else enhances quality but is not mandatory to produce your first video.

---

## STEP 1: Determine Your Workflow

Ask the user:
1. **What are you creating?** (Ad, book trailer, product video, social content, explainer, other)
2. **Do you have existing images to animate?** (Yes → Image-to-Video workflow / No → Text-to-Video workflow)
3. **Do you need character consistency across multiple shots?** (Yes → choose a consistency method below)
4. **What's the mood/genre?** (Cinematic dark, bright commercial, documentary, sci-fi, romance, etc.)
5. **Budget tier?** (Free tier / $9 starter / $29 pro / $99 premier)

Based on answers, recommend:
- **Primary workflow:** Image-to-Video (most experts recommend this) or Text-to-Video
- **Kling model version** (see Model Selection below)
- **Character consistency method** (if needed)
- **Style anchors** for the project

---

## STEP 2: The Universal Prompt Formula

Every Kling prompt follows this 4-part structure (consensus across ALL experts):

```
[SUBJECT] + [ACTION] + [CONTEXT] + [STYLE]
```

### SUBJECT (Who/What)
- Primary focus with specific visual details
- Include: age, physical characteristics, clothing, material details, posture
- Bad: "a person"
- Good: "a weathered fisherman in his 60s wearing a salt-stained canvas jacket"

### ACTION (What Happens)
- Precise movement with clear ENDPOINTS
- Bad: "moves around"
- Good: "slowly turns to face the camera, rain dripping from his brow"
- ALWAYS include where motion begins AND ends — open-ended motion causes processing hangs

### CONTEXT (Where — 3-5 Elements Max)
- Environment, time of day, weather, surrounding elements
- Bad: listing 10+ individual objects
- Good: "a dimly lit Tokyo alley at 2am, neon reflections on wet pavement"
- Combine items into categories. Keep total nouns under 12.

### STYLE (How It Looks)
- Camera movement + camera angle + camera framing
- Lighting with NAMED sources (never "dramatic lighting")
- Mood/atmosphere
- Film stock or color grade reference

---

## STEP 3: Model Selection

### Which Model for What (as of March 2026):

| Use Case | Best Model | Why |
|---|---|---|
| Cinematic mood, emotional depth | Kling 2.6 / O1 | Rich lighting, unified atmosphere |
| Big sweeping camera movements, action | Kling 2.5 | Smooth motion physics, tracking shots |
| Stylized/animated aesthetics | Kling 2.5 Turbo / O1 | Clean lines, expressive motion |
| Natural realism / UGC style | Kling O1 | Most stable for hands, products |
| Multi-shot sequences with dialogue | Kling 3.0 | Native multi-shot, audio, lip-sync |
| Prompt adherence + image-to-video | Kling 2.1 Master | Best for animating existing art/images |
| Budget batch creation | Kling 2.1 Standard | Cost-efficient, predictable |
| High-motion smooth transitions | Kling 2.1 Master | Best fluidity for zooms/sweeps |

### Optimal Prompt Length by Model:

| Model | Text-to-Video | Image-to-Video |
|---|---|---|
| Kling 2.1 Standard | 30-50 words | 15-40 words |
| Kling 2.5 Turbo Pro | 40-60 words | 15-40 words |
| Kling 2.6 | 60-100 words | 15-40 words |
| Kling O1 | 50-100+ words | 15-40 words |
| Kling 3.0 | 50-150 words (multi-shot) | 15-40 words |

### Kling 3.0 Capabilities:
- 15-second video generation (extendable to 3 minutes)
- Multi-shot storyboards: up to 6 camera angles in a single output
- Native audio and dialogue (multiple accents/languages)
- Custom sound effects
- First and last frame control
- Native 4K resolution
- Character cloning (extract likeness + voice — quality is inconsistent)

---

## Platform Reality Check

Know these before you start spending credits:

### Credit Costs (Approximate — varies by plan)
| Generation Type | Approximate Credit Cost |
|----------------|------------------------|
| Kling 2.1 Standard, 5s | ~10 credits |
| Kling 2.5 / 2.6, 5s | ~20-30 credits |
| Kling O1, 5s | ~30-50 credits |
| Kling 3.0, 15s multi-shot | ~50-100 credits |
| Still image generation | ~2-5 credits |

*Credit costs change as Kling updates pricing. Check your account dashboard for current rates.*

### Generation Time
- Most clips take **2-10 minutes** to generate. Complex multi-shot or 3.0 generations can take longer.
- Queue times vary by server load. Peak hours (US evenings, Asian business hours) are slower.
- Do NOT sit and watch — queue multiple generations and review in batches.

### Known Limitations
- **Watermark:** Free tier adds a Kling watermark. Paid plans remove it.
- **Text in video:** Kling struggles significantly with rendering readable text in video. Do NOT try to generate on-screen text, titles, or captions inside Kling. Add all text overlays in post-production (Premiere, DaVinci, CapCut).
- **Content policy:** Kling rejects prompts involving violence, nudity, real public figures, and other restricted content. If your prompt is rejected, modify it — don't waste credits retrying the same prompt.
- **Video extensions:** Extensions beyond 5 seconds often introduce quality degradation, seam artifacts, or character drift. Plan for shorter, cleaner clips edited together in post rather than relying on long single generations.

---

## STEP 4: Image-to-Video Workflow (Recommended Primary Approach)

Expert consensus: Image-to-Video produces the most cinematic results.

### The Pipeline:
1. **Generate still image** with best available tool (Midjourney, Flux, Kling AI Images, etc.)
2. **Review the still** — if face/composition is wrong, regenerate. Don't waste video credits on a bad still.
3. **Upscale** with TopazLabs Giga Pixel (optional but recommended)
4. **Animate with Kling** (Image-to-Video mode)
5. **Upscale video** with Topaz Video AI (optional)
6. **Edit and composite** in Premiere/DaVinci/Final Cut Pro

### CRITICAL Image-to-Video Rule:
**NEVER redescribe what is already in the image.** Write ONLY motion instructions.

### Still Image Prompt (50-150 words):
Follow the full 4-part formula: SUBJECT + ACTION + CONTEXT + STYLE. Include specific camera angle, named lighting source, film stock reference. Keep element count under 12 total nouns.

### Motion Prompt (15-40 words):
- Motion instructions ONLY
- All motion must have endpoints ("lifts, then settles" not just "lifts")
- Use restrained motion: "subtle," "slow," "micro"
- Use cinematic camera vocabulary (see below)
- Include "maintain silhouette" or "preserve shape" for character stability

### Face Adherence Guide (when using face references):

| Framing | Adherence % | When |
|---------|-------------|------|
| Extreme close-up | 85-90 | Tight facial shots |
| Medium close-up | 80-85 | Most character shots |
| Medium shot | 75-80 | Two-shots, mid-body framing |
| Wide shot / action | 65-75 | Running, fighting, wide establishing |

### Setup in Kling:
1. Go to app.klingai.com
2. Open **AI Images** tab
3. Click **Reference** → upload face/style reference image
4. Set reference type (Face, Style, etc.)
5. Set face adherence slider per the guide above
6. Set aspect ratio (16:9 for landscape, 9:16 for vertical, 1:1 for square)
7. Add negative prompt: `Smiling (unless intended), cartoonish, bright oversaturated colors, low resolution, morphing, blurry text, disfigured hands`
8. Generate still
9. Review still — regenerate if needed
10. Switch to **AI Videos** tab → **Image to Video**
11. Select recommended model version for this shot type
12. Upload approved still as starting frame
13. Write motion prompt (15-40 words, motion only)
14. Set duration to **5 seconds** (cleanest results)
15. Generate

---

## STEP 5: Text-to-Video Workflow

Use when you don't have source images and need AI to create everything.

### When to Use:
- Complete creative freedom needed
- Scenes that don't exist in your image library
- Multi-shot sequences with dialogue (Kling 3.0)
- Environment-heavy establishing shots

### Text-to-Video Prompt Requirements:
Must include ALL visual elements: subject details, actions, environment, camera behavior, lighting sources, mood. Typical length: 50-150 words.

### Multi-Shot Prompting (Kling 3.0):
```
Shot 1: [Wide establishing] Description of scene...
Shot 2: [Close-up] Description of action...
Shot 3: [Over-shoulder] Description of dialogue...
```

### Dialogue Formatting (Kling 3.0):
```
[Character A: Role Description, voice quality]: "Dialogue line."
Action description between lines.
[Character B: Role Description, voice quality]: "Response line."
```

Use temporal markers: "Immediately," "Pause," "Silence" to control rhythm.

---

## STEP 6: Camera & Lighting Vocabulary

### Camera Movement (use INSTEAD of generic "moves"):
| Term | What It Does |
|------|-------------|
| **Dolly push** | Camera moves toward subject |
| **Dolly pull** | Camera moves away from subject |
| **Whip-pan** | Fast horizontal camera sweep |
| **Shoulder-cam drift** | Handheld, organic movement |
| **Crash zoom** | Rapid zoom in |
| **Snap focus** | Sudden focus shift between subjects |
| **Tracking shot** | Camera follows alongside subject |
| **Crane shot** | Camera rises vertically |
| **Steadicam orbit** | Smooth circular movement around subject |
| **Low-angle** | Camera below subject, looking up |
| **High-angle** | Camera above subject, looking down |
| **Dutch angle** | Camera tilted for unease/tension |

### Lighting — Name Real Sources:
- Bad: "dramatic lighting"
- Good: "neon signs casting blue and pink pools on wet concrete"
- Good: "single candle flame illuminating half his face, deep shadows on the other"
- Good: "golden hour backlight with warm rim illumination"
- Good: "flickering fluorescent tube overhead, clinical and cold"

### Texture & Tactile Details (add for realism):
- Film grain, lens flares, reflections
- Fabric sheen, condensation, smoke, sweat
- Dust motes, steam, rain droplets, breath vapor

### Film Stock References (Kling understands these):
- "Shot on 35mm film"
- "Kodak Vision3" or "Kodak Portra 400 color palette"
- "VHS camcorder aesthetic with heavy grain and chromatic aberration"
- "IMAX 70mm with deep depth of field"
- "Anamorphic lens with oval bokeh"

---

## STEP 7: Character Consistency Methods

### Method 1: Image-to-Video Anchoring (All Versions — Simplest)
- Generate consistent character images first (using Midjourney + style/character references)
- Use those images as I2V starting frames
- The reference image is your "anchor" — Kling respects and preserves it

### Method 2: Elements Feature (Kling 1.6+)
- Upload 1-4 images as "elements"
- Select specific subjects (people, animals, objects)
- Describe actions and interactions in prompt
- Elements can be "bound" to maintain consistency across generations

### Method 3: Custom Model Training (Kling Native)
- Upload 10-30 videos of the character (10-15 seconds each)
- ONE clearly visible face per video
- Include different poses, angles, backgrounds, expressions
- Training takes approximately 90 minutes
- After training: enter prompt and select custom model as face reference
- Avoid: Multiple faces in training videos, insufficient angle variety

### Method 4: Nano Banana + Kling Pipeline (Curious Refuge Method)
- Use Nano Banana to generate images matching specific style/character/location references
- Iterate and refine character images for consistency
- Feed refined images into Kling for animation
- Rated superior to Seedream and Reve for reference-based generation

### Method 5: Kling 3.0 Omni Tagging
- Upload character images to Higgsfield platform
- Tag characters with "@" symbol in prompts
- System recognizes tagged images for consistent placement
- No starting frame required

---

## STEP 8: Common Mistakes to Avoid

| # | Mistake | Problem | Fix |
|---|---------|---------|-----|
| 1 | **Element overload** | Too many elements overwhelm the model | Keep under 5-7 distinct elements per prompt |
| 2 | **Missing camera instructions** | Static, lifeless shots | Always specify camera behavior with direction |
| 3 | **Open-ended motion** | "Hair moves in wind" causes processing hangs | Add endpoints: "hair gently moves, then settles" |
| 4 | **Redescribing in I2V** | Confuses the model | For I2V, write ONLY motion instructions |
| 5 | **Vague spatial language** | Morphing and distortion | Use explicit spatial terms: "fingers wrapped around handle" |
| 6 | **Mixed lighting terms** | Confuses style interpretation | Pick ONE coherent lighting scenario |
| 7 | **Specific number requests** | AI struggles with exact counts | Use "several" or "a group" unless critical |
| 8 | **Aggressive motion** | Chaotic, unusable output | Use "subtle," "slow," "micro" + "keep silhouette identical" |
| 9 | **AI demo reel thinking** | Impressive tech but no story | Start with storyboard and clear goals first |
| 10 | **Using Kling as all-in-one** | Mediocre at image gen, VFX, character cloning | Use Kling as video generator in a multi-tool stack |

---

## STEP 8.5: Iteration & Troubleshooting

**This is where you will spend most of your time.** Kling (like all AI video tools) does not produce perfect output on the first try. Set your expectations now.

### Expected Success Rate
- **Expect 2-4 usable outputs per 10 generations.** This is normal, not a sign you're doing it wrong.
- Hero shots (close-ups, emotional beats) may take 5-8 attempts.
- Atmospheric/environmental shots are more forgiving — often 2-3 attempts.
- Still image generation has a higher hit rate (~50-70%) than video generation.

### Diagnostic Troubleshooting

When output is wrong, diagnose the problem and apply the targeted fix:

| Problem | Likely Cause | Fix |
|---------|-------------|-----|
| Face morphing/warping | Too many elements, insufficient facial detail | Reduce to 1-2 subjects, add "maintain facial structure" and "preserve likeness" to prompt |
| Wrong camera movement | Vague camera instructions | Replace generic terms with exact vocabulary from the camera table (e.g., "dolly push" not "camera moves forward") |
| Artifacts/distortion | Model struggling with complexity | Try simpler composition, reduce noun count, or switch to a different model version |
| Doesn't match prompt | Prompt too long or contains contradictions | Reduce to core elements, remove conflicting descriptors, check for competing style references |
| Character inconsistency across shots | No reference anchoring | Use Image-to-Video with a consistent reference image as starting frame for every shot |
| Hands/fingers deformed | Common AI limitation | Add "naturally posed hands" or crop framing to avoid showing hands; fix in post if 80% acceptable |
| Motion too fast/chaotic | Missing "subtle" or "slow" qualifiers | Add "slow," "subtle," or "micro" before every motion verb; add "maintain silhouette" |
| Seam artifacts in extended video | Quality degrades with extensions | Don't extend — generate separate 5-second clips and edit together in post |

### Salvage Techniques
- **80% good rule:** If a generation is 80% good but has one flaw, consider using it. Use that output as a starting frame for a refined re-generation, or fix the flaw in post-production (crop, color grade, overlay).
- **Screenshot-to-I2V:** If a T2V generation produced a great frame but bad motion, screenshot the best frame and use it as an I2V starting image with new motion instructions.
- **Frankenstein edit:** Combine the best moments from multiple generations of the same shot in your editing timeline.

### Credit Budgeting
- **Budget 3-5x more credits than your final shot count.** For a 5-shot project, expect to spend credits on 15-25 generations.
- Front-load your budget on hero shots. Use cheaper models (2.1 Standard) for atmospheric B-roll.
- Always review stills before animating — a bad still wastes more credits than regenerating the image.

---

## STEP 9: Complete Production Workflow

### The Expert-Validated Pipeline:

```
1. STORYBOARD
   └─ Plan shots, determine mood, choose workflow

2. GENERATE STILLS (if Image-to-Video)
   ├─ Use Midjourney / Flux / Kling AI Images
   ├─ Upload face references, set adherence
   ├─ Follow 4-part formula: SUBJECT + ACTION + CONTEXT + STYLE
   └─ REVIEW each still before animating

3. ANIMATE
   ├─ Select correct Kling model per shot type
   ├─ I2V: Motion-only prompt (15-40 words)
   ├─ T2V: Full scene prompt (50-150 words)
   └─ Duration: 5 seconds (cleanest results)

4. UPSCALE (Optional)
   └─ Topaz Video AI for cinematic quality boost

5. AUDIO
   ├─ Voiceover: Eleven Labs / Kling 3.0 native
   ├─ Music: Licensed or AI-generated
   └─ SFX: Soundly (free) or stock libraries

6. EDIT
   ├─ Premiere Pro / DaVinci Resolve / Final Cut Pro
   ├─ Add transitions, pacing, color grading
   ├─ Add film grain in post for depth (expert tip)
   └─ Final export
```

### Budget-Conscious Tips:
- Mike Donohue created a complete book trailer for $9 (Kling starter plan)
- Use free tools for assembly (Canva, Soundly)
- Generate stills first — review before spending video credits
- Kling 2.1 Standard for batch/atmospheric shots (cheapest)
- Save 2.5/2.6/3.0 credits for hero shots

---

## STEP 10: Genre Style Presets

When the user specifies a genre, apply these style anchors:

### Corporate / Professional
- Clean, bright lighting from large soft sources
- Neutral color palette (whites, grays, blues)
- Smooth, slow camera movements
- "Shot on RED camera, corporate documentary style"
- Shallow depth of field for interviews, deep for wide shots

### Dark / Thriller / Drama
- Warm amber and candlelight gold tones
- Deep shadow with Caravaggio chiaroscuro
- Side lighting from named sources (candles, lamps, moonlight)
- "Shot on 35mm, Kodak Vision3"
- Shallow depth of field throughout

### Bright / Commercial / Product
- High-key lighting, clean whites
- Product close-ups with studio lighting
- Smooth tracking and orbit shots
- "Commercial photography, soft studio lighting"
- Macro lens for detail shots

### Sci-Fi / Futuristic
- Cool blue/purple color palette with neon accents
- Volumetric fog/haze
- Wide establishing shots for scale
- "Shot on IMAX 70mm, Blade Runner color grade"
- Anamorphic lens distortion

### Documentary / UGC
- Natural lighting, handheld feel
- Kling O1 model (most natural realism)
- Shoulder-cam drift for organic movement
- "Shot on iPhone, natural lighting"
- Minimal post-processing look

---

## Platform-Specific Creative Conventions

Genre presets handle the VISUAL style. These conventions handle the STRUCTURAL style — pacing, duration, and hook placement differ by where the video will live.

### TikTok / Instagram Reels (9:16 vertical)
- **Hook in first 1-1.5 seconds.** The first shot must arrest attention — movement, a face, a surprising visual. Do NOT open with a slow establishing shot.
- **Pacing:** Fast cuts. 1-2 second clips. Multiple angles. Use Kling's 5-second generations and trim to the best 1-2 second moments.
- **Duration:** 15-30 seconds total for ads. Up to 60 seconds for organic content.
- **Style:** UGC/Documentary preset works best. Overly cinematic looks can feel out of place on these platforms.
- **Sound:** Audio-on is NOT guaranteed. Design so the visual hook works on mute. Add text overlays in post.

### YouTube (16:9 landscape)
- **Pre-roll ads:** Front-load brand and value proposition in first 5 seconds (viewers skip after 5). Generate your most compelling 5-second clip for the open.
- **Organic content:** Slower build acceptable. Establishing shots work. 10-30 second AI video segments within longer content.
- **Pacing:** Can be more cinematic — longer cuts, smoother transitions, more atmospheric builds.
- **Style:** Any genre preset works. YouTube audiences accept higher production value.

### Landing Page / Sales Page Hero Video
- **Slow reveal is acceptable.** Viewers are already on the page — you don't need a scroll-stopping hook.
- **Loop-friendly:** Design the video to loop seamlessly (ending matches beginning mood/position). Keep to 5-10 seconds.
- **Mood over motion:** Atmospheric, subtle movement preferred. Aggressive motion distracts from page copy.
- **No audio by default.** These autoplay muted. Design for visual impact only.

### Facebook / LinkedIn Feed (1:1 or 16:9)
- **Hook in first 2-3 seconds.** Feed scroll is fast but not as aggressive as TikTok.
- **Text safe zones:** Keep key visuals centered — feed crops can clip edges.
- **Duration:** 15-60 seconds for ads. Shorter performs better.
- **Style:** Corporate/Professional preset for LinkedIn. Bright/Commercial for Facebook product content.

### Email / Embedded (GIF or short clip)
- **Keep under 5 seconds.** Email clients handle short loops best.
- **Export as GIF or short MP4.** Check file size limits for your email platform.
- **Simple motion only.** One subject, one action. Complex scenes waste bandwidth and attention.

---

## OUTPUT FORMAT

For each project, deliver:

1. **Shot List** — numbered shots with: description, model recommendation, workflow (I2V or T2V), mood/lighting notes
2. **Still Image Prompts** (if I2V) — complete prompts per shot following the 4-part formula
3. **Motion Prompts** — animation prompts per shot (15-40 words, motion only for I2V)
4. **Negative Prompts** — project-wide negative prompt
5. **Production Notes** — model selection rationale, face adherence settings, aspect ratio, duration
6. **Post-Production Guide** — recommended tools for upscaling, audio, editing, and export

---

*Sourced from Curious Refuge, Creative Pad Media, Theoretically Media, Delightful Design, SECourses, Mike Donohue, and Ryan Williamson. Zero fabricated techniques.*
