$Skills = @("motivation-spectrum-analyzer", "hybrid-demand-architect")
Write-Host "Installing ZenithPro: Hybrid Skills (2 skills)..."
$Success = 0; $Failed = 0
foreach ($Skill in $Skills) {
    $Dir = "$env:USERPROFILE\.claude\skills\$Skill"
    New-Item -ItemType Directory -Force -Path $Dir | Out-Null
    Copy-Item "$Skill\SKILL.md" "$Dir\SKILL.md"
    if (Test-Path "$Dir\SKILL.md") { Write-Host "✅ $Skill"; $Success++ }
    else { Write-Host "❌ $Skill — FAILED"; $Failed++ }
}
Write-Host "Installed: $Success / 2 skills"
Write-Host "Run first: /motivation-spectrum-analyzer [your market]"
Write-Host "Then run:  /hybrid-demand-architect [your market]"
