---
name: hybrid-demand-architect
description: "Runs the ZenithPro demand creation pipeline calibrated to a market's exact motivation spectrum. Takes the spectrum score from motivation-spectrum-analyzer and blends both pipelines (away and toward) in the right proportion for that specific market. Five modes: Pure Away, Away-Dominant, True Hybrid, Toward-Dominant, Pure Toward. The first demand creation system that consciously handles the full human motivation spectrum — because no real market is purely one direction. Part of the ZenithPro three-track system."
version: 1.0.0
author: Strategic Profits / ZenithPro
programs: [ZenithPro, ZenithPro-Hybrid-Markets, Force Multiplier, Connect the Dots]
interface:
  invoke: "/hybrid-demand-architect [market] [optional: spectrum score]"
  called_by: [user]
  outputs_to: [project folder]
dependencies:
  - motivation-spectrum-analyzer
  - demand-architect (optional — for away-weighted blends)
  - toward-demand-architect (optional — for toward-weighted blends)
---

# Hybrid Demand Architect

The demand creation pipeline calibrated to the full human motivation spectrum.

Every market has a dominant motivation direction. Most have both. This skill reads the spectrum and runs the right blend — activating avoidance motivation where it exists, aspiration motivation where it exists, and combining them into something more powerful than either track alone.

---

## LAYER 1: INVARIANTS

1. **Run motivation-spectrum-analyzer first.** If no spectrum score provided, run it before proceeding. The blend ratio is empirical, not assumed.
2. **The blend is proportional, not averaging.** A 65/35 away-dominant market gets a primary away pipeline with toward injections at specific points — not a 50/50 mix of both pipelines.
3. **The hybrid formulas are net new.** They don't come from either existing track. "Become the kind of person who never has to deal with this again" — these sentences activate BOTH directions simultaneously and exist only in the hybrid.
4. **Entry motivation and sustaining motivation may require different blends.** Entry: often weighted toward dominant direction. Retention: often toward-weighted regardless of entry (community/identity retains; pain relief doesn't).
5. **Save all outputs to files.** Never deliver analysis only in chat.

---

## PURPOSE

Answers the question: "Given that this market is X% away and Y% toward, what is the optimal demand creation strategy?"

**The insight that makes this necessary:**

ZenithPro (original) was built for avoidance markets. It works. But even in pain-driven markets, there are aspirational elements being left on the table. The buyer who wants to escape debt ALSO wants to be the kind of person who has their finances sorted. Activating both — the pain push AND the identity pull — simultaneously is more powerful than either alone.

This isn't "add some inspirational language to your pain copy." This is a structurally different architecture where aspiration and avoidance work together at every level: the desire map, the paradigm shift, the USP, the close, the urgency mechanism.

---

## THE FIVE MODES

### Mode 1: Pure Away (85-100% Away)
**Run:** `demand-architect` (original ZenithPro)
**Toward supplement:** Minimal — only in retention/community architecture
**Note:** Don't overthink it. The market is pain-driven. Run the original pipeline. The only hybrid element worth adding is a toward-flavored retention layer so customers who achieve results don't just leave — they stay because they've claimed a new identity.

---

### Mode 2: Away-Dominant (60-84% Away)
**Primary:** `demand-architect` framework
**Toward injections at 4 specific points:**

1. **Desire Map (L1 level):** Add the suppressed aspiration alongside the primary pain desires. The away desires are dominant but the aspiration is there — surface it. "The toward element in this market: [aspiration]. Weight it as a supporting desire that amplifies the primary pain-based channel."

2. **Paradigm Shift:** Standard away paradigm shift ("THAT'S why nothing worked") PLUS a permission-based addendum: "And here's what becomes possible once you break free: [identity aspiration]." The paradigm shift addresses both what was blocking them (away) and who they get to become (toward).

3. **USP:** Primary promise = solution language. Secondary promise = identity transformation. "Stop [pain state]. Become [aspiration state]." Not just one direction — both in sequence.

4. **Close/Urgency:** Primary urgency = cost of inaction (away). Secondary urgency = life-stage window (toward). "Every day this continues costs you [away consequence]. And the window to become [aspiration] while [life-stage context] is finite."

---

### Mode 3: True Hybrid (45-59% either direction)
**Run:** Both pipelines, synthesize outputs, apply hybrid formulas.

**The sequence:**

**Step 1: Dual Desire Mapping**
Run both `demand-desire-mapper` (away) and `toward-desire-mapper` (toward) on the same market. Identify:
- Primary away desires (pain-driven)
- Primary toward desires (aspiration-driven)
- The overlap point: what is the SAME underlying desire expressed as both pain (away from current) and aspiration (toward desired state)?

The overlap is the core of the hybrid brief. It's the same fundamental human desire expressing itself in two directions simultaneously.

Example (business coaching):
- Away: "I'm trapped working IN the business instead of ON it" (pain)
- Toward: "I want to be the CEO who architects the business, not the employee running it" (aspiration)
- Overlap desire: **Independence + Power** — the same L1 desires expressing as both escape (away) and achievement (toward)

**Step 2: Hybrid Paradigm Shift**
Neither "THAT'S why nothing worked" nor "You CAN do this" alone. Instead:

> "The reason [pain] keeps happening is [structural reason]. And the path out isn't just solving that problem — it's becoming the kind of person for whom that problem can't exist."

This is the hybrid paradigm shift. It addresses the mechanism (away) AND the identity transformation (toward) in a single reframe.

**Step 3: Hybrid Desire Architecture**
For each major desire identified:
1. Map the AWAY expression (how it shows up as pain/frustration)
2. Map the TOWARD expression (how it shows up as aspiration/identity)
3. Build the channel showing how BOTH expressions point to the same offer

**Step 4: Hybrid USP**
Apply the four Hybrid Copy Formulas (see below). Generate candidates in each formula. Select the strongest. The winning USP should feel like it activates both directions in the same sentence.

**Step 5: Hybrid Belief Gap Architecture**
Two simultaneous belief journeys:
- Away track: "What must they believe about the mechanism/solution to trust it?"
- Toward track: "What must they believe about themselves to claim the identity?"
- Hybrid: Both journeys must complete. Map the dependency: which belief unlocks which?

**Step 6: Hybrid Close**
- Pain recap (away): Remind them of the cost of inaction
- Aspiration pull (toward): Show them who they're becoming
- Hybrid urgency: Both life-stage window AND cost-of-inaction. The window is closing AND the pain is compounding. Both are true.

---

### Mode 4: Toward-Dominant (60-84% Toward)
**Primary:** `toward-demand-architect` framework
**Away injections at 3 specific points:**

1. **Entry Hook:** Acknowledge the mild avoidance element that brought them here. Don't dwell on it — acknowledge and pivot to aspiration. "You came here because [mild away trigger]. What you're actually moving toward is [aspiration]."

2. **Identity Permission Bridge:** In approach markets, the permission shift ("You CAN do this") becomes more powerful when it implicitly addresses the small away element: "The fact that you [mild away context] doesn't mean you missed your chance. It means you arrived at exactly the right moment."

3. **Close/Urgency:** Primary urgency = life-stage window (toward). Secondary urgency = mild consequence framing. "This is your chapter. Others are claiming this identity right now. And the one cost of waiting is [simple consequence] — not catastrophic, but real."

---

### Mode 5: Pure Toward (85-100% Toward)
**Run:** `toward-demand-architect` (Toward Markets)
**Away supplement:** Minimal — only in the close as mild consequence framing if needed.
**Note:** Don't import avoidance language into an approach-motivated market. The away element, if used at all, appears only as the softest possible urgency: "This chapter of your life is happening now."

---

## THE FOUR HYBRID COPY FORMULAS

These formulas exist only in the Hybrid pipeline. They activate both motivational directions simultaneously in a single sentence. Neither the away track nor the toward track produces them.

### Formula 1: Escape-Into
**Structure:** "Stop being [pain identity]. Start being [aspiration identity]."
**Mechanism:** Pairs avoidance with approach in a single sentence. The escape (away) IS the entry to the identity (toward).
**Example (business coaching):** "Stop being the most important — and most trapped — person in your business. Start being the architect your business actually needs."
**Example (weight loss):** "Stop being someone who hides from cameras. Start being someone who actually loves the person looking back."

### Formula 2: Transformation-Through
**Structure:** "The path out of [pain] is becoming [identity]."
**Mechanism:** Reframes the solution as identity transformation. The mechanism IS the identity shift, not a separate product feature.
**Example (business coaching):** "The path out of 80-hour weeks isn't working smarter. It's becoming the kind of business owner who would never create that problem in the first place."
**Example (finance):** "The path out of financial stress isn't a better budget. It's becoming someone who thinks about money completely differently."

### Formula 3: Identity-Solution
**Structure:** "Become the kind of person who never has to deal with [pain] again."
**Mechanism:** Makes the aspiration the source of the solution. The identity eliminates the problem — you don't solve it, you transcend it.
**Example (business coaching):** "Become the kind of CEO who has systems that run without you — so 'I need to be there for everything' stops being part of your story."
**Example (health):** "Become the kind of person who makes choices that feel automatic — so willpower stops being the thing standing between you and the life you want."

### Formula 4: Before-After-Identity (BAI)
**Structure:** "[Struggling identity] → [mechanism] → [aspirational identity]. [Pain] stops being part of your story."
**Mechanism:** Full transformation arc that makes the identity shift explicit and shows the mechanism as the bridge.
**Example (business coaching):** "Right now you're a founder who can't take a vacation without the business suffering. After ZenithPro, you're the architect who built something that grows while you sleep. Being trapped in your own business stops being your story."
**Example (creative skill):** "Right now you're someone who's always wanted to draw but 'can't.' After this, you're someone who sketches in cafés and airports and everyone asks 'did you DO that?' The question 'am I creative enough' stops being part of your story."

---

## EXECUTION PROTOCOL

### Step 0: Spectrum Score Verification

If spectrum score not provided:
1. Run `motivation-spectrum-analyzer` on the market
2. Get the score and zone classification
3. Proceed with appropriate mode

If spectrum score provided by user or prior skill run:
1. State the score and zone
2. Confirm which mode will be run
3. Proceed

---

### Step 1: Dual Desire Excavation

**For all modes (adapted by intensity):**

Map the desire architecture from BOTH directions:

**Away desire mapping:**
- Which of the 5 away signal categories are present?
- What are the primary L1 desires being expressed as pain?
- What is the deepest away motivation (the 3 AM thought)?

**Toward desire mapping:**
- Which of the 5 toward signal categories are present?
- What are the primary L1 desires being expressed as aspiration?
- What is the deep layer aspiration (what identity do they secretly want to claim)?

**Overlap identification:**
- Which L1 desires are active in BOTH directions? (This is always the core)
- Map this as: "The desire for [L1 desire] is expressing as both [away pain] and [toward aspiration]"

---

### Step 2: Hybrid Paradigm Shift Construction

Using the overlap desire(s), construct the hybrid paradigm shift:

**Template:**
> "[The reason [away pain] keeps happening] is [structural explanation]. That's not your fault — it's [reframe]. And what becomes possible when you address it isn't just fixing [pain] — it's becoming [aspiration identity]. [Pain] and [aspiration] are two expressions of the same thing."

**Quality test:** Read it aloud. Does it feel like it's speaking to both the person who is in pain AND the person who has an aspiration? If it only addresses one direction, rewrite.

---

### Step 3: Hybrid Desire Architecture

For each primary desire identified:

```
DESIRE: [L1 desire name]

AWAY EXPRESSION:
"[How this desire manifests as pain/frustration]"
Evidence: [quote or behavioral signal]

TOWARD EXPRESSION:
"[How this desire manifests as aspiration/identity]"
Evidence: [quote or behavioral signal]

CHANNEL MAP:
L1: [Desire]
    ↓
L2: "[Category belief — both directions]"
    ↓
L3: "[Product belief — both directions]"
    ↓
L4: "[Both identity permission (toward) AND self-efficacy (away)]"
    ↓
DEMAND: [Both pain relief AND identity transformation]
```

---

### Step 4: Hybrid USP Generation

Generate one candidate in each of the 4 Hybrid Copy Formulas.
Rate each on:
- Emotional activation (does it create both push and pull?)
- Identity clarity (is the aspiration specific?)
- Pain specificity (is the away element real and grounded?)
- Resonance (would a person in this market nod immediately?)

Select the strongest. State why.

---

### Step 5: Hybrid Belief Gap Map

**Dual bridge architecture:**

Away bridge (mechanism belief journey):
- Point A (away): [struggling, failing, frustrated]
- Point B (away): [believes this mechanism works and is different]
- Gaps in the away journey

Toward bridge (identity permission journey):
- Point A (toward): [curious but doubting themselves]
- Point B (toward): [I can become this person]
- Gaps in the toward journey

**Dependency mapping:**
- Which gaps must close first?
- Which away belief unlocks the toward belief? (Often: "If I believe this works, THEN I can believe I can become the person it creates")
- Which toward belief accelerates the away belief? (Often: "If I believe I can become [identity], THEN the mechanism feels worth trying")

---

### Step 6: Hybrid Close Architecture

**The hybrid close has four layers in sequence:**

1. **Pain acknowledgment** — brief, specific, not dwelling
   "You came into this [away context]. That's real."

2. **Aspiration activation** — the identity that's becoming possible
   "What you're actually moving toward is [specific aspiration]."

3. **Hybrid urgency** — both directions, both true
   Away element: "The cost of staying where you are is [specific consequence]."
   Toward element: "And the window to become [aspiration] while [life-stage context] is real."

4. **Hybrid call to action**
   Using one of the 4 Hybrid Copy Formulas as the closing hook.
   Not "buy now" — "[Identity invitation that also implies escape]."

---

## OUTPUT SPECIFICATION

**File:** `Hybrid-Demand-Brief-[Market].md`

**Structure:**
1. Spectrum Score recap + mode selected
2. Overlap Desire Analysis (the core of the hybrid brief)
3. Hybrid Paradigm Shift (with quality check)
4. Dual Desire Architecture (channel maps)
5. Hybrid USP (4 formula candidates + selected winner)
6. Hybrid Belief Gap Map (dual bridge)
7. Hybrid Close Architecture
8. Copy Direction Summary (specific guidance for writers)
9. What to Do Next (which pipeline skills to run, which to inject where)

---

## QUALITY GATE

Before saving:
- [ ] Spectrum score used to calibrate the blend (not assumed)
- [ ] Overlap desire identified — the L1 desire active in both directions
- [ ] Hybrid paradigm shift addresses BOTH mechanism (away) AND identity (toward)
- [ ] At least one Hybrid Copy Formula candidate produced in each of the 4 types
- [ ] USP winner passes resonance test: activates both push and pull
- [ ] Dual belief gap map shows dependency sequence
- [ ] Hybrid close has all 4 layers
- [ ] Copy Direction Summary tells writers something actionable they couldn't get from either pure track

---

## COPY DIRECTION SUMMARY (TEMPLATE)

After producing the full brief, always end with this section:

```markdown
## Copy Direction Summary

**This market is [X]% away / [Y]% toward — [Zone Name].**

**The core hybrid insight:**
[The L1 desire and how it expresses in both directions simultaneously]

**The winning copy direction:**
[Which Hybrid Formula won and why]

**Primary register:** [Away / Toward / True Blend]
**Entry hook type:** [Pain-aware / Aspiration-forward / Dual-activation]
**Urgency mechanism:** [Escalating cost / Life-stage window / Both]

**What the copy must do that neither pure track does:**
[The specific thing this market needs that requires the hybrid — the sentence only this approach can write]

**Example headline in hybrid register:**
[One concrete headline using the winning formula, specific to this market]
```

---

## HOW THIS CONNECTS TO THE FULL SYSTEM

**Before this skill:** Run `/motivation-spectrum-analyzer` to get the score.
**This skill produces:** The calibrated demand creation brief and hybrid copy formulas.
**After this skill:**
- Brief the copywriter with the Hybrid Demand Brief
- Use hybrid copy formulas directly in ad creative, VSL hooks, and email subjects
- Run the appropriate individual skills for deep-dives on any section (desire map, belief gaps, USP)
- The Hybrid close architecture feeds directly into any webinar close skill

**The three-track system:**
```
/motivation-spectrum-analyzer   ← always run first
         │
         ├── Pure Away → /demand-architect
         ├── Away-Dominant → /hybrid-demand-architect (Mode 2)
         ├── True Hybrid → /hybrid-demand-architect (Mode 3)
         ├── Toward-Dominant → /hybrid-demand-architect (Mode 4)
         └── Pure Toward → /toward-demand-architect
```
