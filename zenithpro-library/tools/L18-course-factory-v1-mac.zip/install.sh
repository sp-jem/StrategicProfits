#!/bin/bash
# Course Factory — Mac Installer
set -e

echo ""
echo "================================================"
echo "  COURSE FACTORY — Mac Installer"
echo "================================================"
echo ""

SKILL_DIR="$HOME/.claude/skills/course-factory"
mkdir -p "$SKILL_DIR/scripts"

# 1. Copy skill files
echo "Installing skill files..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp "$SCRIPT_DIR/SKILL.md" "$SKILL_DIR/"
cp "$SCRIPT_DIR/scripts/"*.py "$SKILL_DIR/scripts/"
cp "$SCRIPT_DIR/scripts/"*.sh "$SKILL_DIR/scripts/"
chmod +x "$SKILL_DIR/scripts/deploy_pages.sh"
echo "   Skill installed to $SKILL_DIR"

# 2. Python dependencies
echo ""
echo "Installing Python dependencies..."
pip3 install --quiet google-genai deepgram-sdk scrapetube youtube-transcript-api 2>&1 | grep -E "^(Collecting|Successfully|ERROR|error)" || true

# Check yt-dlp
if ! which yt-dlp &>/dev/null; then
    echo "Installing yt-dlp..."
    pip3 install --quiet yt-dlp
fi
echo "   Python dependencies ready"

# 3. Wrangler (Cloudflare deploy)
echo ""
echo "Installing Cloudflare Wrangler..."
if ! which wrangler &>/dev/null && ! which npx &>/dev/null; then
    echo "   NOTE: Node.js not found. Install from https://nodejs.org/ then run: npm install -g wrangler"
else
    npx wrangler --version &>/dev/null 2>&1 || npm install -g wrangler 2>/dev/null || true
    echo "   Wrangler ready (run 'wrangler login' before first deploy)"
fi

# 4. API Keys
echo ""
echo "================================================"
echo "  API KEY SETUP"
echo "================================================"
echo ""
echo "You need two API keys. Both have free tiers."
echo ""
echo "  1. Gemini API:  https://aistudio.google.com/app/apikey"
echo "  2. Deepgram:    https://console.deepgram.com/"
echo "     (optional — skill works without it, just lower quality transcripts)"
echo ""

read -p "Enter your Gemini API key: " GEMINI_KEY
if [ -z "$GEMINI_KEY" ]; then
    echo "   Skipping Gemini key — add it later by editing $SKILL_DIR/config.json"
    GEMINI_KEY="YOUR_GEMINI_API_KEY_HERE"
fi

read -p "Enter your Deepgram API key (press Enter to skip): " DEEPGRAM_KEY
if [ -z "$DEEPGRAM_KEY" ]; then
    echo "   Deepgram skipped — skill will use YouTube subtitle extraction instead"
    DEEPGRAM_KEY="YOUR_DEEPGRAM_API_KEY_HERE"
fi

cat > "$SKILL_DIR/config.json" << CONFIGEOF
{
  "GEMINI_API_KEY": "$GEMINI_KEY",
  "DEEPGRAM_API_KEY": "$DEEPGRAM_KEY"
}
CONFIGEOF

echo ""
echo "================================================"
echo "  INSTALLATION COMPLETE"
echo "================================================"
echo ""
echo "  Skill installed: $SKILL_DIR"
echo "  Config saved:    $SKILL_DIR/config.json"
echo ""
echo "  To run: open Claude Code and type /course-factory"
echo "  Or say: 'Use the course-factory skill'"
echo ""
echo "  First deploy? Run: wrangler login"
echo ""
