#!/usr/bin/env bash
# install.sh — Positioning Arena portable installer. Run from the package root.
set -euo pipefail

cd "$(dirname "$0")"

mkdir -p ~/.claude/skills ~/.claude/agents ~/.claude/positioning-arena/wild-cards/active

# the skill (self-contained: schools, lenses, pipeline, components all bundled)
rm -rf ~/.claude/skills/positioning-arena
cp -R skills/positioning-arena ~/.claude/skills/

# the 17 agent types (installed as <name>/AGENT.md, the directory agent format)
for f in agents/*.md; do
  name="$(basename "$f" .md)"
  mkdir -p ~/.claude/agents/"$name"
  cp "$f" ~/.claude/agents/"$name"/AGENT.md
done

echo "Installed:"
echo "  skill : ~/.claude/skills/positioning-arena"
echo "  agents: $(ls agents/*.md | wc -l | tr -d ' ') agent types into ~/.claude/agents/"
echo "  state : ~/.claude/positioning-arena/wild-cards/active"
echo
echo "Restart Claude Code, then invoke the positioning-arena skill."
