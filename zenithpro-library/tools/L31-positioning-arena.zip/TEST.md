# Positioning Arena — Portable Package Verification

Run on a CLEAN machine (or at minimum one with none of Rich's skills installed),
AFTER running `install.sh`.

## Static preflight (no tokens, ~1 minute)

```bash
cd ~/.claude/skills/positioning-arena

# 1. No paths to the source machine anywhere
! grep -ri "richardschefren" . || { echo "FAIL: hardcoded paths remain"; exit 1; }

# 2. Every roster skill resolves inside the package
node -e '
const r=require("./references/roster.json");
const fs=require("fs");
const schools=[...r.bands.A.competitors,...r.bands.B.competitors].map(c=>"references/schools/"+c.skill+"/SKILL.md");
const lenses=r.bands.C.competitors.map(c=>"references/lenses/"+c.skill+"/SKILL.md");
const missing=[...schools,...lenses,"references/lenses/toffler-naming-engine/SKILL.md"].filter(p=>!fs.existsSync(p));
if(missing.length){console.error("FAIL missing:",missing);process.exit(1)}
console.log("roster OK")'

# 2b. Every lens-map alternate also resolves inside the package
node -e '
const m=require("./references/lens-map.json");
const fs=require("fs");
const alts=m.layers.flatMap(l=>[l.anchor,...(l.alternates||[])]);
const missing=alts.filter(s=>!fs.existsSync("references/lenses/"+s+"/SKILL.md"));
if(missing.length){console.error("FAIL missing alternates:",missing);process.exit(1)}
console.log("lens-map OK ("+alts.length+" entries)")'

# 3. All 17 agents installed (directory format: <name>/AGENT.md)
for a in positioning-judge positioning-synthesist positioning-10x-critic positioning-school-spawner \
  posarena-trout-critic posarena-dunford-critic posarena-marion-critic posarena-dell-critic \
  posarena-raskin-critic posarena-brunson-critic posarena-moore-critic posarena-yoon-critic \
  posarena-godin-critic posarena-klaff-critic posarena-play-bigger-critic \
  posarena-category-pirates-critic posarena-blue-ocean-critic; do
  [ -f ~/.claude/agents/$a/AGENT.md ] || { echo "FAIL: missing agent $a"; exit 1; }
done

# 4. Wild-cards runtime dir exists
[ -d ~/.claude/positioning-arena/wild-cards/active ] || { echo "FAIL: wild-cards dir"; exit 1; }

echo "PREFLIGHT PASSED"
```

## Live smoke test (small token spend, ~10 minutes)

In Claude Code, invoke the skill with a reduced roster covering one of each band
PLUS the judge/synthesis path:

```
Run the positioning-arena skill for a smoke test:
  runId: "smoke-test-<today's date>"
  productName: "Test Widget Co"
  context: "A B2B SaaS that reduces invoice processing time for mid-market CFOs."
  outRoot: "~/positioning-arena-runs/smoke"
  only: ["trout", "play-bigger", "lens-desire"]
```

**Pass criteria** — check `~/positioning-arena-runs/smoke/runs/smoke-test-*/`:

1. `agents/` contains output for all 3 competitors (proves Band A school read,
   Band B school read, AND a bundled lens read — `lens-desire` exercises
   `references/lenses/girard-field-intelligence/`).
2. The critique phase produced fidelity-critic output for `trout` and
   `play-bigger` (proves the `posarena-*-critic` agent types resolve).
3. `judge.md` exists with a ranking (proves `positioning-judge` resolves).
4. Synthesis output + Vault output exist (proves `positioning-synthesist`
   resolves and the Vault component path works).
5. `scorecard.md` and `thoughtpad-harvest.md` exist (proves the harvester
   component path works).
6. `dashboard/live.html` was mirrored into the run root and loads via
   `python3 -m http.server` from the outRoot.
7. The workflow log contains zero "no such file" / "ENOENT" / unknown-agent
   errors.

If all 7 pass, the package is self-contained. Run one full 20-competitor run
before distributing widely.
