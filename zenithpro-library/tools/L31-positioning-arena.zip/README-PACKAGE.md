# Positioning Arena — packaged download

**Source:** `strategicprofits-bt/shared-claude-skills` @ `origin/master`
**Commit:** 2207be87 "feat: add Positioning Arena v1.1 skill + 17 agent types" (2026-06-11)
**Skill tree hash:** e54a4602f5a6d8f8b058aa24dc24123372a810e2
**Packaged:** 2026-07-16 by Gilfoyle

## Contents (122 files)

- `skills/positioning-arena/` — 105 files. The skill itself:
  - `SKILL.md`, `run.workflow.js`
  - `references/schools/` — 13 posarena-* positioning schools (SKILL.md + persona.md each)
  - `references/lenses/` — 53 deep-thinker lens files
  - `references/components/`, `references/pipeline/`
  - `references/roster.json`, `references/lens-map.json`
  - `dashboard/` — live.html, replay.html, README.md
  - `schemas/` — entry, judgment, thoughtpad
- `agents/` — 17 agent definitions (13 `posarena-*-critic` + `positioning-judge`,
  `positioning-synthesist`, `positioning-school-spawner`, `positioning-10x-critic`)

## Install

**Quick option:** run `bash install.sh` from the package root (Mac, Linux, or Git Bash on Windows). It installs the skill and the 17 agents for you (each agent as `<name>/AGENT.md`) and creates the wild-cards folder. See `INSTALL.md` and `TEST.md`.

Both directories are required — the skill dispatches to the `agents/` types.
Copy preserving the repo-relative layout:

    skills/positioning-arena/  ->  <skills-root>/positioning-arena/
    agents/*.md                ->  <agents-root>/

## Notes

1. **Version label mismatch (cosmetic).** The commit says "v1.1", but `SKILL.md`
   frontmatter and `references/roster.json` both say `1.0.0`, and the body header
   reads "Positioning Arena v1.0". Content is identical either way — there is only
   one positioning-arena on master and this is it. Only the label is inconsistent.
2. **This is the latest merged version.** Two unmerged branches
   (`codex/psychographic-avatar-canonical-20260707-155542`, `fix-sp-shim-targets-20260708`)
   carry a 7-line cross-reference rename (`avatar-excavation` ->
   `psychographic-avatar-excavation`) touching 5 files. Not merged, not included.
3. **Not currently live in SP-SHARED.** The `~/.claude/skills` symlink farm points at
   the SP-SHARED checkout, which does not have positioning-arena — so this skill is on
   master but not loadable by the fleet today.
4. Secret-scanned before packaging: clean.
