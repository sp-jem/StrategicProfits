# Positioning Arena — Portable Install

Self-contained package. No dependency on any other machine's skills — all 13 schools,
8 lens skills, 10 pipeline skills, 4 components, and 17 agent types are bundled.

## Requirements
- Claude Code installed (`claude` CLI or desktop app)
- macOS or Linux shell (on Windows, run it from Git Bash)

## Install

```bash
unzip <the downloaded zip> -d positioning-arena-package
cd positioning-arena-package
bash install.sh
```

The installer:
1. Copies the `positioning-arena` skill into `~/.claude/skills/`
2. Installs the 17 agent types into `~/.claude/agents/<name>/AGENT.md`
3. Creates the wild-cards runtime directory `~/.claude/positioning-arena/wild-cards/active/`

Then **restart Claude Code** so the skill and agents register.

## First run

Invoke the skill in Claude Code, e.g.:

```
Run the positioning-arena skill for <Product>.
Context: <one paragraph — what it is, who it's for, the offer>.
outRoot: <absolute path where run output should go — e.g. your Obsidian vault or ~/positioning-arena-runs>
```

Always pass `outRoot` explicitly. If omitted, output defaults to `~/positioning-arena-runs`.

## Verify

Run the checks in `TEST.md` (static preflight first, then the live smoke test).
