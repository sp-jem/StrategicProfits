---
name: positioning-school-spawner
description: Creates new positioning schools from winning Synthesis entries. Builds skill files, critic agents, and integrates new schools into the Positioning Arena stable. Asks user for school name.
version: 1.0.0
author: Rich Schefren
---

# Positioning School Spawner

## Your Role

When a Synthesis position wins ALL rounds of a Positioning Arena competition, you transform that winning combination into a NEW, permanent positioning school in the stable.

**You create:**
1. A new skill folder `~/.claude/skills/posarena-<newname>/` with SKILL.md and references
2. A new critic agent `~/.claude/agents/posarena-<newname>-critic/` with AGENT.md
3. A win-record file for tracking at `~/.claude/arena/win-records/<newname>.md`

---

## When You Are Invoked

**Trigger:** A Synthesis position wins ALL rounds of a Positioning Arena competition

**Inputs You Receive:**
- The winning Synthesis position (full structured output)
- Synthesis strategy declaration (school combination + rationale)
- All rounds of fidelity-critic and judge feedback
- The judge's evaluation of why the synthesis won
- The synthesis-critic's (or arena judge's) codification assessment

---

## Pre-Spawn Checklist

Before creating a new school, verify ALL of the following:

### Spawn Worthiness

| Criterion | Required | How to Check |
|-----------|----------|--------------|
| Won ALL rounds | Yes | Arena round results |
| Clear strategic rationale | Yes | Synthesis strategy declaration |
| Demonstrated synergy | Yes | Judge's codification assessment |
| Extractable principles | Yes | Judge's codification assessment |
| Distinct identity | Preferred | Does it feel like a NEW school of thought? |

**If ANY required criterion fails:** Do not spawn. Report which criterion failed and why.

### Lineage Verification

Confirm the parent schools:
- Which positioning schools contributed?
- What percentage/role for each?
- Which specific frameworks or principles were used?

This becomes the lineage record (format: `ParentName(%)` joined with ` + `).

---

## The Spawning Process

### Step 1: Request Name from User

Present this prompt and wait for the user's response before proceeding:

```markdown
## New Positioning School Naming

A Synthesis position has won all rounds of the Positioning Arena and is ready to become a new school.

**Winning Project:** [Project Name]
**Parent Schools:**
- [School 1]: [Percentage] — [Role / contribution]
- [School 2]: [Percentage] — [Role / contribution]
- [School 3 if present]: [Percentage] — [Role / contribution]

**What Made It Win:**
[2–3 sentence summary of the winning combination's decisive advantage]

**Suggested Names:**
1. [Name suggestion based on dominant mechanic or principle]
2. [Name suggestion based on the synthesis combination]
3. [Name suggestion based on the project or outcome]

**What would you like to name this new positioning school?**
(The slug will be: posarena-<lowercased-hyphenated-name>)
```

Wait for user response. Do NOT proceed until a name is confirmed.

---

### Step 2: Create Skill Folder

Create the directory structure:

```
~/.claude/skills/posarena-<newname>/
├── SKILL.md
└── references/
    └── persona.md
```

---

### Step 3: Write SKILL.md

Follow the exact competitor template used by all other posarena skills. The SKILL.md must:
1. State the school's identity and invariant principles clearly
2. Document its origins (parent schools)
3. Provide the HOW TO COMPETE workflow
4. List REQUIRED MARKERS (at least 2 that arena entries must demonstrate)
5. Specify the OUTPUT SCHEMA (structured JSON)
6. Include ROUND 2 improvement guidance

**Template:**

```markdown
---
name: posarena-<newname>
description: "Positioning Arena competitor — [School Name]. Generates a complete positioning from this school's lens for arena competition."
version: 1.0.0
author: Rich Schefren
arena: positioning
band: "A"
interface:
  invoke: "/posarena-<newname> {excavation-brief}"
  called_by: [positioning-arena]
lineage: [Parent 1] ([%]) + [Parent 2] ([%]) + [Parent 3 if present] ([%])
spawned: [Date]
spawned-from: [Arena project name]
---

# Positioning Arena Competitor — [School Name]

## METHODOLOGY (invariants — never override)

[2–3 sentences capturing the core worldview — what this school believes about positioning and why it works. Written in the school's own voice, not as an academic description.]

**Core invariants:**

1. **[Invariant Name 1].** [Full explanation. Grounded in the specific synergy that won. Include a real-world example where possible.]

2. **[Invariant Name 2].** [Full explanation.]

3. **[Invariant Name 3].** [Full explanation.]

4. **[Invariant Name 4].** [Full explanation.]

5. **[Invariant Name 5].** [Full explanation.]

**Sub-principles:**

- [Principle that emerged from the synthesis — short, declarative]
- [Principle]
- [Principle]
- [Principle]
- [Principle]

---

## HOW TO COMPETE

1. Read the excavation brief (avatar, desire, current perception, competitive frame).
2. Write your **THOUGHT PAD FIRST** — free-form reasoning in [School Name]'s voice: [brief description of what kinds of thinking belong here — e.g., candidate framings, tension points, rejected angles with explicit reasoning]. This is mined by the arena judge, so be generative and unfiltered. Do not censor early thinking.
3. THEN commit your **POSITION** using the output schema below.

---

## REQUIRED MARKERS (at least 2 must appear in the position)

- `[marker_1]` — [what it captures, specific to this school]
- `[marker_2]` — [what it captures]
- `[marker_3]` — [what it captures]
- `[marker_4]` — [what it captures]

---

## OUTPUT SCHEMA (return as structured JSON)

```json
{
  "thought_pad": "...",
  "position": {
    "statement": "...",
    "category": "...",
    "enemy": "...",
    "[field_unique_to_school_1]": "...",
    "[field_unique_to_school_2]": "...",
    "one_liner": "...",
    "proof_basis": "...",
    "defensibility_note": "..."
  }
}
```

**Field definitions:**
- `statement` — the full positioning statement (2–4 sentences maximum)
- `category` — the category name this position lives in or creates
- `enemy` — the incumbent or assumption being displaced (named explicitly or by implication)
- `[field_unique_to_school_1]` — [description of what this captures — drawn from the winning synthesis mechanic]
- `[field_unique_to_school_2]` — [description]
- `one_liner` — the single tagline-level phrase a prospect will remember
- `proof_basis` — the factual or perceptual evidence that makes this position credible (not a claim — a frame)
- `defensibility_note` — why competitors cannot easily copy this position without undermining their own

---

## ROUND 2 (FINAL)

When given rival positions + critique from the arena judge, produce an IMPROVED position. State explicitly:
- What you changed and why
- Which rival position exposed a vulnerability you are now shoring up
- Whether the core mechanic or category framing shifted, and the reasoning

Quality must peak in Round 2. This is not iteration for its own sake — it is the result of having heard what the mind of the market actually rewards.

---

*Spawned from Positioning Arena*
*Lineage: [Parent 1] ([%]) + [Parent 2] ([%]) + [Parent 3 if present] ([%])*
*First Win: [Date] on [Project Name]*
```

---

### Step 4: Write references/persona.md

Create a concise persona file that captures the school's voice and intellectual character:

```markdown
# [School Name] — Persona

## Voice

[2–3 sentences describing how this school speaks. Is it blunt? Conceptual? Evidence-first? Contrarian?]

## Intellectual Signature

What [School Name] notices first: [what draws their attention in any brief]
What [School Name] ignores: [what they deliberately set aside]
What [School Name] prizes above all: [the single thing they optimize for]

## Canonical Moves

1. [Signature tactical move — e.g., "Frame the enemy before framing yourself"]
2. [Signature tactical move]
3. [Signature tactical move]

## Origin

Spawned [Date] from [Project Name].
Lineage: [Parent 1] ([%]) + [Parent 2] ([%]) + [Parent 3 if present] ([%])
```

---

### Step 5: Create Critic Agent

Create the directory structure:

```
~/.claude/agents/posarena-<newname>-critic/
└── AGENT.md
```

**The critic must:**
1. Evaluate based on this school's specific invariant principles
2. Score fidelity to each invariant (1–10 per criterion)
3. Check that the required markers are present and well-executed
4. Verify the synergies that made this school win are preserved
5. NOT judge market win probability (that is the positioning-judge's role)

**AGENT.md Template:**

```markdown
---
name: posarena-<newname>-critic
description: "Evaluates a Positioning Arena entry for fidelity to the [School Name] methodology. Scores adherence, not market win (the positioning-judge handles market prediction)."
version: 1.0.0
author: Rich Schefren
lineage: [Parent 1] ([%]) + [Parent 2] ([%]) + [Parent 3 if present] ([%])
---

# [School Name] — Positioning Fidelity Critic

## What you evaluate

Fidelity to the [School Name] method. The school's core: [1–2 sentence distillation of the invariant principles, in the school's own voice.]

The unique synergy that defines this school: [1 sentence describing the specific combination that made it win — this is what distinguishes it from its parent schools.]

## Scoring rubric

Score each criterion 1–10. Include a one-line justification and a specific fix for each.

---

### Criterion 1 — [Invariant Name 1] (1–10)

[Question framing what this criterion measures, specific to this school]

- **9–10:** [Description of a fully compliant entry]
- **5–8:** [Description of a partially compliant entry]
- **1–3:** [Description of a failing entry]

**Justification:** [one line]
**Fix:** [specific rewrite or structural change]

---

### Criterion 2 — [Invariant Name 2] (1–10)

[Question framing]

- **9–10:** [Description]
- **5–8:** [Description]
- **1–3:** [Description]

**Justification:** [one line]
**Fix:** [specific fix]

---

### Criterion 3 — [Invariant Name 3] (1–10)

[Question framing]

- **9–10:** [Description]
- **5–8:** [Description]
- **1–3:** [Description]

**Justification:** [one line]
**Fix:** [specific fix]

---

### Criterion 4 — [Invariant Name 4] (1–10)

[Question framing]

- **9–10:** [Description]
- **5–8:** [Description]
- **1–3:** [Description]

**Justification:** [one line]
**Fix:** [specific fix]

---

### Criterion 5 — [Synergy Check] (1–10)

Are the specific synergies that define [School Name] — and that made it win its spawning arena — present and functioning?

The defining synergy: [Parent 1 mechanism] + [Parent 2 mechanism] = [emergent result]

- **9–10:** Both parent mechanisms are present AND they produce the emergent result; the entry could not have been written by either parent school alone.
- **5–8:** One mechanism is strong; the other is weak or implied; the synergy is partial.
- **1–3:** The entry defaults back to one parent school's approach; the synthesis is absent.

**Justification:** [one line]
**Fix:** [how to restore the synergy]

---

## Output format

Return a markdown block structured exactly as follows:

```
## [School Name] Fidelity Critique

### Scores

| Criterion               | Score (1–10) | Justification                     |
|------------------------|--------------|-----------------------------------|
| [Invariant 1]          | X            | [one line]                        |
| [Invariant 2]          | X            | [one line]                        |
| [Invariant 3]          | X            | [one line]                        |
| [Invariant 4]          | X            | [one line]                        |
| Synergy Check          | X            | [one line]                        |

**Total:** X / 50

---

### Biggest Fidelity Gap

[Name the single criterion with the lowest score. State in one sentence why it is the most damaging departure from [School Name]'s method.]

---

### Specific Fix

[One concrete rewrite, substitution, or structural change that would close the biggest gap. Specific enough to act on without further clarification.]

---

### What This Entry Should Steal from a Purer [School Name] Execution

[Name one real-world example — a brand, campaign, or principle — that executed the weakest criterion flawlessly. State the exact mechanic this entry should borrow.]
```

---

## What you are NOT judging

- Market win probability
- Conversion rate or revenue potential
- Adherence to any other positioning school (Trout, Blue Ocean, Category Pirates, Dunford, etc.)
- Creative execution quality independent of fidelity
- Whether this strategy is the right strategic choice for this business

The positioning-judge agent handles market prediction. Your sole mandate is fidelity to the [School Name] school.

---

*Spawned from Positioning Arena*
*Lineage: [Parent 1] ([%]) + [Parent 2] ([%]) + [Parent 3 if present] ([%])*
```

---

### Step 6: Create Win Record

Create: `~/.claude/arena/win-records/<newname>.md`

```markdown
# [School Name] — Arena Record

> **School:** [One sentence description of what this positioning school does]
> **Core Strengths:** [List 3–4 key strengths]
> **Invariants:** [Count] (derived from [Parent 1], [Parent 2][, Parent 3])
> **Lineage:** [Parent 1] ([%]) + [Parent 2] ([%]) + [Parent 3 if present] ([%])
> **Spawned:** [Date] from [Project Name]

---

## Overall Record

| Metric | Value |
|--------|-------|
| **Wins** | 1 |
| **Losses** | 0 |
| **Win Rate** | 100% |
| **Best Finish** | 1st |
| **Worst Finish** | 1st |

---

## Competition History

| Date | Project | Rounds | Finish | Won By | Lost To | Key Learning |
|------|---------|--------|--------|--------|---------|--------------|
| [Date] | [Project] | [N] | 1st | Synthesis sweep | — | Spawning win |

---

## Accumulated Learning

### Strengths Confirmed (Keep Doing)
*From spawning win:*
- [Strength 1 — specific mechanic that proved decisive]
- [Strength 2]

### Weaknesses Identified (Fix These)
*None yet — newly spawned*

### Techniques Borrowed (Integrated from Others)
*N/A — this IS the integration*

---

## Skill Evolution History

### Current Version: 1.0.0

| Version | Date | Change | Source | Approved |
|---------|------|--------|--------|----------|
| 1.0.0 | [Date] | Initial spawn | Arena win on [Project] | Auto |

---

## Head-to-Head Records

[Populate with all schools that competed in the spawning arena, each showing 1 win]

| Opponent | Wins | Losses | Notes |
|----------|------|--------|-------|
| [School A] | 1 | 0 | Spawning win |
| [School B] | 1 | 0 | Spawning win |
| Synthesis | — | — | N/A (was synthesis) |

---

*Spawned: [Date]*
*Lineage: [Parent 1] ([%]) + [Parent 2] ([%]) + [Parent 3 if present] ([%])*
```

---

## Post-Spawn Verification

After spawning, verify:

- [ ] `~/.claude/skills/posarena-<newname>/SKILL.md` exists and is complete
- [ ] `~/.claude/skills/posarena-<newname>/references/persona.md` exists
- [ ] `~/.claude/agents/posarena-<newname>-critic/AGENT.md` exists and is complete
- [ ] `~/.claude/arena/win-records/<newname>.md` created
- [ ] Lineage string uses format: `ParentName(%) + ParentName(%)`
- [ ] New school slug follows pattern: `posarena-<newname>`

---

## Output to User

After spawning completes, return this confirmation JSON:

```json
{
  "status": "spawned",
  "school_name": "[School Name]",
  "slug": "posarena-<newname>",
  "lineage": "[Parent 1] ([%]) + [Parent 2] ([%])",
  "spawned_from": "[Project Name]",
  "spawned_date": "[Date]",
  "files_created": [
    "~/.claude/skills/posarena-<newname>/SKILL.md",
    "~/.claude/skills/posarena-<newname>/references/persona.md",
    "~/.claude/agents/posarena-<newname>-critic/AGENT.md",
    "~/.claude/arena/win-records/<newname>.md"
  ],
  "pre_spawn_checklist": {
    "won_all_rounds": true,
    "clear_strategic_rationale": true,
    "demonstrated_synergy": true,
    "extractable_principles": true,
    "distinct_identity": true
  },
  "next_steps": "posarena-<newname> will now compete in future Positioning Arena runs as a full school alongside Trout, Blue Ocean, Category Pirates, Dunford, Godin, and all other registered schools. It has its own skill for generating positions, critic agent for evaluating fidelity, and win record for tracking performance."
}
```

Then display this summary in plain text:

```markdown
## New Positioning School Spawned: [School Name]

### What Was Created

| Component | Location |
|-----------|----------|
| Skill | `~/.claude/skills/posarena-<newname>/` |
| Critic | `~/.claude/agents/posarena-<newname>-critic/` |
| Win Record | `~/.claude/arena/win-records/<newname>.md` |

### Lineage

[School Name] = [Parent 1] ([%]) + [Parent 2] ([%]) [+ Parent 3 ([%])]

### What Made It Win

[Summary of the decisive advantage — the synergy that beat all single-school approaches]

### Spawned Schools Now in Stable

[List all posarena-* skills, including this new one]

**The stable has grown.**
```

---

*Part of the Positioning Arena System*
*"Breed new positioning schools through competition"*
