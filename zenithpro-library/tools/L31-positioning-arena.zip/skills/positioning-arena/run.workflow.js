export const meta = {
  name: 'positioning-arena-run',
  description: 'Run a Positioning Arena competition: excavation, 2 rounds of school competition, critique, audience eval, judge, synthesis, Vault — emitting live dashboard telemetry',
  phases: [
    { title: 'Excavation' },
    { title: 'Round 1' },
    { title: 'Critique' },
    { title: 'Round 2' },
    { title: 'Audience Eval' },
    { title: 'Judge' },
    { title: 'Synthesis' },
    { title: 'Vault' },
    { title: 'Output' },
  ],
}

// ---------- config ----------
// The Workflow tool delivers `args` as a JSON STRING — parse defensively.
const A = (typeof args === 'string')
  ? (() => { try { return JSON.parse(args) } catch (e) { return {} } })()
  : (args || {})
const SK = A.skillsRoot || '~/.claude/skills'
const ARENA = `${SK}/positioning-arena`
const SCHOOLS_DIR = `${ARENA}/references/schools`   // posarena-* schools (consolidated under router)
const COMP = `${ARENA}/references/components`        // positioning-vault / audience-eval / harvester / wildcard
const OUT_ROOT = A.outRoot || '~/positioning-arena-runs'
const runId = A.runId || 'run'
const runName = A.runName || 'Positioning Arena Run'
const productName = A.productName || A.entity || 'Subject'
const runDir = `${OUT_ROOT}/runs/${runId}`
const brief = A.brief || ''
const briefPath = A.briefPath || ''
const only = A.only || null // optional array of agent ids for a reduced smoke-test roster

// Full roster (ids MUST match dashboard README + roster.json)
const ROSTER = [
  // Band A
  { id:'trout', band:'A', school:'Al Ries & Jack Trout', skill:'posarena-trout', kind:'school' },
  { id:'dunford', band:'A', school:'April Dunford', skill:'posarena-dunford', kind:'school' },
  { id:'marion', band:'A', school:'Marty Marion', skill:'posarena-marion', kind:'school' },
  { id:'dell', band:'A', school:'Brendan Dell', skill:'posarena-dell', kind:'school' },
  { id:'raskin', band:'A', school:'Andy Raskin', skill:'posarena-raskin', kind:'school' },
  { id:'brunson', band:'A', school:'Russell Brunson', skill:'posarena-brunson', kind:'school' },
  { id:'moore', band:'A', school:'Geoffrey Moore', skill:'posarena-moore', kind:'school' },
  { id:'yoon', band:'A', school:'Eddie Yoon', skill:'posarena-yoon', kind:'school' },
  { id:'godin', band:'A', school:'Seth Godin', skill:'posarena-godin', kind:'school' },
  { id:'klaff', band:'A', school:'Oren Klaff', skill:'posarena-klaff', kind:'school' },
  // Band B
  { id:'play-bigger', band:'B', school:'Play Bigger', skill:'posarena-play-bigger', kind:'school' },
  { id:'category-pirates', band:'B', school:'Category Pirates (22 Laws)', skill:'posarena-category-pirates', kind:'school' },
  { id:'blue-ocean', band:'B', school:'Blue Ocean Strategy', skill:'posarena-blue-ocean', kind:'school' },
  // Band C — lenses (call existing deep-thinker skills; no per-lens critic)
  { id:'lens-perception', band:'C', school:'Gordon — Category Perception', skill:'gordon-field-intelligence', kind:'lens', layer:1 },
  { id:'lens-desire', band:'C', school:'Girard — Mimetic Desire', skill:'girard-field-intelligence', kind:'lens', layer:2 },
  { id:'lens-identity', band:'C', school:'Tajfel — Social Identity', skill:'tajfel-social-identity-activator', kind:'lens', layer:3 },
  { id:'lens-status', band:'C', school:'Veblen — Status Signals', skill:'veblen-status-intelligence', kind:'lens', layer:4 },
  { id:'lens-frame', band:'C', school:'Lakoff — Metaphor Frame', skill:'lakoff-metaphor-engineer', kind:'lens', layer:5 },
  { id:'lens-belief', band:'C', school:'Kelman — Internalization', skill:'kelman-internalization-architect', kind:'lens', layer:6 },
  { id:'lens-defense', band:'C', school:'Sherif — Anchor & Contrast', skill:'sherif-anchor-mapper', kind:'lens', layer:7 },
]
const FIELD = ROSTER.filter((r) => !only || only.includes(r.id))
const SCHOOLS = FIELD.filter((r) => r.kind === 'school') // get fidelity critics

// ---------- structured schemas ----------
const ENTRY_SCHEMA = {
  type:'object', additionalProperties:false,
  required:['agent_id','band','school','thought_pad','position'],
  properties:{
    agent_id:{type:'string'}, band:{type:'string'}, school:{type:'string'},
    thought_pad:{type:'string'},
    position:{ type:'object', additionalProperties:false,
      required:['statement','category','enemy','compete_or_create','one_liner','proof_basis','defensibility_note'],
      properties:{ statement:{type:'string'}, category:{type:'string'}, enemy:{type:'string'},
        compete_or_create:{type:'string', enum:['compete','create']}, one_liner:{type:'string'},
        proof_basis:{type:'string'}, defensibility_note:{type:'string'} } },
  },
}
const SCORE_SCHEMA = { type:'object', additionalProperties:false, required:['agent_id','score','summary'],
  properties:{ agent_id:{type:'string'}, score:{type:'number'}, summary:{type:'string'}, biggest_gap:{type:'string'}, fix:{type:'string'} } }
const JUDG_SCHEMA = { type:'object', additionalProperties:false, required:['winner','rankings'],
  properties:{ winner:{type:'string'}, rankings:{type:'array', items:{type:'object', additionalProperties:false,
    required:['rank','agent_id','score'], properties:{ rank:{type:'number'}, agent_id:{type:'string'}, score:{type:'number'}, predicted_dominance_pct:{type:'number'}, note:{type:'string'} }}},
    decisive_advantage:{type:'string'} } }
const SYNTH_SCHEMA = { type:'object', additionalProperties:false,
  required:['statement','category','enemy','compete_or_create','one_liner','proof_basis','defensibility_note','combination_rationale'],
  properties:{ statement:{type:'string'}, category:{type:'string'}, enemy:{type:'string'},
    compete_or_create:{type:'string',enum:['compete','create']}, one_liner:{type:'string'}, proof_basis:{type:'string'},
    defensibility_note:{type:'string'}, combination_rationale:{type:'string'} } }
const VAULT_SCHEMA = { type:'object', additionalProperties:false,
  required:['final_position','altitude_reached','rejected_position','rejected_why','reasoning'],
  properties:{ final_position:{type:'string'}, altitude_reached:{type:'string'}, one_liner:{type:'string'},
    rejected_position:{type:'string'}, rejected_why:{type:'string'}, reasoning:{type:'string'} } }
const OK = { type:'object', additionalProperties:false, required:['ok'], properties:{ ok:{type:'boolean'}, files:{type:'array',items:{type:'string'}}, notes:{type:'string'} } }

// ---------- live status object (held in memory; persisted by writer agents) ----------
let clock = 0
const status = {
  run_id: runId, run_name: runName, product_name: productName,
  phase: 'excavation', agents: FIELD.map((r) => ({ id:r.id, status:'idle', token_pct:0 })),
  scores: {}, events: [], vault: null,
}
function setAgent(id, st, pct){ const a = status.agents.find((x)=>x.id===id); if(a){ a.status=st; if(pct!=null) a.token_pct=pct; } }
function event(type, message, band){ status.events.push({ time:String(clock++), type, source:'System', message, band }); }
async function persist(phaseLabel){
  await agent(
    `Use the Write tool to write the following JSON VERBATIM (no code fences, no commentary, exactly these bytes) to the file ${runDir}/status.json :\n\n${JSON.stringify(status, null, 2)}\n\nReturn {"ok":true,"files":["${runDir}/status.json"]}.`,
    { label:`status:${phaseLabel}`, phase: phaseLabel, model:'haiku', schema: OK }
  )
}
// ---------- audit-trail persistence: write a doc VERBATIM (built in-script, not paraphrased) ----------
async function saveDoc(file, content, model){
  await agent(
    `Use the Write tool to write the text between the markers VERBATIM to ${runDir}/${file} (create parent dirs if needed; do NOT add code fences or any commentary; reproduce it exactly byte-for-byte). Return {"ok":true,"files":["${runDir}/${file}"]}.\n\n===== BEGIN CONTENT =====\n${content}\n===== END CONTENT =====`,
    { label:`save:${file}`, phase: status.phase, model: model || 'sonnet', schema: OK }
  )
}
function critiquesDoc(arr){
  return `# Critiques — Round 1\n\n` + arr.map((c)=>`## ${c.agent_id} — score ${c.score}\n\n**Summary:** ${c.summary}\n\n**Biggest gap:** ${c.biggest_gap||''}\n\n**Fix:** ${c.fix||''}`).join('\n\n---\n\n')
}
function judgeDoc(j){
  const rows = (j.rankings||[]).map((rk)=>`| ${rk.rank} | ${rk.agent_id} | ${rk.score} | ${rk.predicted_dominance_pct||''} | ${String(rk.note||'').replace(/\|/g,'/').replace(/\n/g,' ')} |`).join('\n')
  return `# Judge — Full Per-Entry Ranking\n\n**Winner:** ${j.winner}\n\n**Decisive advantage:** ${j.decisive_advantage||''}\n\n| Rank | Agent | Score | Dmnc% | Note |\n|---|---|---|---|---|\n${rows}`
}

// HARD CONSTRAINTS: subject-specific bans live in the brief; agents MUST obey them over school instinct.
// This is the fix for the 2026-06-01 failure where 20 agents reintroduced a banned framing ("Zero-Memory
// Business" / AI-memory) because the brief's prohibition wasn't enforced. See memory feedback_imprint_not_memory.
const CONSTRAINTS = `\n\nHARD CONSTRAINTS (non-negotiable): Obey every "FORBIDDEN FRAMING", "CONSTRAINT", "do NOT", or "never" rule stated in the brief — they override your school's natural instinct. If the brief bans a frame (e.g. a memory/recall frame), you may NOT reintroduce it under any synonym. When in doubt, ask which frame the brief permits rather than guessing.`
const BRIEF_BLOCK = () => (brief
  ? `EXCAVATION BRIEF:\n${brief}`
  : `Read the excavation brief at: ${briefPath || runDir + '/brief.md'} (use the Read tool).`) + CONSTRAINTS

// ================= PHASE 0/1: EXCAVATION =================
phase('Excavation')
// self-heal: mirror dashboards into the run root so one `python3 -m http.server` serves dashboards AND run data
await agent(
  `Use Bash to run (expand any leading ~ in these paths to the absolute home directory first): mkdir -p "${OUT_ROOT}/dashboard" && cp -f "${ARENA}/dashboard/live.html" "${ARENA}/dashboard/replay.html" "${ARENA}/dashboard/README.md" "${OUT_ROOT}/dashboard/" . Return {"ok":true}.`,
  { label:'dashboard-sync', phase:'Excavation', model:'haiku', schema: OK }
)
status.phase = 'excavation'; event('phase_change', `Excavating ${productName}: avatar, desire, current perception, competitive frame...`)
await persist('Excavation')
if (!brief) {
  await agent(
    `You are the excavation front-end for a Positioning Arena run on "${productName}".
Produce a tight POSITIONING BRIEF and Write it to ${runDir}/brief.md (use the Write tool).
Apply the spirit of Rich Schefren's excavation pipeline (motivation-spectrum-analyzer, zp-excavation, zp-avatar, zp-desire-mapper). Read those SKILL.md files under ${ARENA}/references/pipeline/ if helpful, but keep this FAST — do not run full web research.
The brief must contain: (1) the subject/offer, (2) 2-3 avatars w/ core desire + shadow fear, (3) the L1-L4 desire hierarchy, (4) current market perception, (5) competitive alternatives + the frame buyers use, (6) the transformation. 500-900 words.
Subject context: ${A.context ? A.context : '(none provided — infer reasonable specifics and label assumptions)'}
Return {"ok":true,"files":["${runDir}/brief.md"]}.`,
    { label:'excavation', phase:'Excavation', model:'sonnet', schema: OK }
  )
}

// ================= PHASE 2: ROUND 1 =================
phase('Round 1')
status.phase = 'round_1'; FIELD.forEach((r)=>setAgent(r.id,'thinking',10)); event('phase_change', 'All competitors generating Round 1 positions...')
await persist('Round 1')

function competitorPrompt(r, round, rivalDigest, critique){
  const methodRead = r.kind === 'school'
    ? `Read your method: ${SCHOOLS_DIR}/${r.skill}/SKILL.md and ${SCHOOLS_DIR}/${r.skill}/references/persona.md (use the Read tool). Fully embody ${r.school}.`
    : `Apply the ${r.school} lens. Read ${ARENA}/references/lenses/${r.skill}/SKILL.md for the lens's core question/method, then produce a positioning ANGLE from that lens. Do NOT run a full field-intelligence research pass — synthesize the angle directly.`
  const r2 = round === 2
    ? `\nThis is ROUND 2 (FINAL) — quality must peak. You can see rival positions and your critique below. Produce an IMPROVED position; in your thought_pad note what you changed and why.\nRIVAL DIGEST:\n${rivalDigest}\nYOUR CRITIQUE:\n${critique || '(none)'}\n`
    : ''
  return `You are competing in the Positioning Arena as ${r.school} (agent id "${r.id}", band ${r.band}).
${methodRead}
${BRIEF_BLOCK()}
${r2}
PROCESS:
1. As you reason, APPEND your thinking to ${runDir}/agents/${r.id}/thoughts.md (use Bash: mkdir -p the dir, then append). Write 2-4 separate appends in ${r.school}'s voice as you develop the angle — this thought pad streams live on the demo dashboard, so be generative and vivid.
2. THEN commit your final position, and SAVE the full draft as readable markdown to ${runDir}/agents/${r.id}/round${round}.md (use the Write tool) — include one-liner, statement, category, enemy, compete_or_create, proof_basis, and defensibility_note. This saved draft is the permanent audit trail for round ${round}; do NOT skip it.
Return the entry as structured JSON: {agent_id:"${r.id}", band:"${r.band}", school:"${r.school}", thought_pad:"<your full reasoning>", position:{statement, category, enemy, compete_or_create:"compete"|"create", one_liner, proof_basis, defensibility_note}}.`
}

const round1 = await parallel(
  FIELD.map((r) => () => agent(competitorPrompt(r, 1), { label:`r1:${r.id}`, phase:'Round 1', model:'sonnet', schema: ENTRY_SCHEMA })
    .then((e)=>{ setAgent(r.id,'complete',100); return e; }))
)
const r1 = round1.filter(Boolean)
FIELD.forEach((r)=>{ if(r1.find((e)=>e.agent_id===r.id)) setAgent(r.id,'complete',100); })
event('phase_change', `Round 1 complete: ${r1.length} positions submitted.`)
await persist('Round 1')

// ================= PHASE 3: CRITIQUE =================
phase('Critique')
status.phase = 'critique'; SCHOOLS.forEach((r)=>setAgent(r.id,'critique')); event('phase_change', 'Fidelity critics + truth/defensibility stress test running...')
await persist('Critique')

const critiques = await parallel(
  r1.map((e) => () => {
    const r = FIELD.find((x)=>x.id===e.agent_id)
    const isSchool = r && r.kind === 'school'
    const prompt = `Evaluate this Positioning Arena entry.\nENTRY (${e.school}):\n${JSON.stringify(e.position, null, 2)}\n\n` +
      (isSchool
        ? `Score it for FIDELITY to ${e.school}'s methodology AND for truth/defensibility (is the claim true? can a competitor copy it tomorrow?).`
        : `Score this ${e.school} lens angle for insight value + truth/defensibility.`) +
      `\nReturn {agent_id:"${e.agent_id}", score:<0-100>, summary, biggest_gap, fix}.`
    const opts = { label:`crit:${e.agent_id}`, phase:'Critique', schema: SCORE_SCHEMA, model:'sonnet' }
    if (isSchool) opts.agentType = `posarena-${e.agent_id}-critic`
    return agent(prompt, opts)
  })
)
const crit = critiques.filter(Boolean)
crit.forEach((c)=>{ status.scores[c.agent_id] = Math.round(c.score); setAgent(c.agent_id,'complete'); })
event('phase_change', 'Critique complete. Scores posted.')
await persist('Critique')
await saveDoc('critiques.md', critiquesDoc(crit), 'haiku')

// ================= PHASE 4: ROUND 2 (FINAL) =================
phase('Round 2')
status.phase = 'round_2'; FIELD.forEach((r)=>setAgent(r.id,'thinking',20)); event('phase_change', 'Round 2 (FINAL): competitors revise against rivals + critique. Quality peaks here.')
await persist('Round 2')

const rivalDigest = r1.map((e)=>`- ${e.school}: ${e.position.one_liner}`).join('\n')
const round2 = await parallel(
  FIELD.map((r) => () => {
    const myCrit = crit.find((c)=>c.agent_id===r.id)
    const critText = myCrit ? `${myCrit.summary} | gap: ${myCrit.biggest_gap||''} | fix: ${myCrit.fix||''}` : ''
    return agent(competitorPrompt(r, 2, rivalDigest, critText), { label:`r2:${r.id}`, phase:'Round 2', model:'sonnet', schema: ENTRY_SCHEMA })
      .then((e)=>{ setAgent(r.id,'complete',100); return e; })
  })
)
const r2 = round2.filter(Boolean)
event('phase_change', `Round 2 complete: ${r2.length} final positions.`)
await persist('Round 2')

// ================= PHASE 5: AUDIENCE EVAL =================
phase('Audience Eval')
status.phase = 'audience_eval'; event('phase_change', 'The excavated avatar reacts to each final position (sim-audience).')
await persist('Audience Eval')
const audience = await agent(
  `You are the positioning-audience-eval step. Read ${COMP}/positioning-audience-eval/SKILL.md and apply the spirit of sim-audience / sim-audience-blind.
${BRIEF_BLOCK()}
Have the EXCAVATED AVATAR react to each of these final positions. For each: gut belief reaction, desire-pull (1-10), the objection it triggers, and would-I-repeat-to-a-peer (yes/no).
POSITIONS:\n${r2.map((e)=>`[${e.agent_id}] ${e.school}: ${e.position.one_liner} — ${e.position.statement}`).join('\n')}
First Write your full reactions table + the per-position JSON lines to ${runDir}/audience-eval.md (use the Write tool) — this is the permanent audience-eval record. THEN return the same: a markdown table of reactions AND a JSON line per position. This is the audience signal, SEPARATE from the judge.`,
  { label:'audience', phase:'Audience Eval', model:'sonnet' }
)
await saveDoc('audience-eval.md', typeof audience === 'string' ? audience : JSON.stringify(audience, null, 2), 'haiku')

// ================= PHASE 6: JUDGE =================
phase('Judge')
status.phase = 'judge'; event('phase_change', 'positioning-judge: blind read, atomic-unit evaluation, ranking.')
await persist('Judge')
const judgment = await agent(
  `Judge this Positioning Arena. Predict which COMPLETE position would WIN in the real market (perception ownership, desire-pull, defensibility, believability, memorability, category leverage). Evaluate each position as an ATOMIC UNIT. Blind-read first.
FINAL POSITIONS:\n${JSON.stringify(r2.map((e)=>({agent_id:e.agent_id, school:e.school, position:e.position})), null, 2)}
AUDIENCE SIGNAL:\n${audience}
Return {winner:<school name>, rankings:[{rank,agent_id,score(0-100),predicted_dominance_pct,note}], decisive_advantage}.`,
  { label:'judge', phase:'Judge', agentType:'positioning-judge', model:'sonnet', schema: JUDG_SCHEMA }
)
;(judgment.rankings||[]).forEach((rk)=>{ status.scores[rk.agent_id] = Math.round(rk.score); })
const top = (judgment.rankings||[]).slice(0,3).map((rk)=>rk.agent_id)
top.forEach((id)=>setAgent(id,'finalist'))
event('phase_change', `Judge winner: ${judgment.winner}.`)
await persist('Judge')
await saveDoc('judge.md', judgeDoc(judgment), 'haiku')

// ================= PHASE 7: SYNTHESIS =================
phase('Synthesis')
status.phase = 'synthesis'; event('phase_change', 'positioning-synthesist: converging the strongest moves into one position.')
await persist('Synthesis')
const synth = await agent(
  `Converge the strongest MOVES (not whole entries) across all positions into ONE position greater than any single school — and that is TRUE and DEFENSIBLE (reject anything false or me-too).
FINAL POSITIONS:\n${JSON.stringify(r2.map((e)=>({agent_id:e.agent_id, school:e.school, position:e.position})), null, 2)}
JUDGE: winner ${judgment.winner}; decisive advantage: ${judgment.decisive_advantage||''}
Return {statement, category, enemy, compete_or_create, one_liner, proof_basis, defensibility_note, combination_rationale (name which school contributed which move)}.`,
  { label:'synthesis', phase:'Synthesis', agentType:'positioning-synthesist', model:'sonnet', schema: SYNTH_SCHEMA }
)

// ================= PHASE 8: VAULT =================
phase('Vault')
status.phase = 'vault'; event('phase_change', 'THE VAULT: escalating to the highest defensible altitude.')
await persist('Vault')
const vault = await agent(
  `Run the Vault escalation. Read ${COMP}/positioning-vault/SKILL.md. Take the synthesized position and push it UP the altitude ladder (feature -> benefit -> identity -> worldview -> movement) using the positioning-10x-critic adversary's logic. The SYSTEM decides compete-vs-create on truth + defensibility, but you MUST record the bigger position you rejected and why.
SYNTHESIZED POSITION:\n${JSON.stringify(synth, null, 2)}
Save your full vault write-up to ${runDir}/vault.md using the Write tool — write it INSIDE this run folder, NOT to the project root.
Return {final_position, altitude_reached, one_liner, rejected_position, rejected_why, reasoning}.`,
  { label:'vault', phase:'Vault', model:'sonnet', schema: VAULT_SCHEMA }
)
status.vault = {
  winner: judgment.winner, winner_school: judgment.winner,
  final_position: vault.final_position, reasoning: vault.reasoning,
  rejected_position: vault.rejected_position, rejected_why: vault.rejected_why,
}
status.phase = 'complete'; event('phase_change', 'VAULT sealed. Final position locked.')
await persist('Vault')

// ================= PHASE 9: OUTPUT =================
phase('Output')
const outputs = await parallel([
  // Positioning Operating System doc
  () => agent(
    `Write the POSITIONING OPERATING SYSTEM document to ${runDir}/Positioning-Operating-System.md (use Write).
Compose from: the Vault final position, the synthesis, the judge ranking, and the avatar brief. Sections: The Position (statement + one-liner), The Category (+ compete/create verdict), The Enemy, Proprietary Vocabulary (coin 2-3 terms — apply toffler-naming-engine thinking by reading ${ARENA}/references/lenses/toffler-naming-engine/SKILL.md), The Proof Stack, Awareness-Staged Messaging (unaware->most aware), The Copycat-Defense Protocol, and "The Bigger Position We Rejected" (from the Vault).
DATA:\nVAULT:\n${JSON.stringify(vault,null,2)}\nSYNTHESIS:\n${JSON.stringify(synth,null,2)}\nJUDGE:\n${JSON.stringify(judgment,null,2)}
Return {"ok":true,"files":["${runDir}/Positioning-Operating-System.md"]}.`,
    { label:'out:pos-os', phase:'Output', model:'sonnet', schema: OK }),
  // Scorecard
  () => agent(
    `Write a SCORECARD to ${runDir}/scorecard.md (use Write): a ranked table of every competitor (school, band, judge score, one-liner) + the judge's decisive advantage + the audience signal summary. Keep tables narrow (no horizontal scroll).
RANKINGS:\n${JSON.stringify(judgment.rankings,null,2)}\nENTRIES:\n${JSON.stringify(r2.map((e)=>({id:e.agent_id,school:e.school,one_liner:e.position.one_liner})),null,2)}
Return {"ok":true,"files":["${runDir}/scorecard.md"]}.`,
    { label:'out:scorecard', phase:'Output', model:'haiku', schema: OK }),
  // Thought-pad harvest
  () => agent(
    `Run the positioning-thoughtpad-harvester. Read ${COMP}/positioning-thoughtpad-harvester/SKILL.md. Read ALL files matching ${runDir}/agents/*/thoughts.md (use Bash/Read). Mine them for: swipe-worthy one-liners, raw articulations to keep, category names considered, strong angles the judge rejected, and cross-school patterns. Write the harvest to ${runDir}/thoughtpad-harvest.md (use Write).
Return {"ok":true,"files":["${runDir}/thoughtpad-harvest.md"]}.`,
    { label:'out:harvest', phase:'Output', model:'sonnet', schema: OK }),
  // Replay snapshot
  () => agent(
    `Write a REPLAY SNAPSHOT to ${OUT_ROOT}/snapshots/${runId}.json (use Write) following this exact shape: {run_id, product_name, timeline:[...]}.
Build a timeline (integer "time" seconds, increasing) with events of these types: competition_start, phase_change (Excavation/Round 1/Critique/Round 2/Audience Eval/Judge/Synthesis/VAULT with data.message), thought_appearing (agent_id, band, content, word_count) for each competitor's Round 2 one-liner+statement, critique_complete (agent_id, score, summary), audience_eval (agent_id, audience_score, audience_note), and a final winner_declared with {winner, winner_school, final_scores, vault:{winner,winner_school,final_position,reasoning,rejected_position,rejected_why}}.
DATA:\nENTRIES:\n${JSON.stringify(r2.map((e)=>({agent_id:e.agent_id,band:e.band,school:e.school,one_liner:e.position.one_liner,statement:e.position.statement})),null,2)}\nSCORES:\n${JSON.stringify(status.scores,null,2)}\nVAULT:\n${JSON.stringify(status.vault,null,2)}
Return {"ok":true,"files":["${OUT_ROOT}/snapshots/${runId}.json"]}.`,
    { label:'out:snapshot', phase:'Output', model:'sonnet', schema: OK }),
])

// DETERMINISTIC GUARANTEE: the snapshot-builder agent sometimes OMITS the winner_declared
// event, which dead-stops the replay with no finale. Append it deterministically (node, not LLM)
// from in-script data so the crescendo always fires.
const winnerEvent = {
  event: 'winner_declared', phase: 'VAULT',
  winner: judgment.winner, winner_school: judgment.winner,
  final_scores: status.scores,
  vault: {
    winner: judgment.winner, winner_school: judgment.winner,
    final_position: vault.final_position, one_liner: vault.one_liner || '',
    reasoning: vault.reasoning, rejected_position: vault.rejected_position, rejected_why: vault.rejected_why,
  },
}
const _snapPath = `${OUT_ROOT}/snapshots/${runId}.json`
const _wePath = `/tmp/winner-event-${runId}.json`
await agent(
`Guarantee the replay snapshot ends with a winner_declared event (the builder sometimes omits it, which dead-stops the replay).
1. Use the Write tool to write this EXACT JSON to ${_wePath} :
${JSON.stringify(winnerEvent, null, 2)}
2. Then run this Bash command exactly (it appends the event via node only if missing — deterministic, no judgement):
node -e 'const fs=require("fs");const p=process.argv[1],w=process.argv[2];const d=JSON.parse(fs.readFileSync(p,"utf8"));d.timeline=d.timeline||[];if(!d.timeline.some(e=>e&&e.event==="winner_declared")){const ev=JSON.parse(fs.readFileSync(w,"utf8"));ev.time=(((d.timeline[d.timeline.length-1]||{}).time)||100)+3;d.timeline.push(ev);fs.writeFileSync(p,JSON.stringify(d,null,2));console.log("APPENDED winner_declared");}else{console.log("winner_declared already present");}' ${JSON.stringify(_snapPath)} ${JSON.stringify(_wePath)}
Return {"ok":true}.`,
  { label: 'out:ensure-winner', phase: 'Output', model: 'haiku', schema: OK })

// Append run to snapshots/index.json for replay discovery
await agent(
  `Update ${OUT_ROOT}/snapshots/index.json (use Read then Write). If it exists, parse {"runs":[...]}, append "${runId}" if absent, write back. If it does not exist, create {"runs":["${runId}"]}. Return {"ok":true,"files":["${OUT_ROOT}/snapshots/index.json"]}.`,
  { label:'out:index', phase:'Output', model:'haiku', schema: OK }
)

const outFiles = outputs.filter(Boolean).flatMap((o)=>o.files||[])
return {
  run_id: runId, runDir,
  competitors: FIELD.length, round1: r1.length, round2: r2.length,
  winner: judgment.winner,
  final_position: vault.final_position,
  rejected_position: vault.rejected_position,
  scores: status.scores,
  output_files: outFiles,
  dashboard: `${ARENA}/dashboard/live.html  (serve OUT_ROOT, base http://localhost:8080)`,
}
