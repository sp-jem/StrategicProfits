# Positioning Arena — Dashboard Run-Dir Convention

## Overview

Two dashboards live in this folder:
- **`live.html`** — real-time polling dashboard for an active arena run
- **`replay.html`** — snapshot-driven replay dashboard for completed runs

Both fork the Copywriting Arena aesthetic (dark bg `#07070d`, purple `#8b5cf6` primary, gold `#f59e0b` for vault/winner) and mirror the same polling/streaming/playback engine.

---

## How to Serve

Both dashboards require a local HTTP server — browsers block `file://` cross-origin reads.

```bash
# From the positioning-arena run root (the directory that contains runs/ and snapshots/)
cd /path/to/positioning-arena
python3 -m http.server 8080

# Then open:
# live.html   → http://localhost:8080/dashboard/live.html
# replay.html → http://localhost:8080/dashboard/replay.html
```

When prompted in the setup panel, enter `http://localhost:8080` as the base URL.

---

## Run Directory Convention

### Top-level layout

```
positioning-arena/
├── runs/
│   └── <run-id>/           ← one per arena execution
│       ├── status.json
│       └── agents/
│           └── <agent-id>/
│               └── thoughts.md
├── snapshots/
│   ├── index.json           ← optional: list of run IDs for replay discovery
│   └── <run-id>.json        ← serialized complete run for replay
└── dashboard/
    ├── live.html
    ├── replay.html
    └── README.md
```

---

## `status.json` Shape

Written (and overwritten) by the arena orchestrator during a live run. Polled every 2 s by `live.html`.

```jsonc
{
  "run_id": "my-product-2026-06-01",
  "run_name": "ZenithPro Positioning Battle",
  "product_name": "ZenithPro",      // shown in header
  "phase": "round_1",               // see Phase Values below
  "current_phase": "round_1",       // alias accepted

  "agents": [                       // array of agent status objects
    {
      "id": "dunford",              // must match roster IDs in live.html
      "status": "thinking",         // see Agent Status Values below
      "token_pct": 42               // 0-100 — drives token meter bar
    }
  ],

  "scores": {                       // populated once critique runs
    "dunford": 78,
    "trout": 72,
    "play-bigger": 85
    // ... keyed by agent id
  },

  "events": [                       // append-only array — new events added each write
    {
      "time": "2026-06-01T14:22:05Z",   // ISO timestamp or any string
      "type": "phase_change",            // event type
      "source": "System",
      "message": "All schools generating Round 1 angles...",
      "band": "A"                        // optional: "A", "B", or "C" (controls feed color)
    }
  ],

  "vault": {                        // populated when phase = "vault" or "complete"
    "winner": "Play Bigger",
    "winner_school": "Play Bigger Framework",
    "final_position": "The only [Product] that teaches you to create a category instead of competing in one.",
    "reasoning": "Play Bigger won because it surfaced an insight no other school named...",
    "rejected_position": "The most scientifically-proven [Product] on the market",
    "rejected_why": "This position lands in a credibility war buyers cannot adjudicate..."
  }
}
```

### Phase Values

The `phase` field drives the Phase Ring highlight and the LIVE/COMPLETE badge.

| phase string     | Ring node highlighted |
|------------------|-----------------------|
| `excavation`     | Excavation            |
| `round_1`        | Round 1               |
| `critique`       | Critique              |
| `round_2`        | Round 2               |
| `audience_eval`  | Audience Eval         |
| `judge`          | Judge                 |
| `synthesis`      | Synthesis             |
| `vault` / `complete` | VAULT             |

### Agent Status Values

| status string        | Effect on card                        |
|----------------------|---------------------------------------|
| `thinking` / `drafting` / `writing` | Purple dot pulsing, card glow |
| `complete` / `round1_complete` / `round2_complete` | Green dot |
| `critique` / `under_critique` | Blue dot |
| `finalist`           | Gold dot pulsing, gold card border    |
| `vault`              | Gold dot solid                        |
| anything else        | Shown as-is in status text            |

---

## `agents/<id>/thoughts.md` Convention

One file per agent. **Append-only** — the arena writes new content to the end as the agent reasons. `live.html` polls each file and streams new characters into the agent's card body.

```
# dunford — Round 1 Thoughts

The critical question is: what are buyers already comparing this to?

Mapping alternatives matrix:
- vs. direct competitor X: buyers trade off on Y
- vs. DIY workaround: pain is Z
...
```

- File path: `runs/<run-id>/agents/<agent-id>/thoughts.md`
- Agent IDs must match the roster in the dashboard (see Roster section below).
- No frontmatter required; the full file content is streamed.
- To reset between rounds, truncate (or create a new file) — the dashboard tracks by character count.

---

## `snapshots/<run-id>.json` Shape

A complete serialized run used by `replay.html`. Written once at the end of a run (or exported manually).

```jsonc
{
  "run_id": "my-product-2026-06-01",
  "product_name": "ZenithPro",

  "timeline": [                     // array of events ordered by time (integer seconds)
    { "time": 0,   "event": "competition_start", "phase": "Excavation", "data": {} },

    { "time": 5,   "event": "phase_change", "phase": "Round 1",
      "data": { "message": "All schools generating positioning angles..." } },

    { "time": 12,  "event": "thought_appearing", "phase": "Round 1",
      "agent_id": "dunford", "band": "A",
      "content": "The content text streamed into the card...",
      "word_count": 280 },

    { "time": 30,  "event": "phase_change", "phase": "Critique",
      "data": { "message": "10x critic evaluating..." } },

    { "time": 40,  "event": "critique_complete", "phase": "Critique",
      "agent_id": "dunford", "band": "A",
      "score": 78, "summary": "Strong alternative comparison. Missing emotional hook." },

    { "time": 70,  "event": "audience_eval", "phase": "Audience Eval",
      "agent_id": "play-bigger",
      "audience_score": 91, "audience_note": "Audience immediately understood the new category." },

    { "time": 100, "event": "winner_declared", "phase": "VAULT",
      "winner": "Play Bigger",
      "winner_school": "Play Bigger Framework",
      "final_scores": { "dunford": 78, "trout": 72, "play-bigger": 89 },
      "vault": {
        "winner": "Play Bigger",
        "winner_school": "Play Bigger Framework",
        "final_position": "The only [Product] that teaches you to create a category...",
        "reasoning": "Play Bigger won because it surfaced an insight no other school named...",
        "rejected_position": "The most scientifically-proven [Product] on the market",
        "rejected_why": "This position lands in a credibility war buyers cannot adjudicate."
      }
    }
  ]
}
```

### Timeline Event Types

| event                | Required fields                            | Effect |
|----------------------|--------------------------------------------|--------|
| `competition_start`  | `phase`, `data`                            | Commentary entry |
| `phase_change`       | `phase`, `data.message`                    | Phase Ring + commentary |
| `thought_appearing`  | `agent_id`, `band`, `content`              | Streams text into card |
| `critique_complete`  | `agent_id`, `score`, `summary`             | Sets score + leaderboard |
| `audience_eval`      | `agent_id`, `audience_score`, `audience_note` | Status + commentary |
| `winner_declared`    | `winner`, `final_scores`, `vault`          | All scores + vault overlay |
| `vault_reveal`       | same as `winner_declared`                  | Alias accepted |

### `index.json` (optional, for replay auto-discovery)

```jsonc
{
  "runs": [
    "my-product-2026-06-01",
    "second-product-2026-06-02"
  ]
}
```

Place at `snapshots/index.json`. When the replay dashboard's setup panel is submitted with no explicit run ID, it loads this index and populates run tabs automatically.

---

## Agent Roster (IDs)

The dashboards hard-code these agent IDs. The arena orchestrator must use these exact IDs in `status.json` and `agents/<id>/thoughts.md`.

### Band A — Positioning Schools (10)
| id | name | school |
|----|------|--------|
| `trout` | Trout | Al Ries & Jack Trout |
| `dunford` | Dunford | April Dunford |
| `marion` | Marion | Marty Marion |
| `dell` | Dell | Brendan Dell |
| `raskin` | Raskin | Andy Raskin |
| `brunson` | Brunson | Russell Brunson |
| `moore` | Moore | Geoffrey Moore |
| `yoon` | Yoon | Eddie Yoon |
| `godin` | Godin | Seth Godin |
| `klaff` | Klaff | Oren Klaff |

### Band B — Category Design Schools (3)
| id | name | school |
|----|------|--------|
| `play-bigger` | Play Bigger | Play Bigger Framework |
| `category-pirates` | Cat. Pirates | 22 Laws (Category Pirates) |
| `blue-ocean` | Blue Ocean | Blue Ocean Strategy |

### Band C — Deep-Thinker Lenses (7)
| id | name | school |
|----|------|--------|
| `lens-perception` | Perception | Gordon — Category Perception |
| `lens-desire` | Desire | Girard — Mimetic Desire |
| `lens-identity` | Identity | Tajfel — Social Identity |
| `lens-status` | Status | Veblen — Status Signals |
| `lens-frame` | Frame | Lakoff — Metaphor Frame |
| `lens-belief` | Belief | Kelman — Internalization |
| `lens-defense` | Defense | Sherif — Anchor & Contrast |

---

## The Vault Reveal

The vault is the climax event of every run. When `phase` reaches `vault`/`complete` and `status.json` contains a `vault` object, `live.html` triggers a full-screen card-flip overlay:

1. **Front face** — The "rejected bigger position": the bolder framing that was evaluated and rejected, with the reason why. Shown first with a red strikethrough.
2. **Back face** — The actual vault winner: school name, the final position statement in gold, and the judge's reasoning.

The flip happens automatically after 3.5 seconds (or on click). This is the demo's money moment — the insight that no one else named.

The same overlay fires in `replay.html` when playback reaches `winner_declared` / `vault_reveal` events (suppressed during seek operations to avoid interrupting scrubbing).
