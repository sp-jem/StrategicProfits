---
name: reber-perceptual-fluency-auditor
description: Audits visual and typographic decisions for perceptual fluency — contrast ratio, font legibility, line length, white space, type hierarchy — and outputs a fluency score per section with specific upgrade recommendations.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Rolf Reber & Norbert Schwarz (Processing Fluency) — Idea 1"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/reber-perceptual-fluency-auditor {copy-or-page-description}"
  called_by: [user, reber-field-intelligence]
  outputs_to: [project-output-folder]
---

# Reber Perceptual Fluency Auditor

---

## LAYER 1: INVARIANTS (Never override.)

1. **Attribution correction reversal is the master constraint.** The perceptual fluency mechanism operates because readers do not notice that font contrast, legibility, or layout ease is affecting their truth judgments. When they notice — when the manipulation is visible — the effect reverses: fluency reads as deception, disfluency reads as authentic effort. Every recommendation in this audit must pass the detection test: "If the reader were told this design choice was made to increase believability, would they trust the claim more or less?" Only recommend fluency improvements that pass this test. Fluency amplifies true claims. It cannot manufacture believability for weak ones.

2. **Perceptual fluency is sensory-level only.** This skill audits the physical/sensory processing dimension: can the eye form a perceptual representation of the text effortlessly? Contrast ratio, font legibility, figure-ground separation, visual noise, line spacing, text density. Conceptual fluency (vocabulary, sentence structure) and linguistic fluency (rhyme, rhythm, cadence) are audited by separate skills. Do not conflate them.

3. **The mechanism is empirically verified.** Reber & Schwarz (1999) demonstrated that typographic contrast alone shifts truth ratings by approximately 0.4 standard deviations, controlling for actual truth value and prior familiarity. This is not a soft design preference. Every visual production decision — font choice, type size, contrast ratio, line length, white space, color contrast — is a truth-perception lever. Recommendations are grounded in this mechanism, not aesthetic opinion.

4. **The truth-fluency link requires that ease cannot be attributed to the typography itself.** When subjects were told a statement was in large font "for a vision test," the fluency-truth effect was eliminated. This means: design choices that look like they are designed to be readable (clean, professional, high-contrast) produce the fluency bonus. Design choices that look like they are designed to overwhelm or impress (decorative fonts, gradient text, busy backgrounds) are attributed to styling intent and lose the truth bonus.

5. **Disfluency is not an option in default high-fluency copy environments.** The Alter & Oppenheimer "rugged path" case (strategic disfluency to activate analytic processing) is treated as an advanced edge case in `reber-truth-fluency-calibrator`. In perceptual fluency auditing, the default rule is: maximize perceptual fluency everywhere. There is no perceptual fluency version of "strategic disfluency" — the analytic activation use case applies to conceptual and linguistic dimensions, not to whether text is physically readable.

---

## LAYER 2: QUALITY GUIDANCE

6. **Score every section, not just the whole page.** Perceptual fluency varies significantly across a single sales page — the headline is usually well-designed, the body copy is often where fluency degrades. Section-level scoring reveals exactly where believability is being suppressed.

7. **Produce upgrade instructions specific enough to implement without a designer present.** "Improve contrast" is not actionable. "Change this body copy from #777777 on #F5F5F5 to #333333 on #FFFFFF — this increases contrast ratio from approximately 3.9:1 to 12.6:1 and meets WCAG AAA while restoring the full truth-fluency effect" is actionable.

8. **Prioritize by impact on claim believability.** A low-fluency header carries higher priority than a low-fluency footer disclaimer. The biggest claims — the core promise, the mechanism, the price justification — must have the highest perceptual fluency scores. That is where the fluency-truth mechanism has the most dollars-at-risk leverage.

---

## PURPOSE

Every visual production decision on a sales page, email, or VSL overlay is simultaneously a perceptual fluency decision and a truth-perception decision. Reber & Schwarz (1999) proved this with a single typographic variable. The mechanism: perceptual ease produces a positive metacognitive signal that is used as evidence of truth. High-contrast black on white text produces this signal. Light gray text on a white background suppresses it. Decorative fonts in headlines create figure-ground ambiguity that suppresses it. Tight leading creates visual density that suppresses it.

This audit instrument applies the perceptual fluency framework to any copy-bearing design, producing a section-by-section fluency score and a prioritized remediation brief.

---

## INPUT REQUIREMENTS

Provide one of the following:
1. **A URL** — the skill will analyze the visible design characteristics of the page
2. **A design description** — font choices, colors, layout structure, spacing, background colors, text sizes
3. **A screenshot or image** — visual inspection of the page
4. **Copy-only** — the skill will flag typographic risks that commonly appear with the copy structure provided, even without visual access

Optional:
- Device target (desktop / mobile / both) — mobile has different fluency failure modes
- Audience sophistication level — design-literate audiences have different fluency expectations

---

## AUDIT FRAMEWORK

### Perceptual Fluency Dimensions (5 dimensions, scored 1-5 each)

**Dimension 1: Contrast Ratio**
- The single most empirically loaded variable. Reber & Schwarz (1999) used contrast as their manipulation.
- 5/5 = High-contrast black/dark body text on white/near-white background (contrast ratio ≥ 7:1)
- 3/5 = Readable but suboptimal (contrast ratio 4.5:1 to 7:1)
- 1/5 = Low-contrast gray-on-white, colored text on colored backgrounds, reversed text with insufficient contrast
- Score each named section separately.

**Dimension 2: Font Legibility**
- Does the typeface produce clean, unambiguous letterforms at the sizes used?
- 5/5 = High-legibility serif or sans-serif at appropriate size, no decorative letterforms in body copy
- 3/5 = Acceptable but with legibility risk (thin weights, narrow tracking, slightly small size)
- 1/5 = Decorative/script fonts in body text, very thin weights, inadequate size, excessive stylization
- Note: Headline fonts can be slightly more decorative if large enough that letterforms remain unambiguous.

**Dimension 3: Figure-Ground Separation**
- Can the text be immediately separated from its background without cognitive effort?
- 5/5 = Clean separation, no texture/pattern behind text, no competing visual elements in proximity
- 3/5 = Mild visual noise (subtle texture, light background image) that requires slight processing effort
- 1/5 = Text over photography, patterned backgrounds, overlapping design elements, busy layouts behind copy
- This dimension is particularly critical for VSL lower-third text overlays.

**Dimension 4: Line Density and Spacing**
- Does the spatial arrangement of text facilitate rapid perceptual parsing?
- 5/5 = Comfortable line spacing (1.4–1.8 leading), paragraph breaks every 2-4 lines, adequate margins, comfortable line length (50-75 characters)
- 3/5 = Slightly tight or slightly wide spacing; long paragraphs without breaks; lines slightly too long or too short
- 1/5 = Wall-of-text formatting, very tight leading, full-width text blocks at small sizes, minimal white space
- Mobile note: Line length violations are almost always worse on mobile — audit both if applicable.

**Dimension 5: Visual Hierarchy Clarity**
- Does the typography communicate relative importance instantly, so the eye knows where to land next?
- 5/5 = Clear size and weight differentiation between headline, subhead, and body; pull quotes or callouts clearly distinguished; no ambiguity about reading order
- 3/5 = Some hierarchy exists but with ambiguity — two text levels that are too similar in size, or too many hierarchy levels that confuse reading sequence
- 1/5 = Flat hierarchy (all text the same size), inverted hierarchy (body larger than subhead), or chaotic hierarchy (arbitrary size/weight variation)

---

## EXECUTION PROCESS

### Step 1: Section Identification
Parse the piece into named sections: above-the-fold / headline area, lead paragraph, subheads, body copy sections, testimonials, mechanism/proof section, price/offer section, guarantee, CTA. Name each.

### Step 2: Per-Section Scoring
For each section, score all 5 dimensions (1-5). Note specific evidence for each score (e.g., "body copy appears approximately #888888 on white background = est. 3.5:1 contrast ratio = Dimension 1 score: 2").

### Step 3: Composite Section Score
Average the 5 dimension scores for each section → Composite Perceptual Fluency Score (1-5 scale).

### Step 4: Priority Ranking
Rank sections by: (Composite Score × Claim Criticality). Claim criticality weights:
- Core promise headline: 3×
- Price/value justification: 3×
- Mechanism/proof section: 2.5×
- Close/CTA: 2.5×
- Testimonials: 2×
- Body supporting copy: 1.5×
- Footer/legal/navigation: 1×

### Step 5: Remediation Brief
For each section scoring below 3.5 composite, produce specific upgrade instructions for each dimension scored below 3.

---

## OUTPUT STRUCTURE

### Section 1: Perceptual Fluency Scorecard

| Section | D1 Contrast | D2 Font | D3 Figure-Grnd | D4 Density | D5 Hierarchy | Composite | Priority |
|---------|------------|---------|----------------|------------|--------------|-----------|----------|
| [Name] | [1-5] | [1-5] | [1-5] | [1-5] | [1-5] | [avg] | [H/M/L] |

### Section 2: Critical Failures
Any dimension score of 1-2 in a section with Priority = HIGH gets immediate callout with:
- What the failure is
- Estimated impact on truth perception for claims in that section
- Exact remediation instruction

### Section 3: Prioritized Remediation Brief
Ranked list of specific changes, highest-impact first, each formatted as:
> **[Section] — [Dimension]:** [Current state] → [Recommended change] → [Expected fluency gain and rationale]

### Section 4: Attribution Risk Assessment
For the overall design: does anything look like it was designed to manipulate? Aggressive trust badges, excessive use of designed-to-look-legible but stylized fonts, artificial urgency via typographic distress styling? Flag any element that could trigger attribution correction and reverse the fluency-truth benefit.

---

## OUTPUT FILE

Save complete audit to:
`[project-folder]/Reber-Schwarz - Perceptual Fluency/[YYYY-MM-DD] - Perceptual Fluency Audit - [Piece Name].md`
