---
name: markus-possible-selves-architect
description: Constructs the full possible-selves architecture for any offer — hoped-for self, feared self, bridge mechanism, and working-self-concept sequencing. Primary Markus & Nurius skill.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Hazel Markus & Paula Nurius (Possible Selves) — Idea 1, 3, 5"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/markus-possible-selves-architect {avatar-profile} {offer}"
  called_by: [user, copywriting-arena, bj, clayton, dd, ae]
  outputs_to: [client-output-folder]
depends_on: [markus-specificity-audit, markus-balance-diagnostic, markus-schema-activation-primer]
---

# Markus Possible Selves Architect

---

## LAYER 1: INVARIANTS (Never override.)

1. **"You'll make more money" is NOT a possible self and does NOT motivate.** An operative possible self requires FIVE dimensions: (1) role specification — the specific position/title/function the person occupies; (2) situational context — the physical and social setting, who else is present; (3) behavioral content — what they do differently than they do now; (4) emotional charge — what it feels like from the inside; (5) plausible bridge — the credible path from current self to this future self. Copy that passes the emotional resonance test but fails the specificity test produces "sounds good" responses, not purchase decisions.

2. **Balance requirement is non-negotiable.** A hoped-for self without a domain-matched feared self underperforms relative to the full regulatory circuit (Oyserman & Markus 1990). Both poles must be present, domain-matched, and specifically elaborated. "Domain-matched" means both poles are about the same life domain — professional, financial, relational, health, etc. A financial feared self cannot balance a professional hoped-for self.

3. **The bridge is structurally required.** A vivid hoped-for self without a credible mechanism for getting there produces inspiration without purchase. The bridge answers: "I can see who I want to be, but I cannot see how to get there." The product/offer IS the bridge. The architecture is not complete until the bridge is installed.

4. **Steele pre-frame is required before feared self activation.** The feared self is an identity threat. Without a self-affirmation pre-frame (establishing that the prospect is a capable, resourceful person), feared self activation triggers defensive processing — the prospect protects self-integrity rather than engaging with the message. The pre-frame must come first. This is not optional.

5. **Schema activation precedes everything.** Before constructing the possible selves, the relevant self-schema must be fired. Copy that presents the hoped-for self before activating the domain identity schema gets evaluated by a generic processor, not a domain-invested one. The opener's job is schema activation, then possible selves construction.

6. **Plausibility gates vividness.** The most elaborated hoped-for self fails to motivate if it is not perceived as attainable. The prospect must be able to see a credible path from current self to hoped-for self. "Possible but not certain" produces more motivation than either "definitely will happen" (no tension) or "I don't really expect this" (too implausible). Calibrate elaboration to the market's actual attainability perception.

---

## LAYER 2: QUALITY GUIDANCE

7. **The five-dimension test is a binary, not a gradient.** Either the possible self has all five dimensions or it doesn't. Do not produce "partial" possible selves with 3 of 5 dimensions and call them complete. If a dimension is genuinely unknowable from the available input, flag it as a gap and ask for more information rather than filling it with generic language.

8. **Cross-references to activate:**
   - Higgins regulatory focus: promotion orientation = toward hoped-for self; prevention orientation = away from feared self. Use both in the architecture — the regulatory mix determines which type of language dominates each section.
   - Steele self-affirmation: install pre-frame before feared self. This is a hard sequencing requirement, not a stylistic option.
   - Oyserman action-readiness: even a perfectly constructed possible self fails to produce behavior if the situational context signals "people like you don't act here/now." The CTA and closing context must confirm situational congruence.
   - Working self-concept: what is active in the prospect's mind at the moment of reading determines which self-schema processes the message. The sequencing of the entire piece must maintain the relevant identity frame throughout — not just in the lead.

9. **The nightmare section has clinical precision requirements.** The feared self must be domain-specific, situationally grounded, behaviorally described, and emotionally charged. Generic failure language ("you might not succeed") activates general anxiety without directing it toward a specific possible self — non-specific anxiety is as likely to produce avoidance of the copy itself as avoidance of the feared state. Specificity in the feared self is not manipulative escalation; it is the empirically verified mechanism for directed motivational potency.

10. **Testimonials are working-self-concept activators, not just credibility devices.** The right testimonial (from someone the prospect identifies with) activates the relevant identity schema and brings the product-relevant possible self into the working self-concept. Select and sequence testimonials with this function in mind — which identity component does each testimonial activate, and when in the copy's sequence should that activation occur?

---

## PURPOSE

Most transformation copy fails at the same point: it names outcomes instead of constructing self-representations. "You'll make more money" describes a result. "You'll be the person in your industry who others call when they're lost — the one who speaks about the transformation you've already made, while your peers are still running tactics that worked five years ago" — that is a possible self. The distinction is not rhetorical polish; it is whether the motivational circuit activates or doesn't.

Markus & Nurius (1986) demonstrated that motivation is generated by vivid, self-relevant cognitive representations of what one might specifically become — or fail to avoid becoming. The specificity is load-bearing. The balance between hope and fear is empirically required. The bridge from current self to hoped-for self is structurally necessary for purchase behavior.

This skill constructs the complete architecture: schema activation primer, hoped-for self (five dimensions), feared self (five dimensions, domain-matched), bridge language, and working-self-concept sequencing across the full piece.

---

## INPUT REQUIREMENTS

Provide:
1. **Avatar profile** — Who is the prospect? Current role/situation, known self-schemata (how they already identify), the primary domain of the offer (professional, financial, relational, health), recent history of what they've tried, where they feel stuck.
2. **Offer description** — What does the product/program do? What is the mechanism? What transformation does it promise? What makes the pathway credible?
3. **Tone mode** (optional) — Promotion-forward (toward hoped-for) or prevention-forward (away from feared). Default: balanced. Override when market research indicates strong prevention orientation.

Optionally provide:
- Competitor positioning (to avoid mimetic convergence with other hoped-for self constructions in the market)
- Existing copy that needs retrofitting into a possible selves architecture

---

## EXECUTION PROCESS

### Phase 1: Schema Activation Layer

**Identify the primary self-schema to activate.**

From the avatar profile, determine:
- What domain is this offer in? (professional, financial, relational, health)
- What identity does the prospect already hold about themselves in this domain? ("I'm a strategist," "I'm a builder," "I'm someone who always figures it out")
- Is the prospect schematic (has organized self-knowledge in this domain) or aschematic (domain is unfamiliar)?

**If schematic:** Activate the schema by naming it and confirming it — "You're the kind of person who..." + behavioral evidence they'd recognize from their own experience.

**If aschematic:** Install a schema fragment — the copy must grant the identity before the possible self can be inhabited. "Most people in your position haven't been told this about themselves, but what you've been doing is the foundation of..." + new schema label.

**Output from Phase 1:** Schema activation language for the lead (3-5 sentences).

---

### Phase 2: Hoped-For Self Construction

Construct the hoped-for self across all five dimensions. Fill each dimension fully. Do not proceed to the next dimension until the current one is sufficiently elaborated.

**Dimension 1 — Role Specification**
What specific role/position/function does the prospect occupy in the hoped-for state?
- Not: "successful"
- Yes: "the person in your market who other practitioners call when they're trying to figure out what's actually working — the one who gets asked to speak, to consult, to weigh in, because you made the move everyone else is still thinking about"

**Dimension 2 — Situational Context**
Where is the prospect? Who is around them? What does the physical and social environment look like?
- Not: "living the life"
- Yes: "you're in the room where the decisions get made — not because you pushed your way in, but because you were invited; the people around you are people who used to seem out of reach"

**Dimension 3 — Behavioral Content**
What does the prospect do differently than they do now? What specific behaviors define this future state?
- Not: "operating at a higher level"
- Yes: "you make the same decisions your current self agonizes over in minutes, not days; you've stopped explaining yourself to people who aren't in position to understand; you spend your time on work that compounds, not work that clears"

**Dimension 4 — Emotional Charge**
What does it feel like from the inside? Not how others perceive them — the internal felt experience.
- Not: "confident and successful"
- Yes: "the particular relief of not having to perform competence to people who don't have it — the quiet that comes from knowing exactly who you are in a room, not as arrogance but as settled fact"

**Dimension 5 — Plausible Bridge**
What is the specific mechanism that makes this transition credible? Why is this achievable for this person?
- Not: "with the right system"
- Yes: "you're two moves away from this state, not twenty — you have [X skill/asset/foundation already]; what's missing is [specific thing the product provides], and once that's in place, the rest follows from what you've already built"

**Output from Phase 2:** Hoped-for self — full five-dimension articulation.

---

### Phase 3: Steele Pre-Frame Installation

Before constructing the feared self, install the self-affirmation pre-frame.

**The pre-frame does two things:**
1. Confirms the prospect's competence, values, and identity in the domain — activates the self-integrity buffer
2. Establishes that the feared self is not an accusation about who they are, but a description of what happens to capable people who don't have the right mechanism in place

**Template structure:**
"The fact that you're [behavior/trait that reflects self-awareness and seriousness] is not the problem. Most people who end up [feared state description] aren't people who didn't care or didn't try. They're people who were [real characteristic of the prospect's identity] but were working with [missing element the product provides]. This isn't about who you are. It's about what you have access to."

**Output from Phase 3:** Pre-frame language (2-4 sentences).

---

### Phase 4: Feared Self Construction

Construct the feared self across all five dimensions. Domain must match the hoped-for self's domain.

**Dimension 1 — Role Specification**
What specific role/position/function does the prospect occupy in the feared state?
- Not: "you might fail"
- Yes: "you're still in the role where you started — still doing the work yourself, still explaining why the results aren't there yet, still one of the people the market hasn't sorted out from the people who are just trying"

**Dimension 2 — Situational Context**
Where is the prospect? Who is around them? What does the social environment signal?
- Not: "you're not where you want to be"
- Yes: "you're watching the people you used to be ahead of start to pull away; they're showing up in rooms you haven't been invited to; the gap between where you are and where you intended to be becomes visible every time someone else gets the call you should have gotten"

**Dimension 3 — Behavioral Content**
What does the prospect do in the feared state? What patterns persist?
- Not: "still struggling"
- Yes: "you're still running the same set of moves — the ones that worked well enough to get you here but not well enough to get you there; you're still optimizing at the edge of a model that needs to be replaced"

**Dimension 4 — Emotional Charge**
What does the feared state feel like from the inside?
- Not: "frustrated and stuck"
- Yes: "the specific kind of exhaustion that comes from working hard and smart and still falling short of the version of yourself you're capable of being — not failure, which would be easier to name; something more like deferred life"

**Dimension 5 — Plausible Bridge (Absence)**
Why is this state realistic? What makes this feared outcome genuinely possible, not catastrophic?
- Not: "everything falls apart"
- Yes: "this isn't a dramatic failure scenario — it's the more common one: the steady accumulation of missed windows, of being slightly behind the right moment, of having everything required except the one thing that converts effort into position"

**Output from Phase 4:** Feared self — full five-dimension articulation.

---

### Phase 5: Bridge Language

The bridge answers the implicit challenge the possible self architecture creates: "I can see who I want to be — how do I get there?"

**Bridge construction requirements:**
1. Names the specific mechanism by which the product converts current self into hoped-for self
2. Explains why this mechanism works when other approaches haven't
3. Connects the bridge explicitly to the prospect's current self — not a generic "here's the solution," but "here's why this is the move for someone at your specific stage"
4. Addresses the plausibility concern directly — "this isn't a different version of what you've already tried; here's what's structurally different"

**Output from Phase 5:** Bridge language (4-8 sentences).

---

### Phase 6: Working Self-Concept Sequencing

Map the full architecture onto a copy sequence. Every element of the copy serves a working-self-concept function.

| Copy Element | Working-Self-Concept Function | Possible Selves Component |
|---|---|---|
| Lead / Hook | Schema activation | Fires domain identity; brings relevant self-schemata into working self-concept |
| Before-State Description | Current-self anchoring | Establishes the gap between current-self and hoped-for self |
| Greatest Hits / Origin | Schema confirmation | "You've already demonstrated you're this kind of person" |
| Aspiration Section | Hoped-for self activation | Constructs the five-dimensional hoped-for self |
| Pre-Frame | Self-affirmation buffer | Steele pre-frame before feared self |
| Nightmare/Agitation | Feared self activation | Constructs the five-dimensional feared self (domain-matched) |
| Mechanism / Product | Bridge installation | "Here is specifically how current-self becomes hoped-for-self" |
| Testimonials | Working-self-concept reinforcement | Select for identity-schema activation, not just result evidence |
| CTA | Hoped-for self peak activation | Close while the hoped-for self is maximally accessible in working memory |

**Critical sequencing rules:**
- Schema activation BEFORE hoped-for self construction
- Self-affirmation pre-frame BEFORE feared self activation
- Bridge AFTER both poles are established (prospect needs to feel the tension before the resolution is credible)
- CTA must land while the hoped-for self is still active in working memory — buried CTAs after long feature lists lose conversion because the identity frame has lapsed

**Output from Phase 6:** Sequencing map with each copy element tagged to its working-self-concept function.

---

## OUTPUT STRUCTURE

### Markus Possible Selves Architecture: [Offer Name]

**Input Summary**
- Avatar: [one sentence]
- Domain: [professional / financial / relational / health]
- Offer mechanism: [one sentence]
- Tone mode: [promotion-forward / prevention-forward / balanced]

---

**SCHEMA ACTIVATION LAYER**
[Output from Phase 1 — 3-5 sentences of lead language]

Schema being activated: [name it]
Schematic or aschematic: [which, with brief reasoning]

---

**HOPED-FOR SELF**

*Role specification:* [full elaboration]
*Situational context:* [full elaboration]
*Behavioral content:* [full elaboration]
*Emotional charge:* [full elaboration]
*Plausible bridge:* [full elaboration]

Compiled construction: [single integrated passage pulling all five dimensions together — this is the actual copy-ready version]

---

**STEELE PRE-FRAME**
[Output from Phase 3 — 2-4 sentences]

---

**FEARED SELF**

*Role specification:* [full elaboration]
*Situational context:* [full elaboration]
*Behavioral content:* [full elaboration]
*Emotional charge:* [full elaboration]
*Plausible bridge (absence):* [full elaboration]

Compiled construction: [single integrated passage — copy-ready]

Domain match confirmed: [YES / NO — if NO, rebuild before proceeding]

---

**BRIDGE LANGUAGE**
[Output from Phase 5 — 4-8 sentences]

---

**WORKING SELF-CONCEPT SEQUENCE MAP**
[Table from Phase 6]

---

**AUDIT FLAGS**
Run `markus-specificity-audit` on the hoped-for and feared self constructions before finalizing. Run `markus-balance-diagnostic` to confirm both poles are domain-matched and adequately specific.

Any dimension that scored below threshold: [list with specific gaps]
Plausibility concern: [YES/NO — if YES, describe what makes the bridge not credible and what's needed to fix it]

---

## OUTPUT FILE

Save complete architecture to:
`[project-folder]/Markus & Nurius - Possible Selves Architecture/[Offer Name] - Possible Selves Architecture - [Date].md`
