---
name: sherif-anchor-mapper
description: Maps the prospect's attitudinal anchor before writing any copy. Entry point for all SJT-based claim decisions.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Muzafer Sherif (Social Judgment Theory) — Idea 1"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/sherif-anchor-mapper {market-or-audience-description}"
  called_by: [user, sherif-field-intelligence]
  outputs_to: [project-folder]
depends_on: []
---

# Sherif Anchor Mapper

---

## LAYER 1: INVARIANTS (Never override.)

1. **Sherif's anchor is attitudinal, not numerical.** The anchor is the prospect's existing position on an issue — their prior belief about the product category, the problem, the solution type, or the transformation being offered. This is categorically distinct from Kahneman & Tversky's numerical anchoring (1974), which operates on estimation tasks using numerical starting values. Sherif's anchor operates on the attitude spectrum. Do not conflate these constructs. If the Kahneman/Tversky anchoring stack is also in use, they address different phenomena and must not be merged.

2. **The anchor is the reference point for every claim decision downstream.** "Every person comes to a persuasive communication with a position of his own on the issue in question. This own position serves as an anchor in his evaluative process." — Sherif & Hovland, *Social Judgment* (1961), p. 4. No claim magnitude, no headline wording, no offer positioning is correct until the anchor is identified. All other Sherif skills depend on this output.

3. **The anchor is pre-message.** It exists before any copy is written or read. It is shaped by the prospect's prior experience with the category, their social reference group, their public commitments, and their ego-involvement level. It cannot be inferred from reading your own copy — it must be derived from market research: reviews, forums, customer interviews, behavioral data.

4. **Commercial copy requires proxy detection, not direct measurement.** Sherif & Hovland used the "Own Categories" procedure — having subjects sort statements into labeled piles — to measure anchors experimentally. This is not field-deployable for copy contexts. The anchor must be inferred from behavioral proxies: the language prospects use to describe the problem, the solutions they have already tried, the claims they accept vs. reject in competitor copy, their awareness stage (Schwartz proxy), their community membership. State these proxies explicitly in the output — do not manufacture a false precision.

5. **The commercial extension is inferential.** Sherif's empirical base is prohibition attitudes — politically charged, highly ego-involving, with clear social norms. Extension to product and service copy is logically tight but lacks a dedicated commercial-copy replication. Every output from this skill is labeled as an inference from SJT principles, not an experimentally validated finding for consumer persuasion.

---

## LAYER 2: QUALITY GUIDANCE

6. **The anchor is a position on a spectrum, not a binary.** Never reduce the anchor to "skeptical" or "believing." Map it on the relevant attitude dimension: Where on the awareness spectrum (Schwartz: unaware / problem-aware / solution-aware / product-aware / most-aware) does the target segment sit? Where on the belief spectrum for this specific product category? The Schwartz awareness stages are the best available commercial proxy for anchor position and acceptance latitude width — an unaware market has an anchor far from any product claim, and a correspondingly wide latitude of acceptance for educational framing; a most-aware market has an anchor close to the product category and a very narrow acceptance latitude.

7. **Multiple anchors may coexist.** The prospect may hold different anchors for different frames: the problem (one position), the solution category (another), the specific vendor (another). Map separately when the copy must navigate all three.

8. **Anchor instability must be flagged.** Sherif largely treated the anchor as stable, but later research (Mussweiler, 2003; Strack & Mussweiler, 1997) showed anchors are malleable via priming. If the copy or funnel strategy is likely to encounter primed anchors (e.g., competitor comparisons just consumed, recent negative press), flag this as an anchor-volatility risk.

---

## PURPOSE

"Before writing a word of copy, identify the anchor — the prospect's current belief about the problem, solution, or product category. All claim magnitude decisions flow from this." — Sherif dossier, Construct 1, Operational Implication.

Most copywriters begin with the offer and work backward. Social Judgment Theory requires the opposite: begin with the prospect's current position, and use that position to calibrate every claim in the copy. A claim that seems bold and credible to the copywriter may land in the latitude of rejection for a highly ego-involved prospect. A claim that seems modest may produce no attitude change because it falls below the assimilation threshold.

This skill produces the anchor map — the reference document that all other Sherif skills use to set their parameters.

---

## INPUT REQUIREMENTS

Provide one or more of the following:
1. **Market description** — who the target prospect is, what category they're in
2. **Existing research** — forum data, review language, interview transcripts, survey results
3. **Competitor copy samples** — what claims the market has already been exposed to and accepted/rejected
4. **Behavioral signals** — what solutions they've tried, what communities they belong to, what they've publicly stated
5. **Schwartz awareness stage estimate** — if already assessed, provide it; if not, this skill will estimate it from available signals

---

## EXECUTION PROCESS

### Step 1: Signal Inventory
List every piece of evidence available about the prospect's prior beliefs. Organize by source type: forum/review language, competitor copy acceptance, behavioral history, community membership, stated identity language ("as someone who has tried everything...").

### Step 2: Awareness Stage Estimation
Using the Schwartz five-stage framework as the commercial proxy for anchor position:
- **Unaware:** Prospect doesn't know they have the problem. Anchor is far from any solution claim — wide acceptance latitude for educational/curiosity framing.
- **Problem-Aware:** Knows the problem, doesn't know solutions exist. Anchor is at the problem level — will accept problem-framing claims, will reject premature product claims.
- **Solution-Aware:** Knows solutions exist, hasn't committed to a category. Anchor is at the solution-category level — will accept category-benefit claims.
- **Product-Aware:** Knows your product exists, hasn't bought. Anchor is at or near your specific offer — narrow acceptance latitude, requires proof over claims.
- **Most-Aware:** Has seen your offer repeatedly. Anchor is at the offer itself — the narrowest acceptance latitude, hair-trigger rejection latitude for overclaims.

State which stage (or which mix of stages, if a segmented audience) applies.

### Step 3: Anchor Position Statement
Produce a 2-3 sentence statement of the prospect's current anchor:
- The specific belief they hold about the problem
- The specific belief they hold about the solution category
- The specific belief they hold about claims of this magnitude (what they'll find credible vs. absurd)

### Step 4: Anchor Instability Assessment
Flag any conditions that could shift the anchor before or during message exposure:
- Recent competitor activity that may have primed a new reference point
- Social pressure events (news, community debates, peer opinions)
- The prospect's own recent behavior (trial purchases, program completions, failures)

### Step 5: Downstream Handoff
Summarize the anchor in the format required by `sherif-latitude-calibrator` and `sherif-ego-involvement-profiler`:
- **Anchor Position:** [Brief statement]
- **Schwartz Stage:** [Unaware / Problem-aware / Solution-aware / Product-aware / Most-aware]
- **Key proxy signals:** [Top 3 behavioral signals that define this anchor]
- **Anchor volatility:** [Stable / Unstable — reason]

---

## OUTPUT FILE

Save complete anchor map to:
`[project-folder]/Muzafer Sherif - SJT/01 - Anchor Map - [Market Name] - [Date].md`
