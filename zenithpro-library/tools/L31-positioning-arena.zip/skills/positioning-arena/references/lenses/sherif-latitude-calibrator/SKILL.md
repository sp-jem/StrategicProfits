---
name: sherif-latitude-calibrator
description: Translates anchor + ego-involvement inputs into a concrete claim magnitude zone. Governs headline, lead, and offer claim wording.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Muzafer Sherif (Social Judgment Theory) — Idea 2"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/sherif-latitude-calibrator {anchor-map} {ego-involvement-profile}"
  called_by: [user, sherif-field-intelligence]
  outputs_to: [project-folder]
depends_on: [sherif-anchor-mapper, sherif-ego-involvement-profiler]
---

# Sherif Latitude Calibrator

---

## LAYER 1: INVARIANTS (Never override.)

1. **Three latitudes govern all message outcomes.** "The latitude of acceptance includes the position most acceptable to the individual as well as any other positions he finds acceptable." "The latitude of rejection consists of positions the individual finds objectionable." "The latitude of noncommitment includes positions that are neither accepted nor rejected." — Sherif, Sherif & Nebergall, *Attitude and Attitude Change* (1965), pp. 23–24. Every claim lands in exactly one of these three zones. The zones are not fuzzy opinions — they are structural positions relative to the anchor.

2. **The optimal claim lands at the outer edge of the latitude of acceptance, not at the anchor.** The assimilation effect operates when the message falls within the latitude of acceptance: "There is a tendency to perceive it as closer to one's own position than it actually is." — *Social Judgment* (1961), p. 132. A claim too close to the anchor produces no attitude change — there is nothing to assimilate. A claim at the outer edge of acceptance triggers maximum assimilation without crossing into contrast. This is the "just-right" claim magnitude principle.

3. **Ego-involvement determines latitude width, which determines the safe claim range.** "The more ego-involved the individual, the smaller his latitude of acceptance and the larger his latitude of rejection." — *Attitude and Attitude Change* (1965), pp. 65–66. Calibration without ego-involvement assessment produces a claim magnitude that may be correct for an average audience but wrong for the actual target. The ego-involvement profile from `sherif-ego-involvement-profiler` is a required input, not optional context.

4. **The latitude of non-commitment is the death zone for copy.** Claims that are too hedged, too vague, or too far inside the acceptance zone produce no conversion. "This might be for you" is a non-commitment-latitude message. The goal is not to be safe — it is to be at the acceptance edge. The non-commitment zone is only useful as a tactical entry point in a staged sequence (start there to build familiarity, then escalate).

5. **The commercial extension is inferential.** Sherif's empirical work used prohibition attitudes. The latitude framework is extended here to product and service copy claims by logical inference from the mechanism, not from a dedicated commercial replication. State outputs as calibration guidance, not experimentally validated claim ranges.

---

## LAYER 2: QUALITY GUIDANCE

6. **The assimilation-contrast boundary is the most valuable output.** The key line to find is not the center of the acceptance latitude but its outer edge — the point just inside the rejection threshold. This is the highest-leverage claim position: close enough to the anchor that assimilation fires (prospect pulls the message toward their view), far enough from the anchor that real attitude change occurs.

7. **The non-commitment zone has a tactical use.** For high-ego-involvement markets, the staged-claim sequence may begin in the non-commitment zone (low threat, establishes rapport) and step toward the acceptance edge across the funnel. The non-commitment zone is the death zone only for a single-shot message. In a sequence, it is the safe entry point. Flag which situation applies.

8. **Latitude width estimates must be tied to evidence.** Every latitude width estimate must cite the ego-involvement signals and awareness stage that justify it. Do not produce claim ranges from intuition. Show the reasoning: "The target segment is Most-Aware (Schwartz) with high ego-involvement evidence [specific signals] → acceptance latitude is narrow → claim must be conservative and staged."

---

## PURPOSE

"Know the approximate width of your target's latitude of acceptance before writing the lead claim. For a low-sophistication market: wider, so you can open with a bigger claim. For a high-skepticism market: narrower, so you must stage claims slowly and prove each step before advancing." — Sherif dossier, Construct 2, Operational Implication.

"Place your leading claim at the outer edge of the acceptance latitude — not at the prospect's current position (no change) and not past the rejection border (boomerang). This is the 'just-right' claim magnitude principle." — Sherif dossier, Construct 5, Operational Implication.

The Latitude Calibrator translates the outputs of the anchor map and ego-involvement profile into a concrete claim-magnitude decision: where is the outer edge of the latitude of acceptance for this specific audience on this specific claim? What is the rejection threshold? This output directly governs headline claim wording, lead claim structure, and offer strength positioning.

---

## INPUT REQUIREMENTS

Required:
1. **Anchor map output** from `sherif-anchor-mapper` — or equivalent anchor position statement + Schwartz stage
2. **Ego-involvement profile output** from `sherif-ego-involvement-profiler` — or equivalent ego-involvement tier (Low / Medium / High) with supporting signals

Optional:
3. **Specific claims under consideration** — if you have draft headline or lead claims, provide them for direct calibration against the computed latitude
4. **Funnel context** — single-shot message (one latitude judgment) or staged sequence (entry latitude through escalation sequence)

---

## EXECUTION PROCESS

### Step 1: Set Latitude Width Parameters

Using the ego-involvement tier and Schwartz awareness stage:

**Latitude Width Estimates by Combination:**

| Ego-Involvement | Schwartz Stage | Acceptance Latitude | Rejection Threshold |
|-----------------|----------------|--------------------|--------------------|
| Low | Unaware–Problem-Aware | Wide — large claim range acceptable | Distant — must be extreme to trigger |
| Low | Solution-Aware–Product-Aware | Moderate | Moderate distance |
| Medium | Any Stage | Moderate — some staging needed | Requires moderate discrepancy |
| High | Solution-Aware | Narrow — conservative claims only | Close — small discrepancy triggers contrast |
| High | Product-Aware–Most-Aware | Very narrow — one acceptable position | Very close — even modest overclaiming triggers boomerang |

State the estimated latitude width in plain language before any claim decisions.

### Step 2: Identify the Three Zone Boundaries

For the specific market and claim type, define:

**Zone 1 — Latitude of Non-Commitment (inner):** Claims that are too conservative, too vague, or too close to the anchor. These produce no conversion. Describe the claim level at which this zone ends and acceptance begins.

**Zone 2 — Latitude of Acceptance (target zone):** Claims the prospect will not reject — they either agree or won't push back. The optimal position is the outer edge of this zone: far from the anchor (triggers attitude change) but not past the rejection threshold. Define the outer edge as concretely as possible: what claim magnitude, what proof requirement, what framing signals the boundary.

**Zone 3 — Latitude of Rejection (danger zone):** Claims that trigger contrast. "When a communication is placed in the latitude of rejection, there is a tendency to exaggerate the difference between it and one's own position." — *Social Judgment* (1961), p. 133. Define what types of claims, what levels of magnitude, what framings cross into this zone. Note that crossing into rejection does not just fail to persuade — it actively hardens opposition and increases resistance to future messages.

### Step 3: Calibrate Specific Claims (if provided)

For each provided headline, lead claim, or offer statement:
- **Latitude position:** Acceptance (inner) / Acceptance (outer edge) / Non-Commitment / Rejection
- **Confidence:** High / Medium / Low
- **Adjustment:** If in wrong zone, specific rewrite direction to move it to acceptance outer edge

### Step 4: Staged Sequence Design (if funnel context provided)

For multi-touchpoint funnels, design the claim escalation path:
- **Entry claim** (Ad or cold traffic): Latitude position goal → non-commitment to early acceptance
- **Qualification claim** (Landing page or lead magnet): Acceptance zone, building toward outer edge
- **Core claim** (VSL or sales page lead): Outer edge of acceptance — maximum assimilation trigger
- **Close claim** (Offer statement): Should not exceed the outer edge established by the core claim; proof-heavy, not magnitude-heavy

### Step 5: Handoff to Contrast Audit

Produce a summary for `sherif-contrast-audit`:
- **Rejection threshold description:** What types of claims cross the line for this audience
- **High-risk claim patterns:** Specific language, magnitude types, or proof gaps that will trigger contrast
- **Acceptance outer edge benchmark:** What the optimal claim magnitude looks like for this audience

---

## OUTPUT FILE

Save complete latitude calibration to:
`[project-folder]/Muzafer Sherif - SJT/02 - Latitude Calibration - [Market Name] - [Date].md`
