---
name: mcguire-inoculation-architect
description: Full inoculation pass orchestrator for any copy piece. Structures the complete inoculation architecture — threat calibration, refutational preemption, and placement sequencing — across a VSL, sales letter, or email. The meta-skill that calls on threat-calibrator and refutational-preemption-builder in sequence.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "William McGuire (Inoculation Theory) — Idea 1"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/mcguire-inoculation-architect"
  called_by: [user, mcguire-field-intelligence]
  outputs_to: [project-folder]
depends_on: [mcguire-threat-calibrator, mcguire-refutational-preemption-builder]
---

# McGuire Inoculation Architect

---

## LAYER 1: INVARIANTS (Never override.)

1. **Inoculation is structurally distinct from objection handling.** The threat component — the reader's felt awareness that their belief is genuinely vulnerable BEFORE any refutation is delivered — is the mechanism that separates inoculation from reactive objection management. If a piece of copy addresses doubts only after the reader has already formed them (or only in a late-funnel FAQ section), it is performing objection handling. Inoculation creates vulnerability-awareness in readers who may not yet feel vulnerable, then resolves it. This is the operational distinction that must be preserved in every inoculation pass. Calling a copy section "inoculation" when it lacks the threat component is mislabeling.

2. **Two-component structure is non-negotiable and sequence is structural.** Every inoculation pass requires: (1) threat component first — vulnerability established; (2) refutation second — attack defeated. Neither alone is sufficient. Threat without refutation leaves readers anxious and defenseless. Refutation without prior threat is motivationally inert — the reader has no reason to process it. The sequence cannot be reversed. The architect's role is to guarantee every inoculation unit in the copy contains both components in the correct order.

3. **The inoculation pass is placed BEFORE the full-strength attack reaches the reader — not in reaction to it.** Inoculation that comes after the reader has already encountered the attack from a competitor, a skeptic, or their own deepening resistance has reduced effect. The architect plans placement by asking: "At what point in the copy, sequence, or funnel will the reader likely encounter this attack externally?" The inoculation should land before that point.

4. **The threat component is about vulnerability-of-belief, not fear induction.** McGuire's inoculation threat and Hovland's fear appeals are mechanically distinct constructs. The threat asks the reader to recognize that their current confidence could be challenged by a specific credible argument — not that they should be afraid. Copy that substitutes emotional fear for vulnerability-awareness has switched to a different mechanism. Both can appear in the same piece but are not interchangeable.

5. **The number of inoculation units is determined by attack priority, not completeness.** The goal is not to address every possible objection. It is to inoculate against the attacks that, if believed, most thoroughly undermine the purchase motivation — and to rely on cross-protection transfer for the remaining objections. A focused inoculation against two or three load-bearing attacks outperforms a diluted catalog of every minor doubt. The architect selects, does not enumerate.

---

## LAYER 2: QUALITY GUIDANCE

6. **Inoculation placement has a grammar.** In long-form copy, inoculation units typically appear: (a) early in the argument, before the full promise is made (preemptive threat against "this sounds like every other promise"), (b) after the mechanism reveal, before social proof (threat against "the mechanism doesn't generalize to my situation"), (c) after social proof, before the offer (threat against "these are cherry-picked results"). Each placement serves a different vulnerability moment.

7. **Passive and quasi-active forms have different roles.** Passive inoculation: the copy writes out the full threat + refutation. Quasi-active: the copy poses the threat as a rhetorical question ("Are you thinking: this sounds too good to be true?") before providing the refutation — this invites the reader to generate the thought, producing partial active-inoculation effect. Both are valid; quasi-active is slightly more effective for engaged readers and slightly more risky with skimmers. Choose based on placement and expected engagement level.

8. **Integration with the rest of the copy matters.** Inoculation units are not interruptions — they should feel like they belong inside the argumentative flow. The threat is most effective when it emerges naturally from what the copy has just established, and the refutation lands as a direct continuation of the argument. Inoculation that reads as an abrupt objection-handling sidetrack loses much of its motivational force.

---

## PURPOSE

"Just as the body can be made resistant to disease by inoculation with a weakened form of the disease virus, so can the mind be made resistant to persuasion by exposing the person to a weakened attack on his belief, accompanied by a refutation of that attack." — McGuire, 1964

This skill orchestrates the complete inoculation architecture for a copy piece — VSL, long-form sales letter, email sequence, or webinar script. It reads the piece (or receives a brief describing it), identifies where each inoculation unit belongs, calls on threat calibration and refutational preemption, and assembles the full annotated inoculation map: what goes where, why, and in what form.

The output is an action-ready inoculation blueprint: specific language for each unit, exact placement instructions, and a post-insertion compliance check template.

---

## INPUT REQUIREMENTS

Provide:
1. **The copy piece** (or a detailed brief if not yet written) — type (VSL / letter / email / webinar), length, current structure
2. **The offer and core claims** — the specific beliefs that must survive competitor attacks and deepening skepticism
3. **The audience** — commitment level, sophistication, known doubts, competitor exposure context

Optionally provide:
- **Existing copy** — for audit and upgrade vs. starting from scratch
- **Attack surface data** — known competitor claims, negative review themes, sales call objections
- **Sequence context** — where this piece sits in a larger funnel (affects booster planning)

---

## EXECUTION PROCESS

### Step 1: Copy Type and Structure Assessment
Identify:
- Copy format and length (determines how many inoculation units the piece can support without overloading)
- Current argument structure (problem → mechanism → proof → offer, or other)
- Current objection-handling approach (if any) and where it sits in the piece

**Inoculation unit capacity guidelines:**
| Format | Typical Capacity |
|--------|----------------|
| Email (600-1000 words) | 1 inoculation unit |
| Long email / short letter (1000-2000 words) | 1-2 units |
| Full sales letter / VSL script (3000+ words) | 2-4 units |
| Webinar (60-90 min) | 3-5 units distributed across flow |

Exceeding capacity dilutes each individual inoculation effect and makes the copy feel defensive.

### Step 2: Vulnerability Moment Mapping
Walk the copy's argumentative structure and identify the points where reader vulnerability is highest — where the reader is most likely to feel doubt, form an objection, or be susceptible to external attack.

**Standard vulnerability moments:**
1. **Post-headline / pre-story** — "Is this another promise like all the others?"
2. **Post-mechanism reveal** — "Does this actually work for someone like me?"
3. **During/after social proof** — "These testimonials are cherry-picked"
4. **Pre-close** — "The price isn't worth it" / "This isn't the right time"
5. **Post-close / follow-up** — "I should have checked the competitors first" (booster territory)

### Step 3: Attack Prioritization
Call on refutational-preemption-builder output (or generate attack surface map inline):
- Identify the 2-4 most damaging attacks
- Rank by: (damage potential × probability of reader encounter at that vulnerability moment)
- Assign each attack to its corresponding vulnerability moment

### Step 4: Threat Calibration per Unit
For each assigned inoculation unit, call on threat-calibrator output (or generate inline):
- Audience commitment level at that point in the copy (increases as reader gets deeper)
- Required threat intensity
- Threat language (source + attack + vulnerability bridge)

### Step 5: Refutation Construction per Unit
For each unit:
- Mechanism-level refutation (not assertion — explains WHY the attack misunderstands the operating logic)
- Stress test: could a credible skeptic dismiss this refutation?
- Full combined passage (threat + refutation)

### Step 6: Placement and Integration Instructions
For each inoculation unit:
- Exact placement instruction (after paragraph X / before the social proof section / etc.)
- Transition language that connects it to the surrounding copy
- Format recommendation (inline paragraph / quasi-active rhetorical question / formal "I know what you're thinking" frame)

### Step 7: Post-Insertion Compliance Check Template
After insertion, run this check on each unit:
- [ ] Threat component present and felt (not merely implied)
- [ ] Threat precedes refutation (sequence confirmed)
- [ ] Refutation operates at mechanism level (not reassertion)
- [ ] Refutation passes stress test
- [ ] Unit integrates with surrounding copy (not a jarring interruption)
- [ ] Threat calibrated correctly (not too soft, not defensive-avoidance-inducing)
- [ ] Inoculation verdict: FULL TWO-COMPONENT INOCULATION confirmed

---

## OUTPUT STRUCTURE

**Section 1: Copy Assessment**
Format, length, current structure, existing objection-handling approach, inoculation unit capacity.

**Section 2: Vulnerability Moment Map**
The full map of where in this copy reader vulnerability peaks. Which moments warrant inoculation treatment vs. which are low-risk.

**Section 3: Inoculation Architecture Plan**
The complete assignment: attack → vulnerability moment → unit type → placement instruction. Presented as a prioritized table.

| Unit | Attack | Vulnerability Moment | Placement | Format | Priority |
|------|--------|---------------------|-----------|--------|----------|

**Section 4: Inoculation Units (Full Language)**
For each unit in order of placement:
- Unit name and target attack
- Threat component (calibrated language)
- Refutation component (mechanism-level)
- Combined passage (ready to insert)
- Placement instruction and transition language

**Section 5: Post-Insertion Compliance Checklist**
Formatted checklist for each unit. Run after insertion to confirm inoculation architecture is intact.

**Section 6: Upgrade Notes (if auditing existing copy)**
Current objection-handling sections reclassified as: Inoculation / Objection Handling / Broken. Specific upgrade instructions for each non-compliant section.

---

## OUTPUT FILE

Save complete blueprint to:
`[project-folder]/William McGuire - Inoculation Architecture/[Date] - Inoculation Blueprint - [Copy Piece Name].md`
