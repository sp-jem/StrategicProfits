---
name: festinger-dissonance-detector
description: Maps productive vs. toxic dissonance for buyer journey.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Leon Festinger (A Theory of Cognitive Dissonance, 1957; When Prophecy Fails, 1956) — Skill 1 of 7"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/festinger-dissonance-detector {offer, funnel, or customer journey to audit}"
  called_by: [user, festinger-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  rationale: "Market narratives shift, competitor positioning evolves, and buyer belief structures change as new information enters the category. Dissonance maps decay as the belief landscape shifts."
thaler_integration:
  feeds_from: [thaler-choice-architect, thaler-loss-aversion-audit]
  feeds_to: [thaler-nudge-auditor, thaler-mental-accounting]
  shared_data: "Thaler's choice architecture determines WHICH options the buyer faces. Festinger's dissonance theory explains the psychological aftermath OF facing those options. Every choice point in Thaler's architecture is a potential dissonance generator in Festinger's framework. Loss aversion (Thaler) is amplified when the buyer experiences dissonance between 'I should act' and 'acting means risking loss.' Mental accounts create dissonance when the same purchase could be assigned to different accounts with different emotional valuations."
ariely_integration:
  feeds_from: [ariely-predictability-auditor, ariely-honesty-calibrator]
  feeds_to: [ariely-expectation-architect, ariely-social-norms-detector]
  shared_data: "Ariely's systematic biases often function as dissonance reduction strategies. Self-herding (Ariely) is the behavioral consequence of dissonance avoidance — repeating past choices to avoid the dissonance of admitting the first choice was wrong. The honesty calibrator reveals where self-deception serves as dissonance reduction. Expectation effects (Ariely) create dissonance when experience contradicts expectation."
damasio_integration:
  feeds_from: [damasio-somatic-marker-audit, damasio-emotion-feeling-mapper]
  feeds_to: [damasio-body-loop-auditor, damasio-ecs-designer]
  shared_data: "Damasio reveals the BODILY experience of dissonance. Cognitive dissonance is not purely cognitive — it produces measurable physiological discomfort (increased skin conductance, muscle tension, autonomic arousal). Somatic markers from past dissonance experiences bias future decisions. The emotion-feeling mapper shows where dissonance registers at each tier: primary (physical discomfort), background (persistent unease), social (shame of inconsistency)."
girard_integration:
  feeds_from: [girard-model-map, girard-rivalry-detector]
  feeds_to: [girard-desire-propagation]
  shared_data: "Mimetic desire (Girard) creates dissonance when the buyer's model exhibits behavior inconsistent with the buyer's self-concept. 'My model bought this, but I believe I shouldn't' = dissonance. Rivalry intensifies dissonance by adding social stakes to every choice. The model map reveals WHOSE behavior creates the strongest dissonance pressure."
veblen_integration:
  feeds_from: [veblen-status-intelligence, veblen-signal-decoder]
  feeds_to: [veblen-price-ladder]
  shared_data: "Status signaling (Veblen) creates dissonance when the buyer's desired status conflicts with their current behavior. Purchasing to signal status creates dissonance if the buyer also holds beliefs about frugality or authenticity. The price ladder creates tiered dissonance — each price point triggers different magnitude of 'I want this status / I shouldn't spend this much' conflict."
bourdieu_integration:
  feeds_from: [bourdieu-habitus-profiler, bourdieu-distinction-mapper]
  feeds_to: [bourdieu-field-analyzer]
  shared_data: "Habitus (Bourdieu) is the internalized disposition system that determines which cognitions feel natural and which create dissonance. Class-specific habitus means the SAME offer creates different dissonance patterns for different social segments. Distinction operates through dissonance — choosing 'above your station' creates social dissonance; choosing 'below it' creates identity dissonance."
loewenstein_integration:
  feeds_from: [loewenstein-visceral-audit, loewenstein-empathy-gap-map]
  feeds_to: [loewenstein-risk-as-feelings]
  shared_data: "Visceral states (Loewenstein) amplify dissonance intensity. A buyer in a hot state experiences dissonance more acutely and resolves it more impulsively. The empathy gap means buyers cannot predict how much dissonance they'll experience in the actual purchase moment. Risk-as-feelings shows where emotional risk perception conflicts with cognitive risk assessment — a specific form of dissonance."
---

# Festinger Dissonance Detector

---

## LAYER 1: INVARIANTS (Never override.)

1. **Dissonance is MOTIVATIONAL, not merely informational.** When two cognitions conflict, the result is not a neutral "hmm, interesting" — it is a drive state as real as hunger or thirst. Festinger was explicit: dissonance creates psychological discomfort that the person is MOTIVATED to reduce, just as a physical drive motivates behavior. This means every dissonance point in a buyer journey is an engine — it is generating force. The only question is which direction that force pushes. A business that creates dissonance without controlling the resolution pathway has started a fire without knowing where the exits are.

2. **The buyer will take the EASIEST path to dissonance reduction — which is almost never the path the business wants.** Festinger identified four reduction strategies: change one cognition, add consonant cognitions, trivialize one of the conflicting cognitions, or change behavior. Of these, changing behavior (buying, committing, engaging) is almost always the HARDEST. Trivializing ("it's not that important") or adding consonant cognitions ("I'll do it later," "I'm not the right fit") is almost always easiest. If the business has not deliberately made the desired resolution pathway the path of least resistance, the buyer will resolve dissonance in a way that lets them walk away feeling fine about not acting.

3. **Free choice is the prerequisite — no choice, no dissonance.** Festinger's forced compliance studies demonstrated that when people feel coerced or constrained, dissonance is minimal. The buyer must feel they are FREELY choosing for dissonance to do its motivational work. This has a critical implication: high-pressure tactics that remove the feeling of free choice also remove the dissonance that would drive post-decision commitment. A buyer who feels forced into purchasing experiences minimal dissonance and therefore minimal post-purchase rationalization — which means minimal loyalty, minimal advocacy, and maximum buyer's remorse when the pressure fades.

4. **Magnitude depends on importance and ratio — trivial conflicts produce trivial motivation.** The strength of dissonance is determined by two factors: (a) how important the conflicting cognitions are to the person, and (b) the ratio of dissonant to consonant cognitions. A conflict between two peripheral beliefs creates negligible drive. A conflict that touches identity, core values, or significant financial commitment creates intense drive. The audit must assess magnitude, not just presence. A funnel that creates twenty small dissonance points may generate less total motivational force than one that creates a single identity-level collision.

5. **Post-decision dissonance is fundamentally DIFFERENT from pre-decision dissonance and requires different management.** Before a decision, dissonance can motivate approach OR avoidance — the buyer hasn't committed yet, so either resolution direction is available. After a decision, the buyer has ACTED, and the dissonance between "I chose this" and any doubts creates a strong drive toward self-justification. Post-decision dissonance is the engine of commitment escalation, brand loyalty, and advocacy — IF the business feeds it correctly. It is also the engine of buyer's remorse, refund requests, and negative word-of-mouth — IF the business neglects it. The same mechanism produces opposite outcomes depending on what happens in the first 48 hours after purchase.

6. **Dissonance reduction is usually INVISIBLE to the person experiencing it.** People do not say "I'm experiencing cognitive dissonance, so I'll rationalize my decision." They say "I thought about it more and realized this was the right choice" or "I did some research and decided it wasn't for me." The rationalization process operates below conscious awareness. This means buyer objections, stated reasons for not purchasing, and post-purchase satisfaction claims are all potentially dissonance reduction artifacts rather than accurate reports. The audit must look at STRUCTURAL patterns (what the journey makes easy to believe) rather than taking stated reasons at face value.

7. **Effort justification amplifies commitment.** Festinger's research (and the subsequent Aronson and Mills severity-of-initiation study) showed that the more effort or sacrifice someone expends to achieve something, the more they value the outcome. Difficult onboarding, challenging application processes, and high price points all create dissonance ("I worked hard/paid a lot for this") that resolves toward higher valuation ("therefore it must be worth it"). This is NOT an argument for making everything difficult — it is a principle about which friction to preserve and which to eliminate. Strategic friction at the right moment creates commitment. Random friction at the wrong moment creates abandonment.

---

## LAYER 2: QUALITY GUIDANCE

8. **Map the FULL belief structure before identifying conflicts.** A dissonance point cannot be assessed without knowing BOTH cognitions that are colliding. Most analyses jump straight to "the buyer might feel conflicted about the price." That's not a dissonance analysis — that's a guess. The audit must first inventory the buyer's actual belief structure (about themselves, the category, money, time, competence, and the specific offer), then systematically identify where those beliefs collide with offer signals, social proof, calls to action, and post-purchase experiences.

9. **Always specify WHOSE dissonance.** Different buyer segments carry different belief structures and therefore experience different dissonance at the same touchpoint. A first-time buyer encounters different conflicts than a returning customer. A high-income buyer feels different dissonance about price than a budget-constrained buyer. A skeptic experiences fundamentally different conflicts than a true believer. The audit must be specific about which buyer segment is experiencing which dissonance — not a generic "buyers might feel..."

10. **Rate every dissonance point on the Productive-Destructive spectrum.** Productive dissonance is dissonance where the easiest resolution pathway leads toward the desired business outcome (purchase, engagement, commitment, advocacy). Destructive dissonance is dissonance where the easiest resolution pathway leads away from the desired outcome (exit, rationalized inaction, regret, refund). Most journey touchpoints create a MIX of productive and destructive dissonance. The audit must classify each point and identify which direction the balance tips.

11. **Never recommend eliminating ALL dissonance.** A frictionless, conflict-free buyer journey produces no motivational force. The buyer floats through without commitment, without urgency, without the drive state that Festinger identified as the engine of attitude change. The goal is not zero dissonance — it is MANAGED dissonance where productive tension is deliberately created and destructive tension is deliberately defused or redirected. The best funnels feel like a series of small, manageable tensions that each resolve toward deeper commitment.

---

## PURPOSE

Every buyer journey is a dissonance landscape — a terrain of psychological tensions where beliefs collide with offer signals, past behavior conflicts with desired behavior, and the act of choosing itself creates motivational force. Most businesses build this landscape accidentally. They create dissonance they don't know about, leave resolution pathways they haven't considered, and then wonder why buyers who "should" convert don't — or why buyers who DO convert don't stick.

Festinger's cognitive dissonance theory provides the diagnostic framework. Given THIS buyer's belief structure, THESE offer signals, THIS sequence of touchpoints, and THESE decision points — where does dissonance arise? How intense is it? In which direction does it resolve? And is the business in control of that resolution, or is the buyer's path of least resistance leading somewhere the business doesn't want them to go?

This skill produces a complete Dissonance Detection Report: a map of every significant dissonance point in the buyer journey, classified by type, magnitude, direction, and available resolution pathways — with strategic recommendations for restructuring the dissonance architecture to drive commitment rather than abandonment.

---

## INPUT REQUIREMENTS

Provide:
1. **The system to audit** — offer, funnel, sales page, onboarding sequence, customer journey, or product ecosystem
2. **The buyer** — who is the target? What do they believe about themselves, this category, and this type of purchase? (If unknown, the audit will begin with a belief excavation step)
3. **Key decision points** — where the buyer must choose (opt in, purchase, select tier, stay/leave, renew, refer)
4. **Current performance signals** — conversion rates, drop-off points, refund rates, engagement decay, common objections, support tickets

Optional:
- Prior purchases or commitments (reveals self-herding and effort justification history)
- Competitor offers the buyer has seen (reveals external consonant/dissonant cognitions)
- Post-purchase feedback (reveals dissonance reduction language patterns)
- Onboarding/welcome sequence (reveals post-decision dissonance management)

---

## EXECUTION PROCESS

### Step 1: Belief Inventory

Before dissonance can be mapped, the conflicting cognitions must be identified. This step inventories the buyer's pre-existing belief structure across six domains:

**Self-beliefs:**
- What does the buyer believe about their own competence in this area?
- What is their identity narrative? ("I'm the kind of person who..." / "I'm not the kind of person who...")
- What is their track record narrative? ("I've tried things like this before and..." / "I've never been able to...")
- What commitments have they already made (to themselves or others) that this offer either supports or contradicts?

**Category beliefs:**
- What does the buyer believe about this type of product/service/program?
- What is their default expectation? (Works/doesn't work, worth it/waste of money, legitimate/scam)
- What past experiences have shaped these beliefs?
- What "everyone knows" assumptions operate in this category?

**Money beliefs:**
- What does the buyer believe about spending this amount?
- What mental account would this purchase be assigned to? (Investment in self, discretionary, necessity, luxury, gambling)
- What financial commitments compete with this purchase?
- Is there a "people like me spend/don't spend this much on X" belief operating?

**Time beliefs:**
- What does the buyer believe about the time required?
- Is there a "I don't have time for this" default narrative?
- What is their belief about time-to-results? (Instant, weeks, months, years, never)
- Does the time investment conflict with other commitments they've voiced?

**Trust beliefs:**
- What does the buyer believe about the seller/brand?
- What is their default trust posture? (Skeptical, open, burned before, first encounter)
- What signals have they received that confirm or violate their trust expectations?
- Is there a "too good to be true" cognition available?

**Social beliefs:**
- What would their peers think about this purchase?
- Is this purchase consistent with their social identity?
- Does buying require them to admit something to themselves or others? (A need, a failure, a desire they haven't acknowledged)
- What social proof has been presented, and does it match their reference group?

**For each belief:** Rate importance (1-5), confidence (how firmly held), and source (experience, social, assumption).

### Step 2: Dissonance Point Mapping

Walk through EVERY touchpoint in the buyer journey and identify where two or more cognitions from the belief inventory collide with offer signals, calls to action, social proof, pricing, or experiential elements.

**For each touchpoint, assess:**
- What cognitions does this touchpoint ACTIVATE? (Which beliefs does it bring to the surface?)
- What NEW cognitions does it INTRODUCE? (What new information or framing does it add?)
- Where do activated cognitions CONFLICT with each other or with introduced cognitions?
- Is the conflict between two beliefs, between a belief and a behavior, or between a belief and new information?

**Common dissonance triggers in buyer journeys:**

*Pre-purchase:*
- "I need this" vs. "I shouldn't spend this" (desire-frugality conflict)
- "This could work" vs. "Things like this haven't worked before" (hope-experience conflict)
- "I want to be the kind of person who acts" vs. "I'm the kind of person who researches more" (identity conflict)
- "The testimonials are compelling" vs. "Those people aren't like me" (social proof mismatch)
- "The price seems fair" vs. "I could get something similar for less" (value comparison conflict)
- "I should decide now" vs. "I make better decisions when I take my time" (urgency-deliberation conflict)

*At purchase:*
- "I'm choosing this" vs. "I'm giving up that money/alternative" (choice-loss conflict)
- "I'm committing" vs. "What if I'm wrong?" (commitment-uncertainty conflict)
- "This is important to me" vs. "What will [person] think?" (desire-social approval conflict)

*Post-purchase:*
- "I bought this" vs. "I haven't started it yet" (purchase-inaction conflict)
- "I paid $X" vs. "I'm not seeing $X worth of results yet" (investment-experience conflict)
- "I committed to change" vs. "I'm still doing things the old way" (commitment-behavior conflict)
- "I told people about this" vs. "Now I'm not sure it's working" (public commitment-doubt conflict)

**For each dissonance point:** Name the two conflicting cognitions explicitly. Do not use vague language like "they might feel conflicted." State: "Cognition A [specific belief] conflicts with Cognition B [specific belief or behavior signal]."

### Step 3: Magnitude Assessment

For each dissonance point identified in Step 2, assess the STRENGTH of the motivational force it creates:

**Importance factor:**
- How central are the conflicting cognitions to the buyer's identity? (Peripheral beliefs = low magnitude. Core identity beliefs = high magnitude.)
- How much is at stake? (Small financial commitment = low magnitude. Significant investment = high magnitude.)
- How public is the conflict? (Private deliberation = lower magnitude. Social visibility = higher magnitude.)

**Ratio factor:**
- How many consonant cognitions support one side? (Lots of evidence for purchasing + one doubt = lower dissonance. Balanced evidence = higher dissonance.)
- Has the business provided consonant cognitions to reduce dissonance? (Testimonials, guarantees, logical arguments all serve as consonant cognitions that reduce the ratio.)
- Are there external consonant cognitions the business hasn't accounted for? (A friend's negative review adds a dissonant cognition the business can't see.)

**Free choice factor:**
- Does the buyer feel they are choosing freely? (High-pressure countdown timers and "only 3 spots left" messaging can reduce the FEELING of free choice, which paradoxically reduces dissonance and therefore reduces post-purchase commitment.)
- Is the decision environment enabling genuine deliberation? (A buyer who feels railroaded experiences less dissonance — and therefore less lasting attitude change.)

**Proximity to action:**
- How close is this dissonance point to an actual decision? (Dissonance during browsing is abstract. Dissonance at the checkout page is visceral.)
- Is the buyer in a hot or cold state at this moment? (Hot states amplify experienced magnitude.)

**Rate each dissonance point:** LOW (peripheral beliefs, small stakes, many consonant cognitions), MEDIUM (moderately important beliefs, meaningful stakes, mixed evidence), HIGH (identity-level beliefs, significant stakes, few consonant cognitions), CRITICAL (core identity conflict with high public visibility and major financial commitment).

### Step 4: Resolution Pathway Analysis

For each dissonance point, map ALL available resolution pathways and assess which one the buyer is most likely to take:

**Pathway 1 — Change a belief:**
- Can the buyer change one of the conflicting beliefs? ("Maybe programs like this DO work" or "Maybe I CAN afford this")
- How difficult is this change? (Beliefs held for decades are harder to change than recent opinions)
- What would make this pathway easier? (Overwhelming evidence, trusted authority, personal experience)

**Pathway 2 — Change behavior:**
- Can the buyer change their behavior to match their beliefs? (Buying, committing, engaging, quitting)
- How difficult is this change? (One-click purchase is easy. Restructuring daily schedule is hard.)
- What would make this pathway easier? (Reduced friction, clear next step, social support)

**Pathway 3 — Add consonant cognitions:**
- Can the buyer add new information that reduces the conflict? ("Other smart people bought this" or "The guarantee means I can't really lose")
- How available are consonant cognitions? (Does the environment provide them, or must the buyer seek them out?)
- Is the business actively supplying consonant cognitions at this moment?

**Pathway 4 — Trivialize:**
- Can the buyer dismiss the importance of one cognition? ("It's not THAT much money" or "It's not THAT important that I change")
- How easy is it to trivialize? (Easier for peripheral beliefs, harder for identity-level commitments)
- Is the business accidentally making trivialization easy? (Weak urgency messaging makes it easy to trivialize the importance of acting now)

**For each dissonance point, determine:**
- Which pathway is EASIEST for the buyer right now?
- Is the easiest pathway the one the business wants? (If the easiest path is trivialization and the business wants behavior change, there's a structural problem.)
- What would need to change to make the DESIRED pathway the easiest one?

### Step 5: Productive vs. Destructive Classification

Classify each dissonance point on the Productive-Destructive spectrum:

**Productive dissonance (KEEP and manage):**
- The easiest resolution pathway leads toward the desired outcome
- The dissonance creates urgency, commitment, or engagement
- The tension feels resolvable through action (not through avoidance)
- Examples: "I know I need to change but I haven't yet" (drives purchase), "I paid for this so I should use it" (drives engagement), "I told my partner about this so I need to follow through" (drives commitment)

**Destructive dissonance (DEFUSE or redirect):**
- The easiest resolution pathway leads away from the desired outcome
- The dissonance creates anxiety, doubt, or paralysis rather than motivation
- The tension feels most resolvable through withdrawal or rationalization
- Examples: "This seems too good to be true" (drives skepticism and exit), "I can't justify this expense" (drives guilt and refund), "People like me don't buy things like this" (drives identity-based rejection)

**Mixed dissonance (RESTRUCTURE):**
- The dissonance could resolve in either direction depending on what happens next
- The balance is precarious — a single additional signal could tip it
- The business has an opportunity to influence direction but currently isn't
- Examples: "The testimonials are impressive but I'm not sure they're real" (could go either way depending on proof), "The price is high but the value might justify it" (depends on what evidence appears next)

**For each classification, specify:**
- Current direction (where is it naturally resolving?)
- Desired direction (where should it resolve?)
- Gap (how far apart are these?)
- Intervention opportunity (what touchpoint could redirect it?)

### Step 6: Dissonance Architecture Audit

Assess the OVERALL dissonance landscape — not just individual points, but the system:

**Escalation pattern:**
- Is dissonance escalating gradually (small tensions early, building to the major decision)? This is ideal — it acclimates the buyer to resolving dissonance toward commitment.
- Or is dissonance randomly distributed (major identity conflict on the landing page, trivial conflict at checkout)? This is dysfunctional — it creates whiplash.
- Is there a "dissonance cliff" — a sudden, massive increase in tension at one point? (Common at the pricing reveal or the CTA.) Cliffs cause abandonment.

**Cumulative load:**
- How much TOTAL dissonance is the buyer carrying by the time they reach the decision point?
- Is the cumulative load manageable (buyer feels challenged but capable of resolving) or overwhelming (buyer shuts down, abandons, or rage-quits)?
- Are there "relief points" — moments where tension is resolved before new tension is introduced? (Good architecture alternates tension and relief. Bad architecture just piles tension.)

**Resolution velocity:**
- How quickly can the buyer resolve each dissonance point?
- Are some points left unresolved for too long? (Unresolved dissonance accumulates anxiety. The buyer eventually resolves it by leaving.)
- Are consonant cognitions available at the RIGHT moments? (Testimonials after the price reveal, guarantees after the commitment ask, welcome confirmation after the purchase)

**Post-decision architecture:**
- What happens to dissonance AFTER the buyer commits?
- Is the business feeding post-decision dissonance with confirmation and reinforcement? (Welcome emails, quick wins, community belonging)
- Or is the business neglecting post-decision dissonance, leaving the buyer alone with their doubts? (Silence after purchase is the leading cause of buyer's remorse.)

**Effort justification design:**
- Where does the journey require meaningful effort from the buyer?
- Is that effort positioned BEFORE the commitment (builds dissonance that drives "I've come this far" commitment) or AFTER (builds "I've invested too much to quit" retention)?
- Is there unnecessary friction that creates effort without corresponding justification? (Buggy checkout, confusing navigation, unclear next steps — effort that feels WASTED rather than invested)

### Step 7: Cross-Thinker Integration

Synthesize the dissonance map with findings from other thinker systems (where available):

**Damasio Integration — The Body's Dissonance:**
- Where does dissonance register somatically? (Chest tightness at the price reveal, gut feeling of "something's off," excitement that conflicts with anxiety)
- Which somatic markers from past dissonance experiences are biasing current decisions?
- How does the emotion-feeling hierarchy process dissonance? (Primary: physical discomfort. Background: persistent unease. Social: shame of inconsistency)
- Are there body-loop shortcuts where dissonance triggers automatic avoidance without conscious deliberation?

**Ariely Integration — Biases as Dissonance Reduction:**
- Where is self-herding functioning as dissonance avoidance? (Repeating past behavior to avoid admitting error)
- Where do predictable biases serve as dissonance reduction strategies? (Anchoring to the first price seen to avoid the dissonance of complex value calculation)
- Where does the honesty calibrator reveal self-deception operating as dissonance reduction?
- How do expectation effects create dissonance when experience contradicts what was promised?

**Thaler Integration — Choice Architecture as Dissonance Generator:**
- Which choice points in Thaler's architecture generate the most dissonance?
- How do defaults interact with dissonance? (Opting out of a default creates more dissonance than opting in to a choice)
- Where does loss aversion amplify dissonance? ("I should act" vs. "acting means risking loss")
- Which mental accounts create dissonance when the same purchase could be categorized differently?

**Girard Integration — Mimetic Dissonance:**
- Where does mimetic desire create dissonance? ("My model owns this but my self-concept says I shouldn't")
- Where does rivalry intensify dissonance by adding social stakes?
- How does the model map reveal whose behavior creates the strongest dissonance pressure?
- Where is the buyer resolving mimetic dissonance through imitation vs. through differentiation?

**Loewenstein Integration — Visceral Amplification:**
- Where do visceral states amplify dissonance intensity?
- Which empathy gaps mean the buyer cannot predict their own dissonance experience?
- Where does risk-as-feelings create dissonance between emotional risk perception and cognitive risk assessment?
- How does curiosity create productive dissonance? (Information gap = "I don't know" vs. "I want to know")

**Veblen Integration — Status Dissonance:**
- Where does desired status conflict with current behavior or financial reality?
- Where does conspicuous consumption create dissonance with authenticity beliefs?
- How does the price ladder create tiered dissonance at each level?
- Where is status anxiety functioning as a dissonance driver?

**Bourdieu Integration — Habitus Dissonance:**
- Which internalized dispositions determine which cognitions feel natural vs. foreign?
- Where does the same offer create different dissonance patterns for different social segments?
- Where does distinction create dissonance? (Aspiring above one's station vs. choosing below it)
- How does cultural capital interact with the perceived legitimacy of the offer?

### Step 8: Strategic Recommendations

Synthesize all findings into prioritized interventions:

**For each recommendation:**
- **Dissonance point:** Which specific conflict this addresses (name both cognitions)
- **Current resolution pathway:** How the buyer is currently resolving this conflict
- **Desired resolution pathway:** How the business wants the buyer to resolve it
- **Structural change:** The specific intervention (copy change, sequence change, element addition, touchpoint redesign)
- **Mechanism in Festinger's terms:** WHY this change works — which dissonance principle it leverages (magnitude adjustment, pathway restructuring, consonant cognition addition, effort justification design, free choice preservation)
- **Expected impact:** Direction and estimated magnitude of change
- **Implementation difficulty:** Easy (copy/messaging change) / Medium (sequence restructure) / Hard (fundamental offer or journey redesign)
- **Priority:** Impact x ease ranking (1 = highest priority)

**Recommendation categories:**

*Quick fixes (implement immediately):*
- Adding consonant cognitions at high-dissonance moments (testimonials, guarantees, social proof)
- Removing accidental dissonance triggers (confusing messaging, contradictory signals)
- Improving post-decision dissonance management (confirmation emails, quick wins, welcome sequences)

*Structural improvements (implement within 30 days):*
- Redesigning dissonance escalation sequence (gradual build vs. random spikes)
- Adding relief points between tension moments
- Restructuring effort justification placement (strategic friction before commitment, removed friction after)

*Architecture changes (implement within 90 days):*
- Redesigning the overall dissonance architecture (escalation pattern, cumulative load management, resolution velocity)
- Rebuilding the post-decision reinforcement system
- Creating segment-specific dissonance pathways for different buyer belief structures

---

## OUTPUT STRUCTURE

### Dissonance Detection Report

**Section 1: Belief Inventory**
Complete map of the target buyer's belief structure across all six domains (self, category, money, time, trust, social), with importance and confidence ratings for each belief. Identifies the beliefs most likely to generate dissonance when they collide with offer elements.

**Section 2: Dissonance Point Map**
Every significant dissonance point in the buyer journey, organized chronologically by touchpoint. For each: the two conflicting cognitions named explicitly, the trigger (what creates the collision), and the type of dissonance (belief-belief, belief-behavior, belief-information).

**Section 3: Magnitude Assessment**
Each dissonance point rated LOW / MEDIUM / HIGH / CRITICAL with supporting analysis across all four magnitude factors (importance, ratio, free choice, proximity to action). Highlights the 3-5 highest-magnitude dissonance points that dominate the buyer's experience.

**Section 4: Resolution Pathway Analysis**
For each significant dissonance point: all four resolution pathways mapped with difficulty assessment, the EASIEST pathway identified, comparison to the DESIRED pathway, and specific interventions to align the two.

**Section 5: Productive vs. Destructive Classification**
Each dissonance point classified with current direction, desired direction, gap assessment, and intervention opportunity. Summary statistics: how many productive vs. destructive vs. mixed dissonance points exist in the current journey.

**Section 6: Dissonance Architecture Assessment**
Overall system-level analysis: escalation pattern, cumulative load, resolution velocity, post-decision architecture, and effort justification design. Identifies systemic issues that no single-point fix can address.

**Section 7: Cross-Thinker Synthesis**
Integration findings from all available thinker systems. Where dissonance interacts with somatic markers (Damasio), predictable biases (Ariely), choice architecture (Thaler), mimetic desire (Girard), visceral states (Loewenstein), status signaling (Veblen), and habitus dispositions (Bourdieu). Only includes thinkers whose data is available for this specific analysis.

**Section 8: Strategic Recommendations**
All interventions prioritized by impact and implementation ease. Organized into quick fixes, structural improvements, and architecture changes. Each recommendation traces back to a specific dissonance point, names the mechanism in Festinger's terms, and specifies the expected outcome.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Leon Festinger - Dissonance Detector/01 - Dissonance Detection Report - [System Name] - [Date].md`
