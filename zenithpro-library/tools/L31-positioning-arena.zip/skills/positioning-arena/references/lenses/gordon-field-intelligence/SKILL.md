---
name: gordon-field-intelligence
description: Meta-synthesis across all Gordon skills. Finds The Single Move.
version: 1.0.0
author: Strategic Profits / Hollywood Agents & Dealmakers Series
source_thinker: "Shep Gordon (Fame Manufacturing & Category Creation)"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/gordon-field-intelligence {client-or-project-name}"
  called_by: [user]
  calls: [gordon-fame-engineer, gordon-room-strategist, gordon-controversy-calculator, gordon-cross-pollination-mapper, gordon-perception-sequencer, gordon-category-architect]
  outputs_to: [client-output-folder]
---

# Gordon Field Intelligence

---

## LAYER 1: INVARIANTS (Never override.)

1. **Freshness gate: only synthesize current outputs.** Every skill output has a date. If any skill output is older than 30 days, flag it as stale and recommend re-running that skill before synthesis. Do NOT synthesize stale intelligence --- it produces false convergence. If more than 2 skill outputs are stale, abort synthesis and recommend a full refresh.

2. **Convergence threshold: 3+ signals required.** A convergence zone is only valid when 3 or more Gordon skill outputs independently point to the same move, opportunity, or target. Two signals are a hypothesis. Three are a pattern. Below 3, report it as "emerging signal" not "convergence." Never present a 2-signal finding as high-confidence.

3. **Conflicts are resolved, not listed.** When two skill outputs contradict each other (e.g., controversy-calculator says "no controversy" but fame-engineer includes controversy in the sequence), the field intelligence must RESOLVE the conflict with a reasoned judgment. Listing "Skill A says X, Skill B says Y" without resolution is a failure state. Take a position and justify it.

4. **The Single Move must satisfy 3+ skill outputs.** The final recommendation --- The Single Move --- must be an action that advances the recommendations of at least 3 different skill outputs simultaneously. If no single action satisfies 3+ outputs, the skills are not converging and the client needs to choose a strategic direction before synthesis is meaningful.

5. **Gordon's methodology is the tiebreaker.** When conflicts between skill outputs cannot be resolved by evidence alone, default to Gordon's core principles: (a) manufacture the perception before the reality, (b) opposition validates faster than endorsement, (c) value flows to the gatekeeper first, (d) amplify what's different don't normalize it, (e) category ownership is the only acceptable endpoint. These principles override any individual skill's recommendation.

---

## LAYER 2: QUALITY GUIDANCE

6. **Weight recent outputs more heavily.** When multiple outputs exist from the same skill (re-runs), the most recent output carries more weight. But note when older outputs contained insights that newer ones dropped --- this may indicate a missed signal.

7. **Cross-skill contradictions are often the most valuable findings.** When fame-engineer and room-strategist disagree on approach, the tension between them often reveals a strategic choice the client hasn't consciously made. Surface these as strategic decisions, not just conflicts to resolve.

8. **The synthesis must be shorter than the sum of its inputs.** Field intelligence is distillation, not compilation. If the report is longer than the average individual skill output, it's not synthesizing --- it's concatenating. Cut harder.

---

## PURPOSE

Performs meta-synthesis across all 6 Gordon skill outputs to find where multiple analytical lenses converge on the same strategic move. Individual skills see the client through one lens --- fame manufacturing, room strategy, controversy potential, cross-pollination opportunities, perception sequencing, or category architecture. Field intelligence sees where these lenses overlap and identifies the moves that multiple lenses recommend simultaneously.

**Why this matters:** The highest-leverage moves are the ones that advance multiple strategic objectives at once. A single event that manufactures fame (fame-engineer), gets the right people in a room (room-strategist), creates controlled controversy (controversy-calculator), AND advances the perception sequence (perception-sequencer) is exponentially more valuable than four separate actions. Field intelligence finds those multi-lens moves.

---

## EXECUTION PROCESS

### Step 1: Freshness Audit
Read all available Gordon skill outputs for this client/project:

| Skill | Output Date | Age | Status |
|-------|------------|-----|--------|
| gordon-fame-engineer | | | Fresh/Stale |
| gordon-room-strategist | | | Fresh/Stale |
| gordon-controversy-calculator | | | Fresh/Stale |
| gordon-cross-pollination-mapper | | | Fresh/Stale |
| gordon-perception-sequencer | | | Fresh/Stale |
| gordon-category-architect | | | Fresh/Stale |

**If 3+ outputs are stale:** ABORT. Recommend re-running stale skills first.
**If 1-2 outputs are stale:** Flag but proceed. Note reduced confidence.
**If any skill has no output:** Note the gap. Synthesize available outputs only.

### Step 2: Key Recommendation Extraction
From each fresh skill output, extract:
1. The primary recommendation (The One Move / The Single Move / First Action)
2. The target identified (person, company, domain, audience)
3. The mechanism recommended (event, deal, association, controversy, etc.)
4. The timeline suggested

### Step 3: Convergence Mapping
Cross-reference all extracted recommendations:

**Convergence Zone Detection:**
- Where do 3+ skills recommend the same TARGET?
- Where do 3+ skills recommend the same MECHANISM?
- Where do 3+ skills recommend the same TIMING?
- Where do 3+ skills identify the same OBSTACLE?

For each convergence zone found:
- List the contributing skills (minimum 3)
- Describe what they converge on
- Rate confidence: Strong (4+ skills), Moderate (3 skills)

### Step 4: Conflict Resolution
For each conflict between skill outputs:
1. **The conflict:** What Skill A recommends vs. what Skill B recommends
2. **The root cause:** Why these skills see the situation differently
3. **The resolution:** Which recommendation prevails and why
4. **The Gordon tiebreaker:** If needed, which core Gordon principle resolves this
5. **The strategic choice:** What underlying decision does this conflict reveal

### Step 5: The Single Move
Identify the one action that satisfies 3+ skill outputs simultaneously:
1. **The action:** Exactly what to do
2. **Skills satisfied:** Which 3+ skill recommendations this advances
3. **Why this action:** The convergence logic
4. **What it sets up:** What becomes possible after this move
5. **Timeline:** When to execute and what the first 48 hours look like

---

## OUTPUT STRUCTURE

### The Gordon Field Intelligence Report

**Section 1: Intelligence Status**
- Freshness audit results
- Gaps in coverage (missing skill outputs)
- Overall confidence level

**Section 2: Convergence Zones**
- Each convergence zone with contributing skills
- Confidence rating per zone
- The strategic implication of each convergence

**Section 3: Conflicts Resolved**
- Each conflict identified, root cause, and resolution
- Strategic choices surfaced
- Gordon principles applied as tiebreakers

**Section 4: Emerging Signals**
- 2-signal findings that don't meet convergence threshold
- What additional skill run would confirm or deny each signal

**Section 5: The Single Move**
- The one action that satisfies 3+ skill outputs
- Full justification with convergence logic
- 48-hour execution blueprint
- What to watch for (success indicators and warning signs)

---

## SAVE LOCATION
Save output to: `Active-Brain/00 Projects/01 Behavioral Intelligence/Hollywood Agents/Category 1 - The Fame Engineers/Shep Gordon/Field Intelligence/`
Filename: `XX - Gordon Field Intelligence Report - [Client-or-Project] - [Date].md`
