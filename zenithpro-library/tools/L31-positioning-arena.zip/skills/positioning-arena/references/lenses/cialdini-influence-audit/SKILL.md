---
name: cialdini-influence-audit
description: Audit all 7 influence principles across the customer journey.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Robert Cialdini (Influence, 1984/2021; Pre-Suasion, 2016) — Skill 1 of 7"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/cialdini-influence-audit {offer-or-journey-description}"
  called_by: [user, cialdini-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 60
  reason: "Influence dynamics shift as offers evolve, new competitors enter, and audience sophistication changes. Scarcity claims expire. Social proof ages. Authority positioning erodes or strengthens. Reassess quarterly minimum."
thaler_integration:
  feeds_from: [thaler-choice-architect, thaler-nudge-auditor]
  feeds_to: [thaler-default-detector]
  shared_data: "Nudges and influence principles are complementary tools — Thaler designs the choice environment, Cialdini identifies the psychological forces operating within it. Defaults work through commitment/consistency: once someone is IN the default, consistency pressure keeps them there. Choice architecture can amplify or suppress each influence principle — a poorly structured choice set can neutralize even strong social proof or authority signals."
ariely_integration:
  feeds_from: [ariely-predictability-auditor, ariely-social-norms-detector]
  feeds_to: [ariely-expectation-architect]
  shared_data: "Social norms from Cialdini's social proof interact with Ariely's market norms vs. social norms distinction — introducing money into a social-norm relationship destroys the social proof dynamic. Ariely's anchoring IS a form of pre-suasion: the first number encountered sets the frame for all subsequent evaluations. Predictable irrationality patterns determine which influence principles are most effective at each decision point."
damasio_integration:
  feeds_from: [damasio-somatic-marker-audit, damasio-emotion-feeling-mapper]
  feeds_to: [damasio-body-loop-auditor]
  shared_data: "Each influence principle triggers a specific somatic response — reciprocity creates a bodily felt obligation, scarcity creates anxiety and urgency in the gut, social proof creates comfort and safety, authority triggers deference patterns. The principles work because they activate embodied emotional responses, not just cognitive evaluations. Damasio's somatic marker theory explains WHY influence principles bypass rational analysis."
girard_integration:
  feeds_from: [girard-model-map, girard-desire-propagation]
  feeds_to: [girard-mimetic-content-strategist]
  shared_data: "Social proof IS mimetic desire in action — people want what others want. But Girard reveals that the MODEL matters more than the number: one high-status mimetic model can outweigh thousands of testimonials. Unity (Cialdini's 7th principle) maps to Girard's in-group desire dynamics — we imitate those we identify WITH, not just those we admire. Influence audit must assess mimetic quality, not just quantity."
veblen_integration:
  feeds_from: [veblen-signal-decoder, veblen-status-intelligence]
  feeds_to: [veblen-display-map]
  shared_data: "Authority and scarcity are status signals in Veblen's framework — authority claims position the seller in a status hierarchy, scarcity signals exclusivity. But Veblen reveals the trap: conspicuous authority displays can trigger skepticism in sophisticated markets. The influence audit must assess whether authority and scarcity signals match the status expectations of the target market segment."
bourdieu_integration:
  feeds_from: [bourdieu-habitus-profiler, bourdieu-field-analyzer]
  feeds_to: [bourdieu-capital-audit]
  shared_data: "Habitus determines which influence principles resonate most — high cultural capital audiences respond to authority differently than mass-market audiences. Social proof from mismatched habitus groups can REDUCE influence rather than increase it. Bourdieu's field analysis reveals the power dynamics that determine whether authority claims are accepted or contested within a specific market field."
loewenstein_integration:
  feeds_from: [loewenstein-visceral-audit, loewenstein-anticipation-engine]
  feeds_to: [loewenstein-risk-as-feelings]
  shared_data: "Visceral states amplify influence principles — scarcity is more powerful when anxiety is already elevated, social proof is more compelling when uncertainty is high, reciprocity obligations feel stronger when gratitude is viscerally present. Loewenstein's empathy gap means people in cool states underestimate how powerfully influence principles will affect them in hot states. The audit must assess emotional context at each influence deployment point."
festinger_integration:
  feeds_from: [festinger-dissonance-detector, festinger-commitment-architect]
  feeds_to: [festinger-belief-behavior-sequencer]
  shared_data: "Commitment/consistency IS cognitive dissonance avoidance — once committed, people experience dissonance when acting inconsistently. Festinger's theory explains the MECHANISM behind Cialdini's commitment principle. The influence audit must identify where dissonance is being created productively (driving consistency toward purchase) vs. destructively (creating buyer's remorse or defensive rationalization)."
barthes_integration:
  feeds_from: [barthes-myth-decoder, barthes-connotation-mapper]
  feeds_to: [barthes-ideology-auditor]
  shared_data: "Every influence principle operates through connotation, not just denotation — authority isn't just credentials, it's the MYTH of expertise. Social proof isn't just numbers, it's the cultural narrative of crowd wisdom. Barthes reveals that influence principles work because they activate pre-existing cultural myths. The audit must assess whether the mythological layer supports or undermines each principle's deployment."
mcluhan_integration:
  feeds_from: [mcluhan-medium-audit, mcluhan-hot-cool-strategist]
  feeds_to: [mcluhan-tetrad-analyzer]
  shared_data: "The medium shapes which influence principles dominate — hot media (high definition, low participation) amplify authority and scarcity; cool media (low definition, high participation) amplify social proof and liking. A video testimonial (hot) delivers social proof differently than a community discussion (cool). McLuhan reveals that choosing the wrong medium for an influence principle can neutralize it entirely."
mccracken_integration:
  feeds_from: [mccracken-meaning-flow-mapper, mccracken-celebrity-meaning-mapper]
  feeds_to: [mccracken-ritual-architect]
  shared_data: "Authority and liking operate through meaning transfer — the authority figure transfers meaning to the product, not just credibility. McCracken's meaning movement model explains why celebrity endorsement (authority + liking) works: it moves culturally constituted meaning from the endorser to the product. The influence audit must assess what meanings are being transferred through each authority and liking deployment."
rogers_integration:
  feeds_from: [rogers-adoption-curve-mapper, rogers-innovation-attributes-auditor]
  feeds_to: [rogers-communication-channel-strategist]
  shared_data: "Different positions on the adoption curve respond to different influence principles — innovators respond to scarcity and authority; early majority responds to social proof and commitment consistency; laggards respond to unity and social proof from similar others. Rogers reveals that the influence principle mix must shift as adoption progresses. The audit must map influence deployment to adoption stage."
granovetter_integration:
  feeds_from: [granovetter-threshold-analyzer, granovetter-weak-ties-mapper]
  feeds_to: [granovetter-cascade-architect]
  shared_data: "Social proof triggers cascade dynamics — once enough people adopt, threshold effects kick in and adoption accelerates without additional influence effort. Granovetter's threshold model explains when social proof reaches critical mass. Weak ties spread social proof further than strong ties. The influence audit must assess whether social proof deployment is reaching cascade thresholds or falling short."
barabasi_integration:
  feeds_from: [barabasi-hub-mapper, barabasi-preferential-attachment-auditor]
  feeds_to: [barabasi-network-strategy-designer]
  shared_data: "Authority in networks follows preferential attachment — the more authority a node has, the more it accumulates. Hub dynamics mean that one well-connected authority endorsement can reach more people than thousands of peripheral social proof instances. Barabasi reveals that influence deployment should prioritize network hubs over broadcast reach. The audit must assess network position of authority and social proof sources."
fogg_integration:
  feeds_from: [fogg-behavior-mapper, fogg-motivation-wave-strategist]
  feeds_to: [fogg-prompt-designer]
  shared_data: "Cialdini's principles primarily increase Motivation in Fogg's B=MAP model — reciprocity motivates through obligation, scarcity motivates through loss aversion, authority motivates through trust. But motivation alone doesn't produce behavior; ability and prompts must also be present. A perfectly deployed influence principle fails if the action is too difficult or the prompt is missing. The audit must assess whether influence gains are being lost to ability barriers."
lewin_integration:
  feeds_from: [lewin-force-field-analyzer, lewin-restraining-force-auditor]
  feeds_to: [lewin-unfreeze-architect]
  shared_data: "Cialdini's principles are specific forces in Lewin's field — social proof is a driving force, authority reduces uncertainty (a restraining force), scarcity creates time pressure (driving force), commitment/consistency creates momentum (driving force that increases over time). The force field framework shows how influence principles interact as a system of forces. Removing restraining forces (Lewin's insight) is often more effective than adding driving forces (more influence)."
---

# Cialdini Influence Audit

---

## LAYER 1: INVARIANTS (Never override.)

1. **All 7 principles must be assessed — no exceptions.** Reciprocity, Commitment/Consistency, Social Proof, Liking, Authority, Scarcity, and Unity. Skipping any principle creates a blind spot. Most businesses over-deploy 2-3 principles while completely neglecting 3-4 others. The audit must reveal the COMPLETE influence landscape, including principles that are absent.

2. **Every principle must be assessed in BOTH directions — helping AND hurting.** Each principle can work FOR or AGAINST the business. Fake scarcity destroys trust. Social proof from dissimilar sources reduces confidence. Authority without vulnerability admission triggers skepticism. The audit must identify where each principle is accidentally working against the business, not just where it's present or absent.

3. **Interaction effects between principles are as important as individual principle strength.** Principles don't operate in isolation. Authority + social proof is more powerful than either alone. Scarcity + commitment/consistency creates urgency that locks in. Reciprocity + liking builds deep relationship. But contradictory deployments cancel each other out — e.g., heavy scarcity pressure undermines the trust that liking and authority build.

4. **The ethical test must be applied to every principle deployment.** Cialdini's standard: does applying the principle reveal a REAL feature the prospect would want to know about? If the scarcity is real, communicating it is ethical. If manufactured, it's manipulation. The audit must flag every deployment where the principle creates a FALSE impression rather than revealing a true one.

5. **The customer journey is the unit of analysis, not individual touchpoints.** A principle might be strong at one touchpoint but absent at the adjacent one. The audit must map influence across the ENTIRE journey — from first awareness through post-purchase — to reveal gaps, contradictions, and accumulation effects.

6. **Absence of a principle is a finding, not a blank.** If Unity is completely absent from the journey, that IS the finding — the business has no identity-level belonging structure, and that's a specific, addressable gap.

---

## LAYER 2: QUALITY GUIDANCE

7. **Rate each principle 0-10 at each journey stage.** This creates a visual influence heatmap that immediately reveals where the journey is influence-rich and influence-poor. A journey that's all scarcity and no reciprocity is visible at a glance.

8. **Identify the business's "influence personality."** Every business has a default influence style — usually overusing 2-3 principles (typically scarcity and authority) while neglecting others (typically reciprocity and unity). Name this pattern explicitly.

9. **Compare to the ideal influence mix for this market.** Different markets respond to different principle weightings. B2B = authority + commitment/consistency heavy. Community = unity + social proof heavy. Premium = scarcity + authority heavy. The recommendations must be market-appropriate.

---

## PURPOSE

Every business deploys influence — the question is whether it's deployed intentionally, comprehensively, and ethically. Most businesses stumble into 2-3 principles (usually scarcity and authority because they're the most obvious) while leaving 4-5 principles completely untapped. Worse, many businesses deploy principles in ways that actively work against them: manufactured scarcity that erodes trust, authority claims without the vulnerability that makes them credible, social proof from the wrong sources.

Cialdini identified 7 principles because they represent 7 distinct psychological mechanisms. Each addresses a different question the prospect is unconsciously asking: Do I owe something? (Reciprocity) Is this consistent with who I am? (Commitment) What are others doing? (Social Proof) Do I like/trust this person? (Liking) Is this person credible? (Authority) Will I miss out? (Scarcity) Is this my group? (Unity). A business that only answers 2-3 of these questions leaves 4-5 unanswered — and unanswered questions default to "no."

---

## INPUT REQUIREMENTS

Provide:
1. **The system to audit** — offer, funnel, customer journey, or complete business system
2. **Key decision points** — where buyers make choices (opt-in, purchase, tier selection, upsell, renewal)
3. **Current influence tactics** — what's currently deployed (testimonials, guarantees, deadlines, bonuses, etc.)

Optional:
- Conversion data at each stage (reveals where influence is weakest)
- Customer feedback/objections (reveals which principles are failing)
- Competitor comparison (reveals relative influence strength)

---

## EXECUTION PROCESS

### Step 1: Reciprocity Audit

Map every reciprocity element across the journey:

**What is given:**
- Free content, lead magnets, tools, assessments, consultations
- Concessions ("I was going to charge X, but...")
- Information gifts (genuine insights vs. teasers)

**Reciprocity quality assessment:**
- Does the gift feel GENUINE or obligatory? (Genuine gifts trigger stronger reciprocity)
- Is the gift USEFUL or just voluminous? (A single powerful insight > 47-page PDF of filler)
- Is the gift personalized or mass-produced? (Personalization amplifies reciprocity)
- Three forms: material (tangible value), concession (giving ground), information (knowledge gift)

**Reciprocity timing:**
- When is reciprocity triggered relative to the ask?
- Is there sufficient gap between gift and request? (Immediate ask feels transactional)
- Is reciprocity accumulating across the journey or deployed as a single burst?

### Step 2: Commitment & Consistency Audit

Map the commitment ladder from first touch to full adoption:

**Current commitments requested:**
- Micro-commitments: email opt-in, quiz completion, content consumption
- Medium commitments: webinar attendance, consultation booking, trial activation
- Major commitments: purchase, enrollment, long-term contract

**Commitment quality:**
- Are commitments ACTIVE (buyer does something) or passive (buyer agrees)?
- Are commitments PUBLIC (visible to others) or private?
- Are commitments EFFORTFUL (requiring work) or easy?
- Active + public + effortful = hardest to abandon (Cialdini's finding)

**Consistency gaps:**
- Where does the journey BREAK consistency? (Different messaging, contradictory positioning)
- Where does the buyer's self-image shift between touchpoints?
- Is there an identity thread connecting early actions to the final purchase?

### Step 3: Social Proof Audit

Map every social proof element:

**Proof inventory:**
- Testimonials (text, video, case studies)
- Numbers (customers served, results achieved, community size)
- Expert endorsements, media mentions, certifications
- Peer behavior signals (enrollment counts, waitlists, community activity)

**Proof-prospect SIMILARITY assessment (Cialdini's key finding):**
- Do proof sources look like the prospect? (Same industry, same stage, same challenges)
- Similarity outperforms fame — one testimonial from a peer > one endorsement from a celebrity
- Are proof sources diverse enough to cover different prospect segments?
- Where is social proof coming from DISSIMILAR sources? (This can reduce influence)

**Proof placement:**
- Is social proof present at every decision point?
- Is proof type matched to decision type? (Peer proof for purchase, expert proof for credibility)
- Is proof VISIBLE or buried? (Testimonials at the bottom of the page = wasted proof)

### Step 4: Liking & Authority Audit

**Liking factors:**
- Similarity signals: Does the messenger share characteristics with the audience?
- Compliments: Is the audience genuinely acknowledged? (Not flattery — authentic respect)
- Cooperation: Is the relationship framed as "us together" or "me selling to you"?
- Association: Is the brand associated with things the audience already likes?

**Authority factors:**
- Expertise signals: Credentials, track record, specialized knowledge
- Trustworthiness signals: Vulnerability admission, acknowledging limitations, honesty about downsides
- Cialdini's vulnerability admission strategy: Mentioning a weakness BEFORE strengths dramatically increases credibility
- Is authority EARNED through demonstration or CLAIMED through assertion?

### Step 5: Scarcity & Unity Audit

**Scarcity assessment:**
- What scarcity is deployed? (Limited time, limited quantity, limited access)
- Is the scarcity REAL? (Cialdini's ethical test: scarcity must reflect genuine limitation)
- Is the scarcity BELIEVABLE? (Market-savvy audiences detect false scarcity instantly)
- Loss framing: Is the offer framed as what the prospect will LOSE by not acting?
- Scarcity + uniqueness: What makes this available ONLY here, ONLY now?

**Unity assessment:**
- Is there identity-level belonging? ("We" language, not just "people like you")
- Being together: shared identity, shared values, shared enemy
- Acting together: co-creation, participation, collaborative experiences
- Does the audience feel they ARE part of a group, or just similar to one?

### Step 6: Journey Integration Map

Create a principle × journey stage matrix:

- Rate each principle 0-10 at each stage (Awareness, Consideration, Decision, Post-Purchase)
- Identify influence-rich zones (multiple principles strong) and influence-poor zones (gaps)
- Map principle interactions (where they amplify or cancel each other)
- Identify the business's "influence personality" (which principles it defaults to)

### Step 7: Ethical Assessment

For each deployed principle:
- Does it reveal a REAL feature? (Ethical) Or create a false impression? (Manipulation)
- Would the prospect THANK you for this if they understood what you were doing?
- Does this build long-term trust or extract short-term compliance?
- Flag every deployment that fails Cialdini's ethical test

### Step 8: Strategic Recommendations

Synthesize all findings into prioritized actions:

For each recommendation:
- **Principle addressed:** Which of the 7
- **Current state:** How it's currently operating (absent / weak / strong / counterproductive)
- **Recommended change:** Specific structural fix
- **Mechanism:** Why this change works (in Cialdini's terms)
- **Expected impact:** Direction and rough magnitude
- **Implementation difficulty:** Easy / Medium / Hard
- **Priority:** Impact x ease ranking

---

## OUTPUT STRUCTURE

### Influence Architecture Audit Report

**Section 1: Reciprocity Assessment**
Gift inventory, quality, timing, and reciprocity gap analysis.

**Section 2: Commitment & Consistency Assessment**
Commitment ladder map, quality assessment, and consistency gap identification.

**Section 3: Social Proof Assessment**
Proof inventory, similarity scoring, placement analysis, and effectiveness rating.

**Section 4: Liking & Authority Assessment**
Liking factors, authority signals, vulnerability admission assessment, and credibility rating.

**Section 5: Scarcity & Unity Assessment**
Scarcity reality check, loss framing assessment, unity structure evaluation.

**Section 6: Journey Integration Heatmap**
Principle x stage matrix with interaction effects.

**Section 7: Ethical Assessment**
Every principle deployment rated against Cialdini's ethical standard.

**Section 8: Cross-System Integration**
If other thinker data exists: How do influence principles interact with choice architecture (Thaler), predictable irrationality (Ariely), somatic markers (Damasio), mimetic desire (Girard), and behavioral forces (Lewin)?

**Section 9: Strategic Recommendations**
All interventions prioritized by impact and implementation ease.

**Section 10: Influence Personality Profile**
The business's default influence style named and characterized, with specific recommendations for rebalancing toward a more complete principle deployment across the journey.

---

## IMPORTANT NOTES

- The audit should be conducted from the PROSPECT'S perspective, not the business's. What the business thinks it's deploying and what the prospect actually experiences are often different.
- Influence principle strength is relative to the market. Strong authority in a low-authority market is different from strong authority in a market where everyone claims expertise.
- The heatmap visualization (principle x stage matrix) is the single most valuable output — it makes gaps visible at a glance.
- When scoring principles 0-10, use evidence-based assessment. A "7 on social proof" must be justified with specific proof elements, not guessed.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Robert Cialdini - Influence Audit/01 - Influence Architecture Audit - [System Name] - [Date].md`
