---
name: mcguire-threat-calibrator
description: Calibrates the threat component for a specific audience/offer combination. Determines the correct vulnerability-awareness level and generates threat-framing language that precedes refutation. WITHOUT a correctly calibrated threat, inoculation cannot occur.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "William McGuire (Inoculation Theory) — Idea 2"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/mcguire-threat-calibrator"
  called_by: [user, mcguire-inoculation-architect, mcguire-refutational-preemption-builder]
  outputs_to: [project-folder]
---

# McGuire Threat Calibrator

---

## LAYER 1: INVARIANTS (Never override.)

1. **The threat component is about vulnerability-of-belief, not emotional fear.** The threat is the reader's awareness that their current confidence — in the product, the promise, the approach — is genuinely at risk from a specific counter-argument. Fear appeals (Hovland) operate by raising anxiety to motivate action. The threat component operates by making the reader aware they could be convinced otherwise. These interact but are mechanically distinct. Never substitute a fear appeal for a threat component and claim inoculation was performed.

2. **No threat component = no inoculation.** A refutation delivered without a prior threat component is objection handling, not inoculation. Objection handling responds to a question the reader already has. Inoculation creates the awareness of vulnerability in readers who may not yet feel vulnerable, then resolves it. The threat step is the non-negotiable separator. If the copy skips straight to refutation, rate it as objection handling regardless of how well-written the refutation is.

3. **The threat must be felt, not merely implied.** "You might have heard some critics say..." is implied threat. "Skeptics are already circulating the argument that [X], and if you've seen this, you may be questioning whether [belief] still holds" is felt threat. The standard: after reading the threat component, the reader should experience a moment of genuine uncertainty about their current position. If the threat produces no uncertainty, it is decorative, not functional.

4. **Threat calibration has a ceiling.** McGuire's experimental evidence and the fear-appeal literature both confirm: if the threat is too severe, it triggers defensive avoidance. The reader shuts down rather than processing the refutation. Calibration means finding the window between "too soft to motivate processing" and "too intense to allow processing." This window varies by audience, offer type, and how much prior commitment the reader has to the belief being protected.

5. **Threat credibility is load-bearing.** A threat the reader dismisses as implausible provides no motivational force. The threat must reference an actual counter-argument that the reader would recognize as capable of being believed by someone reasonable. Invented or straw-man threats produce zero inoculation. Real threats from real skeptics, real competitors, or real market doubts are the only valid raw material.

---

## LAYER 2: QUALITY GUIDANCE

6. **The optimal threat names the specific attack, not a category.** "There are critics who doubt this" is categorical and weak. "The specific critique — that [X mechanism] only works in [Y context] and not the one you're in — is already circulating in [this space]" is specific and strong. The more precisely the threat names the actual attack the reader will encounter, the stronger the inoculation effect.

7. **Threat framing has a vocabulary.** McGuire's most effective threat phrasings share a structure: (a) name the source of the attack (critics, skeptics, competitors, market doubts), (b) state the specific content of the attack, (c) establish that the reader's current confidence is what's being challenged. The framing is not "here is a potential problem" but "here is an argument that specifically targets why you might currently believe [X]."

8. **Audience commitment level modifies the required threat intensity.** Low-commitment audiences (early funnel, new leads): lighter threat is sufficient because there is less investment to protect. High-commitment audiences (late funnel, existing buyers of related products): heavier threat is needed because their defenses are higher and a mild threat will be brushed off. Calibrate upward for skeptical, high-information audiences.

---

## PURPOSE

Every "agitate and refute" structure in long-form copy rests on an assumption that the reader's attention and motivation to process the refutation are already activated. They are not — unless the threat component does its job first.

The threat component is what separates inoculation from reactive objection management. Standard objection handling takes a concern the reader has already formed and addresses it. Inoculation uses the threat to create a moment of genuine vulnerability-awareness in readers who might not yet be questioning their position — and in doing so, motivates them to process the coming refutation with full engagement rather than skimming it.

This tool calibrates the threat component for a specific audience and offer, determines the appropriate intensity level, and generates the specific language that will function as a genuine inoculation threat (not a decorative nod toward skepticism).

---

## INPUT REQUIREMENTS

Provide:
1. **The offer and core claim** — what belief or confidence the inoculation is designed to protect (e.g., "this program will produce result X")
2. **The target audience profile** — commitment level, sophistication, prior exposure to similar claims, known skepticisms
3. **The primary attack to inoculate against** — the specific counter-argument, competitor claim, or market doubt that constitutes the real threat
4. **Any copy that already exists** — to audit whether a threat component is already present and rate its calibration

Optionally provide:
- **Sequence context** — is this a single piece or part of a multi-message sequence? (affects whether split-message active inoculation is appropriate)
- **Competitor context** — what the reader is simultaneously seeing that could erode their confidence

---

## EXECUTION PROCESS

### Step 1: Belief Identification
Name the specific belief being protected. Not "confidence in the product" — the specific proposition the reader holds that the attack targets. Example: "This method works even if you have no prior experience." The more precisely the belief is identified, the more precisely the threat can be calibrated.

### Step 2: Attack Reconstruction
Reconstruct the actual counter-argument in its strongest form. Not a straw man — the version a credible, intelligent skeptic would use. Sources:
- Competitor positioning and ad copy
- Negative reviews and refund patterns
- Common objections surfaced in sales calls
- Market dialogue in forums, groups, social media
- What past buyers who didn't get results believed about why

### Step 3: Commitment Level Assessment
Rate the audience's prior commitment to the protected belief:
- **Low (1-3):** New leads, cold traffic, early funnel. Minimal counterarguing motivation exists independently.
- **Medium (4-6):** Warm leads, engaged list, have consumed some content. Some prior investment in the belief.
- **High (7-9):** Late funnel, prior buyers, repeat engagers. Significant investment; defenses are higher.

Commitment level determines baseline threat intensity required.

### Step 4: Threat Intensity Calibration
Map commitment level to required threat intensity:

| Commitment Level | Required Threat Intensity | Calibration Notes |
|-----------------|--------------------------|-------------------|
| Low (1-3) | Moderate — name the attack, establish it's real | Don't over-frighten; they have little investment to protect yet |
| Medium (4-6) | Firm — name the attack, attribute it to credible sources, make it feel proximate | The reader should feel: "I've actually encountered this doubt" |
| High (7-9) | Strong — name the attack in its strongest form, make the vulnerability feel real | High-commitment readers will dismiss light threats as irrelevant noise |

Cap: Never exceed the point where the threat triggers defensive avoidance. Signal: if the reader's likely response is to close the page or dismiss the copy rather than engage with the refutation, the threat has exceeded calibration.

### Step 5: Threat Component Generation
Write the threat component language using this structure:

**Source establishment:** Name who is making this attack or where this doubt originates.
> "Skeptics inside [this space] are already making the argument that..."
> "The most common concern from people who've tried [similar approaches]..."
> "Your competitors are currently positioning against [X] by claiming..."

**Attack statement:** State the attack in its actual, strongest form.
> "...that [specific claim] only works under [narrow conditions] that don't apply to [the reader's situation]."

**Vulnerability bridge:** Establish that this attack specifically challenges the belief the reader currently holds.
> "If you've heard this, or if some version of this doubt has crossed your mind, you're about to understand exactly why that concern — while understandable — misses the mechanism that makes [X] different."

### Step 6: Audit Existing Copy (if provided)
Score any existing threat framing against:

| Criterion | Score (1-5) | Notes |
|-----------|------------|-------|
| Specificity — names the actual attack, not a category | | |
| Source credibility — attributes threat to believable origin | | |
| Felt vulnerability — produces genuine uncertainty, not mere acknowledgment | | |
| Calibration — not too soft (decorative) or too intense (shuts down processing) | | |
| Sequence position — threat appears BEFORE refutation, not after | | |

Total score /25. Below 15: threat component needs reconstruction. 15-20: refinement needed. 21+: calibrated.

---

## OUTPUT STRUCTURE

**Section 1: Belief Under Protection**
The specific proposition being protected, stated precisely.

**Section 2: Attack Reconstruction**
The strongest-form version of the counter-argument, sourced where possible.

**Section 3: Calibration Assessment**
Audience commitment level rating + recommended threat intensity level with reasoning.

**Section 4: Threat Component (Generated)**
Full threat framing language ready for insertion before the refutation section.
- Source establishment phrase
- Attack statement (in the reader's language)
- Vulnerability bridge to the refutation

**Section 5: Audit Results (if existing copy provided)**
Scored threat audit with specific improvement language.

**Section 6: Calibration Notes**
Any risks of over- or under-calibration specific to this audience/offer combination. What to watch for in reader response.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/William McGuire - Threat Calibration/[Date] - Threat Calibration - [Offer Name].md`
