---
name: mcguire-refutational-preemption-builder
description: Surfaces the most dangerous objections/attacks for a given offer and generates the full two-component inoculation language (threat + refutation) for each. Includes two-component structure audit and supportive/refutational defense comparison as integrated layers.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "William McGuire (Inoculation Theory) — Idea 3"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/mcguire-refutational-preemption-builder"
  called_by: [user, mcguire-inoculation-architect]
  outputs_to: [project-folder]
depends_on: [mcguire-threat-calibrator]
---

# McGuire Refutational Preemption Builder

---

## LAYER 1: INVARIANTS (Never override.)

1. **Refutational defense outperforms supportive defense for skeptical audiences — every time.** McGuire's finding is non-negotiable: raising the counterargument and refuting it produces ~2x the resistance of simply piling on more positive reasons to believe. Most copy is supportive-defense only (benefit bullets, testimonials, proof stacks). When the audience is skeptical, low-commitment, or has access to competing messages, that copy is structurally weak. The refutational upgrade is not a stylistic choice — it is an empirically superior architecture. Flag every supportive-defense-only section encountered during audit.

2. **Refutational preemption requires the two-component structure in sequence: THREAT first, REFUTATION second.** Jumping directly to the counter ("you might wonder if this is a scam — it isn't, here's proof") is refutation without threat. The reader has no motivation to process the refutation because vulnerability has not been established. The threshold: the reader must first feel genuine uncertainty before the refutation can provide genuine relief. Sequence is structural, not stylistic.

3. **A weak refutation is worse than no refutation.** If the refutation is unconvincing, the writer has introduced the counterargument (increasing its salience) without neutralizing it. The attack is now more cognitively accessible to the reader without having been defeated. Quality of refutation is non-negotiable. Every refutation produced by this skill must be stress-tested: could a reasonable skeptic dismiss this refutation? If yes, strengthen or abandon in favor of a different objection.

4. **Name YOUR objections, not strawmen.** Refutational preemption fails when the objection raised is weaker or more abstract than what the reader is actually thinking. The skill must identify the real, high-stakes objections — the ones that actually kill sales, drive refunds, and prevent purchase in this specific market. If the actual objections are unknown, surface them before writing (sales call recordings, refund reasons, competitor attack ad claims, review site criticism).

5. **Refutational preemption is NOT the same as objection handling.** Standard objection handling is reactive — it waits for the reader to form an objection and then addresses it. Refutational preemption is preemptive — it names the objection the reader may not have fully formed yet, establishes that it's a real attack that challenges the reader's belief, and then defeats it inside the copy before the full-strength version reaches them from external sources. The critical test: is this copy raising the attack before the reader would naturally form it, or responding to a question they clearly already have?

---

## LAYER 2: QUALITY GUIDANCE

6. **Identify the most damaging objections, not the most common ones.** The objection that appears most frequently in sales calls is often not the one that most powerfully kills the sale. The most dangerous objection is the one that, if believed, most thoroughly undermines the core reason to buy. Sort objections by damage potential, not frequency. The objection that destroys the entire mechanism claim outranks the objection about price.

7. **The refutation must defeat the objection at the level of mechanism, not assertion.** "We've helped hundreds of clients" is not a refutation — it's a reassertion of the original claim. A mechanism-level refutation explains WHY the objection misunderstands the product's actual operating logic. Example: If the objection is "this only works if you already have an audience," the mechanism refutation explains specifically how the method produces results through a pathway that does not depend on prior audience — not just that "our clients start from zero."

8. **Supportive defense has a role, but not as a substitute.** When the audience has high prior commitment to the belief (late-funnel, existing customers, re-engagement), the combination of supportive + refutational defense is stronger than refutational alone. Never eliminate testimonials and proof — add refutational preemption on top of them. The upgrade is additive, not substitutive.

---

## PURPOSE

McGuire found that the counterintuitive approach — raising your own weaknesses and then defeating them — produces dramatically stronger resistance to later attack than only emphasizing strengths. This is the empirical foundation for the "agitate and refute" pattern in long-form copy.

Most copy, however, performs objection handling rather than refutational preemption. The difference is operationally significant: objection handling manages doubts the reader already has; refutational preemption inoculates against the full-strength attack the reader will encounter from competitors, skeptics, and their own deepening resistance after the purchase window closes.

This skill surfaces the attack surface for a given offer, builds the full two-component inoculation language for each critical objection, and audits existing copy against the two-component requirement — flagging supportive-defense-only sections and generating the refutational upgrade.

---

## INPUT REQUIREMENTS

Provide:
1. **The offer** — product/service, core mechanism, primary promise
2. **Target market** — who they are, what they believe coming in, their sophistication level
3. **The primary claims** — the two to four assertions the reader must believe to purchase
4. **Existing copy (optional)** — to audit for supportive-defense vs. refutational-defense ratio and two-component compliance

Optionally provide:
- **Sales call objection recordings/transcripts**
- **Refund reasons** from customer service data
- **Competitor attack messaging** — what the market is hearing against this offer
- **Negative review themes** from review sites, forums, social

---

## EXECUTION PROCESS

### Step 1: Attack Surface Mapping
Identify every major attack against the core claims. For each claim, ask: "What argument, if believed, would most decisively undermine this claim?"

Sources to scan:
- Competitor positioning (what are they attacking?)
- Market-category doubts (what does this market disbelieve about this type of offer?)
- Mechanism vulnerabilities (what are the conditions under which this method would NOT work?)
- Credibility attacks (what challenges the authority of the person making the claim?)
- Social proof attacks (what undermines the testimonials and proof?)
- Price/value attacks (what makes the price unjustifiable?)

Produce an Attack Surface Map: claim → specific attacks → damage potential rating (1-10).

### Step 2: Priority Ranking
Rank attacks by combined score: (Damage Potential × Likelihood of Encounter in Market). Select the top 3-5 for full inoculation treatment. The remainder may be addressed with briefer handling or left for cross-protection transfer.

### Step 3: Two-Component Structure Audit (if existing copy provided)
For each objection-handling section in the provided copy:

**Two-Component Compliance Check:**
| Section | Threat Component Present? | Threat Felt or Implied? | Refutation Follows Threat? | Verdict |
|---------|--------------------------|------------------------|--------------------------|---------|
| [name] | Yes/No | Felt/Implied/Absent | Yes/No | Inoculation / Objection Handling / Broken |

**Supportive vs. Refutational Defense Audit:**
| Section | Defense Type | Upgrade Available? |
|---------|--------------|--------------------|
| [name] | Supportive / Refutational / Both | Yes/No |

Flag every section that is:
- Refutation-only (no threat component) — returns OBJECTION HANDLING verdict
- Threat-only (no refutation) — returns BROKEN structure warning
- Supportive-defense-only — flags UPGRADE AVAILABLE

### Step 4: Full Inoculation Build (top 3-5 objections)
For each selected objection, produce the complete two-component inoculation passage:

**[Objection Name]**

*Attack reconstruction (strongest form):*
> [The exact argument a credible skeptic would make]

*Threat component:*
> [Language establishing vulnerability-awareness. Uses source attribution, specific attack statement, vulnerability bridge. See mcguire-threat-calibrator for full calibration methodology.]

*Refutation component (mechanism-level):*
> [The defeat of the attack at the level of operating logic — not assertion, not reassurance, but explanation of why the attack misunderstands the mechanism]

*Stress test:* Could a reasonable skeptic dismiss this refutation? [Yes → revise / No → cleared]

*Combined passage (ready to insert):*
> [Full threat + refutation language as it would appear in copy]

### Step 5: Supportive Defense Upgrade (if applicable)
For any section identified as supportive-defense-only, generate the refutational preemption layer to add above or around it:
> "The existing [testimonials/proof stack/benefit bullets] remain. Add the following refutational preemption passage immediately before the social proof section to convert supportive-defense-only architecture to full inoculation..."

---

## OUTPUT STRUCTURE

**Section 1: Attack Surface Map**
Full inventory of attacks by claim, with damage potential ratings. Ranked priority list of top 3-5 for inoculation treatment.

**Section 2: Two-Component Audit (if existing copy provided)**
Compliance table. List of objection-handling sections rated Inoculation / Objection Handling / Broken. Supportive-defense-only sections flagged with upgrade availability.

**Section 3: Refutational Preemption Passages (top 3-5)**
For each: attack reconstruction, threat component, refutation component, stress test result, combined ready-to-insert passage.

**Section 4: Supportive Defense Upgrades (if applicable)**
Specific language to add above supportive-defense-only sections.

**Section 5: Structural Recommendation**
Where in the copy each inoculation passage should be placed, and in what sequence. Note: inoculation works best before the full-strength attack reaches the reader — place it earlier in the piece rather than in a late "FAQ" or "objection handling" section.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/William McGuire - Refutational Preemption/[Date] - Refutational Preemption - [Offer Name].md`
