---
name: Toffler Naming Engine
description: Generate 20+ name variations using Toffler/Gladwell/Taleb structural formulas.
version: 1.0
author: Rich Schefren / ZenithPro
programs: [ZenithPro]
interface: standalone
---

# Toffler Naming Engine

## Purpose

The name you give a concept determines whether it spreads. Generic names die. Named concepts that use proven structural formulas from master communicators become searchable, ownable, and memorable. This skill generates 20+ naming variations using structural patterns from Alvin Toffler, Malcolm Gladwell, Nassim Taleb, Seth Godin, Daniel Pink, and Rich Schefren's own naming patterns.

Use this when naming offers, methodologies, frameworks, coined concepts, or proprietary terms.

## Input Required

- The concept, idea, phenomenon, or methodology you need to name (one sentence description)
- Optional: The emotion or transformation it creates
- Optional: The audience it serves

## Methodology

### The 20 Structural Formulas

**ALVIN TOFFLER PATTERNS**

Formula 1 — Compound Neologism
```
[Concept A] + [Concept B] = New Word
Examples: Future + Shock = FutureShock | Pro + sumer = Prosumer
```

Formula 2 — "The ___ ___" (Adjective + Noun)
```
The + [Provocative Adjective] + [Core Noun]
Examples: The Throwaway Society | The Modular Man | The Fractured Family
```

Formula 3 — "The ___ Wave/Age/Era"
```
The + [Ordinal Number] + [Epochal Noun]
Examples: The Third Wave | The Second Self
```

Formula 4 — "Over-___" (Excess Pattern)
```
Over + [Core Concept]
Examples: Overchoice | Overstimulation
```

Formula 5 — Numbered Metaphor
```
The + [Large Number]th + [Time/Life Concept]
Examples: The 800th Lifetime
```

Formula 6 — "The Origins of ___"
```
The Origins of + [Your Concept-word]
```

**MALCOLM GLADWELL PATTERNS**

Formula 7 — Single-Word Verb
```
One powerful verb that captures instant action
Examples: Blink | Talking
```

Formula 8 — "The ___ Point"
```
The + [Action Verb-ing] + Point
Examples: The Tipping Point | The Turning Point
```

Formula 9 — Exceptional Category
```
Single word for edge cases
Examples: Outliers
```

**NASSIM TALEB PATTERNS**

Formula 10 — Color + Creature
```
[Unexpected Color] + [Mythical/Rare Animal]
Examples: Black Swan | Gray Rhino
```

Formula 11 — "Anti-___"
```
Anti + [Core Quality]
Examples: Antifragile | Antilibrary
```

Formula 12 — "Skin in the ___"
```
[Body Part] in the [Abstract Noun]
Examples: Skin in the Game
```

**SETH GODIN PATTERNS**

Formula 13 — Color + Common Animal
```
[Unexpected Color] + [Ordinary Animal]
Examples: Purple Cow
```

Formula 14 — Tribal/Movement Single Word
```
One word suggesting belonging/identity
Examples: Tribes | Linchpin | Icarus
```

Formula 15 — "The ___ of ___" (Dip Pattern)
```
The + [Simple Noun] + of + [Activity]
Examples: The Dip | The Practice
```

**DANIEL PINK PATTERNS**

Formula 16 — Single Power Word (Motivation)
```
One word = entire framework
Examples: Drive | When
```

Formula 17 — "A Whole New ___"
```
A Whole New + [Body Part/System]
Examples: A Whole New Mind
```

**STRATEGIC PROFITS STYLE**

Formula 18 — "The Universal ___ ___"
```
The Universal + [Power Concept] + [Tool/System]
Examples: The Universal Intelligence Amplifier
```

Formula 19 — "Demand ___" (Action Pattern)
```
Demand + [Business Verb]
Examples: Demand Creation | Demand Domination
```

Formula 20 — "___ Excavation"
```
[Target] + Excavation
Examples: Avatar Excavation | Market Excavation
```

### Scoring Each Variation

For each generated name, rate on three dimensions (1-10):
- **Memorability**: How easily remembered after one exposure?
- **Specificity**: How precisely does it communicate the concept?
- **Pattern-Interrupt**: How much does it break expected naming patterns?

### Step-by-Step Process

1. State the concept to name (one sentence)
2. Apply all 20 formulas, generating at least one variation per formula
3. Score each on Memorability / Specificity / Pattern-Interrupt
4. Identify Top 5 Winners with rationale

### The Full Prompt to Use

```
I need a name for this concept: [YOUR CONCEPT HERE]

Generate 20+ naming variations using these structural formulas:

=== TOFFLER PATTERNS ===
1. Compound Neologism: [Concept A] + [Concept B] = New Word
2. "The ___ ___" Adjective + Noun
3. "The ___ Wave/Age/Era"
4. "Over-___" Excess Pattern
5. Numbered Metaphor
6. "The Origins of ___"

=== GLADWELL PATTERNS ===
7. Single-Word Verb
8. "The ___ Point"
9. Exceptional Category Single Word

=== TALEB PATTERNS ===
10. Color + Creature
11. "Anti-___"
12. "Skin in the ___"

=== GODIN PATTERNS ===
13. Color + Common Animal
14. Tribal/Movement Single Word
15. "The ___ of ___"

=== PINK PATTERNS ===
16. Single Power Word
17. "A Whole New ___"

=== STRATEGIC PROFITS STYLE ===
18. "The Universal ___ ___"
19. "Demand ___"
20. "___ Excavation"

For each variation:
- Show the formula applied
- Rate: Memorability (X/10) | Specificity (X/10) | Pattern-Interrupt (X/10)
- One sentence on why it works or doesn't

=== TOP 5 WINNERS ===
Rank your top 5 with brief rationale for why they're the strongest.
```

## Output Format

- 20+ named variations organized by formula family
- Per-variation scores on Memorability / Specificity / Pattern-Interrupt
- Top 5 Winners ranked with rationale
- Recommended winner with deployment guidance

## Example Invocation

```
Generate names for this concept: The phenomenon where online entrepreneurs buy course after course trying to fix their marketing, when the real problem is they haven't defined what makes them the only logical choice for their specific audience.

Apply the Toffler Naming Engine and give me 20+ variations plus your Top 5 recommendations.
```

Expected output would include names like: Course Graveyard Syndrome, Solution Confusion, The Positioning Gap, Tactical Addiction, The Wrong Variable, Overchoice Disease, The Cracked Vessel Problem.
