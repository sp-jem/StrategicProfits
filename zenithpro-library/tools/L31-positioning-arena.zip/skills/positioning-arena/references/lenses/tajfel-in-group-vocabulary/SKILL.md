---
name: tajfel-in-group-vocabulary
description: Prototype vocabulary audit — evaluates whether copy uses the vocabulary, jargon, shared references, and belief markers of the in-group prototype, or generic language that fails normative fit. Outputs a vocabulary substitution list that converts generic to prototype phrasing.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Henri Tajfel & John Turner (Social Identity Theory, Self-Categorization Theory) + Marilynn Brewer (Optimal Distinctiveness) — Idea 6"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/tajfel-in-group-vocabulary {copy-to-audit} {in-group-definition}"
  called_by: [user, tajfel-field-intelligence, tajfel-qualification-architect]
  outputs_to: [client-output-folder]
depends_on: [tajfel-salience-calibrator, tajfel-prototype-auditor]
---

# Tajfel In-Group Vocabulary

---

## LAYER 1: INVARIANTS (Never override.)

1. **Vocabulary is a prototype signal, not decoration.** SCT (Turner et al., 1987) establishes that the prototype includes vocabulary — the specific language the ideal group member uses, the terms they recognize as in-group signals, the jargon that marks who is "one of us" vs. who is an outsider. Copy that uses generic language fails normative fit even if the in-group is correctly named. The mechanism: when the prospect reads generic vocabulary, the copy's normative fit signal is "this person doesn't really know our group" — and self-categorization weakens.

2. **Prototype vocabulary has three components.** (a) In-group jargon: specialized terms the group uses that outsiders don't know or use differently. (b) Belief markers: phrases and framings that signal shared values and worldview. (c) Exclusion signals: generic terms the in-group would NOT use — terms that identify someone as outside the group. All three components must be assessed.

3. **Generic vocabulary actively signals out-group status.** Vocabulary is not neutral. Using generic terms when the in-group has specific terms for the same concept signals that the writer is not of the group — which undermines the copywriter's authority to speak to the group. Even if the content is accurate, generic vocabulary reduces normative fit and weakens self-categorization.

4. **The vocabulary substitution list is the primary deliverable.** This skill's core output is specific: for each piece of generic language identified, a prototype-vocabulary replacement. The list must be actionable — specific generic phrase, specific replacement phrase, explanation of why the replacement is more prototype-appropriate.

5. **Vocabulary is audience-specific — no universal prototype vocabulary list exists.** What counts as in-group vocabulary for "$1M+ operators" is different from in-group vocabulary for "beginner freelancers." The skill must be calibrated to the specific in-group being targeted. Never apply generic "entrepreneur jargon" as a proxy for specific audience vocabulary.

---

## LAYER 2: QUALITY GUIDANCE

6. **The jargon test is the fastest normative fit diagnostic.** Take the five most common generic terms in the copy. Would the prototypical member of this in-group use these terms? If yes — no substitution needed. If the prototype would use a more specific, more insider term — the generic term is a normative fit failure. This five-term quick scan is the entry point for every vocabulary audit.

7. **Belief marker language is underused in most copy.** Generic copy makes claims about results ("you'll achieve X"). Prototype vocabulary makes claims using the belief framing of the in-group ("X is what operators who are building real systems already know"). The second version uses belief-marker language — it frames the claim in terms of what the in-group believes, not just what they achieve. This is a deeper normative fit signal.

8. **Watch for cross-group vocabulary contamination.** Copy that serves multiple audiences often inadvertently uses vocabulary that belongs to a different in-group than the one being targeted. E.g., using startup vocabulary in copy targeting established SME operators, or using academic vocabulary in copy targeting practitioners. This contamination actively weakens self-categorization because the prospect thinks "that's not how we talk."

---

## PURPOSE

Normative fit is one of the three conditions for self-categorization salience (Turner et al., 1987). Normative fit is satisfied when the beliefs, behaviors, and vocabulary attributed to the in-group match what the prospect expects members of that category to believe and do.

Vocabulary is the most visible and most auditable component of normative fit. Every term in a piece of copy is either prototype vocabulary (signals in-group membership and fluency) or generic vocabulary (signals outsider status or lack of group fluency). This skill systematically identifies every generic-vocabulary instance in a piece of copy and replaces it with prototype vocabulary — producing a substitution list that can be applied directly.

This is a Layer 3 extension skill — it runs after `tajfel-prototype-auditor` has confirmed the prototype architecture is sound, and adds the vocabulary layer.

---

## INPUT REQUIREMENTS

Provide:
1. **Copy to audit** — the full piece or the sections with the highest normative-fit importance (leads, qualification language, body copy)
2. **In-group definition** — who the target group is; the more specific, the better the vocabulary calibration
3. (Strongly recommended) **Sample of authentic in-group language** — examples of how the target audience talks: forum posts, community Slack excerpts, testimonials they've given, language from their own content. Without this, vocabulary calibration uses inference; with it, calibration is direct.

---

## AUDIT STRUCTURE

### Section 1: In-Group Vocabulary Inventory

**Before auditing the copy, establish the target vocabulary standard.**

**Known in-group vocabulary for [target group]:**

| Vocabulary Type | Examples |
|----------------|----------|
| In-group jargon (insider terms) | |
| Belief marker phrases (how they frame things) | |
| Preferred outcome language (how they describe success) | |
| Preferred problem language (how they name their pain) | |
| Authority signals (who/what they cite or reference) | |
| Anti-vocabulary (generic terms they would NOT use) | |

**Source:** [Where this vocabulary inventory was derived from — authentic samples, audience research, prior work, inference]

**Confidence level:** [HIGH — based on direct samples / MEDIUM — based on inference / LOW — limited audience data]

---

### Section 2: Copy Vocabulary Scan

**Pass the copy through the vocabulary audit in three layers:**

**Layer A: Jargon scan**
For each specialized term used in the copy, evaluate:
- Is it in-group jargon, generic terminology, or wrong-group jargon?
- Mark: [IN-GROUP / GENERIC / WRONG-GROUP]

| Term | Current | Assessment | Prototype Replacement |
|------|---------|------------|----------------------|
| | | | |

**Layer B: Belief marker scan**
For each claim or framing statement in the copy:
- Does it use the in-group's framing and worldview, or generic/outsider framing?
- Example: "grow your business" (generic) vs. "build real leverage" (belief marker for operators who think in systems)

| Statement | Current Framing | Assessment | Prototype Framing |
|-----------|----------------|------------|-------------------|
| | | | |

**Layer C: Anti-vocabulary scan**
For each term in the copy that the in-group prototype would NOT use:
- Flag it as an anti-vocabulary signal
- Provide the prototype replacement

| Generic Term | Why It Fails | Prototype Replacement |
|-------------|--------------|----------------------|
| | | |

---

### Section 3: Vocabulary Failure Mode Classification

**What type of vocabulary failure is present?**

**[ ] Outsider vocabulary** — Generic terms where the in-group has specific ones. Signals the writer doesn't know the group.
- Impact: Reduces normative fit; prospect thinks "they don't really understand us"
- Fix: Direct substitution using Layer A scan

**[ ] Wrong-group vocabulary** — Terms that belong to a different in-group. Signals misidentification.
- Example: Using "growth hacking" language in copy targeting established operators; using "passive income" language in copy targeting serious business builders
- Impact: Confuses self-categorization; activates the wrong prototype
- Fix: Systematic replacement with correct in-group vocabulary

**[ ] Generic framing** — Claims that use results/outcome language rather than belief/worldview language.
- Impact: Copy reads as persuasion from outside rather than communication from inside; weakens depersonalization
- Fix: Reframe all key claims in in-group belief-marker language

**[ ] Mixed signals** — Some prototype vocabulary alongside significant generic vocabulary. The inconsistency itself is a signal: "This person knows our group partly but not deeply."
- Impact: Partial normative fit — better than pure generic but still weakened
- Fix: Systematic scan for all remaining generic terms

---

### Section 4: The Vocabulary Substitution List

**Primary deliverable — organized by priority (highest-impact substitutions first):**

**Priority 1 — Headline and opening language:**
| Original | Replacement | Why |
|----------|-------------|-----|
| | | |

**Priority 2 — In-group naming and qualification language:**
| Original | Replacement | Why |
|----------|-------------|-----|
| | | |

**Priority 3 — Benefit/outcome language:**
| Original | Replacement | Why |
|----------|-------------|-----|
| | | |

**Priority 4 — Problem/pain language:**
| Original | Replacement | Why |
|----------|-------------|-----|
| | | |

**Priority 5 — CTA and close language:**
| Original | Replacement | Why |
|----------|-------------|-----|
| | | |

---

### Section 5: Prototype Vocabulary Seed List

**For this specific in-group, here is a vocabulary seed list that can be applied across future copy:**

**Preferred jargon:**
[List of 10–20 in-group-appropriate terms with brief context notes]

**Preferred belief framings:**
[List of 5–10 belief-marker phrases with example usage]

**Preferred outcome language:**
[List of 5–10 ways this group describes success]

**Preferred problem language:**
[List of 5–10 ways this group names their pain]

**Anti-vocabulary (terms to avoid):**
[List of generic/outsider terms that this group does not use]

---

### Section 6: Vocabulary Score and Recommendations

| Dimension | Score (1–5) |
|-----------|-------------|
| Jargon accuracy | |
| Belief marker alignment | |
| Anti-vocabulary avoidance | |
| Consistency across piece | |
| **Total** | **/20** |

**Score interpretation:**
- 16–20: Strong normative fit via vocabulary — proceed to `tajfel-qualification-architect`
- 11–15: Partial fit — apply Priority 1–2 substitutions from Section 4 before proceeding
- 6–10: Weak fit — significant vocabulary revision needed; full substitution list required
- 1–5: Generic vocabulary throughout — normative fit is failing; copy is signaling outsider status

---

## OUTPUT FILE

Save complete audit and substitution list to:
`[project-folder]/Tajfel — In-Group Vocabulary/01 - Vocabulary Audit - [Copy Name] - [Date].md`

---

## OUTPUT FORMAT — GIRARD STANDARD (canonical)

Produce a standalone Field Intelligence document conforming to the **Girard Standard**.

**Canonical spec:** `~/.claude/skills/_shared/output-formats/field-intelligence-girard-format.md` — read in full before producing output.

### Hard requirements

- **Length:** 250-400 lines (200 floor; 800 ceiling)
- **Fully self-contained** — reader must understand the analysis with no other file open
- **YAML frontmatter** including: `skill`, `target`, `analyst`, `date`, `analysis_type`, `status`, `priority_finding`
- **Epigraph** — a relevant quote from the source thinker, with application clause
- **Executive thesis** — 3-5 paragraphs that answer: what is analyzed, what lens is applied, what is the headline finding, why does it matter
- **Numbered sections** with embedded **verbatim quotes** from the target (no script-section shorthand like "S3.5" without quoting the actual words)
- **Falsifier check** — a section naming what would have to be false for the analysis to be wrong
- **Conclusion** with deployable verdict (action recommended or no action recommended, named)

### Forbidden patterns

- Script-section shorthand without embedded quote ("S3.5 has X" without the quote)
- Cross-references to other skill outputs ("see [other-skill] audit")
- Glossary references instead of inline definitions
- Generic verdicts ("strong"/"weak") without mechanism
- Closing summary that restates findings (padding)
- Version-comparison markers internal to the analysis ("v5 said X; v10 says Y" — belongs in commit log)

### Output path

Save to: `[project-folder]/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/01-in-group-vocabulary.md`

### Exemplars (read at least two before producing)

1. `Active-Brain/00 Projects/Support Pets - Girard Analysis/02-desire-autopsy.md`
2. `Active-Brain/00 Projects/Support Pets - Girard Analysis/03-rivalry-detector.md`
3. `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/05-qualification-architect.md`

### The "no flipping" test

Before declaring output complete: imagine a colleague opening this file cold, with no project context. Can they understand the analysis end-to-end without opening any other file? If no, the document has failed the standard. Rewrite.

---

## KNOWN PATTERNS (Field-Tested)

Patterns this skill has identified in production runs. Each entry encodes diagnostic intelligence the skill should apply to future targets.

---

### Pattern: Bilingual Register — Load-Bearing vs. Connective Tissue

**Classification:** Anti-pattern

**Description:** When auditing a long-form piece (webinar, VSL, sales letter), map vocabulary register at the section level, not just across the piece as a whole. Look for a structural split: in-group operator vocabulary concentrated in the five or six load-bearing sections (qualification block, first vulnerability beat, belief-marker argument, second vulnerability beat, close), while connective tissue between those peaks (transitions, testimonial sequences, problem-agitation repetitions) defaults to generic self-help language. The piece is not failing uniformly — it is alternating between two registers, and the alternation is doing damage beyond the sum of individual weak terms.

**Mechanism:** SCT normative fit is not averaged across a 75-minute runtime. The prototype detects register switches in real-time. Each switch from in-group register to generic register sends a low-level signal: "this person knows our vocabulary mostly, but not completely." Accumulated over a long runtime, these micro-signals reduce the listener's felt sense of being precisely addressed. The damage is proportional to the frequency and placement of the switches, not just their count.

**Worked example:** ZenithMind OS Evergreen Webinar v10. The qualification block (Section 3.5), the Three Changes architecture (Section 7 Beat C), the infrastructure punchline (Section 15.5), and the final close (Block H) all operate at vocabulary ceiling — "operators and builders," "operating clear," "infrastructure," "calibrated," "Seer." The connective tissue between those peaks used "patterns" loosely across seven instances, "shadows" with Jungian freight, and "breakthrough" at the offer stack reveal — the exact moment buyer genre-recognition is most active. The script scored 19/25 on vocabulary; the bilingual structure was the primary explanation for the 6-point gap from ceiling.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/01-in-group-vocabulary.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern: Threading Map Diagnostic — Vocabulary Dormancy Windows

**Classification:** Anti-pattern

**Description:** After completing the vocabulary scan, build a section-by-section threading map: list every section of the piece, identify which in-group terms appear in each section, and flag any contiguous run of sections (10 minutes or more in a webinar; 300+ words in a sales letter) where no in-group vocabulary appears at all. A single 20-minute dormancy window in a 75-minute piece is sufficient to create a low-grade drift in the listener's felt sense of belonging — even if the surrounding peaks are strong. The map reveals whether vocabulary failures are distributed or clustered in specific windows.

**Mechanism:** Tajfel's identity salience research shows that category membership must be periodically reactivated under cognitive load to remain behaviorally influential. In a long-form piece, the prototype will encounter many sections that do not trigger self-categorization (testimonials, proof sequences, transitions). If in-group vocabulary does not appear for an extended window, the identity installation made at the qualification block begins to decay. The second vulnerability beat — or wherever the next in-group vocabulary appears — must then do double work: reactivating the identity rather than merely reinforcing it.

**Worked example:** ZenithMind OS Evergreen Webinar v10. The threading map revealed a 20-minute dormancy window from Section 9 through Section 11 — the testimonial sequence and hero arc. "Seer" was installed at Section 3.5, reactivated at Section 8, then went quiet until Section 11.5. The Section 11.5 second vulnerability beat ("You're a Seer who hasn't found their bridge yet") fired cleanly and recovered the thread — but it had to reactivate rather than simply reinforce. The audit flagged the dormancy window even though the surrounding peaks were scored at ceiling, because a gap of that length in a 75-minute runtime is a structural vulnerability regardless of how strong the adjacent sections are.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/01-in-group-vocabulary.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern: Asymmetric Vocabulary Requirement — Calibrated Dislike, Not Contempt

**Classification:** Load-bearing pattern

**Description:** When auditing out-group characterization language, apply a two-axis test. Axis 1: Is the out-group deprecated on the relevant dimension (the one the in-group is being distinguished from)? Axis 2: Is the out-group attacked, mocked, or contemptible on other dimensions? The correct calibration is YES on Axis 1, NO on Axis 2. Out-group members should be described as people who made a different choice — specifically the choice the in-group has not made — while being treated as intelligent, decent, and otherwise respectable. Also audit for age-specific or demographic-specific claims in the out-group characterization that a segment of in-group viewers could falsify against their own experience.

**Mechanism:** Tajfel's minimal group paradigm established that asymmetry on a single dimension is sufficient for in-group identity activation — the prototype does not need the out-group to be contemptible, only inferior on the relevant dimension. Copy that attacks the out-group broadly triggers two problems: (1) the prospect may have social ties to out-group members and will defend them, weakening in-group allegiance; (2) a prospect who is unsure whether they belong to the in-group will avoid the contemptible category by disengaging, rather than self-categorizing as in-group. Calibrated dislike (they stopped; we kept going) is more effective than contempt because it leaves the door open for out-group members to re-categorize themselves as in-group.

**Worked example:** ZenithMind OS Evergreen Webinar v10. The Resigned Observer characterization was near-exact: "smart, decent people I respect," "they've just made peace with the gap," "they use self-development now as intellectual stimulation, not as work-in-progress." The out-group was deprecated on one dimension (persistence) without being attacked on others. One calibration leak was identified: "Most operators with your years of experience become Resigned Observers by 35" — the "by 35" claim is a demographic verifiable that viewers older than 35 will test against their own experience and may find inconsistent with their self-identification as Seers. Recommended fix: "by midlife" removes the falsifiable specificity while preserving the asymmetry signal.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/01-in-group-vocabulary.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern: Density vs. Recognition Cue Thresholds — When Repetition Becomes Contamination

**Classification:** Boundary condition

**Description:** A single in-group term used repeatedly without mechanism precision will cross a threshold where it stops functioning as a recognition cue and starts functioning as a generic label. The diagnostic test: identify every instance of the three most frequently used vocabulary terms across the piece. For each instance, ask whether the term is used with mechanism specificity (naming a loop, a causation, a structural distinction) or as a label (applied to whatever is being discussed at that moment). If a term appears 5 or more times and more than half the instances are label-usage rather than mechanism-usage, the term has crossed the contamination threshold. Flag it as a drift term and build a substitution bank of 4-6 mechanism-specific variants the copy can rotate through.

**Mechanism:** Stage 4-5 buyers (Schwartz sophistication scale) have pattern-recognition immunity to generic self-help vocabulary. The word "patterns" is a known trigger — every coach, therapist, and self-help author uses it. When a sophisticated buyer hears it used loosely, their jargon-radar fires: this is the default word, not a precise one. The mechanism here is not just that the word is generic; it is that frequency without precision accumulates into a genre signal across the runtime. Each loose use deposits a small amount of "generic self-help register" into the listener's running model of the speaker. At 7 loose uses over 75 minutes, the deposit is meaningful.

**Worked example:** ZenithMind OS Evergreen Webinar v10. "Patterns" appeared approximately seven times across the 75-minute script. Most instances used it as a label rather than as a mechanism descriptor. The Seer prototype — Stage 4-5 sophistication, familiar with psychological and systems literature — hears "patterns" and her jargon-radar fires: this is the word every coach uses. The audit recommended a substitution bank: "the same defaults," "the same loops," "the kernels firing," "the operating modes you didn't choose," "the assumptions running underneath." The recommendation was contextual rotation, not wholesale replacement — the goal is mechanism-precision and variety, not elimination of the word.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/01-in-group-vocabulary.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)
