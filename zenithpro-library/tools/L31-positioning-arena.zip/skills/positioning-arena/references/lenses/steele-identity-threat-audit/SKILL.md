---
name: steele-identity-threat-audit
description: Full diagnostic scan of a piece of copy. Catalogues every explicit and implicit identity threat, rates each by threat level (low/medium/high), and returns a coverage map showing which threats have affirmation pre-frames installed and which are bare.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Claude Steele (Self-Affirmation Theory) — Idea 6"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/steele-identity-threat-audit {copy-to-audit}"
  called_by: [user, steele-field-intelligence]
  outputs_to: [project-folder/Claude Steele - Identity Threat Audit/]
depends_on: [steele-self-affirmation-primer]
---

# Steele Identity Threat Audit

---

## LAYER 1: INVARIANTS (Never override.)

1. **Audit threats, not weaknesses.** This skill is not a general critique of copy quality. It is a targeted diagnostic: find every point in the copy where the prospect's sense of identity — who they are, whether they are competent, adequate, good — is implicitly or explicitly called into question. Execution quality, argument strength, and offer structure are out of scope here.

2. **Implicit threats are as dangerous as explicit ones.** A headline that says "Why most entrepreneurs are leaving $500K per year on the table" does not explicitly call the prospect incompetent. But if the prospect self-identifies as an entrepreneur, the implicit threat to their identity as a competent business person is active. Audit for both.

3. **Threat level rating is mandatory for every flagged passage.** Every identified threat must be rated: LOW (mild implication of suboptimal behavior), MEDIUM (direct implication of inadequacy, poor judgment, or failure), or HIGH (accusation of moral failure, fundamental incompetence, or systemic inadequacy). Rating determines urgency of pre-frame requirement.

4. **Pre-frame coverage is binary — covered or bare.** A threat is covered if, and only if, a genuine affirmation in a domain the prospect values precedes it in the copy. A threat is bare if no such affirmation exists before it. "Sort of" covered, "implied" covered, or "the prospect probably knows we respect them" do not count. Binary determination.

5. **Every bare high-level threat is a structural failure requiring immediate remediation.** Do not soften this. A high-threat passage without a preceding affirmation is not a "potential improvement" — it is a structural defect that will drive defensive processing and reduce conversion. Report it as a failure, not a suggestion.

---

## LAYER 2: QUALITY GUIDANCE

6. **Look for cumulative threat load, not just individual threats.** Three medium-level threats in three consecutive paragraphs, each bare, represent a higher aggregate threat load than any single one. The audit must assess both individual threats and the cumulative load across sections.

7. **Common implicit threat forms in direct-response copy:**
   - "Most people in your position are making X mistake" → implication: you are one of them
   - "If you've been struggling with X" → implication: you have been failing
   - "The old approach doesn't work anymore" → if the prospect uses the old approach: identity as a competent practitioner is threatened
   - "You deserve better than X" → implication: your current situation is inadequate, and you accepted it
   - Testimonials showing results the prospect hasn't achieved → implicit comparison threat
   - Statistics about how few people succeed → implication: you are likely in the majority

8. **Distinguish identity threat from fear/urgency copy.** Some copy amplifies fear of external events (market crash, deadline, competitor moving) — this is NOT an identity threat. Identity threat specifically concerns the prospect's view of themselves as adequate, competent, and good. Fear copy can coexist with no identity threat at all. Do not conflate.

9. **Map the threat chronology.** The order matters. Identify not just what threats exist but when in the copy they arrive. Early bare threats in the lead are the most dangerous (defensive processing engaged before the offer is even presented). Late bare threats in the close are the second most dangerous (reversing conversion already in progress).

---

## EXECUTION PROCESS

### Step 1: Full Read (No Annotation)
Read the entire piece of copy once, completely, without marking anything. Build a mental picture of the full arc.

### Step 2: Threat Extraction Pass
Re-read paragraph by paragraph. For each passage, ask: "Does this passage, explicitly or implicitly, suggest that the prospect is failing, inadequate, behind, making mistakes, or morally compromised?" If yes, flag it.

For each flagged passage, extract:
- **Quote:** The exact passage (or paraphrase if long)
- **Threat type:** Explicit (directly states inadequacy) or Implicit (implies it through comparison, statistic, assumption, or scenario)
- **Identity domain threatened:** Which aspect of the prospect's identity is at risk? (e.g., competent entrepreneur, good parent, smart investor, moral person)
- **Threat level:** LOW / MEDIUM / HIGH

### Step 3: Pre-Frame Coverage Check
For each flagged threat, look backward in the copy to answer: "Is there a genuine affirmation of the prospect, in a domain they would value, that precedes this threat?"

Mark each threat as:
- **COVERED** — A genuine, identity-relevant affirmation precedes this threat in the copy
- **BARE** — No such affirmation exists before this threat

### Step 4: Cumulative Load Assessment
Count total threats by level. Calculate bare threat count by level. Assess the aggregate threat load by section (Lead, Body, Close, CTA zone).

### Step 5: Coverage Map Production
Produce the audit deliverable.

---

## OUTPUT STRUCTURE

### Header
- **Piece analyzed:** [Title / URL / Description]
- **Date audited:** [YYYY-MM-DD]
- **Total threat count:** [N]
- **Bare threat count:** [N HIGH | N MEDIUM | N LOW]
- **Overall identity risk rating:** LOW / MODERATE / HIGH / CRITICAL

**Rating guide:**
- LOW: 0-1 bare medium threats, 0 bare high threats
- MODERATE: 2-3 bare medium threats OR 1 bare high threat
- HIGH: 4+ bare medium threats OR 2 bare high threats
- CRITICAL: 3+ bare high threats OR cumulative bare load concentrated in the lead

---

### Section 1: Threat Inventory

For each identified threat:

**Threat [N]**
- **Location:** [Section name + paragraph/line reference]
- **Quote:** "[Exact text or paraphrase]"
- **Type:** Explicit / Implicit
- **Domain threatened:** [e.g., Competence as entrepreneur / Self-worth as parent]
- **Threat level:** LOW / MEDIUM / HIGH
- **Pre-frame status:** COVERED / BARE
- **If COVERED:** "[Quote the affirmation that precedes it]" — [Assessment: genuine or weak?]
- **If BARE:** Flag. No affirmation precedes this threat.

---

### Section 2: Cumulative Load Map

A section-by-section summary of threat density:

| Section | Threats (H/M/L) | Bare Threats | Cumulative Load | Risk |
|---------|-----------------|--------------|-----------------|------|
| Lead | | | | |
| Body | | | | |
| Close | | | | |
| CTA Zone | | | | |
| **Total** | | | | |

---

### Section 3: Critical Defects

Any HIGH-level bare threat listed individually as a critical structural defect requiring immediate remediation:

**Critical Defect [N]:** [Location]
- **The threat:** [Quote]
- **Why it's critical:** [What defensive processing this triggers]
- **What a pre-frame must accomplish here:** [Domain, tone, placement requirement]

---

### Section 4: Affirmation Coverage Assessment

A review of the affirmations that ARE present in the copy:

| Affirmation | Location | Domain | Quality | Coverage Radius |
|-------------|----------|--------|---------|-----------------|
| [Quote] | [Where] | [Which identity facet] | GENUINE / WEAK / GENERIC | [Which threats downstream does it cover?] |

**Generic affirmation failure check:** Are any of the affirmations present actually too generic to work? (e.g., "smart people like you" used in copy where the prospect may not identify as "smart" as a core identity marker)

---

### Section 5: Priority Repair List

Ranked by urgency (HIGH bare first, then cumulative load concentration):

| Priority | Threat | Current Status | Repair Required |
|----------|--------|----------------|-----------------|
| 1 | [Threat N] | BARE HIGH | Install [domain] affirmation before [location] |
| 2 | ... | | |

---

## OUTPUT FILE

Save to:
`[project-folder]/Claude Steele - Identity Threat Audit/[Copy-Name] - Threat Audit - [Date].md`

---

## OUTPUT FORMAT — GIRARD STANDARD (canonical)

Produce a standalone Field Intelligence document conforming to the **Girard Standard**.

**Canonical spec:** `~/.claude/skills/_shared/output-formats/field-intelligence-girard-format.md` — read in full before producing output.

### Hard requirements

- **Length:** 250-400 lines (200 floor; 800 ceiling)
- **Fully self-contained** — reader must understand the analysis with no other file open
- **YAML frontmatter** including: `skill`, `target`, `analyst`, `date`, `analysis_type`, `status`, `priority_finding`
- **Epigraph** — a relevant quote from the source thinker, with application clause
- **Executive thesis** — 3-5 paragraphs that answer: what is analyzed, what lens is applied, what is the headline finding, why does it matter
- **Numbered sections** with embedded **verbatim quotes** from the target (no script-section shorthand like "S3.5" without quoting the actual words)
- **Falsifier check** — a section naming what would have to be false for the analysis to be wrong
- **Conclusion** with deployable verdict (action recommended or no action recommended, named)

### Forbidden patterns

- Script-section shorthand without embedded quote ("S3.5 has X" without the quote)
- Cross-references to other skill outputs ("see [other-skill] audit")
- Glossary references instead of inline definitions
- Generic verdicts ("strong"/"weak") without mechanism
- Closing summary that restates findings (padding)
- Version-comparison markers internal to the analysis ("v5 said X; v10 says Y" — belongs in commit log)

### Output path

Save to: `[project-folder]/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/steele/03-identity-threat-audit.md`

### Exemplars (read at least two before producing)

1. `Active-Brain/00 Projects/Support Pets - Girard Analysis/02-desire-autopsy.md`
2. `Active-Brain/00 Projects/Support Pets - Girard Analysis/03-rivalry-detector.md`
3. `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/05-qualification-architect.md`

### The "no flipping" test

Before declaring output complete: imagine a colleague opening this file cold, with no project context. Can they understand the analysis end-to-end without opening any other file? If no, the document has failed the standard. Rewrite.

---

## KNOWN PATTERNS (Field-Tested)

Patterns this skill has identified in production runs. Each entry encodes diagnostic intelligence the skill should apply to future targets.

---

### Pattern: Structural Defect Cluster — Multiple BARE HIGH Threats in Proximity

**Classification:** Anti-pattern

**Description:** When two or more HIGH-severity bare threats appear within the same zone of a script or long-form sales piece (within 3-5 minutes of script time or 5-8 paragraphs of written copy), they form a structural defect cluster. A single BARE HIGH is a critical defect; a cluster of 2-3 in proximity is a critical zone — the viewer has no recovery window between defensive processing events. Detect by mapping BARE HIGH threats to their script timestamps or section positions, then flagging any concentration of 2+ within a 12-18 minute window.

**Mechanism:** Steele's self-affirmation mechanism requires that the prospect restore their sense of overall self-integrity before they can re-engage with threatening content. A single BARE HIGH gives the prospect one defensive repair event. A cluster denies recovery time — each successive threat arrives while the prospect is still in defensive mode from the previous one. The compounding effect is not additive; it is multiplicative. The prospect who absorbs three BARE HIGH threats in sequence is not three times as threatened; their self-integrity reservoir has been depleted and their cognitive resources are now entirely allocated to self-repair rather than evaluating the offer.

**Worked example:** In the ZMOS evergreen webinar v5, Sections 5-7 contained three BARE HIGH threats in proximity: "32 journals — dormant, useless" (S5), "Fear of being irrelevant, forgotten, like you had never existed" (S7), and "I stayed in perpetual potential mode — always about to be great, never having to find out if I actually am" (S7). These arrived 12-18 minutes after the S0.5 affirmation buffer had partially decayed and within the same structural zone of the webinar. The cluster was rated CRITICAL. The fix (Section 5.5 depth-of-self-attention pre-frame) was inserted upstream of all three threats in v6, converting all three from BARE HIGH to BUFFERED by providing a single domain-specific affirmation deposit that covered the entire cluster.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/steele/03-identity-threat-audit.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern: BARE HIGH / BUFFERED / DECOUPLED Classification System

**Classification:** Load-bearing pattern

**Description:** Every flagged threat must be classified into exactly one of three categories — not covered/bare binary. BARE HIGH: threat is high-severity, personally activatable, and has no upstream affirmation in a non-overlapping domain. BUFFERED: threat is high-severity but a genuine upstream affirmation (self-generative, domain-specific, selective rather than generic) precedes it within the effective radius. DECOUPLED: the threat does not activate the viewer's self-concept because it is explicitly about the presenter or a third party, or it resolves within 20 seconds before defensive processing can fire. The distinction between BUFFERED and DECOUPLED is mechanism-critical: BUFFERED threats require an affirmation deposit to neutralize; DECOUPLED threats do not activate the mechanism at all. Misclassifying a DECOUPLED threat as BUFFERED inflates the apparent coverage of a piece and can mask true BARE HIGH threats.

**Mechanism:** Steele's theory requires four simultaneous conditions for a threat to trigger defensive recoil: domain relevance, personal activatability, no prior mitigation affirmation, and pre-purchase timing. DECOUPLED threats fail condition 2 — they are not personally activatable because the prospect is in witness mode (observing someone else's situation) rather than subject mode (being addressed directly). BUFFERED threats fail condition 3 — a genuine non-overlapping affirmation has been deposited. BARE HIGH threats meet all four. The classification system forces the auditor to test each condition explicitly rather than relying on impression.

**Worked example:** In the ZMOS v10 audit, the threat "I came home from that retreat. Looked at the 32 journals. And I thought: there has to be something that can hold all of this at once" was classified DECOUPLED (Rich is the subject; the viewer is in narrative-witness mode, not direct-address mode). The threat "Fear that even if you do the work... you'll still be operating in the dark" was classified BUFFERED (residual S1 buffer + universalization as shared fear, not personal accusation). The threat "32 journals — dormant, useless" in v5 was classified BARE HIGH (all four conditions met; no upstream affirmation in the depth-of-self-attention domain). All three required different audit responses. Without the three-way classification, the v5 critical defect would have been masked by the presence of earlier affirmations that were domain-non-overlapping.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/steele/03-identity-threat-audit.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern: Cumulative Threat Load Mapping by Section

**Classification:** Load-bearing pattern

**Description:** Produce a section-by-section table tracking: number of HIGH threats per section, number of BARE HIGH per section (the critical count), the active buffer source for that section, and the resulting risk rating. The table makes cumulative load visible in a way that per-threat inventory cannot: it reveals zones where multiple threats share the same (decaying) buffer, where buffer radius has expired, and where a new affirmation deposit is needed not because any single threat is unprotected but because the cumulative load has exceeded what one upstream affirmation can carry. Identify the "thinnest coverage window" — the section with the highest threat count against the most decayed buffer.

**Mechanism:** Steele's research shows that affirmation effects decay over time as the self-integrity reservoir is gradually depleted by subsequent threats. An affirmation that fully covers a threat arriving 2 minutes later provides only partial coverage for a threat arriving 12 minutes later — even if both threats are in the same domain. Cumulative load mapping forces the auditor to track the temporal decay of each affirmation deposit and identify the sections where aggregate threat load outpaces buffer capacity. Without this view, an audit can report zero BARE HIGH threats while missing a moderate-risk zone where six MEDIUM threats have progressively drained the buffer below functional threshold.

**Worked example:** In the ZMOS v10 audit, the cumulative load table revealed that S4 (Three Fears) carried three consecutive HIGH threats against a residual S1 buffer that was 7-8 minutes decayed and domain-non-overlapping with the self-knowledge-competence threat (Threat 8: "Fear that even if you do the work... you'll still be operating in the dark"). No single threat was BARE HIGH, but the table revealed that Threat 8 had the weakest coverage in the pre-S5 zone. The table also revealed that Block B.5 in the close was the "thinnest coverage window" in v10 — the cost-of-inaction threat arrived when the S11.5 Seer reframe was 10-15 minutes decayed, producing marginal but acceptable coverage. Both risks were surfaced by the table, neither by individual threat inventory.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/steele/03-identity-threat-audit.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern: Threat Closure Tracking — Version-to-Version BARE HIGH Progression

**Classification:** Convergence signal

**Description:** When auditing a revised version of a previously audited piece, map each v-prior BARE HIGH threat to its current classification and record the specific script construction that effected the change. A threat that was BARE HIGH in a prior version and is BUFFERED in the current version has been "closed." A threat that remains BARE HIGH has "regressed" or "persisted." Track closure rate across versions as a structural health signal. A piece that closes all prior BARE HIGH threats with a single upstream insertion (rather than piecemeal per-threat fixes) has identified a load-bearing affirmation — a single block doing multi-threat coverage work. Flag that block explicitly: it is the highest-leverage element in the script and must not be cut in future revisions.

**Mechanism:** Copy revisions typically address individual feedback items rather than structural threat architecture. The result is that version N may fix one visible BARE HIGH while inadvertently cutting the upstream affirmation that buffered three others (because the affirmation "didn't seem necessary" to the editor). Closure tracking forces an audit of what architectural changes were made, not just what content changed — and identifies which single insertions are doing the most structural work. A load-bearing affirmation that covers 3-4 HIGH threats is the most fragile element in the script: editors who don't understand its coverage radius will cut it for pacing and re-expose the threats it was protecting.

**Worked example:** The ZMOS v5 → v10 evolution showed four BARE HIGH closures: "32 journals — dormant, useless" (BARE HIGH → BUFFERED via Section 5.5), "Fear of being irrelevant, forgotten" (BARE HIGH CRITICAL → BUFFERED via Section 5.5 + AI-attribution framing), "Perpetual potential mode" (BARE HIGH CRITICAL → BUFFERED via Section 5.5 + invisibility framing), and the S7 Beat C "Three Changes" comparative threat (BARE HIGH → BUFFERED via the selective-attribution post-frame). Three of the four closures were produced by a single insertion — Section 5.5, the depth-of-self-attention pre/post-frame. Section 5.5 is the load-bearing affirmation for the entire S5-S7 zone. Its removal would re-expose three BARE HIGH threats simultaneously. The audit flagged it explicitly as the highest-leverage element in the script.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/steele/03-identity-threat-audit.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)
