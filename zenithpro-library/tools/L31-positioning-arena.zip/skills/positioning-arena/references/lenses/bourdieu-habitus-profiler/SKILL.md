---
name: bourdieu-habitus-profiler
description: Profile internalized dispositions and automatic behaviors of a market.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Pierre Bourdieu (The Logic of Practice, 1980; Outline of a Theory of Practice, 1977) — Skill 3 of 6"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/bourdieu-habitus-profiler {audience-or-segment-description}"
  called_by: [user, bourdieu-distinction-mapper, bourdieu-field-analyzer]
  outputs_to: [client-output-folder]
girard_integration:
  feeds_from: [girard-model-map]
  feeds_to: [girard-mimetic-content-strategist]
  shared_data: "Model Map shows WHO is being imitated. Habitus Profiler reveals WHY certain models resonate — they share habitus dispositions with the audience. A model whose habitus matches the audience feels 'natural' to follow; one whose habitus clashes feels 'off' even if their advice is correct."
veblen_integration:
  feeds_from: [veblen-status-intelligence]
  feeds_to: [veblen-signal-decoder]
  shared_data: "Status Intelligence maps tier placement by signals. Habitus Profiler reveals the GENERATING DISPOSITIONS behind those signals — why players at each tier naturally produce certain signals without thinking about it. Habitus generates practice; signals are the visible trace of habitus."
loewenstein_integration:
  feeds_from: [loewenstein-empathy-gap-map]
  feeds_to: [loewenstein-visceral-audit]
  shared_data: "Empathy Gap Map shows how emotional states shift decision-making. Habitus Profiler reveals which emotional states feel NATURAL vs. FOREIGN to the audience — their habitus predisposes them to certain emotional registers and makes others feel manipulative."
---

# Bourdieu Habitus Profiler

---

## LAYER 1: INVARIANTS (Never override.)

1. **Habitus is NOT a personality type.** It is a system of durable, transposable dispositions acquired through social experience. Do not reduce habitus to psychology ("they're risk-averse") or demographics ("they're millennials"). Habitus is the accumulated, embodied social history that generates practices and perceptions WITHOUT conscious deliberation. It is the reason certain messages feel "natural" and others feel "off" — before any conscious evaluation.

2. **Map dispositions, not preferences.** Preferences are surface expressions. Dispositions are the generative structures underneath. "They prefer long-form content" is a preference. "They are disposed toward demonstrated expertise before trust, because their social trajectory taught them that shortcuts lead to failure" is a habitus disposition. Always go to the generating level.

3. **Habitus-field fit is the central assessment.** Every habitus operates within a field (market). The fit between a person's habitus and the field they're operating in determines whether they feel "at home" or "out of place." A buyer whose habitus matches the field moves comfortably toward purchase. A buyer whose habitus clashes with the field feels invisible friction. Map the fit, not just the habitus.

4. **Hysteresis must be detected.** The Don Quixote effect: habitus formed under one set of conditions persists even when conditions change. People carry the dispositions of their PREVIOUS position into their CURRENT situation. Founders who grew up resource-constrained carry scarcity dispositions into abundance. Former employees carry institutional dispositions into entrepreneurship. This lag is often the root cause of "irrational" resistance to offers that should logically appeal.

5. **The seller's habitus is part of the analysis.** The client's own habitus shapes what they produce — their content, voice, offer structure, and sales approach all express their habitus. When the seller's habitus clashes with the buyer's habitus, the result is invisible friction that neither side can name. Map BOTH sides.

---

## LAYER 2: QUALITY GUIDANCE

6. **Habitus clivé (split habitus) is often the most strategically important finding.** When buyers have experienced significant class mobility — working-class origins, now high-income; academic background, now entrepreneurial — they carry a SPLIT habitus. Part of them responds to their origin dispositions, part to their current position. Messages that speak to only one side miss the other. Detecting split habitus explains why audiences seem "contradictory."

7. **'Feel' trumps 'logic' for habitus alignment.** When a message is logically correct but "feels wrong" to an audience, the problem is almost always habitus mismatch. The message violates the audience's internalized sense of how things should be done/said/presented. Prioritize mapping what "feels right" to the audience over what "makes sense."

8. **Practical mastery over discursive mastery.** People usually cannot ARTICULATE their habitus — it operates below conscious awareness. They can't tell you why a message feels "off" because the disposition that rejects it was never conscious to begin with. Use behavioral evidence (what they engage with, share, buy) rather than stated preferences (what they say they want).

---

## PURPOSE

Marketing frequently encounters a puzzling failure mode: a message that is logically correct, well-targeted, and attractively priced simply doesn't connect. The audience can't explain why. The marketer can't explain why. The offer "should" work.

Bourdieu's concept of habitus explains this: every audience carries internalized dispositions — ways of perceiving, thinking, feeling, and acting — that were formed by their social trajectory. These dispositions operate like a grammar: they generate an infinite number of practices (including purchasing decisions) but within structured limits. A message that violates this grammar feels "wrong" even though no one can explain the rule it broke.

This skill profiles the habitus operating in a market segment so you can see: what dispositions generate their behavior, what feels natural vs. forced, where the invisible friction lives, and how to align messaging with the audience's internalized grammar rather than fighting it.

---

## INPUT REQUIREMENTS

Provide:
1. **Audience segment definition** — who they are, where they came from, what they do now
2. **The offer or message** — what's being sold or communicated
3. **Performance data or observations** — what's working, what's not, where the friction appears

Optional:
- Social trajectory data (what class/professional backgrounds dominate this segment)
- Content engagement data (what they engage with, share, avoid)
- Client self-description (their own background and trajectory — for habitus match analysis)

---

## EXECUTION PROCESS

### Step 1: Social Trajectory Mapping

Before mapping dispositions, map the TRAJECTORY — where this audience came from:

**Class origin:** What socioeconomic background dominates this segment? (Working class, middle class, upper middle, professional class)
**Educational trajectory:** What kind of education? Academic, vocational, self-taught, mixed?
**Professional trajectory:** Corporate → entrepreneur? Always independent? Academic → business? Each trajectory produces different dispositions.
**Mobility direction:** Moving up, stable, moving down, lateral shift? The DIRECTION of mobility shapes habitus as much as the position.
**Formative experiences:** What shared experiences shaped this cohort? (Recession graduates, dot-com era, social media natives, pre-internet business builders)

### Step 2: Disposition Mapping

For the identified social trajectory, map the core dispositions:

**Temporal dispositions:** How do they relate to time? (Long-horizon planning vs. immediate returns, patience vs. urgency, delayed gratification capacity)
**Risk dispositions:** How do they relate to uncertainty? (Calculate and control vs. leap and adjust, earned confidence vs. borrowed confidence)
**Authority dispositions:** How do they relate to expertise? (Defer to credentials vs. trust results, respect institutions vs. trust individuals, earned authority vs. positional authority)
**Investment dispositions:** How do they relate to spending money? (Investment mindset vs. cost mindset, comfort with premium vs. value-seeking, what feels "expensive" vs. "appropriate")
**Learning dispositions:** How do they acquire new knowledge? (Systematic study vs. experiential learning, frameworks vs. stories, theory vs. practice)
**Communication dispositions:** What register feels natural? (Formal vs. casual, nuanced vs. direct, elaborate vs. concise, intellectual vs. practical)
**Social dispositions:** How do they relate to groups? (Joiners vs. independents, networkers vs. isolators, collaborators vs. competitors)

### Step 3: Field-Habitus Fit Assessment

Assess how well the audience's habitus fits the FIELD (market) they're operating in:

**High fit areas:** Where do their dispositions match the field's requirements? (These areas feel effortless)
**Low fit areas:** Where do their dispositions clash with the field's requirements? (These areas feel like constant struggle)
**Adaptation zones:** Where have they consciously adapted despite habitus mismatch? (These adaptations are fragile under stress)
**Hysteresis zones:** Where are they carrying dispositions from a PREVIOUS field that no longer serve them? (These are the "irrational" behaviors)

### Step 4: Habitus Clivé Detection

Assess for split habitus:

**Origin pull:** What dispositions from their origin position are still active? (e.g., scarcity mindset despite current wealth, institutional deference despite being independent)
**Current pull:** What dispositions have they developed in their current position? (e.g., premium comfort, independence, strategic thinking)
**Tension zones:** Where do origin and current dispositions conflict? (These tensions create ambivalence in purchasing decisions)
**Which voice to speak to?** For split-habitus audiences, identify whether marketing should address the origin habitus, the current habitus, or explicitly bridge between them.

### Step 5: Seller-Buyer Habitus Match Analysis

Map the CLIENT'S habitus alongside the buyer's:

**Shared dispositions:** Where do seller and buyer habitus overlap? (These are natural resonance points)
**Clash points:** Where do seller and buyer habitus diverge? (These create invisible friction in messaging)
**Blind spots:** What does the seller's habitus make INVISIBLE to them? (A seller with high cultural capital may not realize their vocabulary excludes their audience)
**Habitus translation needs:** Where does the seller need to translate their natural expression into the buyer's habitus grammar?

### Step 6: Message-Habitus Alignment Audit

If a specific message/offer/funnel is provided, audit it against the mapped habitus:

**Alignment points:** Where does the message match buyer dispositions? (Feels natural, easy to engage)
**Friction points:** Where does the message violate buyer dispositions? (Feels forced, creates resistance)
**Habitus-foreign elements:** What parts of the message could only feel natural to someone with a DIFFERENT habitus? (These are the invisible repellents)
**Missing signals:** What habitus-congruent elements are absent? (What the audience unconsciously expects but doesn't find)

### Step 7: Self-Examination

Surface the honest assessment:
- Is the client projecting their own habitus onto the audience? (The most common failure)
- Are they marketing to who they WERE rather than who their audience IS?
- Is their resistance to certain tactics actually habitus-based rather than strategic? (Refusing direct response because it "feels cheap" is a habitus response)
- Are they confusing their taste for universal quality? (A misrecognition Bourdieu would immediately identify)

---

## OUTPUT STRUCTURE

### Habitus Profile Report

**Section 1: Social Trajectory Map**
Where this audience came from, what shaped their dispositions, what mobility pattern dominates.

**Section 2: Disposition Map**
Core dispositions across 7 dimensions (temporal, risk, authority, investment, learning, communication, social), with behavioral evidence for each.

**Section 3: Field-Habitus Fit Assessment**
Where the audience's habitus matches and clashes with the market's requirements. Hysteresis zones and adaptation fragilities.

**Section 4: Habitus Clivé Analysis**
Split habitus detection — where origin and current dispositions conflict, and which voice to address.

**Section 5: Seller-Buyer Habitus Match**
Where the client's habitus aligns and clashes with the buyer's. Blind spots and translation needs.

**Section 6: Message Alignment Audit**
Specific alignment and friction points in the current messaging/offer, with habitus-foreign elements identified.

**Section 7: Self-Examination**
Honest assessment of the client's own habitus projections, taste misrecognitions, and strategic blind spots.

**Section 8: Cross-System Integration**
If Girard/Veblen/Loewenstein data exists: How does habitus shape desire imitation (Girard), status signaling (Veblen), and decision-making patterns (Loewenstein)?

**Section 9: Strategic Recommendations**
Specific habitus alignment moves — messaging adjustments, voice shifts, offer restructuring, friction removal — with rationale tied to the disposition map.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Pierre Bourdieu - Habitus Profiler/01 - Habitus Profile - [Segment] - [Date].md`
