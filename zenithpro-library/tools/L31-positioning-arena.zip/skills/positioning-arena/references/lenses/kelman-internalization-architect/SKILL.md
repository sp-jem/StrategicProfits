---
name: kelman-internalization-architect
description: Designs internalization-pathway copy architecture — value-congruence auditing, values-surfacing lead structure, offer-as-identity-extension framing, and values-consistency proof architecture. The highest-LTV pathway builder in the Kelman system.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Herbert Kelman (Compliance/Identification/Internalization) — Idea 5"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/kelman-internalization-architect {offer} {avatar-values}"
  called_by: [user, kelman-field-intelligence]
  outputs_to: [project-folder]
---

# Kelman Internalization Architect

---

## LAYER 1: INVARIANTS (Never override.)

1. **Internalization cannot be manufactured — only matched. PREREQUISITE GATE ENFORCED.** Per Kelman (1958, 2006): "Value congruence is not merely a matter of the individual's agreement with the content; it requires that the content be experienced as an expression of what the individual himself believes and stands for." Copy that produces values-sounding language without genuine values research will activate identification at best — the prospect admires the values-language and relates to the source — but not internalization. Internalization requires the prospect to recognize their own existing value system in the offer. This recognition cannot be fabricated. It can only be found and reflected back.

   **GATE:** This skill MUST receive the avatar's actual value system (documented through research, interviews, or survey data) before producing any output. Aspirational values ("they want to feel free") are not the avatar's actual value system. Demographic descriptors ("busy entrepreneur") are not values. The values input must describe what this specific segment actually holds as intrinsically important — not what they wish they valued, not what appeals to them as an aspiration. If this input is absent, request it before proceeding. Do not produce internalization-pathway copy without it.

2. **Internalization anchors to the EXISTING value system — not aspirational values.** Per Kelman (1961): "Copy that targets the values the prospect wishes they had (aspirational values) may produce identification with a hoped-for self, but not internalization. Internalization anchors to the existing value system — the prospect as they actually are, not as they wish to be." The critical diagnostic: Is the copy saying "you could become someone who values X" (aspiration = identification with hoped-for self) or "you already ARE someone who values X — and this offer is consistent with who you already are" (internalization)?

3. **Internalization is only available in high-involvement categories.** Per Kelman (1958): if a prospect is purchasing in a low-involvement state (habitual, convenience, price-driven), the value system is not engaged and internalization cannot occur regardless of copy quality. Before designing internalization-pathway copy, confirm: Is this a high-involvement purchase where the prospect's self-concept is activated? If not, route to compliance or identification — internalization copy on a low-involvement offer is wasted architecture.

4. **Value-congruence requires behavioral evidence, not just claimed alignment.** Per Kelman (2006): "If copy claims values alignment but the product's track record, pricing, or company behavior contradicts the claimed values, the prospect detects the incongruence and rejects the internalization pathway." The proof architecture for internalization must include behavioral evidence of the offer's values-consistency — not just values statements. "We believe in X" is not evidence. "Here is how our product was designed around X, here is a decision we made that cost us money but preserved X, here is what changed for someone whose core value is X" is evidence.

5. **Internalization produces the highest-LTV buyer profile — and the hardest-to-reverse belief change.** Per Kelman (1974, 2006): internalized attitudes resist competing influence because they are anchored in the prospect's own value structure. A competitor must challenge the entire value system to dislodge an internalized belief — the hardest condition to create without triggering reactance. An internalized buyer who refers is expressing a value, not a relationship or a surveillance response. This LTV profile is the target. Never underestimate the investment required to earn it — or the commercial return when it is achieved.

---

## LAYER 2: QUALITY GUIDANCE

6. **The values-surfacing lead is the most powerful internalization technique.** Copy that activates a relevant value BEFORE making the offer dramatically increases internalization-pathway activation. The mechanism: make the value salient immediately before the offer attempt, so the prospect's value system is engaged when they encounter the offer's value-congruent content. A lead that opens with "You've always believed that..." or presents a worldview statement that resonates with the prospect's actual values primes the internalization pathway before the offer appears.

7. **Proof architecture for internalization looks completely different from compliance proof.** Compliance proof demonstrates the agent's power to deliver the reward (testimonials about results, before/after, ROI claims). Internalization proof demonstrates values-consistency of the offer (how the product's design reflects the stated values, what the company chose NOT to do because it would violate the values, how customers describe the values fit — not just the results). The proof for internalization is about coherence and authenticity, not just outcomes.

8. **"You're already the kind of person who..." framing is the internalization-pathway's signature technique.** This framing explicitly anchors to the prospect's existing self-concept: "You've already proven that X matters to you by the way you've built your business. This program is for people like you — not to change who you are, but to give your existing values a better vehicle." This framing does not require the prospect to adopt new values. It locates the offer as an expression of values they already hold.

---

## PURPOSE

Internalization-based copy does not sell the product — it matches the product to who the reader already is. Most copy sells. Internalization-pathway copy recognizes.

The commercial payoff is the highest-LTV buyer in the business model: one who does not require re-activation, who generalizes to adjacent offers, who refers without prompting, and whose belief in the brand survives interruptions and competitive offers because it is anchored in their own value system, not in the agent's presence.

This skill designs the full internalization-pathway architecture: the prerequisite value-system research gate, the values-surfacing lead structure, the value-congruence audit framework, the values-consistency proof architecture, and the identity-extension offer framing.

---

## INPUT REQUIREMENTS — PREREQUISITE GATE (NON-NEGOTIABLE)

**This skill will not produce output until all prerequisite inputs are received. This is not a courtesy gate — it is a quality gate. Internalization copy produced without genuine values research is identification copy at best.**

**Required Input 1: Avatar's Actual Value System**
Not aspirational values. Not demographics. The prospect's actual existing values, documented through research.

This means providing at least one of:
- Survey or interview data showing what this segment explicitly identifies as important to them
- Behavioral evidence of their values (what they have chosen, what they have refused, what they have paid for that had no extrinsic reward)
- Documented statements from existing customers about why this offer fits who they already are (not just what it does for them)
- Psychographic research that identifies the dominant value orientation of the target segment

If you have none of these, run `avatar-excavation` or `psychographic-excavation` first. Do not submit aspirational guesses as values research.

**Required Input 2: Offer Description**
What is being offered, at what commitment level, and what does it actually DO? (Not the value proposition — the actual mechanism and content.)

**Required Input 3: Category Involvement Level**
Is this a high-involvement purchase? Does the prospect's self-concept engage when considering this offer? (High-involvement indicators: significant price, significant time commitment, identity-relevant category, prospect deliberates rather than defaults.)

**Required Input 4: Values-Consistency Evidence Available**
What behavioral evidence exists that the offer's design, the company's decisions, or the product's track record is consistent with the stated values? If none exists, flag this before designing copy — a values-consistency claim without evidence will be detected as inauthentic.

---

## EXECUTION PROCESS

### Step 1: Value System Analysis
From the provided values research, identify:

- **Dominant values (top 3):** The values that are most load-bearing in this segment's self-concept and decision-making
- **Value expression patterns:** How do these prospects express their values? (What language do they use? What decisions reveal these values? What do they criticize in others that implicitly reveals their own values?)
- **Value-threat sensitivities:** What would the prospect experience as a violation of their values? (Important for negative space — what not to say or do.)
- **Values most relevant to this offer:** Which of the dominant values connect most directly to the offer's content and mechanism?

### Step 2: Value-Congruence Audit
Audit the offer against the identified values:

For each dominant value that connects to the offer:
- **Congruence claim:** Where is the offer genuinely, demonstrably congruent with this value?
- **Evidence available:** What behavioral proof substantiates this congruence?
- **Incongruence risks:** Are there aspects of the offer's design, pricing, structure, or company behavior that contradict this value? (If yes: flag these as credibility threats that must be addressed or eliminated before internalization-pathway copy can succeed.)
- **Congruence depth:** Is this surface congruence (the offer's language uses values vocabulary) or structural congruence (the offer is built around this value in ways that show in its design and outcomes)?

Surface congruence → can support identification but not internalization.
Structural congruence → can support internalization.

### Step 3: Values-Surfacing Lead Design
Design the lead sequence that primes the internalization pathway before the offer appears:

- **Values activation opener:** A statement, story, or observation that activates the prospect's relevant value before any offer language appears. The prospect must feel "this resonates with how I actually think" before they encounter the offer.
- **"You've always believed that..." bridge:** The explicit moment of connecting the activated value to who the prospect already is.
- **Proof of shared values recognition:** A moment where the source demonstrates they hold the same value — not just that they offer something the prospect might want.
- **Transition to offer:** How the copy moves from values recognition to offer introduction without rupturing the values context. The offer must enter as a natural extension of the values discussion, not as an interruption.

### Step 4: Offer-as-Identity-Extension Framing
Design the framing that positions the offer as an expression of the prospect's existing self-concept:

- **The "already who you are" proposition:** How is acceptance of this offer an act of self-consistency, not persuasion? What does saying yes mean about who the prospect already is?
- **The "not a transformation" reframe:** Internalization-pathway copy explicitly or implicitly rejects the "become someone new" frame (which requires adopting new values = aspiration/identification). The offer is positioned as: "This is for people who already are X. It gives X people a better way to be X."
- **Value-extension language:** Specific phrases that carry the "natural next step for someone with your values" quality.

### Step 5: Values-Consistency Proof Architecture
Design the proof structure that demonstrates behavioral values-consistency:

**Proof type 1: Design decision evidence**
Stories or statements about how the offer was designed around the stated value — especially decisions that constrained the product but preserved the value.

**Proof type 2: What we refused to do**
Evidence of choices the brand/founder made that cost money, ease, or scale but preserved the values. This is among the most powerful internalization proof because it demonstrates value salience over interest.

**Proof type 3: Behavioral testimony**
Customer statements that describe values fit, not just results. "I kept thinking, these people actually think like me" is internalization testimony. "I made $50,000" is compliance testimony.

**Proof type 4: Consistent values expression over time**
Evidence that the values have been held consistently across different contexts, communications, and market conditions. Internalization requires the prospect to perceive the values as genuine and structural, not marketing language.

### Step 6: Value-Relevance Priming Sequence
Design the content sequence before the offer appears that activates value relevance:

- **Pre-offer priming content:** What content (article, email, video, workshop) immediately precedes the offer attempt and activates the most relevant values?
- **Priming-to-offer timing:** The priming literature (Oyserman, Lewin) indicates that values must be salient at the moment of offer encounter. Design the timing accordingly — not weeks before, but hours before or in the same session.
- **Priming sequence (if multi-step):** If the funnel has multiple touchpoints, design the values activation sequence across the funnel so the relevant values are increasingly salient as the offer approaches.

### Step 7: Internalization Failure Mode Detection
Before finalizing the architecture, check for these specific failure modes:

- **Aspirational values substitution:** Has any values content slipped from "who you already are" to "who you could become"? If yes, rewrite.
- **Values sounding without values evidence:** Are there any values claims in the copy that are not supported by structural congruence evidence? If yes, either add evidence or remove the claim.
- **Low-involvement bypass:** Has anything in the copy shifted the prospect into low-involvement mode (price-comparison triggering, urgency framing, complexity that produces cognitive load)? If yes, redesign — low-involvement state blocks internalization.
- **Identification bleed:** Has identification-pathway language (personality-led, relationship-contingent) displaced internalization-pathway language (content-congruent, value-anchored) anywhere in the copy? Identification and internalization can coexist — but if identification is load-bearing where internalization was intended, flag and correct.

---

## OUTPUT STRUCTURE

### Internalization Architecture Design

**Header:**
- Offer: [description]
- Dominant avatar values: [top 3 from research]
- Values-consistency evidence: [available or gaps noted]
- Category involvement: [High / Medium — if Low, note why internalization was still attempted]
- Date: [YYYY-MM-DD]

**Section 1: Value System Analysis**
Dominant values, expression patterns, value-threat sensitivities, values relevant to this offer.

**Section 2: Value-Congruence Audit**
For each relevant value: congruence claim, evidence available, incongruence risks, congruence depth assessment.

**Section 3: Values-Surfacing Lead Structure**
The specific lead sequence: activation opener, "you've always believed" bridge, shared values recognition moment, transition to offer.

**Section 4: Offer-as-Identity-Extension Framing**
The "already who you are" proposition, the "not a transformation" reframe, value-extension language guidelines.

**Section 5: Values-Consistency Proof Architecture**
Proof inventory by type: design decisions, refusals, behavioral testimony, longitudinal values consistency.

**Section 6: Value-Relevance Priming Sequence**
Pre-offer priming content, priming-to-offer timing recommendations, multi-step priming sequence design.

**Section 7: Failure Mode Audit**
Assessment of each failure mode — whether it is present, and correction if so.

---

## OUTPUT FILE

Save complete architecture to:
`[project-folder]/Herbert Kelman - Internalization Architecture/[YYYY-MM-DD] - Internalization Architecture - [Offer Name].md`
