---
name: tajfel-distinctiveness-calibrator
description: Brewer ODT calibration tool — the headline skill of the bundle. Evaluates whether copy's in-group construction hits optimal distinctiveness for the target audience. Outputs Too Inclusive / Optimal / Too Exclusive assessment with specific adjustments. No universal thresholds — always audience-calibrated.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Henri Tajfel & John Turner (Social Identity Theory, Self-Categorization Theory) + Marilynn Brewer (Optimal Distinctiveness) — Idea 4"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/tajfel-distinctiveness-calibrator {copy-to-audit} [audience-profile]"
  called_by: [user, tajfel-field-intelligence, tajfel-qualification-architect]
  outputs_to: [client-output-folder]
depends_on: [tajfel-social-identity-activator, tajfel-salience-calibrator, tajfel-prototype-auditor]
---

# Tajfel Distinctiveness Calibrator

---

## LAYER 1: INVARIANTS (Never override.)

1. **No universal optimal distinctiveness number exists.** Brewer (1991) explicitly established that the optimal balance point between inclusion and differentiation needs is AUDIENCE-SPECIFIC. It shifts by demographic, by status level, by cultural context, by market maturity. "Join 500 operators" may be optimal for a high-status executive audience and too exclusive for a mass-market small business audience. Never apply a fixed membership size threshold. Always calibrate to the specific audience.

2. **"Join 17,000 customers" is a social proof move, not an optimal distinctiveness move.** Large-number social proof (Cialdini's normative influence) and optimal distinctiveness are separate mechanisms. For undifferentiated mass markets, large-number proof works because the social proof effect is primary. For high-identification, high-status audiences, "join 17,000 customers" submerges the prospect in a group so large it frustrates the differentiation need — the result is low identification, not high. This distinction must be made explicitly in every audit.

3. **The two needs have asymmetric activation dynamics.** Inclusion need is activated by threat of exclusion (being too alone, too different, unconnected). Differentiation need is activated by submersion in a too-large group (being indistinguishable, generic, ordinary). Different audiences have different chronic need levels. High-status audiences typically have lower chronic inclusion-need activation (they're rarely threatened by exclusion) and higher chronic differentiation-need activation (they're frequently submerged in large categories). Diagnose which need is more active for the specific audience before prescribing adjustments.

4. **The simultaneous dual-activation trigger is the power move.** "Rare enough to feel special + large enough to feel real" is the optimal distinctiveness formula. Copy that activates both needs simultaneously produces maximum identification. "Join 500 operators who have crossed $1M annually" — 500 is exclusive (differentiation need satisfied), "join...operators" implies real community (inclusion need satisfied). Build this structure into every recommendation.

5. **The Cialdini boundary is explicit.** Cialdini's social proof is the surface effect. Optimal Distinctiveness Theory explains the MECHANISM beneath it — why social proof works when it works, and why it fails when it fails. Skills in the tajfel-* bundle do not replace or compete with the cialdini-* bundle; they explain when Cialdini's normative proof is the right move (undifferentiated markets) vs. when ODT calibration is the right move (high-identification audiences). Citing both and routing correctly is required.

---

## LAYER 2: QUALITY GUIDANCE

6. **The failure modes produce opposite errors.** Too inclusive = everyone is the target, so no one feels special. The copy sounds like a mass offer. The differentiation need is frustrated. Identification is low. Too exclusive = the group is so small or so hard to access that the belonging signal is absent. The inclusion need is frustrated. Identification is also low. Name which failure mode is present — they require opposite fixes.

7. **Group size is a proxy, not the variable.** Brewer used group size as an operationalization in her experiments, but the underlying variable is distinctiveness signal strength, not raw number. A group of 500 with no qualifying criteria is less distinctive than a group of 2,000 with strong achievement-based membership criteria. The audit must assess distinctiveness signal quality, not just count members.

8. **Forced inclusion in too-large a group can be actively demotivating.** Copy that shows the prospect as one of 100,000 customers may actively lower purchase intent among high-differentiation audiences — not just fail to help, but actively harm. Flag this as an active risk, not merely a missed opportunity.

---

## PURPOSE

Marilynn Brewer's Optimal Distinctiveness Theory (1991) provides the calibration dial for in-group construction in copy. The theory specifies that people's identification with a group is maximized at the point where two fundamental needs are simultaneously satisfied: the need for inclusion (belonging, being part of a community) and the need for differentiation (being distinct, special, not just another face in the crowd).

This is the headline skill of the tajfel-* bundle because it answers the question that most copywriters get wrong: how exclusive should the group be? The answer is not "as exclusive as possible" or "as large as possible" — it is "optimal for this specific audience's need profile."

The skill also serves as the explicit interface between the tajfel-* bundle and the cialdini-* bundle: it specifies when large-number social proof is appropriate (normative compliance, undifferentiated markets) vs. when ODT calibration is required (high-identification, status-driven audiences).

---

## INPUT REQUIREMENTS

Provide:
1. **Copy to audit** — the in-group construction language: qualifying criteria, membership size signals, exclusivity language, community language
2. **Audience profile** — required; especially: status level, degree of prior identification with the category, chronic differentiation need (high = executives/successful entrepreneurs; moderate = growing businesses; lower = beginners/mass market)
3. (Optional) **Competitive context** — what distinctiveness signals the market is currently seeing; helps assess relative position

---

## AUDIT STRUCTURE

### Section 1: Inclusion Need vs. Differentiation Need — Audience Profile

**Step 1: Diagnose the audience's dominant need.**

**High differentiation need audience indicators:**
- High status, high achievement (executives, $1M+ operators, experienced professionals)
- Saturated with generic offers (everyone is targeting them the same way)
- Self-concept is built on being different from the crowd
- Currently in a context where they're often submerged in "everyone" categories
- Has many belonging options; being part of "any community" is not scarce

**High inclusion need audience indicators:**
- Isolated in their role (solopreneurs, niche professionals, people who feel they don't fit the mainstream)
- Frequently excluded from peer groups (too advanced for beginners, not established enough for elite groups)
- Primary pain is loneliness or lack of peers who understand their situation
- Currently has few belonging options

**Audience dominant need assessment:** [DIFFERENTIATION-DOMINANT / INCLUSION-DOMINANT / ROUGHLY BALANCED]

**Evidence:** [What in the audience profile supports this diagnosis]

---

### Section 2: Current Copy — Distinctiveness Signal Inventory

**Inclusion signals present in copy:**
List all language that activates inclusion need:
- Community/belonging language ("join X operators")
- Scale signals ("17,000 members already inside")
- Safety/acceptance language ("you're not alone")
- Shared struggle framing
- "We" language

**Differentiation signals present in copy:**
List all language that activates differentiation need:
- Exclusivity language ("not for everyone," "application required")
- Achievement-based membership criteria ("for those who have already...")
- Limited size signals ("only 500 spots," "exclusive cohort")
- Screening/qualification language
- Status language ("the top 1% of...")

**Balance assessment:**
- Which signals are stronger in the current copy?
- Is there a dual-activation structure (both needs addressed simultaneously)?
- Or does the copy activate one at the expense of the other?

---

### Section 3: Optimal Distinctiveness Assessment

**The calibration verdict:**

**[ ] TOO INCLUSIVE**
- Indicators: Large number claims without qualifying criteria, "anyone can join" framing, mass community language, no achievement bars, commodity positioning
- Effect: Differentiation need frustrated; prospect feels submerged, not special
- For high-differentiation audience: actively demotivating
- Fix direction: Add achievement-based membership criteria, reduce raw number emphasis, add exclusivity signals, specify who the group is NOT for

**[ ] OPTIMAL DISTINCTIVENESS**
- Indicators: Clear qualifying criteria that most people don't meet, membership size that feels like a real community but not a crowd, dual-activation structure present
- Effect: Both needs simultaneously satisfied; maximum identification
- Maintain and refine

**[ ] TOO EXCLUSIVE**
- Indicators: Criteria so stringent most prospects self-select out, group feels like a fantasy club, inclusion signals absent, prospect can't see themselves qualifying
- Effect: Inclusion need frustrated; prospect admires but doesn't self-categorize
- Fix direction: Add inclusion signals alongside exclusivity, provide a pathway to membership, show the community aspect alongside the exclusive criteria

**Current verdict:** [TOO INCLUSIVE / OPTIMAL / TOO EXCLUSIVE]

---

### Section 4: Cialdini Boundary Check

**Social proof type classification:**
- Is the copy using large-number social proof (Cialdini's normative influence)?
  - Appropriate when: undifferentiated mass market, high-belonging-need audience, early-market social proof building
  - Problematic when: high-differentiation audience, high-status targets, premium positioning
- Or is the copy using selective proof (ODT-calibrated)?
  - Appropriate for: high-differentiation audiences, premium/exclusive positioning

**Boundary diagnosis:**
If the copy is using large-number social proof with a high-differentiation audience, flag as: **Cialdini/ODT Mismatch** — the proof mechanism is wrong for this audience. The normative proof effect (everyone is doing it) competes against the differentiation need (I want to be different from everyone).

**Routing recommendation:**
- Undifferentiated market / high-belonging-need audience → `cialdini-social-proof-optimizer` (normative proof is the primary mechanism)
- High-differentiation / high-status audience → `tajfel-distinctiveness-calibrator` (ODT calibration is primary; use cialdini-* only for selective proof of in-group quality)

---

### Section 5: Optimal Distinctiveness Redesign

**If the current copy needs recalibration, produce specific rewrites:**

**The dual-activation formula:**
"[Exclusive enough to feel distinctive] + [Large enough to feel like a real community]"

**Rewrite for too-inclusive copy:**
- Original: [Quote the current inclusion-heavy language]
- Problem: [What the differentiation need that's being frustrated]
- Rewrite: [New version that adds achievement criteria without destroying community feel]
- Calibration note: [Why this version sits in optimal range for this specific audience]

**Rewrite for too-exclusive copy:**
- Original: [Quote the current exclusivity-heavy language]
- Problem: [What inclusion need is being frustrated]
- Rewrite: [New version that adds belonging signals without destroying exclusivity feel]
- Calibration note: [Why this version sits in optimal range for this specific audience]

**The three copy elements that most affect distinctiveness calibration:**
1. **Membership size signal** — how large the group appears; the primary distinctiveness proxy
2. **Qualifying criteria** — what achievement, belief, or behavior is required to belong
3. **Community vs. club framing** — whether the group feels like a community (inclusion) or an elite club (differentiation)

---

### Section 6: Calibration Score and Final Recommendations

| Dimension | Assessment |
|-----------|------------|
| Audience need profile diagnosed | YES / NO |
| Inclusion signals inventoried | YES / NO |
| Differentiation signals inventoried | YES / NO |
| Cialdini/ODT routing correct | YES / NO |
| Dual-activation structure present | YES / NO |
| Calibration verdict | TOO INCLUSIVE / OPTIMAL / TOO EXCLUSIVE |

**Final recommendations (3 specific changes in priority order):**
1. [Highest-impact change + specific copy rewrite]
2. [Second-highest-impact change + specific copy rewrite]
3. [Third-highest-impact change + specific copy rewrite]

**Pass/gate decision:** Does the in-group construction hit optimal distinctiveness for this audience?
- [PASS] → proceed to `tajfel-enemy-designator`
- [REVISE FIRST] → make the changes above, then re-audit

---

## OUTPUT FILE

Save complete audit to:
`[project-folder]/Tajfel — Distinctiveness Calibration/01 - Distinctiveness Audit - [Copy Name] - [Date].md`

---

## OUTPUT FORMAT — GIRARD STANDARD (canonical)

Produce a standalone Field Intelligence document conforming to the **Girard Standard**.

**Canonical spec:** `~/.claude/skills/_shared/output-formats/field-intelligence-girard-format.md` — read in full before producing output.

### Hard requirements

- **Length:** 250-400 lines (200 floor; 800 ceiling)
- **Fully self-contained** — reader must understand the analysis with no other file open
- **YAML frontmatter** including: `skill`, `target`, `analyst`, `date`, `analysis_type`, `status`, `priority_finding`
- **Epigraph** — a relevant quote from the source thinker, with application clause
- **Executive thesis** — 3-5 paragraphs that answer: what is analyzed, what lens is applied, what is the headline finding, why does it matter
- **Numbered sections** with embedded **verbatim quotes** from the target (no script-section shorthand like "S3.5" without quoting the actual words)
- **Falsifier check** — a section naming what would have to be false for the analysis to be wrong
- **Conclusion** with deployable verdict (action recommended or no action recommended, named)

### Forbidden patterns

- Script-section shorthand without embedded quote ("S3.5 has X" without the quote)
- Cross-references to other skill outputs ("see [other-skill] audit")
- Glossary references instead of inline definitions
- Generic verdicts ("strong"/"weak") without mechanism
- Closing summary that restates findings (padding)
- Version-comparison markers internal to the analysis ("v5 said X; v10 says Y" — belongs in commit log)

### Output path

Save to: `[project-folder]/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/07-distinctiveness-calibrator.md`

### Exemplars (read at least two before producing)

1. `Active-Brain/00 Projects/Support Pets - Girard Analysis/02-desire-autopsy.md`
2. `Active-Brain/00 Projects/Support Pets - Girard Analysis/03-rivalry-detector.md`
3. `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/05-qualification-architect.md`

### The "no flipping" test

Before declaring output complete: imagine a colleague opening this file cold, with no project context. Can they understand the analysis end-to-end without opening any other file? If no, the document has failed the standard. Rewrite.

---

## KNOWN PATTERNS (Field-Tested)

Patterns this skill has identified in production runs. Each entry encodes diagnostic intelligence the skill should apply to future targets.

---

### Pattern: Textbook ODT Pairing — Rarity-Clause + Populace-Clause in Adjacent Sentences

**Classification:** Load-bearing pattern

**Description:** Look for two adjacent sentences where the first clause establishes rarity ("rarer than you think," "most people like you have already given up") and the second clause dissolves isolation ("not as alone as you feel," "there are more of you than you've ever met"). The adversative conjunction "But" between them is the grammatical signature. When both clauses appear within 3-4 sentences and are connected by "But," the dual-need pair is firing simultaneously — this is the highest-leverage ODT construction available in cold-traffic copy. Flag its presence as a load-bearing asset; flag its absence as the primary gap when calibration is failing.

**Mechanism:** Brewer's ODT specifies that maximum in-group identification is produced when both the differentiation need and the assimilation need are satisfied simultaneously, not sequentially. Adjacent-sentence pairing collapses the gap between the two activations to near-zero, preventing the cognitive interference that occurs when the two needs are addressed in separate sections. The "But" adversative signals to the reader that the rarity claim is being held in place while the isolation is dissolved — the perceiver gets to keep the differentiation pride without paying the loneliness cost.

**Worked example:** ZMOS v10, Section 3.5 (Qualification Block, ~minute 8.5): *"you're rarer than you think. Most operators with your years of experience become Resigned Observers by 35. The fact that you're still feeling something — that's actually the signal that you're built differently from most of your peers. But you're not as alone as you feel. There are more Seers than you've ever met. They've been hiding in plain sight. They're who I built this hour for."* Audit finding: both needs activated in four sentences, connected by "But." Verdict: textbook ODT execution, calibration optimal. Recommendation: protect from editing pressure.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/07-distinctiveness-calibrator.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern: Single-Passage Dual-Activation as Highest-Leverage Move for Dual-Dominant Audiences

**Classification:** Load-bearing pattern

**Description:** When audience need diagnosis returns ROUGHLY BALANCED (both differentiation need and assimilation need are genuinely active and genuinely underserved), a single passage that fires both needs simultaneously outperforms two separate passages that each address one need. Diagnose for dual-dominance by checking: (1) audience is isolated by being ahead of peers, AND (2) audience is saturated by generic categories that don't capture them. When both are true, route the copy strategy to single-passage dual-activation rather than split treatment. Two sequential passages that address each need separately allow cognitive interference — the differentiation activation fades by the time the assimilation activation lands, and vice versa.

**Mechanism:** ODT's equilibrium model treats the two needs as simultaneously co-active in roughly balanced audiences. Satisfying them in sequence leaves one need temporarily frustrated while the other is being addressed — the frustrated need creates a pull that partially cancels the satisfaction of the addressed need. Simultaneous activation in a single passage resolves both tensions at once, producing the full identification payoff without the cancellation effect.

**Worked example:** ZMOS v10 audience profile: "high differentiation need" (10+ years self-development, saturated by generic entrepreneur offers, self-concept built on having done more than most) AND "high assimilation need" (isolated by being ahead, rarely meets peers who think this way). Audit finding: dual-dominant profile confirmed. Single-passage strategy at Section 3.5 outperforms the alternative of a separate rarity section + separate belonging section. The dual-activation lands cleanly because both needs are pulling simultaneously at the moment the passage fires.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/07-distinctiveness-calibrator.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern: Activation-at-Categorization vs. Confirmation-Inside-Identity (Early vs. Mid-Script ODT Placement)

**Classification:** Load-bearing pattern

**Description:** ODT activation fires differently depending on when in the script it lands. At the moment of initial categorization (early script, ~minute 8-10), the perceiver is being offered the in-group identity for the first time — both needs must be activated to install the category. After 30+ minutes of content have reinforced the identity, a second dual-activation passage lands from inside the in-group rather than as an external offer. Flag scripts that carry only one ODT passage for the risk of identity attrition: without a mid-script confirmation, the identity installed early erodes as the perceiver tracks through content and loses the emotional state of the categorization moment. The confirmation passage should not re-introduce the categories — it should confirm a categorization the perceiver has already made, using "us" and "we" rather than "you might be" language.

**Mechanism:** Self-categorization theory (Turner, 1987) establishes that category membership must be periodically reactivated to remain behaviorally salient. In a long-form webinar (60-80 minutes), a single early activation is insufficient — the perceiver's attention and emotional state fluctuate, and the categorization established at minute 8 has lost salience by minute 42 without reinforcement. The second passage operates on a different mechanism than the first: the first activates the identity (categorization event), the second confirms and deepens it (identity consolidation). Both are needed; neither substitutes for the other.

**Worked example:** ZMOS v10 deploys Passage A at minute 8.5 (categorization) and Passage B at minute 42 (confirmation): *"There aren't many of us. But there are enough."* Audit finding: the second passage is more compressed than the first because it doesn't need to introduce the category — the perceiver has been inside the Seer identity for 33 minutes. The nine-word confirmation lands harder than a second extended treatment would. Recommendation: protect both passages; cutting either reduces the force of the other because the confirmation's power is proportional to the strength of the original installation.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/07-distinctiveness-calibrator.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern: Age-Specific Claims as False-Positive Friction (and Removal Pattern)

**Classification:** Anti-pattern

**Description:** When copy uses a specific age threshold to mark the rarity event ("most operators become Resigned Observers by 35," "by 40 most people stop expecting change"), scan the audience age distribution. Age-specific claims create correct-positive activation for prospects younger than the threshold ("that's me — except I'm still here") and false-positive friction for prospects older than the threshold who have a reinstatement arc (became resigned, then came back). For $500+ offers, the 45+ demographic is typically non-trivial and is the cohort most likely to have a reinstatement arc. The fix is substitution to a culturally resonant age-stage label — "by midlife," "by the time most people have a career behind them" — that covers the full age distribution without losing the specificity that makes the rarity claim feel testable.

**Mechanism:** Brewer's rarity signal works by giving the perceiver a comparison class she can check against her own peer group and find true. A specific age threshold is a strong form of this specificity — the perceiver can immediately scan her memory for people she knows who fit the pattern. The problem is directional: the scan succeeds for younger perceivers (who haven't yet hit the threshold) and fails for older perceivers with reinstatement arcs (who crossed the threshold and came back, making the claim feel not-quite-right). Age-stage labels ("midlife") preserve the testability of the claim while covering the full reinstatement arc.

**Worked example:** ZMOS v10, Section 3.5: *"Most operators with your years of experience become Resigned Observers by 35."* Audit finding: serves the 28-40 segment cleanly; creates brief turbulence for the 45+ segment who hit resignation in their early 40s and recently came back. Recommended replacement: *"Most operators with your years of experience become Resigned Observers by midlife."* Cost: one word swap. Estimated effect: removes false-positive friction for the 45+ segment without weakening the rarity signal; "midlife" carries independent cultural resonance as the established moment of pattern-resignation.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/07-distinctiveness-calibrator.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)
