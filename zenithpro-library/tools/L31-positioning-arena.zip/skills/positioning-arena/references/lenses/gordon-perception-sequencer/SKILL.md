---
name: gordon-perception-sequencer
description: Use when needing a roadmap from obscurity to category leader.
version: 1.0.0
author: Strategic Profits / Hollywood Agents & Dealmakers Series
source_thinker: "Shep Gordon (Fame Manufacturing & Category Creation)"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/gordon-perception-sequencer {person-or-brand-current-state}"
  called_by: [user, gordon-field-intelligence]
  outputs_to: [client-output-folder]
---

# Gordon Perception Sequencer

---

## LAYER 1: INVARIANTS (Never override.)

1. **Perception phases cannot be skipped.** Gordon's lifecycle is sequential: manufactured social proof must precede staged events, which must precede media mythology, which must precede association positioning, which must precede category ownership. Each phase creates the conditions that make the next phase possible. Jumping ahead produces fragile fame that collapses under scrutiny.

2. **Each phase has an exit trigger, not a timeline.** You don't leave Phase 1 after "two months" --- you leave Phase 1 when the specific perception benchmark is met. The skill must define concrete, observable exit triggers for each phase. Time-based transitions are prohibited because perception doesn't follow calendars.

3. **Amplify-Don't-Normalize is the design principle at every phase.** Gordon's Teddy Pendergrass insight: find what makes someone MOST different, amplify it to 11 instead of suppressing it. At every phase in the sequence, the moves must amplify the client's most distinctive quality, never sand it down for broader appeal. If a move makes the client more "normal," it's wrong.

4. **The Delivery System Identifier runs parallel to the sequence.** At every phase, identify: What's the "record album" equivalent (the product)? What's the "radio" equivalent (free exposure)? Can you sacrifice the radio fee for product distribution? This is not a one-time question --- the delivery system evolves as perception phases advance.

5. **Category ownership is the only acceptable endpoint.** The sequence is not complete at "famous" or "well-known." It is complete only when the client OWNS a category --- when their name is synonymous with a space they defined. Every phase must be designed to converge on category ownership, not just visibility.

---

## LAYER 2: QUALITY GUIDANCE

6. **Phase 1 (manufactured proof) requires the most courage.** This is where you hire photographers with no film, create events that look bigger than they are, and manufacture the appearance of something that doesn't yet exist. Clients and operators resist this phase because it feels inauthentic. The skill must make the case: manufactured proof creates the conditions for real proof to follow.

7. **The "For Women Only" test applies at every phase.** Gordon turned Teddy Pendergrass's sensual appeal into an entire concert format --- "For Women Only" shows. At each phase, ask: "Is there a format or event that IS the client's difference?" Not showcases the difference --- IS the difference.

8. **Media mythology requires a single, repeatable origin story.** By Phase 3, the client needs one story that media tells about them over and over. Design this story deliberately --- don't let media construct their own narrative. Gordon chose which stories to seed and which to suppress.

---

## PURPOSE

Designs the complete perception lifecycle that transforms someone from unknown to category leader, using Gordon's proven phase-by-phase methodology. This is not "build awareness over time" --- it is a precision sequence where each phase creates manufactured conditions that make the next phase inevitable.

**Why this matters for business owners:** Most visibility strategies are formless --- "post content, build audience, get known." Gordon's system is architectural. Each phase has specific moves, exit triggers, and a delivery system running in parallel. The difference between "trying to get famous" and "manufacturing category leadership" is this sequence.

---

## EXECUTION PROCESS

### Step 1: Current Phase Diagnosis
Determine where the client currently sits in the Gordon lifecycle:

| Phase | Indicators | Client Match? |
|-------|-----------|---------------|
| Pre-Phase (Unknown) | No market presence, no social proof, no media | |
| Phase 1 (Manufactured Proof) | Some visibility but it's engineered, not organic | |
| Phase 2 (Staged Events) | Known in niche, generating some media on own | |
| Phase 3 (Media Mythology) | Media tells a story about them, has a narrative | |
| Phase 4 (Association) | Positioned alongside established names | |
| Phase 5 (Category Owner) | Name IS the category | |

### Step 2: The Amplification Audit
Identify the client's most distinctive quality:
1. **What makes this person/brand MOST different?** (Not "good at" --- DIFFERENT)
2. **Who finds this quality most compelling?** (The natural audience)
3. **Who finds this quality most offensive?** (The natural opposition)
4. **What format or event would BE this difference?** (The "For Women Only" test)
5. **What is the Delivery System at current phase?**
   - Product equivalent ("record album"): ___
   - Free exposure equivalent ("radio"): ___
   - Trojan Horse opportunity: ___

### Step 3: Phase-by-Phase Design
Design each remaining phase from current position to Category Ownership:

**PHASE 1: Manufactured Social Proof**
- Specific manufactured proof tactics (what gets faked/engineered)
- Visual assets to create (photos, testimonials, association signals)
- The perception being built: "This person matters"
- **Exit trigger:** [specific observable benchmark, e.g., "media asks for quotes" or "invited to industry events unprompted"]

**PHASE 2: Staged Events**
- Specific events to manufacture (what "happens")
- The "uncontrollable" appearance design
- Media mechanism (why press covers it)
- The perception being built: "This person creates news"
- **Exit trigger:** [specific benchmark, e.g., "media covers them proactively, not just reactively"]

**PHASE 3: Media Mythology**
- The single origin story to seed with media
- Which stories to suppress
- The repeatable narrative ("every profile says...")
- The perception being built: "Everyone knows who this person is and why"
- **Exit trigger:** [specific benchmark, e.g., "new media profiles repeat the seeded narrative without prompting"]

**PHASE 4: Association Positioning**
- Who to be positioned alongside (the John Lennon equivalent)
- Events, stages, or contexts for association
- How association signals category-level status
- The perception being built: "This person belongs with the greats"
- **Exit trigger:** [specific benchmark, e.g., "peers treat them as category-level, invitations come from established names"]

**PHASE 5: Category Ownership**
- The category name and definition
- The infrastructure that makes ownership permanent
- The roster that proves it's a category, not a person
- The perception being built: "This person IS the category"
- **Exit trigger:** Category ownership is the terminal state --- no exit, only defense

### Step 4: Delivery System Evolution
Map how the delivery system evolves across phases:

| Phase | Product | Free Exposure | Trojan Horse |
|-------|---------|---------------|--------------|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |

### Step 5: The 90-Day Sprint
Design the next 90 days in detail based on current phase:
- Week 1-2: Specific actions
- Week 3-4: Specific actions
- Month 2: Specific milestones
- Month 3: Exit trigger assessment

---

## OUTPUT STRUCTURE

### The Perception Sequencer Report

**Section 1: Current Phase Diagnosis**
- Where the client sits today
- Evidence for this assessment
- What's missing from current phase completion

**Section 2: Amplification Identity**
- The distinctive quality identified
- The format that IS the difference
- The natural audience and opposition

**Section 3: The Full Sequence**
- Each phase designed with specific moves
- Exit triggers defined for each phase
- Escalation verified across phases

**Section 4: Delivery System Evolution**
- Product/exposure/Trojan Horse at each phase
- Key deal structures to pursue

**Section 5: The 90-Day Sprint**
- Week-by-week action plan
- Resources needed
- Decision points and checkpoints

**Section 6: The Single Move**
- The one action this week that advances the current phase toward its exit trigger

---

## SAVE LOCATION
Save output to: `Active-Brain/00 Projects/01 Behavioral Intelligence/Hollywood Agents/Category 1 - The Fame Engineers/Shep Gordon/Perception Sequencer/`
Filename: `XX - Perception Sequencer Report - [Person-or-Brand] - [Date].md`
