---
name: rogers-chasm-analyzer
description: Diagnoses chasm: Early Adopters vs. Early Majority. Use when: growth stalled.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Everett Rogers (Diffusion of Innovations, 1962; 5th edition 2003) — Skill 2 of 7"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/rogers-chasm-analyzer {product-or-offer-description}"
  called_by: [user, rogers-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Chasm dynamics shift rapidly as the market evolves. A product that was approaching the chasm may have crossed it — or fallen in — within weeks. Reassess after any significant product launch, market event, or competitive shift."
thaler_integration:
  feeds_from: [thaler-choice-architect, thaler-default-auditor]
  feeds_to: [thaler-nudge-auditor]
  shared_data: "The chasm is fundamentally a choice architecture problem. Early Adopters navigate complex choice environments willingly. Early Majority needs Thaler's simplified defaults, clear opt-in paths, and friction-free decision structures. Crossing the chasm requires redesigning the entire choice architecture from 'choose your adventure' to 'the obvious right choice.'"
ariely_integration:
  feeds_from: [ariely-predictability-auditor, ariely-relativity-engine]
  feeds_to: [ariely-expectation-architect]
  shared_data: "The chasm exposes a fundamental shift in which predictable irrationalities dominate. Early Adopters are biased toward action (they overweight potential and underweight risk). Early Majority is biased toward inaction (they overweight risk and demand social proof). Ariely's anchoring shifts too — Early Adopters anchor on the innovation's potential; Early Majority anchors on what their peers have already proven."
damasio_integration:
  feeds_from: [damasio-somatic-marker-audit]
  feeds_to: [damasio-emotion-decision-map]
  shared_data: "The chasm is a somatic marker cliff. Early Adopters have accumulated positive somatic markers around risk-taking and innovation — their bodies say 'go.' Early Majority has accumulated cautionary somatic markers around unproven solutions — their bodies say 'wait.' Crossing the chasm means triggering DIFFERENT somatic markers in the new audience: safety, belonging, and proven reliability instead of excitement and novelty."
girard_integration:
  feeds_from: [girard-mimetic-audit, girard-model-identification]
  feeds_to: [girard-desire-propagation]
  shared_data: "The chasm exists because Early Majority does not model Early Adopters. They're in different social worlds with different mimetic models. Early Adopters model innovators and visionaries. Early Majority models successful pragmatists. Crossing the chasm requires installing new mimetic models — pragmatic reference customers that the Early Majority recognizes as 'people like me' rather than visionary risk-takers."
veblen_integration:
  feeds_from: [veblen-signal-decoder, veblen-status-audit]
  feeds_to: [veblen-conspicuous-strategy]
  shared_data: "The chasm marks a status signal inversion. Before the chasm, adoption signals innovative daring (high status among visionaries). After the chasm, early adoption signals unnecessary risk (low status among pragmatists). Crossing requires repositioning the innovation's status meaning from 'cutting edge' to 'smart, proven choice' — a fundamentally different Veblen signal."
bourdieu_integration:
  feeds_from: [bourdieu-habitus-profiler, bourdieu-field-analyzer]
  feeds_to: [bourdieu-capital-audit]
  shared_data: "The chasm reflects a habitus boundary. Early Adopters possess habitus disposed toward experimentation — their internalized dispositions say 'try new things.' Early Majority habitus is disposed toward conformity and risk minimization. Bourdieu reveals that the chasm isn't just a market gap — it's a class-of-disposition gap requiring the innovation to speak to fundamentally different internalized worldviews."
loewenstein_integration:
  feeds_from: [loewenstein-curiosity-audit, loewenstein-visceral-audit]
  feeds_to: [loewenstein-empathy-gap-map]
  shared_data: "Curiosity drives pre-chasm adoption; visceral risk aversion blocks post-chasm adoption. Loewenstein's information gap theory explains why Early Adopters seek out innovations (the gap itself motivates them). But Early Majority experiences visceral discomfort with the SAME information gap — for them, not knowing is threatening, not exciting. The chasm is where curiosity gives way to anxiety."
festinger_integration:
  feeds_from: [festinger-dissonance-audit]
  feeds_to: [festinger-commitment-escalation]
  shared_data: "Dissonance dynamics flip at the chasm. Pre-chasm, Early Adopters reduce post-purchase dissonance by becoming advocates (they justify their visionary bet). Post-chasm, Early Majority reduces pre-purchase dissonance by demanding more proof (they need to justify the risk to themselves before acting). Festinger reveals why the same product generates evangelists on one side and skeptics on the other."
barthes_integration:
  feeds_from: [barthes-myth-decoder]
  feeds_to: [barthes-narrative-audit]
  shared_data: "The chasm requires a myth change. Pre-chasm myth: 'This is the future, and you can be first.' Post-chasm myth: 'This is proven, and smart people like you are already using it.' Barthes reveals that crossing the chasm isn't just a marketing pivot — it's a complete mythological reconstruction. The innovation must shed its pioneer mythology and adopt mainstream success mythology."
mcluhan_integration:
  feeds_from: [mcluhan-medium-audit]
  feeds_to: [mcluhan-channel-strategy]
  shared_data: "The medium must change at the chasm. Pre-chasm communication works through specialized, insider media (niche forums, conferences, direct relationships). Post-chasm communication requires mainstream, accessible media. McLuhan's insight is that switching from insider to mainstream media changes the MESSAGE itself — the innovation is perceived differently when encountered in a mainstream context, regardless of identical words."
mccracken_integration:
  feeds_from: [mccracken-meaning-transfer-audit]
  feeds_to: [mccracken-cultural-positioning]
  shared_data: "The chasm is a meaning transfer failure. The innovation's meaning was successfully transferred to Early Adopters through insider cultural channels. But those channels don't reach Early Majority. McCracken's model shows that new meaning transfer mechanisms — mainstream advertising, celebrity endorsement, fashion system positioning — must be activated to carry the innovation's meaning across the chasm."
granovetter_integration:
  feeds_from: [granovetter-weak-ties-audit]
  feeds_to: [granovetter-bridge-strategy]
  shared_data: "The chasm IS a weak ties problem. Within the Early Adopter segment, strong ties spread adoption efficiently. But strong ties don't cross to Early Majority — these are separate social clusters. Granovetter's weak ties are the ONLY bridges across the chasm. Crossing strategy must identify and activate the specific weak ties (boundary-spanning individuals, shared contexts, cross-segment communities) that connect Early Adopters to Early Majority."
barabasi_integration:
  feeds_from: [barabasi-network-audit]
  feeds_to: [barabasi-hub-strategy]
  shared_data: "Barabasi's hub model reveals that the chasm can be crossed through targeted hub activation rather than broad market campaigns. If a small number of highly connected nodes in the Early Majority can be converted, their network influence cascades adoption through the mainstream. The chasm crossing strategy is a hub identification and conversion strategy, not a mass marketing strategy."
---

# Rogers Chasm Analyzer

---

## LAYER 1: INVARIANTS (Never override.)

1. **The chasm is structural, not motivational.** The gap between Early Adopters and Early Majority is not caused by insufficient marketing effort or weak messaging. It is a structural discontinuity in the adoption process caused by fundamentally different buyer psychologies. Early Adopters buy vision and potential; Early Majority buys proven solutions and peer validation. No amount of "better marketing" bridges this gap — only structural changes to the product, positioning, and go-to-market strategy cross it.

2. **The chasm kills more innovations than any other single factor.** Most innovations that achieve initial success (enthusiastic early customers, positive feedback, growing buzz) die in the chasm. They mistake Early Adopter enthusiasm for market validation, scale their Early Adopter playbook, and discover it doesn't work for the next segment. This skill must diagnose chasm risk honestly, even when the business feels optimistic.

3. **Crossing requires a beachhead, not a broad attack.** Rogers' diffusion model and subsequent research consistently show that mainstream markets are won segment by segment, not all at once. The first mainstream segment (the beachhead) must be narrow enough to dominate, pragmatic enough to demand a complete solution, and connected enough to create reference-customer effects for adjacent segments.

4. **The whole product must be complete for the mainstream.** Early Adopters fill gaps themselves — they assemble missing pieces, tolerate bugs, and work around limitations. Early Majority expects a complete, working solution out of the box. The chasm is as much a product completeness gap as a marketing gap. This assessment must evaluate whole-product readiness.

5. **Reference customers are the currency of chasm crossing.** Early Majority buyers do not trust vendor claims, visionary testimonials, or theoretical benefits. They trust reference customers — people in their segment, in their industry, solving their specific problem, who can be contacted and verified. Without reference customers in the target mainstream segment, the chasm cannot be crossed.

---

## LAYER 2: QUALITY GUIDANCE

6. **Be brutally honest about chasm position.** Businesses in the chasm typically believe they just need "more of the same" — more leads, better copy, bigger ad spend. The diagnosis must clearly state whether the issue is execution within the current segment or a structural chasm problem requiring fundamentally different strategy.

7. **Name the beachhead concretely.** "Small businesses" is not a beachhead. "Accounting firms with 5-20 employees in the Southeastern US" is a beachhead. The recommended beachhead must be specific enough to dominate and narrow enough to serve completely.

8. **Distinguish between chasm symptoms and other growth problems.** Not every growth stall is the chasm. Stalled growth could also indicate market saturation within the current segment, product-market fit issues, competitive displacement, or pricing problems. The diagnosis must rule out alternative explanations.

---

## PURPOSE

The chasm between Early Adopters and Early Majority is the graveyard of promising innovations. A product can have enthusiastic customers, strong referrals, and growing revenue — and still be heading for failure if all that traction is coming from Early Adopters and nothing has been done to prepare for the fundamentally different Early Majority.

This skill diagnoses chasm position with precision: Is the business pre-chasm, in the chasm, or post-chasm? What specific indicators support this diagnosis? If approaching or in the chasm, what crossing strategy should be deployed? If post-chasm, what consolidation is needed before pushing further?

---

## INPUT REQUIREMENTS

Provide:
1. **The product/offer** — what it does, how long it's been in market, what it replaces
2. **Customer profile** — who is buying, their characteristics, how they found you
3. **Growth trajectory** — adoption over time, any stalls or inflection points

Optional:
- Customer testimonials/case studies (reveals reference customer strength)
- Churn data (reveals whole-product gaps)
- Sales cycle data (reveals decision complexity)
- Competitor positioning (reveals category maturity)

---

## EXECUTION PROCESS

### Step 1: Chasm Position Diagnosis

Assess current position across three possible states:

**Pre-Chasm indicators (still in Early Adopter territory):**
- Customers are visionaries who see potential, tolerate imperfection
- Growth is through direct relationships, conferences, insider channels
- Customers actively suggest features and provide detailed feedback
- Sales require significant education about the category, not just the product
- Customers are willing to co-develop the solution
- Revenue is growing but customer base is narrow and homogeneous

**In-the-Chasm indicators:**
- Initial growth has stalled or slowed significantly
- New customer acquisition costs are rising
- Marketing that worked before is yielding diminishing returns
- Leads express interest but don't convert — they want "more proof"
- Sales cycle has lengthened
- Prospects ask "who else is using this?" more than "what does it do?"
- The business is investing more in marketing with declining returns

**Post-Chasm indicators:**
- Customers reference peers as reason for adoption, not the innovation itself
- Sales cycle follows a standardized, repeatable process
- Word-of-mouth and referrals are significant growth drivers
- Customers expect and receive a complete, polished solution
- Competition is emerging (validation of mainstream market)
- Growth is self-reinforcing through network effects and social proof

For each indicator: present / absent / partial — with evidence.

**Position verdict:** Pre-Chasm / Entering Chasm / In Chasm / Exiting Chasm / Post-Chasm

### Step 2: Whole Product Assessment

Evaluate product completeness against Early Majority requirements:

**Core product:** The thing itself — does it work reliably without workarounds?

**Expected product:** Features the mainstream buyer assumes are included:
- Onboarding / implementation support
- Documentation / training
- Integration with existing tools/workflows
- Support / help when things go wrong

**Augmented product:** Elements that differentiate against alternatives:
- Community / peer learning
- Ongoing updates / improvements
- Industry-specific configurations
- Success metrics / ROI tracking

**For each layer:**
- Current completeness (1-10)
- Gap description
- Impact on mainstream adoption
- Effort to close gap

**Whole Product Readiness Score:** Average across layers, weighted by mainstream buyer priority.

### Step 3: Reference Customer Inventory

Assess the strength of reference customers for the target mainstream segment:

**For each existing reference customer:**
- Segment: Innovator / Early Adopter / Early Majority
- Industry/context relevance to target mainstream segment
- Results achieved (quantified?)
- Willingness to be referenced
- Accessibility (can prospects actually talk to them?)
- Similarity to target mainstream buyer ("someone like me" factor)

**Reference Customer Strength Score:**
- 0 references in target mainstream segment = Crossing impossible
- 1-2 references = Crossing barely possible (extremely narrow beachhead only)
- 3-5 references = Crossing possible with focused strategy
- 5+ references = Strong foundation for crossing

### Step 4: Beachhead Identification

If crossing is needed, identify the optimal beachhead segment:

**Beachhead criteria (ALL must be met):**
- Narrow enough to dominate with current resources
- Pragmatic buyers with a compelling reason to act now
- Accessible through available channels
- Connected to adjacent segments (creates word-of-mouth bridge)
- Can be served with a complete whole product (no major gaps)
- Has recognizable, referenceable companies/people

**Beachhead candidates:**
- Candidate 1: [Segment definition] — Score against each criterion
- Candidate 2: [Segment definition] — Score against each criterion
- Candidate 3: [Segment definition] — Score against each criterion

**Recommended beachhead:** Which candidate and why.

### Step 5: Positioning Shift Assessment

Evaluate whether positioning has made the pre-chasm to post-chasm shift:

**Pre-chasm positioning (works for Early Adopters):**
- "Revolutionary new approach to..."
- "Be first to..."
- "The future of..."
- Emphasis on innovation, novelty, vision
- Comparison to old way of doing things

**Post-chasm positioning (works for Early Majority):**
- "The proven solution for..."
- "Join [X] companies who already..."
- "The industry standard for..."
- Emphasis on reliability, proven results, peer adoption
- Comparison to direct competitors

**Current positioning diagnosis:**
- Where does current messaging fall on the pre/post-chasm spectrum?
- Is there a positioning mismatch (pre-chasm positioning aimed at post-chasm buyers)?
- What specific language, claims, and proof elements need to change?

### Step 6: Sales Process & Decision Architecture

Assess whether the buying process matches the target segment's decision-making:

**Early Adopter buying process:**
- Vision-driven: "I can see how this could work"
- Founder/leader-driven: One person decides
- Tolerates ambiguity: "We'll figure it out"
- Short cycle: Excitement drives speed

**Early Majority buying process:**
- Evidence-driven: "Show me proof it works for people like me"
- Committee/consensus: Multiple stakeholders must agree
- Demands clarity: "Exactly what will happen when we implement?"
- Longer cycle: Deliberation, comparison, risk assessment

**Current sales process alignment:**
- Is the sales process designed for the target segment's decision-making?
- Are objection handling and risk-reduction matched to mainstream concerns?
- Is the buying experience itself mainstream-ready (or does it require insider knowledge)?

### Step 7: Competitive Dynamics at the Chasm

Assess how competition affects crossing strategy:

**Competitive landscape:**
- Who else is attempting to cross or has crossed?
- What positioning are competitors using for the mainstream?
- Is there a "gorilla" (dominant player) establishing the category standard?
- Can the business position as the category leader, or must it differentiate within an established category?

**Competitive implications for crossing:**
- If no competitor has crossed: opportunity to define the category for mainstream
- If a competitor has crossed: must differentiate within the mainstream category they've established
- If multiple competitors are in the chasm: race to cross first

### Step 8: Strategic Recommendations

Synthesize into a crossing strategy:

**If Pre-Chasm:**
- Immediate actions to prepare for the chasm
- Whole product gaps to close
- Reference customers to develop
- Beachhead to identify and validate

**If In-the-Chasm:**
- Beachhead strategy with specific target segment
- Whole product completion priorities
- Positioning shift requirements
- Reference customer development plan
- Sales process redesign specifications

**If Post-Chasm:**
- Consolidation strategy for current mainstream segment
- Adjacent segment expansion plan
- Competitive defense requirements
- Scaling infrastructure needs

**For each recommendation:**
- What to do
- Why it matters for chasm position
- Expected impact on crossing progress
- Implementation timeline and difficulty

---

## OUTPUT STRUCTURE

### Chasm Diagnostic Report

**Section 1: Chasm Position Diagnosis**
Evidence-based assessment of Pre-Chasm / In Chasm / Post-Chasm with confidence level.

**Section 2: Whole Product Assessment**
Completeness scores across core, expected, and augmented product layers.

**Section 3: Reference Customer Inventory**
Strength and relevance of existing references for the target mainstream segment.

**Section 4: Beachhead Identification**
Recommended beachhead segment with scoring against all criteria.

**Section 5: Positioning Shift Assessment**
Current positioning diagnosis and required shifts for the target segment.

**Section 6: Sales Process & Decision Architecture**
Alignment between current sales process and target segment decision-making.

**Section 7: Competitive Dynamics**
How competition affects crossing strategy.

**Section 8: Cross-System Integration**
If other thinker data exists: How do chasm dynamics interact with mimetic modeling (Girard), status signaling (Veblen), network bridges (Granovetter), and hub activation (Barabasi)?

**Section 9: Crossing Strategy**
Complete crossing plan with prioritized actions, timeline, and success metrics.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Everett Rogers - Chasm Analyzer/02 - Chasm Diagnostic - [Product Name] - [Date].md`
