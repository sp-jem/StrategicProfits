---
name: tajfel-qualification-architect
description: Synthesizes SCT (salience/normative fit), SIT (positive distinctiveness), and ODT (Brewer calibration dial) into a complete qualification section builder. Produces "not for everyone" copy that activates depersonalization, triggers positive distinctiveness, and hits optimal distinctiveness balance. Includes the asymmetric dual-activation trigger.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Henri Tajfel & John Turner (Social Identity Theory, Self-Categorization Theory) + Marilynn Brewer (Optimal Distinctiveness) — Idea 7"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/tajfel-qualification-architect {audience-profile} {existing-qualification-language}"
  called_by: [user, tajfel-field-intelligence]
  outputs_to: [client-output-folder]
depends_on: [tajfel-social-identity-activator, tajfel-salience-calibrator, tajfel-prototype-auditor, tajfel-distinctiveness-calibrator, tajfel-enemy-designator, tajfel-in-group-vocabulary]
---

# Tajfel Qualification Architect

---

## LAYER 1: INVARIANTS (Never override.)

1. **Qualification language is not exclusion language.** The goal is not to repel people — it is to activate the self-categorization mechanism such that the right people pull themselves in and the wrong people self-select out. Copy that merely says "this isn't for everyone" is making an assertion. Copy built on the SCT/SIT/ODT architecture creates the cognitive conditions for this sorting to happen automatically, via the prospect's own self-categorization process. The mechanism must be in the copy, not just the claim.

2. **Three-layer synthesis is required for effective qualification copy.** Layer 1 (SIT): The qualification must activate social identity — cognitive + evaluative + emotional components all present. Layer 2 (SCT): The qualification must create the salience conditions — comparative fit, normative fit, and perceiver readiness. Layer 4 (ODT): The qualification must hit optimal distinctiveness for the specific audience — neither too inclusive nor too exclusive. Missing any layer produces partial qualification copy that undersells the mechanism.

3. **The asymmetric dual-activation trigger is the master qualification formula.** "Rare enough to feel special + large enough to feel real." This is the simultaneous activation of the differentiation need (I'm part of something exclusive) and the inclusion need (I'm genuinely connected to real people like me). Both must fire in the same sentence or passage for maximum identification. This is not two separate messages; it is one message that activates both drives at once.

4. **Depersonalization is the target cognitive state for the qualified prospect.** After reading well-constructed qualification copy, the prospect should be processing the rest of the letter/VSL/offer from the frame: "Is this what people like me do?" — not "Is this what I personally want?" That shift from individual-level to group-level processing is what makes the rest of the persuasion architecture more efficient. Qualification copy sets the cognitive frame; everything downstream depends on it being set correctly.

5. **Positive distinctiveness must be specified, not asserted.** "This is for serious entrepreneurs" asserts positive distinctiveness (serious = better) but doesn't demonstrate what dimension the in-group is actually superior on. Effective qualification copy names the dimension of positive distinctiveness: "serious entrepreneurs who build instead of collect" — now the superiority is specific (building vs. collecting) and the prospect knows exactly what they're gaining by being in-group. Vague positive assertions are weak; specific dimensional comparisons are strong.

---

## LAYER 2: QUALITY GUIDANCE

6. **The architecture is invisible; only the copy is visible.** Good qualification copy reads naturally and compellingly. The mechanism works underneath. The goal is not to produce copy that reads like a textbook exercise in SIT — it is to produce copy that converts, with the mechanism correctly encoded. The architecture serves the craft; the craft must be evaluated on its own terms.

7. **Qualification copy has a sequence.** (1) Perceiver readiness prime — activate the relevant identity before qualifying. (2) In-group naming with prototype specificity — who this is for, using prototype vocabulary. (3) Positive distinctiveness contrast — what makes this group distinct (implicit or explicit enemy). (4) Optimal distinctiveness signal — the "rare enough + real enough" dual-activation. (5) Behavioral norm statement — what members of this group do (depersonalization induction). This sequence can be compressed or expanded; it should not be reversed.

8. **Test the qualification against: "Would a non-target who reads this feel correctly excluded?"** The qualification works if the right people are pulled in AND the wrong people self-select out. If a non-target could still see themselves in the qualification copy, the normative fit and comparative fit components are failing. Run the test explicitly.

---

## PURPOSE

Qualification copy ("this is for you if," "this is NOT for," "not for everyone") is one of the highest-leverage copy constructs in direct response. When it works, it sets the cognitive frame for the entire rest of the piece, pre-qualifies attention quality, reduces refund rates by improving buyer-fit, and activates the group-identity processing mode that makes all downstream persuasion more efficient.

When it fails — which is most of the time — it's either (a) a weak assertion ("not everyone has what it takes") that makes no cognitive difference, or (b) a generic avatar description that names demographics without activating any mechanism.

This skill builds qualification copy from the ground up using the full SIT/SCT/ODT architecture: social identity activation, salience conditions, prototype specification, optimal distinctiveness calibration, and the asymmetric dual-activation trigger. Input is an audience profile. Output is complete, deployable qualification copy with the full mechanism encoded.

---

## INPUT REQUIREMENTS

Provide:
1. **Audience profile** — status level, what they've achieved, what they struggle with, what they aspire to, what groups they identify with
2. **Existing qualification language** (if any) — current "this is for" or "not for everyone" language; if absent, skill builds from scratch
3. **Product/offer context** — what the offer delivers; needed to anchor the qualification language to actual value
4. **Enemy/out-group definition** — or run `tajfel-enemy-designator` first

---

## CONSTRUCTION PROCESS

### Step 1: Audience Need Profile (ODT Calibration Input)

**Diagnose the dominant need for this specific audience:**

| Need | Audience Level | Evidence |
|------|---------------|----------|
| Differentiation need | HIGH / MODERATE / LOW | |
| Inclusion need | HIGH / MODERATE / LOW | |
| Optimal balance point description | | |

**Calibration directive:**
- High differentiation need → Lead with exclusivity; inclusion signals follow
- High inclusion need → Lead with belonging; exclusivity signals follow
- Balanced → Dual-activation trigger can appear in single construction

---

### Step 2: Positive Distinctiveness Dimension

**What specific dimension does the in-group compare favorably on?**

Not generic ("serious operators") but dimensional ("operators who build systems instead of chasing tactics") — the comparison object makes the distinctiveness specific and verifiable.

**Distinctiveness dimension:** [X vs. Y — where in-group does X and out-group does Y]

**Enemy reference:** [Explicit / Implicit / Type: category/archetype/institutional]

---

### Step 3: Prototype Specification

**Who is the prototypical member?**

- Achievement level: [What they've already done or proven]
- Belief markers: [What they believe that others don't]
- Behavioral markers: [What they do that others don't]
- Vocabulary signals: [How they talk / what terms they use]
- What they're NOT: [Anti-prototype behavioral markers]

**Prototype extremity check:** More extreme than average member? [YES / NEEDS ADJUSTMENT]

---

### Step 4: The Qualification Copy Architecture

**Assemble the five-layer qualification sequence:**

**Layer 1 — Perceiver readiness prime (1–2 sentences):**
Open by activating the relevant identity. Address the group member, not the individual. Before making any qualifying claims, put the prospect in group-member processing mode.

> Draft: [Write perceiver readiness prime here]

**Layer 2 — In-group naming with prototype specificity (1–3 sentences):**
Name the group with prototype vocabulary. Not "business owners" — the specific, dimensional description of the target prototype.

> Draft: [Write in-group naming here]

**Layer 3 — Positive distinctiveness contrast (1–3 sentences):**
Name or imply the out-group. Establish the favorable comparison. Make the distinctiveness specific and dimensional.

> Draft: [Write positive distinctiveness contrast here]

**Layer 4 — Optimal distinctiveness signal — the dual-activation trigger (1–2 sentences):**
The "rare enough to feel special + large enough to feel real" construction. Must activate both differentiation need and inclusion need simultaneously.

> Draft: [Write dual-activation trigger here]

**Layer 5 — Behavioral norm statement (1–2 sentences):**
What do members of this group do? This is the depersonalization induction — "people like us" + behavior = group-norm processing.

> Draft: [Write behavioral norm here]

---

### Step 5: The Complete Qualification Block

**Assembled sequence (all five layers, copy-edited for flow):**

> [Full qualification block — ready to deploy]

**Character / word count:** [N words — appropriate for placement: lead, pre-offer, section header]

---

### Step 6: The "NOT For" Version

**The inverse qualification — who this is NOT for:**

Anti-prototype behavioral description (not demographics) of the wrong prospect. Must use the archetype enemy or category enemy construction. Must produce reliable self-selection by non-targets.

> [NOT for copy block]

**Test:** Would a non-target clearly recognize themselves? [YES / RISK — why]

---

### Step 7: Compressed Versions (For Headlines, Subheads, CTAs)

**One-sentence qualification (for subhead or email subject):**
> [One sentence capturing the core qualification with both in-group and positive distinctiveness]

**Headline-length qualification (5–7 words):**
> [Ultra-compressed version — for hero section or VSL title card]

**CTA qualification (for button copy or section header):**
> [Action-oriented qualification — "Join [prototype-specific description]"]

---

### Step 8: Qualification Architecture Audit

Before finalizing, run the qualification block through the five-component checklist:

| Component | Present? | Evidence |
|-----------|----------|----------|
| Cognitive component activated (group clearly named) | YES / PARTIAL / NO | |
| Evaluative component activated (positive distinctiveness present) | YES / PARTIAL / NO | |
| Emotional component activated (stakes of belonging) | YES / PARTIAL / NO | |
| Salience conditions met (comparative + normative fit) | YES / PARTIAL / NO | |
| Optimal distinctiveness calibrated for audience | YES / PARTIAL / NO | |

**Pass condition:** All five YES → copy is architecturally complete
**Fail condition:** Any PARTIAL or NO → revise the relevant layer

---

## OUTPUT FILES

Primary output — complete qualification architecture:
`[project-folder]/Tajfel — Qualification Architecture/01 - Qualification Block - [Copy Name] - [Date].md`

Include:
- Complete qualification block (Step 5)
- "NOT for" version (Step 6)
- Compressed versions (Step 7)
- Architecture audit (Step 8)

---

## OUTPUT FORMAT — GIRARD STANDARD (canonical)

Produce a standalone Field Intelligence document conforming to the **Girard Standard**.

**Canonical spec:** `~/.claude/skills/_shared/output-formats/field-intelligence-girard-format.md` — read in full before producing output.

### Hard requirements

- **Length:** 250-400 lines (200 floor; 800 ceiling)
- **Fully self-contained** — reader must understand the analysis with no other file open
- **YAML frontmatter** including: `skill`, `target`, `analyst`, `date`, `analysis_type`, `status`, `priority_finding`
- **Epigraph** — a relevant quote from the source thinker, with application clause
- **Executive thesis** — 3-5 paragraphs that answer: what is analyzed, what lens is applied, what is the headline finding, why does it matter
- **Numbered sections** with embedded **verbatim quotes** from the target (no script-section shorthand like "S3.5" without quoting the actual words)
- **Falsifier check** — a section naming what would have to be false for the analysis to be wrong
- **Conclusion** with deployable verdict (action recommended or no action recommended, named)

### Forbidden patterns

- Script-section shorthand without embedded quote ("S3.5 has X" without the quote)
- Cross-references to other skill outputs ("see [other-skill] audit")
- Glossary references instead of inline definitions
- Generic verdicts ("strong"/"weak") without mechanism
- Closing summary that restates findings (padding)
- Version-comparison markers internal to the analysis ("v5 said X; v10 says Y" — belongs in commit log)

### Output path

Save to: `[project-folder]/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/05-qualification-architect.md`

### Exemplars (read at least two before producing)

1. `Active-Brain/00 Projects/Support Pets - Girard Analysis/02-desire-autopsy.md`
2. `Active-Brain/00 Projects/Support Pets - Girard Analysis/03-rivalry-detector.md`
3. `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/05-qualification-architect.md`

### The "no flipping" test

Before declaring output complete: imagine a colleague opening this file cold, with no project context. Can they understand the analysis end-to-end without opening any other file? If no, the document has failed the standard. Rewrite.

---

## KNOWN PATTERNS (Field-Tested)

Patterns this skill has identified in production runs. Each entry encodes diagnostic intelligence the skill should apply to future targets.

---

### Pattern: Eight-Condition Convergence Signals a Structurally Complete Block

**Classification:** Convergence signal

**Description:** When auditing an existing qualification block using the eight-condition diagnostic (cognitive readiness, evaluative distinctiveness, emotional stakes, comparative fit, normative fit, perceiver readiness, optimal distinctiveness, recognition trigger), track whether conditions converge on STRONG/EXCELLENT or whether any single condition is rated WEAK or MISSING. A block that returns all eight conditions at STRONG or above is architecturally complete — no structural edits are warranted, only cosmetic refinements. A block missing even one condition requires structural intervention, not polish. Apply this convergence test before recommending any edits: the verdict determines whether you are in structural territory or refinement territory.

**Mechanism:** Tajfel's self-categorization framework requires all identity-installation conditions to be simultaneously active. A qualification block missing one condition produces a partially installed identity — subjectively felt by the prospect but not durable under the cognitive load of a 60-minute webinar. Partial installation means downstream reactivation beats have nothing to reactivate. The eight-condition audit is the structural completeness test; convergence at STRONG across all eight is the pass condition.

**Worked example:** The ZenithMind OS v10 qualification block (Section 3.5) returned: Cognitive Readiness — STRONG, Evaluative Distinctiveness — STRONG, Emotional Stakes — STRONG, Comparative Fit — STRONG, Normative Fit — STRONG, Perceiver Readiness — STRONG, Optimal Distinctiveness — EXCELLENT, Recognition Trigger — STRONG. All eight converged. Verdict: no structural edits warranted. Two cosmetic seams identified separately. The convergence result correctly predicted that all downstream identity reactivation beats (Sections 7, 8, 11.5, 17) were inheriting from a solid installation.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/05-qualification-architect.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern: Optimal Distinctiveness Executed as Rarity-Clause + Populace-Clause in One Breath

**Classification:** Load-bearing pattern

**Description:** When auditing or building the Optimal Distinctiveness layer (Condition 7 / Layer 4 of the qualification sequence), look for whether the copy addresses Brewer's two needs — differentiation and inclusion — in immediate sequence, ideally in adjacent sentences. The rarity-clause ("you're rarer than you think") must be immediately followed by the populace-clause ("but you're not as alone as you feel") before any intervening content. If the two clauses are separated by more than one sentence, or if only one is present, the dual-activation trigger is misfiring. The pair must land as a single cognitive unit: "I am special AND I belong."

**Mechanism:** Brewer's Optimal Distinctiveness Theory holds that social identity satisfies two opposing needs simultaneously: the need for differentiation (I am not the same as everyone) and the need for inclusion (I genuinely belong somewhere). If rarity is stated without belonging, the prospect may feel alienated rather than elevated. If belonging is stated without rarity, the group feels too large to be valuable. The rarity-then-belonging sequence resolves both needs before either has time to generate doubt.

**Worked example:** The ZenithMind OS v10 block executes this as: *"You're rarer than you think. Most operators with your years of experience become Resigned Observers by 35. The fact that you're still feeling something — that's actually the signal that you're built differently from most of your peers."* (rarity-clause) immediately followed by *"But you're not as alone as you feel. There are more Seers than you've ever met. They've been hiding in plain sight."* (populace-clause). The field intelligence report rated this construction EXCELLENT — the single strongest element in the block. When scoring future targets, treat this paired construction as the textbook execution standard.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/05-qualification-architect.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern: The Load-Bearing Wall — Cross-Sub-Skill Convergence Identifies the Highest-Leverage Section

**Classification:** Convergence signal

**Description:** When multiple Tajfel sub-skills are run independently against the same target (in-group vocabulary, prototype auditor, enemy designator, salience calibrator, qualification architect, social identity activator, distinctiveness calibrator) and their findings are then mapped to script real estate, watch for the section where ALL sub-skills peak simultaneously. That section is the load-bearing wall of the conversion architecture. It is where the identity vocabulary is deployed at maximum density, the prototype is explicitly described, the enemy is named and calibrated, salience peaks, self-categorization is triggered, the identity is activated for the first time, and optimal distinctiveness is calibrated. Every other section that touches social identity downstream is doing reactivation — and can only reactivate what was installed here. Identify this section early; protect it from runtime cuts; optimize it before optimizing anything else.

**Mechanism:** In SCT, depersonalization (group-level self-processing) can only be reactivated after it has first been installed. The installation moment is singular — it happens once in a script, at the qualification block. Downstream beats that reference the in-group vocabulary, the prototype, or the behavioral norm are borrowing force from the installation. If the installation is weak, no downstream beat can recover — there is nothing to borrow. This means the marginal return on optimizing the load-bearing wall is higher than anywhere else in the script, even if the wall is already strong.

**Worked example:** In the ZMOS v10 seven-sub-skill analysis, all seven Tajfel sub-skills peaked at Section 3.5 (the qualification block). The field intelligence report concluded: "A 30-second improvement to Section 3.5 is worth multiple minutes of improvement elsewhere because every subsequent section inherits its strength." The block was rated 4.6/5 before cosmetic edits and ~4.9/5 after. The two sections runners-up for social-identity density (Sections 7 and 11.5) were performing reactivation only — they could not independently install the identity if 3.5 were removed.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/05-qualification-architect.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern: Cosmetic Seams That Create Prototype-Fit Turbulence

**Classification:** Boundary condition

**Description:** After confirming a qualification block is structurally complete (all eight conditions STRONG), scan for cosmetic seams: specific claims within the prototype description that are verifiably false or inapplicable for a subset of the target audience, causing a brief moment of "wait, is that me?" before the viewer recovers. Two seam types recur: (1) age-specific claims that contradict the lived experience of viewers outside the named range (e.g., "by 35" for a viewer who is 42 and considers themselves a Seer), and (2) cognitive-style filters that narrow the prototype to one mode of thinking when the audience contains multiple valid modes (e.g., "systems and architectures" excluding narrative or relational thinkers who nonetheless match all other prototype markers). Neither seam collapses the qualification block, but each produces a brief self-exclusion signal that a one-line swap eliminates at zero cost.

**Mechanism:** Normative fit (Condition 5) requires the categorization to match the perceiver's pre-existing intuitions about themselves. A single disconfirming data point — an age claim that doesn't match, a thinking-style label that doesn't fit — activates a minor self-exclusion reflex. The block usually recovers because surrounding behavioral markers still match, but the reflex is measurable as hesitation. Because qualification copy is doing installation work (not persuasion work), any hesitation during installation is disproportionately costly: the identity is most fragile at the moment of first categorization.

**Worked example:** Two seams identified in ZMOS v10: (1) *"Most operators with your years of experience become Resigned Observers by 35"* — the age-specific claim risks contradiction for viewers older than 35 who self-identify as Seers. Suggested replacement: *"by midlife."* (2) *"People who think in systems and architectures, not in mindset shifts and vibes"* — excludes narrative or relational thinkers who match all other prototype markers. Suggested replacement: *"People who think in patterns — whether you see them as systems, recurring relationships, or repeating shapes in your life."* Both are one-line swaps; both eliminate a prototype-fit turbulence point at zero structural cost.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/05-qualification-architect.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)
