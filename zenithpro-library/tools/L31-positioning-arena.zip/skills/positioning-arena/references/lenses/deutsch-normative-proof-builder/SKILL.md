---
name: deutsch-normative-proof-builder
description: Construction tool for normative proof elements. Takes an offer context and audience description and outputs the in-group activation sequence, normative proof copy with in-group-specific language, public-response-context framing, and volume ceiling recommendation — with failure-condition checklist.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Morton Deutsch & Harold Gerard (Informational vs. Normative Social Influence) — Idea 3"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/deutsch-normative-proof-builder {offer-context} [audience-description]"
  called_by: [user, deutsch-proof-staging-diagnostic, deutsch-field-intelligence]
  outputs_to: [project-folder]
depends_on: [deutsch-proof-staging-diagnostic]
---

# Deutsch Normative Proof Builder

---

## LAYER 1: INVARIANTS (Never override.)

1. **In-group activation BEFORE normative proof is a hard sequencing rule.** Normative influence requires that the prospect conform to the positive expectations of the reference group. For this to fire, the prospect must first recognize the reference group as their own in-group — a group they belong to, identify with, or aspire to join. Testimonials or crowd counts deployed before in-group identity is activated land as irrelevant social pressure from strangers. The sequence is non-negotiable: (a) establish the in-group identity and prime the prospect's membership, then (b) deploy normative proof from within that in-group. This rule may not be softened into a suggestion.

2. **Normative influence requires public-response conditions.** Normative influence fires when the prospect's response is or will be visible to others whose approval matters. Without observability, the social cost of non-compliance is removed and the normative pathway deactivates. Copy that wants to activate normative influence must frame the purchase or enrollment decision as a visible, social act — not a private transaction. In private/anonymous purchase contexts, normative proof is structurally weakened; supplement with or shift to informational proof.

3. **The reference group must be the prospect's actual in-group.** Strangers' approval is largely irrelevant (Hogg, 2010). The normative pressure only fires from groups the prospect identifies with or wants to belong to. Generic crowd language ("thousands of people," "millions of customers") activates almost no normative pressure and may trigger reactance. Specific in-group language ("3,200 independent financial advisors running fee-only practices") activates normative pressure from a relevant peer group. The narrower and more identity-relevant the reference group, the more potent the normative proof — up to the Brewer distinctiveness limit.

4. **Group size has a ceiling (Brewer optimal distinctiveness).** Per Brewer's Optimal Distinctiveness Theory (1991): very large groups satisfy belonging needs but fail distinctiveness needs. If the reference group is "everyone" or "millions," high-status buyers may perceive the group as too undifferentiated to be worth conforming to — belonging to a mass market does not signal distinction. The optimal normative proof reference group is large enough to signal meaningful social validation but specific enough to satisfy the prospect's distinctiveness need. This is the Brewer calibration step: match group size and specificity to what produces both belonging AND distinctiveness for this specific audience.

5. **Normative proof produces public compliance, not private belief change.** The output of normative influence is conformity — the prospect does the behavior because others in their in-group are doing it, because the purchase is visible, and because non-conformity carries social cost. This produces the sale, but it does not update the buyer's private belief about the product's value. Normative buyers who lose the social context (leave the community, forget the crowd endorsement) may not renew, refer, or maintain the behavior change. The normative proof builder must flag the LTV risk for continuity/high-ticket models and recommend supplementation with informational proof for retention.

---

## LAYER 2: QUALITY GUIDANCE

6. **Kelman's identification pathway is normative proof's highest-durability form.** Per Kelman (1958): compliance (pure normative output) decays when surveillance ends. But identification — where the prospect's conformity is driven by relationship to the group rather than just observed behavior — persists as long as the group relationship is maintained. Community-based offers where ongoing membership is the context produce identification-level normativity, which decays slower. When building normative proof for community/membership offers, frame it as identification (you become part of this group, not just you follow this group's behavior).

7. **The in-group activation sequence should use Tajfel/Turner prototype architecture.** The most effective in-group priming establishes: (a) the relevant social category ("entrepreneurs who..."), (b) the prototype — what the typical/ideal member of this category is like, and (c) the prospect's membership — confirming that the prospect fits the prototype. When the copy has successfully primed the prospect's in-group identity, the normative proof that follows lands as peer behavior rather than stranger behavior. Cross-reference: tajfel-social-identity-activator for the full in-group activation protocol.

8. **Distinguish normative proof from informational proof in same testimonial.** Many testimonials do both simultaneously. "John Chen, a 12-year financial planner with 200 managed accounts, found that his retention rate improved from 34% to 92% using this method because the client communication framework reduced ambiguity about fees" contains both informational proof (credential + outcome + mechanism) AND normative proof (a peer in the reference group chose this). The normative builder focuses on the social identity and belonging dimensions; the informational builder handles the evidence-about-reality dimensions. Flagging dual-function testimonials and using them for both purposes is the highest-efficiency proof strategy.

---

## PURPOSE

Normative proof is the most used proof type in direct response and the most commonly misapplied. Customer counts, "best-selling" labels, and social validation are all normative in mechanism but are routinely deployed without the two preconditions that make them work: (a) in-group identity activation before the proof appears, and (b) a public-response context that makes the decision feel visible.

This tool builds the complete normative proof stack: the in-group activation sequence, the normative proof copy with identity-specific language, the observability framing that makes the purchase feel social, and the volume ceiling that prevents proof paradox from activating in skeptical audiences.

---

## INPUT REQUIREMENTS

Provide:
1. **Offer context:** What is being sold, who is the typical customer, what result does the offer deliver?

2. **Audience description:** Who is the prospect?
   - Primary identity/role (e.g., "independent financial advisor," "B2B SaaS founder," "professional coach")
   - Sophistication level
   - Self-image: Do they see themselves as independent thinkers? Part of a professional community? Aspirational toward a specific group?

3. **Available social proof inventory:** What crowd data, testimonials, or social validation exists?
   - Customer counts (total, by segment if available)
   - Testimonials (names, roles, results)
   - Community membership data (if relevant)
   - Social visibility mechanisms (if any — community platform, peer-visible purchases, etc.)

4. **Purchase context:** How does the prospect make the purchase decision?
   - Public/community context (event, group environment, visible to peers)
   - Semi-public (they may discuss with peers; decision visible after the fact)
   - Private/anonymous (solo research, invisible to others)

5. **Business model LTV requirement:** Single-purchase / Continuity / High-ticket / Referral-dependent

---

## EXECUTION PROCESS

### Step 1: Failure Condition Check
Before building, run the failure condition checklist. If any failure condition is present, flag it prominently — normative proof will either be ineffective or harmful in the presence of these conditions:

**Failure conditions:**
- [ ] **Out-group crowd:** Is the available proof from people the prospect does NOT identify with? (If yes: normative proof from this crowd will not work; either replace with a relevant in-group or shift to informational)
- [ ] **Skeptical/independent self-image:** Does the prospect strongly identify as an independent thinker, analytical decision-maker, or someone who explicitly does NOT follow crowds? (If yes: high normative proof load risks proof paradox; prioritize informational proof)
- [ ] **Private purchase context:** Is the purchase decision entirely private and invisible to peers? (If yes: normative pathway is structurally weakened; supplement with informational proof; do not rely on normative as primary)
- [ ] **Premium/high-ticket audience:** Is the prospect a premium buyer who sees themselves as above average? (If yes: generic "everyone is doing it" language triggers distinctiveness backlash; reference group must be hyper-specific and elite)
- [ ] **Missing in-group:** Does the copy lack an in-group activation sequence before the normative proof placement? (If yes: normative proof will land as pressure from strangers; hard sequencing violation; must fix)

### Step 2: In-Group Identity Analysis
Profile the prospect's primary social identity category relevant to this offer:
- **Category:** [specific role/identity label the prospect uses for themselves]
- **Prototype:** [what the ideal/typical member of this category values, does, and aspires to]
- **Membership confirmation signal:** [what proves the prospect fits this category — job title, years of experience, revenue level, professional credential, specific challenge they face]
- **Aspirational direction:** [what does a successful member of this group achieve? This becomes the normative proof's promise]

### Step 3: In-Group Activation Sequence
Build the copy sequence that primes in-group identity BEFORE the normative proof appears. Required structure:
1. **Category signal:** Name the in-group using the exact vocabulary the prospect uses for themselves (not marketing language — their actual self-description)
2. **Prototype activation:** Describe the typical challenges, values, or situation of the in-group member — the prospect should be nodding along ("that's me")
3. **Membership confirmation:** A phrase or question that confirms the prospect is a member of this in-group
4. **Transition to normative proof:** A bridge phrase that establishes why the reference group's behavior is relevant to the prospect

Example structure:
> "[Category label] who've been in your exact situation — [specific challenge] — [have done X / are doing Y]. [Transition to normative proof]"

### Step 4: Normative Proof Construction
For each available proof element, build the in-group-specific normative version:

**Customer count proof:**
- Raw count is weak: "40,000 customers"
- Segmented count is stronger: "40,000 [category label] who [specific relevant descriptor]"
- Best form: "[Specific number] [specific role] doing [specific thing] [in specific context]"

**Testimonial as normative proof:**
- Lead with the identity match (this is the normative signal): "[Name]'s situation was exactly like yours — [specific parallel]"
- Then the choice (group behavior signal): "decided to [action] because [in-group relevant reason]"
- Frame the choice as visible to/validated by the community (if applicable)

**Community/movement proof:**
- Frame the community as an in-group, not just a customer list
- Show the prospect their future peer group: "Here are the people you'll be working alongside"
- Make the membership feel exclusive enough to be meaningful (Brewer calibration)

### Step 5: Observability/Public-Response Framing
Determine what observability context exists and amplify it:

**Community context (high observability):**
- Frame enrollment as a visible community membership decision: "You'll be joining a group of [specific identity] who [peer-visible activity]"
- Mention the peer visibility mechanism explicitly: "When you join, your profile goes live to [X] other [category] members"
- Create imagined social context in private-purchase contexts: "Imagine how you'll introduce yourself to the group as the [category member] who finally [resolved the problem]"

**Semi-public context:**
- "This is the choice that [specific in-group description] are making this year"
- "When [in-group members] in your network ask what you're doing about [problem], [this offer] is the answer that resonates"

**Private context (normative pathway weakened):**
- Flag: normative proof alone will not close this purchase
- Combine with informational proof: lead with evidence-about-reality, use normative as secondary validator
- Frame normative proof as "you won't be alone in this decision" rather than crowd pressure

### Step 6: Brewer Calibration — Group Size and Specificity
Adjust the reference group language to optimize both belonging and distinctiveness:

**Too generic (fails distinctiveness, risks mass-market signal):**
"Over 100,000 customers love this product"

**Better (belonging + some specificity):**
"17,000 financial professionals upgraded their client communication system this year"

**Best (high belonging + high distinctiveness for right audience):**
"1,200 fee-only RIAs who manage over $25M in AUM and run practices without transaction-based revenue have implemented this system in the last 18 months"

Calibrate: larger numbers signal broader social validation; smaller numbers signal exclusive in-group (elite status signal). Match to what the prospect needs more of — belonging or distinctiveness.

### Step 7: Volume Ceiling Recommendation
Based on audience sophistication and self-image, recommend the maximum number of normative proof elements before proof paradox risk becomes unacceptable:

**Low sophistication + communal self-image:** Volume can be high — up to 15-20 normative elements. Social validation accumulates.

**Medium sophistication + mixed self-image:** Cap at 8-10 normative elements. After this point, additional normative proof adds minimal uplift and introduces mild paradox risk.

**High sophistication + independent self-image:** Cap at 3-5 normative elements maximum. These should be highly specific and identity-relevant, not generic counts. Lead section with informational proof; normative proof is secondary.

**Expert-skeptic + "I think for myself" self-image:** Cap at 1-2 normative elements if any. These should be hyper-specific peer proof that functions more as social context than as crowd pressure. Consider eliminating normative proof entirely and deploying proof-paradox acknowledgment language instead.

---

## OUTPUT STRUCTURE

### Normative Proof Stack: [Offer Name]

**Failure condition check results:**
[List any failure conditions present with recommended action]

**In-group identity profile:**
- Category: [identity label]
- Prototype: [description]
- Membership signals: [list]
- Aspirational direction: [what they achieve]

**In-group activation sequence (copy):**
[Full copy sequence — ready to deploy as written or adapted]

**Normative proof elements (with Brewer calibration):**
[Each proof element rebuilt with in-group language, with notes on specificity level]

**Observability/public-response framing:**
[Context-appropriate copy that frames the decision as social and visible]

**Volume ceiling recommendation:**
[Maximum normative proof elements for this audience, with reasoning]

**LTV warning (if applicable):**
[If business model requires high LTV and normative proof is the dominant proof type, flag the retention risk and recommend informational proof supplementation]

**Kelman pathway note:**
[Is this normative proof operating at compliance level (surveillance-dependent) or identification level (relationship-maintained)? Recommendation for which produces better retention for this business model]

**Cross-reference:**
- Run `deutsch-proof-paradox-auditor` after the full proof section is built to confirm volume and reactance risk are within acceptable range
- Run `kelman-pathway-diagnostic` to confirm normative proof is appropriately matched to LTV requirements

---

## OUTPUT FILE

Save complete output to:
`[project-folder]/Deutsch & Gerard - Normative Proof/[YYYY-MM-DD] - Normative Proof Stack - [Offer Name].md`
