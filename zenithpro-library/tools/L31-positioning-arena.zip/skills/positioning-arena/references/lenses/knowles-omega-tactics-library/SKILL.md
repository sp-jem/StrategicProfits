---
name: knowles-omega-tactics-library
description: Modular library of omega copy blocks keyed to each resistance face — acknowledgment templates, defusion structures, redirection mechanics, DTR patterns, take-away formulas, pacing sequences. Select by face profile from knowles-four-faces-diagnostic output.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Eric Knowles & Jay Linn (Approach-Avoidance Persuasion / Omega Strategies) — Idea 3"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/knowles-omega-tactics-library {face-profile from four-faces-diagnostic} {copy-context}"
  called_by: [user, knowles-field-intelligence]
  outputs_to: [project-folder]
depends_on: [knowles-four-faces-diagnostic]
---

# Knowles Omega Tactics Library

---

## LAYER 1: INVARIANTS (Never override.)

1. **Face matching is mandatory before tactic selection.** Do NOT select omega tactics without a face profile from `knowles-four-faces-diagnostic` or equivalent diagnosis. Randomly applied omega tactics fail — some amplify the resistance face they were not designed for. Always confirm which face is dominant before opening this library.

2. **The omega triad underlies all tactics.** Every omega tactic in this library is a variant of one of three primary moves: acknowledgment (name and validate the resistance), defusion (reduce its emotional charge without attacking it), or redirection (channel the resistance energy toward an adjacent behavior that leads to compliance). Identify which move each tactic is executing before deploying it.

3. **The acknowledgment block goes BEFORE benefit delivery, not after objections emerge.** The common error is treating omega tactics as objection-handlers placed at the end of copy. Acknowledgment of distrust or reactance must precede the promise — not appear after the prospect has already built up their resistance wall. Sequence matters structurally.

4. **DTR has the highest evidential support. All other omega tactics are lower-confidence.** Disrupt-then-reframe (Davis & Knowles, 1999) has clean experimental replication across multiple consumer contexts. All other tactics in this library are theoretically derived or practitioner-validated. Prescribe DTR with higher confidence; label other tactics as best-available without equivalent experimental backing.

5. **Tactic authenticity is a prerequisite for effectiveness.** A defusion tactic that removes the appearance of pressure while the pressure structure is still present (e.g., "take your time" followed immediately by a countdown timer) amplifies distrust rather than reducing reactance. Omega tactics must be genuine to work. If the copy structure cannot authentically support the tactic, do not deploy it. Flag the structural contradiction instead.

---

## LAYER 2: QUALITY GUIDANCE

6. **Write specific acknowledgment language — generic pacing fails.** "You've probably been disappointed before" is generic pacing that reads as a script. "If you've been sold programs that promised [specific outcome] and then gave you [specific gap], you know how that feels" is specific enough to register as genuine. The acknowledgment block requires VOC research — it must echo the prospect's actual language, not a category approximation.

7. **Take-away sell requires pre-existing desire.** Withdrawal only works if the prospect already wants the thing being withdrawn. If desire is thin, take-away confirms disinterest. Run the approach-force audit before using take-away — if approach forces are weak, take-away is contraindicated.

8. **Inertia tactics are structurally different from the other three faces.** Reactance, distrust, and scrutiny are active psychological states requiring engagement tactics. Inertia is a passive state requiring activation tactics. Inertia-dominant audiences need friction reduction and triggering events — not acknowledgment of resistance that doesn't feel like resistance to them.

---

## PURPOSE

> "Omega strategies operate on the resistance dimension — they reduce, neutralize, absorb, or bypass the forces that oppose persuasion. They do not add to the attractiveness of the advocacy position; they remove the obstacles to accepting it." — Knowles & Linn, 2004, *Resistance and Persuasion*, ch. 1

> "Omega approaches do not bypass resistance directly; they engage with it. Acknowledgment involves naming and validating the resistance. Defusion involves reducing the emotional charge of the resistance without directly refuting it. Redirection involves channeling the resistant energy toward an adjacent behavior that either neutralizes the resistance or leads to the target behavior through a back door." — Knowles & Riner, 2007

This library provides modular, face-keyed omega copy blocks. Input a face profile from `knowles-four-faces-diagnostic`. Output is a set of copy blocks matched to the dominant and secondary faces, with placement guidance and substitution notes.

---

## INPUT REQUIREMENTS

1. **Face profile** from `knowles-four-faces-diagnostic` — primary face + secondary face(s) + confidence level
2. **Copy context** — what type of copy (VSL, sales page, email, webinar, ad), funnel stage, offer type, price point
3. **Existing copy** (optional) — if auditing existing copy for omega integration points

---

## THE OMEGA TACTIC LIBRARY

---

### MODULE 1 — REACTANCE FACE TACTICS

Target: Prospects resisting because they feel pushed, controlled, or robbed of choice.

---

**Tactic R1: Autonomy Acknowledgment**
Move type: Defusion
Evidential status: Supported by Guéguen & Pascual (2000) "but you are free" experiments — strong replication.

What it does: Explicitly restores the prospect's perceived freedom to decline. Removes the pressure that was generating the reactance motivational state. The reactance force disappears because there is no longer an opposing constraint to push against.

Template structures:
- "I want to be clear: you don't have to do anything here. This is entirely your call."
- "Whether you take the next step or not, that's completely up to you. I'm going to give you everything you need to make that call yourself."
- "There's no obligation attached to what I'm about to share. Look at it, take what's useful, and ignore the rest."

Placement: Early in the copy — before the main promise. In a VSL, within the first 90 seconds. In a sales page, in the opening section after the hook, before the problem amplification.

Contraindications: Sounds scripted if overused. Use once, not repeatedly. Conflicts with hard deadline/scarcity structures that are genuinely present.

---

**Tactic R2: Take-Away Sell**
Move type: Redirection
See also: `knowles-take-away-sell` (full standalone skill)
Evidential status: Theoretically derived from reactance theory; practitioner-validated in high-ticket sales. Not experimentally replicated in written copy contexts.

What it does: Withdraws or conditionally limits the invitation, reversing the prospect's motivational orientation from resistance to pursuit. The prospect's desire to restore their freedom expresses as chasing the offer rather than resisting it.

Template structures:
- "This program isn't for everyone. Before I go further, let me give you a few questions to see if this even makes sense for your situation."
- "I'm not sure this is the right fit — let me explain who gets results from this and who doesn't, and you can tell me if you're in the right place."
- "We limit who we work with, not because of artificial scarcity, but because the approach doesn't produce results for everyone. Here's what you need to have in place first."

Placement: After establishing the outcome (approach forces must be present for take-away to work), before or at the offer introduction.

Contraindications: Requires genuine desire to already exist. Fails if applied to cold audiences or when desire is thin. Fails when the qualification language is transparently fake — if the program clearly accepts everyone, the take-away reads as manipulation.

---

**Tactic R3: Soft Close / Opt-Out Structure**
Move type: Defusion

What it does: Explicitly names the exit — tells the prospect they can stop reading/watching/attending at any point. Counterintuitively, naming the exit reduces the probability they use it, because the reactance driving exit behavior is defused.

Template structures:
- "If at any point this doesn't apply to you, no problem — you can stop here."
- "I'm going to share a few things. If they're useful, great. If they're not relevant to where you are, move on — I won't be offended."
- CTA language: "Take a look, and if it makes sense, here's how to get in. If it doesn't make sense, that's fine too."

Placement: Interspersed through long copy — especially useful at resistance peaks (price reveal, CTA) to release pressure before it builds.

---

### MODULE 2 — DISTRUST FACE TACTICS

Target: Prospects resisting because they believe the persuader's interests are opposed to their own.

---

**Tactic D1: Persuasion Context Acknowledgment**
Move type: Acknowledgment
Evidential status: Theoretically grounded; practitioner-validated across direct response formats.

What it does: Names the persuasion context explicitly before the prospect activates their defensive posture. By demonstrating awareness of their likely skepticism, the persuader signals safety — someone who knows you're skeptical and still proceeds transparently is less likely to be deceiving you.

Template structures:
- "I'm going to make you an offer at the end of this. I want to tell you that upfront — that way you can evaluate everything I say knowing where it's going."
- "I know you've seen a lot of [category] offers. Most of them promised [X] and didn't deliver. I'm not going to pretend this is different without giving you specific reasons why."
- "You're right to be skeptical. In your position, with everything that's been sold to this market, I'd be skeptical too. Here's what would change my mind, and whether what I'm showing you meets that standard."

Placement: Opens the copy body — before the main proof sequence. Must precede the promise, not follow it.

---

**Tactic D2: Two-Sided Messaging**
Move type: Acknowledgment
Evidential status: Supported by Hovland's two-sided message research — two-sided messages outperform one-sided messages with skeptical audiences on credibility and persuasion durability.

What it does: Voluntarily naming what this is NOT right for, what the limitations are, or who should NOT buy reduces the informational asymmetry that fuels distrust. The persuader who names weaknesses is not acting like someone with something to hide.

Template structures:
- "Who this is NOT for: [specific exclusions]. If you're in that situation, this won't help you and I don't want to waste your time."
- "This approach has limitations. It doesn't work if [specific condition]. If that's your situation, I'd actually recommend [alternative]."
- "I'm going to tell you one thing that concerns me about my own offer — [honest limitation] — and then explain why I still think the value is strong."

Placement: Before or embedded within the proof section. Named weaknesses BEFORE testimonials make the testimonials land harder.

---

**Tactic D3: Reason-Why Transparency**
Move type: Acknowledgment

What it does: Explains the persuader's motivation for making the offer — in terms of the persuader's own interest, not just the prospect's. Counterintuitive but effective: naming why you want them to buy reduces the sense of hidden agenda.

Template structures:
- "Here's why I'm sharing this: [honest self-interested reason]. That's my business interest. Here's why you should buy anyway: [prospect-interest reason]."
- "I want to be honest about what's in this for me: [specific business reason]. Which is separate from whether this is the right decision for you — that's what the rest of this page is about."

Placement: After the problem/agitation section, before the solution introduction.

---

**Tactic D4: Agnostic Proof**
Move type: Acknowledgment / Defusion

What it does: Proof that doesn't obviously benefit the persuader — third-party data, results achieved by people the persuader has no ongoing relationship with, evidence from contexts the persuader wasn't involved in, or proof that comes from the prospect's own category experiences.

Examples:
- Industry data the persuader didn't produce
- Peer testimonials from people who aren't still active customers (no ongoing relationship incentive)
- Specific failure cases: "Here are the people who tried this and it didn't work for them — and here's why"
- Documentation of results by independent third parties

Placement: Integrated throughout the proof section — alternated with standard testimonials to break the "paid testimonial" pattern.

---

### MODULE 3 — SCRUTINY FACE TACTICS

Target: Prospects actively counterarguing — generating objections, testing claims, looking for inconsistencies.

---

**Tactic S1: Inoculation / Objection Preemption**
Move type: Acknowledgment
Evidential status: Supported by McGuire's inoculation theory — one of the strongest theoretical frameworks for scrutiny-face resistance. Preempting the objection reduces its impact when the prospect generates it independently.

What it does: Raises the prospect's likely objection BEFORE they do, in the copy, then provides a counter-argument. The prospect's counterarguing faculty is partially occupied and the objection has been defused before it fires.

Template structures:
- "You might be thinking: [specific objection]. Here's why that's a fair concern, and here's what the evidence actually shows: [counter-argument]."
- "The most common pushback I hear on this is [X]. I want to address it directly because it's a legitimate question."
- "If I were evaluating this from the outside, the thing I'd be most skeptical about is [X]. So let me show you the evidence on that specific point."

Objection identification: Pull from sales call logs, VOC data, customer questions, and competitor review sections. The more specific the objection language matches the prospect's actual internal language, the more effective the inoculation.

Placement: Immediately before or after the main promise, and again at the price reveal. Two or three objection preemptions spread through the copy are more effective than a single "FAQs" block at the bottom.

---

**Tactic S2: Narrative Transportation**
Move type: Redirection
Evidential status: Supported by Green & Brock (2000) narrative transportation research — stories reduce systematic counterarguing by engaging the narrative processing system.

What it does: Bypasses the scrutiny-mode analytical processing by engaging narrative processing. A prospect in a story is not in counterarguing mode — narrative transportation and systematic scrutiny compete for the same cognitive resources.

Implementation:
- Lead with story before claim: introduce the mechanism through a character's experience, not through assertion
- Testimonials as stories (journey, not just result): before → attempt → failure → discovery → result
- Problem agitation through a composite character's narrative rather than through argument
- Case studies structured as stories with specific detail: the more specific, the more transportive

Placement: The story should come BEFORE the claim it's designed to support. The claim lands after the narrative has bypassed the scrutiny gate.

---

**Tactic S3: Social Proof as Judgment Transfer**
Move type: Redirection

What it does: Redirects the prospect's evaluative attention from their own assessment to others' assessments. In scrutiny-dominant audiences, the prospect believes their own evaluation more than the persuader's claims — but they also default to others' judgments when their own analysis is inconclusive.

Implementation:
- Large volume + specificity: many specific results reduce the feasibility of evaluating each claim individually
- Peer testimonials from credible-seeming near-peers (not aspirational figures the prospect doesn't identify with)
- Results that include specific numbers, specific contexts, specific obstacles overcome
- Testimonials that address the primary objection directly

Placement: After the primary objection preemption section. Sequencing: preempt the objection first, then deliver the social proof — the proof lands in a field that has already been cleared.

---

### MODULE 4 — INERTIA FACE TACTICS

Target: Prospects who are not opposed but are simply not moving.

---

**Tactic I1: Cost-of-Inertia Calculation**
Move type: Redirection

What it does: Makes the cost of staying in the current state specific and time-bounded. Inertia is maintained by the implicit assumption that doing nothing is free. Making the cost of nothing explicit and quantified makes inertia an active choice with visible consequences.

Template structures:
- "Here's what staying where you are will cost you in the next 12 months: [specific calculation]. That's not a scare tactic — that's what your current trajectory looks like."
- "You've been [in current state] for [time]. In the next [time period], without changing this, [specific consequence]."
- "The cost of figuring this out on your own — in time, trial and error, and opportunity cost — typically runs [specific figure]. That's what you're paying whether you do anything today or not."

Placement: End of problem/agitation section, just before the solution reveal.

---

**Tactic I2: Triggering Event Creation**
Move type: Redirection

What it does: Creates a reason why NOW is different from LATER. Inertia is defeated by specificity of moment — "later" is infinite; "now" requires a defined reason. The trigger should be genuine (a real deadline, a real capacity limit, a real external event) or derived from the prospect's own timeline.

Template structures:
- External event trigger: "[Market event] is happening in [time frame], which means the window for [result] is [X weeks]."
- Prospect's own deadline: "If you're planning to [prospect goal] by [their stated timeline], the time to start is now — not because of anything I've created, but because of what your own goals require."
- Capacity trigger (genuine): "We work with a limited number of [clients/students] at a time because [genuine operational reason]. [X spots] are currently open."

Contraindications: False scarcity makes inertia worse over time — the prospect who sees the "last 3 spots" message three times disengages permanently.

---

**Tactic I3: Friction Elimination**
Move type: Redirection

What it does: Reduces the action energy required to take the first step. Inertia is defeated by making the initial action smaller than the prospect expected.

Implementation:
- One-click / one-field initial commitment
- Trial or partial commitment before full commitment
- The "just one thing" ask: "Before you decide anything, just [very small action]"
- Pre-filled forms, one-step checkout, mobile-optimized CTA
- Breaking the action into the smallest possible first step ("the only thing you need to do right now is...")

Placement: At and around the CTA — friction elimination is CTA architecture, not body copy.

---

### MODULE 5 — CROSS-FACE PACING SEQUENCE

Applicable to: Mixed-face profiles, especially distrust + scrutiny combinations.

---

**Tactic P1: Pacing and Leading Sequence**
Move type: Acknowledgment → Redirection
Note: K&L import this from behavioral/operational practice. Behavioral framing only — not NLP metaphysics.

What it does: First, demonstrate complete understanding of the prospect's current internal state (pacing). Then, from that established position of understanding, move them incrementally toward the advocacy position (leading). Resistance is reduced because the pacing phase establishes that the persuader understands and shares the prospect's current reality.

Implementation:
- Map the prospect's exact internal monologue at the moment they encounter your copy — not your ideal customer, the actual prospect in their actual state. This requires VOC research.
- Write the pacing section in the prospect's own language, not your own: "If you're like most [segment], you've probably [specific experience]. You've probably tried [specific attempts]. You're probably feeling [specific state] and wondering [specific question]."
- The pacing section should feel like mind-reading — specific enough to cause a "how did they know that?" response.
- Lead from the paced state — the first leading element should be a small step from the paced state, not a leap to the solution.

Length calibration: Higher resistance = more pacing before leading. Warm audiences who trust the persuader need less pacing. Cold audiences with high distrust or scrutiny need extensive pacing before any leading is attempted.

Placement: Opens the main body copy after the hook. In VSL: the first 20-30% of the script. In sales page: the problem/agitation section should be primarily pacing.

---

## EXECUTION PROCESS

### Step 1: Input the Face Profile
State the primary face, secondary face(s), and confidence level from the diagnostic.

### Step 2: Select Primary Tactic Set
Based on primary face, select 2-3 tactics from the corresponding module. For mixed-face profiles, note tactic compatibility constraints (which tactics from each module conflict with each other).

### Step 3: Write Copy Blocks
For each selected tactic, produce the actual copy block in context — not just the template, but the specific language for this offer, this audience, this funnel stage.

### Step 4: Map to Copy Structure
Specify where each copy block goes in the overall copy sequence. The omega architecture must be mapped to a specific position in the copy, not left as floating advice.

### Step 5: Flag Tactic Conflicts
If the copy structure contains elements that contradict the omega tactic (e.g., countdown timer + autonomy acknowledgment, or "take your time" + hard close CTA), name the conflict explicitly. The structure must be resolved before the tactic will work.

---

## OUTPUT FILE

Save complete omega copy blocks to:
`[project-folder]/Knowles & Linn - Omega Tactics/[Campaign] - Omega Copy Blocks - [Date].md`

### Output Structure

**Header:**
- Date: [YYYY-MM-DD]
- Face profile: [From four-faces-diagnostic]
- Copy context: [VSL / Sales page / Email / etc.]
- Tactic set selected: [List]

**Section 1: Primary Face Omega Blocks**
Written copy blocks for each selected tactic, with placement notes.

**Section 2: Secondary Face Omega Blocks**
Written copy blocks for secondary face(s), with placement notes.

**Section 3: Copy Architecture Map**
Table: Copy section → Omega tactic inserted → Tactic type → Resistance face targeted

**Section 4: Tactic Conflicts**
Any copy structure elements that contradict the omega tactics, with resolution notes.
