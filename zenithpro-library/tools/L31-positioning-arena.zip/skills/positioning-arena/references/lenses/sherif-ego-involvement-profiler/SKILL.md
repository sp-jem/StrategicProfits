---
name: sherif-ego-involvement-profiler
description: Pre-copy research tool. Assesses ego-involvement level of target market using behavioral proxies. Sets the parameter inputs for all other Sherif skills.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Muzafer Sherif (Social Judgment Theory) — Idea 4"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/sherif-ego-involvement-profiler {market-or-audience-description}"
  called_by: [user, sherif-field-intelligence]
  outputs_to: [project-folder]
depends_on: []
---

# Sherif Ego-Involvement Profiler

---

## LAYER 1: INVARIANTS (Never override.)

1. **Ego-involvement is the master moderator of SJT.** "Ego-involvement in an issue means that the issue is closely related to the individual's values, to his sense of personal identity, his group memberships, and reference groups... The more ego-involved the individual, the smaller his latitude of acceptance and the larger his latitude of rejection." — Sherif, Sherif & Nebergall, *Attitude and Attitude Change* (1965), pp. 65–66. Get this assessment wrong, and every downstream latitude calibration is wrong. Getting it right sets the correct parameters for the entire Sherif skill stack.

2. **Ego-involvement is pre-message and cannot be measured mid-message.** This profiler is a pre-copy research tool. It assesses the audience's involvement level before any copy is written. It is not a real-time evaluation of reader response during copy consumption. Do not use behavioral metrics from inside a funnel (time on page, scroll depth) as ego-involvement proxies — those measure engagement with the message, not involvement in the issue. Ego-involvement is a property of the person's relationship to the topic, not a property of their response to a specific message.

3. **Ego-involvement requires behavioral proxy inference, not direct survey.** Sherif defined ego-involvement operationally via subjects' public commitment (signing petitions, etc.) and their response patterns on the Own Categories sorting task. Neither of these is field-deployable in commercial copy contexts. The profiler must infer involvement from behavioral proxies: identity language in reviews and forums, community membership, prior purchase behavior, competitor allegiance, publicly stated stance on the issue. Every involvement tier assignment must cite the specific proxies that support it.

4. **Ego-involvement is distinct from personal relevance in ELM.** Petty & Cacioppo's personal relevance construct (ELM) closely parallels ego-involvement — both predict that high involvement leads to more systematic processing and higher resistance to weak arguments. However, SJT adds the latitude-width dimension: ego-involvement does not just increase scrutiny (ELM), it physically widens the rejection latitude and narrows the acceptance latitude. These are complementary, not identical. When the ELM stack is also in use, they address different facets of the same phenomenon.

5. **Schwartz awareness stages are the best available commercial proxy for ego-involvement level.** The Schwartz five awareness stages (unaware / problem-aware / solution-aware / product-aware / most-aware) correlate strongly with ego-involvement: an unaware market has no personal stake in any solution and thus low involvement; a most-aware market has invested time, money, and identity in the problem and solution category, and thus typically high involvement. Use Schwartz stage as the primary heuristic when behavioral data is limited, and supplement with specific signals when available.

---

## LAYER 2: QUALITY GUIDANCE

6. **Segment the audience when involvement levels differ within the target.** A single audience may contain low-involvement and high-involvement subgroups. A well-calibrated copy strategy may require staging: broad-appeal entry claims (calibrated for the low-involvement majority) with proof-heavy progressions (for the high-involvement minority who scrutinize everything). The profiler should identify whether segmentation is needed, and if so, produce separate profiles for each meaningful segment.

7. **High ego-involvement is not the same as high sophistication.** A prospect can be highly ego-involved in an issue without sophisticated market knowledge — a first-time health product buyer who is desperate is highly involved but not sophisticated. The risk profile differs: high involvement + low sophistication = wide acceptance latitude for dramatic claims (the prospect desperately wants the claim to be true); high involvement + high sophistication = very narrow acceptance latitude + large rejection latitude. Distinguish these in the profile.

8. **The ego-involvement tier must be actionable.** Every tier assignment must translate directly into a claim-staging recommendation: what type of claim can be used, at what stage of the funnel, with what proof structure. An ego-involvement profile that does not produce specific claim strategy guidance is incomplete.

---

## PURPOSE

"Before setting claim magnitude, assess the ego-involvement level of the target segment. Behavioral proxies: active community membership, prior product allegiance, stated identity language in reviews and forums ('as someone who has tried everything...'). High ego-involvement → conservative claims, staged escalation, lead with acknowledgment of what the prospect already knows before introducing new claims." — Sherif dossier, Construct 7, Operational Implication.

"The critical sequencing insight: ego-involvement assessment must precede all other decisions. If you misread ego-involvement, you miscalibrate the latitudes, and all subsequent claim decisions are wrong." — Sherif dossier, Dependency Graph.

This skill runs before any other Sherif skill. Its output — the ego-involvement tier and accompanying claim-staging recommendation — flows directly into `sherif-latitude-calibrator` (to set latitude widths) and `sherif-contrast-audit` (to calibrate severity of contrast risk).

---

## INPUT REQUIREMENTS

Provide one or more of the following:
1. **Market description** — who the target prospect is, what category, what stage of awareness
2. **Forum/review language samples** — verbatim quotes from prospect language in reviews, Facebook groups, Reddit, forums
3. **Behavioral data** — purchase history, community membership, competitor switching behavior, refund rates
4. **Identity signals** — language that indicates the product/category is tied to self-concept ("I'm a biohacker," "I've been doing this for years," "I've tried everything")
5. **Competitive landscape** — how many solutions has this market been exposed to, what has been oversold to them before

---

## EXECUTION PROCESS

### Step 1: Signal Inventory

Catalog all available signals by proxy type:

**Identity language signals:** Does the prospect describe themselves using language tied to the product category? ("as someone who has struggled with X for 10 years," "I'm a serious investor, not a casual dabbler," "I'm not like most people who...")

**Community membership signals:** Is the prospect an active member of communities organized around this topic? (Facebook groups, Reddit communities, professional associations, student communities of prior programs)

**Prior allegiance signals:** Has the prospect publicly committed to competing solutions? (testimonials for competitors, stated loyalty, prior courses completed)

**Behavioral commitment signals:** Has the prospect invested time, money, or public identity in this category? (multiple prior purchases, ongoing practice, public teaching of related material)

**Failure/frustration signals:** Has the prospect tried and failed with prior solutions? High prior failure with high continued investment = high ego-involvement + high skepticism (the most dangerous combination for overclaiming).

### Step 2: Schwartz Stage Cross-Reference

Map signals to Schwartz awareness stage:

| Awareness Stage | Typical Ego-Involvement | Acceptance Latitude Width | Rejection Sensitivity |
|-----------------|------------------------|--------------------------|----------------------|
| Unaware | Low | Wide | Low |
| Problem-Aware | Low–Medium | Moderate–Wide | Low–Moderate |
| Solution-Aware | Medium | Moderate | Moderate |
| Product-Aware | Medium–High | Moderate–Narrow | Moderate–High |
| Most-Aware | High | Narrow–Very Narrow | High–Very High |

State which stage applies and what the Schwartz proxy suggests for involvement level.

### Step 3: Proxy Synthesis

Synthesize the signals into an ego-involvement tier:

**LOW:** Prospect is new to the category. No prior investment, no identity language, no community membership. The issue is not yet connected to their sense of self. Wide acceptance latitude — bolder claims are viable.

**MEDIUM:** Prospect has some investment in the category. They know about solutions, may have tried one or two. Some identity connection but not strong. Moderate acceptance latitude — staging needed but not extreme.

**HIGH:** Prospect has deep investment in the category. Identity language is present, community membership exists, prior purchases are evident, or failure history creates defensive posture. Narrow acceptance latitude — conservative claims, staged escalation, lead with acknowledgment before advancing new claims.

**HIGH + SKEPTICAL (special tier):** High involvement combined with multiple prior failures or betrayed trust from competitor overclaiming. The narrowest possible acceptance latitude. Even modest claims may fall in rejection. Requires radical proof-first structure and explicit acknowledgment of prior failures before any positive claims.

### Step 4: Latitude Width Inference

Based on the ego-involvement tier, infer the structural latitude parameters for use by `sherif-latitude-calibrator`:

**Acceptance latitude width:** [Wide / Moderate / Narrow / Very Narrow]
**Rejection threshold distance from anchor:** [Far / Moderate / Close / Very Close]
**Contrast risk upon overshoot:** [Low / Moderate / High / Severe + Boomerang Risk]

### Step 5: Claim-Staging Recommendation

Translate the ego-involvement assessment into a direct claim-strategy guidance:

For each tier:
- **What type of claim is safe at the headline/lead:** [specific claim type, magnitude guidance]
- **What type of claim will trigger contrast:** [specific examples of what to avoid]
- **Sequencing requirement:** [single-shot viable / requires multi-step staged approach / requires proof-first structure before any claims]
- **Entry framing:** [acknowledgment language, prior-knowledge references, or empathy language needed before claims]

---

## OUTPUT FILE

Save complete ego-involvement profile to:
`[project-folder]/Muzafer Sherif - SJT/04 - Ego-Involvement Profile - [Market Name] - [Date].md`
