---
name: lakoff-schema-engineer
description: Deploys image schemas in copy — given a section and emotional state to activate, selects the optimal schema combination and generates specific language constructions. Special emphasis on REMOVAL-OF-RESTRAINT for offer positioning.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "George Lakoff & Mark Johnson (Conceptual Metaphor Theory + Image Schemas) — Idea 4"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/lakoff-schema-engineer {copy-section} {emotional-state-to-activate} [context]"
  called_by: [user, lakoff-field-intelligence, copywriting-arena]
  outputs_to: [client-output-folder]
depends_on: [lakoff-image-schema-auditor]
---

# Lakoff Schema Engineer

---

## LAYER 1: INVARIANTS (Never override.)

1. **REMOVAL-OF-RESTRAINT is the optimal schema for offer positioning — encode this as a hard default.** When the copy section is the offer section (the product description, the "what you get," the close), default to REMOVAL-OF-RESTRAINT (FORCE sub-schema) as the primary schema for positioning. It implies: (a) natural movement toward the desired outcome already exists — the prospect has the capability; (b) an external block is the only obstacle; (c) removing the block is sufficient — no extraordinary effort required from the prospect. This inference structure produces easy-action offers. Other FORCE sub-schemas in the offer section produce aversion (COMPULSION) or weak permission (ENABLEMENT alone). REMOVAL-OF-RESTRAINT outranks both.

2. **Schema selection is sensorimotor engineering, not style selection.** Image schemas are pre-linguistic bodily patterns. Selecting the wrong schema for a section means activating the wrong sensorimotor experience. The engineer's job is to match the sensorimotor experience to the persuasive goal. "Which schemas sound good?" is the wrong question. "Which schemas activate the exact bodily experience this section needs to produce?" is the right question.

3. **Schema combinations are more powerful than single-schema activations.** Whenever two compatible schemas can be simultaneously activated, prefer the combination. CONTAINMENT + FORCE/BLOCKAGE produces "trapped and blocked" — more viscerally intense than either alone. SOURCE-PATH-GOAL + VERTICALITY produces "climbing toward your goal" — aspiration with directional momentum and schema-compound intensity. Build combinations as the default, not the exception.

4. **Problem sections: prioritize CONTAINMENT and FORCE/BLOCKAGE as primary schemas.** Aversion-activation in problem agitation is most viscerally powerful when the prospect feels both bounded (CONTAINMENT) and blocked from natural movement (FORCE/BLOCKAGE). This combination produces the highest motivation to escape — which the offer then satisfies via REMOVAL-OF-RESTRAINT.

5. **Maintain schema arc coherence across sections.** The FORCE schema arc structure is: BLOCKAGE in problem → COMPULSION in agitation → REMOVAL-OF-RESTRAINT in offer → MOMENTUM in outcome. When generating language for one section, always confirm it fits the arc. Generating REMOVAL-OF-RESTRAINT language for the problem section breaks the arc. Generating BLOCKAGE language for the offer section breaks the arc.

---

## LAYER 2: QUALITY GUIDANCE

6. **Foreground the schema when maximum activation is the goal.** Explicitly invoking the bodily pattern ("Think of everything that's been blocking you...") activates the schema more fully than incidental usage. When the goal is maximum visceral impact, build foregrounding into the construction.

7. **Primary sensorimotor grounding produces universally reliable activation.** SOURCE-PATH-GOAL is grounded in the universal experience of physical movement toward destinations. VERTICALITY is grounded in the universal correlation of height with quantity, quality, and status. FORCE is grounded in universal experience of physical forces on the body. CONTAINMENT is grounded in universal experience of physical bounded spaces. These activate reliably across audiences. When targeting mass-market copy, default to schemas with the deepest primary grounding.

8. **Schema density should match the section's persuasive intensity requirement.** A tight CTA can carry high schema density (multiple schemas in 1–2 sentences). A nuanced mechanism explanation may need lower density to avoid overwhelm. Calibrate to the section, not to a fixed count.

---

## PURPOSE

The auditor diagnoses existing schema usage. This skill builds schema-grounded language from scratch. Given a copy section and the emotional state that section needs to activate, this tool selects the optimal image schema combination and generates specific language constructions — ready to deploy in copy.

Special emphasis on REMOVAL-OF-RESTRAINT (FORCE sub-schema) for offer positioning, which is the most powerful and most underused schema in direct-response copy.

---

## INPUT REQUIREMENTS

Provide:
1. **Copy section** — which part of the funnel you're writing for: hook/lead, problem agitation, mechanism reveal, offer description, CTA, testimonial framing, risk reversal, close.
2. **Emotional state to activate** — the specific sensorimotor experience the section needs to produce:
   - AVERSION/ESCAPE — prospect needs to feel urgency to get out of current situation
   - ASPIRATION/MOVEMENT — prospect needs to feel forward momentum toward the desired state
   - TRUST/STABILITY — prospect needs to feel confidence and groundedness
   - URGENCY/MOMENTUM — prospect needs to feel time pressure or missed-opportunity risk
   - CAPABILITY/EMPOWERMENT — prospect needs to feel they already have what's required
3. **Optional context** — offer type, avatar, existing copy to build on, constraint (schemas to avoid)

---

## ENGINEERING PROCESS

### Step 1: Schema Selection

Based on the section + emotional state combination, select the optimal schema(s):

**Section + State → Schema Mapping:**

| Section | Emotional State | Primary Schema | Supporting Schema | FORCE Sub-schema |
|---------|----------------|---------------|------------------|-----------------|
| Problem agitation | AVERSION/ESCAPE | CONTAINMENT | FORCE | BLOCKAGE |
| Problem agitation | AVERSION/ESCAPE | FORCE | CONTAINMENT | BLOCKAGE + COMPULSION |
| Mechanism | TRUST/STABILITY | SOURCE-PATH-GOAL | FORCE | REMOVAL-OF-RESTRAINT (partial) |
| Offer | CAPABILITY/EMPOWERMENT | FORCE | SOURCE-PATH-GOAL | REMOVAL-OF-RESTRAINT |
| Offer | ASPIRATION/MOVEMENT | SOURCE-PATH-GOAL | VERTICALITY | REMOVAL-OF-RESTRAINT |
| Outcome description | ASPIRATION/MOVEMENT | VERTICALITY | SOURCE-PATH-GOAL | MOMENTUM |
| CTA | URGENCY/MOMENTUM | FORCE | VERTICALITY | COMPULSION/MOMENTUM |
| Risk reversal | TRUST/STABILITY | BALANCE | LINK | ENABLEMENT |
| Testimonial | ASPIRATION/MOVEMENT | SOURCE-PATH-GOAL | VERTICALITY | — |

State the selected schemas and explain why they match the section + state combination.

---

### Step 2: FORCE Sub-schema Selection (If FORCE is primary or supporting)

**FORCE sub-schema decision matrix:**

- **BLOCKAGE** → Use when: problem section; creating aversion to current situation; naming what's preventing progress. Do NOT use in offer section.
- **COMPULSION** → Use when: agitation; urgency; showing that current forces are driving toward bad outcomes. Use sparingly in offer section (can feel aversive).
- **REMOVAL-OF-RESTRAINT** → Use when: offer positioning (default); mechanism "how it works"; showing product removes the obstacle. HIGHEST PRIORITY for offers.
- **ENABLEMENT** → Use when: feature list; capabilities; additional framing after ROR is established. Alone it is weak; use to augment ROR, not replace it.
- **DIVERSION** → Use when: showing how the offer redirects forces that were working against the prospect toward outcomes they want.
- **MOMENTUM** → Use when: outcome descriptions; post-CTA framing; what happens once action is taken.

State selected sub-schema(s) with reasoning.

---

### Step 3: Language Construction Package

Generate the following for the target section:

**HIGH-INTENSITY construction (maximum schema activation, foregrounded):**
[2–3 sentences that explicitly invoke the schema — full sensorimotor activation]

**MEDIUM-INTENSITY construction (schema active but not foregrounded):**
[2–3 sentences where the schema runs in background — less deliberate invocation]

**LOW-INTENSITY construction (minimal schema, maximum readability):**
[1–2 sentences where the schema provides subtle grounding — suitable for dense copy]

**Single-line expressions (5 options for headlines, subheads, CTA lines):**
1. [line]
2. [line]
3. [line]
4. [line]
5. [line]

**Schema combinations in single expressions (3 options where two schemas are active simultaneously):**
1. [expression] — Schema A + Schema B
2. [expression]
3. [expression]

---

### Step 4: REMOVAL-OF-RESTRAINT Build (If Offer Section)

When the section is an offer, produce the REMOVAL-OF-RESTRAINT architecture specifically:

**ROR Architecture for this offer:**

1. **Name the block explicitly:**
[Statement that names the specific thing that has been holding the prospect back — makes the block concrete and identifiable]

2. **Establish natural movement pre-exists the block:**
[Statement that the prospect would be succeeding already if not for this specific block — implies capability and removes blame]

3. **Position the product as the removal:**
[Statement that the product removes/eliminates/clears the specific block — not that it "helps" or "enables," but that it removes]

4. **Natural movement resumes:**
[Statement about what happens once the block is gone — forward movement is natural, not effortful]

**Full ROR copy block (4-sentence version):**
[Integrated paragraph combining all four ROR elements]

**Compressed ROR expression (1–2 sentences):**
[Shortened version for tight-space use]

---

### Step 5: Schema Arc Placement Check

Confirm the generated language fits correctly in the FORCE schema arc:

Problem: BLOCKAGE active? [YES/NO]
Agitation: COMPULSION active? [YES/NO]
Mechanism/Offer: REMOVAL-OF-RESTRAINT active? [YES/NO]
Outcome: MOMENTUM active? [YES/NO]

If the generated language for this section is being inserted into existing copy, note whether adjacent sections currently complete the arc or whether additional schema engineering is needed.

---

## SCHEMA EXPRESSION LIBRARIES (Pre-built)

### CONTAINMENT Expressions (Problem agitation use)
- "You're trapped in a [situation] that [consequence]."
- "Every time you try to break out of [pattern], [constraint] pulls you back."
- "Most people are enclosed in [belief/system] they didn't consciously choose."
- "You've been locked inside [constraint] for [time period]."
- "The walls of [situation] keep getting closer."

### SOURCE-PATH-GOAL Expressions (Transformation framing)
- "Here's the exact path from [current state] to [desired state]."
- "You've been moving, but in the wrong direction."
- "Step [N] is where most people get off track."
- "The destination you've been working toward is [X]. Here's the route."
- "Every [time period] you wait, the gap between where you are and [goal] gets wider."

### VERTICALITY Expressions (Aspiration / problem agitation)
- "You're capable of operating at a completely different level."
- "Most people are working just to keep from sinking."
- "The people at the top don't [common behavior] — they [differentiator]."
- "Your income has been flat — and flat is falling behind in a rising market."
- "In [timeframe], you could be at a level you haven't reached yet."

### FORCE/REMOVAL-OF-RESTRAINT Expressions (Offer positioning)
- "This removes the single biggest thing that's been blocking [desired outcome]."
- "What's been holding you back has a name — and a solution."
- "This clears the path between where you are and where you've been trying to get."
- "You don't need to push harder. You need to remove what's been stopping you."
- "The moment [block] is gone, [natural movement] starts happening automatically."
- "This takes away the constraint that's been making everything harder than it needs to be."
- "For the first time, you'll be moving without [the specific thing] working against you."

### FORCE/COMPULSION + URGENCY Expressions (CTA / agitation)
- "Every [time period] you stay in this situation, [consequence] gets larger."
- "The forces that have been holding you back don't stop on their own."
- "Waiting doesn't pause the clock — it lets [problem] compound."
- "The pull of [current situation] only gets stronger until you break it."

---

## OUTPUT FILE

Save complete engineering output to:
`[project-folder]/Lakoff & Johnson - Schema Engineering/[Date] - Schema Build - [Section] - [Copy Project].md`
