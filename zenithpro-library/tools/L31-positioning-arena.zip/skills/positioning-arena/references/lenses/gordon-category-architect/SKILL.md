---
name: gordon-category-architect
description: Use when trapped in commodity category — finds ownable new space.
version: 1.0.0
author: Strategic Profits / Hollywood Agents & Dealmakers Series
source_thinker: "Shep Gordon (Fame Manufacturing & Category Creation)"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/gordon-category-architect {business-description}"
  called_by: [user, gordon-field-intelligence]
  outputs_to: [client-output-folder]
---

# Gordon Category Architect

---

## LAYER 1: INVARIANTS (Never override.)

1. **Categories are built, not found.** The entire premise of this skill is that market categories don't emerge naturally --- they are manufactured by someone who builds the infrastructure first. If the user thinks they need to "discover" their category, reframe: you need to BUILD it.

2. **The Gordon Diagnostic Question is mandatory.** Before any analysis, answer: "Who has enormous value but no mechanism to capture it?" This was Gordon's starting point for celebrity chefs --- he saw chefs being exploited by hotels/restaurants, recognized the structural injustice, and built the category to fix it. Apply this same diagnostic to the client's market.

3. **Infrastructure precedes market.** Gordon built the first celebrity chef agency BEFORE the celebrity chef market existed. Any category creation plan must specify what infrastructure to build BEFORE the market recognizes the category. If the plan starts with "wait for market demand," it's wrong.

4. **Price signals legitimacy.** Gordon insisted chefs never work for free because pricing creates the category. Any category creation plan must include the pricing strategy that signals "this is a real category, not a hobby." If the client is giving it away, the category won't form.

5. **A roster proves the category.** One person in a category is an anomaly. Multiple people is a category. The plan must include how to build a roster or community that proves the category exists beyond the founder. Gordon didn't just make Emeril famous --- he represented 20+ chefs to prove "celebrity chef" was real.

---

## LAYER 2: QUALITY GUIDANCE

6. **The best categories solve a structural injustice.** Gordon's celebrity chef category worked because chefs were genuinely being exploited --- high value, no capture mechanism. The strongest category-creation opportunities exist where talented practitioners are undervalued by existing structures. Prioritize these in the audit.

7. **Adjacent category analysis matters more than white-space analysis.** Don't look for empty space in the market. Look for existing categories that can be adapted to a new population. Gordon adapted the "rock star management" category to chefs. What existing category model can be adapted to the client's practitioners?

8. **The Trojan Horse deal structure is the monetization key.** Gordon accepted low TV fees for Emeril in exchange for spice commercial distribution. The public platform isn't the revenue --- it's the distribution for the real product. Always identify what the "Emeril's Essence" equivalent is.

---

## PURPOSE

Audits a business for the opportunity to create and own a new market category, using Shep Gordon's proven methodology. Gordon didn't find famous chefs --- he invented the entire concept of "celebrity chef" and then installed his clients as the faces of it. This skill applies the same system to any business: find the structural injustice (valuable practitioners with no capture mechanism), build infrastructure before the market exists, identify the delivery system, and design the category architecture.

**Why this matters for business owners:** Most businesses compete WITHIN existing categories. The most valuable strategic move is to create a category you OWN. This eliminates competition because you defined the space. Gordon did this repeatedly --- Alice Cooper (shock rock), celebrity chefs, "For Women Only" concerts. The methodology is transferable.

---

## EXECUTION PROCESS

### Step 1: The Gordon Diagnostic
Answer these questions about the client's situation:
1. **Who has enormous value but no mechanism to capture it?** (The chefs-being-exploited-by-hotels question)
2. **What existing category does this most resemble?** (Rock star management → chef management)
3. **What is the structural injustice?** (Who is capturing value that should go to the practitioners?)
4. **Is there already a nascent community of practitioners?** (Gordon needed multiple chefs, not just one)

### Step 2: Category Viability Audit
Score the opportunity on 5 dimensions (1-10 each):

| Dimension | Question | Score |
|-----------|----------|-------|
| Value Gap | How large is the gap between value created and value captured? | |
| Practitioner Density | Are there enough practitioners to populate a roster? | |
| Delivery System | Does a scalable delivery system exist or could be created? (TV, online, events) | |
| Naming Opportunity | Can this category be named in a way that's instantly understood? | |
| First-Mover Window | Is anyone else building this category? How long is the window? | |

**Threshold:** Score of 35+ = strong category opportunity. 25-34 = possible but needs specific conditions. Below 25 = probably a positioning play, not a category play.

### Step 3: Category Architecture Design

**Section A: The Category Name & Definition**
- What is the category called? (Must be instantly understandable, like "celebrity chef")
- What is the one-sentence definition?
- Who is IN the category and who is NOT? (Boundaries matter)

**Section B: Infrastructure Blueprint**
Following Gordon's "infrastructure precedes market" principle:
1. **What agency/platform/structure needs to exist first?** (Gordon built Alive Culinary Resources before the market)
2. **What deal templates need to be created?**
3. **What standards/pricing need to be established?**

**Section C: Delivery System Map**
For each revenue stream:
| Delivery System | Gordon Equivalent | Client Version | Revenue Model |
|----------------|-------------------|----------------|---------------|
| Visibility Platform | Food Network | ? | ? |
| Tangible Product | Emeril's Essence | ? | ? |
| Authority Builder | Cookbook deals | ? | ? |
| Revenue Multiplier | Endorsements | ? | ? |

**Section D: The Trojan Horse Deal**
- What platform can you accept low/no fees from in exchange for product distribution?
- What is the "Emeril's Essence" --- the real revenue product that the platform distributes?

**Section E: Roster Strategy**
- Who are the first 5-10 practitioners who could populate this category?
- What is the value proposition for them to join?
- How does each new member validate the category further?

### Step 4: Category Launch Sequence
Design the time-sequenced plan:
1. **Month 1-2:** Build infrastructure (agency/platform/structure)
2. **Month 2-3:** Sign founding roster (3-5 practitioners)
3. **Month 3-4:** Secure first delivery system deal (Trojan Horse structure)
4. **Month 4-6:** Establish price signal (first paid engagements)
5. **Month 6-12:** Scale roster, prove category with multiple practitioners

---

## OUTPUT STRUCTURE

### The Category Architect Report

**Section 1: The Gordon Diagnostic**
- The structural injustice identified
- The value gap quantified
- The adjacent category model being adapted

**Section 2: Category Viability Score**
- 5-dimension scoring with justification
- Go/No-Go recommendation

**Section 3: Category Architecture**
- Name and definition
- Infrastructure blueprint
- Delivery system map
- Trojan Horse deal design
- Roster strategy

**Section 4: Launch Sequence**
- Time-sequenced plan with milestones
- Risk factors and mitigation

**Section 5: The One Move**
- Single highest-leverage action to take THIS WEEK to begin category creation

---

## SAVE LOCATION
Save output to: `Active-Brain/00 Projects/01 Behavioral Intelligence/Hollywood Agents/Category 1 - The Fame Engineers/Shep Gordon/Gordon - Category Architect/`
Filename: `XX - Category Architect Report - [Client/Market] - [Date].md`
