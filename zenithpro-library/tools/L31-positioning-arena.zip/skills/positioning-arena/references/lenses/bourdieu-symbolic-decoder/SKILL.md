---
name: bourdieu-symbolic-decoder
description: Decode how authority and meaning become naturalized in a market.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Pierre Bourdieu (Language and Symbolic Power, 1991; Outline of a Theory of Practice, 1977) — Skill 6 of 6"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/bourdieu-symbolic-decoder {market-or-authority-landscape-description}"
  called_by: [user, bourdieu-field-analyzer, bourdieu-distinction-mapper]
  outputs_to: [client-output-folder]
girard_integration:
  feeds_from: [girard-model-map, girard-scapegoat-radar]
  feeds_to: [girard-field-intelligence]
  shared_data: "Model Map shows WHO is desired. Symbolic Decoder reveals WHY their authority feels legitimate rather than imposed. Scapegoat Radar detects who is being blamed. Symbolic Decoder reveals the LEGITIMATION LOGIC behind scapegoating — how blame gets presented as deserved rather than arbitrary."
veblen_integration:
  feeds_from: [veblen-waste-audit, veblen-status-intelligence]
  feeds_to: [veblen-field-intelligence]
  shared_data: "Status Intelligence maps tier placement. Symbolic Decoder reveals HOW top-tier positions are LEGITIMATED — what makes the hierarchy feel natural rather than arbitrary. Waste Audit identifies conspicuous consumption. Symbolic Decoder identifies the SYMBOLIC MEANING of that consumption — what it communicates beyond wealth."
loewenstein_integration:
  feeds_from: [loewenstein-risk-as-feelings, loewenstein-empathy-gap-map]
  feeds_to: [loewenstein-field-intelligence]
  shared_data: "Risk-as-Feelings shows emotional risk processing. Symbolic Decoder reveals how symbolic power shapes WHAT FEELS RISKY — markets define certain moves as 'dangerous' not because they are, but because breaking with legitimate authority feels threatening. Empathy Gap shows hot-cold decision shifts. Symbolic authority operates in the 'cold' state — it's the quiet assumption underneath."
---

# Bourdieu Symbolic Decoder

---

## LAYER 1: INVARIANTS (Never override.)

1. **Symbolic power is power that doesn't look like power.** It is the ability to impose meanings, categories, and worldviews THAT THE DOMINATED ACCEPT AS LEGITIMATE. The market leader who "sets the standard" exercises symbolic power. The thought leader whose framework becomes "how we all think about it" exercises symbolic power. The key analytical move is recognizing that what appears natural, obvious, or self-evident is actually an exercise of power by those who benefit from the current arrangement.

2. **Symbolic violence must be named without moralizing.** Symbolic violence is not physical violence — it's the process by which dominated groups participate in their own domination by accepting the legitimacy of the hierarchy that subordinates them. The new entrepreneur who believes they need to "earn the right" to charge premium prices is experiencing symbolic violence — they've internalized the established players' framework. Name it analytically, not judgmentally.

3. **Consecration mechanisms must be mapped concretely.** Consecration is the process by which the market anoints certain players as "legitimate" authorities. This is NOT random and NOT purely merit-based. Specific mechanisms do the anointing: speaking at the right events, being featured in the right media, getting endorsed by the right people, winning the right awards. Map the SPECIFIC mechanisms, not a vague sense of "authority."

4. **Symbolic capital is distinct from other capitals but converts from them.** Symbolic capital is the form that any capital takes when it is RECOGNIZED as legitimate. Money is economic capital. Money that is recognized as "deserved" because of "contribution to the field" is symbolic capital. The same resource, but with a layer of legitimation. Map where capital has been SYMBOLICALLY LEGITIMATED versus where it's raw and unlegitimated.

5. **The client's own symbolic position must be decoded honestly.** What symbolic capital does the client actually hold? What consecration mechanisms have they been through? What symbolic power do they exercise (perhaps unknowingly)? What symbolic violence do they experience (perhaps unknowingly)? Both sides of the equation.

---

## LAYER 2: QUALITY GUIDANCE

6. **Misrecognition is the engine of symbolic power.** The REASON symbolic power works is that it ISN'T RECOGNIZED AS POWER. It's recognized as "natural," "obvious," "just how things are." Every time you surface a misrecognition — where the market treats an exercise of power as natural order — you've found a strategic insight. These are the most valuable findings.

7. **Legitimation strategies differ by field position.** Dominant players legitimize through consecration and institutional endorsement. Challengers legitimize through heterodox disruption and "authentic" positioning. Both are legitimation strategies. Neither is more "real" — they're both deployed to accumulate symbolic capital. Analyze all positions equally.

8. **Symbolic capital accumulates slowly but deploys instantly.** Years of consecration produce symbolic capital that can be deployed in a single statement: "I've been doing this for 20 years" / "As featured in..." / "My students have generated..." The asymmetry between accumulation time and deployment speed is what makes symbolic capital so powerful and so hard to compete against directly.

---

## PURPOSE

Markets aren't just structured by money, knowledge, and connections. They're structured by LEGITIMACY — the shared (but never questioned) agreement about who has the right to speak, what counts as authority, which frameworks are "real," and what the hierarchy "naturally" looks like.

Bourdieu's insight is that this legitimacy is not earned neutrally — it's produced by specific mechanisms that benefit specific players. The player who gets to define the market's vocabulary exercises power over everyone who adopts that vocabulary. The player whose framework becomes "the standard" has structured everyone else's thinking. This isn't conspiracy; it's how symbolic power works in every field.

This skill decodes the symbolic power structures so you can see: who holds legitimacy, how they got it, what mechanisms maintain it, where the market is participating in its own subordination, and where opportunities exist to build, borrow, challenge, or redirect symbolic capital.

---

## INPUT REQUIREMENTS

Provide:
1. **Market or authority landscape** — which space of competition and which authority structures are relevant
2. **Key authority figures** — minimum 8 players who hold or claim authority in this space
3. **Client identity** — who is being positioned within this symbolic landscape

Optional:
- Existing Field Analysis from bourdieu-field-analyzer (shows field structure and doxa)
- Existing Distinction Map from bourdieu-distinction-mapper (shows taste hierarchies)
- Specific concern ("How do I become the recognized authority?" / "Why does [competitor] get treated as the expert when their work is inferior?")

---

## EXECUTION PROCESS

### Step 1: Consecration Mechanism Inventory

Map the specific mechanisms through which the market anoints "legitimate" authorities:

**Media consecration:** What publications, podcasts, platforms confer legitimacy? Who controls access?
**Event consecration:** What stages/events are consecrating? (Speaking at X = legitimated. Speaking at Y = not yet.)
**Peer consecration:** Whose endorsement matters? (Being referenced by [Name] = instant credibility)
**Institutional consecration:** What institutions, awards, certifications confer legitimacy?
**Output consecration:** What types of output confer authority? (Books? Research? Revenue proof? Student results?)
**Community consecration:** Which community membership/leadership confers legitimacy?

For each mechanism:
- Who controls it? (Gatekeepers)
- What criteria (stated and unstated) determine access?
- How recently has it been used? (Active vs. historical)
- Who has been consecrated through it? (Recent anointed figures)

### Step 2: Symbolic Capital Distribution

For each key player, assess their symbolic capital:

| Player | Consecration | Framework Adoption | Authority | Legit Source | Symbolic Power |
|--------|-------------|-------------------|-----------|-------------|---------------|
| [Name] | [Which mechanisms they've been through] | [Has their vocabulary/framework been adopted?] | [Recognized as authority by whom?] | [What the legitimacy rests on] | H/M/L |

Distinguish between:
- **Consecrated authorities:** Fully legitimated, their statements carry automatic weight
- **Aspiring authorities:** Building legitimacy, still proving themselves
- **Heterodox challengers:** Challenging established authority, building alternative legitimacy
- **Invisible players:** Hold capital but lack symbolic recognition

### Step 3: Legitimation Strategy Analysis

How are different players building and maintaining symbolic capital?

**Consecration-seeking strategies:**
- Pursuing media features, speaking slots, endorsements
- Publishing books, research, thought leadership
- Building track records and proof portfolios

**Framework-imposition strategies:**
- Creating vocabulary that others adopt ("funnel," "scaling," "leverage")
- Defining categories that structure the market's thinking
- Publishing "definitive" frameworks or methodologies

**Association strategies:**
- Standing next to consecrated figures (proximity legitimation)
- Co-creating with established authorities
- Joining legitimating groups/circles

**Heterodox legitimation strategies:**
- Explicitly challenging dominant frameworks ("Everything they told you is wrong")
- Building alternative consecration mechanisms (own events, own media, own community)
- Using outsider status as legitimating credential ("I'm not part of the establishment")

### Step 4: Symbolic Violence Mapping

Identify where market participants are accepting domination as natural:

**Pricing deference:** Where do players accept that they "can't" charge premium because they haven't been consecrated? (This is symbolic violence — the dominant players' pricing authority is accepted as earned rather than structurally produced)

**Framework adoption:** Where have players adopted dominant frameworks without questioning them? (Using someone else's vocabulary to describe their own work is accepting their symbolic authority)

**Self-limiting beliefs:** Where do market participants hold back because they feel they haven't "earned the right" to certain positions? (The sense of unworthiness is internalized symbolic violence)

**Gatekeeping acceptance:** Where do players accept that certain gatekeepers' approval is NECESSARY rather than one path among many?

For each instance:
- What's being accepted as natural that is actually a power exercise?
- Who benefits from this acceptance?
- What would change if this were recognized as constructed rather than natural?

### Step 5: Misrecognition Audit

The deepest layer. What is the market collectively misrecognizing?

**Authority misrecognition:** Treating constructed authority as natural expertise ("They're the expert because they're the expert" — circular legitimation)
**Merit misrecognition:** Treating structural advantages as personal merit ("They succeed because they're better" — ignoring the capital advantages that enabled success)
**Framework misrecognition:** Treating one player's framework as objective truth rather than one perspective that happened to get adopted
**Standard misrecognition:** Treating market standards as natural quality criteria rather than as standards set by dominant players to protect their position

### Step 6: Client Symbolic Position Assessment

Map the client's position in the symbolic landscape:

**Symbolic capital held:** What consecration have they been through? What authority do they carry? Where is their legitimacy recognized?
**Symbolic capital gaps:** Where do they lack legitimation despite holding real capital?
**Symbolic power exercised:** Are they imposing frameworks, vocabulary, standards? Consciously or unconsciously?
**Symbolic violence experienced:** Where are they accepting limits on their positioning that are structurally imposed, not earned?
**Legitimation strategy:** What are they currently doing to build symbolic capital? Is it working?
**Consecration pathway:** What's the most efficient path to further consecration given their current position?

### Step 7: Self-Examination

Surface the honest assessment:
- Is the client exercising symbolic power they don't recognize? (Imposing frameworks on students/clients without awareness)
- Is the client subject to symbolic violence they don't recognize? (Accepting limits that serve others' interests)
- Are they pursuing consecration through mechanisms that don't match their strengths?
- Are they trying to BUILD symbolic capital when they should be DEPLOYING capital they already hold?
- Is their authority more legitimate than they realize? Or less?

---

## OUTPUT STRUCTURE

### Symbolic Power Audit Report

**Section 1: Consecration Mechanism Map**
The specific mechanisms that confer legitimacy in this market. Who controls each, what the criteria are, who has been anointed.

**Section 2: Symbolic Capital Distribution**
Per-player symbolic capital assessment — consecration, framework adoption, authority recognition, and power level.

**Section 3: Legitimation Strategy Analysis**
How players are building and maintaining symbolic capital — consecration-seeking, framework-imposition, association, and heterodox strategies.

**Section 4: Symbolic Violence Map**
Where market participants accept domination as natural. Pricing deference, framework adoption, self-limiting beliefs, gatekeeping acceptance.

**Section 5: Misrecognition Audit**
What the market collectively treats as natural that is actually structurally produced. The deepest strategic insights.

**Section 6: Client Symbolic Position**
Honest assessment of the client's symbolic capital, gaps, power exercised, violence experienced, and legitimation trajectory.

**Section 7: Self-Examination**
Client blind spots about their own symbolic position — unrecognized power, unrecognized subordination, mismatched legitimation strategies.

**Section 8: Cross-System Integration**
If Girard/Veblen/Loewenstein data exists: How do symbolic power structures interact with desire dynamics (Girard), status display (Veblen), and decision behavior (Loewenstein)?

**Section 9: Strategic Recommendations**
Specific symbolic capital moves — consecration pathways to pursue, frameworks to impose or challenge, misrecognitions to exploit or expose, symbolic violence to break free from — with rationale tied to the power audit.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Pierre Bourdieu - Symbolic Decoder/01 - Symbolic Power Audit - [Market] - [Date].md`
