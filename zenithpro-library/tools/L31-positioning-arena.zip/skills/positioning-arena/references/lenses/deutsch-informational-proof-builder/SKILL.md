---
name: deutsch-informational-proof-builder
description: Construction tool for informational proof elements. Takes a claim to be supported and outputs the three-part informational proof structure (credential/track-record signal + specific quantified outcome + mechanism explanation), calibrated for audience sophistication and framed as evidence about reality.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Morton Deutsch & Harold Gerard (Informational vs. Normative Social Influence) — Idea 2"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/deutsch-informational-proof-builder {claim-to-support} [audience-sophistication: low|medium|high|expert]"
  called_by: [user, deutsch-proof-staging-diagnostic, deutsch-field-intelligence]
  outputs_to: [project-folder]
depends_on: [deutsch-proof-staging-diagnostic]
---

# Deutsch Informational Proof Builder

---

## LAYER 1: INVARIANTS (Never override.)

1. **Informational influence produces genuine private belief change.** The mechanism: the prospect treats the proof as evidence about reality — what is actually true about the product, the outcome, the method — and updates their private belief accordingly. This is not persuasion by social pressure; it is persuasion by evidence quality. The built proof must be constructed so it functions as evidence about reality, not as testimony of approval.

2. **The three-part structure is the minimum viable informational proof.** Every informational proof element must contain all three components: (1) Credential/track-record signal — establishes that the source has genuine expertise or directly relevant experience; (2) Specific quantified outcome — names the actual result with specificity, magnitude, and attribution; (3) Mechanism explanation — explains why and how the outcome occurred, which requires actual knowledge and distinguishes genuine expertise from endorsement. Missing any one of the three degrades the element's informational pathway value and pushes it toward the normative pathway, where it will fail with skeptical audiences.

3. **Framing as evidence about reality is non-negotiable.** The same data can be framed as social proof ("thousands of customers chose this") or as evidence about reality ("a 2023 randomized trial in the Journal of Applied Psychology showed that practitioners who used this method showed a 34% improvement in client retention vs. control"). The first is normative. The second is informational. Every output of this skill must be framed as evidence about reality. Never allow informational proof to slip into "look how popular this is" language.

4. **Calibrate to audience sophistication — higher bars require stronger signals.** Expert-skeptic audiences (researchers, senior practitioners, sophisticated investors, premium-market buyers) have higher minimum thresholds for what counts as credible evidence about reality. For them, credentials without outcomes, outcomes without mechanisms, and mechanisms that lack specificity all fail. "Clinically proven" in a market saturated with false clinical claims has near-zero informational value. The sophistication calibration determines the minimum specificity and evidence quality required for the proof to function informationally.

5. **Ambiguity activation is the informational influence activation condition.** Informational influence fires most strongly when the prospect has genuine uncertainty about what the correct choice is. From Sherif's ambiguity condition (the foundational predecessor): when the correct answer is unclear, others' behavior and testimony provide genuine epistemic value. When the prospect has already formed a confident belief, informational influence is less needed (they already know) or less available (they are defending an existing position). The proof builder must identify whether ambiguity is present and, if not, how to activate it before deploying the informational proof.

---

## LAYER 2: QUALITY GUIDANCE

6. **Specificity is the primary credibility signal for skeptical audiences.** Generic outcomes ("improved results," "saved time," "grew revenue") have low informational value because they could be claimed by anyone. Specific outcomes ("reduced client churn from 34% to 11% over 6 months in a firm with 200 managed accounts") have high informational value because the specificity itself signals genuine knowledge. The more specific, the more it functions as evidence about reality rather than endorsement.

7. **Mechanism explanation is the element most commonly omitted.** Most testimonials and proof elements state outcomes. Almost none explain mechanisms. "Why did this happen?" is the question that distinguishes informational proof from normative proof. A source who can explain the mechanism reveals genuine expertise — they do not just know what happened, they know why. For sophisticated buyers, mechanism explanation is the single highest-leverage addition to most proof sections.

8. **The sherif-field-intelligence cross-reference.** Sherif's ambiguity condition (1935) established that informational influence operates most powerfully when the prospect faces maximum uncertainty about the correct answer. Before deploying informational proof, the copy should surface the ambiguity the proof resolves: "You've probably wondered whether X is actually true, or whether it works the way it's claimed." Activating the uncertainty before presenting the evidence amplifies the informational influence by making the evidence more epistemically valuable.

---

## PURPOSE

Most proof in direct response copy is normative by default — testimonials, counts, social validation. Informational proof — proof that functions as evidence about reality and produces genuine private belief change — is rare, harder to construct, and dramatically more valuable for premium markets, skeptical audiences, and high-LTV business models.

This tool takes a specific claim that needs to be supported and builds the three-part informational proof structure that maximizes the element's informational pathway activation. It also flags ambiguity activation opportunities and outputs the proof framed as evidence about reality at the appropriate sophistication level.

---

## INPUT REQUIREMENTS

Provide:
1. **The claim to be supported** — what do you need the prospect to believe?
   Example: "This method reliably improves client retention" or "The investment produces measurable ROI within 90 days"

2. **Available proof sources** — what evidence exists?
   - Expert/researcher citations available? (Names, credentials, publications, specific findings)
   - Client/customer results available? (Names, industries, specific before/after data, timeframes)
   - Internal data available? (Aggregate metrics, longitudinal data, case studies)
   - Third-party validation available? (Press, certifications, audits, industry recognition)

3. **Audience sophistication level:** Low / Medium / High / Expert-skeptic

4. **Purchase context:** Private research (anonymous) / Community/event (visible) — determines whether to supplement with normative framing or keep pure informational

---

## EXECUTION PROCESS

### Step 1: Ambiguity Assessment
Before building the proof, assess the ambiguity landscape:
- What is the prospect's current belief state about this claim? (Sceptical / Uncertain / Slightly positive / Already convinced)
- Is there genuine uncertainty about the correct answer? (Yes / No / Partially)
- What specific doubts or alternative hypotheses does the prospect hold?

If genuine uncertainty exists: the proof will activate informational influence directly.
If the prospect is skeptical with a formed negative belief: the proof must first destabilize the existing belief before presenting the evidence (sequence: surface the skepticism → acknowledge it → present the evidence as resolving what was genuinely uncertain).

Ambiguity activation language (to use before the proof element): "You may have wondered whether [claim] is actually true in [specific context], or whether it's just marketing language. Here's what the evidence actually shows:"

### Step 2: Source Qualification Audit
For each available proof source, assess:
- **Credential specificity:** Does the source have a credential that is directly relevant to this claim? (Generic expertise = low value; Domain-specific expertise = high value; Institutional affiliation = adds credibility; Track record with this exact problem = maximum value)
- **Experience relevance:** Is the source's experience specifically relevant to the prospect's situation? A 7-figure agency owner's testimony is more informational to an agency owner than a blogger's testimony.
- **Conflict of interest check:** Does the source have an obvious financial incentive to endorse? If yes, the informational value is discounted. Flag and compensate (neutral third-party corroboration, or explicit conflict-of-interest acknowledgment that increases perceived honesty).

Rank available sources by informational value.

### Step 3: Three-Part Structure Construction
For each selected proof source, build the complete three-part element:

**Part 1 — Credential/Track-Record Signal**
Establish why this source has epistemic authority on this specific claim. Format:
- [Name], [specific relevant credential or role] — NOT generic ("successful entrepreneur") but specific ("founder of [firm type], 12 years specializing in [specific domain]")
- If using a study or data source: [Publication/institution], [year], [study design if relevant] — NOT "research shows" but "[specific journal/institution], [year]: [study parameters]"
- If using aggregate data: [data source and collection methodology], [scope/scale of data], [timeframe]

**Part 2 — Specific Quantified Outcome**
Name the actual result with full specificity. The minimum requirements:
- What changed (the outcome variable)
- By how much (the magnitude, ideally with a comparison baseline)
- For whom (specific enough to be identity-relevant to the prospect)
- In what timeframe
- Under what conditions (the context that determines generalizability)

Avoid: "significant improvement," "substantial results," "major increase"
Use: "[specific metric]: from [X] to [Y] in [Z timeframe] for [specific type of person/organization] doing [specific thing]"

**Part 3 — Mechanism Explanation**
Explain why and how the outcome occurred. This is the element that makes the proof informational rather than merely normative. Requirements:
- Identify the causal mechanism — what specifically produced the result?
- State it in terms the prospect can understand and evaluate
- The mechanism should be falsifiable (a claim that could in principle be disproven) — vague mechanism claims ("it works because of our unique approach") have no informational value
- The mechanism should be specific enough to imply knowledge: anyone can claim "it increases productivity"; explaining the specific mechanism reveals genuine expertise

Format: "The [outcome] occurred because [specific mechanism]. Specifically: [how mechanism operates in practice]."

### Step 4: Evidence-About-Reality Framing
Frame the complete three-part element as evidence about reality, not as social proof:

**Normative framing (avoid):** "Thousands of customers have used this and loved it."
**Informational framing (use):** "Here is what the data actually shows about [claim]:"

Framing signals:
- Lead with the claim being addressed, not the count of believers
- Position the source as an evidence-provider, not an endorser
- Frame the outcome as a finding, not a recommendation
- If the evidence is uncertain or conditional, say so — conditional honesty increases informational credibility with skeptical audiences

### Step 5: Sophistication Calibration
Adjust the proof element for the target audience's sophistication level:

**Low sophistication:** Credential can be simpler (title/institution), outcome can be less granular, mechanism can be accessible (metaphor-level explanation). Focus on outcome magnitude and source relevance.

**Medium sophistication:** Full three-part structure required. Mechanism should be substantive but does not need to be technical.

**High sophistication:** All three parts must be present and specific. Credential must be relevant to the specific domain (not just generally impressive). Mechanism must be technically plausible and non-trivially stated. Data should be specific enough to be falsifiable.

**Expert-skeptic:** Highest bar. Source must be maximally credible to THIS audience specifically (not just impressive in general). Outcome must be specific, attributed, and verifiable in principle. Mechanism must withstand expert scrutiny — it should be the kind of explanation that holds up under informed questioning. Consider adding: limitations of the evidence, conditions under which it may not apply (this increases credibility by demonstrating epistemic honesty).

---

## OUTPUT STRUCTURE

### Informational Proof Element: [Claim Being Supported]

**Ambiguity assessment:**
- Prospect's current belief state: [assessment]
- Ambiguity present: [Yes/No/Partial]
- Ambiguity activation needed: [Yes/No — include language if yes]

**Source ranking:**
- Selected source(s): [names/types ranked by informational value]
- Sources excluded and why: [if any]

**Three-part proof structure (for each selected source):**

---

**[Proof Element 1]**

*Part 1 — Credential/Track-Record Signal:*
[Specific credential framing]

*Part 2 — Specific Quantified Outcome:*
[Outcome with all required specificity elements]

*Part 3 — Mechanism Explanation:*
[Causal mechanism explained at appropriate sophistication level]

*Evidence-about-reality framing:*
[Full assembled element with informational framing]

---

**Sophistication calibration notes:**
[Any adjustments made for target audience level]

**Cross-pathway check:**
[Confirm this element is functioning informationally, not normatively — flag any language that could be perceived as social pressure]

**Proof paradox check:**
[Confirm this element does not increase normative proof load — informational proof can coexist with existing normative elements without triggering proof paradox]

---

## OUTPUT FILE

Save complete output to:
`[project-folder]/Deutsch & Gerard - Informational Proof/[YYYY-MM-DD] - Informational Proof - [Claim Name].md`
