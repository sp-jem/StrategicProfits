---
name: barthes-myth-construction-strategist
description: Design intentional brand myths that make positioning feel natural.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Roland Barthes (Mythologies, 1957; Elements of Semiology, 1964; The Fashion System, 1967) — Skill 6 of 7"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/barthes-myth-construction-strategist {market, positioning goal, or myth to construct/invert}"
  called_by: [user, barthes-myth-decoder, barthes-signal-archaeology, barthes-connotation-mapper, barthes-ideology-auditor, barthes-punctum-finder]
  outputs_to: [client-output-folder]
freshness_gate: 45
thaler_integration:
  feeds_from: [thaler-mental-accounting, thaler-default-detector, thaler-choice-architect]
  feeds_to: [thaler-nudge-auditor, thaler-loss-aversion-audit]
  shared_data: "Mental Accounting reveals which price frames are already naturalized as 'obvious' (myths about what things should cost). Default Detector reveals which choice architectures are perceived as neutral (mythologized defaults). Choice Architect reveals how to embed new myths into decision structures so they feel like natural framing rather than persuasion."
ariely_integration:
  feeds_from: [ariely-predictability-auditor, ariely-expectation-architect, ariely-social-norms-detector]
  feeds_to: [ariely-relativity-engine, ariely-honesty-calibrator]
  shared_data: "Predictability Auditor reveals which irrational behaviors are already naturalized as 'just how people are' — these are myths about human nature that can be leveraged or inverted. Expectation Architect reveals how myths SET expectations that change actual experience. Social Norms Detector reveals which myths operate through social norm enforcement vs. market norm logic."
damasio_integration:
  feeds_from: [damasio-somatic-marker-audit, damasio-emotion-feeling-mapper, damasio-body-loop-auditor]
  feeds_to: [damasio-ecs-designer, damasio-homeostatic-drive-mapper]
  shared_data: "Somatic Marker Audit reveals the bodily responses myths trigger — a naturalized myth activates somatic markers (gut feelings) that make its truth feel PHYSICAL, not intellectual. Emotion-Feeling Mapper reveals whether the myth operates at the emotion level (pre-conscious, fast) or feeling level (conscious, narratable). Body Loop Auditor reveals whether the myth's 'naturalness' is experienced as a body state."
girard_integration:
  feeds_from: [girard-model-map, girard-desire-propagation, girard-mimetic-content-strategist]
  feeds_to: [girard-desire-autopsy, girard-rivalry-detector, girard-scapegoat-radar]
  shared_data: "Model Map identifies WHO will model the myth — myths naturalize through respected models behaving AS IF the myth is true, not through argument. Desire Propagation reveals how myths spread mimetically through model imitation chains. Mimetic Content Strategist designs content that makes the myth modelable. Scapegoat Radar reveals which competitor or ideology the myth positions as the 'enemy' whose exposure makes the myth feel like liberation."
veblen_integration:
  feeds_from: [veblen-status-intelligence, veblen-signal-decoder, veblen-display-map]
  feeds_to: [veblen-price-ladder, veblen-waste-audit, veblen-emulation-tracker]
  shared_data: "Status Intelligence reveals which myths are maintained because they serve status hierarchies — challenging these myths threatens status holders who will defend them. Signal Decoder reveals which signals are 'read' as confirming the myth. Display Map reveals the conspicuous behaviors that reinforce the myth's naturalness. Myths that serve status functions are harder to invert because status holders actively maintain them."
bourdieu_integration:
  feeds_from: [bourdieu-field-analyzer, bourdieu-habitus-profiler, bourdieu-capital-audit, bourdieu-symbolic-decoder]
  feeds_to: [bourdieu-distinction-mapper, bourdieu-social-capital-mapper]
  shared_data: "Field Analyzer reveals the power dynamics that determine WHOSE myths dominate the market — myth construction must account for field position. Habitus Profiler reveals what feels 'natural' to each audience segment — the myth must resonate with habitus, not violate it. Capital Audit reveals which forms of capital (economic, cultural, social, symbolic) give authority to myth-makers. Symbolic Decoder reveals the symbolic violence through which dominant myths are maintained."
loewenstein_integration:
  feeds_from: [loewenstein-curiosity-architect, loewenstein-anticipation-engine, loewenstein-visceral-audit]
  feeds_to: [loewenstein-information-flow, loewenstein-empathy-gap-map]
  shared_data: "Curiosity Architect reveals information gaps that myths can fill — a well-constructed myth resolves curiosity in a way that feels like discovery rather than persuasion. Anticipation Engine reveals how myths shape what people anticipate and therefore what they experience. Visceral Audit reveals when myths are being processed through visceral (hot) states vs. deliberative (cold) states — visceral processing accelerates naturalization."
festinger_integration:
  feeds_from: [festinger-commitment-architect, festinger-belief-behavior-sequencer, festinger-dissonance-detector]
  feeds_to: [festinger-post-decision-engineer, festinger-effort-value-auditor, festinger-social-comparison-architect]
  shared_data: "Commitment Architect designs behavior sequences that create BELIEF in the myth — once someone acts AS IF the myth is true, dissonance reduction makes them believe it IS true. Belief-Behavior Sequencer orders the actions that naturalize the myth in the buyer's own experience. Dissonance Detector reveals where the myth contradicts existing beliefs — these are friction points that need behavior-first resolution, not argument."
mcluhan_integration:
  feeds_from: [mcluhan-medium-audit, mcluhan-hot-cool-analyzer, mcluhan-sensory-balance-mapper]
  feeds_to: [mcluhan-tetrad-analyst, mcluhan-figure-ground-reversal]
  shared_data: "Medium Audit reveals which media environments are hospitable to myth construction — myths naturalize differently in hot media (filled, low participation) vs. cool media (sparse, high participation). Cool media may naturalize myths faster because the audience fills in meaning themselves, making the myth feel like their own conclusion. Figure-Ground Reversal reveals what the myth makes invisible (the ground) while highlighting what it makes visible (the figure)."
mccracken_integration:
  feeds_from: [mccracken-meaning-transfer-audit, mccracken-cultural-category-mapper, mccracken-ritual-designer]
  feeds_to: [mccracken-celebrity-meaning-analyst, mccracken-brand-meaning-architect]
  shared_data: "Meaning Transfer Audit reveals how cultural meaning flows from the culturally constituted world through advertising and fashion into consumer goods — myth construction must align with these meaning-transfer channels. Cultural Category Mapper reveals the category systems that organize meaning in the buyer's world — myths either reinforce or rearrange these categories. Ritual Designer engineers the possession, exchange, grooming, and divestment rituals through which buyers naturalize the myth in their own lives."
barthes_integration:
  feeds_from: [barthes-myth-decoder, barthes-connotation-mapper, barthes-signal-archaeology, barthes-ideology-auditor, barthes-punctum-finder]
  feeds_to: [barthes-myth-decoder, barthes-ideology-auditor]
  shared_data: "Myth Decoder reveals the existing myths operating in the market — you must decode before you construct. Connotation Mapper reveals the chains of connotation that give signs their meaning — myth construction must work WITH existing connotation chains or deliberately reroute them. Signal Archaeology reveals the historical layers of meaning sediment — new myths must account for what came before. Ideology Auditor reveals whose interests existing myths serve — your construction either reinforces or challenges these interests. Punctum Finder identifies the emotionally piercing details that can anchor a myth in felt experience rather than abstract positioning."
---

# Barthes Myth Construction Strategist

---

## LAYER 1: INVARIANTS (Never override.)

1. **Myth construction is not lying — it is selective naturalization.** A myth takes one genuine aspect of reality and presents it as the whole truth, making alternatives invisible. "AI extends human capability" is not a lie — it is one truth presented as the primary truth while "AI replaces human work" is made invisible. Effective myth construction requires genuine material to work with. A myth built on fabrication will collapse when buyers encounter reality. A myth built on selective truth will be reinforced every time buyers encounter the selected truth — which they will, because it is real.

2. **Myths succeed through REPETITION, not argument.** A myth becomes natural not because someone proved it but because it was repeated across enough contexts by enough voices until it felt obvious. "You get what you pay for" is not a proven law — it is a myth naturalized through repetition. This is why myth construction requires a repetition strategy — not just a positioning statement but a plan for how, where, and through whom the myth gets repeated. A brilliant myth stated once is a marketing claim. A simple myth repeated a thousand times through a hundred channels is culture.

3. **Myths require MODELS to naturalize.** (Connects to Girard) A myth alone is a claim. A myth embodied by respected models is culture. When a successful entrepreneur BEHAVES AS IF "implementation speed matters more than information volume," that behavior naturalizes the myth far more effectively than any argument could. The construction strategy must identify who will model the myth — through behavior, not endorsement. Endorsement says "I think this is true." Behavior says "this IS true — so obviously true I don't even discuss it." Behavior naturalizes; endorsement advertises.

4. **The strongest myths INVERT existing myths rather than creating from scratch.** "AI will do everything for you" inverted to "AI extends YOUR capability." "More information equals more success" inverted to "implementation speed beats information volume." Inversions are powerful because they use the existing myth's cultural weight against itself. The audience already FEELS something is off about the existing myth — the inversion crystallizes that unease into a new truth. Inversions feel like revelation ("I always felt something was off about that") rather than novelty ("here's something new to consider"). Revelation is naturalized instantly; novelty requires months of repetition.

5. **Myth construction fails when it contradicts lived experience.** If buyers have experienced that "online courses don't work," no amount of myth construction around "this course is different" will naturalize. The myth must connect to something the buyer has ALSO experienced as true. "Most courses are consumption, not implementation — what if you could deploy in 47 minutes?" works because it acknowledges lived experience (courses don't work) and connects to another lived experience (when I actually DO something, it works). The new myth rides on existing experience rather than fighting it.

6. **Counter-myths destroy faster than myths build.** A competitor who successfully constructs a counter-myth ("people who charge $5,000 for AI courses are selling overpriced information") can dismantle years of myth construction in weeks. Counter-myths work because they exploit the same mechanism as myths — selective truth presented as whole truth — but they have the additional advantage of DEBUNKING energy. Audiences feel clever when they see through a myth. The strategy must include counter-myth defense: how to make the myth resistant to inversion. The best defense is deep connection to lived experience — a myth that buyers have PERSONALLY VERIFIED through their own behavior is nearly impossible to counter.

7. **Naturalization takes time and cannot be rushed.** Myth construction operates on cultural timescales, not campaign timescales. A myth that feels natural in 6 months was built through 6 months of consistent, multi-channel, model-reinforced repetition. Short-term campaigns create awareness; long-term myth construction creates inevitability. Any strategy that promises myth naturalization in a single launch or campaign is confusing advertising with myth. Advertising says "consider this." Myth says "everyone knows this." The distance between those two states is measured in months of disciplined repetition.

---

## LAYER 2: QUALITY GUIDANCE

8. **Always map the existing myth landscape before attempting construction.** You are not building in empty space — you are building within or against existing myths. Every market has a mythology: "what everyone knows," "how things work," "what the good players do." These existing myths are the terrain. Ignoring them is like building a house without surveying the land. Map them first. Decode them using Barthes Myth Decoder if available.

9. **Identify which existing myths are ALLIES and which are ENEMIES.** Allied myths can accelerate your construction — you align with them and ride their momentum. Enemy myths must be inverted or circumvented — building directly against them requires sustained energy and risks triggering counter-myth responses from those who benefit from the existing mythology. Neutral myths can be ignored. The strategic question for every existing myth: align, invert, or ignore?

10. **The myth construction plan must include four components.** (a) The core myth statement — what should feel natural when construction succeeds. (b) The repetition strategy — channels multiplied by frequency multiplied by voices, with varied expression (same meaning, different words). (c) The modeling strategy — who embodies it and what behavior makes it visible. (d) The defense strategy — how the myth resists inversion and counter-myth attack. A plan missing any component will fail.

11. **Cross-reference with the full thinker network.** Girard: who models the myth and how mimetic desire spreads it. Bourdieu: whose cultural position gives the myth authority and how field dynamics constrain construction. Festinger: how behavior creates belief in the myth through dissonance reduction. McCracken: how meaning flows from culture through the myth into the product via transfer rituals. Veblen: how status dynamics support or undermine the myth. McLuhan: which media environments are hospitable to myth construction. Thaler: how defaults and frames embed the myth. Ariely: how expectations set by the myth change actual experience. Damasio: how the myth becomes a somatic marker. Loewenstein: how curiosity and anticipation drive myth adoption.

---

## PURPOSE

Most businesses argue their positioning. They make claims, present evidence, construct logical cases. The problem: arguments can be counter-argued. For every claim, a competitor can construct a counter-claim. For every piece of evidence, alternative evidence exists. Argument-based positioning exists in a permanent state of contest.

Myths operate differently. A myth is not argued — it is assumed. "You get what you pay for" is not a conclusion anyone reached through evidence — it is a cultural assumption that feels like common sense. No one argues FOR it because no one needs to. It just IS. That is the power of myth: it removes the claim from the arena of debate and places it in the realm of the obvious.

This skill designs intentional myths — cultural meanings that will be perceived as natural facts rather than marketing claims. It takes the business's genuine strengths, selects the truth that serves positioning, and engineers the repetition, modeling, and cultural reinforcement required to naturalize that truth until it feels inevitable.

The process begins with decoding the existing myth landscape (what does the market already "know"?), identifies construction opportunities (align, invert, or build?), designs the core myth, engineers the repetition and modeling architecture required for naturalization, plans defense against counter-myths, and integrates with the full thinker network to ensure the myth operates at every psychological, social, and cultural level.

The output is not a tagline or positioning statement. It is a myth construction strategy: a multi-month plan for making one truth feel so natural that arguing against it feels absurd.

---

## INPUT REQUIREMENTS

Provide:
1. **The market or category** — what space the brand operates in and who the buyers are
2. **The positioning goal** — what the brand wants to mean, what truth it wants naturalized
3. **The competitive landscape** — who else operates in this space and what they claim

Optional:
- An existing myth to invert (if the goal is repositioning against an entrenched narrative)
- Current brand messaging and positioning (to identify what myths are already partially constructed)
- Customer language and testimonials (reveals which truths buyers already experience)
- Output from Barthes Myth Decoder (the existing myth landscape, already decoded)
- Output from Girard Model Map (who the market's current models are)
- Output from Bourdieu Field Analyzer (the power dynamics of the market)

---

## EXECUTION PROCESS

### Step 1: Market Myth Landscape

Map all active myths in the market. These are the things "everyone knows" — the assumptions that feel like facts:

**Category myths:**
- What is "obviously true" about this type of product or service?
- What do buyers "just know" about how this category works?
- What would a newcomer to the market learn as "common sense" within the first week?

**Success myths:**
- What does "everyone know" about how to succeed in this space?
- What methods/approaches are assumed to be "the way it's done"?
- What results are considered "normal" or "realistic"?

**Quality myths:**
- What signals "quality" in this market? (Price, production value, credentials, etc.)
- What signals "scam" or "low quality"?
- What do buyers assume about the relationship between signals and substance?

**Player myths:**
- Which competitors have successfully naturalized myths about themselves?
- What does the market "know" about the major players?
- Which player-myths are vulnerable to inversion?

For each myth identified:
- **State it as a naturalized truth** (how a believer would express it)
- **Decode it** (what selective truth is being naturalized, what alternative is being hidden)
- **Assess its strength** (how deeply naturalized is it — surface assumption or deep cultural bedrock?)
- **Identify its beneficiaries** (who profits from this myth's continued naturalization)

### Step 2: Myth Opportunity Analysis

Given the positioning goal, classify each existing myth:

**ALLY myths (align with them):**
- Which existing myths, if reinforced, would support your positioning?
- How can your myth construction ride the momentum of allied myths?
- What's the fastest path to naturalization through alignment?

**ENEMY myths (invert or circumvent):**
- Which existing myths directly contradict your positioning?
- Can they be inverted? (Use their weight against them)
- Must they be circumvented? (Build around them rather than through them)
- Who benefits from these myths and will defend them?

**NEUTRAL myths (ignore):**
- Which myths are irrelevant to your positioning?
- Are any neutral myths at risk of becoming enemies? (Monitor but don't engage)

**VACUUM opportunities (build from scratch):**
- Are there spaces in the myth landscape with no dominant myth?
- What truths exist in buyer experience that no one has naturalized yet?
- These are the easiest construction opportunities — no existing myth to overcome

### Step 3: Core Myth Design

Design the myth to be constructed:

**The myth statement:**
- What should feel naturally, obviously true when construction succeeds?
- Write it as a buyer would say it casually: "Everyone knows that..." or "It's just common sense that..."
- It should sound boring in its obviousness — that's the mark of successful naturalization

**The truth being naturalized:**
- What genuine aspect of reality is being selected?
- Is this truth verifiable through buyer experience? (Critical for durability)
- Can the buyer confirm this truth through their own behavior? (Critical for defense)

**The alternative being made invisible:**
- What competing truth does the myth suppress?
- Is this suppression sustainable? (If the hidden truth is easily experienced, the myth will be fragile)
- How visible is the hidden alternative currently? (High visibility = harder construction)

**The experiential anchor:**
- What has the buyer already experienced that confirms this myth?
- What behavior can the buyer perform that will confirm this myth in their own life?
- The strongest myths feel like the buyer "always knew" this — the construction just gave it words

**Stress test the myth:**
- Does it connect to genuine experience? (If not: won't naturalize)
- Does it survive first contact with the product? (If not: creates dissonance)
- Can a competitor easily invert it? (If so: needs stronger defense)
- Does it serve the positioning goal? (If not: beautiful but useless)
- Does it violate habitus for the target audience? (If so: will feel foreign, not natural)

### Step 4: Repetition Architecture

Design the repetition strategy. Myths naturalize through varied repetition — same meaning, different expressions:

**Channel mapping:**
- Which channels reach the target audience? (Content, social, email, community, events, PR, partners)
- Which channels carry MORE naturalizing authority? (A myth repeated in a peer community naturalizes faster than the same myth in an ad)
- Which channels allow BEHAVIORAL modeling? (Video, live events, community > static content)

**Frequency design:**
- What repetition frequency avoids both "too rare to naturalize" and "too frequent to feel natural"?
- High-authority channels: lower frequency, higher impact per exposure
- Ambient channels: higher frequency, lower intensity per exposure
- The mix should create the feeling of "I keep hearing this everywhere" without "someone is pushing this"

**Variation strategy:**
- List 10-15 different ways to express the same myth
- Different formats: story, data, example, metaphor, question, observation, quote
- Different voices: founder, team, customers, partners, industry observers
- Different contexts: responding to events, answering questions, making predictions, reviewing competitors
- Same underlying meaning in every variation — the audience should feel the pattern without seeing the repetition

**Organic amplification:**
- How will the myth spread beyond controlled channels?
- What makes the myth REPEATABLE by others? (Simple, resonant, experientially verifiable)
- What makes it USEFUL to repeat? (Makes the repeater look insightful, connects them to a community)
- Design the myth to be a tool people WANT to use, not just a message they receive

### Step 5: Model Strategy

Design who will embody the myth through behavior (not endorsement):

**Primary model:**
- Who is the most visible, most credible person to model this myth?
- What specific behaviors demonstrate the myth as lived reality?
- How will these behaviors be VISIBLE to the target audience?
- The primary model doesn't SAY the myth — they LIVE it so obviously that others articulate it for them

**Secondary models:**
- Which customers, partners, or allies can model the myth?
- What behavior sequences would demonstrate the myth in their contexts?
- How can modeling be encouraged without making it feel staged?
- Customer success stories are modeling when the success CONFIRMS the myth

**Anti-models:**
- Who embodies the OPPOSITE of the myth? (The cautionary tale)
- How can anti-model behavior be made visible without direct attack?
- Anti-models are powerful because they make the myth feel necessary — "see what happens when you DON'T..."
- The anti-model should be a recognizable type, not a named individual (avoids backlash)

**Model reinforcement:**
- How will models be recognized, rewarded, and amplified?
- What makes modeling this myth STATUS-ENHANCING for the modeler? (Connects to Veblen)
- How does modeling create commitment that deepens the model's own belief? (Connects to Festinger)

### Step 6: Counter-Myth Defense

Anticipate and defend against inversion:

**Vulnerability audit:**
- What's the simplest, most devastating counter-myth a competitor could construct?
- Express it: "What people like [brand] don't want you to know is..."
- How much lived experience supports the counter-myth?
- How easily could the counter-myth recruit models?

**Defense through experience:**
- The strongest defense is buyer behavior that CONFIRMS the myth personally
- What behavior sequence can buyers perform that makes the myth feel self-evidently true?
- Once a buyer has personally verified a myth through their own experience, counter-myths feel like attacks on the buyer's own intelligence — they will defend the myth themselves

**Defense through community:**
- A myth held by a community is harder to invert than a myth held by individuals
- How does the community reinforce the myth through shared language, shared stories, shared identity?
- Community defense is automatic — members correct counter-myth exposure without being asked

**Defense through pre-emption:**
- Can the construction strategy INCLUDE acknowledgment of the counter-myth's partial truth?
- "Some people think [counter-myth]. They're not wrong that [partial truth]. But what they miss is [your myth]."
- Pre-emption inoculates — it makes the counter-myth feel like old news when the competitor finally deploys it

**Escalation plan:**
- If a counter-myth gains traction, what's the response?
- More models? More varied repetition? Direct inversion of the counter-myth?
- When to ignore (gives it oxygen) vs. when to respond (it's gaining real traction)?

### Step 7: Cross-Thinker Integration

Integrate myth construction with insights from the full thinker network:

**Girard (mimetic spread):**
- Which models will trigger mimetic desire for the myth?
- How does the myth spread through imitation chains?
- Where could mimetic rivalry undermine the myth? (Two models competing could fragment it)

**Bourdieu (field authority):**
- Whose cultural capital gives them myth-making authority in this field?
- What field position does the brand need to occupy for its myth to carry weight?
- How do dominant players maintain their myths through symbolic power?

**Festinger (behavior-belief loop):**
- What behavior sequence creates belief in the myth through dissonance reduction?
- How does public commitment to the myth deepen private belief?
- Where does the myth create productive dissonance with old beliefs?

**McCracken (meaning transfer):**
- How does cultural meaning flow from the constituted world through the myth into the product?
- What rituals (purchase, use, display, disposal) reinforce the myth?
- How does the myth connect to broader cultural categories and principles?

**Veblen (status dynamics):**
- Does believing the myth confer status? (Accelerates adoption)
- Does the myth challenge existing status hierarchies? (Creates resistance from status holders)
- How can myth adoption be made conspicuous without being obnoxious?

**McLuhan (media compatibility):**
- Which media environments naturalize the myth fastest?
- Is this a "hot" myth (complete, low participation) or "cool" myth (incomplete, audience fills in)?
- Cool myths may naturalize faster because the audience co-constructs them

**Thaler (framing and defaults):**
- How can the myth be embedded in choice architecture as a default assumption?
- What frames make the myth the "obvious" interpretation?
- How do mental accounting categories interact with the myth?

**Ariely (expectation effects):**
- How does the myth set expectations that change actual experience?
- Does believing the myth make the product ACTUALLY work better? (Placebo/expectation effect)
- How do price signals interact with the myth?

**Damasio (somatic naturalization):**
- How does the myth become a gut feeling rather than a thought?
- What somatic markers does the myth trigger?
- When the myth is fully naturalized, it should be felt in the body, not reasoned in the mind

**Loewenstein (curiosity and anticipation):**
- How does the myth create or resolve information gaps?
- Does the myth shape what people anticipate and therefore what they experience?
- How does the myth interact with hot-cold empathy gaps?

### Step 8: Myth Construction Strategy

Synthesize everything into a complete construction plan:

**Myth Construction Brief:**
- Core myth statement (what should feel obvious when naturalized)
- Truth being naturalized (the genuine material)
- Alternative being hidden (what becomes invisible)
- Experiential anchor (what buyers already know that confirms this)

**90-Day Implementation Roadmap:**
- Month 1: Myth seeding — primary model begins behavioral demonstration, initial varied repetition across 3-4 channels, community language introduction
- Month 2: Myth amplification — secondary models activated, repetition expanded to 6-8 channels, customer behavior sequences designed and deployed, first counter-myth defenses tested
- Month 3: Myth acceleration — organic amplification measured and encouraged, community reinforcement patterns established, model visibility increased, counter-myth pre-emption deployed

**6-Month Naturalization Timeline:**
- Months 1-3: Active construction phase (requires intentional, managed effort)
- Months 4-5: Transition phase (myth begins to repeat without direct effort, organic spread increases)
- Month 6: Naturalization assessment (is the myth being stated as common sense by non-models? Is it defended without prompting? Does it feel "obvious" to newcomers?)

**Measurement indicators:**
- Language adoption: Are buyers using myth-consistent language unprompted?
- Behavioral modeling: Are customers demonstrating the myth through behavior?
- Community defense: Do community members correct counter-myth exposure automatically?
- Newcomer assumption: Do new market entrants encounter the myth as "common sense"?
- Competitor response: Are competitors adjusting their positioning to account for the myth?

---

## OUTPUT STRUCTURE

### Myth Construction Strategy Report

**Section 1: Market Myth Landscape**
All active myths in the market decoded — what "everyone knows," who benefits, how deeply naturalized each myth is, and where vulnerabilities exist.

**Section 2: Myth Opportunity Analysis**
Classification of every existing myth as ally (align), enemy (invert), or neutral (ignore), plus vacuum opportunities where no dominant myth exists.

**Section 3: Core Myth Design**
The myth statement, the truth being naturalized, the alternative being hidden, the experiential anchor, and stress test results.

**Section 4: Repetition Architecture**
Complete repetition plan — channels, frequency, variation strategy, and organic amplification design.

**Section 5: Model Strategy**
Primary model, secondary models, anti-models, and model reinforcement plan — who embodies the myth, what behavior demonstrates it, and how behavior is made visible.

**Section 6: Counter-Myth Defense Plan**
Vulnerability audit, defense through experience, defense through community, pre-emption strategy, and escalation plan.

**Section 7: Cross-System Integration**
Integration with all 11 thinker systems — how each thinker's insights strengthen myth construction and where cross-system synergies create compounding effects.

**Section 8: Myth Construction Roadmap**
90-day implementation plan (seeding, amplification, acceleration) and 6-month naturalization timeline with measurement indicators.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Roland Barthes - Myth Construction Strategist/01 - Myth Construction Strategy - [System Name] - [Date].md`
