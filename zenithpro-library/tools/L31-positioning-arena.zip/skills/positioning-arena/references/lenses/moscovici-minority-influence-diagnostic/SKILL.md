---
name: moscovici-minority-influence-diagnostic
description: Full integrated diagnostic for contrarian copy — evaluates all three activation conditions (genuine conflict, consistency, confidence) plus behavioral style and conversion probability. The go/no-go assessment for minority influence copy architecture.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Serge Moscovici (Minority Influence and Conversion Theory) — Ideas 1 & 7"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/moscovici-minority-influence-diagnostic {copy-or-brief}"
  called_by: [user, moscovici-field-intelligence]
  outputs_to: [project-folder]
depends_on: [moscovici-genuine-conflict-validator, moscovici-consistency-confidence-auditor, moscovici-behavioral-style-auditor]
---

# Moscovici Minority Influence Diagnostic

---

## LAYER 1: INVARIANTS (Never override.)

1. **Three activation conditions, all required.** The minority influence mechanism fires if and only if three conditions are present: (1) GENUINE CONFLICT — the position is in real tension with what the majority currently believes; (2) CONSISTENCY — the position does not waver across the copy; (3) CONFIDENCE — the position is delivered without hedging. All three are threshold conditions. If any one is absent, the minority influence mechanism does not activate. A piece that fails one condition cannot compensate by over-delivering on the others.

2. **Conversion ≠ compliance — this distinction governs the entire diagnostic.** Minority influence produces PRIVATE attitude change (conversion): the prospect restructures their belief and becomes a durable, referring, generalizing buyer. Majority influence produces only PUBLIC compliance: the prospect agrees under social pressure but has not updated their private belief — they are a high-refund, low-LTV, non-referring buyer. The purpose of this diagnostic is to determine which type of buyer the copy is manufacturing. Never conflate conversion rate (purchase probability) with conversion in Moscovici's sense (private belief restructuring).

3. **The validation process is the mechanism — diagnose whether copy creates conditions for it.** When a consistent, confident minority claim triggers genuine conflict, prospects enter the validation process: they actively evaluate whether the minority is right, processing the argument deeply rather than comparing themselves to social norms. The diagnostic must assess whether the copy creates the conditions for validation: (a) genuine conflict to activate it, (b) processable argument for it to work on, (c) consistent source to sustain it, (d) confident delivery to prevent premature dismissal.

4. **Turner's in-group requirement is operative.** Per Turner (1991), in-group minority sources produce stronger conversion than out-group sources. The diagnostic must assess whether the copy positions the source as inside the reader's reference group or as an external critic. "I used to believe what you believe — here's what changed my mind" is in-group minority framing and activates stronger conversion. "You're all doing it wrong" is out-group framing and may produce defensiveness rather than validation.

5. **The delayed conversion effect is architecturally significant.** Wood et al. (1994) documented that minority influence often produces deferred attitude change — initial public resistance, with private conversion completing days or weeks later. This is the "sleeper" variant of conversion. The diagnostic must assess whether the copy is designed to capture delayed conversion (email sequence, multi-touch follow-up) or relies on single-shot immediate response. A contrarian lead in a single-shot piece may show artificially low immediate conversion rates while producing delayed conversion that is never attributed.

---

## LAYER 2: QUALITY GUIDANCE

6. **The diagnostic produces a go/no-go ruling plus a scored profile.** The primary output is binary: does this copy operate as minority influence (conversion-producing) or not (compliance-producing or dismissal-producing)? The scored profile identifies which conditions are met and which are failing — enabling precise targeted fixes rather than a general rewrite instruction.

7. **The involvement-modulation caveat.** Wood et al. (1994) found that minority influence effects are most robust in high-involvement, identity-relevant domains. In low-involvement topics (commodity purchases, low-stakes decisions), the conversion/compliance distinction may be undetectable. The diagnostic must note the involvement level of the topic and modulate confidence in predictions accordingly. For high-involvement categories (health, wealth, identity, business performance, relationships), the mechanism predictions are most reliable.

8. **Cross-frame the diagnosis with Kelman and Deutsch & Gerard.** This diagnostic is most valuable when placed in the Phase 3 context: Moscovici's conversion/compliance maps onto Kelman's internalization/compliance, and onto Deutsch & Gerard's informational/normative influence. A complete buyer-quality prediction requires all three frameworks. Flag where additional analysis from kelman-pathway-diagnostic or the deutsch-* bundle would add precision.

---

## PURPOSE

This skill is the integrated go/no-go assessment for minority influence copy architecture. It synthesizes the three prerequisite checks (genuine conflict, consistency, confidence) and the behavioral style audit into a single minority influence readiness score, with a clear verdict on whether the copy is likely to produce conversion (private belief change → high LTV buyers) or compliance (public agreement → low LTV buyers).

Run this skill when:
- Evaluating a contrarian lead for a new campaign
- Diagnosing why a contrarian piece is underperforming
- Making a go/no-go decision on minority-influence positioning for a launch

---

## INPUT REQUIREMENTS

Provide one of:
1. **The complete copy piece** — all elements from subject line through P.S.
2. **The copy brief** — intended minority claim, target market, source identity, proof structure, and offer framing

Also provide:
- **Target market involvement level:** How identity-relevant and high-stakes is this category for the reader? (HIGH / MODERATE / LOW)
- **Campaign architecture:** Single-shot direct response / Email sequence / Webinar funnel / Long-form VSL / Other

---

## EXECUTION PROCESS

### Step 1: Three Activation Conditions Assessment

**Condition 1 — Genuine Conflict**
Run moscovici-genuine-conflict-validator inline or inherit its output.

- Proposed minority claim: [extract or state]
- Majority norm being contested: [reconstruct]
- Conflict genuineness: GENUINE / STRAWMAN / LATENT CONSENSUS / EXPIRED
- Conflict quality: STRONG / ADEQUATE / WEAK

**Condition 2 — Consistency**
Run or inherit moscovici-consistency-confidence-auditor — consistency component.

- Core claim stated: YES / NO (if NO: critical finding — stop)
- Consistency across all elements: PASS / FAIL [note failures]
- Critical consistency failures: [list]

**Condition 3 — Confidence**
Run or inherit moscovici-consistency-confidence-auditor — confidence component.

- Hedge count: [N] total; [N] critical/high proximity
- Aggregate confidence: STRONG / MODERATE / WEAK

**Three-Condition Gate:**
- All three PASS/STRONG: MINORITY INFLUENCE MECHANISM ACTIVATABLE
- Any condition FAIL: MECHANISM DOES NOT ACTIVATE — [specify which condition and why]

### Step 2: Behavioral Style Profile (if gate passes)

Run or inherit moscovici-behavioral-style-auditor — abbreviated profile:

| Component | Score | Critical Finding |
|-----------|-------|-----------------|
| Consistency | PASS/FAIL | |
| Confidence | STRONG/MOD/WEAK | |
| Autonomy | STRONG/ADEQUATE/WEAK/ABSENT | |
| Investment | STRONG/ADEQUATE/WEAK/ABSENT | |
| Fairness | PRINCIPLED/ADEQUATE/STRAWMAN/DISMISSIVE/ABSENT | |

Behavioral style overall: COMPLETE / MINIMUM VIABLE / COMPROMISED / ABSENT

### Step 3: Validation Process Assessment

Assess whether the copy creates conditions for the validation process to complete:

**Activation trigger:** Does the copy generate genuine conflict strong enough to activate "what do they know that I don't?" response? (Requires GENUINE conflict + CONFIDENT delivery)

**Processability:** Is the minority argument processable? Can the reader evaluate its logic with the information provided? Or is the argument too obscure, too technical, or too remote from the reader's experience?
- FULLY PROCESSABLE / PARTIALLY PROCESSABLE / OBSCURED

**Resolution pathway:** Does the copy guide the reader to the correct validation conclusion — i.e., does it provide the evidence and reasoning needed for the reader to conclude "the minority is right"? Or does it assume the reader will validate on their own?
- GUIDED (copy walks reader to conclusion) / PARTIAL / UNGUIDED

**Validation process status:** COMPLETE CONDITIONS / PARTIAL CONDITIONS / INSUFFICIENT CONDITIONS

### Step 4: Turner In-Group Assessment

Assess the source's positioning relative to the reader's reference group:

- Is the source framed as inside the reader's world (shared experience, shared prior beliefs, shared failures)? IN-GROUP
- Is the source framed as an external authority or outsider critic? OUT-GROUP
- Is the source's journey from majority belief to minority position narrated? (This is the in-group conversion narrative — most powerful framing)

**In-group status:** STRONG IN-GROUP / ADEQUATE / WEAK / OUT-GROUP
**Implication for conversion probability:** [adjust up/down based on Turner findings]

### Step 5: Delayed Conversion Architecture Assessment

Assess whether the campaign is designed to capture delayed conversion:

- Is this a single-shot piece? If YES: delayed conversion is likely untracked. Flag this as an attribution risk — genuine minority-influence conversion may be occurring but not credited to this piece.
- Is there a follow-up sequence after the initial contact? If YES: assess whether the sequence reinforces the minority claim with maintained consistency (which captures delayed conversion) or pivots to normative social proof (which substitutes compliance-pressure for conversion).
- For email sequences specifically: does the sequence maintain the minority position through all messages, or does it shift to majority-influence tactics after the initial contact?

**Delayed conversion readiness:** OPTIMIZED (sequence maintains minority position) / ADEQUATE / RISK (single-shot or inconsistent sequence) / NOT APPLICABLE

### Step 6: Minority Influence Readiness Score

Score the copy across six dimensions:

| Dimension | Weight | Score (0–10) | Notes |
|-----------|--------|-------------|-------|
| Genuine conflict quality | 25% | | |
| Consistency (no waver) | 20% | | |
| Confidence (no hedge) | 20% | | |
| Behavioral style completeness | 15% | | |
| Validation process conditions | 10% | | |
| In-group positioning | 10% | | |

**Weighted overall score:** [calculate]

**Score interpretation:**
- 85–100: MINORITY INFLUENCE READY — copy is architected for conversion-producing buyer manufacturing
- 70–84: FUNCTIONAL — mechanism fires but conversion depth is limited; specific improvements will increase LTV
- 55–69: MARGINAL — some minority influence elements present but compliance mechanisms are competing; buyer quality is mixed
- Below 55: COMPLIANCE-MODE — copy is functioning as majority/normative influence regardless of contrarian surface framing; expect low-LTV buyers

### Step 7: Buyer Quality Prediction

Based on the diagnostic:

**Expected buyer type:**
- HIGH CONVERSION: Private belief restructuring likely → Low refund rate, high LTV, spontaneous referral, adjacent offer uptake
- MIXED: Some private conversion + significant compliance → Moderate quality, some refunds, limited generalization
- COMPLIANCE-DOMINANT: Primarily public agreement → Elevated refund risk, low LTV, minimal referral, adjacent offer resistance

**Involvement modulation:** At [HIGH/MODERATE/LOW] involvement, the conversion-compliance distinction is [strong/moderate/weak] predictor of buyer behavior.

**Delayed conversion note:** [If applicable — are there conversion completions likely happening 2–14 days after initial exposure?]

---

## OUTPUT STRUCTURE

### Minority Influence Diagnostic Report

**Header:**
- Copy analyzed: [title or description]
- Campaign type: [single-shot / sequence / funnel]
- Involvement level: [HIGH / MODERATE / LOW]
- Date: [YYYY-MM-DD]

**Section 1: Three-Condition Gate**
Each condition scored with evidence. PASS or FAIL verdict.

**Section 2: Behavioral Style Profile**
Five-component table with scores and critical findings.

**Section 3: Validation Process Assessment**
Activation trigger, processability, resolution pathway — and overall validation process status.

**Section 4: In-Group Positioning**
Turner assessment with specific textual evidence.

**Section 5: Minority Influence Readiness Score**
Six-dimension weighted scorecard with overall score and interpretation.

**Section 6: Buyer Quality Prediction**
Expected buyer type, LTV implications, delayed conversion note.

**Section 7: Priority Interventions**

Ranked from highest to lowest impact on minority influence activation:

1. **[Intervention]:** [specific fix — quote target text, provide rewrite]
   Expected impact: [which score dimension improves and by how much]

2–5. [same format]

**Cross-Frame Note:**
For complete buyer quality architecture, cross-reference:
- kelman-pathway-diagnostic — maps this piece's influence mechanism to Kelman's compliance/identification/internalization
- deutsch-* bundle — positions this piece in the normative/informational influence spectrum

---

## CROSS-REFERENCES

- **Kelman:** Moscovici's conversion = Kelman's internalization. Both describe private, durable belief change as the highest-quality influence outcome. Moscovici specifies source conditions (minority position, behavioral style) for producing internalization; Kelman specifies content conditions (value-consistent, credible source framing). Together they form the complete conversion architecture.
- **Deutsch & Gerard:** Moscovici's validation process = Deutsch & Gerard's informational influence. The minority provides new information that genuinely updates belief, as opposed to normative compliance which merely aligns behavior with group norms. The Moscovici addition: source status (minority vs. majority) is an independent trigger for informational vs. normative processing — not just argument quality.
- **Wood et al. 1994:** Empirical anchor. 143 studies, N=5,990 confirm: minority sources produce stronger private (indirect) attitude change; majority sources produce stronger public (direct) attitude change. Effect most robust in high-involvement domains.
- **Turner 1991:** In-group minority status amplifies conversion. Out-group status risks dismissal. Source must be positioned as inside the reader's reference group for maximum mechanism activation.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Serge Moscovici - Minority Influence Diagnostic/[YYYY-MM-DD] - Minority Influence Diagnostic - [Copy Name].md`
