---
name: knowles-four-faces-diagnostic
description: Identifies the dominant resistance face(s) in a prospect segment — reactance, distrust, scrutiny, or inertia — using behavioral and language signatures, then outputs a ranked face profile and omega-tactic recommendation.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Eric Knowles & Jay Linn (Approach-Avoidance Persuasion / Omega Strategies) — Idea 2"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/knowles-four-faces-diagnostic {audience-segment or copy-brief}"
  called_by: [user, knowles-field-intelligence]
  outputs_to: [project-folder]
depends_on: [knowles-approach-avoidance-audit]
---

# Knowles Four-Faces Diagnostic

---

## LAYER 1: INVARIANTS (Never override.)

1. **The four faces are not mutually exclusive.** A prospect carries multiple faces simultaneously — primary face plus one or more secondary faces is the norm, not the exception. This diagnostic must output a ranked face profile, not a single-face verdict. A profile that shows only one face is almost certainly an incomplete diagnosis. Mixed-face profiles are standard; the skill must accommodate them.

2. **The diagnostic is observational, not theoretical.** Which face is dominant cannot be derived from the offer or audience description alone. It requires evidence from what the prospects actually say — forum posts, reviews, sales call objections, customer interview transcripts, email replies, or refusal language. Theoretical derivation without behavioral evidence is speculation. Label evidence type for every face assignment.

3. **Wrong face, wrong tactic.** Applying an omega tactic designed for the wrong resistance face is worse than no omega intervention. Acknowledgment language designed for distrust activates reactance in a reactance-dominant audience because it reads as a sales script. Distraction tactics designed for scrutiny increase reactance by reducing felt autonomy. The diagnostic is load-bearing for all downstream omega work.

4. **The predictive hierarchy is unspecified.** Knowles & Linn explicitly do not provide a rule for which face will dominate in which context. This skill is a diagnostic tool that reads observable signals — it does not claim to predict face dominance from theoretical first principles. Face assignments are based on the behavioral evidence available.

5. **Absence of evidence is not evidence of absence.** If no behavioral data is available for a given face, report it as UNKNOWN, not as LOW. An unknown distrust-face rating is a gap that should be filled, not a clean bill of health.

---

## LAYER 2: QUALITY GUIDANCE

6. **Signature language is the primary evidence type.** Each resistance face produces characteristic language in the market. Reactance: "they're trying to push me into something," "felt pressured," "hard sell." Distrust: "sounds too good to be true," "what's the catch," "just trying to take my money." Scrutiny: specific technical objections, "how exactly does X work," "I've tried [similar thing] and it didn't work because..." Inertia: "I'll look into it later," "been meaning to," "sounds interesting," no response at all. Search for this language in VOC data before running the diagnostic.

7. **Category history shapes face dominance.** Markets that have been repeatedly burned by bad offers in a category develop strong distrust-face patterns across the segment. Markets with sophisticated buyers (high NFC) develop strong scrutiny-face patterns. Markets with high urgency and pushy marketing develop reactance-face patterns. Category history is a fast proxy for face-profile prediction when behavioral data is thin.

8. **The face profile changes over time.** A cold prospect segment may be inertia-dominant (they haven't thought much about the offer category). A warm prospect who has seen your funnel three times may be reactance-dominant (they feel pursued). The diagnostic must specify the awareness stage it applies to.

---

## PURPOSE

> "Resistance to persuasion takes at least four distinct forms. Reactance is resistance based on threatened freedom. Distrust is resistance based on questions about the persuader's motives. Scrutiny is resistance based on careful examination of the evidence. Inertia is resistance based on the comfort of the current position and the effort required to change." — Knowles & Linn, 2004, *Resistance and Persuasion*, pp. 6–8

Not all resistance is the same thing. A prospect who feels pushed around (reactance) needs a different intervention than a prospect who thinks you're lying to them (distrust), or one who is carefully evaluating your claims (scrutiny), or one who simply can't be bothered to act (inertia). Applying the wrong omega tactic to the wrong face not only fails — it amplifies the resistance it was meant to reduce.

This diagnostic identifies which resistance face(s) are active in a given prospect segment and outputs a ranked face profile with evidence-grounded tactic recommendations for `knowles-omega-tactics-library`.

---

## INPUT REQUIREMENTS

Provide one or more of the following:
1. **VOC data** — forum excerpts, review text, customer interview transcripts, sales call objection logs, email reply text
2. **Campaign history** — what has been tried, what resistance showed up, specific refusal language or drop-off patterns
3. **Audience segment profile** — demographics, sophistication level, category experience, awareness stage
4. **Copy brief** — offer type, price point, funnel structure (certain offer structures reliably trigger certain faces)

The diagnostic quality is proportional to the specificity of behavioral evidence provided. A brief with no VOC data will produce a lower-confidence face profile.

---

## EXECUTION PROCESS

### Step 1: Evidence Inventory
List all behavioral evidence available. For each evidence item, note:
- Source type (forum, review, sales call, email, etc.)
- Verbatim language (where available)
- Preliminary face signal (which face this language suggests)

### Step 2: Face-by-Face Assessment

Evaluate each face independently against the evidence.

---

**Face 1 — Reactance**

Definition: Resistance based on threatened perceived freedom of behavior. The prospect feels pushed, controlled, or that options are being closed off. The motivational response is to move away from the advocated position to restore freedom.

Behavioral signatures:
- "Felt pressured," "hard sell," "wouldn't let me leave"
- Abandonment at CTAs with strong command language
- Negative response to countdown timers
- "They really want you to buy this" — awareness of persuasion intent as a threat
- Complaints about follow-up frequency or persistence

Structural triggers in copy/funnels:
- Command-form CTAs without exit option ("MUST-have," "You need to do this NOW")
- Countdown timers without genuine scarcity
- Urgency language that closes alternatives
- Retargeting or follow-up sequences that feel relentless

Omega remedies: Autonomy acknowledgment, take-away sell, defusion via explicit choice restoration, soft close, "this may not be for you" language, removing/softening deadline pressure, offering the opt-out explicitly.

Evidence rating: STRONG / MODERATE / WEAK / UNKNOWN
Evidence summary: [verbatim quotes and sources]

---

**Face 2 — Distrust**

Definition: Resistance based on perceived misalignment between the persuader's motives and the prospect's interests. The prospect believes the persuader is trying to benefit at the prospect's expense. This is skepticism about character, not about evidence.

Behavioral signatures:
- "Sounds too good to be true," "what's the catch"
- "These guys just want your money"
- Skepticism about testimonials ("those are fake"), guarantees ("fine print kills you")
- Comparisons to previous disappointments in the category
- Questions about business model ("how do they make money if...")

Structural triggers in copy/funnels:
- Excessive hyperbole or superlatives
- Implausible claims without specific mechanism
- Aggressive salesmanship signals (pushy, high-energy, lots of exclamation marks)
- Guarantees with visible loopholes
- Celebrity or paid endorsements in a market that has seen too many

Omega remedies: Acknowledgment of persuasion context, two-sided messaging (Hovland), agnostic proof, confessing a limitation in the offer, naming what this is NOT right for, "reason why" transparency about persuader motivation.

Cross-reference: Brehm's foundational reactance work maps to this face's edges; Hovland's credibility research (source credibility, sleeper effect) is the upstream theory for distrust-face interventions; Friestad & Wright's Persuasion Knowledge Model operationalizes why distrust becomes systematic over time.

Evidence rating: STRONG / MODERATE / WEAK / UNKNOWN
Evidence summary: [verbatim quotes and sources]

---

**Face 3 — Scrutiny**

Definition: Resistance based on active, effortful evaluation of the persuasive message. The prospect is counterarguing — generating objections, testing claims, looking for contradictions. This is analytical engagement, not distrust of motives.

Behavioral signatures:
- Specific technical objections ("but does it work for [niche condition]?")
- Claims verification attempts ("I looked this up and...")
- Price comparison behavior ("I found similar things for...")
- Inconsistency detection ("you said X here but Y there")
- Long deliberation cycles, multiple touches before decision

Structural triggers in copy/funnels:
- Technical claims the prospect has expertise to evaluate
- Specific numbers that invite verification
- High-NFC (Need for Cognition) audience segments
- Price points that invite research
- Inconsistencies in proof across touchpoints

Omega remedies: Inoculation (preempt the objection before the prospect raises it — McGuire's inoculation theory is the strongest academic intervention for this face), narrative over argument (story bypasses systematic scrutiny via narrative transportation), social proof that shifts evaluation to others' judgments, distraction (embed cognitive load that occupies the counterarguing faculty).

Cross-reference: McGuire's inoculation theory is the highest-evidence intervention for scrutiny-face resistance. Petty & Cacioppo's ELM maps directly to this face — scrutiny is high-elaboration processing. For scrutiny-dominant audiences, the ELM prescriptions apply.

Evidence rating: STRONG / MODERATE / WEAK / UNKNOWN
Evidence summary: [verbatim quotes and sources]

---

**Face 4 — Inertia**

Definition: Resistance based not on psychological reactance, distrust, or counterarguing, but on the sheer effort required to change the current state. The prospect is not opposed — they are simply not moving.

Behavioral signatures:
- "I'll look into it later," "I've been meaning to"
- High open rates, low click rates
- Engagement without conversion (reads everything, buys nothing)
- "Sounds interesting" without action
- Long-dormant leads who resurface with "I keep meaning to do this"

Structural triggers in copy/funnels:
- Low personal urgency for the prospect (problem exists but doesn't hurt enough yet)
- Complex enrollment processes
- Unclear first step
- No triggering event that makes NOW different from later
- Passive audience being asked to make an active change

Omega remedies: Reduce friction to near-zero (make the first action trivially easy), increase salience of the cost of inertia ("here's what staying where you are costs you in 12 months"), create a triggering event, bold single-step CTA with minimal cognitive load, default opt-in structures where feasible.

Evidence rating: STRONG / MODERATE / WEAK / UNKNOWN
Evidence summary: [verbatim quotes and sources]

---

### Step 3: Face Profile Ranking
Rank all four faces from most to least dominant for this specific audience segment at this specific funnel stage.

Format:
1. [Primary face] — STRONG/MODERATE/WEAK — [1-sentence rationale]
2. [Secondary face] — STRONG/MODERATE/WEAK — [1-sentence rationale]
3. [Tertiary face] — STRONG/MODERATE/WEAK — [1-sentence rationale]
4. [Quaternary face] — STRONG/MODERATE/WEAK — [1-sentence rationale]

Overall confidence in this profile: HIGH / MEDIUM / LOW — [based on quality of available behavioral evidence]

### Step 4: Tactic Recommendation Handoff
For the primary face and any secondary face rated MODERATE or higher, identify the omega tactic category that applies and flag for `knowles-omega-tactics-library`:

- Reactance-dominant → Take-away sell, autonomy acknowledgment, defusion
- Distrust-dominant → Acknowledgment, two-sided messaging, transparency tactics
- Scrutiny-dominant → Inoculation, narrative transportation, objection preemption
- Inertia-dominant → Friction reduction, cost-of-inertia calculation, triggering event creation
- Mixed-face profile → Note tactic compatibility constraints (some omega tactics amplify secondary faces)

---

## OUTPUT FILE

Save complete diagnostic to:
`[project-folder]/Knowles & Linn - Four-Faces Diagnostic/[Audience Segment] - Face Profile - [Date].md`

### Output Structure

**Header:**
- Date: [YYYY-MM-DD]
- Audience segment: [Name/description]
- Funnel stage / awareness level: [Cold / Warm / Hot]
- Evidence quality: [HIGH / MEDIUM / LOW — based on VOC data availability]

**Section 1: Evidence Inventory**
All behavioral evidence with source type and face signal.

**Section 2: Face-by-Face Assessment**
All four faces assessed per the framework above with evidence ratings.

**Section 3: Ranked Face Profile**
Primary through quaternary ranking with confidence level.

**Section 4: Tactic Recommendation Handoff**
Omega tactic categories flagged per dominant faces. Tactic compatibility notes for mixed-face profiles. Handoff spec for `knowles-omega-tactics-library`.
