---
name: lakoff-metaphor-engineer
description: Constructs optimal conceptual metaphors for copy — given a target domain and desired inference package, selects the source domain whose entailments most precisely support the persuasive goal.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "George Lakoff & Mark Johnson (Conceptual Metaphor Theory + Image Schemas) — Idea 2"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/lakoff-metaphor-engineer {target-domain} {desired-inference-package} {emotional-register}"
  called_by: [user, lakoff-field-intelligence, copywriting-arena]
  outputs_to: [client-output-folder]
depends_on: [lakoff-metaphor-auditor]
---

# Lakoff Metaphor Engineer

---

## LAYER 1: INVARIANTS (Never override.)

1. **Source domain selection is logical construction, not style choice.** Every source domain imports a specific inference package. The engineer's job is to identify the inference package the offer NEEDS, then find the source domain whose entailment structure most precisely delivers it. "Which metaphor sounds best?" is the wrong question. "Which source domain imports the exact inferences this offer requires?" is the right question.

2. **Enumerate candidate source domains before selecting.** Never propose a single metaphor as the obvious choice. Always generate 5–8 candidate source domains, map their entailments, and select with explicit reasoning. The best source domain is rarely the first one that comes to mind — it is often the third or fourth after deliberate enumeration.

3. **Run highlighting/hiding analysis on every candidate.** Every source domain highlights some aspects of the target domain and hides others. Verify that the highlighted aspects are the ones the offer needs to be salient. Verify that the hidden aspects are ones the offer is comfortable suppressing. A source domain that hides an inconvenient truth AND highlights the desired inference = an acceptable tradeoff that must be named. A source domain that highlights a liability = rejected.

4. **Primary metaphors earn priority over complex ones for mass-market copy.** Primary metaphors (directly grounded in universal sensorimotor experience: weight, containment, vertical orientation, physical force, warmth, movement toward destination) activate more reliably across culturally diverse audiences than complex compound metaphors. When the offer is mass-market, default to source domains that recruit primary metaphors. Note when a proposed complex metaphor may require cultural calibration.

5. **Produce complete mapping specifications, not just metaphor names.** The deliverable is not "use a journey metaphor." The deliverable is: the full source→target entity correspondence table, the top 5 entailments produced, the specific copy expressions that deploy the metaphor correctly, and the expressions that would misfire by activating competing entailments.

---

## LAYER 2: QUALITY GUIDANCE

6. **The deliberate metaphor is more powerful than the incidental one.** Explicitly foregrounding the metaphor ("Think of your business as a machine...") activates the full entailment structure. Passively deploying metaphorical language ("fix your process") activates only partial structure. When maximum entailment impact is the goal, the engineer should construct expressions that foreground the mapping deliberately.

7. **Name the metaphor you are deliberately NOT choosing.** For the two highest-ranked alternatives that didn't win, document why: what entailments they carry that the winning source domain avoids, or what they hide that the winning source domain keeps visible. This makes the selection logic explicit and prevents the copywriter from reverting to a familiar-but-wrong choice.

8. **Multi-schema source domains are more powerful.** Source domains that activate multiple image schemas simultaneously (e.g., JOURNEY activates SOURCE-PATH-GOAL + VERTICALITY through "climbing toward your goal" + FORCE through "momentum") produce stronger inference packages than single-schema sources. When two candidate source domains have similar entailments, prefer the one that activates more image schemas.

---

## PURPOSE

The auditor diagnoses. This skill builds. Given a target domain (what you need copy to explain or frame), a desired inference package (what you need the prospect to conclude), and an emotional register (the visceral state you need to activate), this skill constructs the optimal source domain mapping by running systematic entailment analysis across a field of candidates.

This produces something most copy review cannot: a logically justified metaphor choice with explicit mapping documentation — not a style preference but an inference engineering decision.

---

## INPUT REQUIREMENTS

Provide:
1. **Target domain** — the abstract concept to frame. Examples: "the prospect's current situation," "our transformation process," "the competition," "the offer itself," "the mechanism," "the risk of inaction."
2. **Desired inference package** — what you want the prospect to conclude about this domain. Be specific. Examples: "the prospect should conclude that their situation is externally caused (not their fault) and that an identifiable blockage exists that can be removed"; "the prospect should conclude that our process is precise and predictable, not experimental"; "the prospect should feel that they are behind on a race they can still win."
3. **Emotional register** — the visceral state to activate. Options: aversion/escape (prospect wants out of something), aspiration/movement (prospect wants toward something), urgency/momentum (action is time-sensitive), trust/stability (confidence in the provider).

Optionally provide:
- **Avatar profile** — cultural context, sophistication level, industry, prior exposure to similar metaphors
- **Copy section** — which section of the funnel this metaphor is being built for (problem agitation, mechanism reveal, offer, CTA)
- **Constraints** — any source domains to avoid (competitor has locked one up, cultural sensitivity, avatar would find it condescending)

---

## ENGINEERING PROCESS

### Step 1: Clarify the Inference Package

Before generating candidates, restate the desired inference package as a precise list of propositions:

**Required entailments (must be produced by the winning metaphor):**
1. [Entailment A — the prospect must be able to infer X]
2. [Entailment B]
3. [Entailment C]

**Forbidden entailments (must NOT be imported by winning metaphor):**
1. [Entailment X — if prospect infers this, it undermines the offer]
2. [Entailment Y]

**Hidden aspects (acceptable to suppress):**
1. [Aspect of the target domain the offer is comfortable not foregrounding]

---

### Step 2: Generate Candidate Source Domains (5–8 minimum)

For each candidate, produce a rapid entailment sketch (5 top entailments in bullet form). This is the initial filter — eliminating obviously wrong candidates before full mapping.

**Candidate [N]: [SOURCE DOMAIN NAME]**
- Top entailments: [5 bullets]
- Quick verdict: KEEP / ELIMINATE + one-sentence reason

---

### Step 3: Full Mapping Specification (Top 3 Candidates)

For the top 3 candidates after the initial filter, build complete mappings:

**CANDIDATE [N]: TARGET IS SOURCE**

**Entity correspondence table:**

| Source Domain Entity | Target Domain Entity |
|---------------------|---------------------|
| [entity in source] | [corresponding entity in target] |
| [e.g., broken component] | [e.g., the specific behavior blocking results] |

**Entailments produced (full list):**
1. [Entailment + whether it is REQUIRED, NEUTRAL, or FORBIDDEN]
2. ...

**Highlighting/hiding analysis:**
- Highlighted aspects of target: [what becomes salient when this source is active]
- Hidden aspects of target: [what gets suppressed — is suppression acceptable?]

**Image schemas activated:** [CONTAINMENT / SOURCE-PATH-GOAL / VERTICALITY / FORCE / BALANCE / LINK]

**Primary vs. complex assessment:** Does this source domain recruit primary metaphors (universally grounded) or complex compound metaphors (potentially culturally variable)?

**Deliberate activation expressions:** [3–5 specific copy expressions that foreground the mapping]
**Incidental activation expressions:** [2–3 expressions that quietly activate the mapping without foregrounding it]
**Expressions to avoid:** [specific phrasings that would activate a competing entailment]

---

### Step 4: Selection and Recommendation

**WINNING SOURCE DOMAIN: [name]**

**Selection reasoning:**
- Produces required entailments: [list which required entailments it delivers]
- Avoids forbidden entailments: [confirm none of the forbidden entailments are present]
- Hidden aspects: [confirm suppressed aspects are acceptable trade-offs]
- Image schema count: [how many image schemas activated]
- Primary metaphor grounding: [yes/no — is it universally grounded?]

**Why [Runner-up A] was rejected:**
[Specific entailment(s) it imports that the winning metaphor avoids, OR specific required entailment it fails to deliver]

**Why [Runner-up B] was rejected:**
[Same analysis]

---

### Step 5: Copy Deployment Package

**Headline expressions using winning metaphor (3 options):**
1. [headline]
2. [headline]
3. [headline]

**Problem agitation expression (2 options):**
1. [copy block — 2–4 sentences deploying the metaphor with full entailment activation]
2. [alternative]

**Offer positioning expression (2 options):**
1. [copy block — positions the offer using the winning source domain]
2. [alternative]

**CTA expression (2 options):**
1. [CTA line]
2. [CTA line]

**Deliberate foreground activation (1 option):**
[A full paragraph that explicitly invokes the metaphor for maximum entailment activation — "Think of your situation as..."]

---

## REFERENCE: Source Domain Libraries by Emotional Register

### Aversion/Escape Register (prospect wants OUT of something)
Preferred source domains: CONTAINMENT (trapped, imprisoned, bounded), FORCE/BLOCKAGE (something holding back, blocked movement), WEIGHT/BURDEN (heavy, dragging down), DISEASE (infected, contaminating, spreading)

### Aspiration/Movement Register (prospect wants TOWARD something)
Preferred source domains: JOURNEY (path, destination, milestones), BUILDING/CONSTRUCTION (foundation, structure, blueprint), GROWING ORGANISM (seeds, roots, cultivation), RACE (track, pace, competitors, arrival)

### Urgency/Momentum Register (time-sensitive action)
Preferred source domains: FORCE/MOMENTUM (moving, accelerating, velocity), DECAY (deteriorating, eroding, time running out), COMPETITION AS RACE (gap closing, falling behind, window closing), TIDE/FLOW (timing with the current, missing the wave)

### Trust/Stability Register (confidence in provider)
Preferred source domains: BUILDING/ARCHITECTURE (solid foundation, structural integrity), NAVIGATION (proven route, experienced guide, accurate map), PRECISION CRAFT (blueprint, engineering, calibrated), MEDICINE (diagnosis, treatment protocol, tested intervention)

---

## OUTPUT FILE

Save complete engineering report to:
`[project-folder]/Lakoff & Johnson - Metaphor Engineering/[Date] - Metaphor Build - [Target Domain] - [Copy Project].md`
