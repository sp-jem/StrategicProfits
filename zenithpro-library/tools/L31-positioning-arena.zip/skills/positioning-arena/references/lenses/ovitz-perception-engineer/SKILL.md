---
name: ovitz-perception-engineer
description: Design selective visibility strategy — what to reveal, what to withhold, how mystique compounds value. Use when over-exposed or under-mystified.
version: 1.0.0
author: Strategic Profits / Hollywood Agents & Dealmakers Series
source_thinker: "Michael Ovitz (Asset Packaging & Perception Management)"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/ovitz-perception-engineer {person-or-brand-description}"
  called_by: [user, ovitz-field-intelligence]
  outputs_to: [client-output-folder]
---

# Ovitz Perception Engineer

---

## LAYER 1: INVARIANTS (Never override.)

1. **Mystique is ten times better than publicity.** This is Ovitz's core perception principle. Visibility is not inherently valuable. Strategic invisibility --- being known for results while the process remains opaque --- creates more perceived power than any amount of public exposure. Every recommendation must be tested against this principle.

2. **What you withhold defines you more than what you reveal.** Ovitz was famous for what people DIDN'T know about CAA. The mystery of how deals were made, who was being recruited, what projects were in development --- this opacity created a gravitational pull that publicity would have dissipated. The skill must identify what the client should STOP revealing.

3. **The Spartan Principle: the firm is the brand, not individuals.** Ovitz deliberately suppressed individual agent profiles at CAA. No one agent became famous --- CAA as an institution was the brand. This prevented talent raiding and client poaching. The analysis must assess whether the client's brand is too dependent on individual visibility.

4. **Let results create the narrative.** Ovitz didn't explain CAA's strategy to the press. He let the deal announcements, the client roster, and the revenue numbers speak. When your results are visible but your methods are invisible, observers construct a more impressive narrative than you could create through PR. The strategy must specify which results to make visible and which methods to keep dark.

5. **Access is a currency that depreciates with overuse.** Every interview, every behind-the-scenes peek, every "how we did it" article spends mystique. Once spent, it can't be recovered. The perception strategy must include an explicit access budget --- how much visibility to spend and on what.

---

## LAYER 2: QUALITY GUIDANCE

6. **Distinguish between mystique and obscurity.** Mystique requires that people KNOW you exist and KNOW you're powerful --- they just don't know HOW. Obscurity means nobody knows you exist. If the client is obscure, they need visibility first. If they're visible but undifferentiated, they need mystique.

7. **Strategic leaks are more powerful than press releases.** Ovitz's power moves often "leaked" to the press rather than being announced. A leak creates the impression of insider access and suggests there's more beneath the surface. Design controlled leak strategies, not announcement strategies.

8. **Consistency compounds mystique; inconsistency destroys it.** One off-brand interview, one too-candid moment, one behind-the-scenes reveal can destroy years of mystique building. The strategy must include guardrails for what NEVER gets revealed.

---

## PURPOSE

Designs a complete perception management strategy based on Ovitz's proven methodology of strategic opacity. Maps what the client currently reveals vs. withholds, identifies where over-exposure is reducing perceived power, and designs a selective visibility strategy that maximizes mystique. The goal is not fame or publicity --- it's the specific perception of power, competence, and inevitability that comes from visible results combined with invisible methods.

**Why this matters for business owners:** The default advice in business is "be more visible" --- more content, more interviews, more transparency. Ovitz proved the opposite: strategic invisibility creates more perceived value than maximum visibility. When everyone shares everything, the person who maintains mystique stands out. This skill designs that mystique architecture.

---

## EXECUTION PROCESS

### Step 1: Current Visibility Audit

Map everything the client currently makes visible:

| Category | Currently Visible | Impact on Mystique |
|----------|------------------|-------------------|
| Methods/Process | What's shared about how you work | Depletes / Neutral / Builds |
| Results/Outcomes | What successes are visible | Depletes / Neutral / Builds |
| Internal Operations | What's known about inside the org | Depletes / Neutral / Builds |
| Personal Brand | How much individual visibility exists | Depletes / Neutral / Builds |
| Client/Customer Info | What's shared about who you serve | Depletes / Neutral / Builds |
| Strategy/Thinking | How much of the playbook is public | Depletes / Neutral / Builds |
| Pricing/Economics | What's known about your financials | Depletes / Neutral / Builds |

**Current mystique score:** Rate 1-10 (1 = fully transparent, no mystique; 10 = deeply mysterious, high mystique)

### Step 2: The Ovitz Inventory

Classify all client information into three categories:

**ALWAYS VISIBLE (Results that speak for themselves):**
- Outcomes and successes
- Client/customer wins (with permission)
- Scale indicators (without specific numbers)
- Quality signals (awards, recognition, demand)

**NEVER VISIBLE (Methods that power the mystique):**
- Internal processes and playbooks
- Decision-making frameworks
- Pricing logic and margin structures
- Recruitment and talent strategies
- Competitive intelligence methods

**STRATEGIC LEAK CANDIDATES (Controlled information releases):**
- Selected project details that create narrative
- Carefully timed announcements
- Partial reveals that increase curiosity
- "Accidentally" visible signals of power

### Step 3: The Spartan Assessment

Evaluate whether the brand is too dependent on individual visibility:

| Dimension | Individual-Dependent | Institution-Strong |
|-----------|--------------------|--------------------|
| Who does the market associate with the brand? | One person | The organization |
| What happens if the leader goes quiet for 3 months? | Brand fades | Brand persists |
| Can competitors recruit the brand's power away? | Yes, by hiring key people | No, the institution holds |
| Where is the mystique located? | In a person | In the organization |

**Recommendation:** Shift toward institutional brand / Maintain individual brand / Hybrid approach

### Step 4: Perception Strategy Design

**A. The Access Budget**
- Total visibility "spend" per quarter: [X interviews, Y posts, Z appearances]
- Each visibility event must be justified by what it accomplishes
- Anything not in the budget requires explicit approval

**B. The Leak Strategy**
- What to "leak" and when (controlled information releases)
- Who the leaks go through (trusted intermediaries)
- What narrative each leak is designed to create

**C. The Dark Zone**
- What is permanently off-limits for visibility
- Who enforces the boundaries
- What to say when pressed for information in the dark zone

**D. The Results Amplification Plan**
- Which results to make visible and how
- Let outcomes speak, never explain the method
- Design "discovery moments" where the market notices results organically

### Step 5: The Mystique Calendar

Design a 90-day perception management calendar:
- Week-by-week: what gets revealed, what stays dark, what gets leaked
- Each event tagged with its purpose (build mystique / signal power / create curiosity / maintain darkness)
- Explicit guardrails for what NEVER happens

---

## OUTPUT STRUCTURE

### The Perception Engineering Report

**Section 1: Current Visibility Assessment**
- What's currently visible and its impact on mystique
- Current mystique score with justification
- Over-exposure areas identified

**Section 2: The Ovitz Inventory**
- Three-category classification of all client information
- Always Visible / Never Visible / Strategic Leak Candidates
- Specific recommendations for what to STOP revealing

**Section 3: Spartan Assessment**
- Individual vs. institutional brand dependency
- Recommendations for rebalancing

**Section 4: Perception Strategy**
- Access budget for next quarter
- Leak strategy with specific items and timing
- Dark zone definition
- Results amplification plan

**Section 5: The First Perception Move**
- Single highest-impact change to make this week
- Usually: something to STOP doing (stop sharing, stop posting, stop explaining)
- What the market will notice and when

---

## SAVE LOCATION
Save output to: `Active-Brain/00 Projects/01 Behavioral Intelligence/Hollywood Agents/Category 2 - The Deal Architects/Michael Ovitz/Perception Engineer/`
Filename: `XX - Perception Engineering Report - [Client/Brand] - [Date].md`
