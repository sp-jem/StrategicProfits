---
name: tajfel-social-identity-activator
description: Audits whether copy has activated social identity across all three components (cognitive, evaluative, emotional). Entry-point diagnostic for the full tajfel-* bundle.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Henri Tajfel & John Turner (Social Identity Theory, Self-Categorization Theory) + Marilynn Brewer (Optimal Distinctiveness) — Idea 1"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/tajfel-social-identity-activator {copy-to-audit}"
  called_by: [user, tajfel-field-intelligence]
  outputs_to: [client-output-folder]
depends_on: []
---

# Tajfel Social Identity Activator

---

## LAYER 1: INVARIANTS (Never override.)

1. **Three-component completeness is mandatory.** Social identity has three components: cognitive (knowing you belong), evaluative (attaching value to that membership), and emotional (feeling its significance). A piece of copy that only achieves one or two components has partial activation — not full activation. Never call activation complete unless all three are present.

2. **Social categorization is the ignition — not the destination.** Naming a group label ("entrepreneurs," "serious operators") triggers social categorization but does not complete social identity activation. Categorization is the spark; evaluative differentiation (the group compares favorably) and emotional significance (membership matters) are the engine and fuel. Categorization without the other two produces recognition without identity pull.

3. **The positive distinctiveness drive requires a comparison reference.** Social identity theory (Tajfel & Turner, 1979) specifies that self-concept derived from group membership depends on favorable comparison to relevant out-groups. An in-group named without any comparative reference — implicit or explicit — cannot fully activate the evaluative component. Flag all cases where an in-group is named but no out-group signal exists.

4. **"Social identification" in this framework means categorical, person-to-group.** This is distinct from Kelman's "identification" (person-to-source, dyadic). When analyzing copy, do not conflate the two. A prospect who trusts and emulates a founder is engaging Kelman's identification pathway. A prospect who sees themselves as a member of a category is engaging Tajfel's social identity. Both can be present; they must be diagnosed separately.

5. **Minimal group findings apply.** Tajfel et al. (1971) demonstrated that categorization alone — even on arbitrary criteria — produces in-group favoritism. This means the threshold for triggering group-level processing in copy is lower than intuition suggests. A clear, well-named category with even slight positive valence will activate the mechanism. The question is not whether it can activate but whether the activation is strong enough to drive behavior.

---

## LAYER 2: QUALITY GUIDANCE

6. **Weak activation is diagnosable.** The most common failure mode is a copy that names a group (cognitive component present) but fails to establish comparative superiority (evaluative component missing) or fails to create emotional stakes for belonging (emotional component missing). Name the specific missing component rather than rendering a general "weak identity" verdict.

7. **Over-broad categorization kills emotional significance.** "Business owners" as a category activates categorization but has near-zero emotional significance — it includes too many contradictory reference points. "Operators doing $1M–$10M who build quietly" is narrow enough to carry emotional charge. Diagnose over-breadth as a specific failure mode: the category is cognitively present but emotionally inert.

8. **The accentuation effect is a gift the copy either uses or wastes.** Once categorization fires, perception automatically amplifies within-group similarity and between-group difference beyond objective warrant. Copy that sharpens category language benefits from this amplification for free. Copy that blurs category edges (trying to be inclusive) fights against this mechanism and loses ground it didn't have to lose.

---

## PURPOSE

Every piece of copy that attempts identity-based persuasion — "this is for people like you," qualification copy, "not for everyone" language, community offers, in-group vocabulary — is attempting to activate social identity. But most copy only partially activates it. The piece names a group (cognitive) and perhaps claims it's special (evaluative) but fails to create the emotional significance that transforms a label into an identity the prospect will act to protect and acquire.

This skill runs the full three-component audit and identifies exactly which components are firing and which are missing. It is the entry point for the full tajfel-* bundle — all downstream skills (salience calibration, prototype audit, distinctiveness calibration) assume social identity has been properly activated. If it hasn't, those analyses are premature.

---

## INPUT REQUIREMENTS

Provide one of:
1. **A piece of copy** (headline, lead, sales letter section, VSL transcript excerpt) to audit
2. **A description of the in-group construction** — what group is the copy claiming the prospect belongs to, and how
3. **URL or document** containing the copy to be analyzed

Optionally provide:
- **Target audience profile** — helps calibrate whether the named group matches who the prospect actually self-categorizes as
- **Competitive context** — what other group-identity offers this market is seeing

---

## AUDIT STRUCTURE

### Section 1: Categorization Scan

**What group is being named?**
- Quote the exact language that names, describes, or implies the in-group
- Rate specificity: [Hyper-specific | Specific | Moderate | Generic | Absent]
- Flag any language that inadvertently names or implies out-group membership (categorization that works against conversion)

**Accentuation analysis:**
- Does the copy use sharp category language (amplifies within-group similarity, between-group difference)?
- Or does it use blurred/inclusive language (fights against the accentuation effect)?
- Recommendation: specific language changes to sharpen categorization if needed

---

### Section 2: Three-Component Activation Audit

**Component 1: Cognitive (Knowing You Belong)**
- Is the group membership claim clear and unambiguous?
- Does the prospect know with certainty whether they qualify?
- Status: [PRESENT / WEAK / ABSENT]
- Evidence: [Quote specific copy elements]
- Gap: [What would complete this component if missing]

**Component 2: Evaluative (Positive Value Attached to Membership)**
- Does the copy establish that this group compares favorably to a relevant reference?
- Is the comparison explicit (named out-group) or implicit (implied by what the in-group is NOT)?
- Is the evaluative dimension (what the in-group is better AT) one the prospect actually values?
- Status: [PRESENT / WEAK / ABSENT]
- Evidence: [Quote specific copy elements]
- Gap: [What would complete this component if missing]

**Component 3: Emotional (Significance of Membership)**
- Does belonging to this group carry emotional weight for the prospect?
- Is there language that makes the stakes of belonging vs. not-belonging felt?
- Does the copy create the sense that membership is worth protecting, earning, or maintaining?
- Status: [PRESENT / WEAK / ABSENT]
- Evidence: [Quote specific copy elements]
- Gap: [What would complete this component if missing]

---

### Section 3: Positive Distinctiveness Assessment

**Comparison structure check:**
- What is the named or implied out-group? (See `tajfel-enemy-designator` for deeper analysis)
- Is the in-group positively differentiated on a dimension the prospect values?
- Is the distinctiveness genuine (the contrast is real and meaningful) or decorative (claimed but not demonstrated)?

**Positive distinctiveness rating:** [STRONG / MODERATE / WEAK / ABSENT]

**What this means:** The prospect's positive distinctiveness drive fires when group membership delivers self-concept enhancement through favorable comparison. Without a clear comparison, this drive cannot activate — belonging feels good but not meaningful.

---

### Section 4: Kelman Disambiguation Check

**Is any "identification" in the copy dyadic (Kelman) rather than categorical (Tajfel)?**
- Kelman's identification: "I want to be like [founder/guru/celebrity]" — person-to-person
- Tajfel's social identification: "I am a member of [category]" — person-to-group
- Note: Both can co-exist in the same copy; both can be useful; they must be diagnosed separately
- If Kelman's pathway is present alongside Tajfel's: flag for routing to `kelman-pathway-diagnostic`

---

### Section 5: Activation Score and Recommendations

**Overall activation score:**

| Component | Status | Strength (1–5) |
|-----------|--------|----------------|
| Cognitive | | |
| Evaluative | | |
| Emotional | | |
| Positive Distinctiveness | | |
| **Total** | | **/20** |

**Score interpretation:**
- 16–20: Full activation — proceed to `tajfel-salience-calibrator` for next-layer check
- 11–15: Partial activation — specific gaps identified above; fix before downstream audits
- 6–10: Weak activation — copy is naming a group but not activating social identity
- 1–5: Activation absent — no meaningful social identity construction present

**Priority fixes (in order of impact):**
1. [Highest-impact missing element + specific rewrite]
2. [Second-highest-impact missing element + specific rewrite]
3. [Third-highest-impact missing element + specific rewrite]

---

## OUTPUT FILE

Save complete audit to:
`[project-folder]/Tajfel — Social Identity Activation/01 - Identity Activation Audit - [Copy Name] - [Date].md`

---

## OUTPUT FORMAT — GIRARD STANDARD (canonical)

Produce a standalone Field Intelligence document conforming to the **Girard Standard**.

**Canonical spec:** `~/.claude/skills/_shared/output-formats/field-intelligence-girard-format.md` — read in full before producing output.

### Hard requirements

- **Length:** 250-400 lines (200 floor; 800 ceiling)
- **Fully self-contained** — reader must understand the analysis with no other file open
- **YAML frontmatter** including: `skill`, `target`, `analyst`, `date`, `analysis_type`, `status`, `priority_finding`
- **Epigraph** — a relevant quote from the source thinker, with application clause
- **Executive thesis** — 3-5 paragraphs that answer: what is analyzed, what lens is applied, what is the headline finding, why does it matter
- **Numbered sections** with embedded **verbatim quotes** from the target (no script-section shorthand like "S3.5" without quoting the actual words)
- **Falsifier check** — a section naming what would have to be false for the analysis to be wrong
- **Conclusion** with deployable verdict (action recommended or no action recommended, named)

### Forbidden patterns

- Script-section shorthand without embedded quote ("S3.5 has X" without the quote)
- Cross-references to other skill outputs ("see [other-skill] audit")
- Glossary references instead of inline definitions
- Generic verdicts ("strong"/"weak") without mechanism
- Closing summary that restates findings (padding)
- Version-comparison markers internal to the analysis ("v5 said X; v10 says Y" — belongs in commit log)

### Output path

Save to: `[project-folder]/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/06-social-identity-activator.md`

### Exemplars (read at least two before producing)

1. `Active-Brain/00 Projects/Support Pets - Girard Analysis/02-desire-autopsy.md`
2. `Active-Brain/00 Projects/Support Pets - Girard Analysis/03-rivalry-detector.md`
3. `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/05-qualification-architect.md`

### The "no flipping" test

Before declaring output complete: imagine a colleague opening this file cold, with no project context. Can they understand the analysis end-to-end without opening any other file? If no, the document has failed the standard. Rewrite.

---

## KNOWN PATTERNS (Field-Tested)

Patterns this skill has identified in production runs. Each entry encodes diagnostic intelligence the skill should apply to future targets.

---

### Pattern 1: ADJACENT / ECHO / NAKED Decision-Moment Classification

**Classification:** Load-bearing pattern

**Description:** When scanning a script for decision moments, rate each one on a three-point scale based on what identity language (if any) appears within the same beat or the immediately preceding beat. ADJACENT = explicit in-group / out-group label present. ECHO = Seer-prototype descriptor present (behavioral definition without the label). NAKED = no identity language of any kind adjacent to the moment. Apply this classification to every structural decision moment: silent selects, bridge offers, cost-of-inaction beats, objection handlers, and final purchase CTAs.

**Mechanism:** Turner's Self-Categorization Theory establishes that identity salience is contextually determined — the active category at the moment of judgment governs the judgment. "Active" means present in the perceiver's working memory at the decision instant, not merely available from memory. The ADJACENT/ECHO/NAKED scale operationalizes this: ADJACENT means the category is maximally active; ECHO means it is partially active (prototype language activates the concept without naming it); NAKED means the perceiver is processing as a generic individual. Only ADJACENT and strong ECHO ratings produce identity-governed behavior.

**Worked example:** In ZenithMind OS Evergreen Webinar v10, six decision moments were mapped. Two were ADJACENT (bridge offer at S11.5 and final close Block H), three were ECHO (S7 Beat C, S5.5 pattern-detection, S15 Phase 1-4 reveal), and one was NAKED (Block B.5 cost-of-inaction). The NAKED rating at Block B.5 — the highest-stakes pre-commitment moment — meant the cost-of-inaction argument landed on a generic existential frame rather than an identity frame, reducing structural persuasiveness at the most critical pre-price beat.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/06-social-identity-activator.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern 2: NAKED Cost-of-Inaction — High-Emotion Beat Without Identity Attachment

**Classification:** Anti-pattern (CRITICAL — fix first)

**Description:** When a cost-of-inaction or "staying is painful" beat runs in the script without any in-group identity language adjacent to it, flag it as NAKED and prioritize it above all other identity gaps. Look for beats that describe emotional consequences of not acting ("three more years of this," "the version of yourself you keep glimpsing") without anchoring those consequences to the prospect's in-group identity. The test: does the copy differentiate the in-group's experience of inaction from a generic human's experience of inaction? If the same copy would land identically on a non-member, it is NAKED.

**Mechanism:** Tajfel's research establishes that in-group-coded consequences feel more personally relevant than identical consequences framed as universal experiences — the identity frame amplifies felt stakes because the cost is reinterpreted as an identity failure, not just a personal outcome. A generic cost-of-inaction argument activates loss aversion at the individual level. An identity-coded cost-of-inaction argument activates loss aversion PLUS identity threat — a structurally more powerful combination. Fixing a NAKED cost-of-inaction beat requires fewer than 30 words and produces outsized conversion impact because this beat is the final emotional accelerant before the price reveal.

**Worked example:** Block B.5 of the ZMOS v10 script ran entirely in generic existential terms ("Mondays," "the version of yourself you keep glimpsing," "the work that's been waiting on you") with no Seer or Resigned Observer language adjacent. The recommended fix was a ~30-word insertion after "Three more years of that. That's the cost of staying." — inserting: "Seers don't stop seeing. The gap you've been watching doesn't get smaller because you looked away. Three more years of seeing without acting. That's the Seer's specific cost." — converting the generic existential consequence into an identity consequence.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/06-social-identity-activator.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern 3: Late-Firing Trigger — Identity Language Arriving After the Decision Moment

**Classification:** Anti-pattern

**Description:** When identity language appears in the same beat as a decision moment but after the decision prompt rather than before it, classify as ECHO (not ADJACENT) and flag the sequence. The structural error is deploying the category label as reinforcement after the viewer has already processed the choice, rather than as a priming frame that governs how the choice is processed. In copy, look for any beat where the Seer / in-group label appears in the second half of a beat that opens with a silent-select prompt or decision ask.

**Mechanism:** Tajfel's original categorization studies and Turner's SCT both establish that category priming before judgment governs the judgment; priming after the judgment records identity retrospectively but does not govern the decision already made. Sequence is the operative variable: pre-decision activation = identity-governed behavior; post-decision activation = identity-consistent retrospective labeling. The latter has value (reinforces identity) but does not convert the decision itself. Fixing late-firing triggers is typically a repositioning of existing language within the same beat, not new copy — move the identity sentence to before the decision prompt.

**Worked example:** In S7 Beat C of the ZMOS v10 script, the silent select ("Of those three — which one feels most missing for you right now? Don't say it out loud. Just notice.") preceded the Seer-prototype language ("The architecture only works for people who have already done the seeing. You're one of them"). The identity reinforcement arrived one beat after the viewer had already processed the choice in a generic frame. The recommended fix was repositioning "You're one of them" to the beat before the silent select, converting a late-firing ECHO to an early-priming ADJACENT.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/06-social-identity-activator.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)

---

### Pattern 4: Mid-Close Identity Decay Under Cognitive Load

**Classification:** Boundary condition

**Description:** When a script's offer sequence (stack reveal, proof avalanche, price reveal, guarantees, urgency blocks) runs for more than approximately 3–4 minutes without an explicit in-group label appearing, flag mid-close identity decay as a structural risk. The viewer installed the identity earlier in the webinar; the offer sequence is cognitively loaded with product evaluation tasks that compete with identity salience. Scan the gap between the last ADJACENT or strong ECHO moment and the final purchase CTA. If this gap spans multiple high-cognitive-load offer blocks, the viewer may be processing as a generic consumer by the time they reach the click moment — even if the final CTA itself is ADJACENT.

**Mechanism:** Identity salience is not durable under competing cognitive demands. Self-Categorization Theory predicts that the functional level of categorization (which identity is active) shifts with perceiver readiness and comparative fit — both are disrupted by the product evaluation mindset triggered by price reveals, guarantee language, and urgency stacks. A viewer who was a Seer at the bridge offer and a generic consumer through Block D, E, F, and G is making the click decision as a generic consumer. Terminal ADJACENT language at the final CTA partially recovers this, but recovery is less effective than prevention.

**Worked example:** In the ZMOS v10 script, the mid-close gap from S11.5 (bridge offer, ADJACENT) to Block H (final close, ADJACENT) spanned Blocks B.5, C, D, D.5, E, F, G, and G.5 — at least five minutes of offer copy — with only one NAKED gap (Block B.5) and one ungoverned objection block (G.5) in between. The aggregate verdict was PARTIAL activation: strong at terminal moments, missing mid-close. The mid-close gap is why fixing Block B.5 was prioritized as the single highest-leverage intervention — it re-anchors identity at the moment the offer sequence accelerates.

**Reference:** `Active-Brain/00 Projects/Evergreen Zenith Mind OS/05-Critical-Analysis/FIELD-INTELLIGENCE-REPORTS/tajfel/06-social-identity-activator.md`

**First identified:** 2026-05-17 (ZMOS Evergreen Webinar v10)
