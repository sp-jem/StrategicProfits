---
name: fauconnier-blend-library
description: Input 2 domain resource bank for double-scope blend construction. Organized by target vital relation, emergent-structure type, and generic space family. Use when generating Input 2 candidates in fauconnier-big-idea-engineer or when stuck on domain selection.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Gilles Fauconnier & Mark Turner (Conceptual Blending Theory) — Idea 5"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/fauconnier-blend-library {problem-type} {desired-emergent-structure}"
  called_by: [user, fauconnier-big-idea-engineer]
  outputs_to: [inline]
depends_on: []
---

# Fauconnier Blend Library

---

## LAYER 1: INVARIANTS (Never override.)

1. **This library provides candidates, not answers.** Every Input 2 domain listed here must still be tested against the specific Input 1 for the prospect and product at hand. Generic space viability, selective projection quality, and emergent structure density all depend on the specific Input 1. A domain that produced brilliant emergent structure for one prospect situation may produce none for another.

2. **The vital relation column is a starting point, not a constraint.** Most domains in this library are coded with their most natural vital relation for direct-response use. But the actual vital relation used in a blend is determined by the specific mapping — a medical domain might typically use ROLE vital relations, but for a specific prospect situation, CAUSE-EFFECT might be the stronger connector. Test the vital relations; don't assume.

3. **The "completion leverage" ratings are calibrated for a general American direct-response audience.** Completion leverage depends entirely on whether the prospect has a rich pre-existing cognitive frame for the domain. Different audiences have different frame densities for different domains. A financial professional has a different frame for "derivatives trading" than a mainstream investor does. Calibrate to the specific market.

4. **Historical examples are probes, not templates.** The classified historical big ideas included here demonstrate what has worked. They are not formulas to copy. Their value is diagnostic: they reveal what generic space was in play, which vital relations were active, and what emergent structure was generated. Use them to train judgment, not to replicate.

5. **Domain saturation matters.** Some Input 2 domains have been used so extensively in a given market that the completion leverage has been depleted — the prospect's frame has been conditioned by prior exposure to that domain in that context, and it no longer generates the emergent structure it once did. War metaphors in financial copy are saturated in most U.S. markets. Medical malpractice remains underutilized for financial products. Ecology is largely unoccupied. Prioritize domains with low saturation in the target market.

---

## LAYER 2: QUALITY GUIDANCE

6. **The best Input 2 domains are ones where the prospect has a strong pre-existing emotional charge.** Not just familiarity — emotional charge. The prospect must have a loaded, specific, visceral frame for Input 2 for completion leverage to be high. Medical domains have high emotional charge for health-anxious prospects. Legal domains have high emotional charge for people who feel wronged. Navigation domains are emotionally neutral for most people — usable but lower completion leverage.

7. **The double-scope upgrade potential column predicts which domains can produce genuine double-scope when combined with Input 1 situations that have rich organizational frame structure.** Domains rated HIGH for double-scope potential have organizational frame structures that are likely to produce emergent organizational frames when combined with a well-specified Input 1.

8. **Cross-domain combinations produce the highest emergent structure.** Some of the most powerful big ideas blend domains from different generic space families. Medical + legal (malpractice is already a cross-domain blend at the source). Ecology + finance. Military + psychology. When an Input 2 candidate is itself a blend, the resulting blend of blends can generate unusually dense emergent structure.

---

## PURPOSE

The hardest part of double-scope construction is not the architecture — it is generating viable Input 2 candidates quickly. Most copywriters default to the same 4–5 source domains (war, medicine, sports, gambling, journey) because those are top-of-mind. This limits emergent structure potential because those domains are either saturated or structurally limited for most prospect situations.

This library expands the Input 2 candidate pool systematically. It is organized to allow rapid lookup by: (a) what type of emergent structure you need; (b) what vital relation your Input 1 most naturally supports; (c) what generic space family connects your prospect situation to a source domain.

---

## LOOKUP STRUCTURE

### Lookup 1: By Desired Emergent Structure

Choose the emergent structure type you need the blend to generate. Each type is a different emotional and cognitive outcome for the prospect.

---

**A. Moral Obligation + Victim Frame**
Goal: Prospect feels they have been wronged, are owed something, and have a legitimate claim.

| Domain | Natural Vital Relation | Completion Leverage | DS Upgrade Potential | Generic Space Family |
|---|---|---|---|---|
| Medical malpractice | ROLE + CAUSE-EFFECT | HIGH | HIGH | Professional fiduciary failure |
| Legal malpractice | ROLE + INTENTIONALITY | HIGH | HIGH | Professional fiduciary failure |
| Financial fraud / Ponzi scheme | IDENTITY + CAUSE-EFFECT | HIGH | MEDIUM | Trust violation |
| Environmental contamination | CAUSE-EFFECT + PART-WHOLE | MEDIUM | HIGH | Invisible harm |
| Product liability / defective goods | CAUSE-EFFECT + ROLE | MEDIUM | MEDIUM | Trust violation |
| Academic credential fraud | ROLE + IDENTITY | MEDIUM | MEDIUM | Professional fiduciary failure |
| Negligent lifeguard | ROLE + INTENTIONALITY | HIGH | MEDIUM | Professional fiduciary failure |

**Key generic space for this emergent structure type:**
"A trusted professional or institution whose failure of duty causes serious harm to a dependent party who cannot easily detect the failure and who trusted the professional/institution precisely because of that information asymmetry."

---

**B. Hidden Mechanism + Urgency Frame**
Goal: Prospect discovers an invisible force that has been operating against them, urgency activated because the mechanism continues operating.

| Domain | Natural Vital Relation | Completion Leverage | DS Upgrade Potential | Generic Space Family |
|---|---|---|---|---|
| Cancer / silent disease | CAUSE-EFFECT + TIME | HIGH | HIGH | Hidden mechanism |
| Termite infestation | CAUSE-EFFECT + TIME | HIGH | HIGH | Hidden mechanism |
| Slow carbon monoxide leak | CAUSE-EFFECT + TIME | HIGH | MEDIUM | Hidden mechanism |
| Compound interest (debt) | CAUSE-EFFECT + TIME | HIGH | HIGH | Hidden accumulation |
| Slow infrastructure decay | CAUSE-EFFECT + PART-WHOLE | MEDIUM | HIGH | Hidden mechanism |
| Parasitic relationship | CAUSE-EFFECT + INTENTIONALITY | HIGH | HIGH | Hidden mechanism |
| Erosion / geological change | CAUSE-EFFECT + TIME | MEDIUM | MEDIUM | Hidden mechanism |

**Key generic space for this emergent structure type:**
"A process that operates continuously, invisibly, and cumulatively to produce serious harm to a party who is unaware of it and who, once aware, faces the urgency of stopping an ongoing mechanism."

---

**C. New Category Creation + Solution Reframe**
Goal: Prospect understands they've been using the wrong category of solution — what they need exists in a new, previously unnamed category.

| Domain | Natural Vital Relation | Completion Leverage | DS Upgrade Potential | Generic Space Family |
|---|---|---|---|---|
| Wrong tool for job | ROLE + CAUSE-EFFECT | HIGH | HIGH | Category error |
| Treating symptom vs. cause (medicine) | CAUSE-EFFECT + PART-WHOLE | HIGH | HIGH | Category error |
| Using a map of the wrong city | SIMILARITY + CAUSE-EFFECT | HIGH | HIGH | Category error |
| Fighting the last war (military doctrine) | TIME + CAUSE-EFFECT | MEDIUM | HIGH | Category error |
| Applying physics of one domain to another (bridge/building codes) | ROLE + SIMILARITY | LOW | HIGH | Category error |
| Nutritional deficiency vs. symptom treatment | CAUSE-EFFECT + PART-WHOLE | HIGH | HIGH | Category error |

**Key generic space for this emergent structure type:**
"A situation where a competent agent applies a standard category of response to a problem and fails, not because of execution failure, but because the problem belongs to a fundamentally different category that requires a different type of response."

---

**D. Urgency + Narrowing Window**
Goal: Prospect understands that the cost of inaction increases over time and a specific threshold exists after which the solution will no longer work.

| Domain | Natural Vital Relation | Completion Leverage | DS Upgrade Potential | Generic Space Family |
|---|---|---|---|---|
| Treatment window after heart attack | TIME + CAUSE-EFFECT | HIGH | HIGH | Journey/navigation |
| Golden hour in emergency medicine | TIME + CAUSE-EFFECT | HIGH | MEDIUM | Journey/navigation |
| Expiring legal statute of limitations | TIME + ROLE | HIGH | HIGH | Journey/navigation |
| Compound interest / compounding growth | TIME + CAUSE-EFFECT | HIGH | HIGH | Hidden accumulation |
| Seasonal growing window | TIME + PART-WHOLE | MEDIUM | MEDIUM | Journey/navigation |
| Rising tide / flood level | TIME + CAUSE-EFFECT | HIGH | MEDIUM | Physical force |
| Burning platform | TIME + CAUSE-EFFECT | HIGH | MEDIUM | Physical force |

**Key generic space for this emergent structure type:**
"A situation where a specific action, applied within a specific time window, produces a dramatically different outcome than the same action applied after the window closes."

---

**E. Villain Assignment + Antagonist Frame**
Goal: Prospect identifies a specific villain who is actively working against them — not a circumstance but an agent with intentionality.

| Domain | Natural Vital Relation | Completion Leverage | DS Upgrade Potential | Generic Space Family |
|---|---|---|---|---|
| Corrupt official | INTENTIONALITY + ROLE | HIGH | HIGH | Adversarial contest |
| Double agent / spy | INTENTIONALITY + IDENTITY | HIGH | HIGH | Trust violation |
| Protection racket | INTENTIONALITY + ROLE | HIGH | HIGH | Adversarial contest |
| Pharmaceutical suppression | INTENTIONALITY + CAUSE-EFFECT | HIGH | HIGH | Adversarial contest |
| Academic gatekeeping | INTENTIONALITY + ROLE | MEDIUM | HIGH | Adversarial contest |
| Information monopoly | INTENTIONALITY + PART-WHOLE | MEDIUM | HIGH | Adversarial contest |
| Deliberate planned obsolescence | INTENTIONALITY + TIME | MEDIUM | HIGH | Trust violation |

**Key generic space for this emergent structure type:**
"A situation where a party with access, authority, or information systematically uses that advantage to extract value from a dependent party while concealing the extraction."

---

**F. Identity Transformation + Crossing a Threshold**
Goal: Prospect understands they are about to cross (or must cross) an identity threshold — the transformation the product delivers is encoded as a one-way crossing into a new category of person.

| Domain | Natural Vital Relation | Completion Leverage | DS Upgrade Potential | Generic Space Family |
|---|---|---|---|---|
| Initiation / rite of passage | IDENTITY + CHANGE | HIGH | HIGH | Transformation |
| Emigration / leaving the old country | IDENTITY + CHANGE | HIGH | HIGH | Transformation |
| Military service / veteran identity | IDENTITY + CHANGE | HIGH | MEDIUM | Transformation |
| Graduation / degree | IDENTITY + CHANGE | HIGH | MEDIUM | Transformation |
| Surgery / before and after | IDENTITY + CHANGE | HIGH | HIGH | Transformation |
| Religious conversion | IDENTITY + CHANGE | MEDIUM | HIGH | Transformation |
| Bankruptcy / clean slate | IDENTITY + CHANGE | HIGH | HIGH | Transformation |

**Key generic space for this emergent structure type:**
"A process where a person crosses a specific threshold that permanently alters their category of identity — before the crossing, they have one set of capabilities, obligations, and social recognition; after the crossing, they have a categorically different set."

---

### Lookup 2: By Primary Vital Relation

If the Input 1 situation most naturally supports a specific vital relation, use this lookup to find Input 2 domains that strongly activate that relation.

**ROLE vital relation** (Input 1 entity fills the same structural role as Input 2 entity):
Top domains: medical profession, legal profession, military command, sports coaching, financial fiduciary, ship navigation, ecological predator/prey, parenting, teaching.

**CAUSE-EFFECT vital relation** (mechanism of harm maps across both inputs):
Top domains: medicine/disease, ecology/invasive species, mechanics/system failure, geology/erosion, chemistry/reaction, epidemiology/infection, electrical/short circuit.

**IDENTITY vital relation** (same entity in a different context, before/after):
Top domains: metamorphosis (biology), recovery (medicine), emigration, initiation rites, conversion, career transition, recovery from addiction.

**CHANGE vital relation** (transformed version — irreversible shift):
Top domains: geological transformation, phase transitions (water → steam), evolution, scar tissue formation, calcification.

**INTENTIONALITY vital relation** (agent with deliberate goals maps across):
Top domains: espionage/sabotage, corruption, predatory lending, manipulation/cult dynamics, monopoly behavior, capture (regulatory), organized crime.

---

### Lookup 3: By Generic Space Family

The generic space families below represent the most productive abstract structures for direct-response copy. When you know what abstract structure connects your prospect's situation to a source domain, use this lookup.

**Professional fiduciary failure:**
Expert domains: medicine, law, accounting, financial planning, architecture, engineering, pharmacy.
Common vital relation: ROLE + CAUSE-EFFECT.
Double-scope potential: HIGH (fiduciary relationship structures in Input 1 combine with specific professional failure frames in Input 2 to produce emergent accountability and recourse structures).

**Hidden mechanism:**
Expert domains: oncology (silent tumor growth), toxicology (bioaccumulation), structural engineering (metal fatigue), ecology (invasive species spread), pharmacology (slow drug interaction), entomology (termite colony).
Common vital relation: CAUSE-EFFECT + TIME.
Double-scope potential: HIGH (the temporal structure of the hidden mechanism combines with the specific causal structure of Input 1 to produce emergent urgency and detection-obligation structures).

**Adversarial contest:**
Expert domains: chess, military strategy, competitive intelligence, legal adversarial process, sports, biological predation, arms races.
Common vital relation: ROLE + INTENTIONALITY.
Double-scope potential: MEDIUM (adversarial frame is well-established; double-scope requires that Input 1's specific power asymmetry contributes novel frame structure to the contest).

**Journey and navigation:**
Expert domains: ship navigation (dead reckoning, currents, storms, charts), wilderness survival, space navigation, underwater exploration, mountaineering.
Common vital relation: CAUSE-EFFECT + TIME + PART-WHOLE.
Double-scope potential: MEDIUM-HIGH (navigation has rich organizational frame structure; upgrades well when Input 1 contributes specific types of uncertainty or compounding error).

**Biological systems:**
Expert domains: ecology (predator/prey, carrying capacity, invasive species), immunology (antigen/antibody, autoimmune), parasitology, evolutionary biology, microbiology (infection dynamics), genetics.
Common vital relation: CAUSE-EFFECT + PART-WHOLE + TIME.
Double-scope potential: HIGH and underexploited in direct response. Biological systems have dense, non-obvious organizational logic that produces rich emergent structure when combined with prospect Input 1 situations.

**Physical force:**
Expert domains: structural engineering (load distribution, failure modes), hydraulics (pressure, flow, blockage), thermodynamics (entropy, heat transfer), seismology (fault accumulation, sudden release), meteorology (pressure systems, storm formation).
Common vital relation: CAUSE-EFFECT + TIME.
Double-scope potential: MEDIUM (physical force frames are visceral but often single-scope; double-scope requires Input 1 to contribute a specific structural vulnerability or threshold effect).

**Trust violation:**
Expert domains: confidence fraud, identity theft, double agent/betrayal, counterfeiting, adulteration of food/medicine, forgery.
Common vital relation: IDENTITY + INTENTIONALITY.
Double-scope potential: HIGH (trust violation frames have dense moral and psychological structure; the specific nature of the trust relationship in Input 1 often produces emergent structures around detection, culpability, and remedy).

---

### Lookup 4: Historical Direct-Response Big Ideas — Classified

Notable direct-response big ideas classified by network type and emergent structure. For diagnostic reference.

| Big Idea | Input 1 | Input 2 | Generic Space | Network Type | Emergent Structure |
|---|---|---|---|---|---|
| "Your financial advisor is committing malpractice" | Financial advisor managing investments | Medical malpractice | Licensed professional whose breach of fiduciary duty causes harm to a dependent client who cannot detect it | Double-scope | Moral obligation to investigate; victim status for prospect; shame and accountability frame for advisor; "legal-equivalent recourse" implication |
| "The Coming Plague in Your Portfolio" | Deteriorating portfolio positions | Infectious disease spreading | An invisible harmful agent multiplying over time in a system the host cannot see without instruments | Double-scope | Urgency of early detection; contamination of otherwise healthy holdings; "disease progression" without intervention; specialist diagnosis framing for the solution |
| "You're fighting a losing battle against weight" | Dieting attempts that keep failing | Military campaign that cannot be won by conventional means | An adversarial contest where the resources available to one side are structurally insufficient to defeat the other | Single-scope | War frame provides entailments (strategy, weapons, enemy) but Input 1 contributes no organizational frame structure back into the blend |
| "The Silent Killer in Your Medicine Cabinet" | Common OTC medications | Silent disease like carbon monoxide or cancer | An invisible ongoing harm operating without the victim's awareness | Double-scope | Trusted object as source of harm (reversal of expectation); cumulative invisible damage; duty to investigate one's own medicine cabinet; detection window urgency |
| "Secrets Your Doctor Doesn't Tell You" | Withheld information about health | Information monopoly / gatekeeping | A knowledge asymmetry where one party controls information that is material to the other's wellbeing and withholds it | Double-scope | Systemic suppression (intentionality); you have been deliberately kept ignorant; the information exists and is actionable; access to it changes your situation |

---

## QUICK REFERENCE: MOST POWERFUL UNDERUTILIZED DOMAINS

For direct-response copy in the business, finance, health, and self-improvement markets, these domains are underutilized and have high double-scope potential:

1. **Parasitology** — The relationship between a parasite and a host is structurally precise: the parasite extracts resources from the host while the host continues to function (often unaware), until the extraction exceeds the host's capacity to compensate. Rich completion leverage, high emotional charge, genuinely underused.

2. **Structural engineering / metal fatigue** — Structures that appear sound are accumulating stress that is invisible to the observer. The failure mode is sudden and catastrophic rather than gradual. Applies to financial positions, health conditions, business systems, relationships.

3. **Ecological succession / invasive species** — An ecosystem being gradually transformed by a non-native element that out-competes the native elements for resources. Applies to market disruption, competitor dynamics, technology adoption curves.

4. **Immunology / autoimmune** — The body's own defense system turning against the body it was designed to protect. Powerful for internal sabotage narratives: the habits, beliefs, or systems that were supposed to protect the prospect are now the source of harm.

5. **Archaeological / geological stratigraphy** — Hidden layers that record history; what is visible on the surface is not what actually happened. Applies to business diagnostics, health histories, financial statements.

6. **Cryptography / signal intelligence** — A message that is present but unintelligible to those without the key. Applies to market signals, health indicators, or behavioral patterns that experts can read and laypeople cannot.
