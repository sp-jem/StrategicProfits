---
name: moscovici-behavioral-style-auditor
description: Full five-component behavioral style audit for contrarian copy sources — consistency, confidence, autonomy, investment, and fairness. Identifies exactly where the source's minority posture breaks down. Line-by-line output with specific rewrites.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Serge Moscovici (Minority Influence and Conversion Theory) — Idea 8"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/moscovici-behavioral-style-auditor {copy-to-audit}"
  called_by: [user, moscovici-minority-influence-diagnostic]
  outputs_to: [project-folder]
depends_on: [moscovici-genuine-conflict-validator, moscovici-consistency-confidence-auditor]
---

# Moscovici Behavioral Style Auditor

---

## LAYER 1: INVARIANTS (Never override.)

1. **Behavioral style is the complete signal architecture of the minority source.** Moscovici's behavioral style cluster is what communicates to the majority that the minority is worth taking seriously — that the minority's position is held genuinely, at personal cost, and with intellectual integrity. Without a complete behavioral style, even a copy piece with a genuine minority claim and consistent messaging fails to trigger the full validation process. Audit all five components. Omitting any one is an incomplete audit.

2. **The five components are distinct — diagnose each separately.** The five behavioral style components are: (1) CONSISTENCY — position does not waver; (2) CONFIDENCE — no hedging language, no epistemic retreat; (3) AUTONOMY — source is not beholden to mainstream expectations, not saying this to please; (4) INVESTMENT — source has visibly paid a price for holding this position; (5) FAIRNESS — source engages with the strongest objection rather than dismissing it. Each has distinct copy-level signals and distinct failure modes. Never conflate them.

3. **Autonomy is the most commonly missing component in contrarian copy.** Most copywriters understand consistency and confidence. Autonomy — the signal that the source holds the minority position independently, not because it is expected, not because it benefits them financially in an obvious way, not because it aligns with a patron's interests — is rarely explicit in copy but is evaluated unconsciously by sophisticated readers. If the autonomy signal is absent, the reader concludes the minority position is a marketing posture, not a genuine belief. Marketing postures do not trigger the validation process.

4. **Investment requires visible cost-signaling.** Investment as a behavioral style component means the source has demonstrably paid a price for holding the minority position — social cost (lost relationships, professional criticism), financial cost (changed a business model, left money on the table), or reputational cost (publicly contradicted a prior position, been wrong in a way they acknowledged). Abstract investment ("I've dedicated my life to this") does not score. Specific, costable investment does.

5. **Fairness is not weakness — it is the signal that distinguishes principled consistency from dogmatism.** A minority that dismisses all objections is perceived as ideological rather than evidential. A minority that acknowledges the strongest version of the opposing argument — then shows why the minority position is still correct — demonstrates intellectual honesty. This is Moscovici's fairness component. Fairness activates the validation process most completely because it signals the source has genuinely considered both sides.

---

## LAYER 2: QUALITY GUIDANCE

6. **Mugny's simplification holds for the minimum viable threshold.** Mugny (1982) found that consistency + confidence (the "maintenance style") accounts for most of the minority influence effect. The additional three components (autonomy, investment, fairness) amplify conversion depth and durability but are not required for the mechanism to activate at baseline. Report all five but weight consistency + confidence as threshold conditions; autonomy + investment + fairness as amplifiers.

7. **The fairness component is the highest-leverage amplifier.** Of the three amplifiers, fairness has the largest marginal return because it prevents the single most common dismissal pattern: "this person is a true believer who isn't actually engaging with the evidence." A single, genuinely well-framed acknowledgment of the strongest objection — followed by a principled rebuttal — can shift a sophisticated reader from dismissal to active validation.

8. **Source vs. copy architecture.** In live direct response, the "source" is typically the brand or founder. The behavioral style being audited is the behavioral style the copy constructs for that source — not the actual person's personality. The copy is responsible for signaling each component. If the copy fails to signal investment, the reader does not infer it from the actual founder's biography. Signal what the copy communicates, not what the company history contains.

---

## PURPOSE

Moscovici's concept of behavioral style is the European tradition's term for the complete set of observable signals that communicate the minority source's genuine commitment to its position. Consistency and confidence (covered in moscovici-consistency-confidence-auditor) are the two minimum-viable levers. Behavioral style extends this to the full cluster: autonomy (independent of mainstream incentives), investment (has paid a cost for this position), and fairness (engages the strongest objection).

Together, the five components tell the reader: "This person genuinely believes this, has paid for it, cannot be bought off it, and has honestly grappled with the counterarguments." That complete signal package is what triggers the deep validation process — not just consideration, but private reconfiguration of belief.

This skill audits all five components and delivers a scored, line-by-line breakdown with specific copy corrections.

---

## INPUT REQUIREMENTS

Provide:
1. **The complete copy piece** — all elements
2. **The core minority claim** (will be extracted if not provided)
3. **Source context** (optional but recommended): Who is the source? What is their actual background? What costs have they actually paid for their position? This allows the auditor to identify where real investment exists but is not being signaled in the copy.

---

## EXECUTION PROCESS

### Step 1: Behavioral Style Component Framework

Before auditing, establish the scoring framework:

| Component | Copy-Level Signal | Absence Pattern | Failure Label |
|-----------|------------------|-----------------|---------------|
| CONSISTENCY | Same claim, same strength, from first line to last | Position softens, qualifies, contradicts | WAVER |
| CONFIDENCE | No hedging language; definitive claim structure | "might," "perhaps," "could be," epistemic retreat | HEDGE |
| AUTONOMY | Source holds position independently of financial/social incentives | Claim aligned with obvious commercial interest, or "what you want to hear" | CAPTURED |
| INVESTMENT | Source has paid specific, named cost for this position | Vague commitment claims, no specificity | COSTLESS |
| FAIRNESS | Strongest objection acknowledged and engaged from position | Objections ignored, strawmanned, or dismissed | DISMISSIVE |

### Step 2: Consistency Audit (inherit from moscovici-consistency-confidence-auditor if already run, or run inline)

Per LAYER 1 Invariant 2 in moscovici-consistency-confidence-auditor: position must not waver across all elements.

Score: PASS / FAIL — note all deviations with element and specific text.

### Step 3: Confidence Audit (inherit or run inline)

Per LAYER 1 Invariant 2 in moscovici-consistency-confidence-auditor: no hedging language in the context of the core claim.

Score: STRONG / MODERATE / WEAK — note all hedges with element, type, and proximity.

### Step 4: Autonomy Audit

Assess whether the copy signals that the source holds the minority position independently:

**Autonomy Signals (positive):**
- Source held this position before it was profitable or popular
- Source has publicly disagreed with people who pay them or refer them
- Source is saying something that alienates a segment of their current audience
- Source's position costs them — in revenue, relationships, or social capital
- Source explicitly distinguishes their position from their commercial interest ("I'd sell more X if I believed the conventional wisdom — I don't")

**Autonomy Failures (CAPTURED signals):**
- Minority claim is conveniently aligned with the product being sold (no acknowledgment of the alignment)
- Source is positioned as a consultant or affiliate for the approach they're recommending (unconsidered)
- The "contrarian" position is the one that happens to benefit the source's business model
- Source does not signal any cost to their position

**Audit questions:**
- Does the copy explicitly address the alignment between the minority claim and the commercial offer?
- Is there a disclosure or acknowledgment that creates epistemic distance from obvious commercial interest?
- Is there a "why I'm telling you this even though it costs me" signal?

Score: STRONG / ADEQUATE / WEAK / ABSENT

### Step 5: Investment Audit

Assess whether the copy signals visible, specific cost-taking for the minority position:

**Investment Signals (positive):**
- Named specific relationships lost or strained because of this position
- Named specific financial decisions made based on this position (changed business model, turned down deals)
- Named specific prior beliefs contradicted by this position (I used to believe X — here is what it cost me to change my mind)
- Named specific professional or public criticism received for this position
- Named specific experiments or risks taken on the basis of this claim

**Investment Failures:**
- Generic commitment language: "I've dedicated my life to this," "I've been obsessed with this for years"
- Unnamed sacrifice: "I've paid the price for this view" without specifics
- Investment implied but not stated: reader is expected to infer cost from biography without it being made explicit in the copy

**Audit questions:**
- Can a specific, named cost be quoted from the copy? If not: COSTLESS
- Is the investment claim specific enough to be verifiable? (NAMED vs. GENERIC)
- Is the cost-signal proximate to the minority claim (linked directly) or general biography (not linked)?

Score: STRONG (specific, named, linked to claim) / ADEQUATE (specific but not directly linked) / WEAK (generic) / ABSENT

### Step 6: Fairness Audit

Assess whether the copy engages the strongest objection from a position of principled strength:

**Fairness Signals (positive):**
- The copy identifies the best counterargument to the minority position (not a strawman)
- The copy engages the counterargument with evidence, not dismissal
- After engagement, the copy returns to the minority position stronger, not weaker
- The source acknowledges what is valid in the majority position before explaining why the minority position is still correct

**Fairness Failures:**
- DISMISSIVE: Objections are ignored or treated as self-evidently wrong
- STRAWMAN: A weak version of the objection is presented and easily defeated
- CONCESSION: The source "acknowledges" the objection by retreating from the minority position (this is consistency failure, not fairness)
- ABSENT: No engagement with any objection whatsoever

**The fairness standard:** The test is whether a sophisticated advocate of the majority position would feel their strongest argument was accurately represented and seriously engaged. If not: STRAWMAN or DISMISSIVE.

Score: PRINCIPLED (strongest objection, genuine engagement) / ADEQUATE (real objection, adequate engagement) / STRAWMAN (weak objection, easy defeat) / DISMISSIVE / ABSENT

### Step 7: Behavioral Style Profile and Score

Compile the five-component profile:

| Component | Score | Evidence | Priority Fix |
|-----------|-------|----------|--------------|
| Consistency | PASS/FAIL | [key evidence] | [fix if needed] |
| Confidence | STRONG/MOD/WEAK | [key evidence] | [fix if needed] |
| Autonomy | STRONG/ADEQUATE/WEAK/ABSENT | [key evidence] | [fix if needed] |
| Investment | STRONG/ADEQUATE/WEAK/ABSENT | [key evidence] | [fix if needed] |
| Fairness | PRINCIPLED/ADEQUATE/STRAWMAN/DISMISSIVE/ABSENT | [key evidence] | [fix if needed] |

**Overall Behavioral Style Rating:**
- COMPLETE: Consistency PASS + Confidence STRONG/MODERATE + at least ADEQUATE on all three amplifiers
- MINIMUM VIABLE: Consistency PASS + Confidence STRONG/MODERATE (mechanism activates but conversion depth is limited)
- COMPROMISED: Any threshold condition failing (Consistency FAIL or Confidence WEAK)
- ABSENT: Multiple failures across threshold + amplifier components (copy is not functioning as minority influence)

---

## OUTPUT STRUCTURE

### Behavioral Style Audit Report

**Header:**
- Copy analyzed: [title or description]
- Core minority claim: [extracted statement]
- Source: [who is being audited as the minority source]
- Date: [YYYY-MM-DD]

**Section 1: Five-Component Scorecard**
[Table as in Step 7]

**Overall Behavioral Style Rating:** [COMPLETE / MINIMUM VIABLE / COMPROMISED / ABSENT]

**Section 2: Component Narratives**

For each component with a finding below STRONG/PASS/PRINCIPLED:

**[Component Name] — [Score]**
- What the copy is currently doing
- Specific text excerpt(s)
- Why this fails the behavioral style requirement
- Specific rewrite recommendation

**Section 3: Priority Fixes**

Ranked by impact on conversion mechanism activation:

1. **[Highest priority component]:** Specific fix
2–5. [same format]

**Section 4: Complete Source Behavioral Style Profile**

A 3–4 sentence characterization of how the source comes across based on the behavioral style audit — what a sophisticated reader perceives about this source's commitment, independence, and intellectual integrity.

**Section 5: Amplifier Opportunity**

If the two threshold conditions are met, identify the highest-leverage amplifier investment (which of autonomy, investment, fairness would produce the largest increase in conversion depth if strengthened, and specifically how).

---

## CROSS-REFERENCES

- **Consistency-Confidence Auditor:** This skill extends the two-component audit from moscovici-consistency-confidence-auditor to the full five-component behavioral style. Run the consistency-confidence auditor first when time is limited; run this skill for complete behavioral style diagnosis.
- **Hovland source credibility:** Hovland's trustworthiness + expertise framework is the American-lineage complement to Moscovici's behavioral style. Autonomy maps closely to Hovland's trustworthiness (not motivated by self-interest); Investment maps to expertise (cost of acquiring the knowledge). Cross-reference hovland-source-credibility-architect for the credibility architecture that supports behavioral style.
- **Kelman internalization:** Kelman's internalization pathway requires the source to be credible and the content to be value-consistent. Moscovici's behavioral style (especially autonomy + fairness) is what makes a source credible enough to trigger internalization rather than just identification.
- **Brehm reactance:** Rigid consistency (total refusal to acknowledge any nuance) can trigger reactance. The fairness component is the behavioral style antidote — it demonstrates the source is not dogmatic, which reduces reactance risk.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Serge Moscovici - Behavioral Style Audit/[YYYY-MM-DD] - Behavioral Style Audit - [Copy Name].md`
