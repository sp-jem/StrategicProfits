---
name: bourdieu-capital-audit
description: Map economic, cultural, and social capital operating in a market.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Pierre Bourdieu (The Forms of Capital, 1986) — Skill 1 of 6"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/bourdieu-capital-audit {market-description}"
  called_by: [user, bourdieu-field-analyzer, bourdieu-distinction-mapper]
  outputs_to: [client-output-folder]
girard_integration:
  feeds_from: [girard-model-map]
  feeds_to: [girard-desire-propagation, girard-rivalry-detector]
  shared_data: "Model Map provides WHO is being imitated. Capital Audit adds WHAT CAPITAL those models possess and which forms of capital the market actually rewards. Together they answer: who holds desire, and what resources (economic, cultural, social) sustain that desire?"
veblen_integration:
  feeds_from: [veblen-status-intelligence, veblen-price-ladder]
  feeds_to: [veblen-signal-decoder, veblen-waste-audit]
  shared_data: "Status Intelligence maps tier placement by visible signals. Capital Audit reveals the UNDERLYING RESOURCES that produce those signals. A player may signal apex tier but hold thin capital — that's a bluff. Price Ladder shows economic capital extraction; Capital Audit shows whether pricing reflects real capital or performed capital."
loewenstein_integration:
  feeds_from: [loewenstein-information-flow]
  feeds_to: [loewenstein-curiosity-architect]
  shared_data: "Information Flow maps what knowledge states buyers are in. Capital Audit reveals what CULTURAL CAPITAL (knowledge, taste, competence) the market values and who holds it. Together they answer: what does the market need to know, and who is credible enough to teach it?"
---

# Bourdieu Capital Audit

---

## LAYER 1: INVARIANTS (Never override.)

1. **All three capital forms must be mapped independently.** Economic capital (money, assets, revenue), cultural capital (knowledge, credentials, taste, expertise), and social capital (networks, relationships, group memberships, access) are distinct resources. Every player must be assessed on all three. Collapsing them into a single "influence" score destroys the analytical power.

2. **Capital conversion pathways must be identified.** Bourdieu's critical insight: capital forms are CONVERTIBLE. Cultural capital converts to economic capital (expertise → premium pricing). Social capital converts to economic capital (network access → deals). Economic capital converts to cultural capital (wealth → education → credentials). For every major player, identify which conversions they're executing and which they're missing.

3. **Capital volume and capital composition are separate assessments.** Two players can have equal TOTAL capital but radically different COMPOSITIONS — one heavy on economic, the other heavy on cultural. Composition determines positioning strategy. Volume determines tier placement. Both must be mapped.

4. **Embodied, objectified, and institutionalized forms must be distinguished.** Cultural capital exists in three states:
   - **Embodied** — internalized knowledge, skills, taste (takes time, cannot be delegated)
   - **Objectified** — books written, courses created, tools built (transferable objects)
   - **Institutionalized** — degrees, certifications, awards, formal recognition (externally validated)
   Each form carries different weight in different markets. A market that values embodied capital (deep expertise) will not respond to institutionalized capital (certificates) the same way.

5. **The client's capital portfolio must be audited honestly.** Do not inflate. Map what capital the client ACTUALLY holds versus what they CLAIM to hold. Identify capital gaps — forms they need but don't have — and capital waste — forms they hold but aren't converting. The gap between held capital and deployed capital is where the strategic opportunity lives.

---

## LAYER 2: QUALITY GUIDANCE

6. **Capital conversion failures are more valuable than capital inventories.** Everyone can list what capital a player has. The insight is in conversion failures — where a player holds significant capital in one form but FAILS to convert it to another. A thought leader with massive cultural capital who can't monetize it has a conversion failure. A wealthy operator who can't buy credibility has a different conversion failure. These failures reveal strategic opportunities.

7. **Inherited versus acquired capital matters.** Capital that was built over time through demonstrated competence reads differently than capital that was inherited, purchased, or borrowed. The market can usually sense the difference. Assess whether each player's capital feels EARNED or PERFORMED.

8. **The capital the MARKET rewards may differ from what the market SAYS it rewards.** Markets claim to value expertise (cultural capital) but often reward connections (social capital) or revenue proof (economic capital). The stated hierarchy and the actual hierarchy frequently diverge. Use behavioral evidence — who actually gets hired, who gets paid premium, who gets invited — not stated preferences.

---

## PURPOSE

Most competitive analyses look at what players SAY and DO — their positioning, pricing, content. They miss the deeper question: what RESOURCES does each player actually command, and how are those resources being converted into market position?

Bourdieu's insight is that markets are structured by capital — but not just money. The knowledge, relationships, and cultural competence that players bring to a market determine their position more durably than any tactical move. A player with deep cultural capital and strong social capital can price at a premium, attract partnerships, and weather market shifts in ways that a player with only economic capital cannot.

This skill maps the entire capital landscape so you can see: who holds what, who's converting effectively, who's sitting on unconverted capital, and where the gaps create opportunity for a new entrant or repositioning play.

**Cross-system integration:** The Girard system tells you who the market desires. The Veblen system tells you what status signals they display. This skill reveals what UNDERLYING RESOURCES generate and sustain those signals and that desire. Capital is the foundation; signals and desire are the surface expression.

---

## INPUT REQUIREMENTS

Provide:
1. **Market definition** — who the buyers are, what sophistication level, what they're buying
2. **Key players to analyze** — minimum 8, ideally 15-20 across capital levels (or ask the skill to identify them via research)
3. **Client identity** — who is being mapped INTO this capital landscape

Optional:
- Existing Model Map from girard-model-map (provides who holds desire)
- Existing Status Intelligence from veblen-status-intelligence (provides tier placement)
- Specific concern ("Why can't I charge more despite my expertise?" / "Why do less qualified competitors win deals?")

---

## EXECUTION PROCESS

### Step 1: Market Definition & Player Identification

Confirm the market boundaries. If players are not provided, research to identify 15-20 using web search: dominant players, established competitors, rising operators, and commodity-tier examples.

### Step 2: Economic Capital Inventory (Per Player)

For each player, assess visible economic capital signals:

**Revenue indicators:** Stated revenue, team size, office/infrastructure, ad spend visibility
**Asset indicators:** Product portfolio value, intellectual property, recurring revenue streams
**Investment capacity:** Ability to sustain losses, fund experiments, acquire competitors/talent
**Pricing power:** What they charge relative to the market, payment terms, ability to hold price

### Step 3: Cultural Capital Inventory (Per Player)

For each player, assess cultural capital across all three states:

**Embodied:** Demonstrated expertise depth, originality of thinking, ability to improvise and adapt, taste level, vocabulary sophistication, historical knowledge of the field
**Objectified:** Books, courses, frameworks, tools, methodologies, content library, research produced
**Institutionalized:** Degrees, certifications, awards, media features, speaking invitations, institutional affiliations, formal recognition

### Step 4: Social Capital Inventory (Per Player)

For each player, assess social capital across dimensions:

**Network breadth:** How many distinct communities/groups they have access to
**Network depth:** Quality of relationships (transactional vs. genuine, one-way vs. reciprocal)
**Structural position:** Are they a bridge between disconnected groups (high structural capital) or embedded in a single cluster?
**Access capital:** Who can they get on the phone? What rooms are they in? What introductions can they make?
**Community capital:** Do they own/lead communities, or are they members? Leading = higher social capital
**Reputation capital:** What is said about them when they're not in the room?

### Step 5: Capital Composition Analysis

For each player, create the capital composition profile:

| Player | Econ | Cultural | Social | Dominant Form | Conversion Quality |
|--------|------|----------|--------|---------------|-------------------|
| [Name] | H/M/L | H/M/L | H/M/L | [Which leads] | [Strong/Weak/Missing] |

Identify:
- **Capital-heavy players** — high volume across all three (market leaders)
- **Capital-specialized players** — strong in one form, weak in others (vulnerable to conversion failures)
- **Capital-bluffers** — performing capital they don't actually hold (unsustainable positions)
- **Capital-wasters** — holding capital they're not deploying (missed opportunities)

### Step 6: Capital Conversion Pathway Analysis

For each significant conversion pathway in the market:

**Cultural → Economic:** Who successfully converts expertise into revenue? How? What's the mechanism (premium pricing, productized knowledge, consulting leverage)?
**Social → Economic:** Who converts relationships into revenue? How? (Referral networks, JV deals, community monetization, partnership leverage)
**Economic → Cultural:** Who uses money to acquire cultural capital? How? (Hiring experts, buying education, funding research, acquiring credentialing institutions)
**Economic → Social:** Who uses money to acquire social connections? How? (Sponsoring events, joining masterminds, funding causes, buying media access)
**Cultural → Social:** Who converts expertise into network access? How? (Teaching attracts connections, thought leadership creates community, mentoring builds loyalty)
**Social → Cultural:** Who leverages connections to acquire knowledge? How? (Access to private information, mentorship from leaders, insider knowledge from network position)

### Step 7: Client Capital Assessment

Map the client's capital portfolio with complete honesty:

- **Economic capital:** What they actually command (not aspirational)
- **Cultural capital:** Embodied (what they genuinely know), objectified (what they've produced), institutionalized (what's formally recognized)
- **Social capital:** Network map, structural position, access quality, community ownership
- **Capital composition:** What's their dominant form? Where are they weak?
- **Conversion quality:** Which conversions are they executing well? Which are they failing at? Which haven't they attempted?
- **Capital gaps:** What forms of capital would change their market position most if acquired?
- **Capital waste:** What capital do they hold but aren't deploying?

### Step 8: Strategic Recommendations

Based on the full capital audit:
- What capital form should the client invest in building? (May not be the obvious one)
- Which conversion pathways should they activate? (Specific mechanisms, not vague advice)
- Where is unconverted capital creating the biggest missed opportunity?
- Which competitors' capital positions are vulnerable? (Bluffers, wasters, conversion failures)
- What capital moves would shift the client's market position most efficiently?
- Where does the client's capital composition create natural advantages they're not exploiting?

---

## OUTPUT STRUCTURE

### Capital Audit Report

**Section 1: Market Capital Landscape**
Overview of how the three capital forms are distributed across the market. Which form dominates? What does the market actually reward?

**Section 2: Player Capital Profiles**
Per-player assessment across all three capital forms, with composition analysis and conversion quality ratings.

**Section 3: Capital Conversion Map**
Which conversion pathways are active in this market, who executes them well, and where conversion failures create opportunity.

**Section 4: Capital Bluffs & Vulnerabilities**
Players performing capital they don't hold, and players sitting on unconverted capital. These are the strategic openings.

**Section 5: Client Capital Portfolio**
Honest assessment of the client's capital across all three forms, including gaps, waste, and conversion failures.

**Section 6: Cross-System Integration**
If Girard/Veblen/Loewenstein data exists: How does capital distribution map to desire dynamics (Girard), status signals (Veblen), and decision behavior (Loewenstein)?

**Section 7: Strategic Recommendations**
Specific capital investments, conversion activations, and positioning moves — with rationale tied to the capital landscape.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Pierre Bourdieu - Capital Audit/01 - Capital Audit Report - [Market] - [Date].md`
