---
name: fauconnier-big-idea-engineer
description: Primary generative tool — constructs double-scope conceptual blend candidates for use as big ideas. Given a product and prospect situation, systematically builds 3–5 ranked blend candidates with emergent structure maps, network-type classification, and a developed headline + lead for the top candidate.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Gilles Fauconnier & Mark Turner (Conceptual Blending Theory) — Idea 1"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/fauconnier-big-idea-engineer {product} {prospect-situation}"
  called_by: [user]
  outputs_to: [project-folder]
depends_on: [fauconnier-blend-library, fauconnier-emergent-structure-tester]
---

# Fauconnier Big Idea Engineer

---

## LAYER 1: INVARIANTS (Never override.)

1. **Input 1 must be articulated with precision before generating Input 2 candidates.** Input 1 is not "the prospect's general situation." It is the precise constellation of circumstances the prospect is actually in: the specific problem, the specific failed attempts, the specific beliefs that make the problem feel inevitable, the specific emotional state. A vague Input 1 produces a weak generic space and therefore a weak blend. Refuse to proceed to Input 2 generation until Input 1 is specific.

2. **The generic space must be articulated for each candidate before assessing the blended space.** The generic space is the construction bottleneck. Every failed blend fails here first. For each Input 2 candidate, state the generic space explicitly in abstract, content-free language before attempting to run the blend. If the generic space cannot be articulated, the candidate blend is not viable — discard it.

3. **Selective projection must be specified explicitly.** Do not assume everything from both inputs enters the blend. For each candidate, specify: (a) which elements of Input 1 are projected; (b) which elements of Input 2 are projected; (c) what is deliberately excluded from each input and why. The exclusions are as important as the inclusions.

4. **Emergent structure is the selection criterion for ranking candidates.** Candidates are not ranked by how vivid the analogy is, how memorable the headline sounds, or how emotionally resonant the Input 2 domain feels. They are ranked by emergent-structure density: how many elements exist in the blended space that exist in neither input alone? A bland-sounding double-scope blend with dense emergent structure outranks a vivid single-scope metaphor every time.

5. **Do not conflate Lakoff/Johnson entailment with blending emergent structure.** Source-domain entailments (what the war frame automatically implies about conflict) are CMT-level effects. They are useful but they are not emergent structure. Emergent structure is what the BLEND produces, not what Input 2 brings on its own. The test: does removing Input 1 from the blend eliminate the element? If yes, it may be emergent. If no (the element exists in Input 2 alone), it is entailment.

6. **The developed output (headline + lead) must demonstrate the blend in use, not just describe it.** The headline must be a blend compression — a single vivid statement that activates both input spaces simultaneously. The lead must demonstrate elaboration — the blend being run forward to generate the argument. If the headline can be read as simply "this product is like [Input 2 domain]," the compression has failed.

---

## LAYER 2: QUALITY GUIDANCE

7. **The vital relations are the connector infrastructure — select them deliberately.** Before running any blend, identify which vital relation(s) connect the inputs. The ROLE vital relation (Input 1 entity fills the same structural role as Input 2 entity) is the most common in direct-response big ideas. CAUSE-EFFECT is the most powerful for mechanism-based big ideas. IDENTITY (same entity in different context) produces the most personally immediate blends. Choose the vital relation first; it governs what projections are natural.

8. **The compression to human scale principle is the most underused generative lever.** The most powerful big ideas compress abstract, invisible, systemic phenomena into a single human-scale scene between specific people. Market dynamics → a specific doctor's negligence toward a specific patient. Compound interest → a specific daily habit with a specific future payoff. Diffuse risk → a specific moment of danger. When constructing Input 2, always ask: what single human-scale scene compresses the abstract phenomenon of Input 1?

9. **Completion is the most powerful force in the blend — engineer it deliberately.** The best big ideas put one precise element in the blend that automatically recruits a rich cognitive frame the reader already has. A single word like "malpractice" imports an entire legal and moral schema without the writer saying it. When selecting between Input 2 candidates, prioritize the one whose key frame element carries the richest automatic completion for the specific prospect.

10. **The double-scope test at the end of each candidate evaluation is mandatory.** For each candidate's blended space, state the organizational frame that governs it. Then check: is this frame present in Input 1 alone? Is it present in Input 2 alone? If the answer to both is no, you have a double-scope candidate. If the answer to either is yes, you have single-scope — still usable, but flag it.

---

## PURPOSE

A "big idea" in direct response is not a clever headline. It is not a strong benefit statement. It is not a vivid analogy. A big idea is a conceptual blend — a cognitive entity produced by fusing two input spaces in a way that generates emergent structure neither input possesses alone. The emergent structure IS the big idea: it is the new evaluative reality the blend creates in the reader's mind, changing how they perceive their situation, the villain, the solution category, and the urgency.

This skill constructs big ideas systematically, using Fauconnier & Turner's four-space model as the engineering framework. It is not a creativity tool — it is a construction tool. It does not wait for inspiration; it builds the architecture and lets the emergent structure emerge from the architecture.

The output is not a single headline. It is a ranked set of blend candidates, each with a full architectural specification and emergent structure map, plus a fully developed headline and lead for the top-ranked candidate.

---

## INPUT REQUIREMENTS

**Required:**
1. **Product description** — What does the product do? What specific transformation does it produce? What is the mechanism?
2. **Prospect situation** — Who is the prospect? What specific problem are they in? What have they tried? What do they believe about why they're stuck? What is the emotional state they're operating from?

**Highly recommended:**
3. **Known objections and beliefs** — What does the prospect currently believe about the problem, the solution category, and why prior solutions failed?
4. **Dominant desire** — What does the prospect most want? Not the product feature — the identity endpoint or life outcome.
5. **Existing big ideas in the market** — What are competitors using? This helps identify unoccupied blend territory.

---

## ENGINEERING PROCESS

### Step 1: Input 1 Precision Build

Before generating any Input 2 candidates, fully specify Input 1.

**Input 1 specification:**

*The prospect's circumstances:*
- Specific situation: [What exactly is happening to them]
- Failed attempts: [What they've tried and why it didn't work]
- Dominant belief about the problem: [Why they think they're stuck]
- Emotional state: [Not generic frustration — the specific texture: shame, anger, resignation, desperation, confusion]
- Stakes: [What happens if this isn't solved]

*The prospect's relationship to the product category:*
- What category does this product fall into as the prospect currently understands it?
- What associations does that category carry for them?
- What objections does that category trigger automatically?

*Input 1 frame inventory:*
What organizational structures exist in the prospect's situation that could contribute frame structure to a double-scope blend?
- Power relations: who has power over them in this situation?
- Causal structures: what forces are operating on them?
- Role structures: what role are they currently playing (victim, player, consumer, employee)?
- Temporal structures: are there deadlines, accumulation effects, or irreversibility at play?

---

### Step 2: Input 2 Candidate Generation

Generate 5–7 candidate Input 2 domains. For each candidate:
- Name the domain
- Identify why it has structural parallels to Input 1
- Identify the potential vital relation
- Flag whether it is likely to produce single-scope or double-scope

**Domain selection heuristic:** Start with domains where the prospect already has a rich, emotionally loaded cognitive frame. The richer the existing frame, the more powerful the completion leverage. Prioritize: medicine/health, law/justice, military/war, navigation/travel, ecology/biology, mechanics/engineering, finance/investment, architecture/construction. Do not default to war — it is overused and often produces weak completion leverage for non-competitive products.

**For each of the 5–7 candidates:**

---

**Candidate [N]: [Domain Name]**

*Structural parallel to Input 1:*
[What this domain shares structurally with the prospect's situation]

*Potential vital relation:*
[ROLE / CAUSE-EFFECT / IDENTITY / CHANGE / PART-WHOLE / SIMILARITY / INTENTIONALITY]

*Generic space (attempt):*
[State in abstract, content-free language what both domains share: "Both involve..."]

*Generic space viability assessment:*
- VIABLE: abstract structure is clear, neither too thin nor too obvious
- THIN: insufficient structural parallel — blend will feel forced
- EXHAUSTED: parallel is too obvious — everyone already knows this analogy
- INCOHERENT: the abstract description collapses into content from one input — generic space is not truly abstract

*Single-scope or double-scope potential:*
[SINGLE-SCOPE: Input 2 frame will likely dominate / DOUBLE-SCOPE POTENTIAL: both frames may contribute to a new organizational frame]

*Proceed to full blend construction?* [YES/NO]
*Reason for NO (if applicable):* [Why this candidate was eliminated at the generic space stage]

---

### Step 3: Full Blend Construction (Top 3 Viable Candidates)

For each of the 3 most viable candidates, complete the full construction:

---

**Full Blend: [Candidate Name]**

**Generic space (final articulation):**
[The abstract structure both inputs share — content-free]

**Selective projection — from Input 1:**
- Projected: [Elements of the prospect's situation that enter the blend]
- Suppressed: [Elements of Input 1 excluded and why]

**Selective projection — from Input 2:**
- Projected: [Elements of Input 2 domain that enter the blend]
- Suppressed: [Elements of Input 2 excluded and why — this is where bad projection decisions are made; be surgical]

**Vital relations in the blend:**
- Primary: [Which vital relation does the most structural work]
- Secondary (if any): [Supporting vital relations]

**Blended space construction:**
[Describe the cognitive entity that exists in the blended space — what does it look like? what relations hold within it?]

**Emergent structure inventory:**

| Emergent Element | In Input 1 Alone? | In Input 2 Alone? | Generated by |
|---|---|---|---|
| [Element A] | No | No | Composition/Completion/Elaboration |
| [Element B] | No | No | Composition/Completion/Elaboration |
| [Element C] | No | No | Composition/Completion/Elaboration |

**Completion leverage:**
- Key frame element imported: [The single element that does the most completion work]
- Automatic completions not stated: [Enumerated list of what the reader knows without being told]
- Completion leverage rating: LOW / MEDIUM / HIGH

**Elaboration potential:**
Run the blend forward: [What scenario emerges? What does the blend generate: villain? victim? mechanism? solution category? proof structure? CTA implication?]
- Elaboration potential rating: LOW / MEDIUM / HIGH

**Network type classification:**
[SIMPLEX / MIRROR / SINGLE-SCOPE / DOUBLE-SCOPE]
- If DOUBLE-SCOPE: State the organizational frame of the blended space. Confirm it is absent from both inputs.
- If SINGLE-SCOPE: Name the dominant frame and flag for potential upgrade via `fauconnier-double-scope-upgrader`.

**Optimality principle assessment:**
- Integration (coherent single entity): PASS / FAIL / PARTIAL
- Compression to human scale: PASS / FAIL / PARTIAL — What human-scale scene does this compress to?
- Good reason (no gratuitous projections): PASS / FAIL / PARTIAL

**Emergent structure score: [1–10]**
**Double-scope score: [N/A / Partial / Full]**

---

### Step 4: Candidate Ranking

Rank the 3 constructed blends by:
1. Emergent structure score (primary criterion)
2. Double-scope score (tiebreaker)
3. Completion leverage (secondary criterion)
4. Elaboration potential (tertiary criterion)
5. Optimality principle compliance (final check)

| Rank | Candidate | ES Score | DS Score | Completion | Elaboration | Optimality | Overall |
|---|---|---|---|---|---|---|---|
| 1 | [Name] | [1-10] | [N/A/P/F] | [L/M/H] | [L/M/H] | [Pass count] | [Grade] |
| 2 | [Name] | [1-10] | [N/A/P/F] | [L/M/H] | [L/M/H] | [Pass count] | [Grade] |
| 3 | [Name] | [1-10] | [N/A/P/F] | [L/M/H] | [L/M/H] | [Pass count] | [Grade] |

**Why Rank 1 wins:** [Specific comparison to Rank 2 — what does it have that Rank 2 doesn't]

---

### Step 5: Full Development of Top Candidate

**Headline development:**

The headline must be a blend compression — it must activate both input spaces simultaneously in a single statement. It should feel like a new category of claim, not a clever metaphor.

*Three headline variants for the top blend (ordered from most to least compressed):*

1. [Most compressed — assumes reader can complete the blend from minimal activation]
2. [Moderate compression — provides more framing without losing the blended charge]
3. [Most explicit — names both domains for readers who need both activated clearly]

**Recommended headline:** [Pick one and explain why]

**Lead development (first 150 words):**

The lead must demonstrate elaboration — the blend being run forward. It should:
- Open by activating the blended space (the first sentence establishes we are in the blend)
- Develop one elaboration chain (what happens in the blend when we push it forward)
- Plant the key completion element (the word or phrase that recruits the richest background frame)
- End with the prospect in the blend — feeling the emergent structure as their current reality

[Write the lead here]

**Body copy development path:**
Map how the blend elaborates through a full argument:
- Section 1 (Agitation): How does the blended scenario unfold to intensify the problem?
- Section 2 (Villain): What role does the villain play within the blended frame?
- Section 3 (Mechanism/Proof): What proof type is natural to the blended frame?
- Section 4 (Solution): How does the product enter the blended frame as the resolution?
- Section 5 (CTA): What action does the blended frame make feel urgent and obvious?

---

## CMT/BLENDING INTEGRATION NOTE

If all three constructed candidates are SINGLE-SCOPE (no double-scope candidates found):

This is not a failure — it is a diagnostic. Single-scope blends are the starting point for most strong copy. Use `fauconnier-double-scope-upgrader` on the top-ranked single-scope candidate to attempt the upgrade. The upgrade process: identify what organizational frame structure the prospect's Input 1 situation contributes back into the blend — if this can be projected into the blended space, a new organizational frame may emerge that is absent from both inputs.

For entailment management on the single-scope candidates, consult the Lakoff/Johnson skills (lakoff-* bundle). The Fauconnier bundle handles double-scope construction and emergent structure engineering; the Lakoff bundle handles source-domain selection and entailment mapping for single-scope metaphors.

---

## OUTPUT FILE

Save complete engineering report to:
`[project-folder]/Fauconnier & Turner - Big Idea Engineer/[Date] - Big Idea Engineering - [Product Name].md`
