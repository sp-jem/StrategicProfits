---
name: rogers-adoption-curve-mapper
description: Maps product on Rogers S-curve. Use when: launching or diagnosing growth stall.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Everett Rogers (Diffusion of Innovations, 1962; 5th edition 2003) — Skill 1 of 7"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/rogers-adoption-curve-mapper {product-or-offer-description}"
  called_by: [user, rogers-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Adoption position shifts as market awareness grows, competitors enter, and messaging evolves. A product can move from Early Adopter to Chasm territory in weeks. Reassess quarterly minimum, or after any significant market event."
thaler_integration:
  feeds_from: [thaler-choice-architect, thaler-default-auditor]
  feeds_to: [thaler-nudge-auditor]
  shared_data: "Choice architecture determines how adoption decisions are structured. Early Adopters tolerate complex choice environments; Early Majority needs simplified defaults and clear decision paths. Thaler's defaults are Rogers' compatibility requirements in disguise — the easier it is to say yes without thinking, the further down the adoption curve you can reach."
ariely_integration:
  feeds_from: [ariely-predictability-auditor, ariely-expectation-architect]
  feeds_to: [ariely-relativity-engine]
  shared_data: "Each adopter segment has different predictable irrationalities. Innovators are biased toward novelty (they overweight relative advantage). Early Majority is biased toward social proof and loss aversion (they overweight compatibility and observability). Ariely's anchoring effects shift as adoption progresses — early anchors are set by the innovation itself, later anchors by competitor positioning."
damasio_integration:
  feeds_from: [damasio-somatic-marker-audit]
  feeds_to: [damasio-emotion-decision-map]
  shared_data: "Somatic markers accumulated through past innovation experiences shape adoption willingness. Early Adopters have positive somatic markers around novelty — excitement, anticipation. Late Majority has negative somatic markers — anxiety, past disappointments with new things. The adoption curve is partly a map of accumulated emotional memories about change itself."
girard_integration:
  feeds_from: [girard-mimetic-audit, girard-desire-propagation]
  feeds_to: [girard-model-identification]
  shared_data: "Mimetic desire drives adoption modeling. Early Adopters model Innovators. Early Majority models Early Adopters — but ONLY after sufficient social proof accumulates. The adoption curve is a mimetic cascade: each segment needs visible models from the preceding segment before desire activates. Without visible adoption models, the cascade stalls."
veblen_integration:
  feeds_from: [veblen-signal-decoder, veblen-status-audit]
  feeds_to: [veblen-conspicuous-strategy]
  shared_data: "Innovation adoption carries status signals that change across the curve. Early adoption signals sophistication and risk tolerance (high status). Late adoption signals reliability and prudence (different status). When an innovation crosses into Early Majority, its status meaning inverts — from 'cutting edge' to 'smart choice.' Veblen's status dynamics explain WHY adopter segments adopt, beyond Rogers' functional explanations."
bourdieu_integration:
  feeds_from: [bourdieu-habitus-profiler, bourdieu-capital-audit]
  feeds_to: [bourdieu-field-analyzer]
  shared_data: "Adopter segments map roughly to capital configurations. Innovators typically possess high cultural and economic capital (they can afford to experiment). Late Majority often has constrained capital and habitus-driven conservatism. Bourdieu explains the CLASS structure underlying Rogers' adoption categories — why certain people are structurally positioned to adopt early or late."
loewenstein_integration:
  feeds_from: [loewenstein-curiosity-audit, loewenstein-visceral-audit]
  feeds_to: [loewenstein-information-flow]
  shared_data: "Curiosity and information gaps drive early adoption. Loewenstein's curiosity theory explains Innovators — they adopt because the information gap itself is motivating. As adoption progresses, curiosity gives way to risk assessment and visceral comfort. Late Majority adopts not from curiosity but from fear of being left behind — a visceral, not cognitive, motivation."
festinger_integration:
  feeds_from: [festinger-dissonance-audit]
  feeds_to: [festinger-commitment-escalation]
  shared_data: "Post-adoption confirmation is Rogers' Stage 5, and it maps directly to Festinger's dissonance reduction. Early Adopters who encounter problems reduce dissonance by becoming evangelists (justifying their risk). Late Majority who adopt reluctantly reduce dissonance by finding fault (justifying their delay). The same dissonance mechanism produces opposite behaviors at different points on the curve."
barthes_integration:
  feeds_from: [barthes-myth-decoder]
  feeds_to: [barthes-narrative-audit]
  shared_data: "Innovations carry mythological meaning that shifts across adoption stages. Early adoption myths: pioneering, discovery, being ahead. Mainstream adoption myths: wisdom, smart choice, joining the successful. Barthes reveals that adoption is never purely functional — buyers adopt the MEANING of the innovation as much as its features, and that meaning changes as the S-curve progresses."
mcluhan_integration:
  feeds_from: [mcluhan-medium-audit]
  feeds_to: [mcluhan-channel-strategy]
  shared_data: "The medium through which an innovation is communicated shapes adoption independent of the message content. Rogers identified mass media for awareness and interpersonal channels for persuasion. McLuhan adds: the FORM of the communication medium itself signals which adopter segment is being addressed. A podcast signals different adoption norms than a TikTok video, regardless of identical content."
mccracken_integration:
  feeds_from: [mccracken-meaning-transfer-audit]
  feeds_to: [mccracken-cultural-positioning]
  shared_data: "McCracken's meaning transfer model explains HOW innovations acquire cultural meaning as they move through adopter segments. The culturally constituted world assigns meaning to innovations through advertising, fashion systems, and opinion leaders — the same channels Rogers identified for diffusion. Adoption is meaning acquisition as much as functional acquisition."
granovetter_integration:
  feeds_from: [granovetter-weak-ties-audit]
  feeds_to: [granovetter-bridge-strategy]
  shared_data: "Granovetter's weak ties are the bridges between adopter segments. Strong ties connect people within a segment (Innovators know Innovators). Weak ties connect ACROSS segments (an Early Adopter's casual acquaintance in the Early Majority). Diffusion across the chasm requires activating weak ties — the bridges that carry information between socially distant groups."
barabasi_integration:
  feeds_from: [barabasi-network-audit]
  feeds_to: [barabasi-hub-strategy]
  shared_data: "Barabasi's scale-free network model reveals that adoption doesn't spread evenly — it spreads through hubs. A small number of highly connected nodes in each adopter segment drive the majority of diffusion. Identifying and activating these hubs is more efficient than broad outreach. The adoption S-curve's shape is a function of network topology, not just individual decision-making."
---

# Rogers Adoption Curve Mapper

---

## LAYER 1: INVARIANTS (Never override.)

1. **The adoption curve is a population model, not a marketing funnel.** Rogers' S-curve describes how an innovation moves through an entire social system over time. The five segments — Innovators (2.5%), Early Adopters (13.5%), Early Majority (34%), Late Majority (34%), Laggards (16%) — are defined by their relationship to uncertainty, not by demographics or psychographics. Every assessment must identify which segment is CURRENTLY being reached based on their behavioral characteristics, not assumed based on marketing intent.

2. **Each adopter segment requires fundamentally different messaging, proof, and risk mitigation.** Innovators want novelty and are comfortable with incomplete information. Early Adopters want strategic advantage and tolerate risk for vision. Early Majority wants proven solutions with social proof. Late Majority wants standardized, risk-free options with peer pressure. Laggards want tradition-compatible solutions with no perceived risk. Marketing that works for one segment ACTIVELY REPELS another. This skill must identify segment-message mismatches.

3. **Adoption velocity is diagnostic, not decorative.** The SPEED at which adoption is progressing reveals whether the innovation has product-market fit for the current segment. Stalled velocity means the current segment is exhausted OR the next segment's requirements aren't being met. Accelerating velocity means the innovation is successfully bridging to the next segment. Velocity must be measured and interpreted.

4. **The adoption curve is not linear — it has structural breaks.** The transition between Early Adopters and Early Majority (the "chasm") is the most dangerous structural break, but transitions between ALL segments involve friction. Each transition requires deliberate strategy, not natural momentum. The assessment must identify which transition the business is approaching and what friction exists.

5. **Re-invention is normal and healthy, not failure.** Rogers documented that adopters consistently modify innovations to fit their context. As adoption spreads, the innovation itself changes. A business that resists re-invention by later adopters is fighting the natural diffusion process. The assessment must evaluate whether the business is allowing appropriate re-invention.

---

## LAYER 2: QUALITY GUIDANCE

6. **Ground every segment identification in observable behavior.** "We think we're reaching Early Adopters" is assumption. "Our buyers find us through niche communities, tolerate our beta-quality onboarding, and need minimal social proof" is evidence. Identify segments by what buyers DO, not what the business hopes.

7. **Compare adoption velocity to category norms.** "We've acquired 500 users in 6 months" means nothing without context. For enterprise SaaS, that might be excellent. For a consumer app, it might signal stalled adoption. Always benchmark against category expectations.

8. **Make the next-segment requirements specific and actionable.** "You need more social proof" is generic. "Early Majority in this category requires 3+ case studies from recognizable companies, a guarantee that reduces switching risk, and a simplified onboarding that doesn't require technical sophistication" is actionable.

---

## PURPOSE

Every innovation follows a predictable path through a social system — or dies trying. Most businesses have no idea where they sit on that path. They market to everyone, speak to no one's specific adoption concerns, and wonder why growth stalls after the initial burst of enthusiastic early customers.

Rogers' adoption curve is the diagnostic framework. Given THIS product, THIS market, THIS adoption history, and THESE buyer characteristics — where exactly is this innovation on the S-curve? Which segment is currently being served? Is the business ready for the next segment? What specific changes are required to reach them?

This skill produces a precise adoption position assessment with specific next-segment requirements.

---

## INPUT REQUIREMENTS

Provide:
1. **The product/offer/innovation** — what it is, what it replaces, how long it's been in market
2. **Current buyer characteristics** — who is buying, how they find you, what convinces them
3. **Adoption metrics** — growth rate, total users/customers, time in market

Optional:
- Competitor adoption data (reveals category norms)
- Churn/satisfaction data (reveals confirmation stage dynamics)
- Marketing channel mix (reveals communication strategy alignment)
- Customer acquisition history over time (reveals adoption velocity curve)

---

## EXECUTION PROCESS

### Step 1: Current Segment Identification

Analyze buyer behavior against Rogers' segment definitions:

**Innovator indicators (2.5%):**
- Buyers tolerate significant product imperfections
- Buyers find the product through technical/niche channels
- Buyers require minimal social proof — novelty itself is sufficient
- Buyers are comfortable with complexity
- Buyers provide extensive feedback and suggest features

**Early Adopter indicators (13.5%):**
- Buyers see strategic/competitive advantage in adoption
- Buyers are opinion leaders in their networks
- Buyers tolerate moderate imperfections for vision alignment
- Buyers want to be seen as innovative
- Buyers actively share their adoption with peers

**Early Majority indicators (34%):**
- Buyers require substantial social proof before purchasing
- Buyers want proven, documented results
- Buyers need simplified onboarding and low complexity
- Buyers compare extensively before deciding
- Buyers follow peers rather than lead

**Late Majority indicators (34%):**
- Buyers adopt only after the majority has
- Buyers are motivated by fear of being left behind, not excitement
- Buyers need maximum risk reduction (guarantees, standards compliance)
- Buyers require peer pressure or institutional mandates
- Buyers resist change and need hand-holding

**Laggard indicators (16%):**
- Buyers adopt only when the previous approach is no longer available
- Buyers are tradition-oriented
- Buyers have the longest decision-making timeline
- Buyers want the innovation to be indistinguishable from the familiar

For each indicator: present/absent/partial — with evidence.

### Step 2: Adoption Velocity Assessment

Calculate and interpret adoption speed:

**Metrics:**
- Total adopters vs. time in market
- Growth rate by period (monthly, quarterly)
- Growth rate trend (accelerating, steady, decelerating)
- Comparison to category norms for this innovation type

**Velocity interpretation:**
- **Accelerating:** Successfully penetrating current segment or bridging to next
- **Steady:** Stable adoption within current segment
- **Decelerating:** Current segment saturating, or failing to bridge to next
- **Stalled:** Innovation has hit a structural barrier (likely a segment transition)

**Calculate approximate position on S-curve:**
- What percentage of the addressable market has adopted?
- Where does this fall on the cumulative adoption curve?
- How does current velocity predict time to next segment transition?

### Step 3: Segment Saturation Analysis

Determine how much of the current segment has been captured:

**For each segment the business has passed through:**
- Estimated segment size (total addressable within that category)
- Estimated penetration within that segment
- Remaining opportunity within that segment
- Signs of saturation (declining response rates, higher CAC, smaller deal sizes)

**Key diagnostic:** If the current segment is saturating but the business hasn't prepared for the next segment's requirements, growth will stall regardless of marketing effort within the current segment.

### Step 4: Next Segment Requirements Gap

Identify what the next adopter segment needs that the current offering doesn't provide:

**For each requirement category:**
- **Relative Advantage:** Is the advantage clear enough for the next segment? (Early Majority needs obvious, quantified advantage — not visionary potential)
- **Compatibility:** Does the innovation fit the next segment's existing workflows, values, and vocabulary?
- **Complexity:** Is the innovation simple enough for the next segment? (Each subsequent segment tolerates less complexity)
- **Trialability:** Can the next segment try before committing? (Risk tolerance decreases with each segment)
- **Observability:** Can the next segment SEE results from the current segment? (Social proof requirements increase)

**Gap assessment for each:**
- Current state
- Required state for next segment
- Specific changes needed
- Difficulty of change (Easy / Medium / Hard)

### Step 5: Communication Channel Alignment

Assess whether current channels match the adoption stage:

**Rogers' channel principle:**
- Mass media channels create AWARENESS (reach new segments)
- Interpersonal channels create PERSUASION (convert within segments)
- The mix must shift as adoption progresses

**Current channel audit:**
- Which channels are currently used?
- Are they awareness channels or persuasion channels?
- Do they reach the CURRENT segment or the NEXT segment?
- Are interpersonal influence channels being activated? (Referrals, communities, opinion leaders)

**Channel-segment mismatch indicators:**
- Using interpersonal channels for awareness (too slow, too narrow)
- Using mass media channels for persuasion (too impersonal for risk reduction)
- Marketing only to the current segment while needing to bridge to the next

### Step 6: Re-Invention Assessment

Evaluate whether and how adopters are modifying the innovation:

**Re-invention indicators:**
- Are users using the product differently than intended?
- Are different segments using different features or workflows?
- Has the product's positioning or meaning changed as adoption spread?
- Is the business fighting re-invention or enabling it?

**Re-invention health check:**
- Healthy re-invention: Adopters adapt the innovation to fit their context, expanding use cases
- Unhealthy resistance: Business insists on original vision while market demands adaptation
- Unhealthy drift: Innovation loses coherence as re-invention fragments the product identity

### Step 7: Competitive & Category Context

Assess how category dynamics affect adoption position:

**Category maturity:**
- Is this a new category (no established alternatives) or existing category (replacing incumbents)?
- What is the category's typical adoption curve shape?
- Where are competitors on their respective curves?

**Competitive pressure effects:**
- Are competitors accelerating adoption across the category? (Rising tide)
- Is a competitor ahead on the curve, pulling the market forward?
- Is there competitive fragmentation splitting the adopter base?

### Step 8: Strategic Recommendations

Synthesize into prioritized actions:

**For each recommendation:**
- **Adoption barrier addressed:** Which segment gap or transition friction
- **Current state:** What's happening now
- **Recommended change:** Specific action
- **Mechanism:** Why this works in Rogers' terms
- **Expected impact on adoption velocity:** Direction and rough magnitude
- **Implementation difficulty:** Easy / Medium / Hard
- **Priority:** Impact x ease ranking

**Segment transition strategy:**
- If approaching a transition: what must change before attempting to cross
- If stuck in a transition: what's blocking the crossing
- If recently crossed: what needs to consolidate the new segment before pushing further

---

## OUTPUT STRUCTURE

### Adoption Curve Position Report

**Section 1: Current Segment Identification**
Behavioral evidence for which segment is currently being served.

**Section 2: Adoption Velocity Assessment**
Speed, trend, and comparison to category norms.

**Section 3: Segment Saturation Analysis**
How much of the current segment is captured and remaining opportunity.

**Section 4: Next Segment Requirements Gap**
What must change across all five innovation attributes to reach the next segment.

**Section 5: Communication Channel Alignment**
Whether channels match the adoption stage and segment.

**Section 6: Re-Invention Assessment**
How adopters are modifying the innovation and whether this is healthy.

**Section 7: Competitive & Category Context**
How category dynamics affect the adoption position.

**Section 8: Cross-System Integration**
If other thinker data exists: How do adoption dynamics interact with choice architecture (Thaler), predictable irrationality (Ariely), mimetic desire (Girard), status signaling (Veblen), and network structure (Granovetter/Barabasi)?

**Section 9: Strategic Recommendations**
All interventions prioritized by impact on adoption velocity.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Everett Rogers - Adoption Curve Mapper/01 - Adoption Curve Position - [Product Name] - [Date].md`
