---
name: deutsch-proof-staging-diagnostic
description: Pre-write or post-write classifier that audits every proof element in a copy piece — assigning it to informational or normative pathway, checking preconditions, scoring proof-paradox risk, and recommending proof type swaps. The master gatekeeper for all downstream Deutsch/Gerard tools.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Morton Deutsch & Harold Gerard (Informational vs. Normative Social Influence) — Idea 1"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/deutsch-proof-staging-diagnostic {copy-or-proof-section}"
  called_by: [user, deutsch-field-intelligence]
  outputs_to: [project-folder]
depends_on: []
---

# Deutsch Proof Staging Diagnostic

---

## LAYER 1: INVARIANTS (Never override.)

1. **Two mechanistically distinct pathways — not a spectrum.** Informational influence and normative influence are not more or less of the same thing. They differ in mechanism, activation conditions, required inputs, and output durability. Informational influence: the prospect accepts others' behavior or testimony as evidence about reality → genuine private belief change → durable conversion. Normative influence: the prospect conforms to gain approval or avoid rejection → public compliance only → temporary behavior, no LTV. Treat them as qualitatively distinct at all times.

2. **The diagnostic precedes all proof decisions.** Every decision about what type of proof to use, how to frame it, where to place it, and how much to use it depends on whether the proof element is primarily informational or normative. Classification comes before all copy decisions about proof. Never let proof choices be made without running this diagnostic first.

3. **Classify primary pathway, not exclusive pathway.** In naturalistic settings, most proof elements activate both pathways to some degree. A testimonial from a recognized expert is simultaneously informational (they have credibility as an evidence source) and normative (belonging to the group of people who chose this). Classify the PRIMARY pathway for each element — the one doing the load-bearing conversion work — and note secondary activation. Do not attempt to force clean separation.

4. **Precondition check is non-negotiable.** Each pathway has hard preconditions that must be met for the influence to fire. Informational: source must have perceived expertise or relevant experience; claim must be framed as evidence about reality, not social consensus; ambiguity about the correct choice must be present. Normative: response must be observable (public-response condition); reference group must be the prospect's in-group; in-group identity must be activated before the normative proof appears. Skipping precondition checks produces inaccurate pathway assignments.

5. **The proof paradox risk score is mandatory for every diagnostic.** For any copy targeting sophisticated, skeptical, or "I think for myself" audiences, the proof paradox is the primary failure risk: normative proof volume triggers Brehm reactance, conversion drops despite (or because of) high proof load. Every diagnostic output must include a proof paradox risk score (LOW / MEDIUM / HIGH / CRITICAL) with explicit reasoning. This is never optional.

---

## LAYER 2: QUALITY GUIDANCE

6. **Volume is not the same as weight.** Three testimonials with high informational specificity (credential + outcome + mechanism) outweigh twenty testimonials with zero informational value for skeptical audiences. The diagnostic assesses proof weight per element and total weight by pathway, not headcount.

7. **Context determines pathway efficiency.** The same proof element may operate primarily as informational influence in a private-browsing/anonymous context (where normative pathway is deactivated by absence of observability) and primarily as normative influence in a community/event context (where observability activates the normative pathway). Diagnose pathway for the actual purchase context, not the default assumption.

8. **Cialdini distinction:** Cialdini's "social proof" principle synthesizes both pathways at the surface level. The existing cialdini-* bundle is the application layer. This diagnostic operates at the foundational mechanism layer — it has proof-staging diagnostic depth that Cialdini's framework does not provide. Do not substitute Cialdini's heuristics for pathway analysis.

---

## PURPOSE

Most proof sections are built by accumulation — more testimonials, more credentialing, more social proof. The result is a section that may be doing normative work (pressuring conformity) when the audience requires informational work (evidence about reality), or vice versa. The pathway mismatch explains why high-proof-volume approaches often underperform in premium markets.

This diagnostic classifies every proof element before it is deployed (or audits it post-write), maps the pathway mix of the entire proof section, checks preconditions for each pathway, calculates proof paradox risk, and recommends specific swaps where the proof type does not match the audience context or business model requirements.

---

## INPUT REQUIREMENTS

Provide one of the following:
1. **The proof section itself** — any format (testimonials, case studies, credentials, statistics, expert citations)
2. **The full copy piece** — diagnostic will identify and isolate all proof elements
3. **A proof planning brief** — what proof elements you are considering before writing

Also provide (required for accurate diagnosis):
- **Audience sophistication level:** Low / Medium / High / Expert-skeptic
- **Audience self-image:** Does the prospect identify as independent-minded, analytical, "I don't follow crowds"?
- **Purchase context:** Public/community (normative pathway available) or Private/anonymous (normative pathway reduced)?
- **Business model LTV requirement:** Single-purchase / Continuity / High-ticket / Referral-dependent?

---

## EXECUTION PROCESS

### Step 1: Proof Element Inventory
Catalog every proof element in the copy. For each, record:
- Type (testimonial / case study / credential / statistic / expert citation / certification / award / social count / press mention / other)
- Source identity (who is vouching or what body of evidence is cited)
- Specific claim made
- Mechanism explanation present? (Yes / No)

### Step 2: Primary Pathway Classification
For each proof element, assign primary pathway:

**Informational indicators:**
- Source has specific verifiable credentials or directly relevant experience
- Claim includes specific quantified outcome with attribution
- Mechanism explanation is present (why/how the outcome occurred)
- Proof is framed as evidence about reality, not as social consensus
- Claim would be persuasive even to an anonymous reader who could not be observed

**Normative indicators:**
- Proof relies primarily on number of people, popularity, or group consensus
- Source's primary value is identity relevance, not expertise
- Proof requires the prospect to imagine being part of the crowd
- Proof depends on the purchase context being visible or social to function
- Claim would lose most of its force in a private/anonymous context

Assign: [INFORMATIONAL / NORMATIVE / MIXED — PRIMARY: X]

### Step 3: Precondition Check
For each proof element, verify the preconditions for its primary pathway:

**Informational preconditions:**
- [ ] Source credibility: Does the source have perceived expertise or directly relevant experience? (Missing = informational proof will be discounted or ignored)
- [ ] Specificity: Is the outcome specific and quantified, or vague and generic? (Generic = low informational value, slides toward normative)
- [ ] Mechanism: Is there an explanation of why/how the outcome occurred? (Missing = proof lacks the evidence-about-reality weight; sophisticated buyers discount)
- [ ] Ambiguity activation: Is there genuine uncertainty in the prospect's mind about the correct choice? (If no uncertainty, informational influence has no purchase)

**Normative preconditions:**
- [ ] In-group identity activated: Has copy preceding this proof element established that the reference group is the prospect's group? (Missing = HARD FAILURE — normative proof cannot fire without in-group priming)
- [ ] Public-response context: Is this a community/event/visible-purchase context where observability is present? (Private context = normative pathway structurally weakened)
- [ ] Group specificity: Is the reference group specific enough to be identity-relevant? ("40,000 entrepreneurs" vs "17,000 independent financial advisors running $5M+ books")

### Step 4: Proof Section Profile
Aggregate the element-level analysis:
- Total proof elements: [N]
- Informational elements: [N] ([%])
- Normative elements: [N] ([%])
- Mixed elements: [N] ([%])
- Precondition failures: [list each failure with element and missing precondition]

### Step 5: Proof Paradox Risk Score
Assess the overall proof paradox risk for this copy + audience combination:

**Risk factors (each raises the score):**
- Audience sophistication = High or Expert-skeptic
- Audience self-image includes independent thinking or analytical identity
- Purchase context is private/anonymous
- Normative elements represent >60% of total proof elements
- Normative elements lack in-group specificity (generic crowds)
- Normative element count is high (10+) with low diversity of source types
- Offer is high-ticket (>$1,000) — premium price implies premium buyer judgment
- Product/service category involves identity or personal values

**Risk levels:**
- LOW: 0-2 risk factors — normative proof load is appropriate
- MEDIUM: 3-4 risk factors — normative elements should be reduced and specificity increased
- HIGH: 5-6 risk factors — normative elements should be replaced with informational elements; proof-paradox language recommended
- CRITICAL: 7+ risk factors — normative proof is actively harming conversion; immediate restructure required; deploy proof-paradox acknowledgment copy

### Step 6: Recommendations
For each precondition failure and for any HIGH/CRITICAL proof paradox risk:

**Element-level fixes:**
- Element: [identifier]
- Failure: [specific precondition not met]
- Fix: [specific action — add mechanism explanation, narrow reference group, move normative element after in-group activation, etc.]

**Section-level restructure (if risk is HIGH or CRITICAL):**
- Replace [specific normative elements] with informational equivalents using the three-part structure: credential + specific outcome + mechanism
- Add in-group activation sequence BEFORE first normative element
- If proof paradox risk is CRITICAL: add explicit skeptic-acknowledgment copy ("You probably don't make decisions based on what thousands of others did — here's the evidence instead")
- Volume ceiling recommendation: for HIGH/CRITICAL audiences, cap normative proof at [N] elements and lead with informational

---

## OUTPUT STRUCTURE

### Proof Staging Diagnostic Report

**Header:**
- Copy analyzed: [title or description]
- Audience profile: [sophistication level + self-image]
- Purchase context: [public/community vs. private/anonymous]
- Business model LTV requirement: [stated]
- Date: [YYYY-MM-DD]

**Section 1: Proof Element Inventory**
Table of all proof elements with type, source, primary pathway, and precondition status.

| # | Element | Type | Source | Primary Pathway | Preconditions Met | Notes |
|---|---------|------|--------|-----------------|-------------------|-------|

**Section 2: Proof Section Profile**
Aggregate counts and percentages. List all precondition failures.

**Section 3: Proof Paradox Risk Score**
[LOW / MEDIUM / HIGH / CRITICAL] — risk factors present, explicit reasoning.

**Section 4: Element-Level Fixes**
Specific corrections for each precondition failure.

**Section 5: Section-Level Recommendations**
If proof paradox risk is MEDIUM or above: restructure recommendations, volume ceiling, in-group sequencing fix, proof-paradox acknowledgment copy (if CRITICAL).

**Section 6: Downstream Skill Routing**
Based on the diagnostic findings, route to:
- `deutsch-informational-proof-builder` — if informational elements are needed but underdeveloped
- `deutsch-normative-proof-builder` — if normative elements are present but lack in-group specificity or observability framing
- `deutsch-proof-paradox-auditor` — if proof paradox risk is HIGH or CRITICAL (deeper audit)
- `deutsch-pathway-durability-analyzer` — if LTV implications of the current proof mix need explicit projection

---

## OUTPUT FILE

Save complete diagnostic to:
`[project-folder]/Deutsch & Gerard - Proof Staging/[YYYY-MM-DD] - Proof Staging Diagnostic - [Copy Name].md`
