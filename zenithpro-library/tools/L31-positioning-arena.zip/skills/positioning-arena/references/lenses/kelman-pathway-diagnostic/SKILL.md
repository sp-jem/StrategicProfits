---
name: kelman-pathway-diagnostic
description: Pre-write diagnostic that identifies which Kelman pathway(s) a copy piece is engineering, surfaces technique-pathway mismatches, and recommends corrections. The meta-skill that governs all other Kelman tools.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Herbert Kelman (Compliance/Identification/Internalization) — Idea 1"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/kelman-pathway-diagnostic {copy-to-diagnose}"
  called_by: [user, kelman-field-intelligence]
  outputs_to: [project-folder]
---

# Kelman Pathway Diagnostic

---

## LAYER 1: INVARIANTS (Never override.)

1. **Three qualitatively distinct processes — not points on a continuum.** Compliance, identification, and internalization are qualitatively different types of attitude change. They are not more or less of the same thing. Treat them as distinct mechanisms with distinct activation conditions, distinct decay conditions, and distinct LTV outputs. A diagnosis that treats them as a spectrum has misread Kelman.

2. **Diagnose the load-bearing pathway, not all pathways present.** A single copy piece may activate more than one process simultaneously. A celebrity testimonial may produce compliance (social proof), identification (admiration), and internalization (values alignment) at once. The diagnostic question is: WHICH process is load-bearing — which one is doing the primary conversion work? Report all pathways present but identify the dominant one.

3. **Technique-pathway match is mandatory.** Every persuasion technique has a primary pathway it activates. Scarcity activates compliance. Personality foregrounding activates identification. Values-surfacing content activates internalization. A mismatch — using identification techniques for a business model that requires internalization-level LTV — is the primary failure mode this skill exists to catch. Never skip the mismatch check.

4. **The 2006 reframe must be applied.** Every pathway diagnosis must also be stated in Kelman's 2006 interests/relationships/identities vocabulary: Compliance = interest-level appeal. Identification = relationship-level appeal. Internalization = identity-level appeal. This reframe sharpens the diagnosis and connects it to offer-depth architecture.

5. **Kelman's "identification" (dyadic — person to source) is not Tajfel/Turner's "social identification" (categorical — person to group).** When diagnosing identification-pathway activity, determine whether the mechanism is dyadic (prospect wants to relate to a specific person or brand) or categorical (prospect self-categorizes as belonging to a group). Dyadic identification = Kelman. Categorical group identification = Tajfel/Turner. Route group-membership identification analysis to the tajfel-* bundle. Do NOT treat them as the same mechanism.

---

## LAYER 2: QUALITY GUIDANCE

6. **Compliance is not the villain.** A common misreading of Kelman is that compliance is "bad" and internalization is "good." Kelman does not say this. Compliance is appropriate when the business model does not require high LTV — single-purchase, volume-transaction contexts. The diagnostic must match pathway to business model, not rank pathways on a moral scale.

7. **Agent framing determines pathway before technique does.** Per Kelman (1958): the perceived characteristics of the agent of influence — power/control (→ compliance), attractiveness/identity relevance (→ identification), credibility/information quality (→ internalization) — are the architectural decision that precedes all technique choices. Diagnose agent framing first, then diagnose technique selection.

8. **Pathway migration is the highest-LTV lever.** The most commercially powerful application of the Kelman framework is not identifying the pathway but designing the post-acquisition migration path: compliance → identification → internalization. Flag migration architecture as a separate recommendation track in the output.

---

## PURPOSE

Most copy review focuses on persuasion elements — hooks, proof, CTAs, flow, offer presentation. All of these matter. But they don't explain why copy with strong elements produces low-LTV buyers, or why simple copy with no visible "tactics" produces multi-year clients who refer constantly.

The pathway architecture — which of Kelman's three processes is load-bearing, whether the agent framing supports that process, whether the persuasion techniques match the intended pathway — operates underneath all surface-level copy elements and often determines buyer quality more than any of them.

This diagnostic runs before writing (or as a post-write audit) to identify which pathway is being engineered, whether that pathway matches the business model's LTV requirements, and what specific changes would correct a mismatch.

---

## INPUT REQUIREMENTS

Provide one of the following:
1. **The copy itself** (draft or live) — any length, any format
2. **A description of the copy's structure** — agent framing, main persuasion techniques, proof type, CTA structure
3. **The copy brief** — who the prospect is, what the offer is, how the agent (brand/founder/institution) is positioned

Also provide (required for business-model matching):
- **Business model type:** Single-purchase / Continuity / High-ticket / Referral-dependent / Community/membership
- **Target LTV:** What buyer tenure and behavior does this offer require to be profitable?

---

## EXECUTION PROCESS

### Step 1: Agent Framing Audit
Before examining techniques, identify how the copy frames the source's perceived characteristics:
- Does it foreground power/control (ability to deliver or withhold reward, scarcity, authority, normative social pressure)? → Compliance activation
- Does it foreground attractiveness, personality, identity relevance, community belonging? → Identification activation
- Does it foreground credibility, expertise, evidence quality, information reliability? → Internalization activation
- Mixed or unclear framing? → Identify which framing is loudest and whether it is intentional

### Step 2: Technique Inventory
Catalog every persuasion technique present. Assign each a primary pathway:

| Compliance Techniques | Identification Techniques | Internalization Techniques |
|----------------------|--------------------------|---------------------------|
| Countdown timers | Founder personality foregrounding | Values-surfacing lead |
| "Only X spots/units" | "People like us" framing | "You've always believed that..." framing |
| Fear-based authority | In-group vocabulary | Product as natural self-extension |
| Normative social proof | Community belonging architecture | Evidence of values-consistency over time |
| Loss framing | Testimonials foregrounding relationship to brand/mentor | Proof of congruence with prospect's existing values |
| Urgency pressure | Celebrity/personality endorsement (dyadic) | Philosophy/worldview statement before offer |

### Step 3: Pathway Identification
State the dominant pathway (load-bearing process) and any secondary pathways present. Apply the 2006 reframe:
- Dominant pathway: [Compliance / Identification / Internalization]
- 2006 vocabulary equivalent: [Interests / Relationships / Identities]
- Secondary pathways present: [list, if any]

### Step 4: Business Model Match Test
Compare the dominant pathway to the LTV requirements of the stated business model:
- Compliance → appropriate for single-purchase, volume-transaction; MISMATCHED for continuity/high-ticket/referral-dependent
- Identification → appropriate for personal brand, coaching, community-based; MISMATCHED where relationship salience cannot be maintained
- Internalization → appropriate for high-LTV, continuity, adjacent-offer generalization; only available in high-involvement categories

Verdict: [MATCHED / MISMATCHED / PARTIALLY MATCHED] + reasoning

### Step 5: Mismatch Correction (if applicable)
For each mismatch identified, produce a specific correction:
- What technique or framing to remove/change
- What to replace it with and why it activates the correct pathway
- How to reframe the agent's perceived characteristics to support the intended pathway

### Step 6: Pathway Migration Recommendation
Regardless of whether the current copy is matched, assess: Is a post-sale migration architecture needed? If the business model benefits from moving buyers up the pathway stack (compliance → identification → internalization), outline the migration sequence.

---

## OUTPUT STRUCTURE

### Diagnostic Report

**Header:**
- Copy analyzed: [title or description]
- Business model: [stated type]
- Target LTV: [stated]
- Date: [YYYY-MM-DD]

**Section 1: Agent Framing**
What perceived characteristics does this copy construct for the source, and what pathway does that framing prime?

**Section 2: Pathway Identification**
- Load-bearing pathway: [Compliance / Identification / Internalization]
- 2006 reframe: [Interests / Relationships / Identities]
- Supporting evidence: [specific elements from the copy]
- Secondary pathways: [present or absent]
- Group identification note: If any identification-pathway elements appear to rely on categorical group membership (prospect identifying with a group type rather than a specific source), flag for Tajfel/Turner analysis rather than treating as Kelmanite dyadic identification.

**Section 3: Business Model Match**
Verdict: [MATCHED / MISMATCHED / PARTIALLY MATCHED]
- What the current pathway predicts for buyer LTV and behavior
- What the business model requires
- Gap analysis if mismatched

**Section 4: Mismatch Corrections** (if applicable)
For each mismatch:
- Element to change: [specific technique or framing]
- Replacement: [specific alternative]
- Pathway activated by replacement: [which process and why]

**Section 5: Migration Architecture Recommendation**
- Is a post-sale migration sequence needed? [Yes/No]
- If yes: Suggested migration pathway and key content interventions at each stage

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Herbert Kelman - Pathway Diagnostics/[YYYY-MM-DD] - Pathway Diagnostic - [Copy Name].md`
