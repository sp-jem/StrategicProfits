---
name: rogers-innovation-attributes-auditor
description: Scores offer on Rogers 5 adoption attributes. Use when: diagnosing adoption.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Everett Rogers (Diffusion of Innovations, 1962; 5th edition 2003) — Skill 3 of 7"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/rogers-innovation-attributes-auditor {offer-or-product-description}"
  called_by: [user, rogers-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  reason: "Attribute scores shift as products evolve, competitors enter, and market expectations change. A complexity score that was acceptable six months ago may be unacceptable now because a competitor simplified their offering. Reassess quarterly or after significant product or market changes."
thaler_integration:
  feeds_from: [thaler-choice-architect, thaler-nudge-auditor]
  feeds_to: [thaler-default-detector]
  shared_data: "Thaler's choice architecture directly affects perceived complexity and trialability. Smart defaults reduce complexity. Opt-out framing increases trialability. Nudges can improve compatibility by making the innovation feel like the natural next step rather than a disruption. Rogers' attributes are the WHAT to optimize; Thaler's architecture is one of the HOWs."
ariely_integration:
  feeds_from: [ariely-relativity-engine, ariely-expectation-architect]
  feeds_to: [ariely-predictability-auditor]
  shared_data: "Relative advantage is perceived, not objective — and Ariely shows that perception is systematically distorted. Anchoring effects change perceived advantage. Expectation effects change perceived experience. The FREE effect can make trialability irresistible. Each of Rogers' five attributes is filtered through Ariely's predictable irrationalities before it influences adoption."
damasio_integration:
  feeds_from: [damasio-somatic-marker-audit, damasio-emotion-feeling-mapper]
  feeds_to: [damasio-body-loop-auditor]
  shared_data: "Each of Rogers' five attributes triggers somatic responses that operate below conscious evaluation. Complexity triggers anxiety markers (body tightens, breathing shallows). Compatibility triggers comfort markers (relaxation, familiarity). Observability triggers social safety markers (seeing others succeed reduces visceral threat). The attribute audit must account for these embodied responses, not just cognitive evaluations."
girard_integration:
  feeds_from: [girard-model-map, girard-desire-propagation]
  feeds_to: [girard-mimetic-content-strategist]
  shared_data: "Observability is mimetic desire made visible. When adopters can SEE others benefiting, mimetic desire activates — they want what models have. Relative advantage is meaningful only relative to what mimetic models currently use. Girard reveals that Rogers' attributes are not evaluated in isolation — they're evaluated through the lens of what desired models are doing."
veblen_integration:
  feeds_from: [veblen-signal-decoder, veblen-display-map]
  feeds_to: [veblen-price-ladder]
  shared_data: "Relative advantage includes status advantage, not just functional advantage. Observability includes status visibility — can others SEE that you've adopted? Compatibility includes compatibility with desired social position. Veblen adds the status dimension to every one of Rogers' five attributes, revealing that adoption decisions are as much about social positioning as practical utility."
bourdieu_integration:
  feeds_from: [bourdieu-habitus-profiler, bourdieu-capital-audit]
  feeds_to: [bourdieu-distinction-mapper]
  shared_data: "Compatibility is habitus compatibility. An innovation that conflicts with internalized dispositions — regardless of its objective merits — will score low on compatibility for that audience. Complexity is relative to cultural capital — what seems simple to high-capital buyers seems impenetrable to others. Bourdieu reveals that attribute scores are SEGMENT-SPECIFIC, varying by social position."
loewenstein_integration:
  feeds_from: [loewenstein-curiosity-architect, loewenstein-visceral-audit]
  feeds_to: [loewenstein-information-flow]
  shared_data: "Trialability satisfies curiosity while reducing visceral risk. Loewenstein's information gap theory explains why trialability works — it lets prospects close the curiosity gap (what would this be like?) without triggering the visceral fear of commitment. High complexity widens the information gap in threatening ways; high observability narrows it reassuringly."
festinger_integration:
  feeds_from: [festinger-dissonance-detector, festinger-commitment-architect]
  feeds_to: [festinger-post-decision-engineer]
  shared_data: "Compatibility is partly about dissonance avoidance. Innovations that conflict with existing beliefs, values, and self-concept create pre-adoption dissonance that blocks decision-making. High compatibility means low cognitive dissonance required to adopt. Post-adoption, low observability creates confirmation anxiety — adopters can't SEE results, which prevents dissonance resolution and may trigger buyer's remorse."
barthes_integration:
  feeds_from: [barthes-myth-decoder, barthes-connotation-mapper]
  feeds_to: [barthes-signal-archaeology]
  shared_data: "Each attribute carries mythological meaning beyond its functional description. 'Relative advantage' connotes progress and improvement (modernization myth). 'Compatibility' connotes belonging and safety (tradition myth). 'Complexity' connotes either sophistication (positive myth) or exclusion (negative myth). Barthes reveals the semiotic layer operating beneath Rogers' apparently objective attribute categories."
mcluhan_integration:
  feeds_from: [mcluhan-medium-audit, mcluhan-hot-cool-strategist]
  feeds_to: [mcluhan-tetrad-analyzer]
  shared_data: "The medium through which innovation attributes are communicated changes how they're perceived. Demonstrating relative advantage through video (hot medium) creates different perception than through text (cool medium). Observability is medium-dependent — some media make results visible, others obscure them. McLuhan adds the channel dimension to attribute perception."
mccracken_integration:
  feeds_from: [mccracken-meaning-flow-mapper, mccracken-authenticity-auditor]
  feeds_to: [mccracken-ritual-architect]
  shared_data: "Compatibility in McCracken's terms means compatibility with the adopter's meaning world — their cultural categories, their identity narratives, their ritual practices. An innovation that disrupts meaning (even while providing functional advantage) will score low on compatibility. McCracken reveals that adoption is meaning integration, and the five attributes measure different dimensions of meaning fit."
granovetter_integration:
  feeds_from: [granovetter-weak-ties-audit]
  feeds_to: [granovetter-bridge-strategy]
  shared_data: "Observability depends on network structure. Results that are visible within a tight cluster (strong ties) drive adoption within that cluster. Results visible across clusters (through weak ties) drive broader diffusion. Granovetter reveals that observability is not just about whether results are visible — it's about WHO can see them and whether those observers are connected to non-adopters."
barabasi_integration:
  feeds_from: [barabasi-network-audit, barabasi-hub-mapper]
  feeds_to: [barabasi-hub-strategy]
  shared_data: "Network hubs amplify observability disproportionately. When a hub adopts, their adoption is visible to far more people than when a peripheral node adopts. Barabasi reveals that attribute scores — especially observability and relative advantage — are functions of WHO adopts, not just WHAT is adopted. Hub adoption changes the effective attribute profile for the entire network."
---

# Rogers Innovation Attributes Auditor

---

## LAYER 1: INVARIANTS (Never override.)

1. **Attributes are PERCEIVED, not objective.** Rogers is explicit: it is the potential adopter's PERCEPTION of these attributes that matters, not any objective measurement. A product can have massive objective relative advantage and still score low on perceived relative advantage if that advantage isn't communicated in terms the adopter understands and values. Every score in this audit reflects the target segment's perception, not the business's assessment.

2. **All five attributes must be assessed together.** They interact. High relative advantage cannot compensate for high complexity in the Early Majority. High trialability cannot overcome low compatibility. The attribute PROFILE — the specific combination of scores across all five — determines adoption rate. Fixing one attribute while ignoring the constraint of another wastes effort.

3. **Attribute requirements change by adopter segment.** Innovators tolerate high complexity and low observability because novelty itself is motivating. Early Majority demands low complexity and high observability because proof and ease are their minimum requirements. The same product needs different attribute profiles for different segments. This audit must score attributes FOR THE CURRENT TARGET SEGMENT.

4. **Complexity is the silent killer.** Of all five attributes, complexity has the strongest negative relationship with adoption rate. Businesses consistently underestimate how complex their offering appears to the next adopter segment because they evaluate complexity from their OWN expertise level, not the adopter's. The complexity assessment must use the target adopter's frame, not the seller's.

5. **Observability drives word-of-mouth.** Innovations with visible results spread faster because adoption itself becomes the communication channel. When results are invisible (internal processes, private outcomes, delayed benefits), the business must CREATE observability through design — making private results public, delayed results immediate, or internal improvements external.

---

## LAYER 2: QUALITY GUIDANCE

6. **Score each attribute numerically (1-10) with evidence.** Vague assessments ("pretty good relative advantage") are useless. Each score must be grounded in specific evidence and benchmarked against the target segment's threshold for that attribute.

7. **Identify the binding constraint.** One attribute is typically the primary bottleneck. Find it. A product with scores of 9, 8, 8, 3, 7 has a trialability problem — and no amount of improving the 9s and 8s will fix it.

8. **Make interventions specific to the attribute.** "Improve your marketing" addresses nothing. "Create a 14-day free trial that lets prospects experience the core value proposition without implementation cost" addresses trialability specifically.

---

## PURPOSE

Rogers' research across thousands of diffusion studies found that five perceived attributes of an innovation explain the vast majority of variance in adoption rates. This means adoption speed is largely predictable — and designable.

Most businesses have never systematically assessed their offer against these five attributes from their target adopter's perspective. They optimize for what they think matters (features, price, branding) while the actual adoption bottleneck sits unaddressed in an attribute they haven't measured.

This skill produces a precise attribute scorecard with specific interventions for the binding constraint.

---

## INPUT REQUIREMENTS

Provide:
1. **The innovation/offer** — what it is, what it replaces, core value proposition
2. **Target adopter segment** — which Rogers segment you're trying to reach
3. **Current adoption data** — how fast adoption is occurring, any stall points

Optional:
- Competitor attribute profiles (reveals relative positioning)
- Customer feedback (reveals perceived attribute scores)
- Sales objection data (reveals which attributes are blocking)
- Onboarding/implementation data (reveals complexity reality)

---

## EXECUTION PROCESS

### Step 1: Relative Advantage Assessment

Score perceived advantage over what the innovation replaces:

**Dimensions of relative advantage:**
- **Economic advantage:** Does it save money, make money, or reduce cost?
- **Social advantage:** Does it enhance status, belonging, or social position?
- **Convenience advantage:** Does it save time, reduce effort, or simplify life?
- **Satisfaction advantage:** Does it produce better outcomes or experiences?

**For each dimension:**
- Score (1-10) from target segment's perspective
- Evidence supporting the score
- How the advantage is currently communicated
- Whether the target segment recognizes and values this advantage

**Relative Advantage traps:**
- Advantage is real but not communicated in adopter's language
- Advantage is communicated but not believed (lack of proof)
- Advantage is believed but not valued by this segment (wrong dimension emphasized)
- Advantage is valued but not sufficient to overcome switching costs

**Overall Relative Advantage Score:** (1-10) with justification

### Step 2: Compatibility Assessment

Score alignment with existing values, experiences, and needs:

**Value compatibility:**
- Does the innovation align with the target segment's core values?
- Does it require changing beliefs or worldview to adopt?
- Are there value conflicts that create resistance (even unconscious)?

**Experience compatibility:**
- Does it feel familiar to what the adopter already knows?
- Does adoption require learning entirely new skills or processes?
- Can existing habits and workflows incorporate the innovation?

**Need compatibility:**
- Does it address a need the adopter already recognizes?
- Or does it require the adopter to first recognize a NEW need?
- Is the need framed in the adopter's vocabulary or the innovator's?

**Compatibility traps:**
- Innovation requires belief change before adoption (high friction)
- Innovation uses insider vocabulary unfamiliar to target segment
- Innovation disrupts workflows the adopter is comfortable with
- Innovation addresses a need the adopter doesn't yet recognize

**Overall Compatibility Score:** (1-10) with justification

### Step 3: Complexity Assessment

Score difficulty to understand and use:

**Comprehension complexity:**
- How many concepts must the adopter understand before seeing value?
- Can the core value proposition be explained in one sentence?
- Does understanding require specialized knowledge?

**Implementation complexity:**
- How many steps from purchase to first value?
- Does implementation require external help or resources?
- What's the time from adoption to first tangible result?

**Ongoing complexity:**
- How much maintenance/ongoing effort does the innovation require?
- Does complexity increase or decrease with use?
- Are there compounding complexity factors (integrations, updates, dependencies)?

**Complexity assessment from target segment's perspective:**
- What is their technical/domain sophistication?
- What complexity level have they tolerated in past adoptions?
- What is the maximum acceptable complexity for this segment?
- How does current complexity compare to their threshold?

**Overall Complexity Score:** (1-10, where 10 = extremely simple, 1 = extremely complex) with justification

### Step 4: Trialability Assessment

Score ability to experiment before committing:

**Current trial mechanisms:**
- Free trial / freemium / demo available?
- Money-back guarantee?
- Pilot program or limited engagement option?
- Can the adopter experience core value before full commitment?

**Trial quality:**
- Does the trial represent the actual experience? (Or is it a stripped-down version that doesn't demonstrate value?)
- How long does the trial need to be for the adopter to evaluate?
- Is the trial friction-free or does it require significant setup?
- Can the adopter exit the trial without cost or embarrassment?

**Trialability barriers:**
- High setup cost before any trial value
- Long time-to-value within trial period
- Trial requires commitment that feels like adoption
- No way to "dip a toe in" without full immersion

**Segment-specific trialability needs:**
- Innovators: Minimal trial needed (they'll experiment regardless)
- Early Adopters: Pilot program or limited engagement sufficient
- Early Majority: Full-featured trial with clear exit path required
- Late Majority: Risk-free trial with peer validation required

**Overall Trialability Score:** (1-10) with justification

### Step 5: Observability Assessment

Score visibility of results to others:

**Result visibility:**
- Can non-adopters SEE the results of adoption?
- Are results visible immediately or only after extended use?
- Are results visible to the public or only to the adopter?
- Can results be quantified and shared?

**Adoption visibility:**
- Can non-adopters tell someone has adopted? (Usage is visible)
- Does adoption create visible artifacts? (Badges, certifications, outputs)
- Is there a social/public component to usage?

**Word-of-mouth potential:**
- Do results naturally come up in conversation?
- Are adopters motivated to share their experience?
- Can the business facilitate sharing without it feeling forced?

**Observability design opportunities:**
- How could invisible results be made visible? (Dashboards, reports, shareable metrics)
- How could private adoption be made public? (Community, showcase, certification)
- How could delayed results be made immediate? (Leading indicators, early wins)

**Overall Observability Score:** (1-10) with justification

### Step 6: Attribute Profile Analysis

Synthesize all five scores into a profile:

**Attribute Scorecard:**
| Attribute | Score | Target Threshold | Gap | Priority |
|-----------|-------|-----------------|-----|----------|
| Relative Advantage | X/10 | Y/10 | Z | |
| Compatibility | X/10 | Y/10 | Z | |
| Complexity (simplicity) | X/10 | Y/10 | Z | |
| Trialability | X/10 | Y/10 | Z | |
| Observability | X/10 | Y/10 | Z | |

**Target thresholds** based on adopter segment:
- Innovators: 5/5/3/3/3 (low bar across all)
- Early Adopters: 7/6/4/5/4
- Early Majority: 7/7/7/7/7 (high bar across all, especially complexity and observability)
- Late Majority: 6/8/8/8/8 (compatibility and simplicity dominate)

**Binding constraint identification:**
Which attribute has the largest gap between current score and target threshold?

**Interaction effects:**
Where are attribute scores creating compound problems? (Low compatibility + high complexity = adoption rejection. Low observability + low trialability = trust vacuum.)

### Step 7: Competitive Attribute Comparison

Score the innovation's attributes relative to alternatives:

**For each major competitor/alternative:**
- Relative Advantage vs. this competitor
- Compatibility advantage/disadvantage
- Complexity comparison
- Trialability comparison
- Observability comparison

**Competitive attribute positioning:**
- Where does this innovation have clear attribute superiority?
- Where is it at attribute parity?
- Where is it at attribute disadvantage?
- Which attribute gaps are competitors exploiting?

### Step 8: Strategic Recommendations

Design interventions for each underperforming attribute:

**For each attribute below target threshold:**
- **Current score and gap**
- **Specific intervention** — what to change, add, or remove
- **Mechanism** — how the intervention improves the attribute score
- **Expected score improvement** — estimated post-intervention score
- **Implementation requirements** — time, cost, resources
- **Priority** — based on binding constraint analysis

**Binding constraint intervention (highest priority):**
- Detailed intervention design for the single most limiting attribute
- Implementation plan with milestones
- Success metrics to track improvement

---

## OUTPUT STRUCTURE

### Innovation Attributes Audit Report

**Section 1: Relative Advantage Assessment**
Multi-dimensional advantage scores with evidence and communication gaps.

**Section 2: Compatibility Assessment**
Value, experience, and need compatibility analysis with conflict identification.

**Section 3: Complexity Assessment**
Comprehension, implementation, and ongoing complexity from adopter's perspective.

**Section 4: Trialability Assessment**
Current trial mechanisms, quality, and barriers.

**Section 5: Observability Assessment**
Result visibility, adoption visibility, and word-of-mouth potential.

**Section 6: Attribute Profile Analysis**
Complete scorecard, binding constraint identification, and interaction effects.

**Section 7: Competitive Attribute Comparison**
Head-to-head attribute positioning against alternatives.

**Section 8: Cross-System Integration**
If other thinker data exists: How do attribute scores interact with choice architecture (Thaler), predictable bias (Ariely), somatic markers (Damasio), mimetic modeling (Girard), and status dynamics (Veblen)?

**Section 9: Strategic Recommendations**
Prioritized attribute interventions with binding constraint deep dive.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Everett Rogers - Innovation Attributes Auditor/03 - Attributes Audit - [Product Name] - [Date].md`
