---
name: oyserman-identity-congruence
description: Offer-element audit for identity congruence. Evaluates every offer element — headline, mechanism name, CTA language, product name, bonus framing, guarantee copy, and order form language — for identity congruence vs. transactional framing. Directly addresses the under-mechanized A/B phenomenon where "Buy Now" underperforms "Join the [identity-name] community."
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Daphna Oyserman (Identity-Based Motivation) — Idea 5"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/oyserman-identity-congruence {offer-page-or-copy-section}"
  called_by: [user, oyserman-ibm-diagnostic, oyserman-field-intelligence]
  outputs_to: [project-folder]
depends_on: [oyserman-ibm-diagnostic, oyserman-dynamic-construction]
---

# Oyserman Identity Congruence

---

## LAYER 1: INVARIANTS (Never override.)

1. **Identity-congruent framing and transactional framing are not just different tones — they operate through different mechanisms.** Transactional framing activates a cost-benefit evaluation mode. Identity-congruent framing activates a "is this what people like me do?" evaluation mode. These are distinct cognitive processes with different conversion implications. A change from transactional to identity-congruent framing is not a cosmetic edit — it changes the question the prospect is answering.

2. **Identity-congruence failures can undo all upstream construction work.** A prospect may arrive at the CTA with the right identity fully active, full action-readiness established, and all objections addressed — and still not convert if the CTA language, product name, or order form breaks the identity-behavior link. The offer presentation is the last gate, and it operates continuously. Every element either maintains or breaks the identity frame established in the copy.

3. **Congruence audit covers all offer elements, not just the CTA.** The most common audit error is optimizing only the CTA button text while leaving identity-breaking framing in the product name, bonus stack, guarantee language, and order form. The audit is complete only when every element visible during the offer and purchase decision has been assessed.

4. **Identity congruence is most powerful for self-defining behaviors.** Oyserman's research establishes that identity-congruent framing works strongest for purchases or commitments that the buyer will identify with — programs they join, communities they belong to, transformations they're making. It is less powerful for routine, low-involvement, low-identity-salience transactions. This audit applies to high-involvement offers where identity is at stake.

5. **Commercial validation note.** The identity-congruent action construct is supported by Oyserman's 2009 consumer behavior work — participants primed with a "healthy person" identity showed higher purchase intention for the same items. The theoretical grounding is strong; commercial copy applications are inferential from the priming research. State this when presenting findings.

---

## LAYER 2: QUALITY GUIDANCE

6. **Transactional language is identifiable by specific vocabulary.** "Buy Now," "Purchase," "Order," "Get it," "Add to cart," "Claim your discount," "Sign up" — these are transaction signals. They tell the reader this is a commercial exchange. Identity-congruent alternatives — "Join the [identity-group]," "Start building," "Take this next step," "Become a member," "Claim your spot" — frame the action as an identity expression. The audit identifies all transactional language and replaces it with identity-congruent equivalents calibrated to the specific target identity.

7. **Product naming is the most under-audited element.** Generic product names ("The Business Growth Course," "The Health Transformation System") are identity-neutral. Identity-congruent names signal belonging ("The Founders' Method," "The Builder's Protocol," "The Practitioner's Toolkit"). The audit evaluates whether the product name itself signals identity membership or positions the offer as a generic commodity.

8. **Guarantee language often breaks identity congruence invisibly.** "30-day money-back guarantee" signals: "you might regret this." "Our guarantee: you'll know within [timeframe] whether this is right for you — and if not, we'll refund every cent" signals: "we're confident this is for people like you." The guarantee is part of the offer element inventory and must be audited for identity congruence.

---

## PURPOSE

Oyserman's construct of identity-congruent vs. identity-incongruent action establishes that the same behavior is processed entirely differently depending on whether it has been linked to an active identity. A purchase that is framed as "what people like you do" — at the level of the CTA, product name, bonus descriptions, and order form — is processed as an identity expression. The same purchase framed transactionally is processed as a cost-benefit calculation.

This audit evaluates the offer layer of a sales page or funnel — everything the prospect sees when deciding whether to commit — for identity congruence at the element level. It produces a scored inventory of all offer elements and specific rewrites for each identity-breaking element found.

**Key connection to the stack:** Identity congruence is the fourth and final component of IBM's behavioral sequence (after construction, action-readiness, and difficulty interpretation). It ensures that the offer presentation itself does not break the identity frame that all upstream copy has built. This skill is the quality-control layer for the offer moment.

---

## INPUT REQUIREMENTS

Provide one or more of the following:

1. **The offer section of the copy** — the section that presents the product, price, CTA, bonuses, and guarantee
2. **The full sales page or VSL script** — if the offer elements are distributed throughout
3. **The target identity** — the primary self-concept being activated in this copy (or reference `oyserman-dynamic-construction` output)
4. **Product name, CTA text, bonus names, guarantee language** — if auditing specific elements in isolation

Optionally provide:
- **Known A/B test results** — if there's existing data showing which framing versions outperformed, this provides calibration
- **Competitor offer framing** — if the audit should also assess how this offer's identity congruence compares to alternatives in the market

---

## AUDIT STRUCTURE

### Pre-Audit: Identity Anchor

Confirm the target identity before assessing congruence:

**Target identity label:**
**Primary identity facets active at offer presentation point:**
**Identity vocabulary established upstream in the copy:**

If the target identity is unclear or not specified, the congruence audit cannot produce calibrated recommendations. Flag and request identity specification.

---

### Element Inventory: Identity Congruence Scorecard

Rate every offer element on the following 3-point scale:

- **CONGRUENT (3):** The element actively signals "this is what people like you do"
- **NEUTRAL (2):** The element neither reinforces nor breaks the identity frame
- **TRANSACTIONAL / BREAKING (1):** The element shifts the prospect into cost-benefit mode or actively signals "this is a commercial exchange, not an identity expression"

| Element | Current text/framing | Score | Verdict | Recommended rewrite |
|---------|---------------------|-------|---------|---------------------|
| **Headline (offer section)** | | | | |
| **Product name** | | | | |
| **Mechanism name / program name** | | | | |
| **CTA button text** | | | | |
| **CTA surrounding copy** | | | | |
| **Price framing / value anchoring** | | | | |
| **Bonus #1 name and framing** | | | | |
| **Bonus #2 name and framing** | | | | |
| **Bonus #3 name and framing** | | | | |
| **[Additional bonuses]** | | | | |
| **Guarantee language** | | | | |
| **Order form headline** | | | | |
| **Order form subheadline** | | | | |
| **Order form field labels** | | | | |
| **Post-purchase / thank-you language** | | | | |

**Aggregate congruence score:** [Sum / Max = Percentage]

**Critical breaks:** [Elements scoring 1 — highest priority for rewrite]

---

### Detailed Rewrite Section

For each element scoring TRANSACTIONAL or BREAKING, produce a specific rewrite:

**[Element name]**

Current:
> [Exact current text]

Why it breaks identity congruence:
> [Mechanism — which transactional signal or identity-neutral framing it uses]

Identity-congruent rewrite:
> [Replacement text]

Identity facet activated:
> [Which specific facet of the target identity this now expresses]

---

### CTA Architecture Deep Dive

The CTA is the highest-stakes congruence moment. Provide full CTA architecture:

**CTA text options (ranked by identity congruence for this specific target identity):**

1. [Most congruent option] — Identity link: [why this works]
2. [Second option] — Identity link:
3. [Third option / control comparison] —

**CTA surrounding copy (the sentences immediately before and after the CTA button):**

Current:
> [If provided]

Optimized:
> [Rewrite — this should: re-activate the target identity, frame the action as an identity expression, and make the next step feel like the natural move for someone with this identity]

**CTA placement note:** The CTA should appear after the last identity re-priming moment in the copy, not after the price reveal. Price reveals are transactional; identity re-priming is identity-activating. Sequencing: identity re-prime → difficulty reframe (if applicable) → CTA.

---

### Product Naming Assessment

**Current product name:** [Name]

**Identity congruence assessment:**
- Does the name signal membership in the target identity group?
- Does the name use vocabulary from the target identity's lexicon?
- Does the name frame the product as a tool/community/system that people with this identity use — or as a generic commodity?

**Naming alternatives (if current name is neutral or breaking):**

| Option | Identity signal | Verdict |
|--------|----------------|---------|
| [Option 1] | [Which identity facet it activates] | |
| [Option 2] | | |
| [Option 3] | | |

---

### Order Form and Checkout Audit

The order form is the most commonly abandoned identity-breaking moment. Audit:

| Order form element | Current | Identity congruence | Recommended |
|-------------------|---------|---------------------|-------------|
| Page headline | | | |
| Subheadline / reassurance copy | | | |
| Product description in the form | | | |
| Button text | | | |
| Security / trust copy | | | |

**Order form principle:** The order form should feel like completing an enrollment into an identity-matched community or program — not filling out a purchase form. Every element should reinforce: "You're joining something that's for people like you."

---

### Synthesis: Identity Congruence Report

**Overall verdict:** [STRONG / ADEQUATE / BREAKING — number of critical failures]

**Highest-priority fixes:** [Top 3 rewrite priorities by impact on conversion]

**Elements already working:** [Any elements that are already identity-congruent and should not be changed — preserve these]

**Integration note:** If upstream IBM skills (`oyserman-dynamic-construction`, `oyserman-action-readiness`) have already been applied, verify that the identity vocabulary used in offer elements is consistent with the vocabulary established in the construction sections. Vocabulary drift between construction and offer presentation breaks congruence even when individual elements pass the audit in isolation.

---

## OUTPUT FILE

Save complete audit to:
`[project-folder]/Oyserman Identity Congruence Audit - [Offer Name] - [Date].md`
