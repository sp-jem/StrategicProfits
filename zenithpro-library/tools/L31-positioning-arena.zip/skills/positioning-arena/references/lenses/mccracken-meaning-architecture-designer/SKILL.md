---
name: mccracken-meaning-architecture-designer
description: Integrate all McCracken subsystems into a coherent meaning architecture. Use when brand sends mixed cultural signals.
version: 1.0.0
author: Strategic Profits / Deep Marketing Thinkers Series
source_thinker: "Grant McCracken (Culture and Consumption, 1988; Transformations, 2008; Chief Culture Officer, 2009) — Skill 6 of 7"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/mccracken-meaning-architecture-designer {brand or system}"
  called_by: [user, mccracken-field-intelligence]
  outputs_to: [client-output-folder]
freshness_gate:
  max_age_days: 45
  rationale: "Architecture evolves slower than individual components. A meaning architecture remains valid longer than a flow map or authenticity audit because it represents the structural relationships between subsystems, not the subsystems themselves. However, if any component skill has been re-run (new flow map, updated ritual design, fresh authenticity audit), the architecture should be reassessed to incorporate new findings. Reassess every 45 days or whenever two or more component analyses are refreshed."
thaler_integration:
  feeds_from: [thaler-choice-architect, thaler-default-detector, thaler-mental-accounting]
  feeds_to: [thaler-nudge-auditor, thaler-loss-aversion-audit]
  shared_data: "Thaler's choice architecture is the DELIVERY INFRASTRUCTURE for meaning architecture. The meaning architecture specifies what cultural meanings should transfer and in what sequence; choice architecture determines how the decision environment presents those meanings to the buyer. Default settings encode the architecture's priority meanings — the default option should carry the STRONGEST meaning signal, not just the highest conversion probability. Mental accounting determines which meaning frame the buyer applies, which in turn determines which architectural layer they engage with first. A coherent meaning architecture aligns choice defaults with meaning priorities."
ariely_integration:
  feeds_from: [ariely-expectation-architect, ariely-social-norms-detector, ariely-relativity-engine]
  feeds_to: [ariely-predictability-auditor, ariely-honesty-calibrator]
  shared_data: "Ariely's expectation effects reveal that the meaning architecture literally shapes what the buyer EXPERIENCES. A coherent architecture — where every subsystem sends the same cultural signal — creates expectation alignment that amplifies experienced quality. An incoherent architecture creates expectation confusion that diminishes experience regardless of product quality. The relativity engine reveals how buyers compare meaning architectures across competitors — not feature by feature, but architecture against architecture. Social norms detection flags where the architecture shifts from social-norm territory (relationship, trust, belonging) to market-norm territory (transaction, pricing, urgency) — each shift is an architectural fracture."
damasio_integration:
  feeds_from: [damasio-somatic-marker-audit, damasio-emotion-feeling-mapper, damasio-body-loop-auditor]
  feeds_to: [damasio-ecs-designer, damasio-convergence-zone-mapper]
  shared_data: "Damasio reveals that meaning architecture registers in the body as a COHERENCE SIGNAL. When all meaning subsystems align, the somatic response is a unified marker — 'this feels right,' 'this brand makes sense,' 'I trust this.' When subsystems contradict, the body registers confusion before the mind can articulate the problem. The emotion-feeling mapper traces how architectural coherence produces calm confidence (emotion) that becomes articulated trust (feeling). Architectural incoherence produces unease (emotion) that becomes 'something feels off' (feeling) — even when the buyer cannot name the contradiction. The architecture designer optimizes for somatic coherence across the entire system."
girard_integration:
  feeds_from: [girard-model-map, girard-desire-propagation, girard-mimetic-content-strategist]
  feeds_to: [girard-desire-autopsy, girard-rivalry-detector]
  shared_data: "Girard reveals that meaning architectures are MIMETICALLY evaluated. Buyers don't assess each subsystem independently — they assess the architecture as a whole against the architectures of brands they admire. A brand whose meaning architecture resembles an admired brand's architecture inherits perceived coherence through mimetic association. The model map identifies whose meaning architecture the buyer is using as a reference standard. The desire propagation system reveals how architectural coherence (or incoherence) spreads through social networks — buyers who experience a coherent architecture become mimetic amplifiers; buyers who experience incoherence become mimetic dampeners."
veblen_integration:
  feeds_from: [veblen-status-intelligence, veblen-signal-decoder, veblen-display-map]
  feeds_to: [veblen-price-ladder, veblen-waste-audit]
  shared_data: "Veblen reveals that STATUS must be architecturally positioned, not sprinkled. Many brands inject status signals into every subsystem — premium pricing, exclusive access, conspicuous design, celebrity association — creating status saturation that reads as insecurity rather than genuine elevation. The architecture designer determines WHERE status meaning belongs in the system (often concentrated in display rituals and celebrity transfer) and where it must be ABSENT (authenticity mechanisms, grooming rituals) to maintain coherence. Status that contradicts other meaning dimensions — premium pricing with discount urgency, exclusive positioning with mass-market advertising — is the most common architectural incoherence."
bourdieu_integration:
  feeds_from: [bourdieu-habitus-profiler, bourdieu-distinction-mapper, bourdieu-capital-audit]
  feeds_to: [bourdieu-field-analyzer, bourdieu-symbolic-decoder]
  shared_data: "Bourdieu reveals that meaning architectures must be designed for a specific HABITUS. A meaning architecture that reads as coherent to high-cultural-capital buyers may read as pretentious to others. One that reads as accessible and genuine to mass-market buyers may read as unsophisticated to culturally privileged buyers. The distinction mapper shows how meaning architecture functions as class sorting — the architecture itself communicates 'this is for people like you' before the buyer engages with any specific subsystem. The architecture designer must ensure every subsystem speaks to the same habitus, or explicitly design transitions between habitus levels within the architecture."
loewenstein_integration:
  feeds_from: [loewenstein-visceral-audit, loewenstein-anticipation-engine, loewenstein-curiosity-architect]
  feeds_to: [loewenstein-empathy-gap-map, loewenstein-risk-as-feelings]
  shared_data: "Loewenstein reveals that meaning architecture is received differently across VISCERAL STATES. A buyer in a hot state (excited, fearful, urgent) receives the architecture through an emotional filter that amplifies dominant signals and suppresses subtlety. A buyer in a cold state (evaluative, comparative, analytical) receives the full architecture and detects incoherences invisible in hot states. The empathy gap means architects in cold states (designing carefully) cannot predict how buyers in hot states will experience the architecture. The anticipation engine reveals how architectural coherence amplifies during the anticipation period — a coherent architecture builds meaning during the wait; an incoherent one generates doubt."
festinger_integration:
  feeds_from: [festinger-dissonance-detector, festinger-commitment-architect, festinger-effort-value-auditor]
  feeds_to: [festinger-post-decision-engineer, festinger-belief-behavior-sequencer]
  shared_data: "Festinger reveals that meaning architecture must be DISSONANCE-MINIMAL at entry and DISSONANCE-LEVERAGING post-commitment. Before purchase, architectural contradictions create cognitive dissonance that prevents action — the buyer senses something is wrong but cannot name it. After purchase, controlled dissonance (the gap between current identity and the identity the architecture promises) drives the buyer DEEPER into the meaning system to resolve the gap. The commitment architect ensures that post-purchase engagement with each subsystem increases commitment to the whole architecture. The effort-value auditor ensures the architecture demands enough engagement to generate value attribution but not so much that buyers disengage."
barthes_integration:
  feeds_from: [barthes-connotation-mapper, barthes-myth-decoder, barthes-ideology-auditor]
  feeds_to: [barthes-myth-construction-strategist, barthes-signal-archaeology]
  shared_data: "Barthes provides the SEMIOLOGICAL verification layer for the meaning architecture. Every subsystem produces signs — and those signs must be read together as a text. The connotation mapper reads what each subsystem connotes individually. The myth decoder reveals whether the subsystems combine into a coherent myth (a naturalized cultural narrative) or a contradictory text (where the reader detects the artifice). The ideology auditor reveals whose interests the meaning architecture serves and whether that service is naturalized or visible. McCracken designs the architecture; Barthes reads it as the buyer will read it — as a system of signs that either coheres into believable narrative or fractures into visible construction."
mcluhan_integration:
  feeds_from: [mcluhan-medium-audit, mcluhan-hot-cool-strategist, mcluhan-tetrad-analyzer]
  feeds_to: [mcluhan-sensory-ratio-mapper, mcluhan-acoustic-vs-visual-auditor]
  shared_data: "McLuhan reveals that each subsystem of the meaning architecture is delivered through a MEDIUM, and the medium shapes the meaning. A ritual designed for live interaction (cool medium, high participation) transfers meaning differently than the same ritual delivered via automated email (hot medium, low participation). The architecture designer must ensure medium choices across subsystems are compatible — a brand whose positioning uses cool media (podcasts, community dialogue) but whose sales system uses hot media (polished VSLs, automated sequences) has a medium-level architectural contradiction. The tetrad analyzer reveals what each medium choice enhances, obsolesces, retrieves, and reverses within the architecture."
mccracken_integration:
  feeds_from: [mccracken-meaning-flow-mapper, mccracken-ritual-architect, mccracken-authenticity-auditor, mccracken-celebrity-meaning-mapper, mccracken-style-evolution-tracker]
  feeds_to: [mccracken-field-intelligence]
  shared_data: "The meaning architecture designer (this skill) is the INTEGRATION skill of the McCracken system. It receives outputs from all five component skills: the meaning flow mapper (Skill 1) provides the flow map — where meaning originates, how it transfers into goods, how it reaches identity. The ritual architect (Skill 2) provides the ritual designs that enable goods-to-identity transfer. The authenticity auditor (Skill 3) provides the claims-vs-infrastructure gap analysis. The celebrity meaning mapper (Skill 4) provides the endorsement meaning inventory and fit analysis. The style evolution tracker (Skill 5) provides the style lifecycle and trajectory assessment. This skill integrates all five into a UNIFIED ARCHITECTURE — detecting where subsystems reinforce each other, where they contradict, where gaps exist, and where redundancy wastes meaning bandwidth. Field intelligence (Skill 7) then synthesizes the architecture with all other thinker systems."
---

# McCracken Meaning Architecture Designer

---

## LAYER 1: INVARIANTS (Never override.)

1. **A meaning architecture is more than the sum of its components.** Individual meaning subsystems (flow, ritual, authenticity, celebrity, style) do not automatically produce coherence when combined. They can CONTRADICT each other in ways invisible when examined individually. A meaning flow that draws from "rebellious innovation" culture, combined with rituals of "exclusive membership," creates an architectural contradiction (rebels don't join clubs). The architecture designer's primary job is detecting emergent contradictions that no component analysis can reveal alone.

2. **Coherence means every subsystem reinforces the SAME cultural meaning.** The meaning that flows from culture into the product (Skill 1) must be the same meaning the rituals transfer into identity (Skill 2), must be the meaning that the authenticity signals protect (Skill 3), must be the meaning the celebrity endorsers carry (Skill 4), and must be the meaning the style choices express (Skill 5). When these diverge — even partially — the buyer receives a mixed signal that weakens all five subsystems simultaneously. Coherence is not perfection; it is alignment of direction across all components.

3. **Meaning architecture requires HIERARCHY, not equality.** Not all subsystems carry equal weight. In some architectures, meaning flow is the primary driver and ritual is secondary support. In others, ritual IS the meaning and flow merely provides raw material. Celebrity may be central or irrelevant. Style may lead or follow. The architecture must establish which subsystem is PRIMARY (the meaning anchor), which are SECONDARY (reinforcement), and which are TERTIARY (background consistency). Without hierarchy, all subsystems compete for the buyer's attention and none wins.

4. **Redundancy is as dangerous as gaps.** When multiple subsystems attempt to transfer the SAME meaning through different channels, the buyer experiences repetition that reads as insecurity. A brand that says "premium" through pricing (Veblen), through exclusive rituals (ritual architect), through celebrity association (celebrity mapper), through minimalist style (style tracker), AND through high-production advertising (flow mapper) has stacked five premium signals — which paradoxically reads as "trying too hard to be premium" rather than actually premium. The architecture designer must identify where DIFFERENT meanings should be assigned to different subsystems to create a rich, multidimensional architecture rather than a one-note repetition.

5. **Meaning architecture must accommodate TEMPORAL sequence.** The buyer does not encounter all subsystems simultaneously. They encounter them in order: first advertising (meaning flow), then purchase experience (exchange ritual), then onboarding (possession ritual), then ongoing engagement (grooming ritual), then display (display ritual). The architecture must be designed as a SEQUENCE where each subsystem deepens, extends, or reveals new dimensions of meaning — not as a simultaneous blast where every subsystem says everything at once. The temporal design determines whether meaning COMPOUNDS over time or merely repeats.

6. **Contradiction at the architecture level destroys subsystem quality.** A brilliant ritual design placed within an incoherent architecture UNDERPERFORMS a mediocre ritual design within a coherent one. The architecture creates the context that determines how each subsystem is received. This means fixing architectural incoherence is ALWAYS higher leverage than optimizing individual subsystems. A brand should redesign its architecture before perfecting any component within it.

7. **The buyer experiences the architecture, not the components.** No buyer thinks "the meaning flow is strong but the ritual design is weak." They think "this brand feels right" or "something is off." The architecture is experienced as a gestalt — a unified impression formed from all signals together. The architecture designer works at this gestalt level: designing the total impression, then allocating specific meaning-transfer responsibilities to each subsystem.

---

## LAYER 2: QUALITY GUIDANCE

8. **Begin with the component analyses, not from scratch.** The architecture designer does NOT re-analyze flow, ritual, authenticity, celebrity, or style. It takes the OUTPUTS of Skills 1-5 and integrates them. If component analyses are missing or outdated, flag them as prerequisites rather than attempting partial architecture with incomplete data. An architecture built on incomplete component analysis is worse than no architecture — it creates false confidence.

9. **Test the architecture against the buyer's TEMPORAL experience.** Walk through the architecture as the buyer would encounter it: first exposure → interest → consideration → purchase → onboarding → engagement → display → renewal/departure. At each stage, ask: what meaning is the buyer receiving? Does it build on what came before? Does it prepare for what comes next? Any meaning that contradicts the prior stage or fails to set up the next stage is an architectural fault.

10. **Design for the MINIMUM effective architecture, not the maximum.** Meaning overload is a real risk. An architecture that attempts to transfer too many meanings simultaneously overwhelms the buyer's capacity to absorb any of them. The strongest architectures transfer ONE PRIMARY MEANING through every subsystem and 2-3 SUPPORTING MEANINGS through specific subsystems. Total meaning dimensions should rarely exceed four. More than four creates noise, not richness.

11. **Cross-reference the architecture against ALL thinker systems, not just McCracken components.** The meaning architecture operates within decision environments (Thaler), expectation frames (Ariely), somatic reception systems (Damasio), mimetic fields (Girard), status hierarchies (Veblen), class structures (Bourdieu), information gaps (Loewenstein), dissonance states (Festinger), semiotic systems (Barthes), and media environments (McLuhan). An architecture coherent within McCracken's system may be incoherent when these other forces are considered. The Cross-Thinker Integration step is not optional.

---

## PURPOSE

Most brands build meaning subsystems in isolation. The marketing team designs positioning (meaning flow). A different team designs the customer experience (rituals). The brand team manages visual identity (style). PR handles endorsements (celebrity). Nobody manages the connections between them.

The result is predictable: each subsystem works adequately in isolation, but together they send contradictory signals. The positioning promises "transformation" while the rituals feel "transactional." The celebrity endorser carries "rebellion" while the style signals "establishment." The authenticity claims say "we're different" while the infrastructure looks identical to every competitor.

McCracken's meaning transfer model, when applied at the architectural level, reveals that coherent meaning transfer is a SYSTEM property, not a component property. Individual subsystem quality is necessary but not sufficient. The architecture — the structural relationship between all subsystems — is what determines whether cultural meaning actually flows from culture through the product and into the buyer's identity.

This skill designs that architecture. It takes the outputs of all five McCracken component skills and produces a unified meaning system where every component reinforces every other, contradictions are resolved, gaps are filled, redundancies are eliminated, and the buyer's temporal experience is designed as a meaning-building sequence.

---

## INPUT REQUIREMENTS

Provide:
1. **The brand or system to architect** — the scope of the meaning architecture
2. **Meaning Flow Map** — output from Skill 1 (mccracken-meaning-flow-mapper), or current state of meaning flow
3. **Ritual Architecture Plan** — output from Skill 2 (mccracken-ritual-architect), or current state of ritual design
4. **Authenticity Audit** — output from Skill 3 (mccracken-authenticity-auditor), or current state of authenticity
5. **Celebrity Meaning Map** — output from Skill 4 (mccracken-celebrity-meaning-mapper), or current state of endorsement strategy
6. **Style Evolution Assessment** — output from Skill 5 (mccracken-style-evolution-tracker), or current state of style

Optional:
- Prior meaning architecture (for redesign rather than initial design)
- Business objectives and constraints (what the architecture must achieve)
- Buyer journey documentation (the temporal sequence the buyer experiences)
- Cross-thinker analyses already completed (from other thinker systems)

If any component skill output is missing, the architecture designer will flag it as a gap and proceed with available data, noting reduced confidence in the affected architectural dimensions.

---

## EXECUTION PROCESS

### Step 1: Current Architecture Assessment

Synthesize all component skill outputs into a single picture of the current meaning system:

**Meaning flow summary:**
- What cultural meanings are currently flowing into the product?
- What transfer mechanisms (advertising, fashion system) are active?
- Where is flow blocked, leaking, or reversed?
- Primary finding from Skill 1 analysis

**Ritual system summary:**
- What rituals exist across exchange, possession, grooming, display, divestiture?
- Which rituals are effectively transferring meaning? Which are broken or absent?
- What meanings are the rituals actually transferring?
- Primary finding from Skill 2 analysis

**Authenticity position summary:**
- What is the gap between authenticity claims and infrastructure reality?
- Where are the critical authenticity breaches?
- What authenticity signals are working?
- Primary finding from Skill 3 analysis

**Celebrity/endorsement summary:**
- What cultural meanings do current endorsers carry?
- Are endorser meanings aligned with intended product meanings?
- Where are endorsement gaps or mismatches?
- Primary finding from Skill 4 analysis

**Style position summary:**
- Where is the brand's style in its lifecycle?
- Is the style advancing, stagnating, or declining?
- What cultural meanings does the current style express?
- Primary finding from Skill 5 analysis

### Step 2: Gap Analysis

Identify meaning dimensions that NO subsystem is serving:

**Meaning dimensions inventory:**
- List every cultural meaning the brand intends to transfer
- Map which subsystem(s) currently serve each meaning
- Identify meanings served by zero subsystems (architectural gaps)
- Identify meanings served by only one subsystem (single-point-of-failure risks)

**Structural gaps:**
- Where the flow map shows meaning entering the product but no ritual moves it to identity
- Where rituals exist but no meaning flows to feed them
- Where authenticity protects a meaning that no other subsystem actually transfers
- Where celebrity carries a meaning that no other subsystem reinforces
- Where style expresses a meaning disconnected from all other subsystems

**Priority gaps:**
- Rank gaps by impact on overall meaning transfer
- Identify which gaps are quick fixes and which require architectural redesign

### Step 3: Redundancy Detection

Identify where multiple subsystems transfer the SAME meaning:

**Redundancy inventory:**
- Map every instance where two or more subsystems carry identical meaning
- Assess whether redundancy is reinforcing (builds coherence) or repetitive (reads as insecurity)
- Distinguish: parallel reinforcement (same meaning through different channels) vs. stacking (same meaning through same channel type, multiple times)

**Redundancy risks:**
- Where does repetition undermine the meaning? (Premium signaled too many ways reads as "trying too hard")
- Where does redundancy create dimensional poverty? (All subsystems carry the same meaning, leaving other meanings unrepresented)
- Where are subsystem resources being wasted on meanings already covered?

**Redundancy resolution:**
- For each redundancy: keep the strongest carrier, reassign others to unserved meanings
- Preserve intentional reinforcement (primary meaning should appear in multiple subsystems)
- Eliminate unintentional repetition (secondary meanings doubled without purpose)

### Step 4: Incoherence Mapping

Identify where subsystems send CONTRADICTORY cultural signals:

**Direct contradictions:**
- Meaning flow says X, ritual says Y (e.g., flow channels "innovation" but rituals enforce "tradition")
- Authenticity claims conflict with flow or ritual evidence
- Celebrity meaning contradicts brand meaning
- Style signals contradict positioning signals

**Indirect contradictions:**
- Tonal mismatches (formal flow + casual ritual, premium style + discount urgency)
- Temporal inconsistencies (meaning at purchase differs from meaning at engagement)
- Audience confusion (subsystems designed for different habitus levels)

**For each incoherence:**
- The contradicting subsystems
- The conflicting meanings
- Buyer impact (confusion, distrust, meaning dilution)
- Resolution: which subsystem adapts? Which holds firm?
- Rationale for resolution direction

### Step 5: Architecture Redesign

Design the unified meaning architecture:

**Primary meaning declaration:**
- The ONE cultural meaning that anchors the entire architecture
- This meaning must appear in every subsystem (the coherence thread)
- All other meanings must be compatible with and subordinate to this meaning

**Supporting meaning allocation:**
- 2-3 supporting meanings, each assigned to specific subsystems
- No supporting meaning should conflict with the primary
- Each supporting meaning is carried by at least two subsystems for resilience

**Subsystem hierarchy:**
- Which subsystem is PRIMARY (the meaning anchor for this brand)?
- Which subsystems are SECONDARY (reinforcement and extension)?
- Which subsystems are TERTIARY (background consistency)?
- Rationale for hierarchy order

**Temporal sequence design:**
- How meaning unfolds across the buyer's journey
- First exposure: what meaning arrives first?
- Deepening: how does each subsequent touchpoint add dimension?
- Culmination: where does the architecture achieve full meaning transfer?
- Maintenance: how is meaning sustained post-transfer?

**Coherence mechanisms:**
- What structural elements ensure subsystems stay aligned?
- How are future additions/changes tested against the architecture?
- What would break the architecture (the critical constraints)?

### Step 6: Implementation Pathway

Design the sequence for implementing or correcting the architecture:

**Immediate alignment (7 days):**
- Remove the most visible contradictions
- Correct the most damaging incoherences
- Fill the most critical gaps with temporary measures
- Stop subsystem activities that actively undermine the architecture

**Foundation building (30 days):**
- Implement primary meaning across all subsystems
- Reallocate subsystem resources from redundant to gap-filling work
- Align temporal sequence so the buyer journey builds meaning progressively
- Test architecture with target buyer for coherence perception

**Full architecture (90 days):**
- Complete supporting meaning allocation
- Activate all subsystem redesigns
- Build feedback mechanisms to monitor architectural coherence
- Train team on architectural constraints (what must NOT change)

**For each implementation action:**
- What changes in which subsystem
- Expected impact on overall coherence
- Dependencies (what must happen first)
- Success indicators

### Step 7: Cross-Thinker Integration

Validate the meaning architecture against all available thinker systems:

**Barthes Integration — Semiological coherence:** Does the architecture produce a unified sign system? Does it naturalize into myth or reveal its construction?
**Girard Integration — Mimetic evaluation:** Whose meaning architecture is the reference standard for this audience? How does this architecture compare mimetically?
**Veblen Integration — Status architecture:** Where is status positioned in the architecture? Does status signal placement cohere with other meaning dimensions?
**Bourdieu Integration — Habitus alignment:** Is the architecture designed for one habitus? Does it inadvertently mix class signals?
**Damasio Integration — Somatic coherence:** Will the architecture produce a unified somatic marker or conflicting body-level signals?
**Ariely Integration — Expectation architecture:** Do expectations set by early subsystems align with experience delivered by later subsystems?
**Festinger Integration — Dissonance design:** Is pre-purchase dissonance minimized and post-purchase dissonance leveraged for deeper engagement?
**Loewenstein Integration — Visceral state design:** Does the architecture work across hot and cold states? Where is it vulnerable to state-dependent reception?
**McLuhan Integration — Medium coherence:** Are the media used across subsystems compatible? Do medium choices reinforce or contradict meaning choices?
**Thaler Integration — Choice architecture alignment:** Does the decision environment support the meaning architecture? Do defaults encode the primary meaning?

### Step 8: Complete Architecture

Produce the final unified meaning architecture:

**Architecture blueprint:**
- Primary meaning, supporting meanings, meaning hierarchy
- Each subsystem's role, responsibilities, and boundaries
- Temporal sequence from first exposure through sustained engagement
- Coherence mechanisms and constraints

**Meaning transfer map:**
- Visual or descriptive map showing how meaning flows through the entire architecture
- Every transfer point, the meaning transferred, and the subsystem responsible
- Points of reinforcement where subsystems compound meaning
- Points of vulnerability where meaning could leak or contradict

**Implementation roadmap:**
- Phased plan with specific actions, owners, timelines
- Dependencies mapped
- Success metrics for each phase
- Architectural constraints that must be maintained throughout

**Risk assessment:**
- What could break this architecture? (external cultural shifts, competitor moves, internal inconsistency)
- Where is the architecture most fragile?
- What monitoring mechanisms detect architectural drift?
- Contingency plans for the three most likely disruptions

---

## OUTPUT STRUCTURE

### Meaning Architecture Report

**Section 1: Current Architecture Assessment**
Unified picture of the current meaning system synthesized from all five component skill outputs. State of each subsystem and their current relationships.

**Section 2: Gap Analysis**
Meaning dimensions with no subsystem coverage. Single-point-of-failure risks. Structural gaps between subsystems. Priority ranking.

**Section 3: Redundancy Report**
Where multiple subsystems carry identical meaning. Reinforcing vs. repetitive redundancy. Resolution recommendations.

**Section 4: Incoherence Map**
Every contradiction between subsystems — direct and indirect. Buyer impact. Resolution direction with rationale.

**Section 5: Architecture Design**
Primary meaning declaration, supporting meaning allocation, subsystem hierarchy, temporal sequence design, and coherence mechanisms. The complete architectural blueprint.

**Section 6: Implementation Pathway**
Phased plan (7-day, 30-day, 90-day) with specific actions, dependencies, and success indicators.

**Section 7: Cross-System Integration**
Architecture validated against all available thinker systems. Conflicts, synergies, and optimizations noted.

**Section 8: Complete Architecture**
Unified meaning transfer map, implementation roadmap, risk assessment, and monitoring recommendations.

---

## OUTPUT FILE

Save complete report to:
`[project-folder]/Grant McCracken - Meaning Architecture Designer/06 - Meaning Architecture - [System Name] - [Date].md`
