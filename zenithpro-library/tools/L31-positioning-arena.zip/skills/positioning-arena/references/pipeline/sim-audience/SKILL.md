# sim-audience

## Purpose

Run any content through the Simulated Audience Engine — a panel of 12 documented buyer archetypes derived from Rich Schefren's actual audience database.

Returns a buyer heat map showing which content wins with which segments, what objections each persona raises, where drop-offs happen, and aggregate conversion probability.

Standalone tool. Plugs into: copywriting arena, webinar arena, standalone focus groups.

---

## Trigger

User invokes `/sim-audience` with content to test.

---

## Inputs

```
CONTENT: [the copy, email, ad, offer, or script section to test]
CONTENT TYPE: [copy | email | ad | webinar-script | offer | positioning-statement]
AUDIENCE CONTEXT: [optional — describe which buyer segment this is aimed at, or "general"]
PERSONAS: [optional — comma-separated list of persona IDs to run, or "all" (default: all 12)]
OUTPUT PATH: [optional — where to save results, defaults to current project folder]
```

---

## Persona Library Location

`~/Obsidian/Active-Brain/00 Projects/Simulated Audience Engine/personas/persona-library.json`

Load this file before spawning agents. Pass the full persona profile for each selected archetype.

---

## Execution Flow

### Step 1: Load Personas
Read `persona-library.json`. Select personas based on input (default: all 12).

### Step 2: Spawn Buyer Panel (Parallel)
Spawn one `buyer-persona` agent per selected persona using the Task tool.

Task message format:
```
PERSONA: [full persona object from library, formatted as readable profile]

CONTENT TYPE: [content_type]

CONTENT:
[full content text]

REACTION FORMAT: panel
```

All 12 run in parallel. Wait for all to complete before aggregating.

### Step 3: Aggregate Results
When all Task agents return, compile:

1. **Per-persona summary table** — Buy decision, confidence, top objection, drop-off risk
2. **Conversion heat map** — Rank personas by buy probability
3. **Objection bank** — All objections raised, grouped by theme
4. **Resonance map** — All resonant elements, grouped by theme
5. **Drop-off analysis** — Where each persona would exit and why
6. **Segment winners** — Which claims/elements work across the most personas
7. **Leaks** — Where no version of the content is working
8. **Aggregate conversion estimate** — Weighted average across personas with confidence band

### Step 4: Write Output

Write to `[OUTPUT_PATH]/buyer-heat-map.md` and `[OUTPUT_PATH]/reactions.json`

If no output path specified, ask user where to save or write to current working directory.

---

## Output Format: buyer-heat-map.md

```markdown
# Buyer Heat Map: [Content Type] — [Date]

## Summary

**Aggregate Buy Probability:** [X]% (range: [low]-[high])
**Strongest Segment:** [persona name] — [X]% buy probability
**Weakest Segment:** [persona name] — [X]% buy probability
**Universal Win Elements:** [what worked across all/most personas]
**Critical Leaks:** [what failed across all/most personas]

---

## Persona Scorecard

| Persona | Buy? | Confidence | Top Objection | Drop-Off Risk | Resonant Element |
|---|---|---|---|---|---|
| Skeptical Veteran | YES/NO/MAYBE | 0-100 | [text] | HIGH/MED/LOW | [text] |
| AI-Anxious Entrepreneur | ... | ... | ... | ... | ... |
[... all 12 personas ...]

---

## Segment Heat Map

### HIGH PROBABILITY (>60%)
[Persona names + brief why]

### MEDIUM PROBABILITY (40-60%)
[Persona names + brief why]

### LOW PROBABILITY (<40%)
[Persona names + brief why]

---

## Objection Bank

### Most Common Objections (appearing in 3+ personas)
1. [objection] — raised by: [personas]
2. ...

### Segment-Specific Objections
**[Persona]:** [objection]
...

---

## Resonance Map

### Universal Resonators (landing with 6+ personas)
1. [element] — reason it works broadly
...

### Segment-Specific Wins
**[Persona]:** [element] — [why it works for them]
...

---

## Drop-Off Analysis

| Persona | Drop-Off Point | Trigger |
|---|---|---|
| [name] | [specific moment in content] | [what caused it] |
...

---

## Critical Leaks (Fix These First)

1. **[Leak]** — Losing [N] personas at [point] because [reason]
   - Fix: [what would address this without breaking what's working]

---

## Per-Persona Full Reactions

[Full reaction from each buyer-persona agent, formatted as documented in agent]
```

---

## Output Format: reactions.json

```json
{
  "run_date": "YYYY-MM-DD",
  "content_type": "...",
  "personas_tested": 12,
  "aggregate": {
    "buy_probability_mean": 0.0,
    "buy_probability_range": [0.0, 0.0],
    "yes_count": 0,
    "maybe_count": 0,
    "no_count": 0
  },
  "per_persona": [
    {
      "persona_id": "...",
      "buy_decision": "YES|NO|MAYBE",
      "confidence": 0,
      "would_reach_checkout": true,
      "top_objection": "...",
      "drop_off_risk": "HIGH|MEDIUM|LOW",
      "resonant_elements": [],
      "friction_elements": []
    }
  ]
}
```

---

## Integration Notes

### Copywriting Arena
Called after Phase 6 (Marketplace Judge). Pass each of the top 2-3 entries separately. Results saved to `round-X/results/buyer-heat-map-[copywriter].md`. Marketplace judge may reference these in final notes.

### Webinar Arena
Called after webinar judgment. Pass the full winning script. Results saved alongside resistance-map.md. Provides segment-level conversion data for learning briefs.

### Standalone
User can call `/sim-audience` at any time with any content. Saves to location user specifies or prompts for path.

---

## Persona Subset Shortcuts

If user specifies a campaign context, suggest appropriate persona subsets:

- **Cold traffic campaign:** ColdSkeptic, AIAnxious, Transformer, ToolCollector (new eyeballs)
- **Email to existing list:** SkepticalVet, RepeatBuyer, Strategist, RevenueOp (warm known buyers)
- **High-ticket offer:** PremiumBuyer, SkepticalVet, Strategist, Credentialist
- **Mass market / webinar:** All 12 (widest read of the room)
- **Community offer:** CommSeeker, Transformer, AIAnxious, Overwhelmed
