# sim-audience-blind

## Purpose

Run content through the Simulated Audience Engine with **blind sequential reaction** — each persona reacts section-by-section without knowing what comes next.

The key difference from `/sim-audience`: personas do not have access to future sections when reacting to current ones. This produces honest drop-off tracking, genuine surprise/disappointment signals, and turning-point identification that retroactive synthesis cannot replicate.

---

## Trigger

User invokes `/sim-audience-blind` with content to test.

---

## Inputs

```
CONTENT: [the copy, email, ad, offer, or script — can be a file path]
CONTENT TYPE: [copy | email | ad | webinar-script | offer | positioning-statement]
AUDIENCE CONTEXT: [optional — describe audience, or "general"]
PERSONAS: [optional — comma-separated persona IDs, or "all" (default: all 12)]
OUTPUT PATH: [where to save results]
```

---

## Persona Library Location

`~/Obsidian/Active-Brain/00 Projects/Simulated Audience Engine/personas/persona-library.json`

---

## Execution Flow

### Step 1: Load Personas
Read `persona-library.json`. Select personas (default: all 12).

### Step 2: Split Content Into Sections
Read the full content. Identify natural section breaks. For webinar scripts: use phase headers, demo transitions, testimonial bridges, and offer/close as natural split points. Target 8–12 sections.

Label each section clearly:
```
[SECTION 1: Opening / Hook] (~min 0-5)
[SECTION 2: Phase 1 - Failure Validation] (~min 5-15)
[SECTION 3: Phase 2 - Root Cause + Category Distinction] (~min 15-30)
[SECTION 4: Demo Setup] (~min 28-32)
[SECTION 5: Demo 1 - Autonomous Cascade] (~min 32-50)
[SECTION 6: Testimonial Bridge 1] (~min 50-53)
[SECTION 7: Demo 2 - Different Business] (~min 53-65)
[SECTION 8: Testimonial Bridge 2] (~min 65-69)
[SECTION 9: Demo 3 + Rich's OS] (~min 69-83)
[SECTION 10: The Bridge] (~min 83-86)
[SECTION 11: The Close] (~min 86-90)
```

For sales letters/VSLs: use hook, problem, mechanism reveal, proof, offer, guarantee, close as sections.
For emails: paragraph breaks or logical argument shifts.

### Step 3: Build Blind Prompt
Construct a single prompt per persona group (4 personas per group) using this interleaved format:

```
You are running a BLIND audience simulation for 4 personas.

PERSONAS:
[Full persona profiles for all 4]

STRICT RULES:
1. Process sections IN ORDER. Do not read ahead.
2. For each section, complete ALL [REACT] blocks for all 4 personas BEFORE reading the next section.
3. Once a [REACT] block is written, it cannot be revised — even if later sections change the picture.
4. STILL WATCHING must be answered honestly. If a persona would have dropped off before this section, mark them as DROPPED and stop reacting for that persona.

REACT BLOCK FORMAT (complete for each persona at each section):
---
[PERSONA NAME]
STILL WATCHING: YES / WAVERING / DROPPED
TRUST LEVEL: 0-100
INTERNAL STATE: (what they're thinking right now, in their voice)
PREDICTION: (what they expect to happen next — before reading the next section)
DROP-OFF TRIGGER: (what specific word/claim/moment in this section almost lost them, if anything)
---

=== SECTION 1: [label] ===
[content]

[REACT — Section 1]
[Complete blocks for all 4 personas]

=== SECTION 2: [label] ===
[content]

[REACT — Section 2]
[Complete blocks for all 4 personas]

[... continue through all sections ...]

=== FINAL VERDICT ===
[Complete for each persona that reached the end]

[PERSONA NAME]
BUY DECISION: YES / NO / MAYBE
CONFIDENCE: 0-100%
TOP OBJECTION:
TURNING POINT SECTION: (which section changed your evaluation most, and why)
WHAT MOVED THE NEEDLE:
WHAT ALMOST LOST YOU:
PREDICTION ACCURACY: (list 2-3 predictions you made that were right or wrong — shows where surprises happened)
```

### Step 4: Spawn Blind Panel (Parallel)
Spawn 3 Task agents (groups of 4 personas) using `general-purpose` subagent type.

Each agent receives:
- The 4 persona profiles
- The fully structured blind prompt with all section content interleaved with REACT blocks
- Instruction to process strictly in order and not revise earlier reactions

All 3 run in parallel. Wait for all to complete.

### Step 5: Aggregate Results

From the completed blind reactions, compile:

1. **Drop-off map** — Which personas dropped at which sections, with exact trigger
2. **Trust progression chart** — Trust level per persona across sections (0-100 at each section)
3. **Prediction accuracy log** — Where the content surprised vs. met expectations (surprises = section did more work than expected)
4. **Turning point analysis** — Which sections moved evaluations most across the most personas
5. **Per-persona verdict table** — Buy decision, confidence, top objection
6. **Objection bank** — Grouped by theme
7. **Resonance map** — What landed and when
8. **Critical leaks** — Where multiple personas are dropping or wavering simultaneously

**New outputs not available in retroactive mode:**
- Exact drop-off sections with triggering language
- Trust level arcs (rising/falling/volatile)
- Prediction violations (where the content surprised positively or negatively)
- Turning point sections by persona

### Step 6: Write Output

Write to:
- `[OUTPUT_PATH]/buyer-heat-map-blind.md` — full analysis
- `[OUTPUT_PATH]/trust-arcs.md` — section-by-section trust levels per persona (table format)
- `[OUTPUT_PATH]/think-pads/[PersonaName].md` — individual think pads (same format as sim-audience)

---

## Output Format: buyer-heat-map-blind.md

```markdown
# Buyer Heat Map (Blind): [Content Type] — [Date]
**Mode:** Blind sequential reaction
**Sections tested:** [N]
**Personas:** [N]

## Summary

**Aggregate Buy Probability:** [X]% (range: [low]–[high])
**Earliest drop-off:** [persona] at Section [N] — [trigger]
**Latest-holding skeptic:** [persona] — held through Section [N] before committing
**Biggest positive surprise:** Section [N] — overdelivered vs. [N] personas' predictions
**Biggest negative surprise:** Section [N] — underdelivered vs. [N] personas' predictions
**Universal turning point:** Section [N] — moved [N] personas' evaluations

---

## Trust Arc Summary

| Persona | S1 | S2 | S3 | S4 | S5 | S6 | S7 | S8 | S9 | S10 | S11 | Final |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
[trust levels 0-100 per section per persona]

---

## Drop-Off Map

| Persona | Dropped at | Trigger |
|---|---|---|
[personas that dropped, with section and specific trigger]

---

## Persona Scorecard

[Same as sim-audience format]

---

## Turning Point Analysis

### Sections that moved the most personas
1. Section [N]: [label] — moved [N] personas, direction: [up/down/split]
   Reason: [what happened in this section that shifted evaluations]

---

## Prediction Accuracy Log

### Where the content positively surprised personas (prediction was pessimistic, reality was better)
- [Persona] at Section [N]: expected [X], got [Y]

### Where the content negatively surprised personas (prediction was optimistic, reality disappointed)
- [Persona] at Section [N]: expected [X], got [Y]

---

## Objection Bank
[Same structure as sim-audience]

## Resonance Map
[Same structure as sim-audience]

## Critical Leaks
[Same structure as sim-audience, but now includes exact section numbers]
```

---

## Output Format: trust-arcs.md

```markdown
# Trust Arc Data: [Content] — [Date]

## Trust Level by Section

| Persona | S1 | S2 | S3 | S4 | S5 | S6 | S7 | S8 | S9 | S10 | S11 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| SkepticalVet | 35 | 38 | 42 | 42 | 68 | 72 | 75 | 70 | 80 | 82 | 85 |
[... all personas ...]

## Interpretation
[Which sections caused the sharpest rises and drops, and what that means]
```

---

## Why This Is Better Than Retroactive

**What blind mode catches that retroactive misses:**

1. **Real pre-demo drop-offs** — Personas who would abandon before the demo never get credit from seeing the demo. Their confidence scores reflect genuine cold-entry friction.

2. **Prediction violations** — When a persona predicts "another pitch coming" and instead gets a live demo, that surprise is explicitly captured. When a persona expects social proof and doesn't get it, the disappointment is recorded.

3. **Turning point precision** — Instead of inferring "the demo moved them," you get "Trust went from 42 to 68 at Section 5 specifically" with the prediction violation that caused it.

4. **Honest negative surprises** — If a section promises something that the next section doesn't deliver, personas react to the gap in real time.

---

## Integration Notes

Use blind mode when:
- Testing a revised script against a prior version (blind mode differentials are more reliable)
- The content has a clear sequential arc (webinars, VSLs, long-form sales letters)
- You want to know exactly WHERE something is working or failing, not just WHETHER it works

Use standard `/sim-audience` when:
- Content is not sequential (ads, emails, positioning statements)
- Speed matters more than precision
- You want a quick directional read

---

## Persona Subset Shortcuts

Same as `/sim-audience`:
- **Cold traffic webinar:** ColdSkeptic, AIAnxious, Transformer, ToolCollector
- **Warm list:** SkepticalVet, RepeatBuyer, Strategist, RevenueOp
- **High-ticket:** PremiumBuyer, SkepticalVet, Strategist, Credentialist
- **All 12:** Full read
