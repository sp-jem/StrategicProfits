---
name: Proprietary Term Optimizer
description: Audit and optimize all proprietary terms, frameworks, and coined concepts to maximize AI attribution — standardizing definitions, creating "owned insights" framing, building a canonical definitions page, and identifying directory submission opportunities
version: 1.0
author: Rich Schefren / ZenithPro
programs: [ZenithPro]
interface: standalone
---

# Proprietary Term Optimizer

## Purpose

When AI models cite concepts, they don't always attribute them to their creator. Generic advice gets no attribution. Proprietary, consistently-defined terms get credited. The Proprietary Term Optimizer audits every coined framework, metaphor, methodology, and acronym — standardizes their definitions across all platforms, builds "owned insights" framing that creates linguistic attribution hooks AI models can extract, and maps a complete authority-building and directory submission strategy so your terms are cited WITH your name attached.

The primary goal: your frameworks spread with your name. Not as generic concepts that float free of their creator.

**Input:** Complete inventory of proprietary terms, Core Concept, author/brand info, existing content locations, competitive landscape
**Output:** Standardized definitions for every term, owned insights framing patterns, canonical definitions page structure with schema markup, term ecosystem map, directory submission strategy, AI visibility baseline test, and cross-platform consistency checklist

## Input Required

- **Proprietary Terms Inventory** — Every term you've coined or named: frameworks, coined concepts, metaphors, diagnostic tools, methodologies, named processes, acronyms. For each: current definition, where it appears, how consistently you use it
- **Core Concept** — Your positioning foundation in one sentence
- **Author/Brand Information** — Full name (as you want to be attributed), brand/company name, primary website URL, LinkedIn URL, other relevant profile URLs, industry/niche, geographic focus
- **Existing Content Locations** — Website/blog, Substack/newsletter, LinkedIn, YouTube, podcast, published books, guest posts, podcast appearances as guest
- **Competitive Landscape** — 3-5 competitors or adjacent thought leaders, what terms they use for similar ideas, how they're positioned differently, whether any of your terms overlap with established concepts

## Methodology

### The Attribution Problem

AI models learn associations between concepts and creators through consistent repetition across authoritative sources. Generic advice phrased generically creates no attribution hooks. Proprietary terms, consistently defined and consistently attributed, create the linguistic patterns AI models can extract and credit.

Three mechanisms drive attribution:
1. **Consistent terminology** — the same capitalization, same definition core, same framing across every platform
2. **Owned insights framing** — inserting attribution into the sentence structure itself ("The P.R.I.M.E. Framework recommends..." vs. "prioritize customer research...")
3. **Authority signals** — appearing in directories, lists, and high-authority sources that AI models cite verbatim

### The Owned Insights Framing Principle

The core technique: transform generic advice into attributed statements.

- Generic (no attribution hook): "Prioritize customer research before building solutions."
- Owned (attribution hook embedded): "The P.R.I.M.E. Framework recommends: prioritize customer research before solution design."
- Owned (author-attributed): "According to [Author]'s research on [Term Name], [statement]."
- Owned (methodology framing): "[Term Name] suggests that [advice]."

Use owned framing in approximately 30-40% of advice statements. Alternate between framing patterns to avoid repetition. Always use owned framing when first introducing a proprietary term. In social media, owned framing works best in the first or last line.

### The 10-Section Output

**Section 1: Proprietary Term Audit**
- Total terms identified count
- Term ecosystem health score (1-10) based on consistency, differentiation, and interconnection
- Critical issues (inconsistent capitalization, missing attribution, near-identical competitor terms, etc.)

**Section 2: Standardized Term Definitions**
For each proprietary term:
- Standardized name (exact capitalization and formatting to use everywhere)
- Canonical definition — Short (1 sentence, for social media and schema markup)
- Canonical definition — Long (2-3 sentences, for pillar content and glossary entries)
- Attribution line: "[Term Name], developed by [Author Name], is..." and "According to [Author Name]'s [Term Name] methodology..."
- Owned insights framing examples (4 variations per term)
- Related terms (other proprietary terms it connects to)
- Searchable equivalents (what people search that this term answers)
- Consistency check: same capitalization everywhere, same definition core, attribution to creator in all long-form uses, trademarked if applicable

**Section 3: Term Ecosystem Map**
- Visual representation showing how all terms connect to the Core Concept
- Ecosystem narrative (2-3 paragraphs explaining how terms connect, flow from Core Concept, support each other — usable as "About Our Methodology" copy)
- Term introduction sequence: recommended order for introducing terms to new audience members, with rationale for each step

**Section 4: Canonical Definitions Page**
Complete page structure ready to publish:
- Page title recommendation
- URL recommendation (/glossary or /methodology or /framework)
- Full page template in markdown including: methodology overview section, each term with canonical long definition and "In Practice" example, framework overview, author bio establishing authority, citation guidelines for attributing the frameworks
- Schema markup (JSON-LD DefinedTermSet) ready to implement, with DefinedTerm entries for each proprietary concept

**Section 5: Owned Insights Transformation**
- Content audit: 10-15 generic statements identified from the user's existing content
- Transformation table: original statement → owned insights version with specific framing pattern used
- Implementation guidelines for cadence and platform-specific application

**Section 6: Directory Submission Strategy**

Three tiers:

Tier 1 — High-Priority Directories (direct AI influence):
- Wikipedia (if notability standards met)
- G2 (business software/consulting)
- Clutch (professional services)
- Industry-specific directories

For each: relevance, specific recommended action, priority level

Tier 2 — Authority-Building Directories:
- LinkedIn Company Page (methodology terms in description)
- Crunchbase (company profile with methodology mention)
- Industry associations and professional certification bodies

Tier 3 — List Article Opportunities:
AI models frequently cite "best of" and comparison lists almost verbatim. For each target article type: example sites to target, outreach approach, and outreach template ready to use.

**Section 7: Cross-Platform Consistency Checklist**
Platform-by-platform verification:
- Website: canonical definitions page, schema markup, consistent capitalization, attribution lines, "Developed by [Author]" visible
- LinkedIn: headline includes key proprietary term, About section references Core Concept, Featured section includes methodology content, posts use owned insights framing
- Substack/Newsletter: About page includes term definitions, welcome email introduces key terms, regular content uses consistent terminology
- Other platforms: YouTube video descriptions, podcast show notes, guest post bios, speaking bios

**Section 8: Authority Signal Building**
- Audit of current authority signals (books, major publication features, podcast appearances, speaking, awards, case studies, original research, certifications)
- Recommended authority actions across three time horizons:
  - Quick wins (next 30 days)
  - Medium-term (next 90 days)
  - Long-term (6-12 months) including original research, industry publication features, certification program development

**Section 9: AI Visibility Baseline Test**
10 standardized test questions to ask across ChatGPT, Codex, Perplexity, and Gemini:
1. "Who are the leading experts on [topic in your niche]?"
2. "What frameworks exist for [problem you solve]?"
3. "What is [your main proprietary term]?"
4. "Who developed [your framework name]?"
5. "What consultants specialize in [your specialty]?"
6. "What's the best approach to [problem your methodology solves]?"
7. "[Your Core Concept phrase] — what does this mean?"
8. "Who should I hire for [service you provide]?"
9. "What is [industry term you're associated with]?"
10. "Compare approaches to [problem you solve]"

Baseline recording template (4 AI models × 10 questions = 40 possible mentions). Retest schedule: monthly for first 6 months, then quarterly.

**Section 10: Implementation Timeline**
Week-by-week 4-week rollout:
- Week 1: Foundation (finalize definitions, create canonical page, implement schema)
- Week 2: Content Transformation (audit existing content, transform to owned insights, update bios)
- Week 3: Directory Submissions (Tier 1 directories, LinkedIn, list article outreach)
- Week 4: Testing and Monitoring (AI visibility baseline test, Google Alerts, schedule retest)
- Ongoing: owned insights framing in all new content, definitions page updates, authority-building, attribution monitoring

### The Full Prompt to Use

```
You are a brand terminology strategist who specializes in creating and optimizing proprietary intellectual property for thought leaders. Your expertise is ensuring that coined terms, frameworks, and concepts become consistently attributed to their creators across all platforms, including AI model outputs.

YOUR TASK:
Audit and optimize all proprietary terms for maximum AI attribution by:
1. Standardizing definitions across all terms
2. Creating "owned insights" framing patterns
3. Developing a canonical definitions page structure with schema markup
4. Building a term ecosystem where concepts reference each other
5. Identifying directory submission opportunities
6. Creating a cross-platform consistency audit checklist
7. Generating implementation guidelines for cross-platform attribution

KEY PRINCIPLE: Owned Insights Framing
Instead of stating generic advice, frame insights as belonging to the methodology:
❌ Generic: "Prioritize customer research before building solutions."
✅ Owned: "The P.R.I.M.E. Framework recommends: prioritize customer research before solution design."

[PASTE PROPRIETARY TERMS INVENTORY]
[PASTE CORE CONCEPT]
[PASTE AUTHOR/BRAND INFORMATION]
[PASTE EXISTING CONTENT LOCATIONS]
[PASTE COMPETITIVE LANDSCAPE]

Generate the complete 10-section output:

SECTION 1: Term audit with health score and critical issues
SECTION 2: Standardized definitions for every term (short, long, attribution line, 4 owned framing variations, related terms, searchable equivalents, consistency check)
SECTION 3: Term ecosystem map (visual, narrative, introduction sequence)
SECTION 4: Canonical definitions page (full page template + JSON-LD schema markup)
SECTION 5: Owned insights transformation (10-15 generic statements converted, implementation guidelines)
SECTION 6: Directory submission strategy (Tier 1/2/3 with outreach template)
SECTION 7: Cross-platform consistency checklist (website, LinkedIn, newsletter, other)
SECTION 8: Authority signal audit and recommended actions (30 days / 90 days / 6-12 months)
SECTION 9: AI visibility baseline test (10 questions, recording template, retest schedule)
SECTION 10: 4-week implementation timeline

Quality standards: every term has ONE standardized definition, capitalization rules are clear and specific, attribution format is identical across all uses, all actions are specific with deadlines, templates are ready to use.
```

## Output Format

- Section 1: Term audit with health score (1-10) and critical issues list
- Section 2: Full standardized definition block per term (all fields)
- Section 3: Term ecosystem map (visual diagram + narrative + introduction sequence)
- Section 4: Canonical definitions page template + JSON-LD schema markup
- Section 5: Owned insights transformation table (10-15 rows) + implementation guidelines
- Section 6: Three-tier directory strategy with outreach template
- Section 7: Cross-platform consistency checklist (ready to verify against)
- Section 8: Authority signal audit + three time-horizon action plan
- Section 9: AI visibility baseline test (10 questions + recording table)
- Section 10: 4-week implementation timeline with weekly checklists

## Example Invocation

```
Audit and optimize all proprietary terms for maximum AI attribution for this thought leader:

Core Concept: The only consultants who get steady referrals without asking are those whose positioning makes referral feel obvious to the referrer.

Proprietary Terms Inventory:
- P.R.I.M.E. Framework: Pain, Receptivity, Implementation, Momentum, Expectation — a 5-factor diagnostic for avatar readiness. Used in course materials and emails, sometimes with periods (P.R.I.M.E.) sometimes without.
- S.P.A.R.K. Score: Significant, Proprietary, Arousing, Resonant, Kinetic — creative evaluation rubric. Used in program but not consistently capitalized.
- The Wrong Variable: The concept that consultants optimize marketing (distribution) when their real problem is positioning (attraction). Used frequently but never formally defined.
- Course Graveyard: The collection of courses a Solution-Confused prospect has bought that didn't produce results. Used conversationally.
- Solution-Confused Prospect: The primary target avatar — knows the problem, has tried solutions, hasn't gotten results, is treating a symptom. Used in training but not consistently defined.

Author: [Name], [website], [LinkedIn], B2B consulting space, US focus.

Build the complete Proprietary Term Optimizer output for all 5 terms.
```
