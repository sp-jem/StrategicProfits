---
name: gallin-reset-diagnostic
description: Use when growth stalls — diagnoses evolution vs. revolution needed.
version: 1.0.0
author: Strategic Profits / Hollywood Agents & Dealmakers Series
source_thinker: "Sandy Gallin (Career Transformation Specialist) — 'I look at the client as a business and the manager becomes the chairman of the board.' — Skill 1 of 6"
programs: [ZenithPro, Force Multiplier, Connect the Dots]
interface:
  invoke: "/gallin-reset-diagnostic {business-or-situation-description}"
  called_by: [user, gallin-field-intelligence]
  outputs_to: [client-output-folder]
---

# Gallin Reset Diagnostic

---

## LAYER 1: INVARIANTS (Never override.)

1. **Evolution and revolution are fundamentally different strategies with opposite risks.** Evolution optimizes what exists — same audience, better offer, refined positioning. Revolution replaces what exists — new audience, new positioning, new identity. Gallin's genius was knowing which one a client needed. Applying the wrong one is worse than doing nothing: evolution when you need revolution is slow death; revolution when you need evolution destroys assets.

2. **The audience loyalty test is the diagnostic key.** Gallin asked: what is the audience loyal to — the GENRE or the PERSON? When Dolly Parton's country audience was loyal to HER (not just country music), crossover was possible because the audience would follow. When an audience is loyal to the genre, crossing over means abandoning them. The diagnostic must identify what specifically the audience is loyal to.

3. **Chairman-of-the-Board thinking, not performer thinking.** Gallin treated each client as a corporation, not an individual performer. The diagnostic must evaluate the business as an entity with assets, liabilities, market position, and strategic options — not as a personal brand that needs a refresh. This changes what questions you ask and what options you see.

4. **Stagnation is not neutral — it is decline.** Markets move. Audiences evolve. Competitors advance. A business that is "stable" is actually falling behind at the rate the market is advancing. The diagnostic must assess not just current position but trajectory — where does this business end up in 3 years if nothing changes?

5. **The reset must be diagnosed from data, not feelings.** "I feel like we need a change" is not a diagnosis. Gallin looked at specific indicators: audience demographics shifting, engagement patterns changing, revenue sources concentrating or diversifying, competitor positioning moves. The diagnostic must ground the evolution/revolution decision in observable evidence.

---

## LAYER 2: QUALITY GUIDANCE

6. **Map the asset inventory before recommending destruction.** Revolution means abandoning some assets. Before recommending revolution, catalog every asset (audience, brand equity, content, relationships, systems) and what survives vs. what is lost.

7. **Test the hybrid option.** Sometimes the answer is partial revolution — evolve the core while launching a revolutionary flank. Gallin moved Dolly from country to pop without abandoning country. The diagnostic must evaluate whether a hybrid path exists.

8. **Time-horizon the recommendation.** Evolution is faster but caps growth. Revolution is slower but unlocks new ceilings. Make the time trade-off explicit.

---

## PURPOSE

Every business hits a point where the current approach stops working. Revenue plateaus. Engagement declines. The market feels different. At this inflection point, the owner faces the most consequential strategic decision: do I optimize what I have (evolution) or fundamentally change what I am (revolution)?

Sandy Gallin made this diagnosis for the biggest careers in entertainment. He looked at Dolly Parton — enormous country success but capped — and saw revolution: cross over to pop, reach a 10x larger audience, build a business empire. He looked at Cher — written off as a has-been — and saw revolution: relaunch through an adjacent medium (film), stack credibility wins, then convert back to music from a position of strength.

But not every stall needs revolution. Some need better execution of the existing strategy. The cost of getting this wrong is enormous — either years of wasted optimization on a fundamentally broken positioning, or destruction of working assets in pursuit of unnecessary change.

This skill makes the diagnosis.

---

## INPUT REQUIREMENTS

Provide:
1. **Business description** — what you sell, to whom, current positioning
2. **Growth history** — trajectory over the past 1-3 years
3. **Audience data** — who buys, engagement trends, demographic shifts
4. **Competitive landscape** — who is growing, who is declining, what's changing

Optional:
- Revenue breakdown by product/channel (to identify where growth is coming from)
- Customer feedback themes (to identify satisfaction vs. desire gaps)
- Previous pivots or repositioning attempts (to avoid repeating what didn't work)

---

## EXECUTION PROCESS

### Step 1: Stagnation Diagnosis

Confirm whether stagnation is actually occurring:

| Metric | 12mo Ago | 6mo Ago | Now | Trajectory |
|--------|---------|--------|-----|-----------|
| Revenue | | | | Up/Flat/Down |
| New customers | | | | |
| Retention | | | | |
| Engagement | | | | |
| Market share (est.) | | | | |

**Stagnation confirmed?** If all metrics are healthy, the diagnosis may be premature. Flag this.

### Step 2: Audience Loyalty Test

The Gallin diagnostic question — what is your audience loyal to?

| Loyalty Object | Evidence | Strength |
|---------------|----------|----------|
| You personally (the founder/brand) | Do they follow YOU across topics? | Strong/Moderate/Weak |
| The category/genre | Do they buy from anyone in this space? | |
| The specific offer | Are they loyal to THIS product specifically? | |
| The community | Are they loyal to each other? | |
| The results | Will they go wherever results are best? | |

**Loyalty verdict:** If loyalty is primarily to YOU, crossover/revolution is viable because the audience follows. If loyalty is primarily to the CATEGORY, revolution means starting from zero with a new audience.

### Step 3: Asset Inventory

What does the business actually own (tangible and intangible)?

| Asset | Current Value | Survives Evolution? | Survives Revolution? |
|-------|--------------|--------------------|--------------------|
| Audience/list | | Yes/Partial/No | |
| Brand equity | | | |
| Content library | | | |
| Relationships | | | |
| Systems/processes | | | |
| IP/frameworks | | | |
| Revenue streams | | | |

**Revolution cost:** Total value of assets that DON'T survive revolution.

### Step 4: Market Trajectory Analysis

Where is the market going (not where it is)?

- Is the current audience demographic growing or shrinking?
- Are competitors repositioning? In what direction?
- Are adjacent markets growing faster?
- Is technology changing what's possible?
- Are buyer expectations shifting?

**3-year inaction projection:** If you change NOTHING, where does this business end up?

### Step 5: Evolution vs. Revolution Scorecard

| Factor | Favors Evolution | Favors Revolution |
|--------|-----------------|-------------------|
| Audience loyalty | To category | To person |
| Market trajectory | Growing market | Shrinking market |
| Competitive position | Defensible | Being flanked |
| Asset portability | Low | High |
| Revenue headroom | Room to grow | Ceiling hit |
| Founder energy | Energized by current work | Burned out on current work |
| Adjacent opportunity | Small | Large |

**Score:** Count factors on each side. 5+ on either side is a clear signal.

### Step 6: Hybrid Assessment

Can you do both?

- **Evolve the core** while **launching a revolutionary flank** in a new market
- **Maintain current revenue** while **testing new positioning** with a subset
- **Keep the loyal base** while **building a bridge product** to a new audience

**The Dolly Parton hybrid:** She never abandoned country. She added pop. The country base stayed. The pop audience was net new. Is this possible for your business?

### Step 7: Diagnosis & Recommendation

**Verdict: EVOLUTION / REVOLUTION / HYBRID**

- **What specifically to evolve or revolutionize**
- **What to preserve**
- **What to abandon**
- **Timeline**
- **Risk assessment**
- **Recommended next Gallin skill to run**

---

## OUTPUT STRUCTURE

### Reset Diagnostic Report

**Section 1: Stagnation Diagnosis** — Is the business actually stagnating?
**Section 2: Audience Loyalty Test** — What is the audience loyal to?
**Section 3: Asset Inventory** — What survives each option?
**Section 4: Market Trajectory** — Where things are going without intervention
**Section 5: Evolution vs. Revolution Scorecard** — Factor-by-factor assessment
**Section 6: Hybrid Assessment** — Can you do both?
**Section 7: Diagnosis & Recommendation** — Clear verdict with rationale
**Section 8: Recommended Next Skill** — Which Gallin skill to run next

---

## SAVE LOCATION

Save complete report to:
`[project-folder]/Sandy Gallin - Reset Diagnostic/01 - Reset Diagnostic - [Business Name] - [Date].md`
