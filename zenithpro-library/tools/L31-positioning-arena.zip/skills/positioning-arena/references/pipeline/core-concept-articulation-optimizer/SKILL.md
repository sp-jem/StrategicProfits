---
name: Core Concept Articulation Optimizer
description: Generate 100+ variations of a core concept statement using rhetorical, poetic, and linguistic techniques to find the most memorable and viral expression
version: 1.0
author: Rich Schefren / ZenithPro
programs: [ZenithPro]
interface: standalone
---

# Core Concept Articulation Optimizer

## Purpose

A powerful idea expressed poorly dies. This skill takes a single core concept sentence and generates 100+ variations across 10 linguistic categories — rhythm, alliteration, rhyme, metaphor, antithesis, chiasmus, rule of three, compression, sound symbolism, and cultural echoes — then synthesizes the best elements into ultimate versions.

Use this after you have your Core Concept statement from the Core Concept Generator. The goal is to find the one articulation that spreads — the version that is naturally repeated by others, quoted in conversations, and shared without prompting.

## Input Required

- Your one-sentence Core Concept (the central idea that reframes how your market sees their problem)
- Optional: Target audience context
- Optional: Tone preferences (bold, conversational, academic, provocative)

## Methodology

### The 10 Variation Categories

**SECTION 1 — Rhythmic Variations**

Create versions with strong rhythmic patterns:
- Iambic rhythm (da-DUM da-DUM)
- Trochaic rhythm (DUM-da DUM-da)
- Parallel structure (same rhythm in both halves)
- Building rhythm (short → longer → longest)
- Staccato punch (short, sharp words)
- Rolling cadence (flowing, connected sounds)

Consider syllable count balance, stressed/unstressed patterns, and natural speaking rhythm.

**SECTION 2 — Alliterative Power**

Generate versions using alliteration:
- Opening alliteration (first words of each clause)
- Internal alliteration (key words throughout)
- Consonant clusters (pr-, str-, cr-, fl-)
- Soft sounds (s, f, h, w) vs. hard sounds (k, g, t, d)
- Triple alliteration (three key words)
- Bookend alliteration (first and last words)

**SECTION 3 — Rhyme Engineering**

Create rhyming variations:
- End rhyme
- Internal rhyme (within the sentence)
- Slant rhyme (near-rhymes that surprise)
- Masculine rhyme (single syllable) vs. feminine rhyme (multiple)
- Conceptual rhyme (ideas that "rhyme" thematically)

**SECTION 4 — Metaphorical Reframes**

Express the concept through metaphor:
- Physical metaphors (building, journey, battle)
- Natural metaphors (growth, weather, seasons)
- Technical metaphors (operating system, level, gear)
- Medical metaphors (symptom vs. disease)
- Sports metaphors (playing field, game, score)
- Musical metaphors (harmony, rhythm, tune)

**SECTION 5 — Antithesis and Contrast**

Sharpen the concept through opposition:
- Not X, but Y structures
- Surface vs. depth contrasts
- Assumed vs. actual problem
- Symptom vs. root cause
- Visible vs. invisible
- Tactical vs. strategic

**SECTION 6 — Chiasmus Patterns**

Create mirror structures (AB-BA):
- "Ask not what X can do for Y, but what Y can do for X"
- Reversed word order in second half
- Conceptual reversal

**SECTION 7 — Rule of Three**

Apply triple patterns:
- Three-word punch phrases
- Three-part progression
- Three parallel clauses
- Setup, setup, punchline

**SECTION 8 — Compression Techniques**

Distill to maximum impact:
- Remove every unnecessary word
- Use Anglo-Saxon words (short, punchy)
- Active voice only
- Present tense
- Single-syllable word versions

**SECTION 9 — Sound Symbolism**

Use phonesthemes (sound-meaning associations):
- GL- words (glimmer, glow) for vision/clarity
- SL- words (slip, slide) for smoothness
- CR- words (crack, crush) for breaking through
- FL- words (flow, flourish) for movement
- ST- words (stuck, static) for stillness

**SECTION 10 — Cultural Echoes**

Adapt familiar phrase patterns:
- Movie quote structure
- Proverb structures
- Famous speech patterns
- Ad slogan rhythms
- Book title patterns

### Synthesis Round

After generating all variations, produce 10 Ultimate Versions combining the best elements:

1. **The Rhythm Master** — Best rhythmic flow
2. **The Alliteration King** — Most powerful alliterative impact
3. **The Rhyme Lord** — Strongest rhyming memorability
4. **The Metaphor Maker** — Clearest metaphorical expression
5. **The Contrast Champion** — Sharpest antithesis
6. **The Mirror Master** — Best chiasmus structure
7. **The Triple Threat** — Strongest three-part pattern
8. **The Compression King** — Maximum impact, minimum words
9. **The Sound Sage** — Best sound symbolism
10. **The Culture Echo** — Most familiar yet fresh

### Evaluation Criteria

Rate each variation on (1-10 each):
- **Memorability**: How easily remembered?
- **Repeatability**: How naturally spoken?
- **Impact**: How powerful the insight?
- **Clarity**: How immediately understood?
- **Virality**: How likely to be shared?

Total Score: ___/50

### Final Selection: Top 5

Choose the Top 5 based on:
1. Highest combined score
2. Most natural to say aloud
3. Most likely to be repeated by others
4. Clearest communication of concept
5. Most emotionally resonant

For each top version, provide:
- The Version: [exact wording]
- Why It Works: [linguistic explanation]
- Use Case: [when/where to deploy]
- Memorability Hook: [what makes it stick]

### Testing Phrases

Provide 3 test scenarios:
1. "A consultant at a conference tells another consultant..."
2. "Someone explaining to their spouse why they need this program..."
3. "A client testimonial naturally saying..."

### The Full Prompt to Use

```
You are a master linguist with access to every rhetorical device, poetic technique, and memorable phrasing pattern ever documented. Your mission is to take this single core concept sentence and generate 100+ variations that maximize memorability, repeatability, and impact.

INPUT CORE CONCEPT: [Insert the one-sentence core concept here]

Generate variations using ALL of the following techniques (10-15 variations per category):

SECTION 1: RHYTHMIC VARIATIONS (iambic, trochaic, parallel, building, staccato, rolling)
SECTION 2: ALLITERATIVE POWER (opening, internal, consonant clusters, triple)
SECTION 3: RHYME ENGINEERING (end, internal, slant, masculine/feminine)
SECTION 4: METAPHORICAL REFRAMES (physical, natural, technical, medical, sports, musical)
SECTION 5: ANTITHESIS & CONTRAST (not X but Y, surface vs depth, symptom vs cause)
SECTION 6: CHIASMUS PATTERNS (AB-BA mirror structures)
SECTION 7: RULE OF THREE (three-word punch, progression, setup-setup-punchline)
SECTION 8: COMPRESSION TECHNIQUES (remove every unnecessary word, Anglo-Saxon only)
SECTION 9: SOUND SYMBOLISM (GL-, SL-, CR-, FL-, ST- words)
SECTION 10: CULTURAL ECHOES (movie quotes, proverbs, famous speech patterns)

SYNTHESIS ROUND: Create 10 Ultimate Versions combining the best elements across categories.

Rate each variation: Memorability | Repeatability | Impact | Clarity | Virality (each 1-10)

Select Top 5 with: exact wording, why it works, use case, memorability hook.

Test top 3 in three conversation scenarios.
```

## Output Format

- 100+ variations organized by category (10-15 per section)
- Scores for each variation (out of 50)
- 10 Ultimate Synthesis versions
- Top 5 final selections with full analysis
- 3 conversation scenario tests
- Single recommended winner for deployment

## Example Invocation

```
Run the Core Concept Articulation Optimizer on this concept:

"You don't have a marketing problem. You have a positioning problem — and every marketing tactic you try is just a symptom of that underlying cause."

Generate 100+ variations across all 10 categories, synthesize into 10 Ultimate Versions, then give me the Top 5 with deployment recommendations.
```

The goal is finding the version that becomes the line people quote without being asked to — the kind of phrase that shows up in testimonials naturally, gets shared in DMs, and becomes the shorthand for your entire methodology.
