---
name: positioning-arena-wildcard
description: Wild Card Methodology Generator for Positioning Arena. Imports an external positioning document (a real company's positioning, a swipe, a competitor brief), codifies it as a TEMPORARY competitor school, enters it into the arena alongside the permanent schools, and on a win routes it to the spawner for breakthrough extraction.
version: 1.0.0
author: Rich Schefren
arena: positioning
triggers:
  - /positioning-arena-wildcard
  - /posarena-wildcard
  - create positioning wild card
---

# Positioning Arena Wild Card Generator

## Purpose

Import an external positioning document — a real company's positioning, a competitor swipe, a category-design brief, a published brand strategy — and create a TEMPORARY wild card school to compete against the 13 permanent schools in the Positioning Arena. If the wild card wins or outperforms its band, extract breakthrough principles via the spawner.

---

## Commands

### `/positioning-arena-wildcard [file-or-text]`

Create a positioning wild card from an external source.

**Supported Sources:**
- Company positioning document (PDF, text file, URL)
- Competitor brand brief or category-design deck
- Published positioning swipe (tagline + supporting materials)
- Product launch announcement with positioning language
- Sales page, landing page, or brand manifesto
- Analyst report framing a company's market position
- Interview transcript where a founder explains their positioning

**Example invocation:**
```
/positioning-arena-wildcard ~/Desktop/notion-brand-brief.pdf
Name: Notion Connected Workspace
Description: Notion's actual all-in-one positioning vs. fragmented tool stack
```

---

## Wild Card Creation Process

### Phase 1: Source Ingestion and Analysis

Read the source material end-to-end. Extract:

**Structural elements:**
- Category claim (what market/category does this company say it owns or is creating?)
- Core enemy (what status quo, incumbent, or behavior is it positioned against?)
- Owned concept or word (the single idea it stakes a claim to)
- Proof basis (what makes the claim credible — not features, but a frame)
- Audience anchor (who is this position designed to land with first?)
- Tension mechanism (what internal or market tension does this position exploit?)

**Methodology fingerprint:**
- Which of the 13 permanent schools does this most resemble? (Closest cousin)
- Which school does it most diverge from, and why?
- Is there a novel structural move not represented in any permanent school?

**Failure modes visible in the source:**
- Where is the logic incomplete or assumptive?
- Where does it borrow too heavily from a permanent school without adding delta?
- What would a Trout, Dunford, or Play Bigger critique surface immediately?

---

### Phase 2: Methodology Codification

Write the wild card competitor file using the same schema as permanent posarena schools.

**File template:**

```markdown
---
name: wildcard-[id]
description: [One-sentence summary of source company/approach]
version: 1.0.0 (wild card — experimental)
source: [Original file path or URL]
created: [ISO date]
status: Experimental
closest_cousin: [Permanent school ID most similar to this approach]
---

# Wild Card: [Name]

## Source
[Original material description — company, document type, date if known]

## Core Philosophy
[What makes this approach unique — the insight that differentiates it from
all 13 permanent schools. If there is no genuine delta, state that explicitly
rather than inventing novelty that isn't there.]

## Methodology (codified from source)

### Category Move
[How this approach defines, names, or creates its category]

### Enemy Frame
[How it identifies and names what it is positioned against]

### Owned Concept
[The word, phrase, or idea it attempts to own in the target mind]

### Proof Architecture
[How it makes its claim credible without relying on features alone]

### Audience Strategy
[Who it targets first and why — the beachhead logic]

### Tension It Exploits
[What market or psychological tension this position is designed to resolve]

## Key Techniques (ranked by novelty vs. permanent schools)
1. [Most novel technique — delta from existing schools]
2. [Second technique]
3. [Third technique]
...

## Structural Divergence from Closest Cousin
[Explicit comparison: what does this approach do that [closest_cousin] does not,
and vice versa? Do not merge them — treat the differences as the signal.]

## When to Use
[Market conditions, product stages, or audience contexts where this approach
would outperform the permanent schools — or the conditions where it would fail.]

## Known Vulnerabilities
[What Trout/Dunford/Play Bigger/etc. would attack first in this position,
and whether the source material has a defense.]

---
*Wild Card — Experimental Methodology. Entered: [date]. Status: [active|archived|extracted]*
```

---

### Phase 3: Competition Entry

The wild card enters the full arena as an additional competitor in the band that matches its closest cousin, OR as a standalone cross-band entry if it does not cleanly fit Band A, B, or C.

**Entry rules:**

| Condition | Entry placement |
|-----------|----------------|
| Clearly a positioning school approach | Band A (alongside Trout, Dunford, Marion, Dell, Raskin, Brunson, Moore, Yoon, Godin, Klaff) |
| Clearly a category-design approach | Band B (alongside Play Bigger, Category Pirates, Blue Ocean) |
| A lens/psychology approach | Band C (alongside the 7 deep-thinker lenses) |
| Hybrid or novel structure | Cross-band — wild card band, judged against all 13 |

**Competition count by entry type:**

- Band-specific entry: [N permanent competitors in band] + 1 Wild Card + synthesis
- Cross-band entry: 13 permanent competitors + 1 Wild Card + synthesis

The wild card receives the same excavation brief as every permanent school. It competes on equal footing with no adjustments for being experimental.

---

### Phase 4: Judging

The positioning judge scores all entries including the wild card on the standard rubric:
- Clarity of category claim
- Sharpness of enemy frame
- Memorability of owned concept
- Credibility of proof basis
- Specificity of audience anchor
- Defensibility against counter-positioning

The wild card's score is flagged with a `[WC]` marker in the scorecard so it is visually distinct. No scoring leniency is applied — experimental status does not buy partial credit.

---

### Phase 5: Result Routing

#### IF WILD CARD WINS OR TIES BAND LEADER:

Route to the `positioning-school-spawner` agent for breakthrough extraction.

**Spawner receives:**
1. Wild card codification file
2. Arena scorecard with judge commentary
3. Side-by-side comparison vs. closest permanent cousin
4. Explicit delta analysis (what the wild card did that the permanent school did not)

**Spawner determines extraction type:**

| Extraction type | Trigger condition | Output |
|----------------|-------------------|--------|
| **Full Spawn** | Wild card won on a genuinely novel structural move absent from all permanent schools | New permanent posarena school skill at `~/.claude/skills/posarena-[id]/SKILL.md` + roster.json entry |
| **Principle Add** | Wild card won on a technique that enhances an existing school without replacing it | Addendum to the closest cousin school's SKILL.md under `## Absorbed Techniques` |
| **Archive with Citation** | Wild card performed well but no novel structural move identified — already covered by existing schools | Move to `archived/` with citation of which permanent school absorbed the win |

All Full Spawn and Principle Add extractions require explicit approval before writing to permanent school files.

#### IF WILD CARD LOSES:

Archive for reference. Log what failed and which permanent school outperformed it and why. This is signal for future wildcard submissions — patterns of failure accumulate into a "what not to import" guide.

---

## Wild Card Storage

```
~/.claude/positioning-arena/wild-cards/
├── active/
│   └── wildcard-[id]/
│       ├── SKILL.md             (codified methodology)
│       ├── source.md            (original material excerpt or summary)
│       ├── analysis.md          (Phase 1 extraction output)
│       └── arena-result.md      (scorecard + judge commentary)
├── archived/
│   └── [wild cards that lost or were subsumed by permanent schools]
└── extracted/
    └── [wild cards that became permanent school additions or spawns]
```

Arena competition output (positions, scorecards, synthesis) writes to the standard output root:
```
~/Obsidian/Active-Brain/00 Projects/Positioning Arena/
```

---

## Breakthrough Extraction Detail

When the spawner is triggered, it runs the following sequence:

```
1. Confirm the novel structural move (what specifically did the wild card do 
   that the permanent schools cannot do without adopting a different theory?)

2. Test codifiability: can this move be written as 3–5 invariant principles 
   that a Claude agent can reliably execute from a brief?

3. Determine extraction type (Full Spawn / Principle Add / Archive with Citation)

4. If Full Spawn:
   - Draft new posarena-[id] SKILL.md following permanent school schema
   - Propose roster.json entry with band assignment
   - Await Rich's approval before writing permanent files

5. If Principle Add:
   - Draft the addendum section for the target school's SKILL.md
   - Await Rich's approval before modifying permanent school files

6. If Archive with Citation:
   - Move wildcard to archived/ directory
   - Write 1-paragraph citation explaining which permanent school 
     already covers this ground and where
```

---

## Use Cases

**Import live competitor positioning for competitive war-gaming:**
- A direct competitor's brand positioning page
- A well-funded startup's category-design thesis
- A market leader's repositioning announcement

**Test unconventional positioning structures:**
- Non-category positioning (personality-first brands like Apple in early 1984)
- Anti-positioning (deliberately refusing to claim a category)
- Temporal positioning (being first to name what the market is becoming, not what it is)
- Community-anchored positioning (the position is held by the tribe, not the product)

**Import positioning from adjacent domains:**
- Professional services firms repositioning as platforms
- Government or non-profit sector positioning (mission clarity as competitive advantage)
- Media/publishing brands where the author IS the position
- Physical product brands with strong category-design language

**Test academic or theoretical frameworks against live briefs:**
- A business school case study's positioning recommendation
- A consultant's brand architecture deliverable
- A VC pitch deck's market framing

---

## Output: Confirmation JSON

On successful wild card creation and arena entry, return:

```json
{
  "status": "ok",
  "wildcard": {
    "id": "wildcard-[id]",
    "name": "[Human-readable name]",
    "source": "[File path or URL]",
    "closest_cousin": "[Permanent school ID]",
    "band_entry": "A|B|C|cross-band",
    "codification_path": "~/.claude/positioning-arena/wild-cards/active/wildcard-[id]/SKILL.md"
  },
  "arena_entry": {
    "competitors_in_round": [N],
    "wild_card_included": true,
    "excavation_brief_used": "[Brief summary or path]"
  },
  "result": {
    "outcome": "win|loss|tie",
    "rank": "[Position in final scorecard]",
    "spawner_triggered": true|false,
    "extraction_type": "full_spawn|principle_add|archive_with_citation|pending|n/a",
    "extraction_requires_approval": true|false
  },
  "output_paths": {
    "arena_output": "~/Obsidian/Active-Brain/00 Projects/Positioning Arena/[run-folder]/",
    "wildcard_file": "~/.claude/positioning-arena/wild-cards/active/wildcard-[id]/SKILL.md",
    "arena_result": "~/.claude/positioning-arena/wild-cards/active/wildcard-[id]/arena-result.md"
  }
}
```

---

*Part of Positioning Arena v1.0. Permanent schools roster: posarena-trout, posarena-dunford, posarena-marion, posarena-dell, posarena-raskin, posarena-brunson, posarena-moore, posarena-yoon, posarena-godin, posarena-klaff, posarena-play-bigger, posarena-category-pirates, posarena-blue-ocean.*
