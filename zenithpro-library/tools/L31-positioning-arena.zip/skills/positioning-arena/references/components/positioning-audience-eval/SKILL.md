---
name: positioning-audience-eval
version: 1.0.0
author: Rich Schefren
arena: positioning
interface: "/positioning-audience-eval {positions} {avatar}"
dependencies:
  - sim-audience
  - sim-audience-blind
---

# positioning-audience-eval

## Purpose

Wire the Simulated Audience Engine to candidate positioning statements so the **excavated avatar** reacts to each one as a real prospect — not as a market prediction, but as a felt experience.

**This is NOT the positioning judge.**
- `positioning-judge` = market prediction (which position will win commercially, competitive whitespace, category dynamics)
- `positioning-audience-eval` = simulated prospect reaction (what does the EXCAVATED AVATAR actually feel, believe, and say when they encounter each position)

These are complementary, not duplicative. Run audience-eval first to see how positions land in the gut. Run the judge to see where they land in the market.

---

## Trigger

```
/positioning-audience-eval {positions} {avatar}
```

Where:
- `{positions}` — 2–10 candidate positioning statements, passed as a numbered list or file path
- `{avatar}` — The excavated avatar profile (output from `/avatar-excavation`, `/aspiration-excavation`, or a manually written avatar document). This is the single prospect the skill simulates — NOT the full 12-persona panel.

If `{avatar}` is omitted, the skill will prompt for it before proceeding.

---

## When To Use This Skill

Use when you have:
1. A set of candidate positioning statements (from posarena, a strategy session, or a copy sprint)
2. An excavated avatar — a specific, documented prospect profile with real language, real fears, real aspirations, real objections

You want to know: **How does THIS person react to EACH of these positions, one by one?**

---

## What This Is NOT

- Not a full buyer panel (that's `/sim-audience` — 12 archetypes, aggregate probability)
- Not blind sequential reaction (that's `/sim-audience-blind` — section-by-section trust tracking)
- Not a market prediction (that's `positioning-judge`)
- Not a copy critique (that's `bj-critic`, `dd-critic`, etc.)

This is a focused, single-avatar, per-position emotional and cognitive reaction read.

---

## Inputs

```
POSITIONS: [numbered list of 2–10 candidate positioning statements, or file path]
AVATAR: [full excavated avatar profile — language, pains, aspirations, objections, worldview]
OUTPUT PATH: [optional — where to save results; defaults to current working directory]
```

**Avatar must include at minimum:**
- Core identity statement (who they see themselves as)
- Primary pain / frustration
- Primary aspiration / dream outcome
- Current worldview / belief system about the problem space
- Natural language samples (actual phrases they use, if available)
- Top objections / resistance patterns
- What they've already tried and why it failed

If the avatar profile is thin (missing 3+ of the above), flag this before running. Thin avatars produce thin reactions. Ask user to supplement or use `/avatar-excavation` first.

---

## Execution Flow

### Step 1: Parse and Validate Inputs

1. Read the full avatar profile. Internalize the voice, the worldview, the emotional register.
2. Read all candidate positioning statements. Number them if not already numbered.
3. If fewer than 2 positions: prompt for more.
4. If no avatar: halt and request avatar document.
5. If avatar is thin (missing 3+ required fields): flag and ask to supplement.

### Step 2: For Each Position — Simulate Avatar Reaction

Process positions sequentially. For each position, generate the avatar's reaction across four capture dimensions:

**Dimension 1 — Gut Belief Reaction**
What is the avatar's immediate, unfiltered internal response? Not what they think they should say — what actually fires in their mind in the first 3 seconds. Write this in the avatar's voice, first-person. Example: "Okay but I've heard this before — every coach says they have the 'system' and none of them actually change anything."

**Dimension 2 — Desire-Pull Score (1–10)**
How much does this position pull the avatar toward wanting to know more?
- 1–3: Repels or bores. They've heard it, don't believe it, or it triggers cynicism.
- 4–6: Neutral or mildly curious. Doesn't move the needle much.
- 7–9: Genuine pull. Something in this landed and they want to know more.
- 10: Rare. Would stop what they're doing to engage immediately.

Score must be a whole number. Always justify the score in 1–2 sentences using the avatar's specific profile (not generic reasoning).

**Dimension 3 — Primary Objection Triggered**
What is the first resistance thought the position generates? One sentence, in the avatar's voice. This is different from the gut reaction — the gut reaction is the emotional first hit; the objection is the rational pushback that follows. Example: "But how is this different from [thing I already tried]?"

**Dimension 4 — Peer Transmission Test**
Would the avatar repeat this to a peer — a friend, colleague, or online community member — in a way that conveys genuine interest or excitement? Answer YES / NO / MAYBE.
- If YES: Write the exact phrase they would use. This is the brag-line / quotable carry-forward.
- If NO: Write what WOULD need to be true for them to repeat it.
- If MAYBE: Write the condition that tips it to YES.

### Step 3: Compile Audience Evaluation Table

After processing all positions, produce the **Audience Evaluation Table**.

**Primary Table (per position):**

| # | Position (truncated to 60 chars) | Gut Reaction (summary) | Pull | Primary Objection | Peer Pass? |
|---|---|---|---|---|---|
| 1 | [position text] | [2–4 word gut label] | [1–10] | [objection, 10 words max] | YES / NO / MAYBE |
| 2 | ... | ... | ... | ... | ... |

Legend:
- Pull = Desire-Pull Score (1=repels, 10=stops everything)
- Peer Pass = Would avatar repeat this to a peer with genuine interest?

**Full Reactions (per position below the table):**

For each position, output the full four-dimension reaction in this block format:

```
---
POSITION [N]: [full text]

GUT REACTION (avatar voice):
[full first-person internal monologue]

DESIRE-PULL: [score]/10
[1–2 sentence justification grounded in avatar profile]

PRIMARY OBJECTION:
[one sentence, avatar voice]

PEER TRANSMISSION TEST: [YES / NO / MAYBE]
[exact phrase OR what would need to be true OR tipping condition]
---
```

### Step 4: Synthesis

After all positions, write a brief synthesis (5–8 bullet points) covering:

1. **Highest-pull position** — which position scored highest and WHY it landed for this specific avatar
2. **Lowest-pull position** — what killed it for this avatar
3. **Objection cluster** — if 2+ positions trigger the same objection family, name the cluster (e.g., "same-old-promise skepticism", "proof deficit", "relevance gap")
4. **Best peer-transmittable position** — which one has the strongest carry-forward phrase
5. **Tension map** — if the avatar simultaneously pulled toward one position while objecting to another with the same underlying mechanism, flag this (it's a creative opening)
6. **Missing territory** — what would a PULL-10 position for this avatar need to contain that NONE of the candidates currently has?

### Step 5: Write Output

Write to `[OUTPUT_PATH]/audience-eval-[date].md`

If no output path specified, write to current working directory and confirm path in response.

Also return a compact JSON to the session:

```json
{
  "run_date": "YYYY-MM-DD",
  "avatar_id": "[name or label from avatar profile]",
  "positions_tested": [N],
  "results": [
    {
      "position_index": 1,
      "position_text": "...",
      "desire_pull": 0,
      "peer_transmission": "YES|NO|MAYBE",
      "peer_phrase": "...",
      "primary_objection": "..."
    }
  ],
  "top_pull_position": 1,
  "lowest_pull_position": 2,
  "objection_clusters": [],
  "missing_territory": "..."
}
```

---

## Output Format: audience-eval-[date].md

```markdown
# Audience Evaluation: [Avatar Name/Label] — [Date]

**Avatar:** [name or label]
**Positions tested:** [N]
**Skill:** positioning-audience-eval v1.0.0

---

## Audience Evaluation Table

| # | Position | Gut | Pull | Objection | Peer |
|---|---|---|---|---|---|
[rows]

**Legend:** Pull = Desire-Pull 1–10 (1=repels, 10=stops everything). Peer = Would avatar pass this to a peer with genuine interest?

---

## Full Reactions

[Per-position blocks as specified in Step 3]

---

## Synthesis

[5–8 bullet synthesis as specified in Step 4]
```

---

## Distinction: This Skill vs. sim-audience

| Dimension | sim-audience | positioning-audience-eval |
|---|---|---|
| Persona model | 12 documented archetypes from audience database | Single excavated avatar (your specific prospect) |
| Content type | Copy, emails, ads, webinar scripts, offers | Positioning statements only |
| Output | Buyer heat map, conversion probability, drop-off tracking | Gut reaction, desire-pull, objections, peer transmission |
| Mode | Full panel reaction to finished content | Single avatar reaction to position candidates |
| When to use | After positioning is set, testing the copy | Before copy, while choosing the position |

---

## Distinction: This Skill vs. positioning-judge

| Dimension | positioning-judge | positioning-audience-eval |
|---|---|---|
| Unit of analysis | Market (category dynamics, whitespace, competitive vectors) | Single avatar (emotional and cognitive response) |
| Output | Predicted commercial winner, strategic rationale | Felt experience, objections, peer transmissibility |
| Lens | Market prediction | Prospect simulation |
| When to use | Strategic positioning decision (where to play) | Creative validation (does this land as felt experience) |

Run both for high-stakes positioning decisions. They answer different questions.

---

## Integration With Positioning Arena

When used inside a positioning sprint:

1. Run posarena experts to generate candidate positions
2. Run `/positioning-audience-eval` with excavated avatar to get prospect reactions
3. Run `positioning-judge` to get market prediction
4. Cross-reference: positions that score high on both audience-eval AND judge are the strongest candidates
5. Positions that score high on judge but low on audience-eval need creative translation work
6. Positions that score high on audience-eval but low on judge may be niche plays worth considering

---

## Dependency Notes

This skill wires the **avatar reaction layer** from the Simulated Audience Engine without spawning the full 12-persona panel.

**sim-audience** (`~/.claude/skills/sim-audience/SKILL.md`):
- Required for persona library structure understanding
- The avatar profile used here mirrors the detailed persona format used there
- If you need full-panel heat map validation after audience-eval, run `/sim-audience` as a follow-up

**sim-audience-blind** (`~/.claude/skills/sim-audience-blind/SKILL.md`):
- Not invoked directly by this skill
- Recommended follow-up if a top-pull position needs sequential trust tracking through actual copy sections
- After this skill identifies which position has the highest pull, use `/sim-audience-blind` with copy built around that position

Both dependencies must be installed for the full positioning evaluation workflow to function. This skill itself does not invoke them programmatically — it inherits the avatar simulation methodology and uses the same persona profile structure.

---

## Example Invocation

```
/positioning-audience-eval

POSITIONS:
1. "The only AI business system designed for operators who've already tried the tools and are still stuck"
2. "How strategic business owners are using AI to eliminate the bottlenecks their teams can't see"
3. "The OS upgrade for your business — not more apps, a different way of running everything"
4. "What the top 1% of business operators have that you don't: a live system, not a strategy"

AVATAR:
[full excavated avatar document or file path]

OUTPUT PATH: ~/Obsidian/Active-Brain/00 Projects/Positioning Sprint/
```

---

## Output Returns Confirmation JSON

After writing the file, return this JSON to confirm completion:

```json
{
  "status": "complete",
  "skill": "positioning-audience-eval",
  "version": "1.0.0",
  "output_file": "[full path to audience-eval-[date].md]",
  "positions_tested": [N],
  "avatar": "[label]",
  "top_pull_position": [index],
  "top_pull_score": [score]
}
```
