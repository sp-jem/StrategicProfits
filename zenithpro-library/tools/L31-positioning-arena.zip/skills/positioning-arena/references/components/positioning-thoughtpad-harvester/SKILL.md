# positioning-thoughtpad-harvester

---

## Frontmatter

```yaml
name: positioning-thoughtpad-harvester
version: 1.0.0
author: Rich Schefren
arena: positioning
```

---

## Purpose

After a positioning arena run, read every competitor's `thought_pad` field from the run output and mine it for strategic raw material that would otherwise be discarded. The `thought_pad` is where each expert's real reasoning lives — unfiltered angles, rejected framings, half-formed category names, and compressed one-liners the judge never saw.

This skill surfaces five categories of intelligence from those pads and writes a "Thought-Pad Harvest" markdown to the run folder.

---

## When to invoke

- After any `/posarena` run (or any positioning arena variant: posarena-brunson, posarena-godin, posarena-trout, posarena-dunford, etc.)
- When you want to recycle losing angles from an arena run into future positioning work
- When you want cross-school pattern analysis — what did multiple experts independently gravitate toward?
- Before writing a positioning brief: feed the harvest as input so nothing from the run is wasted

---

## Inputs

### Required
| Input | Description |
|-------|-------------|
| `run_folder` | Absolute path to the arena run folder (e.g., `~/Obsidian/Active-Brain/00 Projects/Positioning Arena/runs/2026-05-31-001/`) |

### Optional
| Input | Description |
|-------|-------------|
| `output_filename` | Custom filename for harvest file (default: `thought-pad-harvest.md`) |
| `filter_school` | Limit cross-pattern analysis to specific schools (e.g., `godin,trout`) |

---

## Execution

### Step 1 — Locate run files

Search `run_folder` for all `.md` and `.json` files that contain competitor output. Look for:
- Files named after positioning schools (e.g., `godin.md`, `trout-output.md`, `brunson-positioning.md`)
- Any file containing `thought_pad:` or `"thought_pad":`
- Arena result files (often named `results.md`, `round-*.md`, `competitors.json`)

```bash
find "<run_folder>" -type f \( -name "*.md" -o -name "*.json" \) | sort
```

### Step 2 — Extract all thought_pad content

For each file found, extract the `thought_pad` field. Handle both formats:

**Markdown format:**
```
## thought_pad
[content]

## next_section
```

**JSON format:**
```json
{"thought_pad": "content here", ...}
```

**YAML front-matter format:**
```yaml
thought_pad: |
  content here
```

Map each extracted pad to its source school/expert name. If the source name is not in the filename, infer from the nearest heading or JSON key.

### Step 3 — Mine for five categories

For each thought_pad, classify content into these buckets:

**Category 1: Swipe-Worthy One-Liners**
- Compressed, high-density phrases (under ~12 words) that could function as a headline, hook, or positioning statement
- Prioritize phrases with contrast, specificity, or unexpected framing
- Flag if multiple schools independently produced similar phrasing

**Category 2: Raw Articulations Worth Keeping**
- Longer passages (2-4 sentences) that capture a positioning angle clearly but weren't selected by the judge
- These are "almost won" material — they lost on fit, not quality
- Keep the exact wording; do not paraphrase

**Category 3: Category Names Considered**
- Any attempt to NAME a category: "we call this X," "this is the era of Y," "the [adjective] [noun] category"
- Even rejected or incomplete category names belong here
- Note which school proposed each name

**Category 4: Strong Angles the Judge Rejected**
- Positions that were internally coherent but lost on strategic fit, timing, or audience mismatch
- Reconstruct WHY the judge likely passed (if inferrable from context)
- These are candidates for a different product, audience segment, or future campaign

**Category 5: Cross-School Patterns**
- Themes, tensions, or framings that appeared independently in 2+ schools' thought pads
- Cross-school convergence = strong signal about the category's real fault lines
- Cross-school divergence on the same question = unresolved strategic tension worth surfacing

### Step 4 — Write the harvest file

Save to `<run_folder>/thought-pad-harvest.md` (or the custom filename if specified).

---

## Output Format

```markdown
# Thought-Pad Harvest
**Run:** [run_folder name]
**Date:** [today's date]
**Schools harvested:** [comma-separated list of schools found]
**Pads processed:** [count]

---

## 1. Swipe-Worthy One-Liners

| # | One-Liner | Source School | Notes |
|---|-----------|--------------|-------|
| 1 | "[phrase]" | [school] | [why it's strong / caveat] |
| 2 | ... | ... | ... |

---

## 2. Raw Articulations Worth Keeping

### [School Name]
> [exact quoted passage]

*Why kept:* [1 sentence on what makes this worth preserving]

---

## 3. Category Names Considered

| Proposed Name | Source School | Verdict | Notes |
|--------------|--------------|---------|-------|
| "[name]" | [school] | Rejected / Runner-up / Partial | [context] |

---

## 4. Strong Angles the Judge Rejected

### [Angle title — inferred or extracted]
**Source:** [school]
**The angle:**
> [exact or reconstructed framing]

**Probable rejection reason:** [inferred from context — audience mismatch / timing / fit with offer / etc.]

**Recycle candidate for:** [different product / audience / medium / season]

---

## 5. Cross-School Patterns

### Pattern: [short label]
**Schools that touched this:** [list]
**The convergence / tension:**
[2-4 sentence synthesis of what multiple schools independently arrived at or diverged on]

**Strategic implication:**
[1-2 sentences on what to do with this insight]

---

## Harvest Summary

- **Strongest one-liner:** "[phrase]" — [school]
- **Most recycl-able rejected angle:** [title] — [school]
- **Highest-signal cross-school pattern:** [label]
- **Unexpected finding:** [anything surprising that doesn't fit the five categories]
```

---

## Error Handling

| Condition | Behavior |
|-----------|----------|
| No thought_pad fields found | Report which files were scanned, suggest manual field name to search for |
| Run folder does not exist | Exit with clear path error; suggest running `/posarena` first |
| Only one school's pad found | Produce harvest but skip Cross-School Patterns section; note this |
| Thought_pad is empty string | Skip silently; note in harvest header how many pads were empty |
| File is binary or unreadable | Skip; log filename in header |

---

## Example invocation

```
/positioning-thoughtpad-harvester

run_folder: ~/Obsidian/Active-Brain/00 Projects/Positioning Arena/runs/2026-05-31-zenithpro/
```

---

## Integration notes

- **Feeds into:** future `/posarena` runs (paste Category 1-2 into context), positioning briefs, sales letter angle selection
- **Pairs with:** `posarena-blue-ocean`, `posarena-dunford`, `arena-market-intel`
- **Output location follows CLAUDE.md rule:** harvest file is written to the run folder inside the vault, never to `~/.claude/`
- **If thought_pad fields are absent from the run output:** the arena skill that generated the run may not be writing thought pads; check that arena's SKILL.md for the `thought_pad` output field and add it if missing
