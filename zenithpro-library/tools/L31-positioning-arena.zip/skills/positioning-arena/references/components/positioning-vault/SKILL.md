---
name: positioning-vault
version: 1.0.0
author: Rich Schefren
arena: positioning
description: "Escalation phase of the positioning pipeline. Runs the altitude ladder (feature→benefit→identity→worldview→movement), invokes the positioning-10x-critic adversary, decides compete-vs-create, and always records the bigger position it rejected with the reason."
interface:
  invoke: "/positioning-vault {synthesized-position}"
  called_by: [positioning-arena]
  output: positioning-vault-result.json
---

# Positioning Vault — Escalation Phase

## PURPOSE

The Vault is the final escalation step after arena competition has produced a synthesized position. Its job is not to pick a winner from the arena — that already happened. Its job is to ask: **how high can this go, and should it?**

Most positioning dies at Feature or Benefit altitude. Durable market leadership lives at Identity, Worldview, or Movement altitude. The Vault runs a disciplined ladder, stress-tests the highest viable rung with an adversarial critic, and makes a principled decision. Critically: **it records every position it rejected and why** — because the rejected higher position is a future asset, a campaign seed, or evidence for a future pivot.

---

## THE ALTITUDE LADDER

Five rungs. Each rung amplifies the previous. The Vault climbs until truth + defensibility break.

### Rung 1 — FEATURE
The factual description of what exists.
- Answers: "What is this thing literally?"
- Language: specifications, mechanics, capabilities
- Test: Is this what a product manager would write in a spec sheet?
- Example: "A 12-week program with weekly live calls and a private community."

### Rung 2 — BENEFIT
The instrumental outcome the feature produces.
- Answers: "What does having this thing get you?"
- Language: results, saves, earns, prevents
- Test: Is this a before/after gap the prospect consciously wants?
- Example: "You'll have a working AI system in your business in 90 days."

### Rung 3 — IDENTITY
The self-concept the benefit enables or confirms.
- Answers: "What kind of person are you when you have this?"
- Language: "I am / I become / People like me..."
- Test: Would a member carry this as a badge? Would they say it unprompted to a peer?
- Example: "You're an AI-native operator, not someone who got left behind."

### Rung 4 — WORLDVIEW
The belief system the identity implies or requires.
- Answers: "What must be true about the world for this position to matter?"
- Language: paradigm, era, before/after history, what's broken in the old model
- Test: Does this position imply a thesis a thinking person could debate?
- Example: "The industrial-era business model is structurally over. AI doesn't automate your business — it replaces the model itself."

### Rung 5 — MOVEMENT
The collective mission the worldview demands.
- Answers: "What are we building together beyond the transaction?"
- Language: "We are the people who...", shared enemy, shared future
- Test: Could this position anchor a manifesto, a community flag, a decade-long brand?
- Example: "We are the founders building the first generation of AI-native enterprises — not improved humans, but a new category of operator."

---

## LADDER EXECUTION PROTOCOL

For each rung, the Vault must:

1. **Draft the rung** — write the position at this altitude in 1-3 sentences.
2. **Run the truth test** — is this grounded in actual evidence about the offer, the founder, the market? (Mark: GROUNDED / ASPIRATIONAL / UNSUPPORTED)
3. **Run the defensibility test** — if a skeptic challenged this position in public, does the evidence hold? (Mark: DEFENSIBLE / SHAKY / INDEFENSIBLE)
4. **Run the believability test** — will the target avatar accept this without requiring a 20-minute argument? (Mark: IMMEDIATE / EARNABLE / IMPLAUSIBLE)
5. **Decide: CONTINUE or STOP** — Continue if GROUNDED + DEFENSIBLE + BELIEVABLE. Stop if any test fails.

**Stopping rule:** The Vault stops climbing when truth + defensibility break. The highest rung that passes all three tests is the CANDIDATE ALTITUDE.

**Rejection rule:** Every rung that failed must be recorded — not discarded — in the REJECTED POSITIONS VAULT (see Output section).

---

## THE POSITIONING-10X-CRITIC

After the altitude ladder identifies the CANDIDATE ALTITUDE, the Vault invokes an internal adversarial critic before committing.

### Critic Role
The 10x-critic operates as a hostile, well-informed skeptic. Its job is not to destroy the position but to surface weaknesses the advocate overlooked. The critic assumes:
- The market has heard claims like this before
- Competitors will copy it if it works
- The avatar is more skeptical and slower-to-trust than the advocate assumes
- Every superlative has been used by someone weaker

### Critic Attack Protocol
The critic runs five attacks on the CANDIDATE ALTITUDE position:

**Attack 1 — The "so what" attack**
Who cares? Why would someone who has heard 50 similar claims stop and believe this one? What makes it non-generic?

**Attack 2 — The "prove it" attack**
Where is the evidence? What would a skeptic demand to see? Is the proof basis accessible, specific, and difficult to fake?

**Attack 3 — The "who else" attack**
Who else is saying essentially the same thing? If three well-funded competitors can make the same claim tomorrow, this position has no moat.

**Attack 4 — The "wrong person" attack**
Is this position actually believable from this specific founder/company given their track record, size, and current market position? Or is it a position that belongs to someone else?

**Attack 5 — The "altitude collapse" attack**
Is the candidate rung being claimed only because it sounds impressive? Test by asking: if the founder had to defend this position at a dinner table to a skeptical peer, would it hold for 10 minutes?

### Critic Resolution
For each attack, the advocate produces a counter:
- **DEFENDED** — direct evidence or structural argument neutralizes the attack
- **PARTIALLY DEFENDED** — attack reveals a real weakness; position needs modification
- **NOT DEFENDED** — attack stands; position must retreat to the rung below

If any attack results in NOT DEFENDED, the position descends one rung and critic attacks run again on the new candidate.

---

## COMPETE-VS-CREATE DECISION

After the altitude is confirmed and the critic is satisfied, the Vault makes the compete-vs-create call.

### Decision Logic

**COMPETE** when:
- The category already exists with established vocabulary
- The avatar already has search behavior for this category
- The position wins by being the best/most/only in an existing frame
- Winning competitive share is faster than building a new category
- The evidence base maps cleanly to existing category metrics (case studies, before/afters, ROI)

**CREATE** when:
- The existing category frames the offer in a way that undersells it
- The avatar's real problem is unnamed — they're solving the symptom, not the disease
- The competition is strong enough that competing on existing terms is a losing war
- The position at Identity/Worldview/Movement altitude requires a new vocabulary
- The founder has structural advantages that only matter if the category is framed a specific way

**Truth + Defensibility Override:** If the CREATE position requires claims the offer cannot currently support, COMPETE wins by default — even if CREATE would theoretically be better. A CREATE position that collapses under scrutiny is worse than a COMPETE position that holds.

**The final call is one word:** `COMPETE` or `CREATE` — followed by the deciding reason in one sentence.

---

## OUTPUT FORMAT

The Vault writes output to disk and returns a confirmation JSON to the calling context.

### Disk Output (Markdown)
Write to: `~/Obsidian/Active-Brain/00 Projects/Positioning Arena/{session-slug}-vault.md`

File structure:

```markdown
# Positioning Vault — {offer-name} — {YYYY-MM-DD}

## INPUT: Synthesized Position
{synthesized-position passed in}

## ALTITUDE LADDER RESULTS

### Rung 1 — Feature
[Position text]
Truth: GROUNDED | ASPIRATIONAL | UNSUPPORTED
Defensibility: DEFENSIBLE | SHAKY | INDEFENSIBLE
Believability: IMMEDIATE | EARNABLE | IMPLAUSIBLE
Decision: CONTINUE / STOP

### Rung 2 — Benefit
[same structure]

### Rung 3 — Identity
[same structure]

### Rung 4 — Worldview
[same structure]

### Rung 5 — Movement
[same structure]

## CANDIDATE ALTITUDE
**Rung reached:** [Rung name]
**Position at this altitude:**
[Full position statement]

## 10X-CRITIC ATTACKS

### Attack 1 — "So What"
Attack: [text]
Counter: [text]
Verdict: DEFENDED | PARTIALLY DEFENDED | NOT DEFENDED

### Attack 2 — "Prove It"
[same structure]

### Attack 3 — "Who Else"
[same structure]

### Attack 4 — "Wrong Person"
[same structure]

### Attack 5 — "Altitude Collapse"
[same structure]

**Post-critic altitude:** [Rung name — may differ from candidate if attack failed]

## COMPETE-VS-CREATE DECISION
**Decision:** COMPETE | CREATE
**Deciding reason:** [one sentence]

## FINAL ELEVATED POSITION
[Full position statement at confirmed altitude]

**Altitude reached:** [Rung name]
**One-liner:** [Single sentence a member could carry to a peer]
**Category frame:** [The category name, owned or created]
**Enemy:** [What this position is NOT / what it displaces]
**Brag-test phrase:** [The exact sentence a member would say at a dinner table that makes someone else say "wait, you get THAT?"]

## REJECTED POSITIONS VAULT
*These positions were climbed to and failed. They are NOT discarded — they are future campaign seeds, launch angle candidates, and pivot signals.*

| Rung | Position Text | Reason Rejected | Future Use Signal |
|------|---------------|-----------------|-------------------|
| [Rung] | [Text] | [Specific reason: truth/defensibility/believability] | [When this might become viable] |

*Note: Every rung above the confirmed altitude must appear here, including the bigger positions. A rejection is not a failure — it is a documented future asset.*
```

### Confirmation JSON (returned to calling context)

```json
{
  "skill": "positioning-vault",
  "status": "complete",
  "session_slug": "{session-slug}",
  "output_file": "~/Obsidian/Active-Brain/00 Projects/Positioning Arena/{session-slug}-vault.md",
  "altitude_reached": "{rung-name}",
  "compete_or_create": "compete|create",
  "deciding_reason": "...",
  "final_position": "...",
  "final_one_liner": "...",
  "brag_test_phrase": "...",
  "rejected_positions_count": 0,
  "rejected_positions": [
    {
      "rung": "...",
      "position_text": "...",
      "reason_rejected": "...",
      "future_use_signal": "..."
    }
  ],
  "critic_attacks_survived": 5,
  "critic_attacks_failed": 0
}
```

---

## ABSOLUTE RULES

1. **Never skip a rung.** The ladder runs bottom to top. You cannot jump to Identity without grounding in Feature and Benefit first — the tests at each rung depend on the rung below.

2. **Never discard a rejected position.** Every failed rung goes into the Rejected Positions Vault with a reason AND a future use signal. Discarding is a protocol violation.

3. **The critic runs on every candidate altitude, not just the final.** If the position descends due to a failed attack, the critic reruns at the new rung.

4. **Truth beats ambition.** If the best-supported altitude is Feature, the output is Feature. An over-claimed Identity position that collapses under scrutiny is worse than a defensible Benefit position.

5. **The bigger position must always be recorded.** Even if the Vault stops at Benefit, it must record what the Identity, Worldview, and Movement positions would have been — and why they were rejected. The system decides based on truth and defensibility, but it never pretends the higher positions don't exist.

6. **COMPETE-vs-CREATE is a system decision, not a preference.** The Vault applies the decision logic mechanically. If the logic says COMPETE, the output says COMPETE — even if CREATE sounds more exciting.

7. **Write to disk before returning JSON.** The markdown file is the durable record. The JSON is the machine-readable handoff. Both must exist.

---

## INTEGRATION NOTES

- **Input:** A synthesized position from the positioning-arena skill (or any upstream positioning process). Can be passed as plain text or as the `synthesized_position` field from arena output JSON.
- **Output:** Written to `~/Obsidian/Active-Brain/00 Projects/Positioning Arena/{session-slug}-vault.md` + confirmation JSON in conversation.
- **Session slug:** Derived from `{offer-name}-{YYYY-MM-DD}` format. If no offer name is provided, use a descriptor from the synthesized position.
- **Downstream:** The `final_position` and `compete_or_create` fields feed into copy briefs, webinar frameworks, and offer naming.
- **Rejected positions:** The `rejected_positions` array is a first-class output. Downstream copy and campaign agents should be given access to it, not just the final position.
