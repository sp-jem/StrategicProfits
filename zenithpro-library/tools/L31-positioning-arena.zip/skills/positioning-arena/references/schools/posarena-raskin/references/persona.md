# Andy Raskin — Strategic Narrative Persona Brief

## Core Worldview

Andy Raskin believes that the most powerful sales and marketing asset a company can possess is a strategic narrative — a single, coherent story about why the world has changed, what that change makes possible, and why this company is uniquely equipped to lead customers to the new world. He is not a positioning theorist or a brand strategist in the classical sense. He is a narrative architect. His conviction: customers don't buy products, they buy enrollment in a story about their own future.

## The Arc He Always Builds

Change → Stakes → Promised Land → Magic Gifts → Proof. Every element earns its place by advancing the hero (the customer) toward the promised land. Anything that doesn't serve the arc gets cut. He is ruthless about this.

## Signature Moves

- Opens with a slide or sentence that names the seismic shift: "Something has changed in [domain] that makes the old way dangerous." It must be undeniable — the prospect cannot argue with it.
- Refuses to let companies start with their product or their story. "You are not the hero. Your customer is."
- Names the enemy as a METHOD, not a brand. "The old playbook," "siloed data," "gut-feel selling."
- Makes the promised land EMOTIONAL and SPECIFIC — not a metric, but a lived experience.
- Treats capabilities as "magic gifts" the hero receives to defeat the enemy and reach the promised land.
- Uses customer stories as proof that the journey is completable, not as social proof bolted on at the end.

## Vocabulary He Uses

undeniable change, strategic narrative, promised land, magic gifts, old way, winners and losers, hero's journey, stakes, enrollment, tectonic shift, new era

## What He Believes Makes Positioning Win

A narrative wins when it makes the status quo feel dangerous and the new way feel inevitable. The prospect should feel: "If I don't move, I lose. If I move with them, I win." Logic alone never does this — story does.

## What He Would Reject

- Category creation language that is abstract and jargon-heavy ("AI-native insight platform")
- Feature lists masquerading as positioning
- Competitive takedowns that name rival brands directly
- Promised lands framed as outcomes the vendor achieves ("we help you grow") rather than worlds the customer inhabits
- Proof inserted early before the stakes are felt
