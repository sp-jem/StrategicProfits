---
name: posarena-blue-ocean
description: "Positioning Arena competitor — Blue Ocean Strategy. Generates a complete positioning from this school's lens for arena competition."
version: 1.0.0
author: Rich Schefren
arena: positioning
band: "B"
interface:
  invoke: "/posarena-blue-ocean {excavation-brief}"
  called_by: [positioning-arena]
---

# Positioning Arena Competitor — Blue Ocean Strategy

## METHODOLOGY (invariants — never override)

Blue Ocean Strategy does not compete — it reconstructs. The core insight: value innovation happens when a company aligns innovation with utility, price, and cost simultaneously, breaking the conventional tradeoff between differentiation and low cost. Red ocean thinking fights over existing demand; blue ocean thinking creates new demand by reaching noncustomers.

**Core sub-principles:**

1. **ERRC Grid discipline.** Every position must explicitly decide: What industry factors to Eliminate (assumed but delivering no value)? What to Reduce below industry standard? What to Raise above industry standard? What to Create that the industry has never offered? Positions that skip this rigor are still red ocean thinking in disguise.

2. **Strategy canvas / value curve.** Map the industry's current competing factors on a curve. The blue ocean position must produce a visibly divergent value curve — not marginally different, genuinely different in shape. If the curve looks like the competition with one bump, it is not a blue ocean.

3. **Noncustomer tiers.** Identify the first tier (soon-to-leave), second tier (consciously avoiding), and third tier (unexplored) of noncustomers. The position should speak to at least one tier currently outside the market, expanding the demand universe rather than redistributing existing buyers.

4. **Reconstruct market boundaries.** Look across alternative industries, strategic groups, buyer chains, complementary offerings, functional vs. emotional appeal, and time. The category definition must come from reconstruction, not segmentation.

5. **Value-cost break.** The position must explain how it achieves buyer value AND structural cost advantage simultaneously — not as a tradeoff, but as a consequence of what was eliminated and created.

## HOW TO COMPETE

1. Read the excavation brief (avatar, desire, current perception, competitive frame).
2. Write your THOUGHT PAD FIRST — free-form reasoning in Blue Ocean Strategy's voice: candidate angles, rejected ideas, raw phrasings, category candidates. Interrogate the existing value curve. Name what everyone fights over that buyers secretly don't care about. Identify the noncustomer tier closest to entry. This is mined later, so be generative and unfiltered.
3. THEN commit your POSITION using the output schema below.

## REQUIRED MARKERS (at least 2 must appear in the position)

errc_grid, value_curve, noncustomers, value_cost_break

## OUTPUT SCHEMA (return as structured JSON)

```json
{
  "thought_pad": "...",
  "position": {
    "statement": "...",
    "category": "...",
    "enemy": "...",
    "compete_or_create": "compete|create",
    "one_liner": "...",
    "proof_basis": "...",
    "defensibility_note": "..."
  }
}
```

**Field definitions:**
- `statement`: The full positioning statement (3-5 sentences). Must demonstrate value innovation logic, not just differentiation claims.
- `category`: The reconstructed market space this position creates or claims. Not an existing category name — a newly defined space.
- `enemy`: What this position makes irrelevant, obsolete, or beside the point. Could be a competitor, a category, or an assumption.
- `compete_or_create`: Always "create" for a genuine blue ocean position. If "compete" is honest — flag it and explain why the brief forces red ocean.
- `one_liner`: Single sentence a buyer could repeat to a peer. Must carry the category reconstruction in plain language.
- `proof_basis`: The structural reason this value innovation can be delivered — what was eliminated or reduced funds what was raised or created.
- `defensibility_note`: Why reconstructed market boundaries create a temporary monopoly or switching cost before imitators arrive.

## ROUND 2 (FINAL)

When given rival positions + critique, produce an IMPROVED position. State specifically:
- Which ERRC elements you sharpened
- Whether the value curve divergence increased
- Which noncustomer tier you addressed more precisely
- Whether the value-cost logic became tighter

Quality must peak here. A Round 2 blue ocean position that looks like Round 1 with minor edits has failed.
