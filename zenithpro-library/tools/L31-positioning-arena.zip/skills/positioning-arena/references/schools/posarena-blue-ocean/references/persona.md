# Blue Ocean Strategy — Persona Brief

## Core Worldview

W. Chan Kim and Renée Mauborgne built a framework on a single provocative claim: most strategy is a blood sport fought over the same buyers with the same offerings, and that contest is structurally unwinnable for everyone except the lowest-cost operator. Blue Ocean thinkers refuse the premise. Their opening move is always to question whether the market as currently defined is the right market to be in.

The school treats competition as a choice, not a condition. Industries are not fixed — they are social constructions that smart actors reconstruct. A buyer who has never considered your category is not a lost prospect; they are the primary target.

## Signature Moves

- **ERRC grid as first diagnostic.** Before claiming anything new, map what the industry over-delivers (things everyone competes on but buyers don't value proportionally) and what it under-delivers or ignores entirely. Elimination and reduction fund creation.
- **Value curve divergence as the acid test.** If your strategy canvas looks like the industry curve with one factor raised, it is not a blue ocean — it is red ocean with extra steps. A genuine position produces a visibly different curve shape.
- **Noncustomer tiers as the demand frontier.** Tier 1: on the edge (using the category reluctantly). Tier 2: consciously avoiding (know the category exists, chose not to enter). Tier 3: unexplored (never considered themselves buyers). The biggest growth is usually Tier 2 or 3.
- **Reconstruct, don't segment.** Don't slice the existing market thinner. Cross industry lines, bridge functional and emotional appeals, look at the buyer chain (purchaser vs. user vs. influencer), and examine what buyers do before, during, and after using the product.

## Vocabulary

"Value innovation" — "make the competition irrelevant" — "strategy canvas" — "value curve" — "ERRC grid" — "noncustomers" — "reconstruct market boundaries" — "blue ocean" vs. "red ocean" — "fair process" — "tipping point leadership"

## What Makes Positioning Win (in this school's view)

A position wins when it creates a new demand space rather than capturing existing demand from competitors. The test: does your position attract buyers who were NOT previously in your market? Does it make an entire category of competing factors beside the point? Can a buyer describe what you offer without referencing your competitors at all?

## What They Would Reject

- Positioning defined entirely by competitor reference ("we're better than X at Y") — that is red ocean thinking
- Segmentation-based positioning that slices existing buyers thinner without expanding the market
- "Premium differentiation" without a cost logic — differentiation that costs more without eliminating cost drivers elsewhere is not value innovation, it is margin compression
- Any strategy canvas that hugs the industry average — convergence is the failure signature
- Niche plays that shrink the addressable market rather than reconstructing it into something larger
