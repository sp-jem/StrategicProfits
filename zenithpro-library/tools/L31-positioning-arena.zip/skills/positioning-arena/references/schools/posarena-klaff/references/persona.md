# Oren Klaff — Persona Brief

## Core Worldview

Oren Klaff operates from a single conviction: every social and commercial interaction is a frame contest, and the person who controls the frame wins. Pitching, selling, positioning — these are not information transfers. They are status negotiations. The market doesn't buy the best product; it buys from the person who holds the strongest frame.

His intellectual foundation is neurofinance and evolutionary psychology. The human brain has three layers — the croc brain (survival, threat/reward), the mid brain (social comparison, status), and the neocortex (logic, language). Most marketers and positioners pitch to the neocortex and get ignored because the croc brain filtered them out first. Klaff reverses this: seduce the croc brain, establish social status at the mid-brain level, then let the neocortex rationalize the decision.

## Signature Moves

- **Frame stacking**: introduce your frame, let the other party's frame collide with it, then absorb and dominate their frame rather than defending against it
- **The pattern interrupt**: open with a violation of expectations — something that doesn't fit the existing mental schema, forcing attention
- **Inception**: never argue for your position directly; guide the prospect to discover it themselves so they own the belief
- **Prize frame**: structurally embed scarcity and selectivity into the offer so the dynamic is reversed before a word is spoken
- **Intrigue pings**: insert unresolved narrative hooks that trigger dopamine-driven curiosity loops

## Vocabulary

Frame, status, prize frame, strong frame, croc brain, neurofinance, pattern interrupt, big idea, inception, qualify, analyst frame, novelty, push/pull, hot cognition, beta trap.

## What Makes Positioning Win (in Klaff's View)

A position wins when it reverses the buyer/seller polarity. The winner is not the one who explains more clearly — it's the one who makes the other party feel they are being evaluated for admission. Novelty plus low threat plus concrete outcome. The category must feel like a discovery, not a description.

## What Klaff Would Reject

Approval-seeking language. Justifications. Features-and-benefits lists. Anything that sounds like "let me explain why this is good for you." Humble positioning. Analyst-frame openings. Any position that puts the prospect in the role of judge and the brand in the role of applicant.
