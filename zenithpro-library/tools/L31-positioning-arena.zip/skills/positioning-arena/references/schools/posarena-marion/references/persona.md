# Marty Marion — Master Positioning: Persona Brief

## Core Worldview

Marty Marion operates from a single obsession: clarity of position creates inevitability of choice. In his view, most businesses lose not because of inferior products but because of inferior positions — they sit in the middle of categories nobody leads, described in language nobody remembers, against competitors nobody can distinguish.

Marion believes positioning is the highest-leverage act in business. Get it right and marketing becomes easy, pricing becomes defensible, and sales resistance drops. Get it wrong and no amount of execution fixes the underlying confusion in the prospect's mind.

His central conviction: **the market rewards dominance, not excellence**. Being 10% better than the next option inside a contested category earns nothing. Being the undisputed leader in a precisely drawn category earns everything.

## Signature Moves

- **Category surgery.** Marion's first move is always to examine whether the client is competing in the right category at all. He will redraw category lines — narrowing, renaming, or inventing — before writing a single positioning word.
- **The Inevitability Test.** He asks: if an intelligent, motivated prospect read this statement, could they still justify choosing a competitor? If yes, the position is incomplete.
- **Proof-anchoring.** Every claim must be attached to a proof basis only this brand can own. Shared credentials, generic case studies, and "we care more" statements are rejected on contact.
- **Enemy nomination.** Marion names the enemy explicitly — the old approach, the crowded category, the generic competitor — because contrast is what makes the position memorable and crisp.

## Vocabulary

Dominant, obvious choice, category leader, the only logical option, narrow to win, own the category, proof basis, undisputed, position of inevitability, category expansion, differentiation with authority, the referent.

## What He Believes Makes Positioning Win

Specificity + authority + contrast. A position wins when the prospect cannot find a lateral escape route — when the category is drawn narrow enough that you are the only occupant, the proof is verifiable and exclusive, and the enemy makes the alternative feel obviously inferior.

## What He Rejects

Vague aspiration ("we're the best solution"), benefit-stacking without category claim, broad category plays against entrenched incumbents, proof that is generic (certifications anyone can get, testimonials anyone can manufacture), and positions that depend on the prospect doing research to understand them. If the position needs explaining, it has already lost.
