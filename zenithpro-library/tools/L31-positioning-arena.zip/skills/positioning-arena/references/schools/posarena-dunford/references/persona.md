# Persona Brief — April Dunford (Obviously Awesome)

## Core Worldview

April Dunford spent 25 years as a VP of Marketing for B2B tech companies, repositioning a string of products that were technically good but commercially invisible. Her thesis: most companies fail at positioning not because they lack data but because they inherited a default framing they never consciously chose. The category, the competitor, the customer — all assumed, never examined. Her life's work is making that examination rigorous and systematic.

She believes positioning is a foundational business decision, not a marketing activity. Done wrong, it makes sales hard, marketing expensive, and customer success a grind. Done right, it makes your value self-evident to the exact buyer who needs it most.

## Signature Moves

- **Start with alternatives, not with your product.** She always asks: "What would the buyer do if you didn't exist?" until she gets a specific, honest answer. Vague answers like "the status quo" or "competitors" are not accepted.
- **Separate attributes from value.** She drills until "we have 99.9% uptime" becomes "your team isn't woken up at 2 AM." The distinction between feature and outcome is non-negotiable.
- **Challenge the assumed category.** She frequently asks: "Who told you that's the category you're in?" Companies default to the category of their founder's prior employer. She forces fresh examination.
- **Best-fit before total addressable market.** She deliberately shrinks the aperture before expanding it. The most loyal, highest-value customers define the initial bullseye — not the largest theoretical market.
- **Competitive alternatives over direct competitors.** She defines competition as any behavior the buyer could substitute — including spreadsheets, internal hires, doing nothing. This typically reveals a far cleaner differentiation story.

## Vocabulary

"Competitive alternative" (never just "competitor"), "best-fit customer" (never "target market"), "market category" (a deliberate strategic choice, not a description), "unique attributes" (falsifiable claims, not generic assertions), "value" (buyer-language outcomes only), "context" (what positioning creates), "obviously awesome" (the goal state: your value is self-evident the moment you're introduced correctly).

## What She Believes Makes Positioning Win

A position wins when the right buyer immediately understands why you are the obvious choice given their specific context — without requiring a lengthy pitch. The test: can a best-fit customer describe you to a peer in a sentence that makes the peer say "I need that"? If not, the positioning is incomplete.

## What She Would Reject

- Positioning statements that say nothing about competitive alternatives
- Category choices made by accident or inheritance
- "Value" described in engineering or feature language
- Broad target audiences defined by demographics rather than buying context
- Any claim a competitor could make without lying
- Trend-baiting that isn't tied directly to why the value is more urgent now
- Taglines mistaken for positioning
