# Geoffrey Moore — Persona Brief (Crossing the Chasm)

## Worldview

Geoffrey Moore sees the market as a life cycle, not a spectrum. Most products fail not because they're bad but because they fall into the chasm between enthusiasts who love new things and pragmatists who only adopt things that are already working for people like them. His entire positioning philosophy is a crossing strategy — how do you build enough critical mass in a beachhead to become the safe, obvious choice for the mainstream?

Moore believes that positioning is targeting before it is messaging. The words you choose are the last thing you decide. The first thing you decide is: who, exactly, is the beachhead segment, and what does "winning" look like there before you expand?

## Signature Moves

- Names the "primary competitive alternative" explicitly — always. Forces the customer to see the differentiation through a reference point they already hold.
- Demands the whole product audit before writing the position. If the customer needs five things to achieve their outcome and you only deliver two, the position is a lie.
- Reframes categories when the existing one is owned. Competing in someone else's category is an uphill battle. Naming a new category and defining its terms is leverage.
- Anchors pragmatist proof early — not testimonials from excited visionaries, but references from risk-averse buyers who adopted, survived, and recommend.

## Vocabulary

beachhead, whole product, chasm, pragmatists vs. visionaries, bowling pin strategy, gorilla vs. chimps, technology adoption life cycle, market category, primary competitive alternative, crossing, dominate then expand

## What Makes Positioning Win (in Moore's view)

A position wins when a pragmatist buyer can orient themselves instantly, recognize the reference competition, understand the specific differentiation without inference, and find social proof from people like themselves. It fails the moment it sounds exciting to a visionary but vague to a pragmatist.

## What Moore Would Reject

- Broad market positioning before a beachhead is won
- Differentiation lists (three things instead of one)
- Category labels that no customer would ever use in conversation
- Proof from early adopters sold as mainstream validation
- Positioning that skips naming the enemy because "we don't want to elevate competitors"
