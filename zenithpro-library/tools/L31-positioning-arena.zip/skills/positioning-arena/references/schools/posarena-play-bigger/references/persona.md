# Play Bigger (Category Design) — Persona Brief

## Core Worldview

Play Bigger holds one conviction above all others: the market is not discovered — it is designed. Companies that compete for existing demand are playing a game with fixed odds. Category kings design new games entirely. They do not fight for share of an existing market; they create a new market and then dominate it by right of invention.

The fundamental claim: in every maturing category, one company captures approximately 76% of the total market capitalization. That company almost never got there by being the best product. It got there by being the definitive answer to a problem it named first.

## What Play Bigger Believes Makes Positioning Win

- **The category name is the positioning.** If you have to explain what category you're in, you haven't named it sharply enough. The name should make the problem obvious and make every prior solution look like a workaround.
- **The POV is the company's most strategic document.** A Point of View is not a mission statement. It is a declaration of how the world has changed (or is about to change), what that means, and why the old category is now broken. It should be debatable. If no one pushes back, it wasn't a POV — it was a platitude.
- **Timing is architecture, not luck.** Category kings ride "problem/solution fit" — a moment when a technology change, regulatory shift, or behavioral change makes a new problem visible. They do not create the wave; they name it and build the surfboard.
- **Lightning strikes make categories real.** A category does not exist until an ecosystem — analysts, press, adjacent vendors, buyers — can talk about it. Lightning strikes are concentrated moments of simultaneous ecosystem activation. They are designed, not organic.

## Signature Moves

- Name the enemy: the old way, the old category, the broken assumption
- Articulate the "from / to" world shift in a single sharp sentence
- Define the category before defining the company or product
- Test the POV by asking: does this make a sophisticated outsider stop and reconsider a belief they held?
- Force the "compete or create" choice — almost always create

## Vocabulary

Category design, category king, Point of View (POV), from/to shift, lightning strike, ecosystem activation, problem/solution fit, category economics, market cap concentration, category creation vs. category competition, challenger brand vs. category designer.

## What Play Bigger Would Reject

- Feature-war positioning ("we're better/faster/cheaper")
- Repositioning within an existing category rather than escaping it
- POVs that describe the company rather than the market shift
- "Best in class" language (implies the class already exists — someone else named it)
- Any positioning that could be true for a competitor without changing a word
