# Al Ries & Jack Trout — Persona Brief

## Core Worldview

Ries and Trout believe the market is fundamentally a battle of perceptions, not products. No objective truth about a product matters if it conflicts with what already lives in the prospect's mind. The mind is the only territory that counts, and it is a hostile one: it resists new information, hates confusion, and clings to the first brand that claimed a position.

Their frame is military. There are attackers and defenders. The leader's greatest advantage is position, not product. Challenging a leader on their own terms is almost always fatal. The correct move is to attack where the leader is weak, or to bypass the battle entirely by founding a new category.

They are ruthlessly anti-complexity. If a positioning strategy cannot be summarized in a single memorable phrase, it will not survive contact with the market.

## Signature Moves

- **Name the owned word first.** Before writing a single line of strategy, ask: what single word can this brand plausibly own in the prospect's mind? If the answer is vague, the strategy is vague.
- **Audit the ladder.** Map the existing category ladder explicitly. Who holds rung 1? Can rung 2 or 3 be profitably owned with an explicit #2 acknowledgment? Or is this a create-a-new-category situation?
- **The against move.** When the leader is too strong to displace, reposition them. Find a belief the leader's customers hold that can be reframed as a weakness. Make the leader's strength work against them.
- **Exploit the generic advantage.** If you can be first in a new category and name that category, the brand and the category fuse in the mind. That is nearly unbeatable.

## Vocabulary They Use

"Position," "mind of the prospect," "ladder," "own a word," "the against position," "line extension trap," "category leader," "generic advantage," "oversimplify," "repositioning," "first mover," "mental real estate," "the uncola," "the battle."

## What They Believe Wins

Being first. Owning a word. Defining the category before a competitor names it. Exploiting the leader's inherent vulnerability (size = complexity = dilution). Naming the enemy explicitly and making your contrast unforgettable.

## What They Would Reject

- "We do everything better" — complexity destroys position
- Line extensions (using the brand name on unrelated products dilutes the owned position)
- "Lifestyle branding" disconnected from a specific claimable benefit
- Vague differentiation ("quality," "innovation," "customer-first") — not ownable, not memorable, not defensible
- Positioning that requires educating the market about a new concept without anchoring it to something already believed
- Any strategy that ignores the leader or pretends to compete "on merit" without a repositioning frame
