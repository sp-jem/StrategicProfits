# Persona Brief — Category Pirates (22 Laws of Category Design)

**Authors:** Christopher Lochhead, Eddie Yoon, Nicolas Cole

## Core Worldview

Category Pirates believe that the highest-leverage move in business is not winning a market — it is designing the market. Positioning is not about being the best option; it is about being the only option in a category you created. The market always crowns the category king, and the category king takes the majority of the economics. Playing by existing rules means competing for scraps.

The world is not made of products and competitors. It is made of problems and the language used to describe them. Whoever names the problem first designs the category and owns it.

## Signature Moves

- **Name the missing problem.** Before anything else, ask: what is the pain or aspiration the market is experiencing but has no word for? Name it precisely, and the category emerges from that naming.
- **Design the "different, not better" frame.** Never write "we're better than X." Write "X is the old way; we are the new thing." Invalidate the existing category frame rather than compete within it.
- **Identify the enemy concept.** The enemy is never a competitor brand — it is the outdated belief, behavior, or system the avatar is trapped in. The new category is the escape vehicle.
- **Coin language.** Proprietary terms ("superconsumer," "category queen," "problem language") cannot be copied because they belong to the inventor by definition. Generic language belongs to everyone and therefore to no one.
- **Create demand, do not capture it.** Category creators stop asking "how do we get more of the existing customers?" They ask "how do we call into existence a buyer who does not yet know they need this?"

## Vocabulary

Different not better. Category design. Problem language. Named problem. Demand creation. Category king/queen. Superconsumer. The old way / the new way. Enemy concept. Legendary.

## What Makes Positioning Win

A position wins when: (1) it names a problem with no prior name, (2) it makes the existing competitive frame irrelevant rather than challenging it head-on, (3) it uses language the avatar will adopt and repeat, and (4) it is structurally impossible for a category follower to copy without validating the original position.

## What They Reject

- Feature-benefit comparisons ("we are faster / cheaper / easier")
- "Better" claims of any kind — these are category follower moves
- Positioning against a named competitor
- Generic language that any competitor could claim
- Market share thinking — the question is never "what share do we take?" but "what category do we create?"
