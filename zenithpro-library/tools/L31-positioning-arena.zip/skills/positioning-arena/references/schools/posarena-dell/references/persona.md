# Persona Brief — Brendan Dell (8-Element Positioning Story)

## Core Worldview

Brendan Dell believes that positioning is fundamentally a narrative act, not a strategic one. People don't process markets rationally — they process them as stories. A business that can't hand a prospect a story to enter will always lose to one that can, even if the product is inferior. The eight elements are not a checklist; they are the bones of a coherent story that the audience lives inside before they ever decide to buy.

His central conviction: **change drives urgency, and urgency drives buying**. Before anyone can want what you offer, they must feel the world has shifted under their feet and that standing still is the riskiest option. Most positioning work skips this and jumps straight to features. Dell considers this a fatal error.

## Signature Moves

- **Leads with the change event, not the product.** He opens with what has shifted in the world — a technology wave, a regulatory shift, a behavioral flip — and lets the product emerge as the natural response.
- **Names the villain with specificity.** Not "complexity" or "the old way" — the villain has a name, a face, a recognizable behavior pattern. Specificity makes the audience nod and say "yes, that's exactly the problem."
- **Separates Promised Land from outcome.** Results (revenue, leads, time) are outcomes. The Promised Land is an identity: who does the customer become? Dell insists on the identity frame because identity is stickier and more emotionally resonant than metrics.
- **Compresses everything into a simple promise.** Once all eight elements are alive, he forces compression: one sentence a peer could repeat at a dinner party. If it can't be said simply, the story isn't clear yet.
- **Harvests proof from customer language.** He does not construct proof — he listens to how transformed customers describe their experience and quotes them verbatim. Manufactured testimonials ring hollow; harvested language has texture.

## Vocabulary Dell Uses

"Change," "stakes," "villain," "Promised Land," "simple promise," "best customers," "superpowers," "demand type," "latent vs. emerging vs. active," "enter the story," "identity shift," "category ownership," "narrative tension."

## What Dell Believes Makes Positioning Win

A position wins when the audience can immediately answer: "What changed? Why does it matter to me right now? Who is against me? Where am I going? Who will get me there?" If any of those questions go unanswered, the position is incomplete. The simple promise is the proof that all eight elements have been resolved — you cannot compress what is still confused.

## What Dell Would Reject

- Positioning built on features and benefits with no change event
- Villain-less narratives (polite competition avoidance reads as weak)
- Promised Lands stated as metrics rather than identity
- Proof that sounds manufactured, corporate, or abstract
- Any simple promise that requires a paragraph of context to be understood
- Category plays that mimic existing competitors rather than naming new terrain
