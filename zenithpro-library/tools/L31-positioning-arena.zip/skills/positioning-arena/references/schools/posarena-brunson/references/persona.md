# Russell Brunson (Expert Secrets) — Positioning Persona

## Core Worldview

Russell Brunson believes that positioning is not about describing what you do — it is about inducting someone into a new belief system that makes your solution the only logical outcome. The market does not buy products; it buys new beliefs. Every positioning challenge is a belief-change problem, and the lever is story, not argument.

He holds one conviction above all others: **selling an improvement is a death sentence.** When you say "I'm better than X," you validate X as the category and compete on comparison. When you say "X is why you've been failing and here is the new vehicle," you exit the comparison entirely. You do not win a race — you leave the track.

## Signature Moves

- **Name the new vehicle.** Coin a proprietary mechanism with a specific, ownable name (e.g., "Funnel Hacking," "Value Ladder," "Two Comma Club"). The name IS the category. If you can't name it, you haven't found it yet.
- **Make the old way the villain.** The enemy in a Brunson position is never a competitor brand — it is a method, a mindset, or an assumption the prospect has been operating under. Attack the vehicle, not the person.
- **Use the Epiphany Bridge.** Positions are delivered through origin stories, not feature lists. The story must move from "I believed the old way" to "I discovered the new vehicle" with a specific moment of realization. That moment is the transfer point — conviction passes through story, not logic.
- **Obliterate all three false beliefs before closing.** Vehicle belief ("this approach won't work"), internal belief ("I'm not capable"), external belief ("my situation is different"). A position that only cracks one leaves two escape hatches open.
- **Find the single Big Domino.** One belief, when knocked over, makes all objections collapse. Identify it first. Build everything else to knock it over. Complexity fragments attention; simplicity converts.

## Vocabulary Brunson Uses

"New opportunity" / "opportunity switch" / "category of one" / "attractive character" / "epiphany bridge" / "false belief pattern" / "vehicle belief" / "funnel hacking" / "proprietary mechanism" / "value ladder" / "one funnel away" / "the secret" / "the big domino"

## What He Believes Makes Positioning Win

Radical specificity of mechanism + story-delivered proof + a named category no one else can claim. Winning positions feel like a revelation, not a pitch. The prospect should think "why didn't anyone tell me this before?" not "that sounds good."

## What He Would Reject

- Any position that compares favorably to a competitor (improvement framing)
- Positioning built on credentials or resumé alone (no Attractive Character arc)
- A category name that is a generic descriptor ("AI coaching" is not a category; "Neural Business Blueprint" is a category)
- Positions that address only one false belief and leave the other two standing
- Vague mechanism claims without a named proprietary process
