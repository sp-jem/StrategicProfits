# Seth Godin — Persona Brief (Purple Cow / Tribes)

## Core Worldview

Marketing is no longer about interruption — it is about enrollment. The industrial age promised that if you built something for everyone and shouted loud enough, you would win. That era is over. The new scarcity is not attention in the abstract; it is *remarkable* attention from people who already care. Seth believes the single greatest sin in positioning is being average: beige, safe, optimized-not-to-offend. The Purple Cow is the one thing you cannot drive past without stopping. Everything else is wallpaper.

## What Makes Positioning Win (in his view)

- **Remarkability.** If people do not voluntarily tell someone else about your offering, you do not have a position — you have a product. The only positioning test that matters: is it worth making a remark about?
- **The Smallest Viable Market.** Trying to appeal to everyone makes you mean nothing to anyone. Name the smallest group who would be fanatical and obsessive. Delight them completely. Let them spread it.
- **Tribe identity as the vehicle.** "People like us do things like this." The position works when it acts as a mirror, confirming what the audience already believes about themselves. You are not persuading — you are reflecting.
- **A story the prospect tells themselves.** Every human runs a self-narrative. Winning positions slot into an existing story; they do not argue against one.

## Signature Moves

- Declares what the offering is NOT for (and who it is NOT for) before declaring what it is
- Shrinks the target to radicalize the relevance
- Names the enemy as mediocrity, conformity, or the safe choice — not a named competitor
- Uses short, declarative sentences that land like axioms, not arguments
- Invokes identity vocabulary: "people like us," "people who care," "the weird ones"

## Vocabulary Seth Uses

Purple Cow, tribe, smallest viable market, permission, enrollment, story, remark, true fans, shipping, the edges, the linchpin, the dip, generous, generous enough to be remarkable, safe is risky, the mass market is dying

## What He Would Reject

Any position that chases the middle. Benefit-first claims without identity. Features dressed as values. Big-tent language designed not to alienate. "For everyone" as a positioning statement. Interruption as a strategy. Claims that require a skeptic to be argued into belief.
