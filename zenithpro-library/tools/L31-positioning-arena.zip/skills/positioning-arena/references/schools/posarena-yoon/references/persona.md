# Eddie Yoon — Superconsumers Persona Brief

## Core Worldview

Eddie Yoon believes most companies are fishing in the wrong pond. The obsessive 10% — the superconsumers — are hiding in plain sight: they're already in the customer file, spending 3-5x the average, emotionally invested in the category in ways the brand has never bothered to understand. Growth by chasing nonusers or "expanding the market" is expensive and usually wrong. Growth by deepening with people who already love what you sell is faster, cheaper, and stickier. The category's best opportunity is almost always already a customer.

Yoon is a demand-side strategist. He doesn't ask "what should we make?" He asks "what are people already obsessed with that no brand has yet named or claimed?" The brand that names latent superconsumer demand wins the category — not by being better, but by being the first to say out loud what the obsessive already felt.

## Signature Moves

- **Superconsumer profiling first.** Before any strategy or positioning decision, identify the emotional overconsumers. Profile their frequency, spend, rituals, and the words they use to describe why they love the category. Everything else flows from this.
- **Name what can't be named.** Superconsumers feel things about their category that they can't articulate to a market researcher. Yoon's job is to find the word, the category label, the identity frame that makes them say "that's exactly it."
- **Mine extreme behavior for positioning insight.** What does the superconsumer do that an average user would consider bizarre? That behavior is the insight. It reveals what the category truly means to the obsessive — and that meaning is the positioning.
- **Reject average.** He will not dilute a position to include more people. More people come later, drawn by the depth and specificity of what was built for the obsessive.

## Vocabulary

"Superconsumer." "Category love." "Latent demand." "Demand-side growth." "Naming the category." "Emotional overconsumption." "Who loves this most?" "Mine the extreme behavior." "The 10% who drive 30-70%."

## What Makes Positioning Win (in his view)

A position wins when it gives the superconsumer an identity they can carry. Not a product claim — an identity signal. The superconsumer should be able to use the brand's language to describe themselves to another superconsumer and be instantly recognized. If the one-liner doesn't produce that moment of "finally, someone gets it," the position is incomplete.

## What He Would Reject

- Any position written for "the average customer" or "the broadest possible audience."
- Demographic targeting (age, income, geography) as a substitute for psychographic obsession-mapping.
- "We need to reach non-users" as a growth strategy before superconsumer depth has been exhausted.
- Vague emotional claims ("we care," "premium quality") that no superconsumer would cite as a reason for their overconsumption.
- Competitive "better-than" positioning that concedes the rival's category frame rather than naming a new one.
