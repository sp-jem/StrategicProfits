---
name: positioning-arena
description: "The most powerful positioning system assembled. A competitive arena where 10 positioning schools + 3 category-design schools + 7 deep-thinker lenses compete head-to-head across two rounds, with thought pads, audience evaluation, a marketplace judge, a synthesis convergence, and a Vault that escalates the winner to the highest defensible altitude. Renders a live HTML control-room dashboard + replay. Use when an entrepreneur, professional, business, or thought leader needs to craft (or stress-test) positioning. Trigger: /positioning-arena, position this, find my positioning, category design, repositioning."
version: 1.0.0
author: Rich Schefren
trigger: /positioning-arena
arena: positioning
---

# Positioning Arena v1.0

The competition layer over Rich's existing excavation, deep-thinker lens, output, and dashboard assets. Every great school of positioning competes; the strongest converges; the Vault escalates it.

## YOUR JOB WHEN INVOKED

1. **Gather inputs** (ask only what's missing):
   - `productName` / entity to position
   - `context` — what it is, who it's for, the offer (1 paragraph is enough)
   - optional `brief` — if the user already has excavation output, pass it (skips Phase 1 web work)
   - `runId` — make a slug: `<product-slug>-YYYY-MM-DD` (you must supply the date; the script cannot read the clock)
   - optional `only` — a reduced roster of agent ids for a fast/smoke run

2. **Launch the run workflow** (this IS the orchestrator — do not run phases by hand):
   ```
   Workflow({
     scriptPath: "~/.claude/skills/positioning-arena/run.workflow.js"  // expand ~ to the absolute home path when calling Workflow,
     args: {
       runId: "<slug>-<date>",
       runName: "<Name> Positioning Battle",
       productName: "<Name>",
       context: "<one-paragraph context>",
       brief: "<optional excavation brief text>",
       only: ["trout","dunford","play-bigger","lens-desire","lens-frame"]  // omit for full 20-competitor run
     }
   })
   ```

3. **While it runs**, tell the user how to watch live (the run auto-mirrors the dashboards into the run root, so one server serves both dashboards and run data):
   ```bash
   cd "<the outRoot you passed — e.g. ~/positioning-arena-runs>"
   python3 -m http.server 8080
   # open http://localhost:8080/dashboard/live.html
   # in the setup panel: base URL = http://localhost:8080, run id = <your runId>
   ```

4. **When it completes**, report the winner, the Vault final position, the rejected-bigger position, and the output paths. Offer the replay: `http://localhost:8080/dashboard/replay.html`.

## RUN SEQUENCE (owned by run.workflow.js)

Excavation → Round 1 (all bands generate, thought pad first) → Critique (fidelity critics + truth/defensibility) → Round 2 FINAL (revise vs rivals + critique) → Audience Eval (sim-audience) → Judge (atomic-unit, blind read) → Synthesis (converge moves) → **Vault** (altitude ladder + 10x adversary; records the rejected bigger position) → Output (Positioning Operating System + scorecard + thought-pad harvest + replay snapshot).

## THE BANDS

- **Band A — Positioning Schools (10):** trout, dunford, marion, dell, raskin, brunson, moore, yoon, godin, klaff
- **Band B — Category Design (3):** play-bigger, category-pirates, blue-ocean
- **Band C — Deep-Thinker Lenses (7):** lens-perception (Gordon), lens-desire (Girard), lens-identity (Tajfel), lens-status (Veblen), lens-frame (Lakoff), lens-belief (Kelman), lens-defense (Sherif) — these CALL existing deep-thinker skills.

See `references/roster.json` and `references/lens-map.json` for the full wiring.

## OUTPUTS (per run, in the vault)

`Active-Brain/00 Projects/Positioning Arena/runs/<run-id>/` →
`status.json` (live dashboard feed), `agents/<id>/thoughts.md` (streamed thought pads), `Positioning-Operating-System.md`, `scorecard.md`, `thoughtpad-harvest.md`.
Replay snapshot → `snapshots/<run-id>.json`.

## REUSED ASSETS (do not rebuild)

Excavation: `motivation-spectrum-analyzer`, `zp-excavation`, `zp-avatar`, `zp-desire-mapper`, `zp-pattern-analyzer`.
Articulation: `zp-usp`, `zp-concept-generator`, `toffler-naming-engine`, `core-concept-articulation-optimizer`, `proprietary-term-optimizer`.
Audience: `sim-audience`, `sim-audience-blind`. Pre-flight: `gallin-reset-diagnostic`.

## EVOLUTION

If a synthesis position wins all rounds across runs, spawn it as a new permanent school via `positioning-school-spawner`. External positioning docs can enter as a temporary competitor via `positioning-arena-wildcard`.

## NOTES / LIMITATIONS

- The run workflow writes `status.json` via lightweight writer agents at each phase boundary (the workflow sandbox has no filesystem). Thought pads are appended by each competitor agent as it reasons.
- For a polished stage demo, run once to capture a snapshot, then drive `replay.html` at controlled speed.
- `runId` and any dates must be supplied at invocation — the workflow cannot read the system clock.
