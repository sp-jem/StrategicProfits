# Revenue Opportunity Mapper
## Install Package v1.4.0

**Author:** Ashley Shaw / Strategic Profits
**Created:** 2026-04-01
**Version:** 1.4.0 (adversarial tested + scored 4.2/5.0 CERTIFIED)
**Programs:** Force Multiplier, Connect the Dots

---

## What This Skill Does

Maps a member's existing offer suite against the 6-tier SP/Hormozi value ladder framework.
Identifies missing tiers, broken ascension paths, lifecycle mismatches, and underpriced offers.
Produces the top 3 revenue stream opportunities — ranked by revenue impact × ease of implementation.

**Use when:**
- "What's my biggest untapped revenue opportunity?"
- "What should I build next?"
- "Audit my offer suite"
- "Where are my ascension gaps?"
- "How do I diversify my revenue?"

**NOT for:** Copywriting, funnel building, launch strategy, or market research.

---

## How It Works

The skill runs a 6-phase process:

```
Phase 1: Intake → confirm member data before any analysis
Phase 2: Framework mapping → map every offer to SP/Hormozi tier (1-6)
Phase 3: Gap analysis → identify missing tiers, broken ascension, lifecycle mismatches
Phase 4: Opportunity scoring → Revenue Impact × Ease Score for top candidates
Phase 5: Summary View → Quick View table + opportunity headlines (wait for member selection)
Phase 6: Deep dive → Full detail on selected opportunity only
```

**Key constraint:** Only 3 opportunities max. Prioritization is the entire value.

---

## Installation

### Quick Install
Copy the skill folder into `~/.claude/skills/`:

```bash
cp -r revenue-opportunity-mapper ~/.claude/skills/
```

### Source of Truth Requirement
This skill references:
`00 ASHLEY MISSION CONTROL/SP-Offer-Architecture-Source-of-Truth.md`

If sharing outside SP systems, update the `source_of_truth` field in SKILL.md frontmatter to point to your local copy of the SP/Hormozi offer architecture framework.

---

## Skill Score

| Dimension | Score |
|-----------|-------|
| Structural Quality | 4/5 |
| Output Quality | 5/5 |
| Integration Quality | 4/5 |
| Reliability / Repeatability | 4/5 |
| Error Handling | 4/5 |
| **Overall** | **4.2/5.0 — CERTIFIED** |

Adversarial tested April 1, 2026. All 3 original must-fix items resolved before certification.

---

## Key Design Decisions

1. **Intake confirmation gate:** Skill never begins analysis until member confirms intake data is accurate. Prevents wrong-framework analysis.
2. **Summary View first:** Full opportunity detail is gated behind member selection — prevents overwhelm and forces prioritization.
3. **Revenue formula required:** Every opportunity must have a conservative revenue formula with labeled assumptions.
4. **Constraint diagnosis before recommendations:** Never recommends building a new offer before diagnosing whether the constraint is a missing tier, broken ascension, or lifecycle mismatch.
5. **3-opportunity cap:** Hard limit. More than 3 recommendations defeats the purpose of prioritization.

---

## Triggers

```
"revenue opportunities"
"what should I build next"
"new revenue streams"
"offer suite audit"
"ascension gap"
"what's missing in my offers"
"diversify revenue"
"offer ladder"
```

---

## Files in This Package

| File | Purpose |
|------|---------|
| `SKILL.md` | Full skill specification — install this |
| `TEST-RESULTS.md` | Adversarial test record (11 tests, Apr 1, 2026) |
| `SCORECARD.md` | Skill-grader certification scorecard |
