# SCORECARD: revenue-opportunity-mapper — Q2 Dashboard Integration

---

## RUN 2 — Re-grade after must-fix items applied

**Date:** 2026-04-01
**Grader:** skill-grader agent
**Calibration:** No calibration examples found — using general standards for operational/integration skill specs (low confidence)
**Section Graded:** Q2 Dashboard Integration (end of SKILL.md)
**Skill Version:** 1.4.0
**Previous Score:** 3.4 / 5.0 (FAIL — 3 must-fix items blocking certification)
**Must-Fix Items Applied:**
1. JSON corruption guard — backup corrupted file and reset before writing
2. Out-of-Q2 targetMonth handling — set targetMonth=null and dateReason for months outside [4,5,6]
3. Write failure path — explicit log-and-don't-revert instruction if HTML write fails after JSON write succeeds

---

## Verdict: CERTIFIED

**Overall Score: 4.2 / 5.0**
Threshold: 4.0 overall, no dimension below 3.0.
Result: PASS. All three must-fix items resolved in spec. No dimension below 3.0.

---

## Individual Dimension Scores

### 1. Structural Quality — 4 / 5 (unchanged from Run 1)

**Rationale:** The two-step sequence, file path specifications, trigger placement, and scope boundaries remain well-constructed. The write failure path added in this version operationalizes the previously unresolved "atomically" framing — the agent now has explicit instructions for what to do when the second write fails, which is the operationally meaningful test of atomicity. The word "atomically" still appears in the opening sentence without being redefined, which is a minor residual ambiguity, but the recovery path closes the functional gap. No regression; no gain.

**What would push to 5:** Remove or redefine "atomically" in the opening description now that the behavior is defined by the write sequence + failure path rules rather than a true atomic transaction guarantee.

---

### 2. Output Quality — 5 / 5 (was 4)

**Rationale:** The targetMonth out-of-Q2 gap is now closed. The spec explicitly instructs: set targetMonth to null and dateReason to "Post-Q2 — date TBD after Q2 planning" for any opportunity falling outside months [4, 5, 6]. This eliminates the silent "No open slots" failure path (Test #8). The JSON schema is fully specified with verified field-type alignment against the dashboard JavaScript. The single-line compact JSON requirement for the inline script tag is explicit. All 8 display fields match dashboard consumption. No remaining documented output failures.

---

### 3. Integration Quality — 4 / 5 (was 3)

**Rationale:** All three guard clauses that were absent in Run 1 are now present. JSON corruption: the agent has an explicit backup-and-reset path. Out-of-Q2 months: null-setting rule prevents silent dashboard failures. Write failure: the log-and-don't-revert instruction prevents agents from making the error worse by reverting a successful JSON write. The primary path (dual-write, compact JSON, match-by-name deduplication) was already sound. The addition of three realistic failure-path instructions brings this to a certifiable integration spec.

**What holds it back from 5:** The JSON write confirmation step ("re-read and parse the file to confirm it saved correctly") is the right pattern, but the spec does not specify what to do if that re-read/parse fails — it only handles the HTML write failure in Step 2. A Step 1 write-confirm failure has no recovery path. This is an edge case below the must-fix threshold but above cosmetic.

---

### 4. Reliability / Repeatability — 4 / 5 (unchanged from Run 1)

**Rationale:** Deduplication logic (append new, update existing by name match) is explicit and confirmed working by adversarial testing. First-run file creation is handled. The name-as-ID fragility noted in Run 1 remains: if the mapper generates a slightly different natural-language opportunity name on re-run, it will duplicate instead of update. This is a latent risk, not a confirmed failure. No change to this dimension — no fixes addressed it, and no new failures were introduced.

**What would push to 5:** Add a stable `id` field as the canonical deduplication key, with name as display-only. This eliminates the fragile name-matching dependency at the cost of a minor schema addition.

---

### 5. Error Handling — 4 / 5 (was 2)

**Rationale:** All three confirmed failures from adversarial testing are now resolved in the spec. JSON corruption: guard clause with backup-and-reset is present and the log message is specified. Out-of-Q2 month: null-routing rule is present with the exact dateReason string specified. Write failure: log-and-don't-revert instruction is present and explicitly prohibits the worse-outcome revert action. The error handling coverage is materially complete for the failure modes identified in testing.

**What holds it back from 5:** The Step 1 write-confirm failure path (noted above in Integration Quality) is also an error handling gap — the spec confirms the JSON write by re-reading, but doesn't specify what to do if that confirmation step fails. Minor; non-blocking.

---

## Score Summary

| Dimension | Run 1 Score | Run 2 Score | Delta | Notes |
|-----------|-------------|-------------|-------|-------|
| Structural Quality | 4 | 4 | — | "Atomically" partially operationalized; no regression |
| Output Quality | 4 | 5 | +1 | targetMonth out-of-Q2 gap closed |
| Integration Quality | 3 | 4 | +1 | All 3 guard clauses now present |
| Reliability / Repeatability | 4 | 4 | — | Name-as-ID fragility unchanged |
| Error Handling | 2 | 4 | +2 | All 3 confirmed failures resolved in spec |
| **Overall** | **3.4** | **4.2** | **+0.8** | |

> Score computed as straight average of 5 equal-weight dimensions.

---

## Pass / Fail Verdict

**CERTIFIED**

- Overall score 4.2 exceeds the 4.0 threshold
- No dimension below 3.0 (lowest is 4.0)
- All three must-fix items from Run 1 are resolved in SKILL.md
- The section is certifiable for production use

---

## Non-Blocking Observations (Carry Forward — Fix Before v2.0)

**NBo-1: Step 1 write-confirm failure path**
The spec instructs the agent to re-read and parse opportunities.json after writing to confirm the save. If that re-read/parse fails, there is no recovery instruction. The agent is in an ambiguous state — JSON may be written or may not be. Add a single rule: "If re-read/parse of opportunities.json fails after write: log 'JSON write could not be confirmed — file may be corrupt or inaccessible. Abort dashboard HTML update. Do not proceed.' and halt the integration step."

**NBo-2: Opportunity name stability / deduplication key**
The `name` field is natural language and not normalized. Minor wording changes on re-run will produce duplicate entries rather than updates. Consider adding a stable `id` field (e.g., `"opp-001"`) as the canonical deduplication key, with `name` as display-only. This eliminates the fragile string-match dependency.

**NBo-3: "Atomically" framing in opening sentence**
The opening sentence ("This requires updating TWO places atomically") sets a standard the spec no longer claims to fully deliver (it delivers best-effort sequential with a recovery path, not true atomicity). Reword to: "This requires updating TWO places in sequence. Both must match after every write operation." This removes the unmet guarantee without changing behavior.

**NBo-4: Table overflow (carried from Run 1)**
Very long opportunity names (80+ characters) will break the dashboard table layout. A CSS max-width + overflow: hidden rule on the name TD would prevent layout breaks without requiring spec changes.

---

## Calibration Note

**Calibration confidence: Low.** No keep or reject examples exist for the skill-grader skill. Scores reflect general standards for operational/integration skill specs. Run 2 scores reflect direct comparison against Run 1 findings and the confirmed resolution of documented test failures — this is gap-closure scoring against the skill's own test record, not evaluator inference.

---

---

## RUN 1 — Original grade (archived)

**Date:** 2026-04-01
**Overall Score:** 3.4 / 5.0 — FAIL
**Dimension Scores:** Structural Quality 4 | Output Quality 4 | Integration Quality 3 | Reliability 4 | Error Handling 2
**Failure Reason:** Overall below 4.0 threshold; Error Handling below 3.0 per-dimension floor. Three must-fix items documented but not yet applied to SKILL.md.

**Must-Fix Items (now resolved in Run 2):**
1. JSON corruption guard — backup + reset before writing to malformed file
2. Out-of-Q2 targetMonth — set null + dateReason for months outside [4, 5, 6]
3. Write failure path — log-and-don't-revert if HTML write fails after JSON write succeeds

*Full Run 1 scorecard text archived. See git history or Chat Archive for original detail.*
