# Mechanism Ideator Skill Installer for Windows
# Installs the mechanism ideation skill for Claude Code

$ErrorActionPreference = "Stop"

$SKILL_NAME = "mechanism-ideator-package"
$SKILL_DIR = "$env:USERPROFILE\.claude\skills\$SKILL_NAME"
$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "==================================" -ForegroundColor Cyan
Write-Host "Mechanism Ideator Installer" -ForegroundColor Cyan
Write-Host "==================================" -ForegroundColor Cyan
Write-Host ""

# Check if Deep Research is installed (prerequisite)
if (-not (Test-Path "$env:USERPROFILE\.claude\skills\deep-research")) {
    Write-Host "WARNING: Deep Research skill not found." -ForegroundColor Yellow
    Write-Host "The Mechanism Ideator works best with Deep Research installed."
    Write-Host "Install Deep Research first for the best results."
    Write-Host ""
    $response = Read-Host "Continue without Deep Research? (y/N)"
    if ($response -ne "y" -and $response -ne "Y") {
        Write-Host "Install Deep Research first, then re-run this installer."
        exit 1
    }
} else {
    Write-Host "Found Deep Research skill - good!" -ForegroundColor Green
}

# Check if skill already exists
if (Test-Path $SKILL_DIR) {
    Write-Host ""
    Write-Host "Warning: $SKILL_DIR already exists" -ForegroundColor Yellow
    $response = Read-Host "Overwrite? (y/N)"
    if ($response -ne "y" -and $response -ne "Y") {
        Write-Host "Installation cancelled"
        exit 1
    }
    Remove-Item -Recurse -Force $SKILL_DIR
}

# Create skill directory
Write-Host "Creating skill directory..."
New-Item -ItemType Directory -Force -Path "$SKILL_DIR\references" | Out-Null

# Copy skill files
Write-Host "Copying skill files..."
Copy-Item "$SCRIPT_DIR\SKILL.md" "$SKILL_DIR\"
Copy-Item "$SCRIPT_DIR\references\*.md" "$SKILL_DIR\references\"

Write-Host ""
Write-Host "==================================" -ForegroundColor Green
Write-Host "Installation Complete!" -ForegroundColor Green
Write-Host "==================================" -ForegroundColor Green
Write-Host ""
Write-Host "Skill installed to: $SKILL_DIR"
Write-Host ""
Write-Host "TEST IT: Open Claude Code and say:"
Write-Host "  '/mechanism-ideator-package Review my course modules and create mechanisms'"
Write-Host ""
Write-Host "==================================" -ForegroundColor Cyan
