#!/bin/bash
# Mechanism Ideator Skill Installer for Mac/Linux
# Installs the mechanism ideation skill for Claude Code

set -e

SKILL_NAME="mechanism-ideator-package"
SKILL_DIR="$HOME/.claude/skills/$SKILL_NAME"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "=================================="
echo "Mechanism Ideator Installer"
echo "=================================="
echo ""

# Check if Deep Research is installed (prerequisite)
if [ ! -d "$HOME/.claude/skills/deep-research" ]; then
    echo "WARNING: Deep Research skill not found at ~/.claude/skills/deep-research"
    echo "The Mechanism Ideator works best with Deep Research installed."
    echo "Install Deep Research first for the best results."
    echo ""
    read -p "Continue without Deep Research? (y/N) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Install Deep Research first, then re-run this installer."
        exit 1
    fi
else
    echo "Found Deep Research skill - good!"
fi

# Check if skill already exists
if [ -d "$SKILL_DIR" ]; then
    echo ""
    echo "Warning: $SKILL_DIR already exists"
    read -p "Overwrite? (y/N) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Installation cancelled"
        exit 1
    fi
    rm -rf "$SKILL_DIR"
fi

# Create skill directory
echo "Creating skill directory..."
mkdir -p "$SKILL_DIR/references"

# Copy skill files
echo "Copying skill files..."
cp "$SCRIPT_DIR/SKILL.md" "$SKILL_DIR/"
cp "$SCRIPT_DIR/references/"*.md "$SKILL_DIR/references/"

echo ""
echo "=================================="
echo "Installation Complete!"
echo "=================================="
echo ""
echo "Skill installed to: $SKILL_DIR"
echo ""
echo "TEST IT: Open Claude Code and say:"
echo "  '/mechanism-ideator-package Review my course modules and create mechanisms'"
echo ""
echo "=================================="
