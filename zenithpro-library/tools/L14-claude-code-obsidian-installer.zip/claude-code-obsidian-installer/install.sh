#!/bin/bash

# ============================================================
# Claude Code MCP - Obsidian Plugin Installer
# Strategic Profits Team
#
# Automatically finds all Obsidian vaults on your Mac and
# installs the Claude Code MCP plugin into each one.
#
# Usage: bash install.sh
# ============================================================

set -euo pipefail

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PLUGIN_ID="claude-code-mcp"
PLUGIN_DIR_NAME="obsidian-claude-code-mcp"
REQUIRED_FILES=("main.js" "manifest.json" "styles.css")

echo ""
echo -e "${BOLD}========================================${NC}"
echo -e "${BOLD}  Claude Code MCP - Obsidian Installer  ${NC}"
echo -e "${BOLD}========================================${NC}"
echo ""

# --- Verify plugin files exist next to this script ---
echo -e "${BLUE}Checking plugin files...${NC}"
for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$SCRIPT_DIR/$file" ]; then
        echo -e "${RED}Error: $file not found in $SCRIPT_DIR${NC}"
        echo "Make sure main.js, manifest.json, and styles.css are in the same folder as this script."
        exit 1
    fi
done
echo -e "${GREEN}All plugin files found.${NC}"
echo ""

# --- Find Obsidian vaults ---
echo -e "${BLUE}Searching for Obsidian vaults...${NC}"
echo "(This searches your home directory for .obsidian folders)"
echo ""

VAULTS=()
while IFS= read -r line; do
    # Strip the /.obsidian suffix to get vault path
    vault_path="${line%/.obsidian}"
    VAULTS+=("$vault_path")
done < <(find "$HOME" -name ".obsidian" -type d -maxdepth 6 2>/dev/null | sort)

if [ ${#VAULTS[@]} -eq 0 ]; then
    echo -e "${RED}No Obsidian vaults found.${NC}"
    echo "Make sure Obsidian is installed and you've opened at least one vault."
    exit 1
fi

echo -e "Found ${BOLD}${#VAULTS[@]}${NC} Obsidian vault(s):"
echo ""
for i in "${!VAULTS[@]}"; do
    vault_name=$(basename "${VAULTS[$i]}")
    echo "  $((i+1)). $vault_name"
    echo "     ${VAULTS[$i]}"
done
echo ""

# --- Confirm installation ---
read -p "Install Claude Code MCP plugin to ALL vaults? (y/n) " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    echo "You can also install to specific vaults:"
    echo "  Enter vault numbers separated by spaces (e.g., '1 3 5')"
    echo "  Or press Enter to cancel."
    echo ""
    read -p "Vault numbers: " -r SELECTIONS

    if [ -z "$SELECTIONS" ]; then
        echo "Installation cancelled."
        exit 0
    fi

    SELECTED_VAULTS=()
    for num in $SELECTIONS; do
        idx=$((num - 1))
        if [ $idx -ge 0 ] && [ $idx -lt ${#VAULTS[@]} ]; then
            SELECTED_VAULTS+=("${VAULTS[$idx]}")
        else
            echo -e "${YELLOW}Warning: Skipping invalid selection '$num'${NC}"
        fi
    done
    VAULTS=("${SELECTED_VAULTS[@]}")

    if [ ${#VAULTS[@]} -eq 0 ]; then
        echo "No valid vaults selected. Exiting."
        exit 0
    fi
fi

echo ""
echo -e "${BLUE}Installing...${NC}"
echo ""

INSTALLED=0
SKIPPED=0
FAILED=0

for vault_path in "${VAULTS[@]}"; do
    vault_name=$(basename "$vault_path")
    dest="$vault_path/.obsidian/plugins/$PLUGIN_DIR_NAME"

    echo -n "  $vault_name... "

    # Create plugin directory
    if ! mkdir -p "$dest" 2>/dev/null; then
        echo -e "${RED}FAILED (can't create directory)${NC}"
        ((FAILED++))
        continue
    fi

    # Copy plugin files
    copy_failed=false
    for file in "${REQUIRED_FILES[@]}"; do
        if ! cp "$SCRIPT_DIR/$file" "$dest/" 2>/dev/null; then
            copy_failed=true
            break
        fi
    done

    if $copy_failed; then
        echo -e "${RED}FAILED (can't copy files)${NC}"
        ((FAILED++))
        continue
    fi

    # Enable plugin in community-plugins.json
    cp_file="$vault_path/.obsidian/community-plugins.json"
    if [ -f "$cp_file" ]; then
        # Add to existing list if not present
        python3 -c "
import json, sys
try:
    with open('$cp_file') as f:
        plugins = json.load(f)
    if '$PLUGIN_ID' not in plugins:
        plugins.append('$PLUGIN_ID')
        with open('$cp_file', 'w') as f:
            json.dump(plugins, f, indent=2)
except Exception as e:
    print(f'Warning: Could not update community-plugins.json: {e}', file=sys.stderr)
" 2>/dev/null
    else
        # Create new file
        echo "[\"$PLUGIN_ID\"]" > "$cp_file"
    fi

    echo -e "${GREEN}OK${NC}"
    ((INSTALLED++))
done

echo ""
echo -e "${BOLD}========================================${NC}"
echo -e "  ${GREEN}Installed:${NC} $INSTALLED"
[ $SKIPPED -gt 0 ] && echo -e "  ${YELLOW}Skipped:${NC}   $SKIPPED"
[ $FAILED -gt 0 ] && echo -e "  ${RED}Failed:${NC}    $FAILED"
echo -e "${BOLD}========================================${NC}"
echo ""

if [ $INSTALLED -gt 0 ]; then
    echo -e "${BOLD}Next steps:${NC}"
    echo "  1. Restart Obsidian (or reload: Cmd+Shift+P > 'Reload app without saving')"
    echo "  2. The plugin should auto-enable. If not:"
    echo "     Settings > Community Plugins > find 'Claude Code MCP' > Enable"
    echo "  3. Open a terminal in your vault folder and run: claude"
    echo "     Claude Code will auto-detect the Obsidian connection."
    echo ""
fi
