# Girard Desire Autopsy

Diagnoses why a product launch, campaign, or competitor effort succeeded or failed — by analyzing the hidden desire structure underneath the marketing.

---

## What This Does For You

Most launch post-mortems look at copy quality, offer structure, funnel mechanics, traffic, and timing. All of that matters. But none of it explains why two launches with nearly identical execution produce wildly different results.

The Girard Desire Autopsy goes one level deeper: it examines the *mimetic desire structure* of your marketing — who was positioned as the desire model, what type of mediation they represented, whether that model matched what your market actually responds to, and whether the desire triangle (Subject → Model → Object) was coherent or broken.

This is the diagnostic layer that conventional analysis cannot surface. It tells you *why* a well-written, well-executed launch flopped — or *why* a competitor's launch crushed it when yours didn't.

Use it on your own launches (past or upcoming), on competitor launches you want to understand, or on any campaign where you want to extract replicable desire-architecture lessons.

---

## How It Works

The autopsy is structured in five sections:

1. **Desire Architecture Map** — diagrams the desire model actually used (model type, mediation type, desire object, triangle integrity)
2. **Four Diagnoses** — evaluates Model Type, Mediation Type, Model-Market Fit, and Desire Triangle Integrity
3. **Failure Mode Classification** — identifies which of 7 specific failure patterns was present (if analyzing a failure)
4. **Counter-Factual Recommendations** — specific rewrites for each failure found
5. **Success Replication** — if analyzing a win, extracts the replicable formula

See `how-it-works.md` for visual diagrams of the framework.

---

## Installation

### Mac (Terminal)

```bash
cd ~/Downloads/girard-desire-autopsy
chmod +x install.sh
./install.sh
```

### Windows (PowerShell)

```powershell
cd ~/Downloads/girard-desire-autopsy
.\install.ps1
```

---

## What Gets Installed

| File | Destination |
|------|-------------|
| `SKILL.md` | `~/.claude/skills/girard-desire-autopsy/SKILL.md` |

That's it — one file, one location. Claude Code picks it up automatically.

---

## How to Use

After installing, trigger the skill in any Claude Code session:

**Run a desire autopsy:**
```
Run a desire autopsy on [launch name / URL / description]
```

**Diagnose a failure:**
```
Why didn't [launch] convert? Run a desire autopsy.
```

**Analyze a competitor:**
```
Run a desire autopsy on [competitor's campaign]. Here's what I observed: [description]
```

**Prepare an upcoming launch:**
```
Run a desire autopsy on my upcoming launch. Here's the plan: [description]
```

### What to provide

Required — one of:
- URL(s) of sales page, webinar, or promotional campaign
- Marketing materials (copy, email sequences, ads)
- Description of the launch sufficient to reconstruct the desire structure

Optional (improves diagnosis):
- Results data (conversion rate, revenue, refund rate)
- Target market definition
- Competitor context

### Output

The skill saves the autopsy report to:
```
[your-project-folder]/René Girard - Desire Autopsy/01 - Desire Autopsy - [Launch Name] - [Date].md
```

---

## Configuration

No configuration required. The skill reads whatever marketing material you provide directly in the conversation.

---

## Troubleshooting

**Skill not triggering after install**
- Restart Claude Code completely (not just a new session tab)
- Verify the file exists: `ls ~/.claude/skills/girard-desire-autopsy/`

**"Permission denied" on Mac**
```bash
chmod +x install.sh
./install.sh
```

**Windows: "cannot be loaded because running scripts is disabled"**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
.\install.ps1
```

**Mac-specific:** If you see `sed: 1: ... extra characters at the end`, the install script uses `-i.bak` which is correct for macOS. A `.bak` backup file may be created — you can safely delete it.

**Windows-specific:** Use `python` not `python3` if any Python dependencies are involved. The installer uses PowerShell-native cmdlets throughout.

---

## Requirements

- Claude Code installed and configured
- Mac (bash) or Windows (PowerShell 5.1+)
- No API keys required
- No additional dependencies

---

*Packaged by Rich Schefren - Strategic Profits*
