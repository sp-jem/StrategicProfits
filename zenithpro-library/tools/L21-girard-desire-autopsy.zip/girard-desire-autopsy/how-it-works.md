# How It Works: Girard Desire Autopsy

Visual diagrams of the framework architecture and autopsy flow.

---

## Overview: From Input to Diagnosis

```mermaid
flowchart TD
A[Marketing Materials<br>or Launch Description] --> B[Desire Architecture Map]
B --> C[Four Diagnoses]
C --> D{Success or Failure?}
D -->|Failure| E[Failure Mode Classification]
D -->|Success| F[Replication Formula]
E --> G[Counter-Factual Rewrites]
F --> H[Autopsy Report]
G --> H
```

---

## The Desire Triangle

The core Girardian framework — every purchase decision runs through this structure.

```mermaid
flowchart TD
S[Subject<br>the prospect] -->|desires| O[Object<br>identity transformation]
M[Model<br>desire mediator] -->|points toward| O
S -->|imitates| M
```

A broken triangle = broken desire = no purchase, regardless of copy quality.

---

## Four Diagnoses

```mermaid
flowchart LR
A[Marketing] --> B[Model Type<br>Who mediates desire?]
A --> C[Mediation Type<br>External or Internal?]
A --> D[Model-Market Fit<br>Does market identify?]
A --> E[Triangle Integrity<br>All legs coherent?]
B --> F[STRONG / WEAK / MISALIGNED]
C --> F
D --> F
E --> F
```

---

## Model Types

```mermaid
flowchart TD
A[Model Type] --> B[Founder or Presenter<br>owns their results]
A --> C[Celebrity or External Figure<br>aspirational distance]
A --> D[Peer Success Story<br>near-rival customer]
A --> E[Abstract Outcome<br>no model present]
A --> F[Community or Movement<br>we as model]
```

---

## Mediation Types

```mermaid
flowchart LR
A[External Mediation] --> B[Model is aspirational<br>distant, admired<br>not a competitor]
C[Internal Mediation] --> D[Model is a near-peer<br>someone prospect<br>competes with]
B --> E[Generates admiration]
D --> F[Generates rivalry-driven desire<br>converts at high-ticket]
```

---

## Failure Mode Classification

```mermaid
flowchart TD
A[Underperformance Detected] --> B{Primary Failure Mode}
B --> C[No Model<br>feature-only marketing]
B --> D[Wrong Model Type<br>external when internal needed]
B --> E[Model-Market Mismatch<br>market doesnt identify]
B --> F[Conflicting Models<br>incompatible desires]
B --> G[Skandalon Dynamic<br>model attracts and blocks]
B --> H[Invisible Object<br>identity outcome unclear]
B --> I[Shattered Triangle<br>all legs present but incoherent]
```

---

## Output Files

```mermaid
flowchart LR
A[Autopsy Complete] --> B[Saved to project folder]
B --> C[Rene Girard - Desire Autopsy folder]
C --> D[01 - Desire Autopsy -<br>Launch Name - Date.md]
```

---

## When to Use This

| Situation | What You Get |
|-----------|-------------|
| Failed launch | Specific failure mode + counter-factual fixes |
| Successful launch | Replicable desire formula |
| Competitor analysis | Why their launch worked when yours didn't |
| Pre-launch review | Desire structure check before going live |
| Historical debrief | Pattern extraction across multiple launches |
