# Girard Desire Autopsy - Windows Installer
$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDir = Join-Path $env:USERPROFILE ".claude\skills\girard-desire-autopsy"
$SkillFile = Join-Path $ScriptDir "SKILL.md"

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Girard Desire Autopsy -- Installer" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Check source file exists
if (-not (Test-Path $SkillFile)) {
    Write-Host "ERROR: SKILL.md not found in $ScriptDir" -ForegroundColor Red
    Write-Host "Make sure you're running this from inside the girard-desire-autopsy folder."
    exit 1
}

# Check for existing installation
if (Test-Path $InstallDir) {
    Write-Host "Existing installation found at: $InstallDir" -ForegroundColor Yellow
    $confirm = Read-Host "Overwrite it? (y/N)"
    if ($confirm -notmatch "^[Yy]$") {
        Write-Host "Installation cancelled."
        exit 0
    }
    $timestamp = Get-Date -Format "yyyyMMddHHmmss"
    $backupPath = "${InstallDir}.bak.${timestamp}"
    Write-Host "Backing up existing installation to $backupPath..."
    Copy-Item -Path $InstallDir -Destination $backupPath -Recurse
    Write-Host "Backup saved." -ForegroundColor Green
}

# Create destination and install
Write-Host ""
Write-Host "Installing..." -ForegroundColor Cyan
New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
Copy-Item -Path $SkillFile -Destination (Join-Path $InstallDir "SKILL.md") -Force

# Verify
$InstalledFile = Join-Path $InstallDir "SKILL.md"
if (Test-Path $InstalledFile) {
    Write-Host ""
    Write-Host "================================================" -ForegroundColor Green
    Write-Host "  Installation Complete" -ForegroundColor Green
    Write-Host "================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Installed:"
    Write-Host "  $InstalledFile"
    Write-Host ""
    Write-Host "To use:"
    Write-Host "  Open Claude Code and say:"
    Write-Host "  'Run a desire autopsy on [launch name or URL]'"
    Write-Host ""
    Write-Host "Restart Claude Code if it was already open."
    Write-Host ""
} else {
    Write-Host "ERROR: Installation failed -- SKILL.md not found at destination." -ForegroundColor Red
    exit 1
}
