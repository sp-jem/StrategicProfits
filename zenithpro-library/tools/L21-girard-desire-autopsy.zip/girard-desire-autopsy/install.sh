#!/bin/bash
# Girard Desire Autopsy - Mac/Linux Installer
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/.claude/skills/girard-desire-autopsy"
SKILL_FILE="$SCRIPT_DIR/SKILL.md"

echo ""
echo "================================================"
echo "  Girard Desire Autopsy — Installer"
echo "================================================"
echo ""

# Check source file exists
if [ ! -f "$SKILL_FILE" ]; then
  echo "ERROR: SKILL.md not found in $SCRIPT_DIR"
  echo "Make sure you're running this from inside the girard-desire-autopsy folder."
  exit 1
fi

# Check for existing installation
if [ -d "$INSTALL_DIR" ]; then
  echo "Existing installation found at: $INSTALL_DIR"
  read -r -p "Overwrite it? (y/N): " confirm
  if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
    echo "Installation cancelled."
    exit 0
  fi
  echo "Backing up existing installation..."
  cp -r "$INSTALL_DIR" "${INSTALL_DIR}.bak.$(date +%Y%m%d%H%M%S)"
  echo "Backup saved."
fi

# Create destination and install
echo ""
echo "Installing..."
mkdir -p "$INSTALL_DIR"
cp "$SKILL_FILE" "$INSTALL_DIR/SKILL.md"

# Verify
if [ -f "$INSTALL_DIR/SKILL.md" ]; then
  echo ""
  echo "================================================"
  echo "  Installation Complete"
  echo "================================================"
  echo ""
  echo "Installed:"
  echo "  $INSTALL_DIR/SKILL.md"
  echo ""
  echo "To use:"
  echo "  Open Claude Code and say:"
  echo "  'Run a desire autopsy on [launch name or URL]'"
  echo ""
  echo "Restart Claude Code if it was already open."
  echo ""
else
  echo "ERROR: Installation failed — SKILL.md not found at destination."
  exit 1
fi
