<!-- my-housekeeper v2.0 -->

# My Housekeeper

**Purpose:** Scans an Obsidian vault for dead files, misplaced notes, duplicates, broken links, agent debris, tag rot, folder debt, and organizational entropy. Produces a scored health report (`VAULT-HEALTH-REPORT-[DATE].md`) and executes approved cleanup actions with full undo logging. Can also survey your entire vault and propose an organizational restructure with a full migration plan.

Run weekly to keep your vault clean, after any intensive building sprint, when you want a reorganization plan, or on-demand whenever things feel messy.

## How to use

```
/my-housekeeper
/my-housekeeper deep
/my-housekeeper post-sprint
/my-housekeeper organize
```

**Modes:**
- `(no argument)` -- Standard scan. All phases, balanced speed. Default for weekly runs.
- `deep` -- Deep scan. Adds content-similarity duplicate detection, tag hygiene analysis, frontmatter consistency audit, and folder structure optimization. Takes longer but finds everything.
- `post-sprint` -- Post-sprint mode. Specifically targets agent artifacts, temporary build files, handoff documents, and other debris left behind by intensive AI work sessions. Run this after any major build sprint.
- `organize` -- Organizational Architect mode. Surveys the entire vault, understands what's in every folder, detects content themes and overlaps, then proposes a new folder structure with a full migration plan. Use when your vault feels disorganized and you want a reorganization plan -- not just cleanup.

Pass an optional vault path as the second argument. Defaults to the current working directory.

## Instructions

Scan the vault at the provided path (or cwd). Execute ALL phases in order. Do NOT skip any phase.

---

### PHASE 1: VAULT CENSUS

Count and report:
- Total files (by type: .md, .pdf, .pptx, .html, .py, .js, .json, .canvas, .css, .sh, .ps1, other)
- Total folders (excluding .obsidian/, .git/, node_modules/)
- Total vault size on disk
- Deepest nesting level (folders within folders)
- Largest 10 files by size
- Files modified in last 24 hours (recent activity)
- Files not modified in 90+ days (cold storage candidates)

Output as a summary table at the top of the report.

---

### PHASE 2: PROBLEM DETECTION

Run each scan. For each problem found, log the file path, the problem type, and a proposed fix.

**2a. Empty Files**
- Files with 0 bytes
- Files with only YAML frontmatter but no body content
- Files with fewer than 10 words of actual content (excluding frontmatter)

**2b. Orphaned Files**
- Files that are not linked TO by any other file (no incoming wikilinks)
- AND not linking OUT to any other file (no outgoing wikilinks)
- Exclude from detection: CLAUDE.md, README.md, .inbox.md, index files, SKILL.md, AGENT.md, config files (.json, .yaml, .yml), installer scripts (.sh, .ps1), CHANGELOG.md, LICENSE, MEMORY.md, any file in .obsidian/

**2c. Duplicate Content**
- Files with identical names in different folders (Obsidian auto-creates "Note 2.md", "Note 3.md" etc.)
- Files where the first 200 characters of content (after frontmatter) are identical
- **[deep mode only]** Files with >80% content similarity (compare first 500 chars, last 500 chars, and word count)

**2d. Misplaced Files**
- Files whose content clearly doesn't match the folder they're in. Use these heuristics:
  - Meeting transcript in a non-meetings folder (look for speaker labels, timestamps, "Zoom", "call" patterns)
  - Skill file (contains `## Instructions` or `## How to use` patterns) outside a skills directory
  - Image files (.png, .jpg, .gif, .svg, .webp) in the vault root instead of an assets/attachments folder
  - Python/JS/shell scripts in unexpected locations (not in a skills/, scripts/, or tools/ folder)
  - Files starting with "draft-" or "v1-", "v2-" in a folder that isn't a drafts/ or versions/ folder

**2e. Broken Wikilinks**
- Wikilinks (`[[Target]]`) that point to notes that don't exist anywhere in the vault
- Broken embeds (`![[Image]]` where the file doesn't exist)
- List the source file and the broken link target

**2f. Stale Files**
- Files in "active" folders (anything with current year, "Active", "Current", "WIP" in the path) that haven't been modified in 30+ days
- Files in project folders where the project appears complete (contains "COMPLETE", "DONE", "SHIPPED" in PROJECT-STATE or similar) but working files remain un-archived

**2g. Naming Issues**
- Files named "Untitled", "Untitled 1", "New Note", "Copy of ...", or containing " copy" suffix
- Files with special characters that cause cross-platform issues (curly quotes in filename, em-dashes, colons on Windows)
- Files with extremely long names (>100 characters)
- Files with leading/trailing spaces in the filename
- Files with double spaces in the filename

**2h. Oversized Markdown Files**
- Single markdown files over 100KB that should probably be split
- For each, suggest how to split (by H2 headers, by date sections, by topic)

**2i. Sync Bloat / Binary Files**
- Video files: .mov, .mp4, .m4a, .wav, .webm, .avi, .mkv
- Office files over 1MB: .pptx, .docx, .xlsx
- Archives: .zip, .tar, .gz, .rar, .7z, .tar.gz
- Other binaries: .dmg, .pkg, .exe, .iso, .app
- Images over 5MB: .png, .jpg, .gif, .tiff, .bmp
- Any single file over 50MB regardless of type
- Database files: .sqlite, .db
- For each, report: filename, size, last modified date, folder
- Calculate total sync bloat in MB/GB
- Proposed fix: move to external storage and replace with a pointer note
- Flag the top 20 largest files separately as "quick wins"

**2j. Agent Artifacts** (always scanned, prioritized in post-sprint mode)
- Handoff documents (files matching `HANDOFF*.md`, `handoff*.md`) from completed conversations that are no longer active
- Completed requirement checklists (files with all items marked `Complete` or `Done` and no `Pending`/`In Progress`)
- Progress logs from finished projects (`PROGRESS-LOG*.md` where the associated project is complete)
- Consumption receipts that are older than 7 days (files containing `## CONSUMPTION RECEIPT`)
- Temporary research files (filenames containing `temp-`, `scratch-`, `_tmp`, `_scratch`)
- Failed or abandoned agent outputs (partially written files with `## HANDOFF DOCUMENT` but no completion)
- Duplicate skill outputs from multiple runs (same skill, same topic, different timestamps)
- Build artifacts in the vault: `dist/`, `build/`, `node_modules/`, `__pycache__/`, `.venv/`, `venv/`, `.cache/`
- Stale `.canvas` files that reference notes no longer in the vault
- Files named with timestamp prefixes that are older than 30 days and not linked from anywhere (e.g., `20260115_143022_...`)

**2k. Empty Folders**
- Folders containing zero files (often left behind after moves/deletes)
- Folders containing only `.DS_Store` or `Thumbs.db` (effectively empty)
- Nested empty folder chains (empty folder inside empty folder)

**2l. Tag Hygiene** (deep mode only)
- Orphan tags: tags that appear in only 1 file across the entire vault
- Variant tags: tags that differ only by case (#Marketing vs #marketing), pluralization (#project vs #projects), or minor spelling (#analyse vs #analyze)
- Tag explosion: report if the vault has more unique tags than 1/3 of its total file count
- Suggest tag consolidation groupings

**2m. Frontmatter Issues** (deep mode only)
- Malformed YAML frontmatter (unclosed quotes, invalid syntax, tabs instead of spaces)
- Duplicate property keys in the same file
- Properties with null, empty string, or `[]` values that serve no purpose
- Files in the same folder with wildly inconsistent property schemas (e.g., one file has 8 properties, adjacent file has 0)

**2n. Unlinked Attachments**
- Images (.png, .jpg, .gif, .svg, .webp, .pdf) that exist in the vault but are not embedded or linked from any .md file
- Count total attachment storage used by unlinked files

**2o. Folder Structure Debt** (deep mode only)
- Singleton folders: folders containing only 1 file (unnecessary nesting -- the file could move up a level)
- Overstuffed folders: folders containing 100+ items (should be subdivided)
- Inconsistent naming at the same level: siblings using different conventions (Title Case, kebab-case, snake_case, UPPER_CASE)
- Excessive depth: any path more than 6 levels deep from vault root
- Folders with underscore prefixes (`_archive/`, `_staging/`) that are growing unbounded (report their size and age)

---

### PHASE 3: CLEANUP REPORT

Output a markdown file with:

**Summary Dashboard:**
```
## Vault Health Report -- [Date]

| Metric | Count |
|--------|-------|
| Total files | X |
| Total folders | X |
| Vault size | X MB |
| Healthy files | X |
| Problems found | X |
| Empty files | X |
| Orphaned files | X |
| Duplicates | X |
| Misplaced | X |
| Broken links | X |
| Stale files | X |
| Naming issues | X |
| Oversized .md | X |
| Sync bloat | X files (X GB) |
| Agent artifacts | X |
| Empty folders | X |
| Tag issues | X |
| Frontmatter issues | X |
| Unlinked attachments | X |
| Folder debt | X |

**Health Score: X/100**
```

**Problem Table (grouped by severity):**

Show CRITICAL first, then HIGH, then MEDIUM, then LOW. Within each severity, group by problem type.

| # | File | Problem | Sev | Fix |
|---|------|---------|-----|-----|
| 1 | path/to/file.md | Empty (0 bytes) | LOW | Delete |
| 2 | path/to/other.md | Agent handoff (stale) | MED | Archive |

Severity levels:
- **CRITICAL** -- Broken links (confuses navigation), duplicates causing confusion, sync bloat over 100MB total, build artifacts in vault (node_modules, dist, __pycache__)
- **HIGH** -- Misplaced files, oversized files needing splits, individual files over 50MB, malformed frontmatter (breaks Obsidian features)
- **MEDIUM** -- Orphaned files, stale files, agent artifacts, unlinked attachments, sync bloat under 100MB
- **LOW** -- Empty files, naming issues, empty folders, tag hygiene, singleton folders, frontmatter inconsistencies

**Top Recommendations:**

After the problem table, provide a prioritized list of the 5 highest-impact actions. Frame as: "Doing X will reclaim Y MB / fix Z problems / improve score by N points."

---

### PHASE 4: CLEANUP EXECUTION (on approval only)

After presenting the report, ask:

> "Want me to execute the cleanup? Options:
> 1. **All fixes** -- everything in the report
> 2. **Critical + High only** -- safest high-impact cleanup
> 3. **Pick categories** -- tell me which problem types to fix
> 4. **Skip** -- just keep the report for now"

If approved, execute in this order (safest first):

1. **Delete** empty/0-byte files and effectively-empty folders (safest -- nothing of value lost)
2. **Remove** build artifacts (node_modules/, dist/, __pycache__/, .venv/, etc.) -- these regenerate
3. **Rename** files with naming issues (remove leading/trailing spaces, replace problematic characters)
4. **Move** misplaced files to correct folders (create destination folders if needed)
5. **Archive** stale files to an `_archive/` subfolder within their current parent (don't move far -- easy to find)
6. **Archive** agent artifacts to `_archive/agent-cleanup-[DATE]/` (group by type: handoffs, receipts, temp files)
7. **Stage** sync bloat files to `_sync-bloat-staging/` in the vault root (create pointer notes with the original path and instructions to move to external storage)
8. **Split** oversized markdown files by H2 headers into separate notes (create an index note linking to all parts)
9. **Fix** broken wikilinks (**deep mode only** -- in standard mode, broken wikilinks are REPORTED but never auto-fixed):
   - If the target was clearly renamed (fuzzy match within 2 edit-distance AND only one candidate matches), update the link
   - If multiple fuzzy candidates exist, list all candidates in the report and do NOT auto-fix (ambiguous matches require manual review)
   - If no match, create a stub note: `# [Target]\n\n> This note was auto-created by My Housekeeper to fix a broken link from [[Source]]. Add content or delete this stub.`
10. **Flag** duplicates for manual review (write a `_DUPLICATES-REVIEW-[DATE].md` file listing pairs with diff summaries -- never auto-delete duplicates)
11. **Consolidate** variant tags (deep mode, with approval per tag group)

For each action taken, log:
- What was done
- Source path
- Destination path (if moved)
- Reversible? (Yes for all moves/renames/archives, No for empty file deletes and build artifact removal)
- Undo command (for moves: the reverse move path)

---

### PHASE 5: BEFORE/AFTER SUMMARY

After cleanup, re-run the census from Phase 1 and show the delta:

```
## Cleanup Results -- [Date]

| Metric | Before | After | Delta |
|--------|--------|-------|-------|
| Total files | 1,247 | 1,198 | -49 |
| Total folders | 89 | 76 | -13 |
| Vault size | 2.4 GB | 1.8 GB | -600 MB |
| Problems | 87 | 12 | -75 |
| Health Score | 62/100 | 91/100 | +29 |
```

**What remains:** List any problems that were intentionally skipped or require manual review. Explain why.

---

### PHASE 6: MAINTENANCE LOG (persistent)

Append the run results to `_maintenance/HEALTH-HISTORY.md` in the vault root. Create the file if it doesn't exist. Format:

```markdown
## Health History

| Date | Score | Files | Problems | Mode | Actions |
|------|-------|-------|----------|------|---------|
| 2026-03-27 | 91/100 | 1,198 | 12 | standard | 75 fixed |
| 2026-03-20 | 62/100 | 1,247 | 87 | post-sprint | 0 (report only) |
```

The table tracks trends across runs.

---

---

## ORGANIZE MODE â Organizational Architect

When invoked with `/my-housekeeper organize`, skip Phases 1-6 above and run the Organize pipeline instead. This mode is an organizational architect, not a janitor -- it looks at what you HAVE and proposes where it SHOULD live.

---

### ORG PHASE 1: VAULT SURVEY

Scan every top-level folder and its immediate children. For EACH top-level folder, capture:

- **Folder name and path**
- **File count** (total files, including nested)
- **Content types** (breakdown by .md, .pdf, .pptx, images, code, other)
- **Purpose** -- infer from: folder name, any CLAUDE.md or README.md or PROJECT-REFERENCE.md inside, sample of 3-5 representative filenames, and frontmatter/content patterns in 2-3 files
- **Activity level** -- newest file modified date, oldest file modified date, percentage of files modified in last 30 days
- **Key topics** -- scan H1/H2 headers and filenames to extract the dominant 3-5 themes
- **Vault size contribution** -- how much disk space this folder uses

Also scan for files living directly in the vault root (outside any folder). These are almost always misplaced.

Output the survey as a structured inventory before proceeding.

---

### ORG PHASE 2: THEME DETECTION

Analyze the survey from Phase 1 to identify:

**2a. Content Clusters**
- Groups of files across different folders that share a common theme, project, or purpose
- Example: marketing files scattered across 4 different folders that logically belong together

**2b. Folder Overlap**
- Two or more folders serving the same logical purpose (e.g., "Research/" and "Notes/Research/" and "Resources/")
- Folders where 50%+ of content could reasonably live in another existing folder

**2c. Orphan Folders**
- Folders with no clear relationship to any other folder or active project
- Folders containing only stale content (100% of files older than 90 days) with no README or purpose doc

**2d. Structural Patterns**
- What organizational convention the vault currently uses (or attempts to use): by project? by type? by date? by workflow stage? Mixed?
- Which convention is dominant (covers the most files)
- Where the convention breaks down

**2e. Depth and Nesting Issues**
- Folders nested more than 4 levels deep (usually a sign of over-organization)
- Single-child folder chains (A/ â B/ â C/ â one file -- the file could live 3 levels higher)

**2f. Scale Assessment**
- Total unique topics/projects detected
- Ratio of folders to logical topics (more folders than topics = fragmentation; fewer = stuffing)
- Whether the vault is small enough for flat structure or large enough to need hierarchy

---

### ORG PHASE 3: PROVENANCE CHECK

**MANDATORY before proposing any moves.** For every folder or file you might recommend moving, merging, or restructuring:

1. **Is anything hardcoded to this path?** Search for the path in:
   - All CLAUDE.md files in the vault and in `~/.claude/`
   - Skill files, agent files, hook scripts
   - Settings files, config files
   - Other notes that reference the path via wikilinks or file links

2. **Is this a system convention?** Some folders exist because a tool, automation, or workflow writes to them. The folder is an inbox, not just content. Moving it breaks the system that feeds it.

3. **Who created this and why?** If a project or workflow created the folder, the fix might not be "move the folder" but "decide if the workflow should change."

4. **What links point here?** Count incoming wikilinks to files in this folder. High link count = high blast radius for a move.

For each item in the reorganization plan, include a **Provenance** line showing what depends on the current path. Items with provenance dependencies get flagged with effort ratings that include updating those dependencies.

---

### ORG PHASE 4: STRUCTURE PROPOSAL

Based on Phases 1-3, propose a new organizational structure. Present it as:

**4a. Proposed Folder Tree**
```
Vault Root/
âââ [Folder Name]/          â purpose (new / existing / merged from X+Y)
â   âââ [Subfolder]/        â purpose
â   âââ ...
âââ [Folder Name]/          â purpose
âââ _archive/               â cold storage
```

For each proposed folder:
- Is it NEW, EXISTING (unchanged), RENAMED, or MERGED (from which sources)?
- One-line purpose statement
- What content moves into it

**4b. Design Rationale**
- What organizational principle the proposed structure follows (by project, by type, by workflow, hybrid)
- Why this principle fits this vault better than alternatives
- What tradeoffs were made (e.g., "grouping by project means meeting notes are spread across projects rather than centralized -- but that's where they're most useful")

**4c. What Stays Put**
- Folders that are already well-organized and don't need to move
- Folders protected by provenance (hardcoded paths in tools/skills)

**4d. Alternatives Considered**
- At least one alternative structure you considered and why the proposed one is better

Present the full proposal and STOP. Wait for the user to approve, modify, or reject before proceeding.

---

### ORG PHASE 5: MIGRATION PLAN

After the user approves (or modifies) the structure, produce a detailed migration plan:

**For each action, specify:**

| # | Action | Source | Destination | Files Affected | Links to Update | Provenance Impact | Reversible |
|---|--------|--------|-------------|---------------|-----------------|-------------------|------------|
| 1 | Move | old/path/ | new/path/ | 47 | 12 wikilinks | None | Yes |
| 2 | Merge | folder-A/ + folder-B/ | combined/ | 23 + 18 | 8 wikilinks | CLAUDE.md reference | Yes |
| 3 | Rename | Old Name/ | New Name/ | 31 | 5 wikilinks | skill hardcode | Yes |

**Execution order matters.** Plan moves so that:
1. Folders with zero provenance dependencies move first (safest)
2. Folders requiring link updates move next
3. Folders requiring config/skill updates move last (highest effort)
4. Merges happen after both source folders are in place

**For every move:** list the exact wikilinks that need updating and in which files. A move that breaks links is worse than no move at all.

---

### ORG PHASE 6: EXECUTE MIGRATION (on approval only)

After presenting the migration plan, ask:

> "Ready to execute the reorganization? Options:
> 1. **Full migration** -- execute everything in the plan
> 2. **Safe moves only** -- only moves with zero provenance dependencies
> 3. **Step by step** -- I'll do one action at a time and confirm each
> 4. **Skip** -- just keep the plan document for reference"

If approved, for each action:
1. Create destination folder if it doesn't exist
2. Move files
3. Update ALL wikilinks that referenced moved files (search entire vault)
4. Update any CLAUDE.md, config, or skill references if applicable
5. Log the action to `MIGRATION-LOG-[DATE].md`

After all moves, re-scan for broken wikilinks to verify nothing was missed.

---

### ORG PHASE 7: MIGRATION SUMMARY

Output a before/after comparison:

```
## Reorganization Results -- [Date]

| Metric | Before | After |
|--------|--------|-------|
| Top-level folders | 23 | 12 |
| Orphan folders | 7 | 0 |
| Overlapping folders | 4 pairs | 0 |
| Root-level loose files | 15 | 0 |
| Max nesting depth | 8 | 4 |
| Avg files per folder | 12 | 28 |
| Broken wikilinks introduced | -- | 0 |
```

**What changed:** Narrative summary of the key moves and why.

**What to do next:** Suggest running `/my-housekeeper` (standard mode) to clean up any issues exposed by the reorganization.

Write the migration report to `_maintenance/REORGANIZATION-REPORT-[DATE].md`.

---

## Output Files

Write to `_maintenance/` folder in the vault root (create if needed):

**Standard / Deep / Post-Sprint modes:**
- `VAULT-HEALTH-REPORT-[DATE].md` -- Full report from Phases 1-3
- `CLEANUP-LOG-[DATE].md` -- What was done in Phase 4 (only if cleanup was executed)
- `_DUPLICATES-REVIEW-[DATE].md` -- Duplicate pairs for manual review (only if duplicates found)
- `HEALTH-HISTORY.md` -- Persistent trend log (append, don't overwrite)

**Organize mode:**
- `REORGANIZATION-PLAN-[DATE].md` -- Structure proposal + migration plan from Org Phases 1-5
- `MIGRATION-LOG-[DATE].md` -- What was moved/renamed in Org Phase 6 (only if migration was executed)
- `REORGANIZATION-REPORT-[DATE].md` -- Before/after summary from Org Phase 7

Keep only the 5 most recent health reports. If there are more than 5 `VAULT-HEALTH-REPORT-*.md` files, archive the oldest to `_maintenance/_archive/`.

---

## Design Principles

- **Never delete without asking.** The report proposes; the user approves. Phase 4 only runs on explicit approval.
- **Moves are safer than deletes.** Prefer moving to `_archive/` over deleting. The user can always empty the archive later.
- **Don't touch system files.** Never modify or move: CLAUDE.md, .obsidian/, .git/, node_modules/ (only flag for removal), .gitignore, .DS_Store, any file in ~/.claude/
- **Preserve link integrity.** When moving a file, update all wikilinks that point to it across the vault. This is critical -- a move that breaks 10 links is worse than leaving the file where it is.
- **Speed matters.** Use Glob and Bash for scanning, not file-by-file reads. Standard mode should complete scanning in under 60 seconds for vaults up to 5,000 files. Deep mode may take longer.
- **Context overflow protection.** If the vault contains more than 3,000 files, process Phase 2 scans in folder-level batches rather than holding all results in memory simultaneously. Write intermediate results to `_maintenance/_scan-progress.json` after each batch. Summarize findings per batch, then merge into the final report. Never attempt to list all files in a single Glob call for vaults over 5,000 files -- use folder-by-folder scans.
- **The health score is motivating.** People will re-run this to see their score go up. Make the scoring transparent and fair.
- **Idempotent.** Running the skill twice in a row should produce the same report (minus the things already fixed). Never create problems by running cleanup.
- **Portable.** This skill works on any Obsidian vault on any machine. No hardcoded paths. No assumptions about vault structure beyond Obsidian conventions.

---

## Health Score Calculation

The score is percentage-based to be fair regardless of vault size.

**Base score: 100**

**Deductions (capped so no single category can destroy the score):**

| Problem Type | Per Item | Max Deduction |
|-------------|----------|---------------|
| Empty files | -0.5 | -5 |
| Orphaned files | -0.5 | -10 |
| Duplicates | -1 | -10 |
| Misplaced files | -1.5 | -10 |
| Broken links | -1 | -10 |
| Stale files | -0.25 | -5 |
| Naming issues | -0.5 | -5 |
| Oversized .md | -1 | -5 |
| Sync bloat | -1 per file, -5 bonus if total > 100MB | -15 |
| Agent artifacts | -0.5 | -10 |
| Empty folders | -0.25 | -3 |
| Tag issues | -0.25 | -5 |
| Frontmatter | -0.5 | -5 |
| Unlinked attach. | -0.25 | -5 |
| Folder debt | -0.25 | -5 |
| Build artifacts | -5 per directory found | -10 |

Floor at 0. A vault with 0 problems scores 100.

**Score interpretation:**
- **90-100:** Immaculate. Your vault is a precision instrument.
- **75-89:** Clean. Minor maintenance needed.
- **50-74:** Messy. Organizational debt is accumulating. Run cleanup.
- **25-49:** Neglected. Significant cleanup needed. Expect 30+ minutes.
- **0-24:** Emergency. The vault needs a full intervention.

---

## Output Exemplar

A correctly-formatted problem table entry looks like this (calibration target):

```markdown
| # | File | Problem | Sev | Fix |
|---|------|---------|-----|-----|
| 1 | 00 Projects/CTD-Weekend/dist/assets/index-DUk2V-K-.js | Build artifact (dist/) | CRIT | Remove dist/ directory |
| 2 | 00 Projects/Dashboard Test 1/round-1/revisions/benson-revision.md | Orphaned (0 in, 0 out links) | MED | Review; archive if obsolete |
| 3 | 00 Mission Control/research-staging/20260115_143022_perplexity_query.md | Timestamped, unlinked, 71 days old | MED | Archive to _archive/agent-cleanup-2026-03-27/ |
| 4 | Untitled 3.md | Default name | LOW | Rename or delete |
```

A correctly-formatted top recommendation looks like this:

```
1. **Remove build artifacts** (dist/, node_modules/, __pycache__/) -- reclaims ~340 MB, fixes 6 CRITICAL items, +8 health points.
```

Do NOT produce recommendations that lack the three-part structure: action, quantified impact, score delta.

---

## Guardrails

These files/folders are NEVER touched, moved, reported as problems, or modified:
- `.obsidian/` (Obsidian config)
- `.git/` (version control)
- `CLAUDE.md` at any level
- `MEMORY.md` and memory files
- `.mcp.json`, `settings.json`, `settings.local.json`
- Any file currently open in Obsidian (check for `.obsidian/workspace.json` references)
- The `_maintenance/` folder itself (our own output)
- Installer scripts: `install.sh`, `install.ps1`
