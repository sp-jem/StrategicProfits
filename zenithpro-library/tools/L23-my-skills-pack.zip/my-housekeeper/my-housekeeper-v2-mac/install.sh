#!/bin/bash
# My Housekeeper v2.0 — Installer (Mac/Linux)
# Vault health audit, cleanup, and organizational architect skill for Obsidian

set -e

SKILL_NAME="my-housekeeper"
SKILL_DIR="$HOME/.claude/skills/$SKILL_NAME"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=== Installing My Housekeeper v2.0 ==="
echo ""

# Create skill directory
mkdir -p "$SKILL_DIR"

# Copy skill file
cp "$SCRIPT_DIR/SKILL.md" "$SKILL_DIR/SKILL.md"

echo "Installed to: $SKILL_DIR"
echo ""
echo "Usage:"
echo "  /my-housekeeper              Standard weekly scan"
echo "  /my-housekeeper deep         Deep scan (tag hygiene, frontmatter, folder debt)"
echo "  /my-housekeeper post-sprint  After intensive AI build sessions"
echo "  /my-housekeeper organize     Survey vault + propose reorganization plan"
echo ""
echo "Run from your Obsidian vault directory in Claude Code."
echo ""
echo "=== Installation complete ==="
