<!-- my-toolkit v1.1 -- Prompt Architecture Audit applied 2026-03-27 -->
# My Toolkit

Your complete capability inventory. Scans every skill and agent you have installed, catalogs them with descriptions and trigger phrases, groups them into workflows, maps the 10 most common business actions as visual flowcharts, compares your system against Rich's full system, and produces a priority-ranked list of skills you should request next.

Run this whenever you install new skills, when you sit down and think "I know I have something for this but I can't remember what it's called," or when you want to see how your system compares to what's possible.

## How to use

```
/my-toolkit
```

## Scope

This skill READS and REPORTS. It does not:
- Install, uninstall, or modify any skills or agents
- Execute any skills it discovers
- Send any data outside the local machine
- Create files other than the 3 specified output files
- Modify existing files in the user's vault

## Error Handling

- **Missing directories:** If `~/.claude/skills/` or `~/.claude/agents/` doesn't exist, report the gap and proceed with available data. A user with zero skills still gets Phases 3-6 (comparison and recommendations).
- **Missing reference files:** If any `references/*.md` file is unreadable, report which file is missing and skip Phase 3. Phases 1, 2, 4-6 still work.
- **Context window pressure:** If the combined reference files exceed 50% of available context, summarize the reference catalogs (category counts only) instead of loading full skill lists.
- **Malformed SKILL.md:** If a SKILL.md cannot be parsed (binary file, empty, encoding error), skip that skill with a note: "[folder-name] -- unreadable SKILL.md."

## Duplicate Handling

- Folders ending in " 2" (space-two) are backup copies. Exclude them from all counts, listings, and output.
- Folders starting with "sp-" are team-distributed variants. If both `skill-name` and `sp-skill-name` exist, list only `skill-name`.
- Count unique skills only. Report: "X unique skills (Y total including backups and team variants)."

## What it does

1. **Scans your installed skills and agents** and produces three views: alphabetical, by category, and by workflow
2. **Creates Mermaid flowcharts** for the 10 most common business actions showing which of YOUR skills chain together
3. **Compares your system against Rich's** using the bundled reference catalogs to show the delta
4. **Produces a priority-ranked recommendation list** of skills that would benefit your business the most
5. **Reviews the list with you** interactively -- you agree, disagree, or re-prioritize
6. **Generates a survey-ready output** with your final skill request list

## Instructions

### PHASE 1: SCAN AND CATALOG

**Step 1a: Scan Skills**

Scan `~/.claude/skills/` directory. For each skill folder found, read its `SKILL.md` file (first 30 lines). If the description isn't in the first 30 lines, read up to 60 lines. If still not found, check for `README.md`. If neither exists, list as "[folder-name] -- no description available."

For each skill, extract:
- **Name** (folder name = skill name)
- **Description** (1-2 sentence summary)
- **When to use** (what situation triggers this skill)
- **Trigger phrase** (what you'd type to invoke it: `/skill-name`)
- **Category** (assign to one of the categories listed below)

**Step 1b: Scan Agents**

Scan `~/.claude/agents/` directory. For each agent folder, read its `AGENT.md` file.

For each agent, extract:
- **Name**
- **Purpose** (what it evaluates or orchestrates)
- **When it's invoked** (what triggers it)
- **What it produces** (output format)

**Phase 1 Constraints:**
- If `~/.claude/skills/` does not exist or is empty, report "No skills directory found at ~/.claude/skills/" and skip to Phase 3.
- If a skill fits multiple categories, assign to the FIRST matching category in the list order below.
- NEVER modify, create, or delete any files in `~/.claude/skills/` or `~/.claude/agents/`. This is a read-only scan.
- Tables must NOT require horizontal scrolling in Obsidian. Max 4 columns per table.
- Do NOT recommend the user install anything during the scan phase. Recommendations come in Phase 4.

**Step 1c: Produce THREE Views**

Write all three views into a single file: `MY-TOOLKIT.md`

**View 1: Alphabetical Index**

A complete A-Z listing of every unique skill and agent (after duplicate exclusion). One line each. Do NOT truncate. If the list exceeds 200 entries, that's fine -- completeness is the point.

```markdown
## Alphabetical Index

| Name | Type | Description |
|------|------|-------------|
| ae | Skill | AE complete copywriting workflow |
| ae-body | Skill | AE body copy frameworks |
| ae-critic | Agent | Evaluates copy against AE frameworks |
```

**View 2: By Category**

Group every skill and agent into these workflow categories:

- **Copywriting** -- writing sales copy, emails, headlines, VSLs
- **Marketing Research** -- market analysis, avatar profiling, demand mapping
- **Deep Thinkers** -- behavioral science frameworks (Ariely, Cialdini, Thaler, etc.)
- **Revenue & Analytics** -- financial data, payment platforms, analysis
- **Content & Media** -- content creation, video, images, social media
- **Operations** -- team management, project management, file organization
- **Webinar** -- webinar creation and optimization
- **Offer Design** -- offer architecture, pricing, product design
- **Intelligence** -- briefings, meeting analysis, research orchestration
- **Building** -- skill creation, strategic builder, code quality
- **Integrations** -- WordPress, Cloudflare, ClickUp, Google Drive, Slack
- **Hollywood / Business Strategy** -- power plays, fame engineering, empire building
- **Client Systems** -- onboarding, employee systems, client profiles

Format each category as a section with a table:

```markdown
### Copywriting (X skills, Y agents)

| Name | Type | Description | When to Use |
|------|------|-------------|-------------|
| bj | Skill | BJ complete workflow | Full VSLs, sales letters |
| bj-critic | Agent | Evaluates BJ copy | After producing BJ copy |
```

**View 3: By Workflow**

Group skills by what you're trying to DO, not by methodology. These workflow groups answer the question "I want to ___":

- Write a sales email
- Write a VSL or sales letter
- Launch a new offer
- Understand my market
- Create content
- Run a webinar
- Analyze my revenue
- Build a new skill or agent
- Onboard a team member
- Run a complete marketing campaign

For each workflow, list the skills in execution order with a brief note on what each contributes.

---

### PHASE 2: WORKFLOW FLOWCHARTS

Create 10 Mermaid flowcharts, one for each common business workflow. Each flowchart shows the skill chain -- which of the USER'S INSTALLED skills to run in what order, with decision points.

**Only include skills the user actually has installed.** If they're missing a skill in the chain, note it as a gap (dashed box).

Use this Mermaid syntax that renders in Obsidian:

```mermaid
graph LR
    A[Start: I want to write a sales email] --> B[/rsf-deep-research/]
    B --> C[/copywriting-arena/]
    C --> D{Winner selected?}
    D -->|Yes| E[/modernize-all/]
    D -->|No| C
    E --> F[/bj-email/]
    F --> G[Deploy to email system]
```

For missing skills in the chain, use dashed style:
```
    X[missing: skill-name]:::gap
    classDef gap stroke-dasharray: 5 5,fill:#333
```

**Phase 2 Constraints:**
- Maximum 12 nodes per flowchart. If a workflow has more steps, group related steps into a single node.
- Each node ID must be unique across the ENTIRE file (use prefixes like `vsl_A`, `offer_A` to avoid collisions).
- If the user has zero skills in a workflow chain, skip that flowchart and note: "You don't have skills for this workflow yet. See recommendations in Phase 4."
- Use `graph LR` for linear workflows, `graph TD` for parallel/branching workflows.

The 10 workflows:

1. **Write a Complete VSL** -- Research > Avatar > Belief Gap > Big Idea > Mechanism > Promise > Arena > Critics > Modernize
2. **Launch a New Offer** -- Research > Avatar > Demand Architect > Offer Factory > Arena > Landing Page > Deploy
3. **Create a Webinar** -- Research > Avatar > Core Concept > Belief Gap > Webinar Arena > Webinar Critics > Slides > Sim Audience
4. **Daily Business Intelligence** -- Morning Standup > Daily Briefing > Analytics > Transcript Audit > Fog Lifter > Action Plan
5. **Deep Market Research** -- Deep Research > Psychographic Excavation > Mimetic Intelligence > Deep Thinkers > Research Synthesis
6. **Build a Framework** -- Framework Forge Mining > Builder > Naming > Productization > Distinction Expander > Microscript Forge
7. **Fix a Revenue Problem** -- Analytics > Theory of Constraints > Steam Era Floorplan > Invisible Tax Detector > Dissolution Engine > Action Plan
8. **Onboard a Client/Employee** -- Client Profile > Employee Intake > File Discovery > Launchpad > Employee System Builder > Operating Standards
9. **Write an Email Sequence** -- Avatar > Belief Gap > Arena > Email Frameworks > Modernize > Deploy
10. **Run a Deep Thinker Analysis** -- Run all field-intelligence skills in parallel > Synthesize > Schwerpunkt Detector > Single Action

---

### PHASE 3: COMPARISON AGAINST RICH'S SYSTEM

Read the reference catalogs bundled with this skill:
- `references/RICHS-SKILLS-CATALOG.md`
- `references/RICHS-AGENTS-CATALOG.md`
- `references/RICHS-WORKFLOW-FLOWCHARTS.md`

Compare the user's installed skills/agents against Rich's full system.

**Phase 3 Constraints:**
- If any reference file is missing, report: "Reference file [name] not found. Skipping comparison for that category." Continue with available files.
- Read RICHS-SKILLS-CATALOG.md by scanning category headers and counts first. Only load full skill details for categories where the user has gaps.
- Do NOT load the full 65KB catalog into context at once.
- Counts must be verified: after scanning, report "Scanned X folders in ~/.claude/skills/, Y folders in ~/.claude/agents/. After excluding Z backups and W team variants: A unique skills, B unique agents."

**Produce three sections in `MY-TOOLKIT-COMPARISON.md`:**

**Section 1: Coverage Summary**

```markdown
## Your System vs Rich's System

| Category | Rich | You | Gap |
|----------|------|-----|-----|
| Copywriting | 120 | 14 | 106 |
| Research | 35 | 3 | 32 |
```

**Section 2: Skills You Have That Aren't In Rich's Catalog**

List any unique skills the user has built themselves. These are interesting -- they show independent capability.

**Section 3: Skills Rich Has That You Don't**

Complete list, organized by category. For each missing skill: name, 1-line description, and why it matters.

---

### PHASE 4: PRIORITY RECOMMENDATION LIST

Based on the comparison, create a priority-ranked list of the **top 20 skills** the user should request next.

**Ranking criteria (scored 1-3 for each, highest total wins):**

| Criterion | 3 (High) | 2 (Med) | 1 (Low) |
|-----------|----------|---------|---------|
| Business Impact | Directly produces revenue output or saves 2+ hrs/week | Improves quality of existing output | Adds capability not currently needed |
| Workflow Gap | Completes a broken workflow chain | Adds depth to a working workflow | Standalone with no workflow chain |
| Foundation | Core skill many others depend on | Useful standalone | Requires 3+ prerequisites first |
| Quick Win | Usable immediately after install | Needs 1 setup step | Needs significant config |

**Phase 4 Constraints:**
- NEVER recommend a skill the user already has installed.
- If the user has fewer than 5 skills, recommend 10 (not 20) -- focus on foundations only.
- If the user has 5-20 skills, recommend 15.
- If the user has 20+, recommend 20.
- Each recommendation must cite which workflow(s) it unlocks or improves.

For each recommended skill, provide:

```markdown
| # | Skill | Cat | Why | Unlocks |
|---|-------|-----|-----|---------|
| 1 | theory-of-constraints | Ops | Finds your #1 bottleneck | Revenue Fix workflow |
| 2 | avatar-excavation | Research | Deep buyer psychology | VSL, Offer, Email workflows |
```

---

### PHASE 5: INTERACTIVE REVIEW

Present the recommendation list to the user and ask:

> "Here are the skills I recommend you request next, in priority order. Review the list and tell me:
> 1. Do you agree with the priority order?
> 2. Are there any you'd remove?
> 3. Are there any from the full gap list you'd add?
> 4. Any you'd move up or down?
>
> We'll finalize this list together, and it will be included in tonight's survey feedback so Rich's team can get these to you by Monday."

**If they agree:** Lock the list.
**If they disagree:** Edit based on their feedback, confirm the revised list, then lock.
**If they say "I don't want any":** Acknowledge, skip Phase 6, and note in output: "User declined all recommendations."
**Maximum 3 revision rounds.** After 3 rounds, lock whatever the current list is.

---

### PHASE 6: SURVEY FEEDBACK OUTPUT

Once the list is finalized, produce `MY-TOOLKIT-REQUEST.md`:

```markdown
# Skill Request -- [User Name]
**Date:** [YYYY-MM-DD]
**Current skills installed:** [count unique]
**Current agents installed:** [count unique]

## Requested Skills (Priority Order)

| # | Skill | Cat | Reason |
|---|-------|-----|--------|
| 1 | [name] | [cat] | [why] |

## Notes
[Any additional context the user provided during the review]

## System Summary
- Total unique skills in Rich's system: 550+
- Total unique agents in Rich's system: 40+
- User's current coverage: [X]%
- After requested skills: [Y]%
```

This file is what gets submitted in the survey feedback.

---

## Completion Checklist

Before declaring the skill complete, verify:
- [ ] MY-TOOLKIT.md exists and contains all 3 views (Alphabetical, Category, Workflow)
- [ ] MY-TOOLKIT-COMPARISON.md exists and contains all 3 sections (Coverage, Unique, Missing)
- [ ] MY-TOOLKIT-REQUEST.md exists (or user explicitly declined all recommendations)
- [ ] All Mermaid blocks use valid syntax (no unclosed brackets, no orphan nodes)
- [ ] Skill and agent counts in output match actual scan results
- [ ] No table requires horizontal scrolling in Obsidian (max 5 columns)

---

## Output Files

All output files are written to the current working directory:
- `MY-TOOLKIT.md` -- Complete inventory (alphabetical + category + workflow views)
- `MY-TOOLKIT-COMPARISON.md` -- Gap analysis against Rich's system
- `MY-TOOLKIT-REQUEST.md` -- Final prioritized skill request list (survey-ready)

## Reference Files (Bundled)

These are Rich's catalogs, bundled with the skill for comparison:
- `references/RICHS-SKILLS-CATALOG.md` -- Rich's 550+ skills by category
- `references/RICHS-AGENTS-CATALOG.md` -- Rich's 40+ agents
- `references/RICHS-WORKFLOW-FLOWCHARTS.md` -- Rich's 10 workflow maps

## Context

The skill reads:
- `~/.claude/skills/` -- all installed skills (scan SKILL.md in each)
- `~/.claude/agents/` -- all installed agents (scan AGENT.md in each)
- Reference files in `references/` subfolder of this skill's location

## Design Principles

- **Three views, one file.** Alphabetical for lookup, category for browsing, workflow for action. All in MY-TOOLKIT.md.
- **Workflow-first thinking.** People think "I want to do X" not "I want to use the Ariely skill." Group by action.
- **Flowcharts show gaps.** When a skill is missing from a workflow chain, show it as a dashed box -- makes the gap visible.
- **The comparison is the upsell.** When participants see the delta between their system and Rich's, they understand what's possible.
- **The request list drives action.** This isn't just informational -- it produces a concrete list that gets fulfilled by Monday.
- **Honest gaps.** If the user is missing something critical, say so clearly. Don't pretend an existing skill covers it.
- **Mermaid must render.** Use valid Mermaid syntax. `graph LR` for linear, `graph TD` for branching. Unique node IDs across the file.
