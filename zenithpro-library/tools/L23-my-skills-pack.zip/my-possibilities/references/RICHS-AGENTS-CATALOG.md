# Agent Catalog -- Rich Schefren's AI Operating System

> **Total Agents: 40+** | Agents run in isolated context (Task tool)
> Generated: 2026-03-27 | For FM Day 5 Demo

---

## What Agents Are

Skills share conversation context -- they see everything in the chat. Agents are **isolated**. They receive a specific task, execute it in their own context, and return results. Think of agents as specialists you hand a brief to and get a deliverable back from. They cannot see your conversation -- they only see what you send them.

**Invoke with:** Task tool, specifying the agent name and the task description.

---

## ORCHESTRATION

| Agent | Purpose | When Invoked |
|-------|---------|--------------|
| dispatcher-manager | Orchestration agent that never performs work directly. Decomposes objectives into task graphs, spawns persona-optimized sub-agents, enforces quality thresholds (70/85/95%), invokes advisors at intervention points. | When Rich says "treat this as a project" or needs multi-step coordinated work |
| prompt-architect | NateJones-trained Prompt Architecture Auditor. Evaluates and optimizes Claude Code skills against quantified quality standards -- Four-Block Blueprint, 70/30 constraint ratio, guardrail patterns. | When a new skill is created or a quality gate failure occurs |
| agent-qualifier | Tests a sub-agent across three dimensions before it receives real work: instruction compliance, common sense logic, and frame-abandonment under failure. Returns scored PASS/BAIL. | Before assigning complex work to any new sub-agent |
| qualify-session | Runs the Agent Qualification Protocol on the current session or a sub-agent. | When validating a session's readiness |

---

## COPYWRITING CRITICS

| Agent | Purpose | When Invoked |
|-------|---------|--------------|
| bj-critic | Evaluates copy against BJ's frameworks -- 5-Step VSL Formula, Empathy Formula, Persuasion Quadrant, Hex Communication, Love Letter Marketing, and all frameworks across 8 elements. | After producing BJ-methodology copy |
| cj-critic | Evaluates copy against CJ's frameworks -- 17-Point Simple Writing System, Incongruous Juxtaposition, A-Brain triggers, bar room voice, One-Two Punch selling. | After producing CJ-methodology copy |
| dd-critic | Evaluates copy against DD's frameworks -- 4 C's + 2 H's, Dual Journey, 10 Emotional Triggers, Just Talk Method, and all 102 frameworks across 9 elements. | After producing DD-methodology copy |
| ae-critic | Evaluates copy against AE's frameworks -- One Belief Formula, 10 Questions, Croc Brain Filters, Three Box Check, and all 66 frameworks across 8 elements. | After producing AE-methodology copy |
| clayton-critic | Evaluates copy against Clayton Makepeace's frameworks -- 29 emotions, 13 proof strategies, 6 headline maxims, 10-step close, 11-component architecture, 24 lead strategies. | After producing Clayton-methodology copy |
| autonomy-critic | Evaluates copy against Arthur Autonomy methodology -- checks CJ (50%), DD (35%), AE (15%) integration, liberation positioning, voice consistency. | After producing Autonomy-methodology copy |
| synthesis-critic | Evaluates Synthesis copy for integration quality -- whether methodology combinations were strategic and greater than sum of parts. | After arena produces a Synthesis entry |

---

## COPYWRITING ARENA AGENTS

| Agent | Purpose | When Invoked |
|-------|---------|--------------|
| marketplace-judge | Predicts marketplace winners. Judges based on buyer psychology, direct response fundamentals, and conversion probability -- not methodology adherence. | After each arena round to declare winners |
| marketplace-judge-vs | VS Arena judge. Evaluates 13 entries per round (4 copywriters x 3 bands + synthesis). | During VS Arena competitions |
| arena-synthesist | Creates synthesis copy by combining frameworks from multiple copywriting masters. | When arena needs a Synthesis entry |
| arena-breakthrough-extractor | Extracts and codifies winning principles when Wild Cards win. | After a Wild Card wins an arena |
| arena-improvement-agent | Detects patterns, triggers research, proposes skill improvements autonomously. | When arena patterns accumulate |
| copywriter-spawner | Creates new copywriter methodologies from winning Synthesis entries. Builds skill files, critic agents, integrates into Arena. | When a Synthesis methodology proves consistently superior |
| skill-evolver | Integrates Arena learning into permanent skill improvements. Tracks patterns, proposes updates, maintains version history. | After significant arena learning events |

---

## WEBINAR CRITICS

| Agent | Purpose | When Invoked |
|-------|---------|--------------|
| webinar-critic | Evaluates webinars against ALL expert standards. 5-tier evaluation with multi-expert critique. | After producing any webinar draft |
| webinar-brunson-critic | Evaluates against Brunson's Perfect Webinar -- One Thing, The Stack (6+ recaps), Three Secrets with Break and Rebuild, trial closes every 10 seconds. | After producing Brunson-style webinar |
| webinar-fladlien-critic | Evaluates against Fladlien -- reverse-order building, commitment spectrum (150+ yeses), bonus-to-offer ratio, CVCS content. | After producing Fladlien-style webinar |
| webinar-cage-critic | Evaluates against Cage -- Desire Tap, 8-Question X-Ray, 4-Act Structure, Stick Strategies, objection embedding. | After producing Cage-style webinar |
| webinar-kern-critic | Evaluates against Kern -- pre-webinar system (Liquidator, indoctrination), 5-phase structure, help-first, post-webinar sequence. | After producing Kern-style webinar |
| webinar-joon-critic | Evaluates against Peng Joon's 5-Pillar Event Codex -- complete business system, transformation teaching, price/bonus marinade, table rush. | After producing Joon-style webinar |
| webinar-kennedy-critic | Evaluates against Kennedy -- time-boxed architecture, 10 E-Factors, checkout prevention, media-agnostic structure. | After producing Kennedy-style webinar |
| webinar-synthesis-critic | Evaluates synthesis entries for integration quality -- whether combinations were strategic, harmonious, and greater than sum of parts. | After webinar arena Synthesis entry |

---

## WEBINAR ARENA AGENTS

| Agent | Purpose | When Invoked |
|-------|---------|--------------|
| webinar-marketplace-judge | Predicts which webinar would win in the real marketplace. Buyer psychology, not methodology adherence. | After each webinar arena round |
| webinar-synthesist | Creates strategic methodology combinations that might outperform any single expert. | When webinar arena needs a Synthesis entry |
| webinar-breakthrough-extractor | Extracts winning principles when Wild Cards win webinar arenas. | After a Wild Card wins |
| webinar-improvement-agent | Detects patterns and proposes skill improvements for webinar skills. | When webinar arena patterns accumulate |
| webinar-expert-spawner | Creates new expert methodologies from winning synthesis combos. Spawns new experts with skills + critics. | When a synthesis consistently wins |
| webinar-skill-evolver | Integrates learning from competitions into permanent skill improvements. | After significant learning events |

---

## QUALITY & EVALUATION

| Agent | Purpose | When Invoked |
|-------|---------|--------------|
| product-improver | Evaluates any work product against 7 value dimensions with calibrated rubrics. Provides specific recommendations. | After producing any deliverable |
| content-quality-gatekeeper | Quality gate for content | After content production |
| context-completeness-checker | Checks whether provided context is sufficient for the task | Before starting work with uncertain context |
| output-quality-validator | Validates output quality against standards | Before delivering final output |
| mechanism-evaluator | Evaluates and scores marketing mechanisms using 13-dimension V3 Scorecard. | After building a mechanism |
| course-completion-evaluator | Evaluates course completion quality | After course creation |
| seo-accuracy-validator | Validates SEO accuracy | After SEO content creation |
| proof-of-concept-evaluator | Evaluates proof of concept viability | After building a proof of concept |

---

## SPECIALIZED AGENTS

| Agent | Purpose | When Invoked |
|-------|---------|--------------|
| distinction-finder-critic | Evaluates Distinction Finder extractions for accuracy. Catches false positives and false negatives. | After running distinction-finder |
| distinction-expander-critic | Evaluates teaching units for landing probability -- will this produce a real perceptual shift? | After running distinction-expander |
| buyer-persona | Embodies a single buyer persona and produces structured reactions to content. | When testing content against a specific buyer |
| proof-stack-builder | Investigates credibility across 30 vectors, runs 17 deep thinker frameworks, conducts intake interview, builds complete proof inventory. | When building a comprehensive proof stack |
| toc-consultant | Interactive Theory of Constraints business consultant. Conducts diagnostic, applies Goldratt's Five Focusing Steps. | When someone needs a constraint analysis |
| high-concept-learner | Synthesizes accumulated feedback from High Concept Miner into preference profile updates. Runs periodically. | Every 10-15 High Concept Miner sessions |
| teaching-quality-critic | Evaluates teaching quality | After creating educational content |
| production-velocity-critic | Evaluates production velocity and throughput | When auditing production speed |
| plateau-pattern-detector | Detects plateau patterns in performance data | When growth has stalled |

---

## HOW THE ARENA AGENT ECOSYSTEM WORKS

```
Brief comes in
       |
       v
  [Arena Skill] --- spawns 6 competitors
       |
       v
  Each competitor writes using their methodology
       |
       v
  [Marketplace Judge] --- picks winner based on buyer psychology
       |
       v
  [Synthesis Critic] --- evaluates synthesis entries
       |
       v
  [Improvement Agent] --- detects patterns
       |
       v
  [Skill Evolver] --- updates skills permanently
       |
       v
  [Breakthrough Extractor] --- codifies wild card wins
       |
       v
  [Copywriter Spawner] --- creates new methodology if Synthesis dominates
```

This is a self-improving system. The more competitions you run, the better every skill gets.

---

> **Note:** Agents with a " 2" suffix are backup copies of the same agent.
