# Skills Catalog -- Rich Schefren's AI Operating System

> **Total Skills: 550+** | Organized by workflow category
> Generated: 2026-03-27 | For FM Day 5 Demo

---

## 1. COPYWRITING

### BJ Methodology (14 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| bj | Complete BJ copywriting workflow -- full VSLs, sales letters, thorough rewrites | End-to-end sales copy projects |
| bj-vsl | BJ's complete VSL formulas -- specialized for Video Sales Letters | Writing a full VSL from scratch |
| bj-headlines | Hook and headline frameworks -- headlines, hooks, subject lines, attention-grabbers | Need a killer headline or hook |
| bj-leads | Lead and opening frameworks -- VSL or sales letter openings, story leads | Writing the opening of any sales piece |
| bj-body | Body copy frameworks -- middle sections of VSLs, proof, mechanism, benefits | Filling in the body of long-form copy |
| bj-close | Close and offer frameworks -- CTAs, guarantees, price presentation, urgency | Writing the close and offer section |
| bj-email | Email and opt-in frameworks -- emails, subject lines, opt-in pages | Writing email campaigns or opt-in sequences |
| bj-bullets | Bullet/fascination frameworks -- bullets for VSLs, sales pages, emails | Cranking out fascination bullets |
| bj-psychology | Psychological persuasion frameworks -- brain psychology, 6-Phase Persuasion, Hex | Applying buyer psychology to copy |
| bj-philosophy | Core philosophy frameworks -- foundational approach, Empathy Formula, Love Letter | Understanding BJ's mindset and principles |
| bj-ideas | Idea generation frameworks -- developing core idea/angle for a promotion | Brainstorming the big idea for a campaign |
| bj-lifts | Lift note and email creative frameworks -- supplementary emails that boost response | Writing lift notes and support emails |

### CJ Methodology (18 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| cj | Complete CJ copywriting workflow -- full sales letters, thorough rewrites | End-to-end sales letter projects |
| cj-sales-letter | Autonomous CJ-methodology sales letter generator | Generating a full sales letter from research |
| cj-headlines | Headline frameworks -- headline templates and formulas | Writing or improving headlines |
| cj-hooks | Hook frameworks -- grabbing attention, positioning your message | Creating hooks for any content |
| cj-leads | Lead frameworks -- opening sections of sales copy | Writing copy openings |
| cj-body | Body copy frameworks -- main body, stories, proof, and flow | Writing the middle of sales letters |
| cj-bullets | Bullet/fascination frameworks -- bullets for sales letters, emails | Writing bullet points and fascinations |
| cj-close | Close frameworks -- closes and calls to action | Writing the close section |
| cj-offers | Offer and guarantee frameworks -- structuring offers, guarantees | Designing the offer and guarantee |
| cj-features-benefits | Feature-to-benefit translation frameworks | Converting features into benefits |
| cj-testimonials | Testimonial frameworks -- writing, gathering, improving testimonials | Working with testimonials |
| cj-turbulence | Turbulence and urgency frameworks -- urgency, scarcity, takeaways | Creating urgency in copy |
| cj-psychology | Buyer psychology frameworks -- A-Brain triggers, zombie states | Applying CJ's buyer psychology |
| cj-research | Market research frameworks -- researching markets, creating avatars | Doing market research CJ-style |
| cj-strategy | Copywriting business frameworks -- business side of copywriting | Strategic copy planning |
| cj-structure | Copy structure frameworks -- planning sales message architecture | Structuring long-form copy |
| cj-voice | Write Like CJ for non-sales contexts -- bar-room storytelling voice | Applying CJ voice to non-sales content |

### DD Methodology (10 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| dd | Complete DD copywriting workflow -- 4 C's + 2 H's, Dual Journey | End-to-end DD copy projects |
| dd-headlines | Headline frameworks | Writing DD-style headlines |
| dd-leads | Lead frameworks -- dual journey starts | Writing copy leads DD-style |
| dd-body | Body copy frameworks -- dual journey, emotional triggers | Body copy with DD's approach |
| dd-bullets | Bullet frameworks -- bullet polishing and fascinations | Writing DD-style bullets |
| dd-close | Close frameworks -- guarantees, offers, final pushes | Writing DD-style closes |
| dd-psychology | Buyer psychology -- emotional triggers, psychological drivers | Applying DD's buyer psychology |
| dd-stories | Story frameworks -- origin stories, testimonials, narratives | Writing stories DD-style |
| dd-strategy | Strategy frameworks -- copy strategy, evaluation | Planning copy strategy |
| dd-process | Process frameworks -- the craft of writing copy | Guidance on writing process |

### AE Methodology (10 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| ae | Complete AE copywriting workflow -- full VSLs, rewrites | End-to-end AE VSL projects |
| ae-headlines | Headline frameworks -- writing, improving, critiquing headlines | Headlines and hooks |
| ae-leads | Lead frameworks -- 10 Questions, VSL openings | Writing VSL openings |
| ae-body | Body copy -- proof, mechanism, benefits in VSLs | VSL body sections |
| ae-bullets | Bullet/fascination frameworks | VSL and sales page bullets |
| ae-close | Close frameworks -- offer presentation, price anchoring | VSL closes |
| ae-ideas | Idea generation -- core idea/angle for a promotion | Developing the big idea |
| ae-lifts | Lift note and email creative frameworks | Supplementary email pieces |
| ae-philosophy | Copywriting philosophy and mindset frameworks | Understanding AE principles |

### Clayton Makepeace Methodology (16 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| clayton | Complete Clayton workflow -- full sales letters, rewrites | End-to-end Clayton copy |
| clayton-headlines | Headline frameworks -- 6 headline maxims | Writing Clayton-style headlines |
| clayton-leads | Lead/opening frameworks -- 24 lead strategies | Writing powerful openings |
| clayton-body-copy | Body copy frameworks -- writing or improving main body | Clayton-style body copy |
| clayton-bullets | Bullet and fascination frameworks | Writing Clayton bullets |
| clayton-closes | Closing frameworks -- 10-step close | Writing Clayton closes |
| clayton-offers | Offer frameworks -- pricing, bonuses, guarantees | Structuring offers |
| clayton-email | Email frameworks -- email campaigns, sequences | Email campaigns |
| clayton-events | Event copywriting frameworks | Writing for live events |
| clayton-proof | Proof and credibility frameworks -- 13 proof strategies | Building credibility |
| clayton-psychology | Buyer psychology -- 29 emotions | Applying buyer psychology |
| clayton-structure | Copy structure frameworks -- 11-component architecture | Organizing sales copy |
| clayton-process | Writing process frameworks | Craft and process guidance |
| clayton-testing | Testing and optimization frameworks | Planning copy tests |
| clayton-business | Copywriting business frameworks | Business side of copy |

### Perry Belcher Methodology (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| perry-belcher | Secret Selling System -- complete methodology | End-to-end Perry approach |
| perry-avatar-profiling | Avatar Profiling -- deep buyer profiles | Profiling your buyer |
| perry-belief-hierarchy | Belief Hierarchy -- mapping belief structures | Mapping prospect beliefs |
| perry-character-building | Character Building and Buddha Positioning | Building authority character |
| perry-offer-architecture | Offer Architecture -- structuring offers | Designing Perry-style offers |
| perry-pitch-structure | Pitch Structure -- presentation flow | Structuring a pitch |
| perry-status-psychology | Status Psychology -- leveraging status | Applying status psychology |
| perry-tripwire-system | Tripwire System -- low-barrier entry offers | Building tripwire funnels |

### Deutsch Methodology (9 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| deutsch-headlines | Deutsch headline frameworks | Headline writing |
| deutsch-leads | Deutsch lead frameworks | Opening sections |
| deutsch-body | Deutsch body copy frameworks | Body copy |
| deutsch-bullets | Deutsch bullet frameworks | Bullet writing |
| deutsch-close | Deutsch close frameworks | Close sections |
| deutsch-psychology | Deutsch buyer psychology | Applying psychology |
| deutsch-stories | Deutsch story frameworks | Story writing |
| deutsch-strategy | Deutsch strategy frameworks | Copy strategy |
| deutsch-process | Deutsch process frameworks | Writing process |

### Evaldo Methodology (8 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| evaldo-headlines | Evaldo headline frameworks | Headline writing |
| evaldo-leads | Evaldo lead frameworks | Opening sections |
| evaldo-body | Evaldo body copy frameworks | Body copy |
| evaldo-bullets | Evaldo bullet frameworks | Bullet writing |
| evaldo-close | Evaldo close frameworks | Close sections |
| evaldo-ideas | Evaldo idea generation | Big idea development |
| evaldo-lifts | Evaldo lift frameworks | Supplementary pieces |
| evaldo-philosophy | Evaldo copywriting philosophy | Mindset and principles |

### Copy Modernizers (4 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| modernize-all | Combined modernizer -- strongest rules from all approaches | Full modernization pass |
| modernize-contrast | Surgical modernizer -- detects and replaces dated DR patterns | Fixing specific dated patterns |
| modernize-current | Modernizes based on what's currently converting at scale | Matching today's market |
| modernize-hormozi | Rewrites in Hormozi's voice -- short declaratives, no adverbs | Hormozi-style rewrite |

### RSF Pipeline (6 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| rsf-big-ideas | Resonant Surprise Framework Big Idea generation | Generating big ideas with FSSIT |
| rsf-deep-research | RSF copywriting market research system | Multi-layer market research |
| rsf-mechanism | RSF-enhanced mechanism development pipeline | Building proprietary mechanisms |
| rsf-promise | RSF-enhanced promise calibration and synthesis | Crafting resonant promises |
| rsf-proof-inventory | RSF proof inventory, analysis, and ranking | Cataloging and scoring proof |
| rsf-root-cause | RSF root cause derivation and expression | Finding the strategic root cause |

### Copywriting Arena System (8 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| copywriting-arena | 6 methodologies compete head-to-head (DD, Clayton, AE, CJ, BJ, Synthesis) | Running competitive copy creation |
| copywriting-arena-vs | Verbalized Sampling Edition | Arena with verbal reasoning |
| copywriting-arena-dashboard | System Health Dashboard | Monitoring arena health |
| copywriting-arena-digest | Weekly Digest Generator | Compiling arena learning |
| copywriting-arena-outcomes | Outcome Tracking System | Tracking real conversion data |
| copywriting-arena-wildcard | Wild Card Methodology Generator | Importing external methods |
| copywriting-arena-runbook-generator | Runbook Generator | Creating arena runbooks |
| arena-live | Live arena competition auto-deployed to Netlify | Live audience-facing arena |

### Arena Support (3 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| arena-autoresearch | Deep pattern analysis across 5+ arena outcomes | Extracting arena patterns |
| arena-deployment-tracker | Tracking deployed arena winners | After deploying winning copy |
| arena-market-intel | Current market intelligence for arena prep | Pre-arena market research |

### Other Copywriting Skills

| Skill | Description | When to Use |
|-------|-------------|-------------|
| autonomy | Arthur Autonomy methodology -- sells liberation, blends CJ/DD/AE | Liberation-positioned copy |
| short-form-copy | Short-Form Copy Mastery for Strategic Profits | Emails, ads, social copy |
| giving-copy-arsenal | Copy that leads with massive value transfer | Value-first copy approach |
| sleight-of-mouth | 14 Sleight of Mouth reframing patterns + NLP | Reframing objections |
| language-engine | Tyrant-Libertarian-Evangelist (TLE) framework | Generating copy variations by voice |
| power-words | A/B testing rig for prompt amplification | Testing prompt word power |
| gumshoe-bigidea | Big Idea database -- analysis skill | Analyzing proven big ideas |
| gumshoe-transformer | Boring ideas transformed to Big Ideas | Making ideas compelling |

---

## 2. MARKETING RESEARCH

| Skill | Description | When to Use |
|-------|-------------|-------------|
| avatar-excavation | Forensic psychological reconstruction of 3-5 avatar segments | Deep buyer profiling |
| aspiration-avatar-excavation | Approach-motivated avatar reconstruction | Profiling aspiration-driven buyers |
| psychographic-excavation | 14-phase deep psychological archaeology of a market | Going beyond demographics |
| aspiration-excavation | 14-phase deep psychology of approach-motivated markets | Mapping passion-driven markets |
| demand-architect | 9-step demand creation pipeline with Girard's mimetic theory | Full demand creation process |
| away-demand-architect | Full pipeline for away-motivated (pain-driven) markets | Pain-driven market demand |
| toward-demand-architect | Full pipeline for toward-motivated (aspiration) markets | Aspiration-driven demand |
| hybrid-demand-architect | Unified ZenithPro demand orchestrator for any market | Any market type |
| demand-desire-mapper | Maps the complete desire hierarchy driving purchase decisions | Understanding what buyers truly want |
| toward-desire-mapper | Aspiration hierarchy in approach-motivated markets | Aspiration desire mapping |
| mimetic-market-intelligence | Girard's mimetic desire theory applied to competitive analysis | What desires are being modeled |
| aspiration-mimetic-intelligence | Mimetic desire in approach-motivated markets | Mimetic desire for aspiration markets |
| belief-gap-analyzer | Maps distance from current beliefs to beliefs needed to buy | Measuring the belief gap |
| identity-belief-gap-analyzer | Maps Point A (doubt) to Point B (confident buyer) | Identity-level belief work |
| belief-installation-orchestrator | Master synthesis engine for multi-step belief installation | Orchestrating belief change |
| ideal-buying-mindset | Forensically defines the mental state where buying is automatic | Defining the target buying state |
| ideal-aspiration-mindset | Defines the psychological state for aspiration-motivated buyers | Aspiration buying state |
| motivation-spectrum-analyzer | Diagnoses toward/away motivation spectrum for any market | Calibrating toward vs away messaging |
| failure-pattern-forensics | Why a market perpetually fails despite trying everything | Understanding recurring market failure |
| progression-pattern-analysis | Maps the progression landscape of approach-motivated markets | Understanding practitioner levels |
| shadow-mining-protocol | Excavates shadow desires beneath stated wants | Finding hidden buyer desires |
| targeting-translator | Translates avatar data into ad targeting specs | Converting research to ad targeting |
| usp-generator | Transmutes features into breakthrough market positioning | Creating a USP |
| toward-usp-generator | USP for approach-motivated markets using identity transformation | Aspiration USP creation |
| core-concept-generator | Generates paradigm-shifting one-sentence reframes | Creating the core concept |
| core-concept-articulation-optimizer | 100+ variations of a core concept statement | Perfecting the core concept phrasing |
| permission-concept-generator | Core Concepts that shift identity permission | When buyers need permission to act |
| mechanism-creator | Creates proprietary mechanisms | Building unique mechanisms |
| mechanism-ideator | Mechanism Ideator v3 | Brainstorming mechanism ideas |
| mechanism-ideator-enhanced | Research Library Integrated mechanism ideation | Research-backed mechanism dev |
| spark-promise-evaluation | Evaluates spark quality of positioning promises | Testing promise tension and specificity |
| proprietary-term-optimizer | Audits and optimizes proprietary terms and coined concepts | Making frameworks stickier |
| toffler-naming-engine | 20+ name variations for offers, frameworks, concepts | Naming things |

---

## 3. DEEP THINKERS (Behavioral Science / Cultural Theory)

### Dan Ariely (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| ariely-field-intelligence | Meta-synthesis of all Ariely skill outputs | Full Ariely analysis |
| ariely-predictability-auditor | Audits for systematic irrationalities in offers/funnels | Finding predictable biases |
| ariely-relativity-engine | How relative comparison shapes value perception | Pricing and positioning |
| ariely-social-norms-detector | Where market norms and social norms collide | Fixing norm mismatches |
| ariely-free-audit | Audits every instance of FREE in a business | Optimizing free offers |
| ariely-honesty-calibrator | Audits for dishonesty and motivated reasoning | Fixing trust gaps |
| ariely-expectation-architect | Designs the expectation architecture of an offer | Setting up expectations |

### Robert Cialdini (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| cialdini-field-intelligence | Meta-synthesis of all Cialdini skill outputs | Full influence audit |
| cialdini-influence-audit | All 7 principles of influence across the journey | Auditing influence levers |
| cialdini-reciprocity-architect | Designs reciprocity structures across the journey | Building give-first systems |
| cialdini-social-proof-optimizer | Optimizes social proof placement and visibility | Improving social proof |
| cialdini-commitment-ladder-designer | Escalating commitment from first touch to full adoption | Designing commitment chains |
| cialdini-pre-suasion-strategist | Pre-suasion environment for each decision point | Pre-framing decisions |
| cialdini-ethical-influence-system-designer | Integration of all 5 Cialdini component skills | Full influence system design |

### Richard Thaler (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| thaler-field-intelligence | Meta-synthesis of all Thaler skill outputs | Full behavioral economics audit |
| thaler-choice-architect | How choices are structured in offers and funnels | Redesigning choice architecture |
| thaler-mental-accounting | How buyers mentally categorize financial decisions | Reframing price perception |
| thaler-nudge-auditor | Audits for nudge opportunities across a funnel | Finding nudge points |
| thaler-default-detector | Detects defaults, status quo, and inertia points | Overcoming inertia |
| thaler-loss-aversion-audit | How loss aversion operates in offers and messaging | Leveraging loss aversion |
| thaler-endowment-mapper | Where the endowment effect operates | Building ownership feeling |

### BJ Fogg (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| fogg-field-intelligence | Meta-synthesis of all Fogg skill outputs | Full behavior design audit |
| fogg-behavior-mapper | Maps B=MAP for every key behavior | Mapping motivation x ability x prompt |
| fogg-ability-auditor | Deep audit of 6 ability factors | Finding ability barriers |
| fogg-motivation-wave-strategist | Maps motivation peaks and troughs | Timing asks to motivation peaks |
| fogg-prompt-designer | Right prompt type per journey point | Designing behavior prompts |
| fogg-tiny-habits-architect | Tiny habit sequences for onboarding/adoption | Building habit loops |
| fogg-behavior-system-designer | Integration of all 5 Fogg component skills | Full behavior system design |

### Kurt Lewin (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| lewin-field-intelligence | Meta-synthesis of all Lewin skill outputs | Full change analysis |
| lewin-force-field-analyzer | Maps driving and restraining forces | Understanding what blocks change |
| lewin-restraining-force-auditor | Deep audit of barriers, frictions, fears | Finding hidden resistance |
| lewin-unfreeze-architect | Designs the unfreezing process | Destabilizing old beliefs |
| lewin-change-sustainability-engineer | Refreezing process that makes change stick | Making new behaviors permanent |
| lewin-group-dynamics-designer | Group structures for community behavior change | Community-driven change |
| lewin-behavior-change-system-designer | Integration of all five Lewin component skills | Full change system design |

### Leon Festinger (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| festinger-field-intelligence | Meta-synthesis of all Festinger skill outputs | Full dissonance analysis |
| festinger-dissonance-detector | Maps cognitive dissonance across the buyer journey | Finding dissonance points |
| festinger-commitment-architect | Commitment escalation across the buyer journey | Designing commitment chains |
| festinger-belief-behavior-sequencer | Should you change beliefs first or behavior first? | Sequencing persuasion strategy |
| festinger-effort-value-auditor | Effort-to-value relationship across the journey | Calibrating effort and reward |
| festinger-post-decision-engineer | Post-decision dissonance management | Reducing buyer's remorse |
| festinger-social-comparison-architect | Social comparison environment in buyer community | Engineering social comparison |

### George Loewenstein (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| loewenstein-field-intelligence | Meta-synthesis of all Loewenstein skill outputs | Full curiosity/emotion audit |
| loewenstein-curiosity-architect | Information gap structures in funnels and content | Building curiosity loops |
| loewenstein-empathy-gap-map | Hot-cold empathy gaps across the journey | Bridging emotional states |
| loewenstein-visceral-audit | Where visceral factors are triggered in a funnel | Mapping visceral triggers |
| loewenstein-information-flow | Information architecture of a complete funnel | Controlling what's revealed when |
| loewenstein-risk-as-feelings | Both risk systems -- cognitive and emotional | Addressing both risk types |
| loewenstein-anticipation-engine | Temporal sequences designed for anticipation | Building anticipation |

### Antonio Damasio (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| damasio-field-intelligence | Meta-synthesis of all Damasio skill outputs | Full emotional architecture audit |
| damasio-somatic-marker-audit | Somatic markers -- bodily-tagged decision shortcuts | Finding gut-reaction triggers |
| damasio-emotion-feeling-mapper | Complete emotional architecture of a buyer journey | Mapping emotional flow |
| damasio-body-loop-auditor | Damasio's two emotion systems in a funnel | Activating body-based signals |
| damasio-ecs-designer | Emotionally Competent Stimulus landscape | Designing emotion triggers |
| damasio-homeostatic-drive-mapper | Homeostatic drives underlying buyer motivation | Connecting to survival drives |
| damasio-autobiographical-self-activator | Three-layer self model in marketing | Activating self-identity |

### Pierre Bourdieu (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| bourdieu-field-intelligence | Master synthesis of all Bourdieu skill outputs | Full cultural capital audit |
| bourdieu-capital-audit | Three forms of capital in a market | Mapping capital landscape |
| bourdieu-distinction-mapper | Taste hierarchies in a market | Understanding status distinctions |
| bourdieu-field-analyzer | Competitive field structure | Mapping market rules |
| bourdieu-habitus-profiler | Internalized dispositions in a target market | Profiling unconscious habits |
| bourdieu-social-capital-mapper | Social capital landscape | Mapping relationship capital |
| bourdieu-symbolic-decoder | Symbolic power structures in a market | Decoding hidden hierarchies |

### Roland Barthes (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| barthes-field-intelligence | Meta-synthesis of all 6 Barthes skill outputs | Full semiotic audit |
| barthes-myth-decoder | Hidden ideology in brand's visible signals | Deconstructing brand myths |
| barthes-myth-construction-strategist | Intentional myth design for your brand | Building brand mythology |
| barthes-connotation-mapper | Connotation layer of every brand element | Mapping hidden meanings |
| barthes-ideology-auditor | Embedded ideologies in offer positioning | Exposing hidden assumptions |
| barthes-punctum-finder | Details that pierce through rational armor | Finding emotional puncture points |
| barthes-signal-archaeology | Origin and cultural weight of brand signals | Understanding signal history |

### Marshall McLuhan (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| mcluhan-field-intelligence | Meta-synthesis of all 6 McLuhan skill outputs | Full media analysis |
| mcluhan-medium-audit | Media/channels and their consciousness effects | Auditing your media mix |
| mcluhan-tetrad-analyzer | Tetrad of Media Effects for your channels | Understanding media tradeoffs |
| mcluhan-hot-cool-strategist | Optimal media sequences by buyer journey stage | Choosing hot vs cool media |
| mcluhan-sensory-ratio-mapper | Which senses are privileged by each channel | Balancing sensory engagement |
| mcluhan-acoustic-vs-visual-auditor | Visual vs acoustic consciousness in marketing | Matching mode to medium |
| mcluhan-global-village-mapper | How your market organizes in the global village | Understanding network effects |

### Thorstein Veblen (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| veblen-field-intelligence | Master synthesis of all 6 Veblen skill outputs | Full status audit |
| veblen-status-intelligence | Complete status hierarchy in a market | Mapping who holds status |
| veblen-signal-decoder | Brand's visible signals and their status story | Reading status signals |
| veblen-display-map | Vicarious display chain in a market | How status flows |
| veblen-emulation-tracker | Imitation flows -- what's being copied, by whom | Tracking mimicry |
| veblen-price-ladder | Pricing as a status device | Status-based pricing |
| veblen-waste-audit | Non-functional excess as status signal | Luxury and waste signals |

### Everett Rogers (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| rogers-field-intelligence | Meta-synthesis of all Rogers skill outputs | Full diffusion analysis |
| rogers-adoption-curve-mapper | Where you sit on the adoption S-curve | Understanding adoption stage |
| rogers-chasm-analyzer | Are you stuck in the chasm? | Diagnosing chasm problems |
| rogers-innovation-attributes-auditor | 5 attributes that determine adoption speed | Improving adoption factors |
| rogers-opinion-leader-mapper | Opinion leaders and change agents | Finding key influencers |
| rogers-communication-channel-strategist | Which channels reach which adopter segments | Channel-segment matching |
| rogers-diffusion-system-designer | Integration of all five Rogers outputs | Full diffusion system design |

### Mark Granovetter (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| granovetter-field-intelligence | Meta-synthesis of all Granovetter skill outputs | Full network analysis |
| granovetter-weak-ties-mapper | Weak tie and bridge structure of a market | Finding bridge connections |
| granovetter-threshold-analyzer | Threshold distribution for adoption/purchase | Tipping point analysis |
| granovetter-cascade-architect | Designs cascade conditions | Engineering viral spread |
| granovetter-embeddedness-auditor | How embedded a business is in its network | Measuring network depth |
| granovetter-network-bridge-strategist | Activating bridge connections | Leveraging weak ties |
| granovetter-spread-system-designer | Integration of all 5 Granovetter outputs | Full spread system design |

### Rene Girard (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| girard-field-intelligence | Master synthesis of all Girard skill outputs | Full mimetic analysis |
| girard-model-map | 15-30 people your prospects model themselves after | Mapping desire models |
| girard-desire-autopsy | Reverse-engineers why something succeeded/failed | Post-mortem on mimetic desire |
| girard-desire-propagation | What desires are spreading through a market | Tracking desire contagion |
| girard-rivalry-detector | Active mimetic rivalries in your market | Finding peer competition |
| girard-scapegoat-radar | Common enemies your market unites against | Identifying shared enemies |
| girard-mimetic-content-strategist | Content strategy built on mimetic desire | Mimetic content planning |

---

## 4. HOLLYWOOD / BUSINESS STRATEGISTS

### Michael Ovitz (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| ovitz-field-intelligence | Meta-synthesis of all 6 Ovitz skill outputs | Full power audit |
| ovitz-packaging-architect | Assembling complete solutions the client controls | Packaging your offering |
| ovitz-perception-engineer | Selective visibility -- what to reveal, what to withhold | Managing market perception |
| ovitz-information-architecture | Information flow strategy -- who knows what, when | Controlling information |
| ovitz-agency-power-mapper | Controlling what both sides need | Mapping agency power |
| ovitz-corporate-bridge | Expertise from one domain deployed in another | Cross-domain leverage |
| ovitz-talent-density-strategist | CAA flywheel -- building talent density | Attracting top talent |

### Ari Emanuel (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| emanuel-field-intelligence | Meta-synthesis of all Emanuel skill outputs | Full empire architecture audit |
| emanuel-empire-architecture | End-state vision when all pieces are in place | Designing the endgame |
| emanuel-acquisition-mapper | Market acquisition targets with synergistic value | Finding acquisition targets |
| emanuel-consolidation-sequencer | Optimal acquisition sequence | Sequencing empire building |
| emanuel-synergy-calculator | Whether combinations create more than sum of parts | Evaluating synergies |
| emanuel-speed-advantage-analyzer | Where speed creates durable advantage | Speed vs integration debt |
| emanuel-moat-auditor | Whether competitors can replicate the position | Testing moat durability |

### Shep Gordon (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| gordon-field-intelligence | The one action satisfying the most outputs | Finding the Shep move |
| gordon-fame-engineer | Fame manufacturing sequence using 7-step method | Manufacturing fame |
| gordon-perception-sequencer | Sequence from 'unknown' to 'authority' | Engineering perception |
| gordon-room-strategist | Who needs to be in what room | Strategic gathering design |
| gordon-category-architect | Category-creation opportunities | Creating a new category |
| gordon-controversy-calculator | Opposition from the right group = validation | Strategic controversy |
| gordon-cross-pollination-mapper | Adjacent industries to recruit from | Cross-industry leverage |

### Bernie Brillstein (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| brillstein-field-intelligence | Meta-synthesis of all Brillstein skill outputs | Full talent-to-production audit |
| brillstein-crossover-architect | Advisory fees to ownership | Moving from advisor to owner |
| brillstein-vehicle-designer | What delivery vehicles to create | Designing vehicles for talent |
| brillstein-talent-pipeline-mapper | Owning the platform AND the talent | Pipeline ownership |
| brillstein-format-inventor | Inventing new show/delivery formats | Creating new formats |
| brillstein-dual-capture-calculator | Earning on both sides of every deal | Double-dipping revenue |
| brillstein-relationship-to-production | Managed people become production partners | Turning relationships into assets |

### Sue Mengers (5 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| mengers-field-intelligence | Meta-synthesis of all 4 Mengers skill outputs | Full social capital audit |
| mengers-social-capital-audit | Existing social capital and proximity value | Mapping relationship wealth |
| mengers-proximity-matcher | Highest-value relationships to cultivate | Finding key relationships |
| mengers-exclusive-access-architect | What to offer, who to include, how to curate | Designing exclusive access |
| mengers-gathering-designer | Events, dinners, communities with engineered positioning | Strategic event design |

### Irving Azoff (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| azoff-field-intelligence | Meta-synthesis of all Azoff skill outputs | Full value chain audit |
| azoff-value-chain-mapper | Management, recording, ticketing, venues, rights | Mapping the value chain |
| azoff-leverage-node-identifier | Control of one point = power over the chain | Finding leverage nodes |
| azoff-integration-sequencer | Optimal order for vertical integration | Sequencing integration |
| azoff-negotiation-position-auditor | Negotiation power at each node | Auditing negotiation leverage |
| azoff-dependency-reversal-designer | Reversing dependencies | Turning weakness to strength |
| azoff-ecosystem-lock-in-analyzer | Whether integration creates real lock-in | Testing ecosystem stickiness |

### Additional Hollywood Strategists

**Lew Wasserman (7 skills)**

| Skill | Description | When to Use |
|-------|-------------|-------------|
| wasserman-field-intelligence | Meta-synthesis of all 6 Wasserman skill outputs | Full deal architecture audit |
| wasserman-deal-architect | Where value is created but not captured | Restructuring revenue |
| wasserman-leverage-mapper | All leverage positions in relationships | Mapping unused leverage |
| wasserman-equity-converter | Fee-for-service to equity/participation | Converting fees to equity |
| wasserman-vertical-power-analyzer | Controlling one node for chain leverage | Vertical integration power |
| wasserman-information-asymmetry-audit | Who knows what -- information as power | Information advantage |
| wasserman-conglomerate-designer | Expanding into adjacent verticals | Building a conglomerate |

**Sandy Gallin (6 skills), Tom Yorn (5 skills), Jason Avant (6 skills), Sandy Lourd (5 skills), Grant DeMann (6 skills), Kevin McCracken (7 skills), Fred Thompson (5 skills), Barabasi (7 skills)** -- each with field-intelligence + specialized component skills for their domain of expertise.

---

## 5. REVENUE & ANALYTICS

| Skill | Description | When to Use |
|-------|-------------|-------------|
| stripe-analytics | Complete Stripe analytics -- daily sales, MRR, balance, comparisons | Checking revenue |
| whop-analytics | Whop analytics -- memberships, payments, customers | Whop platform data |
| trolley-analytics | Trolley (payout) analytics -- payment batches, affiliate payouts | Affiliate payout data |
| keap-analytics | Keap/Infusionsoft CRM data extraction and analysis | CRM and email data |
| finance-financial-statements | Income statements, balance sheets, cash flow (GAAP) | Financial reporting |
| finance-variance-analysis | Financial variance decomposition with narratives | Understanding variances |
| finance-reconciliation | GL vs subledgers, bank statements, third parties | Account reconciliation |
| finance-journal-entry-prep | Journal entries with proper debits/credits | Preparing journal entries |
| finance-close-management | Month-end close with task sequencing | Managing the close |
| finance-audit-support | SOX 404 compliance with control testing | Audit support |
| invoice-organizer | Organizes invoices and receipts for tax prep | Tax prep organization |
| data-data-exploration | Profile and explore datasets | Understanding data |
| data-data-visualization | Python visualizations (matplotlib, seaborn, plotly) | Creating charts |
| data-statistical-analysis | Descriptive stats, trend analysis, outlier detection | Statistical analysis |
| data-sql-queries | SQL across all major warehouse dialects | Writing SQL |
| data-interactive-dashboard-builder | Self-contained HTML dashboards with Chart.js | Building dashboards |
| data-data-validation | QA an analysis before sharing with stakeholders | Validating analysis |
| data-data-context-extractor | Extract tribal knowledge into a data analysis skill | Custom data skill creation |

---

## 6. CONTENT & MEDIA

| Skill | Description | When to Use |
|-------|-------------|-------------|
| content-creator | SEO-optimized marketing content with brand voice | Creating marketing content |
| content-research-writer | High-quality content with research and citations | Research-backed writing |
| content-production | Content Production System | End-to-end content pipeline |
| content-ecosystem-architecture | Map a complete content ecosystem from core beliefs | Content strategy architecture |
| content-repurposing-engine | Repurpose content across formats | Multi-format content |
| pillar-content-architect | "Internet Business Manifesto" style pillar content | Long-form manifesto content |
| signature-talk-architect | Build architecture for a 20-60 minute signature talk | Designing a keynote |
| linkedin-post | LinkedIn posts in Rich Schefren's authentic voice | LinkedIn posting |
| linkedin-lead-magnet | Topic to high-converting LinkedIn lead magnet | LinkedIn lead magnets |
| linkedin-trending-topics | What your LinkedIn audience is discussing now | LinkedIn topic research |
| social-media-poster | Social Media Poster | Posting to social platforms |
| video-downloader | Downloads from YouTube and other platforms | Getting video files |
| video-transcription | Transcribes local video files using MLX Whisper | Transcribing video to text |
| ai-talking-head | AI talking head and lip-sync video generation | Creating AI video |
| rich-avatar | Generate talking-head videos of Rich via HeyGen | Rich Schefren AI video |
| ai-social-graphics | Social media graphics and thumbnails | Creating social images |
| ai-creative-strategist | Research-powered creative strategy with visual previews | Ad creative strategy |
| image-generation | Professional AI images using Google Gemini | Generating images |
| image-enhancer | Improves quality of images, especially screenshots | Enhancing image quality |
| canvas-design | Beautiful visual art in PNG and PDF | Design documents |
| pdf | PDF manipulation -- extract text, create new, edit | PDF work |
| pptx | PowerPoint creation, editing, analysis | PowerPoint work |
| pptx-with-script | PowerPoint with speaker script | Slide decks with scripts |
| docx | Document creation, editing, analysis with tracked changes | Word document work |
| xlsx | Spreadsheet creation, editing, analysis with formulas | Excel/spreadsheet work |
| send-to-speechify | Send files to Speechify for audio playback | Converting text to speech |
| substack-updater | Authenticated Substack newsletter fetcher | Pulling Substack content |
| story-capture | Extracts stories from transcripts to Story Bank | Building the story bank |
| personal-brand-dna-extractor | Extracts brand DNA and creates 8 AI-optimized files | Personal brand extraction |
| brand-guidelines | Applies Anthropic brand colors and typography | Branded artifact styling |
| theme-factory | Styling toolkit for slides, docs, reports | Theming any artifact |
| dark-terminal-landing | Premium dark-mode pages with terminal aesthetic | Hacker-style landing pages |
| slack-gif-creator | Animated GIFs optimized for Slack | Creating Slack GIFs |

---

## 7. OPERATIONS

| Skill | Description | When to Use |
|-------|-------------|-------------|
| morning-standup | Morning Standup System | Daily team standups |
| daily-briefing | Daily intelligence briefing -- all data sources | Rich's daily briefing |
| weekly-briefing | Weekly intelligence briefing aggregating all sources | Weekly summary |
| weekly-business-report | Weekly Business Intelligence Report | Business health report |
| clickup-manager | ClickUp task management for SP workspace | Managing tasks |
| file-organizer | Intelligently organizes files and folders | Organizing files |
| meeting-search | Meeting Transcript Search | Finding meeting content |
| meeting-insights-analyzer | Behavioral patterns, communication styles in meetings | Meeting analysis |
| transcript-audit | Daily transcript audit -- checks every meeting | QA on meeting transcripts |
| transcript-intelligence | Unified transcript extraction -- 3 passes | Deep transcript mining |
| internal-comms | Internal communications templates | Writing internal memos |
| process-inbox | Mark inbox items as processed | Processing captures |
| route-captures | Confirm routing for pending captures | Routing captured items |
| second-brain-orchestrator | Daily digest orchestrator for Second Brain system | Daily brain processing |
| productivity-task-management | Simple task management via TASKS.md | Managing tasks |
| productivity-memory-management | Two-tier memory system for workplace collaboration | Memory management |
| obsidian-markdown | Obsidian Flavored Markdown with wikilinks, embeds | Writing Obsidian notes |
| obsidian-cli | Interact with Obsidian vaults via CLI | Vault operations |
| obsidian-diagram | System architecture diagrams in Mermaid | Creating diagrams |
| obsidian-bases | Obsidian Bases (.base files) with views and filters | Building databases |
| json-canvas | JSON Canvas files with nodes, edges, groups | Visual canvas creation |
| loms-run | Complete LOMS pipeline -- Capture, Analyze, Package, Curate | Look Over My Shoulder pipeline |
| loms-capture | Captures Codex sessions across all projects | Recording sessions |
| loms-analyze | Classifies and analyzes captured LOMS sessions | Analyzing session content |
| loms-package | Transforms analyzed LOMS into student-ready packages | Packaging for students |
| loms-curate | Organizes LOMS into browsable harvest library | Curating LOMS library |
| loms-archive | Archives conversations to Archive-Brain vault | Archiving sessions |

---

## 8. WEBINAR

### Meta-Skill & Arena

| Skill | Description | When to Use |
|-------|-------------|-------------|
| webinar-expert | Synthesizes 6 webinar experts into best-of-all approach | End-to-end webinar creation |
| webinar-arena | 6 expert methodologies compete head-to-head | Competitive webinar creation |
| webinar-arena-dashboard | System Health Dashboard | Monitoring arena health |
| webinar-arena-digest | Weekly Digest Generator | Compiling weekly learning |
| webinar-arena-outcomes | Outcome Tracking System | Tracking webinar results |
| webinar-arena-wildcard | Wild Card Methodology Generator | Importing external methods |
| sim-webinar-chat | Simulated webinar chat | Testing webinar engagement |
| sim-audience | Simulated audience reactions | Testing audience response |
| sim-audience-blind | Blind simulated audience test | Unbiased audience testing |

### Jason Fladlien (8 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| webinar-fladlien | Complete One-to-Many methodology orchestrator | Full Fladlien webinar |
| webinar-fladlien-architecture | Architecture frameworks | Webinar structure |
| webinar-fladlien-intro | Introduction frameworks | Webinar openings |
| webinar-fladlien-content | Content frameworks -- CVCS structure | Teaching sections |
| webinar-fladlien-transition | Transition frameworks | Teaching to selling bridge |
| webinar-fladlien-close | Close frameworks | Webinar closes |
| webinar-fladlien-delivery | Presentation craft frameworks | Delivery polish |
| webinar-fladlien-funnel | Funnel frameworks | Before/after webinar |

### Michael Cage (5 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| webinar-cage | Teleseminar System methodology orchestrator | Full Cage webinar |
| webinar-cage-foundation | Desire Tap philosophy, 8-Question X-Ray | Research layer |
| webinar-cage-positioning | Title Alchemy, Authority Architecture | Positioning layer |
| webinar-cage-architecture | 4-Act Structure, Stick Strategies | Structure layer |
| webinar-cage-conversion | Objection Anticipation, Close Architecture | Conversion layer |

### Russell Brunson (7 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| webinar-brunson | Complete Perfect Webinar methodology | Full Brunson webinar |
| webinar-brunson-architecture | Architecture frameworks | Overall structure |
| webinar-brunson-intro | Introduction frameworks | Webinar openings |
| webinar-brunson-content | Content frameworks -- Three Secrets | Teaching sections |
| webinar-brunson-transition | Transition frameworks | Teaching to selling |
| webinar-brunson-close | Close frameworks -- The Stack | Webinar closes |
| webinar-brunson-delivery | Delivery and presentation craft | Delivery polish |

### Frank Kern (9 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| webinar-kern | Ultimate Webinar Blueprint methodology | Full Kern webinar |
| webinar-kern-architecture | Architecture frameworks | Overall structure |
| webinar-kern-intro | Introduction frameworks | Webinar openings |
| webinar-kern-content | Content -- BOND and teaching sections | Teaching sections |
| webinar-kern-transition | Transition frameworks | Teaching to selling |
| webinar-kern-close | Close frameworks | Webinar closes |
| webinar-kern-delivery | Delivery -- Hybrid Method | Recording and delivery |
| webinar-kern-funnel | Pre-webinar funnel frameworks | Pre-webinar optimization |
| webinar-kern-followup | Post-webinar follow-up (80%+ of revenue) | Follow-up sequences |

### Peng Joon (8 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| webinar-joon | Complete Event Codex methodology | Full Peng Joon event |
| webinar-joon-intro | Introduction frameworks | Event openings |
| webinar-joon-content | Content frameworks | Teaching sections |
| webinar-joon-transition | Transition frameworks | Teaching to selling |
| webinar-joon-close | Close frameworks -- table rush | Event closes |
| webinar-joon-delivery | Delivery frameworks | Show-up and energy |
| webinar-joon-funnel | Funnel frameworks -- Facebook ads, tickets | Selling event tickets |
| webinar-joon-leverage | Leverage frameworks -- maximize event ROI | Funnel economics |

### Dan Kennedy (8 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| webinar-kennedy | Complete "Selling One To Many" methodology | Full Kennedy presentation |
| webinar-kennedy-architecture | Architecture frameworks | Overall structure |
| webinar-kennedy-intro | Open section frameworks | Presentation openings |
| webinar-kennedy-content | Middle section frameworks | Content sections |
| webinar-kennedy-transition | Transition frameworks | Content to commercial |
| webinar-kennedy-close | Close section frameworks | Presentation closes |
| webinar-kennedy-delivery | Physical room tactics, video production | Delivery and room |
| webinar-kennedy-infrastructure | Kennedy + Kern campaign infrastructure | Full campaign system |

---

## 9. OFFER DESIGN

| Skill | Description | When to Use |
|-------|-------------|-------------|
| offer-factory-engine | Offer Factory: Offer Engine | Creating new offers |
| offer-factory-architect | Offer Factory: Offer Architect | Designing offer architecture |
| offer-factory-decomposer | Offer Factory: Product Decomposer | Breaking products into components |
| offer-factory-expander | Offer Factory: Concept Expander | Expanding offer concepts |
| offer-factory-deepener | Offer Factory: Offer Deepener | Adding depth to offers |
| offer-factory-ecosystem | Offer Factory: Offer Ecosystem Designer | Multi-offer ecosystems |
| offer-factory-synthesizer | Offer Factory: Cross-Product Synthesizer | Combining products |
| offer-factory-autopsy | Offer Factory: Offer Autopsy | Diagnosing offer failures |
| offer-optimizer | Active Offer Optimizer | Optimizing live offers |
| product-enhancement-engine | Product Enhancement Engine | Improving existing products |
| product-manager-toolkit | RICE prioritization, customer interviews, sprint planning | Product management |
| product-strategist | OKR cascade, strategic leadership toolkit | Strategic product decisions |
| product-registry | Single source of truth for product components | Product inventory |
| product-improver | Evaluates work products against 7 value dimensions | Improving any deliverable |
| course-factory | Production-grade AI course creator from YouTube research | Building courses |
| guru | AI Course Creator -- YouTube research to deployed course | Course creation |
| revenue-diagnosis-engine | Pre-call revenue diagnosis for service providers | Diagnosing revenue problems |
| lead-capture-activation | Discovers warm audience not being captured | Finding hidden leads |
| lead-research-assistant | Identifies high-quality leads | Lead generation |

---

## 10. INTELLIGENCE

| Skill | Description | When to Use |
|-------|-------------|-------------|
| deep-research | Multi-source orchestrator -- 9 API sources | Comprehensive research |
| claude-deep-research | Codex's native Deep Research feature | Deep research from Codex |
| fog-lifter | Fuses data from every connected business system | Clearing business fog |
| eyes-on-every-street | Continuous ambient awareness across all systems | Always-on monitoring |
| intelligence-engine | Intelligence Engine | Core intelligence system |
| screenpipe-assistant | On-demand Screenpipe intelligence | Screen activity analysis |
| limitless-intelligence | Limitless AI pendant intelligence | Pendant recording insights |
| research-synthesis | Synthesizes research from multiple sources | Unifying research |
| search-knowledge-synthesis | Combines search results into coherent answers | Knowledge synthesis |
| search-search-strategy | Query decomposition and multi-source orchestration | Search planning |
| search-source-management | Manages connected MCP sources for search | Source management |
| vault-search | Semantic search across Obsidian vaults (GPU-accelerated) | Finding vault content |
| perplexity-intel-sync | Perplexity intelligence synchronization | External intel |
| defuddle | Extract clean markdown from web pages | Web content extraction |
| expert-content-processor | Transforms raw expert content into organized knowledge | Processing expert material |
| expert-knowledge-extractor | Extracts knowledge from expert sources | Knowledge extraction |
| expert-summarizer | Comprehensive summaries from organized expert content | Summarizing experts |
| expert-application-mapper | Maps expert frameworks to a specific program | Applying expertise |
| source-to-skill-processor | Processes raw sources into skill-ready extractions | Building skills from content |

---

## 11. STRATEGIC THINKING & BUSINESS DIAGNOSTICS

| Skill | Description | When to Use |
|-------|-------------|-------------|
| theory-of-constraints | Goldratt's TOC to identify and eliminate bottlenecks | Finding the constraint |
| schwerpunkt-detector | Traces causal chains to find the single decisive action | Finding the one thing |
| pattern-which-connects | Cross-matches all systems to find the structural pattern | Finding the meta-pattern |
| paradigm-mirror | Behavioral archaeology to extract actual operating paradigm | Revealing hidden assumptions |
| self-deception-audit | Extracts stated beliefs and tests them against reality | Catching self-deception |
| say-do-gap-tracker | What leaders say vs what actually happens | Measuring follow-through |
| real-business-detector | Reveals what the business actually IS from data | Seeing the real business |
| steam-era-floorplan | Maps how work actually flows across all systems | Mapping real workflows |
| dissolution-engine | Traces 5 chronic problems to their structural generators | Dissolving recurring problems |
| turkey-detector | Scans for things that look stable while becoming fragile | Black swan detection |
| butterfly-effect-scanner | Compares repeatable interactions for tiny leverage points | Finding small changes = big results |
| delay-detector | Measures time lag between action and observed result | Finding hidden delays |
| invisible-tax-detector | Transaction Cost P&L -- friction costs | Quantifying hidden costs |
| red-bead-simulator | Cross-references assignments vs outcomes for system blame | Is it the person or the system? |
| system-2-override | Scans decisions for cognitive bias signatures | Catching biased decisions |
| counterintuitive-advisor | Models second, third, and delayed-order effects | Thinking beyond first order |
| activity-system-audit | Maps every significant activity from observed data | Full activity audit |
| role-mind-fit | Detects whether each person is in the right role | Role-person fit analysis |
| capacity-unlock-interview | How much founder workload is manual/sequential | Finding automation opportunities |
| constraint-portfolio | Ranks products by revenue-per-founder-hour | Portfolio optimization |
| constraint-optimized-portfolio | Measures actual founder-hours consumed | Founder time allocation |
| combinatorial-evolution | Inventories capabilities and maps novel combinations | Finding new combinations |
| founders-compass | Vision extraction, mission calibration, weekly memos | Founder alignment |
| founders-radar | Attention allocation -- who to talk to and what about | Where to focus |
| decision-intelligence-brief | Decision intelligence briefing | Major decision support |
| integration-inflection-detector | Diagnoses strategic inflection points | Recognizing the turning point |
| integration-founder-evolution | When the founder must evolve for growth | Founder development |
| integration-system-conflict | When multiple systems fight each other | System conflict diagnosis |
| integration-antifragile-redesign | Redesigns systems to gain from disorder | Building antifragility |
| integration-convergence-radar | Synthesizes signals across all domains | Convergence detection |
| integration-movement-architect | Designs self-propagating movement systems | Movement building |

---

## 12. BUILDING & DEVELOPMENT

| Skill | Description | When to Use |
|-------|-------------|-------------|
| skill-creator | Guide for creating effective skills | Building new skills |
| sp-skill-creator | Guide for creating skills (SP version) | SP team skill creation |
| strategic-builder | Complete project lifecycle -- setup, build, test, audit | Full project builds |
| sp-strategic-builder | Complete project lifecycle (SP version) | SP team projects |
| code-quality | Code quality enforcement for all code | Code review and enforcement |
| mcp-builder | Guide for creating MCP servers | Building MCP integrations |
| skill-pressure-test | Tests whether a skill works under pressure | Validating new skills |
| qualify-session | Runs Agent Qualification Protocol | Testing sub-agents |
| quality-gate | Automatic content quality evaluation | QA on any content |
| frontend-design | Production-grade frontend interfaces | Building UIs |
| ui-design-system | Design tokens, component systems | Design system creation |
| ux-researcher-designer | UX research and design toolkit | UX work |
| webapp-testing | Testing local web apps with Playwright | Testing web apps |
| playwright-skill | Complete browser automation with Playwright | Browser automation |
| browser-use | Browser interactions for testing, form filling | Browser tasks |
| algorithmic-art | Algorithmic art using p5.js | Creating generative art |
| student-package-builder | Packages skills into student-ready distributions | Distributing to students |
| open-claude-desktop | Opens new Codex Desktop instances | Launching Codex Desktop |
| ai-time-estimator | Prevents inflated time estimates | Accurate time estimation |
| command-center | Personalized command center connecting services | Building dashboards |
| brain-run | On-Demand Intelligence Pipeline + Dashboard Build | Intelligence dashboards |

---

## 13. INTEGRATIONS

| Skill | Description | When to Use |
|-------|-------------|-------------|
| cloudflare | Deploy to Cloudflare Pages with custom domains | Website deployment |
| wordpress-manager | Manage richschefren.com via AI Engine MCP | WordPress content |
| wordpress-admin | WordPress admin automation via browser | WordPress admin tasks |
| google-drive | Browse, search, read Google Drive files via MCP | Accessing Google Drive |
| fireflies-downloader | Downloads meeting transcripts from Fireflies AI | Getting Fireflies transcripts |
| read-ai-downloader | Downloads meeting reports from Read AI | Getting Read AI reports |
| limitless-downloader | Downloads transcripts from Limitless AI | Getting Limitless recordings |
| imessage | iMessage intelligence via SQLite | Reading iMessage data |
| skool-downloader | Downloads entire Skool.com classrooms to Markdown | Downloading Skool content |
| manus-offload | Task dispatch to Manus AI for long-running work | Offloading to Manus |
| telegram-command-center | Telegram command center | Telegram integration |
| seo-content-system | SEO content system | SEO optimization |
| zenithpro-landing-page-builder | Converts copy documents to production-ready HTML | Building landing pages |
| zenithpro-qa-processor | Processes ZenithPro Q&A call transcripts | Processing Q&A calls |

---

## 14. FM-SPECIFIC & SP TEAM SKILLS

| Skill | Description | When to Use |
|-------|-------------|-------------|
| fm-employee-system-builder | Force Multiplier employee system builder | Owner builds employee system post-intake |
| sp-fm-employee-system-builder | SP version of FM employee system builder | SP team FM delivery |
| sp-employee-intake | Structured employee intake interview | Employee onboarding interview |
| sp-client-profile-interview | 20-30 minute client profile interview | New client onboarding |
| sp-file-discovery | Guided file discovery for client vault population | Client file setup |
| sp-diagnostic | Diagnose SP-Shared setup issues | Troubleshooting SP setup |
| sp-launchpad | Platform Connection Installer | Connecting client platforms |
| sp-key-setup | Set up Infisical CLI for team secrets | Team secret management |
| sp-refresh | Sync Shared Skills and Resources | Updating shared skills |
| sp-deep-research | Multi-source deep research (SP version) | SP team research |
| sp-ai-time-estimator | Accurate AI time estimates (SP version) | SP team time estimates |
| sp-image-generation | AI images via Gemini (SP version) | SP team image generation |
| sp-video-downloader | Video downloads (SP version) | SP team video downloads |
| sp-video-transcription | Video transcription (SP version) | SP team transcription |
| sp-pdf | PDF toolkit (SP version) | SP team PDF work |
| sp-pptx | PowerPoint (SP version) | SP team presentations |
| sp-docx | Document (SP version) | SP team documents |
| sp-xlsx | Spreadsheet (SP version) | SP team spreadsheets |
| owners-operating-standards | Complete expertise extraction for quality judgment | Building quality standards |

---

## 15. THOUGHT LEADERSHIP & BRAND

| Skill | Description | When to Use |
|-------|-------------|-------------|
| thoughtpreneur | Complete thought leadership practice system ($500K-$1.5M) | Building a practice |
| thoughtpreneur-genius | Unique Genius Discovery System | Discovering your genius |
| thoughtpreneur-positioning | 9-Box Positioning Matrix builder | Market positioning |
| thoughtpreneur-52-points | 52 Points of Distinction generator | Intellectual property map |
| thoughtpreneur-cluster | 90-Day Cluster Campaign planner | Quarterly execution plan |
| thoughtpreneur-green-sheet | Sales conversation framework | Sales conversations |
| thoughtpreneur-mode | Delivery mode selection | Choosing delivery method |
| thoughtpreneur-practice | Practice architecture builder | Practice design |
| distinction-finder | Extracts raw distinctions from content | Finding distinctions |
| distinction-expander | Builds teaching units from raw distinctions | Expanding distinctions |
| distinction-pipeline | End-to-end distinction pipeline (Find to Expand) | Full distinction creation |
| distinction-reference-builder | Builds distinction reference library | Reference library |
| microscript-forge | Generates 10 ranked microscripts from a distinction | Creating sound bites |
| framework-forge | Orchestrates complete framework creation | Building frameworks |
| framework-forge-mining | Identifies framework opportunities in content | Mining for frameworks |
| framework-forge-builder | Constructs Pink Sheet frameworks | Framework construction |
| framework-forge-naming | Generates and tests framework names | Naming frameworks |
| framework-forge-productization | Sullivan Productization Package | Productizing frameworks |
| character-empire-generator | Complete character empire blueprint | Building a character brand |
| five-layer-invisible-influence | 5-layer invisible influence model | Embedding deep influence |
| creative-generator-spark | Ad creative concepts using invisible influence | Influence-based ad creatives |
| high-concept-miner | High Concept Miner | Mining high concepts |

---

## 16. SALES & SUPPORT

| Skill | Description | When to Use |
|-------|-------------|-------------|
| sales-account-research | Company/person research for actionable sales intel | Pre-sale research |
| sales-call-prep | Account context, attendee research, suggested agenda | Preparing for sales calls |
| sales-competitive-intelligence | Competitive battlecard builder | Competitive intelligence |
| sales-create-an-asset | Tailored sales assets (landing pages, decks) | Sales collateral |
| sales-daily-briefing | Prioritized sales briefing | Daily sales readiness |
| sales-draft-outreach | Research prospect + draft personalized outreach | Writing outreach |
| support-ticket-triage | Categorize, assign priority (P1-P4) | Triaging tickets |
| support-response-drafting | Professional customer-facing responses | Writing support replies |
| support-customer-research | Search across docs and knowledge bases | Researching customer issues |
| support-escalation | Package escalations for engineering/product | Escalating issues |
| support-knowledge-management | Knowledge base articles from resolved issues | Building KB articles |
| legal-contract-review | Review against negotiation playbook | Contract review |
| legal-risk-assessment | Severity-by-likelihood risk framework | Risk assessment |
| legal-compliance | GDPR, CCPA, DPA review | Privacy compliance |
| legal-nda-triage | Screen NDAs -- GREEN/YELLOW/RED | NDA classification |
| legal-meeting-briefing | Structured briefings for legal meetings | Legal meeting prep |
| legal-canned-responses | Templates for common legal inquiries | Legal response templates |

---

## ZenithPro Unified Skills (12 skills)

| Skill | Description | When to Use |
|-------|-------------|-------------|
| zp-avatar | Unified avatar excavation for any market type | ZenithPro avatar work |
| zp-excavation | Unified 14-phase psychographic excavation | ZenithPro market excavation |
| zp-demand-architect | Unified demand creation orchestrator | ZenithPro demand creation |
| zp-desire-mapper | Unified desire mapping for any market | ZenithPro desire mapping |
| zp-mimetic | Unified mimetic market intelligence | ZenithPro mimetic analysis |
| zp-belief-gap | Unified belief gap analyzer | ZenithPro belief gaps |
| zp-buying-state | Unified buying state definition | ZenithPro buying state |
| zp-concept-generator | Unified Core Concept generator | ZenithPro core concepts |
| zp-community | Unified community architecture | ZenithPro community design |
| zp-usp | Unified USP generator | ZenithPro USP creation |
| zp-pattern-analyzer | Unified pattern analysis (failure forensics + progression) | ZenithPro pattern analysis |

---

> **Note:** Skills with a " 2" suffix are backup copies. "sp-" prefixed skills are student/team-portable versions of the corresponding skill.
