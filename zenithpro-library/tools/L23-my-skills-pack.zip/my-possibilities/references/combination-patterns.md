# Combination Pattern Library

Use these 6 combination types when analyzing a user's installed skills. Each type creates a different kind of emergent capability.

## Type 1: Pipeline Combinations

Skills that chain sequentially -- the output of one feeds the input of the next, creating an end-to-end workflow that's greater than any individual step.

**Signal:** Skills where one produces research/analysis and another consumes it to create something.

**Examples:**
- `avatar-excavation` > `belief-gap-analyzer` > `core-concept-generator` = **Belief-to-Concept Pipeline** -- takes raw market psychology and converts it to a positioning concept in one flow
- `deep-research` > `psychographic-excavation` > `rsf-big-ideas` > `copywriting-arena` = **Research-to-Copy Engine** -- from market question to tested sales copy without stopping
- `distinction-finder` > `distinction-expander` > `microscript-forge` = **Distinction-to-Message Pipeline** -- raw insight to deployable marketing language

**What makes it powerful:** Removes the manual handoff between steps. The user gets a complete output where they used to get fragmented pieces they had to assemble themselves.

---

## Type 2: Cross-Domain Fusions

Skills from different categories that create an entirely new capability when combined.

**Signal:** Skills from 2+ different category groups that address the same business problem from different angles.

**Examples:**
- `theory-of-constraints` + `offer-factory-architect` = **Constraint-Based Offer Design** -- designs offers specifically around removing the customer's #1 bottleneck
- `capacity-unlock-interview` + `fm-employee-system-builder` + `owners-operating-standards` = **Team Transformation System** -- diagnoses waste, builds delegation, sets quality standards
- `steam-era-floorplan` + `content-ecosystem-architecture` = **Content-Operations Optimizer** -- maps actual content workflows against ideal architecture

**What makes it powerful:** Creates a capability that doesn't exist in any single skill category. The fusion is the innovation.

---

## Type 3: Intelligence Amplifiers

Research/analysis skills that supercharge creation skills by providing deeper input.

**Signal:** Any deep thinker or research skill combined with any creation skill (copy, offer, content, webinar).

**Examples:**
- `cialdini-influence-audit` + `offer-factory-architect` = **Psychologically Optimized Offer Design** -- builds offers with influence principles baked in from the start, not bolted on after
- `ariely-predictability-auditor` + `thaler-choice-architect` + `offer-factory-deepener` = **Behavioral Economics Offer Engine** -- designs pricing and offer structure based on how humans actually decide
- `girard-model-map` + `avatar-excavation` + `copywriting-arena` = **Mimetic Copy Engine** -- writes copy that activates imitative desire, not just rational benefit

**What makes it powerful:** The creation skill works with surface-level inputs by default. The intelligence skill gives it deep inputs. Same skill, dramatically better output.

---

## Type 4: Diagnostic-to-Action Chains

Analysis skills combined with builder skills -- finds the problem AND builds the fix.

**Signal:** Any audit/analysis/detective skill paired with a builder/architect/designer skill.

**Examples:**
- `dissolution-engine` + `strategic-builder` = **Root Cause Eliminator** -- traces chronic problems to structural causes, then builds the fix
- `invisible-tax-detector` + `fm-employee-system-builder` = **Efficiency Architect** -- finds hidden costs in human workflows, then redesigns the team system to eliminate them
- `self-deception-audit` + `integration-founder-evolution` = **Founder Breakthrough System** -- surfaces the beliefs holding the business back, then designs the owner's evolution path

**What makes it powerful:** Diagnosis without action is frustrating. Action without diagnosis is guessing. The chain gives you both.

---

## Type 5: Competitive Intelligence Systems

Skills that combine to give the user an information advantage competitors don't have.

**Signal:** Multiple research/intelligence skills from different angles focused on the same market.

**Examples:**
- `mktg-competitive-analysis` + `girard-rivalry-detector` + `usp-generator` = **Competitive Positioning Engine** -- maps what competitors are doing, detects what desires they're fighting over, then positions you outside that fight
- `barabasi-hub-mapper` + `granovetter-weak-ties-mapper` + `avant-door-mapper` = **Network Power Map** -- reveals who controls your market's information flow and how to access them
- `veblen-status-intelligence` + `bourdieu-distinction-mapper` + `mccracken-meaning-flow-mapper` = **Cultural Position Intelligence** -- maps the complete status, taste, and meaning landscape of your market

**What makes it powerful:** Combines multiple theoretical lenses on the same market. What one misses, another catches. The synthesis reveals what no single perspective could.

---

## Type 6: Force Multiplier Engines

Combinations that let one person do what normally requires a team -- the true Force Multiplier promise.

**Signal:** Skills that automate research + creation + quality control in a single workflow.

**Examples:**
- `deep-research` + `avatar-excavation` + `copywriting-arena` + critics (agents) = **One-Person Marketing Department** -- researches the market, builds the avatar, writes competing copy, evaluates it, picks the winner
- `expert-content-processor` + `course-factory` + `pptx` = **Course Production Line** -- takes raw expert content and produces a complete digital course with slides
- `webinar-arena` + webinar critics + `sim-audience` = **Webinar Creation Machine** -- generates competing webinars from multiple methodologies, evaluates them, simulates audience response

**What makes it powerful:** This is the "hours back in your week" promise. These combinations replace entire workflows that currently require multiple people or days of manual work.

---

## Scoring Combinations

Rate each combination on three dimensions (1-10 each):

**Power** -- How transformative is the output? Does it create something genuinely new or just save steps?
- 10 = Creates an entirely new capability that didn't exist before
- 7 = Dramatically improves an existing capability
- 4 = Moderate improvement / convenience
- 1 = Marginal benefit

**Potency** -- How immediately actionable is the output? Can the user deploy it today?
- 10 = Produces deployment-ready output (copy, offers, systems)
- 7 = Produces strategic direction that can be acted on this week
- 4 = Produces insight that needs further work to become actionable
- 1 = Produces theoretical understanding only

**Effectiveness** -- How much time/money/effort does this save vs. doing it manually?
- 10 = Replaces weeks of work or an entire team function
- 7 = Replaces days of work or a specialist hire
- 4 = Saves hours of work
- 1 = Marginal time savings

**Composite Score** = (Power + Potency + Effectiveness) / 3, rounded to 1 decimal.

Rank all 30 combinations by composite score, highest first.
