<!-- my-roadmap v1.1 â Prompt Architecture Audit applied 2026-03-27 -->

# My Roadmap

**Purpose:** Reads participant context files (dossier, commitment, progress, transcripts, feedback), performs gap analysis against stated commitments, and produces a structured daily action plan with dependencies, time estimates, and executable commands. Outputs: `ROADMAP-OUTPUT.md` + `ROADMAP-OUTPUT.html`.

**Customization note:** HTML color scheme, typography, and component styles are defined in the HTML Design Spec section below. Override any value there to match a program's brand.

## How to use

```
/my-roadmap
```

Run this from the folder that contains your context files (business dossier, commitment, progress notes, session transcripts, feedback). Or pass a folder path:

```
/my-roadmap ~/Obsidian/my-vault/Force-Multiplier/
```

---

## Scope Boundaries

This skill produces a PLAN, not the work itself. It tells you what to build, in what order, with what tools.

**This skill does NOT:**
- Write copy, emails, or sales pages
- Build skills or systems
- Conduct market research
- Deploy anything to production

**Exception:** Phase 5 (Build It Now) offers optional execution of the plan's priorities after the roadmap is delivered and the user explicitly opts in.

---

## Dependencies & References

**Skills referenced in examples (may or may not be installed):**
- `/copywriting-arena` -- competitive copywriting engine
- `/demand-architect` -- demand creation pipeline
- `/revenue-diagnosis-engine` -- sales call analysis
- `/sp-strategic-builder` or `/strategic-builder` -- project lifecycle methodology

**Phase 5 dependency:** If the user opts into execution, Phase 5 attempts to use `/sp-strategic-builder` (or `/strategic-builder`). See Phase 5 for fallback behavior.

**Environment assumptions:**
- Context files are Markdown (`.md`) in a single folder
- Output is written to the same folder
- The person running this may be a program participant, not Rich -- do not assume vault paths or installed skills beyond what is discoverable

---

## Data Integrity Rule

**NEVER invent data not present in the context files.**

- If the dossier does not mention email list size, say "email list (size not provided -- verify)."
- If no revenue number exists, say "revenue not specified."
- If team size is not stated, say "team size unknown."
- If a metric, number, or fact is not in the source files, do not fabricate it. State what is missing and mark it for the participant to verify.

This applies to every phase. No exceptions.

---

## Context File Discovery

Scan the current working directory (or the provided path) for these files. Use flexible matching -- filenames may vary slightly between participants.

**Required files (skill cannot run without these):**
- `business-dossier.md` -- who they are, what they sell, team, revenue, priorities
- `day1-commitment.md` -- what success looks like in their own words

**Optional but high-value files:**
- `progress-notes.md` -- what they've built so far, what's working/broken
- `session-*.md` -- session transcripts (Day 1, Day 2, Day 3-4, etc.)
- `qa-*.md` -- Q&A session transcripts
- `feedback-quotes.md` or `feedback*.md` -- participant feedback, survey responses
- `employee-intake*.md` -- employee intake transcripts (for team builds)
- `toolkit-output*.md` -- previous My Toolkit output to cross-reference

If a required file is missing, STOP and tell the user exactly which file is needed and what it should contain. Do not generate a roadmap on incomplete data.

If optional files are missing, proceed but note what's missing and how the roadmap would improve with that data. For example: "No session transcripts found. The roadmap will be based on your dossier and commitment only. Adding session transcripts would allow me to extract specific frameworks and advice relevant to your business."

---

## Instructions

Read every `.md` file in the context folder. Then execute ALL of the following phases in order. Do not skip phases. Do not summarize -- be specific.

---

### PHASE 1: INTELLIGENCE GATHERING

**Step 1 -- Situational Awareness**

Summarize in 3-4 sentences: Who is this person? What does their business do? What's their current revenue? What phase of AI adoption are they in? How big is their team? Be specific -- use numbers, names, and details from the dossier. No generic language.

**NEVER constraints for Situational Awareness (apply to ALL output in ALL phases):**
- NEVER use "your business" -- use the actual business name from the dossier.
- NEVER use "your niche" or "your market" -- name the actual market (e.g., "the executive coaching market" or "B2B SaaS for dental practices").
- NEVER use "your audience" -- describe the actual segment (e.g., "the 3,200 email subscribers" or "agency owners doing $500K-$2M").
- NEVER use "various," "multiple," or "several" without a count -- say "3 revenue streams" or "2 team members," not "multiple streams" or "several employees."

These constraints apply to every sentence in every phase of the roadmap.

**Step 2 -- Commitment Gap Analysis**

Create a table comparing their Day 1 commitment to current reality:

| Commitment | Status | Gap | Priority |
|------------|--------|-----|----------|

Score each commitment item as: **DONE**, **IN PROGRESS**, **NOT STARTED**, or **BLOCKED**.

For each item, the Gap column must be specific -- not "needs work" but "Nicole has not yet built a dashboard independently" or "email automation exists but hasn't been tested with real sends."

**NEVER constraints for Gap descriptions:**
- NEVER write "needs work," "room for improvement," "could be better," "still developing," or any abstract placeholder.
- Every Gap MUST name a specific person, system, or action and state what has NOT happened.
- If you cannot identify a specific gap from the context files, write "Gap unknown -- insufficient data in [filename]" rather than inventing a vague description.

Identify the single biggest gap between where they are and where they said they wanted to be. Write this as a callout paragraph after the table.

**Step 3 -- Session Intelligence Extraction**

If session transcripts exist, scan ALL of them. Extract:
- **Key frameworks taught** -- name each one, note which day it was taught
- **Skills or tools demonstrated live** -- list them with what they do
- **Specific advice relevant to THIS business** -- quote it if possible, cite the day
- **Builds by other participants** that this person should consider adapting
- **Warnings or mistakes** discussed that this person should avoid

If no session transcripts are available, skip this step and note: "Session transcripts not available. This section will be populated when transcripts are added to this folder."

---

### PHASE 2: STRUCTURED DAILY PLAN

**Step 4 -- Today's Build Plan**

Create a detailed structure for the NEXT thing this person should work on. Format as time-blocked plan with three blocks:

```
## Today's Plan: [Day X or "Next Session"]

### Morning Block (First 90 min)
**FOCUS:** [Single clear objective -- one sentence]
- Step 1: [Exact action] -- [which skill/tool to use] -- [~X min]
- Step 2: [Exact action] -- [which skill/tool to use] -- [~X min]
- Step 3: [Exact action] -- [which skill/tool to use] -- [~X min]
**CHECKPOINT:** [What should be TRUE when this block is done]

### Build Block (Next 90 min)
**FOCUS:** [What to build or work on]
- Step 1: [Exact action]
- Step 2: [Exact action]
- What to ask for help with: [specific question if in a program setting]
**CHECKPOINT:** [What should be TRUE when this block is done]

### Afternoon Block (Final 90 min)
**FOCUS:** [What to build or refine]
- Step 1: [Exact action]
- Step 2: [Exact action]
**CHECKPOINT:** [What should be TRUE at end of day]
```

**RULES for this section:**
- Every step must be specific enough that the person can execute it without asking "but how?"
- If a step requires a skill, name the skill with the `/skill-name` format
- If a step requires a prompt, write the prompt they should use
- If a step requires reading a file, give the file path or describe where it is
- Every time estimate must be in MINUTES, not hours
- No open-ended "explore" or "research" steps -- be concrete
- NEVER reference a skill name unless it was mentioned in a session transcript or is known to be installed. If uncertain whether a skill exists, describe the action instead (e.g., "write 3 headline variations using the BJ headline framework" instead of "run `/bj-headlines`").

**Portability note:** Examples throughout this skill reference skills that may be installed in some environments. If a named skill is unavailable, substitute with the equivalent manual action.

**Step 5 -- Build Priorities**

Create a prioritized list of the top 3 things this person should build, in order:

| # | What to Build | Why Build It | Benefit | Outcome When Done |
|---|--------------|-------------|---------|-------------------|
| 1 | [Specific system/skill/tool] | [Why this is #1 -- connects to commitment gap] | [Concrete benefit in their business] | [What changes when this is working] |
| 2 | [Specific system/skill/tool] | [Why this is #2] | [Concrete benefit] | [What changes] |
| 3 | [Specific system/skill/tool] | [Why this is #3] | [Concrete benefit] | [What changes] |

**NEVER constraints for Build Priorities:**
- In the "Outcome When Done" column, NEVER write features. ALWAYS write outcomes.
- NEVER: "You'll have a dashboard." ALWAYS: "[Business Name] opens the dashboard and knows the state of 3 revenue streams in 90 seconds instead of spending 2 hours in spreadsheets."
- Every outcome must name WHO experiences it and WHAT changes for them, with a concrete time or money delta.

**Step 6 -- Remaining Days Overview**

If the person is in a multi-day program, create a high-level plan for remaining days:

| Day | Theme | Primary Build | Why This Sequence |
|-----|-------|--------------|-------------------|

Show how each day builds on the previous one. Nothing should be random -- every day should unblock the next. If the person is NOT in a multi-day program (e.g., they're using this skill independently), skip this step and instead create a "Next 7 Days" plan with daily themes.

---

### PHASE 3: REVENUE BRIDGE

**Step 7 -- First Revenue Action**

Identify the single fastest path from what they've already built (or will build today) to actual revenue. This is NOT theoretical -- it should be a specific action they can take THIS WEEK that puts money in motion.

Be specific. Name the skill. Name the list or audience. Name the offer. Name the platform.

**NEVER constraints for Revenue Bridge:**
- NEVER write "leverage your [asset]" -- name the EXACT asset and EXACT action. ("Send a 3-email reactivation sequence to the 1,200 lapsed subscribers in Keap" not "leverage your email list.")
- NEVER write "capitalize on," "monetize your," or "tap into" -- these are filler. State the action, the audience, and the expected math.
- Every revenue action MUST include: (1) the specific asset or channel, (2) the specific action to take, (3) the expected math based on numbers from the dossier.
- If the dossier does not contain the numbers needed for math, say "revenue math requires [missing data point] -- verify with participant before projecting."

Examples of the level of specificity required:
- "Run `/copywriting-arena` on the main offer page for [Business Name] and deploy the winner to the 3,000-subscriber email list in Keap"
- "Use the demand architect output to rewrite the [Product Name] landing page headline and A/B test it against the current version"
- "Take the 5-email reactivation sequence built in Day 3 and schedule it to the 800-person re-engagement segment in ActiveCampaign"
- "Run `/revenue-diagnosis-engine` on the last 3 client call transcripts to find the close rate bottleneck"

Include an estimated revenue impact with real math based on their actual numbers from the dossier. If numbers are not available, state what data is needed.

**Step 8 -- 30-Day System Vision**

Paint a picture of what their system looks like 30 days from now if they follow this roadmap. Structure as:

- **What is running automatically** -- list 3-4 systems with what they do
- **What decisions are being made by the system** -- list 2-3 specific decisions
- **Time saved** -- how many hours/week, redirected to what
- **Revenue impact** -- what the system is generating or protecting, with math

**NEVER constraints for 30-Day Vision:**
- NEVER write a feature statement ("you'll have a dashboard"). ALWAYS write an outcome statement ("[Person Name] opens the dashboard and knows the state of [Business Name]'s pipeline in 90 seconds instead of 2 hours of manual checking").
- Every item must name the person, the system, and the measurable change.

---

### PHASE 4: STRUCTURE ANSWERS

**Step 9 -- Your Launchpad**

This is the most important output. If the person reads NOTHING ELSE, this checklist should be enough to tell them exactly what to do.

Format as a numbered checklist:

```
## My Launchpad -- [Date]

When you sit down tomorrow, do this:

[ ] 1. [Exact action with exact command or exact file to open]
[ ] 2. [Next exact action]
[ ] 3. [Review step -- what to check]
[ ] 4. [Next exact action]
[ ] 5. [Adjustment step -- what to change if something's off]
[ ] 6. [Save/deploy step]
[ ] 7. [Move to next priority]
[ ] 8. [End-of-day verification]
```

Every item must be executable. No ambiguity. No "figure out what to work on." Open laptop, follow checklist.

**Step 10 -- End-of-Day Checkpoint**

Create 3-5 yes/no questions the person should ask themselves at the end of their work session:

- [ ] Did I complete the Morning Block checkpoint?
- [ ] Is [specific system/skill] working and tested?
- [ ] Can I show someone what I built and explain why it matters?
- [ ] Did I document what I built so I can pick up tomorrow without re-reading?
- [ ] Is my next session's priority clear?

---

### PHASE 5: BUILD IT NOW (Post-Roadmap Execution)

After delivering the roadmap outputs (ROADMAP-OUTPUT.md and ROADMAP-OUTPUT.html), present the user with this offer:

---

**Say this to the user (adapt the priority names to match the actual roadmap):**

> Your roadmap identified 3 priorities. I can start building them right now, working through each one in sequence. Before I begin, two questions:
>
> **How would you like me to build?**
> 1. **Draft mode** -- I build everything and save it for your review before anything goes live. You approve, edit, or reject each piece.
> 2. **Deploy mode** -- I build and deploy directly. You review after.
> 3. **Skip** -- Just keep the roadmap. I'll build when you're ready.
>
> **Where should build outputs go?**
> Give me a folder path, or I'll create subfolders in the current context folder (e.g., `priority-1-[name]/`, `priority-2-[name]/`, `priority-3-[name]/`).

---

**Wait for the user's response before proceeding.** Do not assume a build mode.

**When the user chooses to build (option 1 or 2):**

Execute priorities sequentially -- Priority 1 must complete before Priority 2 begins. Each priority follows this process:

**For each priority:**

1. **Assess scope.** Read the priority from the Build Priorities table. Is this a significant undertaking (new skill, new system, multi-step project) or a focused task (run a single skill, write one document)?

2. **Significant projects use Strategic Builder.** If the priority requires creating a new skill, building a multi-component system, or designing an architecture: if `/sp-strategic-builder` (or `/strategic-builder`) is installed, use it. If neither is installed, break the project into sequential steps and execute them directly -- do not block on a missing skill.

3. **Focused tasks execute directly.** If the priority is "run `/copywriting-arena` on X" or "write a brief for Y," just do it. No need for Strategic Builder overhead on a 15-minute task.

4. **Handle blockers gracefully.** If a priority requires something unavailable (API credentials, platform access, data the user hasn't provided), log the blocker in BUILD-LOG.md, tell the user what's needed, and move to the next priority. Do NOT stop the entire build sequence for one blocked item.

5. **In Draft mode:** Save all outputs to the designated folder. Present a summary of what was built with file paths. Ask: "Ready to review Priority 1 before I move to Priority 2?" Wait for approval before continuing.

6. **In Deploy mode:** Build and deploy (install skills to `~/.claude/skills/`, save documents to vault, etc.). Report what was done. Move to next priority.

**BUILD-LOG.md:**

Create and maintain `BUILD-LOG.md` in the context folder. Update it after every priority completes. Format:

```markdown
# Build Log -- [Business Name]

> Started: [YYYY-MM-DD HH:MM] | Mode: [Draft/Deploy]

## Priority 1: [Name]
- **Status:** COMPLETE / IN PROGRESS / BLOCKED
- **Built:** [List of files created with paths]
- **Tested:** [What was verified and how]
- **Blocked:** [Any unresolved dependencies -- or "None"]
- **User decision:** [Approved / Rejected / Modified -- with notes]

## Priority 2: [Name]
- **Status:** [...]
...
```

Only show priorities that have been worked on. The client sees progress on items that matter and are moving forward -- not noise from things that were skipped or denied.

---

### PHASE 6: VERIFICATION

Before delivering the roadmap, run this self-check. If any item fails, fix it before output.

**Data Integrity Checks:**
- [ ] Every number cited (revenue, list size, team count, time estimate) traces to a specific context file. No invented metrics.
- [ ] Every "not provided" or "verify" flag is present where source data was missing.

**Language Checks:**
- [ ] Zero instances of "your business," "your niche," "your market," or "your audience." All replaced with actual names/segments.
- [ ] Zero instances of "various," "multiple," or "several" without a count.
- [ ] Zero instances of "needs work," "room for improvement," "could be better," or "still developing" in Gap descriptions.
- [ ] Zero instances of "leverage your," "capitalize on," "monetize your," or "tap into" in revenue actions.

**Structural Checks:**
- [ ] Every Gap row names a specific person, system, or action -- not an abstraction.
- [ ] Every revenue action includes: specific asset + specific action + math (or explicit data-gap note).
- [ ] Every Launchpad item is executable without asking "but how?"
- [ ] Every skill name referenced either (a) appeared in a session transcript or (b) was described as an action if unknown.
- [ ] The 30-Day Vision contains zero feature statements -- only outcome statements with named people and measurable deltas.

**Completeness Checks:**
- [ ] All 10 Steps across Phases 1-4 are present (or explicitly noted as skipped with reason).
- [ ] ROADMAP-OUTPUT.md includes provenance note listing context files read.
- [ ] ROADMAP-OUTPUT.html is a complete self-contained file matching the markdown structure.

If any check fails, revise the relevant section before saving the output files.

---

## Output Requirements

### Output 1: Markdown File

Save as `ROADMAP-OUTPUT.md` in the same folder as the context files.

Structure with clear H2 headers matching each phase. Use tables, checklists, and code blocks. Make it scannable -- a busy entrepreneur should be able to open this file and know exactly what to do in the first 10 seconds.

Start the file with:
```markdown
# My Roadmap -- [Business Name] / [Person Name]

> Generated: [YYYY-MM-DD] | [Program context, e.g., "Force Multiplier Day 5"]
> Based on: [List all context files read]

---
```

End the file with a provenance note listing how many context files were read and confirming that every recommendation uses real skill names from the installed system and every command is executable.

### Output 2: HTML Design Page

Save as `ROADMAP-OUTPUT.html` in the same folder as the context files.

This must be a self-contained, single-file HTML page with embedded CSS. The design spec:

**Color scheme:** Dark mode
- Background: `#0d1117`
- Primary text: `#e6edf3`
- Headers and links: `#58a6ff`
- Success/done: `#3fb950`
- Warning/in-progress: `#d29922`
- Error/blocked/high-priority: `#f85149`
- Muted text: `#bbbbbb` (use ONLY in the footer timestamp and the blockquote metadata line -- NEVER for body text, table content, or anything the user needs to read)
- Card/block backgrounds: `#161b22`
- Borders: `#30363d` for cards, `#21262d` for table rows and dividers

**Typography:**
- Font: `system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`
- Code: `'SF Mono', 'Fira Code', 'Cascadia Code', monospace`
- Line height: 1.7
- Max width: 900px, centered

**Components to use:**
- **Status badges** in tables: colored `<span>` elements for DONE (green), IN PROGRESS (yellow), NOT STARTED (muted), BLOCKED (red)
- **Priority badges**: HIGH (red), MED (yellow), CRITICAL (red, bold, uppercase)
- **Time block cards**: dark card background with 1px border, rounded corners (8px), focus label in green
- **Checkpoint callouts**: green left border (4px), slightly different background (`#1a2332`)
- **Gap callout**: red left border, red-tinted background (`#2a1215`)
- **Revenue callout**: green left border, green-tinted background (`#1a2a15`)
- **Launchpad box**: blue left border, card background, checkbox items with `\2610` unicode character
- **Weekend/plan blocks**: same card style as time blocks
- **Blockquote** for metadata: blue left border, card background, italic

**Print styles:** Include `@media print` that inverts to white background with appropriate dark text colors. All status/priority badges should remain readable in print.

**Responsive:** Include `@media (max-width: 600px)` with smaller fonts and tighter padding.

**Structure the HTML to match the markdown output section by section.** Every H2 in the markdown becomes an H2 in the HTML. Every table becomes an HTML table with the status badge spans. Every checklist becomes a styled list.

**Footer:** Centered, muted, with the generation date and "Generated by My Roadmap" label.

### Quality Checklist (for human review)

Include this checklist at the bottom of `ROADMAP-OUTPUT.md` under a `## Review Checklist` header so the participant (or their coach) can verify quality:

```markdown
## Review Checklist

Before acting on this roadmap, confirm:

- [ ] Every business name, market, and audience segment matches reality
- [ ] Revenue numbers and list sizes are accurate (or flagged as unverified)
- [ ] The #1 priority aligns with what I actually committed to on Day 1
- [ ] Every Launchpad step is something I can do without asking for clarification
- [ ] The revenue math uses my real numbers, not estimates
- [ ] Skills referenced are ones I actually have installed (or described as actions)
```

---

## Design Principles

These are enforceable constraints, not aspirations. Violating any of these is a defect.

1. **Specific beats general.**
   - ALWAYS: "Run `/demand-architect` on the executive coaching offer" or "write 3 email subject lines using the BJ headline framework."
   - NEVER: "do some market research" or "work on your emails."

2. **Sequence matters.**
   - ALWAYS show the dependency chain explicitly. If Step 3 requires Step 2's output, state: "Requires: [Step 2 output name]."
   - NEVER recommend something that depends on something they haven't built yet without flagging the dependency.

3. **Time-box everything.**
   - ALWAYS attach a realistic time estimate in minutes to every action.
   - NEVER include open-ended "explore" or "research" steps. If research is needed, specify what to research, where to look, and how long to spend.

4. **Revenue is the scoreboard.**
   - ALWAYS connect every build to revenue within 2 steps and make the connection explicit.
   - NEVER put a non-revenue item at Priority #1 unless every revenue-connected item is DONE or BLOCKED.

5. **The launchpad is sacred.**
   - ALWAYS make the Launchpad self-sufficient -- someone who reads ONLY the Launchpad must know exactly what to do.
   - NEVER include a Launchpad item that requires reading another section of the roadmap to understand.

6. **Honor what they said.**
   - ALWAYS pull recommendations toward the Day 1 commitment vision.
   - NEVER substitute your judgment for their stated priorities unless their commitment is provably unachievable with their current resources (and if so, flag it explicitly).

7. **No jargon without context.**
   - ALWAYS explain what a skill does in parentheses the first time you reference it.
   - NEVER assume the reader remembers skill names from previous sessions.

8. **Progress over perfection.**
   - ALWAYS recommend shipping something imperfect today over planning something perfect for next week.
   - NEVER recommend a planning phase without a same-day deliverable.
