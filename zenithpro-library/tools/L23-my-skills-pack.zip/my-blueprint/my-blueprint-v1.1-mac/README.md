# My Blueprint

See your entire AI system as a visual map -- every skill, every agent, every data source, and how they all connect.

---

## What This Does For You

You've been building skills throughout Force Multiplier. By now you might have 10, 20, maybe 50 tools installed. But can you see how they fit together? Can you point to the gaps? Do you know which skills are connected to your daily workflow and which are sitting unused?

My Blueprint scans everything you have installed and generates a complete visual map of your system. It produces Mermaid diagrams that render right inside Obsidian, plus an interactive Obsidian Canvas file where you can drag nodes around and explore spatial relationships. The output shows you architecture maps by category, a capability mind map, data flow diagrams, a usage-vs-impact quadrant, connection health analysis, a build timeline, and a written Key Findings section with specific recommendations.

The difference between having 50 tools and having a system is visibility. This makes the system visible.

---

## How It Works

The skill runs in two phases. First, it scans `~/.claude/skills/` and `~/.claude/agents/` to read every installed component, classify it into categories (Copywriting, Webinar, Research, Intelligence, Revenue, Operations, etc.), and detect connections between components. Then it generates 6 types of diagrams plus a written analysis, saving everything to two files in your current directory.

See [how-it-works.md](how-it-works.md) for visual diagrams of the process.

---

## Installation

### Mac (Terminal)

```bash
cd ~/Downloads/my-blueprint-v1.1
chmod +x install.sh
./install.sh
```

### Windows (PowerShell)

```powershell
cd $env:USERPROFILE\Downloads\my-blueprint-v1.1
.\install.ps1
```

---

## What Gets Installed

| File | Location | Purpose |
|------|----------|---------|
| SKILL.md | `~/.claude/skills/my-blueprint/SKILL.md` | The skill definition |

That's it -- one file. No API keys, no configuration, no dependencies beyond Claude Code itself.

---

## How to Use

Run from any directory in Claude Code:

```
/my-blueprint
```

The skill will:
1. Scan all your installed skills and agents
2. Announce what it found (checkpoint)
3. Generate `MY-BLUEPRINT.md` (Mermaid diagrams + analysis)
4. Generate `MY-BLUEPRINT.canvas` (interactive Obsidian Canvas)

Both files are written to whatever directory you're in when you run the command.

**Best practice:** Run it from your Obsidian vault so the output files appear where you can view them immediately.

---

## What You Get

| Output | What It Shows |
|--------|--------------|
| Architecture Maps | Per-category flowcharts showing components and connections |
| Capability Mind Map | Everything organized by what you can DO (Write, Research, Build, Analyze...) |
| Data Flow (Sankey) | How information flows through your system |
| Usage vs Impact | Quadrant chart showing Power Tools, Untapped Gold, Shelf Warmers |
| Connection Health | X-ray view -- what's connected vs what's isolated |
| Build Timeline | When you added what (mapped to FM days if applicable) |
| Key Findings | Written analysis with stats, gaps, and recommendations |

---

## Troubleshooting

**"No skills directory found"**
Your `~/.claude/skills/` directory is empty or doesn't exist. Install at least one skill first.

**Diagrams show gray error boxes in Obsidian**
Make sure you're viewing in Reading Mode (not Edit Mode). Mermaid diagrams only render in Reading Mode.

**Canvas file shows blank**
Open it with Obsidian's Canvas view (right-click > Open as Canvas). It won't render as a regular markdown file.

**Too many nodes / unreadable diagrams**
The skill has built-in scale rules for 100+ components. If diagrams are still crowded, re-run and the skill will apply compression automatically.

---

## Requirements

- Claude Code installed and working
- At least a few skills installed in `~/.claude/skills/` (the more you have, the more useful the blueprint)
- Obsidian with Mermaid plugin enabled (built-in since Obsidian 1.4+)

---

*Packaged by Rich Schefren - Strategic Profits*
*My Blueprint v1.1 -- Force Multiplier Intensive*
