# How My Blueprint Works

## Overview

```mermaid
flowchart TD
SCAN[Scan Skills + Agents] --> CLASS[Classify by Category]
CLASS --> CONNECT[Detect Connections]
CONNECT --> HEALTH[Score Health]
HEALTH --> OUTPUT[Generate Outputs]
```

## Phase 1: Scan and Classify

```mermaid
flowchart TD
SK[Skills Directory] --> READ[Read First 30 Lines]
AG[Agents Directory] --> READ
MCP[MCP Config] --> READ
READ --> NAME[Extract Name + Purpose]
NAME --> CAT[Assign Category]
CAT --> CONN[Find Connections]
```

**12 Categories:** Copywriting, Webinar, Research, Intelligence, Revenue, Operations, Content, Building, Deep Thinkers, Product, Meta, Uncategorized

## Phase 2: Generate Diagrams

```mermaid
flowchart TD
DATA[Scan Results] --> MD[MY-BLUEPRINT.md]
DATA --> CANVAS[MY-BLUEPRINT.canvas]
MD --> D1[Architecture Maps]
MD --> D2[Mind Map]
MD --> D3[Sankey Flow]
```

```mermaid
flowchart TD
MD2[MY-BLUEPRINT.md cont] --> D4[Quadrant Chart]
MD2 --> D5[Health Map]
MD2 --> D6[Timeline]
MD2 --> D7[Key Findings]
```

## Connection Health Scoring

```mermaid
flowchart TD
COUNT[Count Connections] --> HUB[5+ = Hub]
COUNT --> CON[2-4 = Connected]
COUNT --> WEAK[1 = Weak]
COUNT --> ISO[0 = Isolated]
```

**Color coding across all diagrams:**
- Green = Hub (system nexus)
- Default = Connected (healthy)
- Yellow = Weak (needs attention)
- Red = Isolated (disconnected -- the key insight)

## Output Files

```mermaid
flowchart TD
RUN[Run my-blueprint] --> FILE1[MY-BLUEPRINT.md]
RUN --> FILE2[MY-BLUEPRINT.canvas]
FILE1 --> OBS1[View in Obsidian Reading Mode]
FILE2 --> OBS2[View in Obsidian Canvas Mode]
```
