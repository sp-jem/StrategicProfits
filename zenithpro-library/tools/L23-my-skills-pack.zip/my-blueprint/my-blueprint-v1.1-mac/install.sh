#!/bin/bash
set -e

# My Blueprint v1.1 Installer (Mac/Linux)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$HOME/.claude/skills/my-blueprint"

echo "============================================"
echo "  My Blueprint v1.1 - Installer"
echo "============================================"
echo ""

# Check for existing installation
if [ -d "$SKILL_DIR" ]; then
    echo "Found existing my-blueprint installation."
    read -p "Overwrite? (y/n): " CONFIRM
    if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
        echo "Installation cancelled."
        exit 0
    fi
    # Backup existing
    cp -r "$SKILL_DIR" "${SKILL_DIR}.bak.$(date +%Y%m%d%H%M%S)"
    echo "Backed up existing installation."
fi

# Create skill directory
mkdir -p "$SKILL_DIR"

# Copy skill file
cp "$SCRIPT_DIR/SKILL.md" "$SKILL_DIR/SKILL.md"

# Verify installation
if [ -f "$SKILL_DIR/SKILL.md" ]; then
    echo ""
    echo "============================================"
    echo "  Installation Complete!"
    echo "============================================"
    echo ""
    echo "Installed to: $SKILL_DIR"
    echo ""
    echo "To use: Type /my-blueprint in Claude Code"
    echo ""
    echo "The skill will scan your installed skills"
    echo "and generate visual system maps."
    echo ""
else
    echo "ERROR: Installation failed. SKILL.md not found at $SKILL_DIR"
    exit 1
fi
