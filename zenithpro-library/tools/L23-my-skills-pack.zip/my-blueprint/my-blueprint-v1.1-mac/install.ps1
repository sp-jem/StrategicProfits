# My Blueprint v1.1 Installer (Windows PowerShell)
$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillDir = Join-Path $env:USERPROFILE ".claude\skills\my-blueprint"

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  My Blueprint v1.1 - Installer" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# Check for existing installation
if (Test-Path $SkillDir) {
    Write-Host "Found existing my-blueprint installation." -ForegroundColor Yellow
    $confirm = Read-Host "Overwrite? (y/n)"
    if ($confirm -ne "y" -and $confirm -ne "Y") {
        Write-Host "Installation cancelled."
        exit 0
    }
    # Backup existing
    $backupDir = "${SkillDir}.bak.$(Get-Date -Format 'yyyyMMddHHmmss')"
    Copy-Item -Path $SkillDir -Destination $backupDir -Recurse
    Write-Host "Backed up existing installation." -ForegroundColor Green
}

# Create skill directory
if (-not (Test-Path $SkillDir)) {
    New-Item -ItemType Directory -Path $SkillDir -Force | Out-Null
}

# Copy skill file
Copy-Item -Path (Join-Path $ScriptDir "SKILL.md") -Destination (Join-Path $SkillDir "SKILL.md") -Force

# Verify installation
if (Test-Path (Join-Path $SkillDir "SKILL.md")) {
    Write-Host ""
    Write-Host "============================================" -ForegroundColor Green
    Write-Host "  Installation Complete!" -ForegroundColor Green
    Write-Host "============================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Installed to: $SkillDir"
    Write-Host ""
    Write-Host "To use: Type /my-blueprint in Claude Code"
    Write-Host ""
    Write-Host "The skill will scan your installed skills"
    Write-Host "and generate visual system maps."
    Write-Host ""
} else {
    Write-Host "ERROR: Installation failed. SKILL.md not found at $SkillDir" -ForegroundColor Red
    exit 1
}
