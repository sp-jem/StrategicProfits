<!-- my-blueprint v1.1 â Prompt Architecture Audit applied 2026-03-27 -->
# My Blueprint

Your AI system as a visual map. Scans every skill, agent, and data source you have installed, then generates a set of diagrams showing how everything connects -- what feeds what, where the gaps are, and what's disconnected. The difference between having 50 tools and having a system is visibility.

Run this after installing new skills, or whenever you think "I have a lot of stuff but I can't see how it fits together."

**This skill does NOT:**
- Install, uninstall, or modify any skill, agent, or config file
- Suggest specific skills to install (that is my-roadmap's job)
- Fix broken connections or configurations
- Access any data outside `~/.claude/` and the current working directory

## How to use

```
/my-blueprint
```

---

## Guardrails

- If `~/.claude/skills/` does not exist or is empty, STOP and report: "No skills directory found. Nothing to map."
- If `.mcp.json` is missing or contains invalid JSON, skip it and note "MCP config not found" in the System Overview. Do NOT fail the entire run.
- If a SKILL.md or AGENT.md cannot be read (permissions, encoding), skip it and count it as "unreadable" in the health summary. NEVER halt on a single bad file.
- This skill is READ-ONLY. It MUST NOT modify any skill, agent, config, or data file it scans. It writes ONLY `MY-BLUEPRINT.md` and `MY-BLUEPRINT.canvas`.
- If `MY-BLUEPRINT.md` or `MY-BLUEPRINT.canvas` already exist in the current directory, overwrite them. NEVER append, NEVER create date-suffixed copies.

---

## Scale Rules (100+ components)

When total skills + agents + MCP servers exceeds 100:
1. Read ONLY the first 15 lines of each SKILL.md/AGENT.md (not 30) -- at scale, full reads exhaust context before output begins
2. Collapse skill families into single nodes (e.g., `webinar-brunson-*` becomes one node "Brunson [7]") -- individual sub-skills are noise at this zoom level
3. Split the Connection Health Map into 3 diagrams: Hubs, Connected, and Isolated -- a single diagram with 100+ nodes renders as an unreadable gray blob
4. In the Quadrant chart, plot ONLY the top 20 by connection count divergence from median
5. In the Sankey, aggregate family flows (all webinar skills become one "Webinar" flow)

---

## PHASE 1: SCAN AND INVENTORY

### Step 1 -- Enumerate Everything

Scan these locations for installed components:

**Skills:**
```bash
ls -d ~/.claude/skills/*/SKILL.md 2>/dev/null
```

**Agents:**
```bash
ls -d ~/.claude/agents/*/AGENT.md 2>/dev/null
```

**MCP Servers (data sources):**
```bash
cat ~/.claude/.mcp.json 2>/dev/null
```

**Settings hooks (automated behaviors):**
```bash
cat ~/.claude/settings.json 2>/dev/null | grep -A5 '"hooks"'
```

For each skill, read ONLY the first 30 lines of SKILL.md. NEVER read the full file -- at scale, full reads exhaust context before output begins. Extract:
- **Name**: from the `name:` frontmatter or the `# Title`
- **Purpose**: the first sentence of the description
- **Category**: classify using the rules below
- **Connections**: any skills, agents, or data sources it references by name

For each agent, read ONLY the first 30 lines of AGENT.md for the same fields.

For MCP servers, extract the server name and what service it connects to.

### Step 2 -- Classify Into Categories

Assign every component to exactly ONE category. Check keywords in order -- first match wins. A component that matches COPYWRITING and META goes to COPYWRITING.

| Category | Keywords in name or description |
|----------|-------------------------------|
| COPYWRITING | copy, vsl, sales letter, headline, lead, bullet, close, offer, arena, copywriting, bj, cj, dd, ae, clayton, modernize, autonomy, giving-copy |
| WEBINAR | webinar, fladlien, brunson, cage, kern, joon, kennedy, teleseminar, presentation |
| RESEARCH | research, excavation, avatar, demand, desire, belief, mimetic, psychographic, usp, motivation, buying-mindset, aspiration |
| INTELLIGENCE | briefing, screenpipe, limitless, meeting, transcript, brain-run, fog-lifter, eyes-on, paradigm, dissolution, schwerpunkt, pattern, turkey, delay, role-mind, red-bead, say-do, steam-era, real-business, self-deception, butterfly, invisible-tax, constraint, combinatorial, counterintuitive |
| REVENUE | stripe, whop, trolley, keap, analytics, revenue, finance |
| OPERATIONS | clickup, slack, wordpress, cloudflare, google-drive, imessage, file-organizer, invoice, process-inbox |
| CONTENT | content, linkedin, social-media, video, image, pptx, docx, pdf, xlsx, pillar, story, signature-talk |
| BUILDING | skill-creator, strategic-builder, quality-gate, code-quality, mcp-builder, student-package, command-center, product-registry, sp-diagnostic, sp-launchpad, sp-refresh |
| DEEP THINKERS | ariely, barabasi, barthes, bourdieu, cialdini, damasio, festinger, fogg, girard, gordon, granovetter, lewin, loewenstein, mcluhan, mccracken, rogers, thaler, veblen, azoff, avant, brillstein, demann, emanuel, gallin, lourd, mengers, ovitz, thompson, wasserman, yorn |
| PRODUCT | offer-factory, product-improver, product-enhancement, product-strategist, product-manager, mechanism, framework-forge, proprietary-term, toffler, high-concept, core-concept, permission-concept, distinction, language-engine |
| META | my-roadmap, my-blueprint, my-housekeeper, my-toolkit, roadmap, blueprint, housekeeper, toolkit |

If no keyword matches, assign to **UNCATEGORIZED**.

### Step 3 -- Detect Connections

Two components are connected if ANY of these are true (check all five, use ONLY these -- do NOT infer connections beyond this list):
1. **Explicit reference**: Skill A's SKILL.md mentions Skill B by name
2. **Pipeline**: Skill A's description says it produces output consumed by Skill B (e.g., "feeds into", "output used by")
3. **Orchestration**: Skill A invokes or triggers Skill B (e.g., "orchestrates", "runs", "dispatches to")
4. **Evaluation**: An agent's description names a skill it evaluates (e.g., "evaluates BJ output")
5. **Family group**: Skills sharing the same prefix up to the last hyphen-segment are connected (e.g., `webinar-brunson-*` all connect to `webinar-brunson`)

Do NOT infer connections from shared category alone. Two COPYWRITING skills are NOT connected just because they are both in COPYWRITING. They MUST have an explicit reference, pipeline, orchestration, evaluation, or family relationship.

Build a connection list: `[source, target, type]` where type is one of: `data`, `triggers`, `evaluates`, `family`.

### Step 4 -- Score Connection Health

For each component, count its connections:
- **Hub** (5+ connections): This is a system nexus
- **Connected** (2-4 connections): Healthy integration
- **Weak** (1 connection): Partially integrated
- **Isolated** (0 connections): Disconnected -- this is the key insight

---

## CHECKPOINT: Announce Scan Results

Before generating ANY output, announce your findings in this exact format:

> Scan complete. Found [X] skills, [Y] agents, [Z] MCP servers.
> Categories populated: [N] of 12.
> Hubs (5+): [list].
> Isolated (0): [list].
> Proceeding to generate MY-BLUEPRINT.md and MY-BLUEPRINT.canvas.

Do NOT proceed to Phase 2 until you have announced this summary. This forces commitment to categorization and connection analysis before generating diagrams -- preventing inconsistencies between sections.

---

## PHASE 2: GENERATE OUTPUTS

Write EXACTLY two files to the current working directory. NEVER create additional files.
1. `MY-BLUEPRINT.md` -- Mermaid diagrams + analysis (renders in Obsidian reading mode)
2. `MY-BLUEPRINT.canvas` -- Interactive spatial map (drag nodes around in Obsidian Canvas view)

---

### OUTPUT 1: MY-BLUEPRINT.md

Structure this file with ALL of the following sections in order. Do NOT skip sections. Do NOT reorder.

---

#### Section 1: System Overview

Write EXACTLY 4 sentences covering these four points in order:
1. Total component counts (X skills, Y agents, Z MCP servers)
2. Category coverage (N of 12 categories populated)
3. Biggest hub and biggest gap
4. One-sentence system health verdict

---

#### Section 2: Architecture Maps (per category)

**CRITICAL CONSTRAINTS -- violating any of these produces unreadable output:**
- Do NOT use subgraphs -- they cause horizontal spread that breaks Obsidian rendering
- Do NOT use indentation in Mermaid code -- start every line at column 0
- NEVER exceed 3 edges from any single node -- more than 3 produces an unreadable hairball where no individual connection can be traced. If a node has 4+ connections, split into intermediate nodes or separate diagrams.
- NEVER exceed 15 nodes per diagram -- Mermaid chokes on large diagrams in Obsidian, producing blank renders or gray error boxes

For each populated category, generate a separate `flowchart TD` diagram showing:
- That category's components as nodes
- Edges showing connections within and across categories
- Health coloring (see style rules below)

If a category has more than 15 components, you MUST split into sub-diagrams (e.g., "Copywriting: Sales Letters" and "Copywriting: Arena System").

**Node shapes by component type:**
- Skills: rounded rectangle `(Skill Name)`
- Agents: hexagon `{{Agent Name}}`
- MCP servers: cylinder `[(Server)]`
- External service: stadium `([Service])`

**Edge styles:**
- Data flow: `-->` with label
- Triggers: `-.->` (dotted)
- Evaluates: `==>` (thick)

**Health styling -- add AFTER the diagram edges:**
```
style nodeId fill:#69db7c
style nodeId fill:#ffd43b
style nodeId fill:#ff6b6b
```
- Green `#69db7c` = Hub (5+ connections)
- Yellow `#ffd43b` = Weak (1 connection)
- Red `#ff6b6b` = Isolated (0 connections)
- Default (no style) = Connected (2-4)

**Example of a correct category diagram:**

````markdown
### Copywriting System

```mermaid
flowchart TD
CA(Copywriting Arena)
BJ(BJ)
CJ(CJ)
DD(DD)
MOD(Modernizers)
CA -->|orchestrates| BJ
CA -->|orchestrates| CJ
CA -->|orchestrates| DD
BJ -->|output| MOD
CJ -->|output| MOD
style CA fill:#69db7c
style MOD fill:#ffd43b
```
````

Then after ALL category diagrams, add a **Cross-Category Bridge** diagram showing ONLY the connections that span categories (e.g., Research --> Copywriting, Intelligence --> Operations). This diagram MUST NOT duplicate any intra-category edges.

---

#### Section 3: Capability Mind Map

Generate a `mindmap` diagram organized by ACTION VERB, not category:

```
mindmap
root((My AI System))
  Write
    Sales Letters
    Emails
    Headlines
    Social Posts
  Research
    Markets
    Avatars
    Competitors
  Build
    Skills
    Webinars
    Courses
  Analyze
    Revenue
    Performance
    Behavior
  Manage
    Tasks
    Team Comms
    Content
  Evaluate
    Copy Quality
    System Health
```

Populate each branch from the actual scan results. Use 2 levels of depth: verb --> sub-capability --> skill names. NEVER list more than 3 skills per sub-capability -- excess skills cause the mindmap to collapse into unreadable text in Obsidian.

---

#### Section 4: Data Flow (Sankey)

Generate a `sankey-beta` diagram showing how information flows through the system.

Map major data pipelines:
- Raw inputs (meetings, messages, web data) --> processing skills --> output
- Research --> creative production --> deployment
- Business data --> analytics --> decisions

**Constraints:**
- Each flow line MUST follow format: `"Source", "Destination", weight`
- Weight = relative volume on 1-10 scale, calibrated so the highest-volume flow = 10
- NEVER exceed 20 flow lines -- sankey diagrams with 21+ lines become visual noise
- Every label MUST be under 20 characters -- sankey truncates longer labels without warning

**If sankey-beta fails to render** (some Obsidian versions do not support it), include a text-based fallback table immediately below:

| From | To | Vol | Description |
|------|-----|-----|-------------|

---

#### Section 5: Usage vs Impact Quadrant

Generate a `quadrantChart` plotting skills by estimated usage frequency and business impact.

```
quadrantChart
title Skill Usage vs Revenue Impact
x-axis "Low Frequency" --> "High Frequency"
y-axis "Low Impact" --> "High Impact"
quadrant-1 "Power Tools"
quadrant-2 "Untapped Gold"
quadrant-3 "Shelf Warmers"
quadrant-4 "Comfort Blankets"
```

**Estimation rules -- do NOT guess freely:**
- **High frequency** (>0.6 on x-axis): Skills that run daily or in most sessions (briefings, analytics, core copy skills)
- **Low frequency** (<0.4 on x-axis): Skills used only for specific projects (deep thinkers, niche tools)
- **High impact** (>0.6 on y-axis): Skills that directly drive revenue or save significant time (arenas, analytics, automation)
- **Low impact** (<0.4 on y-axis): Nice-to-have skills that do not directly move business metrics

If a business dossier exists in the current folder, use it to calibrate. Otherwise use general business heuristics.

Plot EXACTLY 15-20 skills. Selection criteria: prioritize skills that appear in multiple categories, have extreme connection counts (hub or isolated), or show the widest gap between estimated usage and impact.

---

#### Section 6: Connection Health Map

Generate a `flowchart LR` diagram showing ONLY connection health -- no edge labels, just nodes and edges, color-coded.

This is the "X-ray" view. It answers: "What did I build that isn't connected to anything?"

Every node label MUST be under 12 characters. Use abbreviations. Add a legend table below the diagram mapping abbreviations to full skill names.

If total components exceed 30, you MUST split into two diagrams:
1. "Connected Components" (hubs + connected + weak)
2. "Isolated Components" (the action list -- these need attention)

---

#### Section 7: Build Timeline

Generate a `timeline` diagram showing when capabilities were added.

**For FM participants:** Map against program days (Day 1, Day 2, Day 3-4, Day 5). Detect FM context by checking for `day1-commitment.md`, `session-*.md`, or `business-dossier.md` in the current folder.
**For general use:** Group by file modification date into weeks. If modification dates are unavailable (e.g., symlinked skills), use alphabetical grouping and note "Timeline based on alphabetical order -- modification dates unavailable."

```
timeline
title System Build Timeline
section Foundation
  Day 1 : Vault setup : CLAUDE.md : First skills
section Core Skills
  Day 2 : Strategic Builder : Skill Creator
section Production
  Day 3-4 : Copywriting Arena : Employee Systems
section Integration
  Day 5 : Blueprint : Roadmap : Full system
```

---

#### Section 8: Key Findings

Write a structured analysis with these exact headings. Do NOT add extra headings. Do NOT skip any.

**System Stats**
- Total skills: X
- Total agents: X
- Total MCP servers: X
- Categories populated: X of 12

**Health Summary**
- Hubs (5+): list them
- Connected (2-4): count
- Weak (1): count
- Isolated (0): list them -- these are the headline finding

**Biggest Hub**
Name the skill with the most connections and explain why it is central.

**Biggest Gap**
Identify the most impactful disconnection. What skill or connection would create the most value if added?

**Recommended Next Build**
Based on the gap analysis, recommend 1-3 specific actions:
1. Connect [isolated skill X] to [hub Y] by [specific action]
2. Build [missing skill] to bridge [gap between categories]
3. Remove or upgrade [shelf warmer] that adds no value

---

### OUTPUT 2: MY-BLUEPRINT.canvas

Generate an Obsidian Canvas file (`.canvas`) following the JSON Canvas spec.

**Layout:**
- Group nodes by category using `group` type nodes (colored backgrounds)
- Position groups spatially:
  - INTELLIGENCE at top center (the brain)
  - RESEARCH at top left, CONTENT at top right
  - COPYWRITING at middle left, WEBINAR at middle right
  - OPERATIONS at bottom left, REVENUE at bottom right
  - BUILDING at bottom center
- Place skill nodes inside their category groups
- Draw edges between connected skills

**Node sizing:**
- Group nodes: 800x600 (large enough to contain children)
- Hub skills: 250x100
- Regular skills: 200x80
- Isolated skills: 200x80

**Colors:**
- Groups: use preset colors 1-6 to distinguish categories
- Hub nodes: `"4"` (green)
- Isolated nodes: `"1"` (red)
- Regular nodes: no color (default)

**Edges:**
- Data flow: `toEnd: "arrow"`
- Evaluation: `toEnd: "arrow"`, `color: "6"` (purple)
- Family: `toEnd: "none"` (just a line)

**Validation -- you MUST pass ALL checks BEFORE writing the .canvas file. If ANY check fails, fix it and re-validate. NEVER write an invalid .canvas -- Obsidian shows a blank screen with no error for corrupt canvas JSON.**
- All node IDs MUST be unique 16-char hex strings -- duplicate IDs cause Obsidian to silently drop edges, producing a map with invisible connections
- Every `fromNode`/`toNode` MUST reference an existing node ID -- dangling references produce silent render failures
- Child nodes MUST be positioned within their group bounds -- out-of-bounds children render outside their category group, destroying the visual organization
- No overlapping nodes (minimum 20px spacing)
- JSON MUST be valid and parseable

---

## Design Principles

1. **Every Mermaid diagram MUST render in Obsidian reading mode.** If you are uncertain about syntax, simplify. A simple diagram that renders beats a complex diagram that shows a gray error box.
2. **Color means something.** Green = hub. Red = isolated. Yellow = weak. NEVER use color decoratively.
3. **The canvas is the centerpiece.** The .canvas file is the interactive "space station" view. Mermaid diagrams are supporting detail views.
4. **Isolated nodes are the insight.** The whole point is to find what is disconnected. Highlight isolation, not connectivity.
5. **Readability over completeness.** If a diagram would have 30+ nodes, split it. Multiple clean diagrams beat one unreadable mess.
6. **The sankey is the showstopper.** People rarely see these. Make flow values intuitive and labels readable.
7. **The quadrant drives action.** "Untapped Gold" (high impact, low use) is where the user should focus next.

---

## Mermaid Rendering Rules

These are ABSOLUTE constraints. Violating ANY of them produces diagrams that break in Obsidian.

- **NO subgraphs** -- they cause horizontal spread that makes the diagram wider than the viewport
- **NO indentation** -- start all Mermaid lines at column 0; indentation adds no value and risks parse errors
- **Max 3 edges from one node** -- more than 3 produces an unreadable hairball where no individual connection can be traced
- **Labels MUST be under 20 characters** -- Obsidian truncates long labels silently, making nodes appear identical
- **No forward slashes in labels** -- Mermaid treats `/` as syntax, producing parse errors with no useful error message
- **No special characters in node IDs** -- use alphanumeric only; special characters cause silent parse failures
- **Use `flowchart TD` not `graph TD`** -- more reliable rendering across Obsidian versions

---

## Error Recovery

- If a Mermaid diagram fails to parse (unclosed brackets, reserved words as IDs, undefined node references), simplify by removing the newest edges until it parses. Log removed edges in a comment block below the diagram.
- If total scanned components exceed 100, apply the Scale Rules above. Do NOT attempt to render 100+ components at full resolution.
- If the .canvas JSON fails validation, identify the specific failing check, fix it, re-validate, and ONLY THEN write the file.
