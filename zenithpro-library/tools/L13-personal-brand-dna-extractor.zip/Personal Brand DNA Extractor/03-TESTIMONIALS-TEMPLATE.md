# Testimonials and Social Proof

> This file contains [PERSON NAME]'s testimonials organized by strength and theme.

---

## Testimonial Strength Tiers

### Tier 1: Transformational Results
*Use for: Sales pages, case studies, high-stakes conversions*

> **"[TESTIMONIAL TEXT]"**
> — [Name], [Title/Company]
> **Context:** [What they hired person for]
> **Result:** [Specific outcome]

---

> **"[TESTIMONIAL TEXT]"**
> — [Name], [Title/Company]
> **Context:** [What they hired person for]
> **Result:** [Specific outcome]

---

### Tier 2: Character & Working Style
*Use for: About pages, relationship building, trust establishment*

> **"[TESTIMONIAL TEXT]"**
> — [Name], [Title/Company]
> **Context:** [Relationship to person]

---

### Tier 3: Skill-Specific Endorsements
*Use for: Targeted positioning, specific service promotion*

> **"[TESTIMONIAL TEXT]"**
> — [Name], [Title/Company]
> **Skill highlighted:** [specific skill]

---

## Testimonials by Theme

### [Theme 1: e.g., Leadership]
| Quote | Source | Use When |
|-------|--------|----------|
| "[short quote]" | [Name] | [context] |
| "[short quote]" | [Name] | [context] |

### [Theme 2: e.g., Results]
| Quote | Source | Use When |
|-------|--------|----------|
| "[short quote]" | [Name] | [context] |
| "[short quote]" | [Name] | [context] |

### [Theme 3: e.g., Character]
| Quote | Source | Use When |
|-------|--------|----------|
| "[short quote]" | [Name] | [context] |
| "[short quote]" | [Name] | [context] |

---

## Quick-Reference Quotes

**Best Overall:**
> "[most powerful testimonial]"

**Best for Trust:**
> "[testimonial about character/reliability]"

**Best for Results:**
> "[testimonial with specific numbers/outcomes]"

**Best for Relatability:**
> "[testimonial about working style/personality]"

---

## Social Proof Numbers

| Metric | Number | Source |
|--------|--------|--------|
| LinkedIn Recommendations | [#] | LinkedIn |
| Client Testimonials | [#] | [source] |
| Case Studies | [#] | [source] |
| Years Experience | [#] | [source] |

---

## Testimonial Sources

- [ ] LinkedIn Recommendations
- [ ] Website testimonials page
- [ ] Client emails/messages
- [ ] Video testimonials
- [ ] Case study interviews
- [ ] Social media comments

---

*Last Updated: [DATE]*
*Extracted from: [SOURCES]*
