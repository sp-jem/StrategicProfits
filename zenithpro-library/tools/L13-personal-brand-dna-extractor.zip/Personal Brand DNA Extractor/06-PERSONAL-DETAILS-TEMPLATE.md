# Personal Details

> This file contains humanizing elements about [PERSON NAME] for relatability and connection.

---

## Basic Information

| Detail | Information |
|--------|-------------|
| **Full Name** | [Name] |
| **Location** | [City, State/Province] |
| **Originally From** | [Hometown] |
| **Family** | [Partner/kids/etc.] |
| **Age/Generation** | [if relevant] |

---

## Personality Profile

### Archetype
**Primary:** [e.g., The Architect, The Mentor, The Innovator]
**Secondary:** [e.g., The Strategist]

### Key Traits
- [Trait 1] - [evidence/example]
- [Trait 2] - [evidence/example]
- [Trait 3] - [evidence/example]

### Communication Style
- [How they communicate]
- [What they value in communication]

---

## Interests & Hobbies

| Interest | Details | Use When |
|----------|---------|----------|
| [Interest 1] | [specifics] | [humanizing content] |
| [Interest 2] | [specifics] | [relating to audience] |
| [Interest 3] | [specifics] | [showing lifestyle] |

---

## Values

### Core Values
1. **[Value 1]**: [How it shows up in their life/work]
2. **[Value 2]**: [How it shows up in their life/work]
3. **[Value 3]**: [How it shows up in their life/work]

### What They Stand Against
- [Thing they oppose 1]
- [Thing they oppose 2]

---

## Personal Journey Timeline

| Year/Period | Event | Significance |
|-------------|-------|--------------|
| [Year] | [Event] | [Why it matters] |
| [Year] | [Event] | [Why it matters] |
| [Year] | [Event] | [Why it matters] |

---

## Humanizing Details for Copy

### Family References
- [How they reference family in content]
- [Safe topics vs. private]

### Lifestyle Elements
- [Morning routine]
- [Work environment]
- [Travel habits]
- [Health/wellness]

### Quirks & Personality
- [Unique trait 1]
- [Unique trait 2]

---

## Social Media Presence

| Platform | Handle | Content Type | Tone |
|----------|--------|--------------|------|
| Instagram | @[handle] | [type] | [tone] |
| LinkedIn | [URL] | [type] | [tone] |
| YouTube | @[handle] | [type] | [tone] |
| Twitter/X | @[handle] | [type] | [tone] |

---

## What Makes Them Relatable

Based on content analysis, audiences connect with:

1. **[Relatability Factor 1]** - [example]
2. **[Relatability Factor 2]** - [example]
3. **[Relatability Factor 3]** - [example]

---

*Last Updated: [DATE]*
*Extracted from: [SOURCES]*
