# Credentials and Authority Claims

> This file documents [PERSON NAME]'s quantified achievements, credentials, and authority markers.

---

## Quantified Achievements

### Business Scale

| Achievement | Details | Context |
|-------------|---------|---------|
| **[Achievement 1]** | [specifics] | [context] |
| **[Achievement 2]** | [specifics] | [context] |
| **[Achievement 3]** | [specifics] | [context] |

### Client Impact

| Achievement | Details |
|-------------|---------|
| **[Impact 1]** | [specifics] |
| **[Impact 2]** | [specifics] |

---

## Industry Firsts & Innovations

### 1. [Innovation Name]
- **What**: [description]
- **When**: [timeframe]
- **Significance**: [why it matters]
- **Use when**: [copywriting context]

### 2. [Innovation Name]
- **What**: [description]
- **When**: [timeframe]
- **Significance**: [why it matters]
- **Use when**: [copywriting context]

---

## Formal Credentials

### Certifications
| Certification | Organization | Year |
|---------------|--------------|------|
| [Cert 1] | [Org] | [Year] |
| [Cert 2] | [Org] | [Year] |

### Professional Experience
- **[X years]**: [Role/Industry]
- **[X years]**: [Role/Industry]

### Education
- [Degree/Program] - [Institution]

---

## Scale Markers

| Metric | Number | Context |
|--------|--------|---------|
| [Metric 1] | [#] | [context] |
| [Metric 2] | [#] | [context] |
| [Metric 3] | [#] | [context] |

---

## Media Coverage & Recognition

### Featured In
- [Publication/Platform 1]
- [Publication/Platform 2]

### Awards
- [Award 1] - [Year]

### Professional Associations
- [Association 1] - [Role]
- [Association 2] - [Role]

---

## Authority Statement Templates

### Bio Long (100+ words)
"[Full bio paragraph]"

### Bio Medium (50-75 words)
"[Medium bio paragraph]"

### Bio Short (25-40 words)
"[Short bio]"

### One-Liner
"[Single sentence positioning statement]"

### Introduction Template
"[How to introduce this person in presentations/podcasts]"

---

## Skills & Expertise

**Primary Skills:**
- [Skill 1]
- [Skill 2]
- [Skill 3]

**Secondary Skills:**
- [Skill 4]
- [Skill 5]

---

*Last Updated: [DATE]*
*Extracted from: [SOURCES]*
