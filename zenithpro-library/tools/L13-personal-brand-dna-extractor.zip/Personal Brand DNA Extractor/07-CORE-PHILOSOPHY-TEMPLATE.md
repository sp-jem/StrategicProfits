# Core Philosophy

> This file documents [PERSON NAME]'s frameworks, beliefs, and mental models.

---

## Core Beliefs

### Belief 1: [Title]
**Statement:** "[Their belief in their words]"
**Why They Believe This:** [Origin/evidence]
**How It Shows Up:** [In their work/content]
**Use When:** [copywriting contexts]

### Belief 2: [Title]
**Statement:** "[Their belief in their words]"
**Why They Believe This:** [Origin/evidence]
**How It Shows Up:** [In their work/content]
**Use When:** [copywriting contexts]

---

## Signature Frameworks

### Framework 1: [Name]™

**Overview:** [One-sentence description]

**The Components:**
1. [Step/Element 1] - [description]
2. [Step/Element 2] - [description]
3. [Step/Element 3] - [description]

**Visual:**
```
[Step 1] → [Step 2] → [Step 3] → [Outcome]
```

**Use When:** [contexts]

---

### Framework 2: [Name]

**Overview:** [One-sentence description]

**The Concept:**
[Explanation of how it works]

**Use When:** [contexts]

---

## Contrarian Positions

| Topic | Conventional Wisdom | Their Position | Why |
|-------|-------------------|----------------|-----|
| [Topic 1] | "[common belief]" | "[their stance]" | [reasoning] |
| [Topic 2] | "[common belief]" | "[their stance]" | [reasoning] |
| [Topic 3] | "[common belief]" | "[their stance]" | [reasoning] |

---

## Mental Models

### Model 1: [Name]
**Concept:** [Explanation]
**Application:** [How they use it]
**Teach When:** [contexts]

### Model 2: [Name]
**Concept:** [Explanation]
**Application:** [How they use it]
**Teach When:** [contexts]

---

## Principles They Live By

1. **[Principle 1]**: [Explanation]
2. **[Principle 2]**: [Explanation]
3. **[Principle 3]**: [Explanation]

---

## What They Teach vs. What They Oppose

| They Teach | Instead Of |
|------------|------------|
| [Approach 1] | [Common approach they oppose] |
| [Approach 2] | [Common approach they oppose] |
| [Approach 3] | [Common approach they oppose] |

---

## Quotable Philosophy Lines

> "[Memorable quote about their philosophy]"

> "[Another quotable line]"

> "[Third quotable line]"

---

## Philosophy in Action

### How They Apply Their Philosophy:
- **In business:** [example]
- **In content:** [example]
- **In client work:** [example]
- **In personal life:** [example]

---

*Last Updated: [DATE]*
*Extracted from: [SOURCES]*
