# Origin Stories

> This file contains [PERSON NAME]'s key stories with context for when to use each.

---

## Primary Origin Story

### [Story Title]

**The Hook:**
> "[Opening line that grabs attention]"

**The Narrative:**
[Full story in their voice - 2-4 paragraphs]

**The Lesson:**
[What this story teaches/proves]

**Use When:**
- [Context 1]
- [Context 2]

**Key Quotes:**
> "[Memorable line from story]"

---

## Supporting Origin Stories

### Story 2: [Title - e.g., "The Burnout Moment"]

**Setting:** [Where/when this happened]

**The Problem:** [What they were struggling with]

**The Turning Point:** [What changed]

**The Outcome:** [What resulted]

**The Lesson:** [What this teaches]

**Use When:** [copywriting contexts]

---

### Story 3: [Title - e.g., "The First Big Win"]

**Setting:** [Where/when this happened]

**The Challenge:** [What they faced]

**The Action:** [What they did]

**The Result:** [What happened]

**The Lesson:** [What this teaches]

**Use When:** [copywriting contexts]

---

### Story 4: [Title - e.g., "The Mentor Moment"]

**Who:** [Who influenced them]

**What Happened:** [The interaction/lesson]

**The Impact:** [How it changed them]

**Use When:** [copywriting contexts]

---

## Story Elements Library

### Defining Moments
| Moment | When | Significance |
|--------|------|--------------|
| [Moment 1] | [Year/Age] | [Why it matters] |
| [Moment 2] | [Year/Age] | [Why it matters] |

### Failures/Setbacks (Vulnerability Content)
| Setback | What Happened | What They Learned |
|---------|---------------|-------------------|
| [Setback 1] | [details] | [lesson] |
| [Setback 2] | [details] | [lesson] |

### Wins/Breakthroughs
| Win | Context | Why It Matters |
|-----|---------|----------------|
| [Win 1] | [details] | [significance] |
| [Win 2] | [details] | [significance] |

---

## Story Usage Guide

| Story Type | Best For | Example Contexts |
|------------|----------|------------------|
| Origin Story | Webinars, about pages | "How I got started..." |
| Failure Story | Relatability, trust | "I used to think..." |
| Win Story | Credibility, proof | "Then this happened..." |
| Mentor Story | Authority by association | "I learned from..." |
| Client Story | Social proof | "When [client] came to me..." |

---

## Emotional Beats to Hit

Based on their stories, the emotional journey typically includes:

1. **[Starting Point]** - [emotional state]
2. **[Struggle]** - [emotional state]
3. **[Turning Point]** - [emotional state]
4. **[Transformation]** - [emotional state]
5. **[Current State]** - [emotional state]

---

*Last Updated: [DATE]*
*Extracted from: [SOURCES]*
