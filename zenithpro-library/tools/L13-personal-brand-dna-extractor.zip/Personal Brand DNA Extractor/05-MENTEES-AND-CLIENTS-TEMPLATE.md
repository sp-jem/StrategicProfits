# Mentees and Clients

> This file documents [PERSON NAME]'s client transformations and results for social proof.

---

## Client Transformation Stories

### Client 1: [Name/Anonymous Descriptor]

**Before State:**
- [Problem they had]
- [Struggle they faced]
- [What they tried that didn't work]

**What We Did:**
- [Intervention 1]
- [Intervention 2]
- [Intervention 3]

**After State:**
- [Result 1 - quantified if possible]
- [Result 2 - quantified if possible]
- [Transformation in their own words]

**Timeline:** [How long this took]

**Use When:** [copywriting contexts]

---

### Client 2: [Name/Anonymous Descriptor]

**Before State:**
- [Problem]
- [Struggle]

**What We Did:**
- [Intervention]

**After State:**
- [Result - quantified]

**Timeline:** [Duration]

**Use When:** [contexts]

---

## Results Summary Table

| Client/Type | Before | After | Timeline | Proof |
|-------------|--------|-------|----------|-------|
| [Client 1] | [state] | [state] | [time] | [testimonial/case study] |
| [Client 2] | [state] | [state] | [time] | [testimonial/case study] |
| [Client 3] | [state] | [state] | [time] | [testimonial/case study] |

---

## Client Types Served

### Type 1: [e.g., "The Overwhelmed Founder"]
**Profile:** [who they are]
**Common Problems:** [what they come with]
**Typical Results:** [what they achieve]

### Type 2: [e.g., "The Scaling CEO"]
**Profile:** [who they are]
**Common Problems:** [what they come with]
**Typical Results:** [what they achieve]

---

## Quantified Impact

| Metric | Total | Average Per Client |
|--------|-------|-------------------|
| Revenue Generated | $[X] | $[X] |
| Time Saved | [X] hours | [X] hours |
| [Custom Metric] | [X] | [X] |

---

## Client Quotes for Copy

### Results-Focused
> "[Quote about specific results]" — [Client]

### Process-Focused
> "[Quote about working together]" — [Client]

### Transformation-Focused
> "[Quote about personal change]" — [Client]

---

## Case Studies Available

| Title | Client | Result | Format | Link |
|-------|--------|--------|--------|------|
| [Case Study 1] | [Client] | [headline result] | [PDF/Video/etc.] | [link] |
| [Case Study 2] | [Client] | [headline result] | [PDF/Video/etc.] | [link] |

---

*Last Updated: [DATE]*
*Extracted from: [SOURCES]*
