# Personal Brand DNA Extractor
## Install Package v1.0

**Author:** Ashley Shaw
**Created:** February 4, 2026
**Purpose:** Extract a person's unique brand DNA from existing materials and create 8 AI-optimized files that power all copywriting and content creation with THEIR voice, THEIR stories, THEIR credentials.

---

## What This Skill Does

The Personal Brand DNA Extractor analyzes a person's:
- Social media presence (Instagram, LinkedIn, YouTube, etc.)
- Website and marketing materials
- Testimonials and case studies
- Video transcripts and speaking samples
- Professional credentials and achievements

And produces **8 markdown files** that any AI tool can use to write in that person's authentic voice.

---

## Installation

### Step 1: Copy the Skill File

Copy `SKILL.md` to your Claude skills folder:

```
.claude/skills/personal-brand-dna-extractor/SKILL.md
```

### Step 2: Create Output Location

Create a Voice DNA folder for each person you extract:

```
[Person Name]/Voice DNA/
```

### Step 3: (Optional) Copy Templates

Copy the template files from the `templates/` folder if you want blank starting points.

---

## How to Use

### Method 1: Run the Skill

In Claude Code, type:
```
/personal-brand-dna-extractor
```

Then provide:
1. Person's name
2. Website URL
3. LinkedIn profile URL
4. Instagram handle
5. YouTube channel URL
6. Any existing testimonials, bios, or presentations

### Method 2: Manual Extraction

Follow the process in `SKILL.md`:
1. Collect source materials
2. Access live social media feeds
3. Capture real voice samples
4. Create the 8 files

---

## Output Files

| File | Purpose |
|------|---------|
| `01-VOICE-AND-TONE.md` | How they actually sound (real voice samples, patterns) |
| `02-CREDENTIALS.md` | Quantified achievements, bios, authority claims |
| `03-TESTIMONIALS.md` | Social proof organized by theme |
| `04-ORIGIN-STORIES.md` | Transformation narratives with context |
| `05-MENTEES-AND-CLIENTS.md` | Client results and transformations |
| `06-PERSONAL-DETAILS.md` | Humanizing elements, background |
| `07-CORE-PHILOSOPHY.md` | Frameworks, beliefs, contrarian positions |
| `CLAUDE.md` | Index and usage guide |

---

## Critical Requirement: Live Feed Verification

**This skill MUST access live social media to work correctly.**

Polished website copy does NOT capture someone's real voice. The skill requires:
- Actual Instagram captions (verbatim)
- YouTube video transcripts
- LinkedIn posts (not just profile)
- Real examples of casual communication

Without this, the Voice DNA will be generic and polished rather than authentic.

---

## Package Contents

```
personal-brand-dna-extractor/
├── README.md                 # This file
├── SKILL.md                  # The main skill file (copy to .claude/skills/)
├── templates/                # Blank templates for each file
│   ├── 01-VOICE-AND-TONE-TEMPLATE.md
│   ├── 02-CREDENTIALS-TEMPLATE.md
│   ├── 03-TESTIMONIALS-TEMPLATE.md
│   ├── 04-ORIGIN-STORIES-TEMPLATE.md
│   ├── 05-MENTEES-AND-CLIENTS-TEMPLATE.md
│   ├── 06-PERSONAL-DETAILS-TEMPLATE.md
│   ├── 07-CORE-PHILOSOPHY-TEMPLATE.md
│   └── CLAUDE-TEMPLATE.md
└── examples/                 # Example outputs (Ashley Shaw's extraction)
    └── see /02 Ashley Shaw/Voice DNA/
```

---

## Integration with Other Skills

Once Brand DNA is extracted, it powers:

- **Copy Arsenal** - All 51 copywriting experts write in the person's voice
- **Webinar Arena** - Webinar scripts use their stories and credentials
- **Content Strategy** - Content matches their authentic voice
- **Any AI copywriting** - Reference the files for voice consistency

---

## Troubleshooting

### "The voice sounds generic"
You probably skipped live social media feeds. Go back and capture:
- 5+ Instagram captions verbatim
- 1+ YouTube transcript excerpt
- Note casual patterns (profanity, emojis, stretched words)

### "The credentials are missing"
Check LinkedIn profile thoroughly:
- Experience section
- Featured section
- Recommendations
- Skills & endorsements

### "No testimonials found"
Look in:
- LinkedIn recommendations
- Google Drive testimonials folder
- Website testimonials page
- Email inbox (client praise)

---

## Example Extraction

See `/02 Ashley Shaw/Voice DNA/` for a complete example of all 8 files extracted and populated.

Key example: The `01-VOICE-AND-TONE.md` file includes real Instagram captions like:

> "Ever tried REALLY hard to work with a potential customer who ended up just sucking the damn life out of you? (Drop a 😬 if this made you instantly think of something 😂)"

This captures the REAL voice - casual profanity, ALL CAPS emphasis, emoji prompts, pain-point-first structure.

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-02-04 | Initial release with live feed verification requirement |

---

*Created for ZenithPro students and anyone building AI-powered content systems.*
