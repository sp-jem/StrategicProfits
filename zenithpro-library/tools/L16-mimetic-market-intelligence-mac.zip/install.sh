#!/bin/bash
# Mimetic Market Intelligence — Mac Installer
# Installs skill to ~/.claude/skills/mimetic-market-intelligence/

SKILL_NAME="mimetic-market-intelligence"
SKILL_DIR="$HOME/.claude/skills/$SKILL_NAME"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "Installing $SKILL_NAME..."

mkdir -p "$SKILL_DIR/references"

cp "$SCRIPT_DIR/SKILL.md" "$SKILL_DIR/SKILL.md"
cp "$SCRIPT_DIR/how-it-works.md" "$SKILL_DIR/how-it-works.md" 2>/dev/null || true
cp "$SCRIPT_DIR/README.md" "$SKILL_DIR/README.md" 2>/dev/null || true
cp "$SCRIPT_DIR/references/"* "$SKILL_DIR/references/"

echo ""
echo "✅  Installed to: $SKILL_DIR"
echo ""
echo "Usage in Claude Code:"
echo "  /mimetic phase1 [your market]"
echo "  /mimetic phase2 [client name]"
echo "  /mimetic full [your market]"
echo ""
echo "Restart Claude Code to activate."
