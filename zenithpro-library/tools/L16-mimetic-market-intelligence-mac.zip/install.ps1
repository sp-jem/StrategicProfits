# Mimetic Market Intelligence — Windows Installer
# Installs skill to ~\.claude\skills\mimetic-market-intelligence\

$SkillName = "mimetic-market-intelligence"
$SkillDir  = "$env:USERPROFILE\.claude\skills\$SkillName"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "Installing $SkillName..."

New-Item -ItemType Directory -Force -Path "$SkillDir\references" | Out-Null

Copy-Item "$ScriptDir\SKILL.md"       "$SkillDir\SKILL.md"        -Force
Copy-Item "$ScriptDir\how-it-works.md" "$SkillDir\how-it-works.md" -Force -ErrorAction SilentlyContinue
Copy-Item "$ScriptDir\README.md"      "$SkillDir\README.md"       -Force -ErrorAction SilentlyContinue
Copy-Item "$ScriptDir\references\*"   "$SkillDir\references\"     -Force

Write-Host ""
Write-Host "Installed to: $SkillDir"
Write-Host ""
Write-Host "Usage in Claude Code:"
Write-Host "  /mimetic phase1 [your market]"
Write-Host "  /mimetic phase2 [client name]"
Write-Host "  /mimetic full [your market]"
Write-Host ""
Write-Host "Restart Claude Code to activate."
